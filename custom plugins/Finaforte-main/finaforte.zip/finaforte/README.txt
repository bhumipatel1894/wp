=== Finaforte: A Mortgage Calculator ===

Contributors: Nexuslink Services, Bhumi Patel
Tags: Loan caculator, Mortgage Calculator, ZZP hypotheek calculator
Tested upto Wordpress version: 6.0

This plugin will allow customers to calculate Loan for single, partner, freelancers, V.O.F, BV/DGA
Term period : 0.5 to 3 Y  

== Description ==

=== User Description ===

- This is Custom Plugin based on Mortgage Calculation requirement. 
- Plugin can calculate loan based on user profile (Freelancer, partner, V.O.F, BV/DGA) and terms  of years.
- User can get advicer help for any query
- On First page user will add all the details for loan and right side user will get all calculation and on page 2 user can get detailed Total calculation of Hypotheekberekening 1, Hypotheekberekening 2, Hypotheekberekening 3 and Hypotheekberekening 4
- User can send all calculation details via email on 3rd page. 

=== Admin Description ===

From Plugin Admin you will see admin menu "Finaforte".
There will be Setting options for plugin as per requirement.
In plugin folder There is calculation sheet based on that pluin calculate the Mortgage as per requirement. 
Admin can update that sheet for intrest change in the same formate. Plugin will fetch that changes automatically.

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload the `finaforte` folder to the `/wp-content/plugins/` directory OR Wp-admin > Plugins > Upload Plugin 
2. Activate the plugin through the 'Plugins' menu in WordPress
3. After Activation plugin admin will able to add/chnage settings like all color, text,input boxes everything are dynamic in the form.
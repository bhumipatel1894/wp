jQuery(document).ready(function($) {

	  jQuery('#btn_bg_color,#toggle_bg_clr, #toggle_text_clr, #loondienst_text_clr, #loondienst_bg_clr, #bv_dga_text_clr, #bv_dga_bg_clr, #vof_text_clr, #vof_bg_clr, #freelancer_text_clr, #freelancer_bg_clr, #loondienst_icon_clr,#call_sec_txt_color, #bv_dga_icon_clr, #vof_icon_clr, #freelancer_icon_clr,  #txt_border_color,#title_color, #subtitle_color, #gentext_color, #text_color, #btn_border_color, #btn_text_color ,#theme_bg_color,#solvency_green_color,#solvency_yellow_color,#solvency_red_color,#liquidity_red_color,#liquidity_green_color,#liquidity_yellow_color,#total_cal_border_clr,#total_cal_txt_clr,#email_cal_bgclr,#email_cal_borderclr,#email_btn_bgclr,#email_btn_txtclr, #email_icon_clr,#email_topname_clr,#total_cal_bg_clr,#divider_clr,#email_foo_bgclr, #email_cal_box_bgclr').wpColorPicker();
	
	$( document ).on( 'click', '.aigpl-img-uploader', function() {
		
		var imgfield, showfield;
		imgfield			= jQuery(this).prev('input').attr('id');
		showfield 			= jQuery(this).parents('td').find('.aigpl-imgs-preview');
		var multiple_img	= false;
		multiple_img 		= (typeof(multiple_img) != 'undefined' && multiple_img == 'true') ? true : false;
		
		if( typeof wp == "undefined" || FinaforteAdmin.new_ui != '1' ) { // check for media uploader
			
			tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
	    	
			window.original_send_to_editor = window.send_to_editor;
			window.send_to_editor = function(html) {
				
				if(imgfield)  {
					
					var mediaurl = $('img',html).attr('src');
					$('#'+imgfield).val(mediaurl);
					showfield.html('<img src="'+mediaurl+'" />');
					tb_remove();
					imgfield = '';
					
				} else {
					window.original_send_to_editor(html);
				}
			};
	    		return false;
		      
		} else {
			
			var file_frame;
			
			var button = jQuery(this);
		
			
			if ( file_frame ) {
				file_frame.open();
			  return;
			}

			if( multiple_img == true ) {
				
				
				file_frame = wp.media.frames.file_frame = wp.media({
					title: button.data( 'title' ),
					button: {
						text: button.data( 'button-text' ),
					},
					multiple: true  
				});
				
			} else {
				
				
				file_frame = wp.media.frames.file_frame = wp.media({
					frame: 'post',
					state: 'insert',
					title: button.data( 'title' ),
					button: {
						text: button.data( 'button-text' ),
					},
					multiple: false  // Set to true to allow multiple files to be selected
				});
			}
			
			file_frame.on( 'menu:render:default', function(view) {
		        
		        var views = {};
				
		        
		        view.unset('library-separator');
		        view.unset('gallery');
		        view.unset('featured-image');
		        view.unset('embed');
		        view.set(views);
		    });

			
			file_frame.on( 'select', function() {
				
				
				var selected_size = $('.attachment-display-settings .size').val();
				var selection = file_frame.state().get('selection');
				
				selection.each( function( attachment, index ) {
					
					attachment = attachment.toJSON();

					
					var attachment_id = attachment.id ? attachment.id : '';
					if( attachment_id && attachment.sizes && multiple_img == true ) {
						
						var attachment_url 			= attachment.sizes.thumbnail ? attachment.sizes.thumbnail.url : attachment.url;
						var attachment_edit_link	= attachment.editLink ? attachment.editLink : '';

						showfield.append('\
							<div class="aigpl-img-wrp">\
								<div class="aigpl-img-tools aigpl-hide">\
									<span class="aigpl-tool-icon aigpl-edit-img dashicons dashicons-edit" title="'+FinaforteAdmin.img_edit_popup_text+'"></span>\
									<a href="'+attachment_edit_link+'" target="_blank" title="'+FinaforteAdmin.attachment_edit_text+'"><span class="aigpl-tool-icon aigpl-edit-attachment dashicons dashicons-visibility"></span></a>\
									<span class="aigpl-tool-icon aigpl-del-tool aigpl-del-img dashicons dashicons-no" title="'+FinaforteAdmin.img_delete_text+'"></span>\
								</div>\
								<img class="aigpl-img" src="'+attachment_url+'" alt="" />\
								<input type="hidden" class="aigpl-attachment-no" name="aigpl_img[]" value="'+attachment_id+'" />\
							</div>\
								');
						showfield.find('.aigpl-img-placeholder').hide();
					}
				});
			});
			
			
			file_frame.on( 'insert', function() {
				
				
				var selected_size = $('.attachment-display-settings .size').val();
				
				var selection = file_frame.state().get('selection');
				selection.each( function( attachment, index ) {
					attachment = attachment.toJSON();
					
					
					var attachment_url = attachment.sizes[selected_size].url;
					
					
					$('#'+imgfield).val(attachment_url);
					showfield.html('<img src="'+attachment_url+'" />');
				});
			});
			
			
			file_frame.open();
		}
	});

	
	$(document).on('click', '.aigpl-image-clear', function(){
		$(this).parent().find('.aigpl-img-upload-input').val('');
		$(this).parent().find('.aigpl-imgs-preview').html('');
	});

	$('.error_Msg').hide(); 

  	
});
/**
 * Jquery to maintain finaforte work flow
 *
 * @package Fina Forte
 * @since 1.0
**/

jQuery(document).ready(function($){   

//iphone specific
var IS_IPHONE = navigator.userAgent.match(/iPhone/i) != null;

if(IS_IPHONE)
{     
    $('.form-control.numbers').addClass('iphoneInput');
}

/* function to initiate tooltip */
$(function () {
    $('[data-toggle="popover"]').popover()
})

/* Add class on click last vof/bv dga in range slider (css purpose) */
$("#rdo_ptype_4, #rdo_ptype_3").click(function(){
    $("div.demo-output").addClass("slider4");
});
$("#rdo_ptype_2, #rdo_ptype_1").click(function(){
    $("div.demo-output").removeClass("slider4");
});

/********************************
                           ******* page back functionality ******** 
                                            *******************************************/

/* show hide error msg box */
var p_notcompleted = $("#p_notcompleted").html();

if(p_notcompleted && p_notcompleted != '') {
    $("#p_notcompleted").show();     
} else {
    $("#p_notcompleted").hide();    
}

calculate_liquiditeitp();
calculate_liquiditeit();
calculate_solvabiliteitp();
calculate_solvabiliteit();
incomedata_calculation();

/* open close sol & liq accordian */
var h_solvabiliteit = $("#h_solvabiliteit").val();    
var h_liquiditeit = $("#h_liquiditeit").val();
if($("#txt_eigenvermogen_1").val() != '' || $("#txt_eigenvermogen_2").val() != '' || $("#txt_eigenvermogen_3").val() != '') {
    $("#card_collapse_11").click();
}
if($("#txt_vlottendeactiva_1").val() != '' || $("#txt_vlottendeactiva_2").val() != '' || $("#txt_vlottendeactiva_3").val() != '') {
    $("#card_collapse_22").click();
}

var lastBoxOpened = 0;

/* take var to get back selected type */
var dataId1 = $("#group1_in1").attr('data-id');
var dataId2 = $("#group1_tv1").attr('data-id');
var dataId3 = $("#group1_ph1").attr('data-id');
/* partner type selection */
var PdataId1 = $("#rdo_ptype_1").attr('data-id');
var PdataId2 = $("#rdo_ptype_2").attr('data-id');
var PdataId3 = $("#rdo_ptype_3").attr('data-id');
var PdataId4 = $("#rdo_ptype_4").attr('data-id');

var data = {
    action: 'ffc_final_result',
    is_ajax: 1
};
$.post(ffc.ajaxurl, data, function (response) {
     
    data = $.parseJSON(response);
    var h_totalincome = $('#h_totalincome').val(); 
           
});

/***************************************
                ******** start partner calculation for page back ********
                                                    ********************************/
/* partner yes no val */
var yn_switch = $("#yn_switch").attr('data-id');
var yn_switch = $("#yn_switch").val();

if (yn_switch == '1') {

    $("#p_notcompleted").show();
    $('#yn_switch').click();       
    $("#p_notcompleted").show();
    $(".sec-sep13").hide();        
    $("#div_box4_1").hide();        
    $("#div_box4").show();
    $("#div_box5").show();

    var h_solvabiliteitp = $("#h_solvabiliteitp").val();
    var h_liquiditeitp = $("#h_liquiditeitp").val();
    var data = {
        action: 'ffc_final_result',
        is_ajax: 1
    };
    $.post(ffc.ajaxurl, data, function (response) {
        /* Do Response Process */
        data = $.parseJSON(response);
            
    });

} else {
    $("#div_box4").hide();
    $("#div_box5").hide();
}

if (PdataId1 == '1') {
  
    $("#rdo_ptype_1").click();
    $("#div_box5").show();
    $("#div_box6").show();
    $("#accordion1").hide();
    $(".psec-sep6").hide();
    $(".psec-sep7").hide();
    $(".psec-sep2").hide();    
    $(".psec-sep3").hide();          
    $(".sec-sep16").hide();          
    $("#div_loondienst").show();

    /* set default year val 0 */
    $("#h_partnertypeselection").val('1');  
    var pyear = $('#h_partneryearselection').val();
    $("#div_rangeslider").html('<input id="single_slider_2" type="hidden" value="'+pyear+'"/><div class="gray-line1"></div><div class="gray-line2"></div><div class="gray-line3"></div>');
    $("#div_rangeslider").removeClass('demo-output2');

    $("#rdo_ptype_1").click();
    $("#div_forhalfyearp").hide();

    load_year_range_partner_session('1');
    incomedata_calculation();

} else {
        $("#div_loondienst").hide();
        $("#accordion1").show();
        $(".sec-sep16").show();   
}
if (PdataId4 == '4') {

    $("#div_box6").show();
    $("#p_notcompleted").show();
    $("#rdo_ptype_4").click();    
    $(".sec-sep13").show();
    $("#div_box4_1").show();
    $(".psec-sep3").hide();
    $(".psec-sep2").hide();
    $(".psec-sep6").show();
    $("#h_partnertypeselection").val('4');

    if($('input[name="ponoffswitch3"]').val() == '1') {
        $('input[name="ponoffswitch3"]').click();
        $(".psec-sep7").show();
    } else if($('input[name="ponoffswitch3"]').val() == '0'){
        $(".psec-sep7").hide();
    }
    $('input[name="ponoffswitch3"]').click(function(){
        if($(this).prop("checked") == true){
            $('input[name="ponoffswitch3"]').val("0");
            $('#pdiv_holdingtext').hide();
            $(".psec-sep7").hide();
        } else {
            $('input[name="ponoffswitch3"]').val("1");
            $('#pdiv_holdingtext').show();
            $(".psec-sep7").show();
        }
    });

    var pyear = $('#h_partneryearselection').val();
    $("#div_rangeslider").html('<input id="single_slider_2" type="hidden" value="'+pyear+'"/><div class="gray-line1"></div><div class="gray-line2"></div><div class="gray-line3"></div>');
    $("#div_rangeslider").removeClass('demo-output2');

    $("#div_inkomensgegevensp_1").show();
    $("#div_inkomensgegevensp_2").show();
    $("#div_inkomensgegevensp_3").show();

    load_year_range_partner_session('4');
    incomedata_calculation();

}  else {
    $("#div_inkomensgegevensp_1").hide();
    $("#div_inkomensgegevensp_2").hide();
    $("#div_inkomensgegevensp_3").hide();
    $(".psec-sep6").hide();
    $(".psec-sep7").hide();
    $(".psec-sep2").hide();
    $(".psec-sep3").hide();
} 

if (PdataId3 == '3') {
    $("#div_box5").show();
    $("#rdo_ptype_3").click();
    $("#p_notcompleted").show();
    $(".psec-sep3").hide();
    $(".psec-sep2").hide();
    $(".psec-sep6").hide();
    $(".psec-sep7").hide();
    $("#h_partnertypeselection").val('3');
    var pyear = $('#h_partneryearselection').val();
    $(".sec-sep13").show();
    $("#div_box4_1").show();

    $("#div_rangeslider").html('<input id="single_slider_2" type="hidden" value="'+pyear+'"/><div class="gray-line1"></div><div class="gray-line2"></div><div class="gray-line3"></div>');
    $("#div_rangeslider").removeClass('demo-output2');
    $("#rdo_ptype_3").click();
    load_year_range_partner_session('3');

    $("#div_winstuitondernemingp_1").show();
    $("#div_winstuitondernemingp_2").show();
    $("#div_winstuitondernemingp_3").show();
    incomedata_calculation();
}

if (PdataId2 == '2') {

    $("#div_box5").show();
    $("#p_notcompleted").show();
    $("#rdo_ptype_2").click();
    $(".sec-sep2").hide();
    $(".sec-sep3").hide();
    $(".psec-sep3").hide();
    $(".psec-sep6").hide();
    $(".psec-sep7").hide();    
    $(".sec-sep13").show();
    $("#div_box4_1").show();
    $("#h_partnertypeselection").val('2');
    $("#div_rangeslider").append('<div class="gray-line4"></div>');
   
    $("#div_rangeslider").addClass('demo-output2');
    load_year_range_partner_session('2');
    incomedata_calculation();

    $('input[name="ponoffswitch1"]').click(function(){
        if($(this).prop("checked") == true){
            $('input[name="ponoffswitch1"]').val("0");
            $(".psec-sep2").show();
            $('#pdiv_holdingtext1').show();
            $(".psec-sep3").hide();
            /*remove disable inputs*/
            $("#txt_halfyearp_first").attr("disabled", false);
            $("#txt_halfyearp_second").attr("disabled", false);
            $("#txt_halfyearp_third").attr("disabled", false);
        } else {
            $('input[name="ponoffswitch1"]').val("1");            
            $(".psec-sep3").show();
            $(".psec-sep2").show();
            $("#txt_halfyearp_first").attr("disabled", true);
            $("#txt_halfyearp_second").attr("disabled", true);
            $("#txt_halfyearp_third").attr("disabled", true);
        }
    });  

    if($('input[name="ponoffswitch1"]').val() == '1'){                  
        $(".psec-sep3").show();
        $(".psec-sep2").show();
        $("#ponoffswitch1").click();
        /*disable inputs*/
        $("#txt_halfyearp_first").attr("disabled", true);
        $("#txt_halfyearp_second").attr("disabled", true);
        $("#txt_halfyearp_third").attr("disabled", true);        
    } else if($('input[name="ponoffswitch1"]').val() == '0'){        
        $(".psec-sep3").hide();
        /*remove disable inputs*/
        $("#txt_halfyearp_first").attr("disabled", false);
        $("#txt_halfyearp_second").attr("disabled", false);
        $("#txt_halfyearp_third").attr("disabled", false);
    }
} else {
    $(".psec-sep2").hide();
    $(".psec-sep3").hide();
}

function load_year_range_partner_session(typeselection){

    var value = jQuery('#single_slider_2').val();       
    if (typeselection == '2') {
        var range_from = 0;
        var range_scale = [0.5, 1, 2, 3];
        if (windowSize <= 767) {}    

    } else {
        var range_from = 1;
        var range_scale = [1, 2, 3];
    }
    
    var windowSize = jQuery(window).width();
    var newwidth = 400;

    if (windowSize >= 993) {
        newwidth =  400;
    }
    if (windowSize >= 768 && windowSize <= 992 ) {
         newwidth = 370;
    }
    else if (windowSize <= 767 && windowSize >= 480 ) {
        newwidth = 350;
    }
     else if (windowSize <= 479) {
        newwidth =  jQuery(".start-box").width() - 20;
    }
   
    jQuery("#single_slider_2").jRange({
        from: range_from,
        to: 3,
        step: 1,
        scale: range_scale,
        format: "jaar",
        width: newwidth,
        showLabels: true,
        snap: true,
        onstatechange: function (value) {
            
            jQuery("#div_winstuitondernemingp").hide();      

            if (typeselection != '1' && typeselection == '2') {
                jQuery("#h_partneryearselection").val(value);

                if (value == '0') {
                    jQuery(".slider-container .back-bar .pointer-label").css("margin-left","-11px");  
                    jQuery("#div_forhalfyearp").show();
                    jQuery(".psec-sep2").show();
                    jQuery("#pdiv_holding1").show();
                  
                    if(jQuery('input[name="ponoffswitch1"]').val() == '1'){                       
                        jQuery(".psec-sep3").show();
                        jQuery(".psec-sep2").show();
                    } else if(jQuery('input[name="ponoffswitch1"]').val() == '0'){                
                        jQuery(".psec-sep3").hide();
                    } 
                    jQuery('input[name="ponoffswitch1"]').click(function(){
                        if(jQuery(this).prop("checked") == true){
                            jQuery('input[name="ponoffswitch1"]').val("0");                        
                            jQuery(".psec-sep3").hide();
                        } else {
                            jQuery('input[name="ponoffswitch1"]').val("1");                        
                            jQuery(".psec-sep3").show();
                        }
                    });     
                    incomedata_calculation();   
                } else if (value == "1") { 
                    jQuery(".slider-container .back-bar .pointer-label").css("margin-left","0px"); 
                    jQuery(".psec-sep2").hide();
                    jQuery(".psec-sep3").hide();
                    jQuery("#div_forhalfyearp").hide();
                    if (typeselection == '4') {
                        jQuery("#div_inkomensgegevensp_2 :input").attr("disabled", true);
                        jQuery("#div_inkomensgegevensp_3 :input").attr("disabled", true);
                    } else {
                        jQuery("#div_winstuitondernemingp").show();
                        jQuery("#div_winstuitondernemingp_2 :input").attr("disabled", true);
                        jQuery("#div_winstuitondernemingp_3 :input").attr("disabled", true);
                    }

                    jQuery("#div_solvabiliteitp_2 :input").attr("disabled", true);
                    jQuery("#div_solvabiliteitp_3 :input").attr("disabled", true);
                    jQuery("#div_liquiditeitp_2 :input").attr("disabled", true);
                    jQuery("#div_liquiditeitp_3 :input").attr("disabled", true);
                    incomedata_calculation();   
                } else if (value == "2") {
                      
                    jQuery(".slider-container .back-bar .pointer-label").css("margin-left","0px"); 
                    jQuery(".psec-sep2").hide();
                    jQuery(".psec-sep3").hide();
                    jQuery("#div_forhalfyearp").hide();

                    if (typeselection == '4') {

                        jQuery(".psec-sep2").hide();
                        jQuery(".psec-sep3").hide();
                        jQuery("#div_inkomensgegevensp_2 :input").attr("disabled", false);
                        jQuery("#div_inkomensgegevensp_3 :input").attr("disabled", true);
                    } else {
                        jQuery("#div_winstuitondernemingp").show();
                        jQuery("#div_winstuitondernemingp_2 :input").attr("disabled", false);
                        jQuery("#div_winstuitondernemingp_3 :input").attr("disabled", true);
                    }

                    jQuery("#div_solvabiliteitp_2 :input").attr("disabled", false);
                    jQuery("#div_solvabiliteitp_3 :input").attr("disabled", true);
                    jQuery("#div_liquiditeitp_2 :input").attr("disabled", false);
                    jQuery("#div_liquiditeitp_3 :input").attr("disabled", true);
                    incomedata_calculation();   
                } else if (value == "3") {
                      
                    jQuery(".slider-container .back-bar .pointer-label").css("margin-left","14px"); 
                    jQuery(".psec-sep2").hide();
                    jQuery(".psec-sep3").hide();
                    jQuery("#div_forhalfyearp").hide();

                    if (typeselection == '4') {

                        jQuery(".psec-sep2").hide();
                        jQuery(".psec-sep3").hide();
                        jQuery("#div_inkomensgegevensp_2 :input").attr("disabled", false);
                        jQuery("#div_inkomensgegevensp_3 :input").attr("disabled", false);
                    } else {
                        jQuery("#div_winstuitondernemingp").show();
                        jQuery("#div_winstuitondernemingp_2 :input").attr("disabled", false);
                        jQuery("#div_winstuitondernemingp_3 :input").attr("disabled", false);
                    }

                    jQuery("#div_solvabiliteitp_2 :input").attr("disabled", false);
                    jQuery("#div_solvabiliteitp_3 :input").attr("disabled", false);
                    jQuery("#div_liquiditeitp_2 :input").attr("disabled", false);
                    jQuery("#div_liquiditeitp_3 :input").attr("disabled", false);
                    incomedata_calculation();   
                }

            } else {

                jQuery(".psec-sep2").hide();
                jQuery("#div_solvabiliteitp_2 :input").attr("disabled", true);
                jQuery("#div_solvabiliteitp_3 :input").attr("disabled", true);
                jQuery("#div_liquiditeitp_2 :input").attr("disabled", true);
                jQuery("#div_liquiditeitp_3 :input").attr("disabled", true);
            }
        }
    });

    jQuery("#div_winstuitondernemingp").hide();            

    if (typeselection != '1') {
        jQuery("#h_partneryearselection").val(value);

        if (value == '0') {

            if (value == "0") {
                jQuery(".psec-sep2").show();
                jQuery("#div_forhalfyear").show();
                jQuery("#div_winstuitonderneming").hide();
                if( jQuery("#txt_eigenvermogenp_1").val() != '' ||  jQuery("#txt_balanstotaalp_1").val() != '' ){
                    jQuery('#card_sol_11').click();
                } 
                if(jQuery("#txt_vlottendeactivap_1").val() != '' ||  jQuery("#txt_kortvreemdvermogenp_1").val() != '' ) {
                    jQuery('#card_liq_22').click();
                }
            } else {
                jQuery("#div_forhalfyear").hide();
                jQuery("#div_winstuitonderneming").show();
            }

            jQuery("#div_forhalfyearp").show();
            jQuery("#div_solvabiliteitp_2 :input").attr("disabled", true);
            jQuery("#div_solvabiliteitp_3 :input").attr("disabled", true);
            jQuery("#div_liquiditeitp_2 :input").attr("disabled", true);
            jQuery("#div_liquiditeitp_3 :input").attr("disabled", true);
            incomedata_calculation();

        } else if (value == "1") {

            jQuery("#div_forhalfyearp").hide();
            if( jQuery("#txt_eigenvermogenp_1").val() != '' ||  jQuery("#txt_balanstotaalp_1").val() != '' ){
                jQuery('#card_sol_11').click();
            } 
            if(jQuery("#txt_vlottendeactivap_1").val() != '' ||  jQuery("#txt_kortvreemdvermogenp_1").val() != '' ) {
                jQuery('#card_liq_22').click();
            }

            if (typeselection == '4') {
                jQuery("#div_inkomensgegevensp_2 :input").attr("disabled", true);
                jQuery("#div_inkomensgegevensp_3 :input").attr("disabled", true);
            } else {
                jQuery("#div_winstuitondernemingp").show();
                jQuery("#div_winstuitondernemingp_2 :input").attr("disabled", true);
                jQuery("#div_winstuitondernemingp_3 :input").attr("disabled", true);
            }

            jQuery("#div_solvabiliteitp_2 :input").attr("disabled", true);
            jQuery("#div_solvabiliteitp_3 :input").attr("disabled", true);
            jQuery("#div_liquiditeitp_2 :input").attr("disabled", true);
            jQuery("#div_liquiditeitp_3 :input").attr("disabled", true);
            incomedata_calculation();

        } else if (value == "2") {

            jQuery("#div_forhalfyearp").hide();

            if( jQuery("#txt_eigenvermogenp_1").val() != '' ||  jQuery("#txt_balanstotaalp_1").val() != '' || jQuery("#txt_eigenvermogenp_2").val() != '' || jQuery("#txt_balanstotaalp_2").val() != '' ){
                jQuery('#card_sol_11').click();
            } 
            if(jQuery("#txt_vlottendeactiva_1").val() != '' ||  jQuery("#txt_kortvreemdvermogen_1").val() != '' || jQuery("#txt_vlottendeactivap_2").val() != '' || jQuery("#txt_kortvreemdvermogenp_2").val() != '' ) {
                jQuery('#card_liq_22').click();
            }

            if (typeselection == '4') {
                jQuery("#div_inkomensgegevensp_2 :input").attr("disabled", false);
                jQuery("#div_inkomensgegevensp_3 :input").attr("disabled", true);
            } else {
                jQuery("#div_winstuitondernemingp").show();
                jQuery("#div_winstuitondernemingp_2 :input").attr("disabled", false);
                jQuery("#div_winstuitondernemingp_3 :input").attr("disabled", true);
            }

            jQuery("#div_solvabiliteitp_2 :input").attr("disabled", false);
            jQuery("#div_solvabiliteitp_3 :input").attr("disabled", true);
            jQuery("#div_liquiditeitp_2 :input").attr("disabled", false);
            jQuery("#div_liquiditeitp_3 :input").attr("disabled", true);
            incomedata_calculation();

        } else if (value == "3") {

            jQuery("#div_forhalfyearp").hide();

            if( jQuery("#txt_eigenvermogenp_1").val() != '' ||  jQuery("#txt_balanstotaalp_1").val() != '' || jQuery("#txt_eigenvermogenp_2").val() != '' || jQuery("#txt_balanstotaalp_2").val() != '' || jQuery("#txt_eigenvermogenp_3").val() != '' || jQuery("#txt_balanstotaalp_3").val() != '' ){
                jQuery('#card_sol_11').click();
            } 
            if(jQuery("#txt_vlottendeactiva_1").val() != '' ||  jQuery("#txt_kortvreemdvermogen_1").val() != '' || jQuery("#txt_vlottendeactivap_2").val() != '' || jQuery("#txt_kortvreemdvermogenp_2").val() != '' || jQuery("#txt_vlottendeactivap_3").val() != '' || jQuery("#txt_kortvreemdvermogenp_3").val() != '' ) {
                jQuery('#card_liq_22').click();
            }

            if (typeselection == '4') {
                jQuery("#div_inkomensgegevensp_2 :input").attr("disabled", false);
                jQuery("#div_inkomensgegevensp_3 :input").attr("disabled", false);
            } else {
                jQuery("#div_winstuitondernemingp").show();
                jQuery("#div_winstuitondernemingp_2 :input").attr("disabled", false);
                jQuery("#div_winstuitondernemingp_3 :input").attr("disabled", false);
            }

            jQuery("#div_solvabiliteitp_2 :input").attr("disabled", false);
            jQuery("#div_solvabiliteitp_3 :input").attr("disabled", false);
            jQuery("#div_liquiditeitp_2 :input").attr("disabled", false);
            jQuery("#div_liquiditeitp_3 :input").attr("disabled", false);
            incomedata_calculation();

        }
    } else {

        if( jQuery("#txt_eigenvermogenp_1").val() != '' ||  jQuery("#txt_balanstotaalp_1").val() != '' ){
            jQuery('#card_sol_11').click();
        } 
        if(jQuery("#txt_vlottendeactivap_1").val() != '' ||  jQuery("#txt_kortvreemdvermogenp_1").val() != '' ) {
            jQuery('#card_liq_22').click();
        }

        jQuery("#div_solvabiliteitp_2 :input").attr("disabled", true);
        jQuery("#div_solvabiliteitp_3 :input").attr("disabled", true);
        jQuery("#div_liquiditeitp_2 :input").attr("disabled", true);
        jQuery("#div_liquiditeitp_3 :input").attr("disabled", true);
        incomedata_calculation();
    }
}   

/************* End partner type calculation ***************************/ 
/****************************
                ****************** start calculation for single type *************
                                                        ************************************/
if(dataId1 == 'in1') { 

   $("#group1_in1").click(); 
   $("#div_box111 #in1").show();
   $("#div_box6").show();
   $(".sec-sep2").show();
   $("#p_notcompleted").show(); 
               
    var boxNumber = parseInt($(this).parents('.desc').attr("data-box"));
    /*check if the data-box was succesfully retrieved. If not, first option chosen, reset all of it*/
    if (isNaN(boxNumber)) {
        boxNumber = 0;
    }   
    var groupval = 'in1';
    var target = $("#" + groupval);
    var newBoxOpened = target.attr("data-box");
    /*check if the last opened box was an earlier one than the newly clicked one*/
    if (lastBoxOpened > boxNumber) {
        /*hide boxes beyond the one we opened now*/
        $('.desc').each(function () {
           /* if box number is bigger than the currently clicked box, close them.*/
            if ($(this).attr("data-box") > boxNumber) {
                $(this).hide();
                /*uncheck the previously selected radio buttons in now hidden things*/
                $('input', this).prop("checked", false);
            }
        });
    }
    /*render target box*/
    $("#div_box111").show();
    target.show(); 

    $('[data-toggle="popover"]').popover();
    /*update last opened box to the newly opened one*/
    lastBoxOpened = newBoxOpened;

    $("#div_box2").show();
    $("#div_box3").show();
    $("#h_typeselection").val(groupval);
    incomedata_calculation();
    if (groupval == 'in1') {

        $("#h_yearselection").val('0');        
        $(".sec-sep2").show();
        $("#div_box111 #in1").show();
        $("#div_holding1").show();
        /*remove disable inputs*/
        $("#txt_halfyear_first").attr("disabled", false);
        $("#txt_halfyear_second").attr("disabled", false);
        $("#txt_halfyear_third").attr("disabled", false);         
        incomedata_calculation();
        if($('input[name="onoffswitch1"]').val() == '1') {
            $('#div_holdingtext1').show();
            $(".sec-sep3").show();
            $("#myonoffswitch1").click();
            /*disable inputs*/
            $("#txt_halfyear_first").attr("disabled", true);
            $("#txt_halfyear_second").attr("disabled", true);
            $("#txt_halfyear_third").attr("disabled", true);

        } else if($('input[name="onoffswitch1"]').val() == '0') {
            
            $('#div_holdingtext1').hide();
            $(".sec-sep3").hide();
            /*remove disable inputs on 0 val */
            $("#txt_halfyear_first").attr("disabled", false);
            $("#txt_halfyear_second").attr("disabled", false);
            $("#txt_halfyear_third").attr("disabled", false);
            incomedata_calculation();
        }

        $('input[name="onoffswitch1"]').click(function(){

            if($(this).prop("checked") == true){

                $('input[name="onoffswitch1"]').val('0');
                $(".sec-sep3").hide();
                $('#div_holdingtext1').hide();
                /*remove disable inputs on 0 val */
                $("#txt_halfyear_first").attr("disabled", false);
                $("#txt_halfyear_second").attr("disabled", false);
                $("#txt_halfyear_third").attr("disabled", false);
                
            } else {
                $('input[name="onoffswitch1"]').val('1');
                $('#div_holdingtext1').show();
                $(".sec-sep3").show();
                /*disable inputs*/
                $("#txt_halfyear_first").attr("disabled", true);
                $("#txt_halfyear_second").attr("disabled", true);
                $("#txt_halfyear_third").attr("disabled", true);
            }
        });
            
        $("#div_inkomensgegevens_1").hide();
        $("#div_inkomensgegevens_2").hide();
        $("#div_inkomensgegevens_3").hide();

        $("#div_solvabiliteit_2 :input").attr("disabled", true);
        $("#div_solvabiliteit_3 :input").attr("disabled", true);
        $("#div_liquiditeit_2 :input").attr("disabled", true);
        $("#div_liquiditeit_3 :input").attr("disabled", true);

        if($("#h_yearselection").val() == '0'){
            $(".sec-sep2").show();
        }
       incomedata_calculation();
        var windowSize = $(window).width();
        var newwidth = 400;

        if (windowSize >= 993) {
            newwidth =  400;
        }
        if (windowSize >= 768 && windowSize <= 992 ) {
             newwidth = 370;
        }
        else if (windowSize <= 767 && windowSize >= 480 ) {
        newwidth = 350;
        }
        else if (windowSize <= 767) {
            newwidth =  $(".start-box").width() - 20;
        }
        

        $("#single_slider_first").jRange({
            from: 0,
            to: 3,
            step: 1,
            scale: [0.5, 1.0, 2.0, 3],
            format: "jaar",
            width: newwidth,
            showLabels: true,
            snap: true,
            onstatechange: function (value) { 
                $("#h_yearselection").val(value);

                if (value == "0") {
                      
                    $(".slider-container .back-bar .pointer-label").css("margin-left","-11px"); 
                    $("#div_forhalfyear").show();
                    $("#div_winstuitonderneming").hide();
                    $('#h_yearselection').val(value);                       
                    $(".sec-sep2").show();                        
                    $("#div_holding1").show();
                    
                    if($('input[name="onoffswitch1"]').val() == '1') {
                        $('#div_holdingtext1').show();
                        $(".sec-sep3").show();                        
                    } else if($('input[name="onoffswitch1"]').val() == '0') {
                        $('#div_holdingtext1').hide();
                        $(".sec-sep3").hide();
                        $(".sec-sep2").hide();
                    }
                    else {
                        $('input[name="onoffswitch1"]').click(function(){
                            if($(this).prop("checked") == true){
                                 $('input[name="onoffswitch1"]').val('0');
                                $(".sec-sep3").hide();

                                $('#div_holdingtext1').hide();
                                
                            } else {
                                 $('input[name="onoffswitch1"]').val('1');
                                $('#div_holdingtext1').show();
                                $(".sec-sep3").show();
                            }
                        });
                    }
                     incomedata_calculation();
                    
                } else {
                    $(".sec-sep2").hide();
                    $(".sec-sep3").hide();
                    $("#div_holding1").hide();
                    $("#div_holdingtext1").hide();
                    $("#div_forhalfyear").hide();
                    $("#div_winstuitonderneming").show();
                }

                if (value == "1") { 
                      
                    $(".slider-container .back-bar .pointer-label").css("margin-left","0px"); 
                    $(".sec-sep2").hide();
                    $("#div_holding1").hide();
                    $(".sec-sep3").hide();
                    $("#div_holdingtext1").hide();
                    $("#div_winstuitonderneming_2 :input").attr("disabled", true);
                    $("#div_winstuitonderneming_3 :input").attr("disabled", true);
                    $("#div_solvabiliteit_2 :input").attr("disabled", true);
                    $("#div_solvabiliteit_3 :input").attr("disabled", true);
                    $("#div_liquiditeit_2 :input").attr("disabled", true);
                    $("#div_liquiditeit_3 :input").attr("disabled", true);
                    $('#h_yearselection').val(value);
                    incomedata_calculation();

                } else if (value == "2") {
                     
                    $(".slider-container .back-bar .pointer-label").css("margin-left","0px");  
                    $(".sec-sep2").hide();
                    $(".sec-sep3").hide();
                    $("#div_winstuitonderneming_2 :input").attr("disabled", false);
                    $("#div_winstuitonderneming_3 :input").attr("disabled", true);
                    $("#div_solvabiliteit_2 :input").attr("disabled", false);
                    $("#div_solvabiliteit_3 :input").attr("disabled", true);
                    $("#div_liquiditeit_2 :input").attr("disabled", false);
                    $("#div_liquiditeit_3 :input").attr("disabled", true);
                    $('#h_yearselection').val(value);
                    incomedata_calculation();
                } else if (value == "3") {
                      
                    $(".slider-container .back-bar .pointer-label").css("margin-left","14px"); 
                    $(".sec-sep2").hide();
                    $(".sec-sep3").hide();
                    $("#div_winstuitonderneming_2 :input").attr("disabled", false);
                    $("#div_winstuitonderneming_3 :input").attr("disabled", false);
                    $("#div_solvabiliteit_2 :input").attr("disabled", false);
                    $("#div_solvabiliteit_3 :input").attr("disabled", false);
                    $("#div_liquiditeit_2 :input").attr("disabled", false);
                    $("#div_liquiditeit_3 :input").attr("disabled", false);
                    $('#h_yearselection').val(value);
                    incomedata_calculation();

                }                
            }
        });

        var value = $("#single_slider_first").val();
                   
        if (value == "0") {

            $(".sec-sep2").show();
            $(".sec-sep3").hide();
            $("#div_forhalfyear").show();
            $("#div_winstuitonderneming").hide();
            $('#h_yearselection').val(value);
            incomedata_calculation();

        } else {
            $("#div_forhalfyear").hide();
            $("#div_winstuitonderneming").show();
        }

        if (value == "1") {

            $(".sec-sep2").hide();
            $(".sec-sep3").hide();
            $('#h_yearselection').val(value);
            if( $("#txt_eigenvermogen_1").val() != '' ||  $("#txt_balanstotaal_1").val() != '' ){
                $('#card_collapse_11').click();
            } 
            if($("#txt_vlottendeactiva_1").val() != '' ||  $("#txt_kortvreemdvermogen_1").val() != '' ) {
                $('#card_collapse_22').click();
            }
            $("#div_winstuitonderneming_2 :input").attr("disabled", true);
            $("#div_winstuitonderneming_3 :input").attr("disabled", true);

            $("#div_solvabiliteit_2 :input").attr("disabled", true);
            $("#div_solvabiliteit_3 :input").attr("disabled", true);

            $("#div_liquiditeit_2 :input").attr("disabled", true);
            $("#div_liquiditeit_3 :input").attr("disabled", true);
            incomedata_calculation();
        
        } else if (value == "2") {

            $('#h_yearselection').val(value);
            if( $("#txt_eigenvermogen_1").val() != '' ||  $("#txt_balanstotaal_1").val() != '' || $("#txt_eigenvermogen_2").val() != '' || $("#txt_balanstotaal_2").val() != '' ){
                $('#card_collapse_11').click();
            } 
            if($("#txt_vlottendeactiva_1").val() != '' ||  $("#txt_kortvreemdvermogen_1").val() != '' || $("#txt_vlottendeactiva_2").val() != '' || $("#txt_kortvreemdvermogen_2").val() != '' ) {
                $('#card_collapse_22').click();
            }
            $("#div_winstuitonderneming_2 :input").attr("disabled", false);
            $("#div_winstuitonderneming_3 :input").attr("disabled", true);

            $("#div_solvabiliteit_2 :input").attr("disabled", false);
            $("#div_solvabiliteit_3 :input").attr("disabled", true);

            $("#div_liquiditeit_2 :input").attr("disabled", false);
            $("#div_liquiditeit_3 :input").attr("disabled", true);
            incomedata_calculation();
           
        } else if (value == "3") {

            $('#h_yearselection').val(value);
            if( $("#txt_eigenvermogen_1").val() != '' ||  $("#txt_balanstotaal_1").val() != '' || $("#txt_eigenvermogen_2").val() != '' || $("#txt_balanstotaal_2").val() != '' || $("#txt_eigenvermogen_3").val() != '' || $("#txt_balanstotaal_3").val() != '' ){
                $('#card_collapse_11').click();
            } 
            if($("#txt_vlottendeactiva_1").val() != '' ||  $("#txt_kortvreemdvermogen_1").val() != '' || $("#txt_vlottendeactiva_2").val() != '' || $("#txt_kortvreemdvermogen_2").val() != '' || $("#txt_vlottendeactiva_3").val() != '' || $("#txt_kortvreemdvermogen_3").val() != '' ) {
                $('#card_collapse_22').click();
            }
            $("#div_winstuitonderneming_2 :input").attr("disabled", false);
            $("#div_winstuitonderneming_3 :input").attr("disabled", false);

            $("#div_solvabiliteit_2 :input").attr("disabled", false);
            $("#div_solvabiliteit_3 :input").attr("disabled", false);

            $("#div_liquiditeit_2 :input").attr("disabled", false);
            $("#div_liquiditeit_3 :input").attr("disabled", false);
            incomedata_calculation();
            
        }       

    } else {

        $("#h_yearselection").val('1');
        $(".sec-sep2").hide();
        $(".sec-sep3").hide();
    } 
} 

if(dataId3 == 'ph1') { 

    $("#group1_ph1").click();
    $("#p_notcompleted").show(); 
    $("#div_box6").show();
    $('#in1').hide();
    $('#div_box111').show();
    $('#ph1').show();
    $('.sec-sep5').show();
    $('.sec-sep6').show();    
    $('#div_forhalfyear').hide();

    var boxNumber = parseInt($(this).parents('.desc').attr("data-box"));

    /*check if the data-box was succesfully retrieved. If not, first option chosen, reset all of it*/
    if (isNaN(boxNumber)) {
        boxNumber = 0;
    }

    var groupval = 'ph1';
    var target = $("#" + groupval);
    var newBoxOpened = target.attr("data-box");
    /*check if the last opened box was an earlier one than the newly clicked one*/
    if (lastBoxOpened > boxNumber) {
       /* hide boxes beyond the one we opened now*/
        $('.desc').each(function () {
            //if box number is bigger than the currently clicked box, close them.
            if ($(this).attr("data-box") > boxNumber) {
                $(this).hide();
                //uncheck the previously selected radio buttons in now hidden things
                $('input', this).prop("checked", false);
            }
        });
    }
    /*render target box*/
    target.show();
    $('[data-toggle="popover"]').popover();
    /*update last opened box to the newly opened one*/
    lastBoxOpened = newBoxOpened;
    $("#div_box2").show();
    $("#div_box3").show();
    $("#h_typeselection").val(groupval);

    if (groupval == 'ph1') {
        
        $("#div_holding").show();
        $('.sec-sep7').hide();

        if($('input[name="onoffswitch3"]').val() == '1') { 
        $('input[name="onoffswitch3"]').click();               
            $('.sec-sep7').show();
        } else if($('input[name="onoffswitch3"]').val() == '0'){                
            $('.sec-sep7').hide();
        }

        $('input[name="onoffswitch3"]').click(function(){
            
            if($(this).prop("checked") == true){
                $('input[name="onoffswitch3"]').val("0");
                $(".sec-sep7").hide();
               
            } else {
                $('input[name="onoffswitch3"]').val("1");
                $(".sec-sep7").show();
                
            }
        });
        incomedata_calculation();
    }
    if (groupval == 'ph1') {   
        $("#div_forhalfyear").hide();
        $("#div_winstuitonderneming").hide();
        $("#div_inkomensgegevens_1").show();
        $("#div_inkomensgegevens_2").show();
        $("#div_inkomensgegevens_3").show();
        var windowSize = $(window).width();
        var newwidth = 400;

        if (windowSize >= 993) {
            newwidth =  400;

        }
        if (windowSize >= 768 && windowSize <= 992 ) {
             newwidth = 370;
        }
         else if (windowSize <= 767 && windowSize >= 480 ) {
        newwidth = 350;
        }
        else if (windowSize <= 767) {
           newwidth =  $(".start-box").width() - 20;
        }
        incomedata_calculation();

    $("#single_slider_ph1").jRange({
            from: 1,
            to: 3,
            step: 1,
            scale: [1.0, 2.0, 3],
            format: "jaar",
            width: newwidth,
            showLabels: true,
            snap: true,
            onstatechange: function (value) {
                $("#h_yearselection").val(value);

                if (value == "1") {
                      
                    $(".slider-container .back-bar .pointer-label").css("margin-left","-11px"); 
                    $('#h_yearselection').val(value);
                    $("#div_inkomensgegevens_2 :input").attr("disabled", true);
                    $("#div_inkomensgegevens_3 :input").attr("disabled", true);
                    $("#div_solvabiliteit_2 :input").attr("disabled", true);
                    $("#div_solvabiliteit_3 :input").attr("disabled", true);
                    $("#div_liquiditeit_2 :input").attr("disabled", true);
                    $("#div_liquiditeit_3 :input").attr("disabled", true);
                    incomedata_calculation();

                } else if (value == "2") {
                      
                    $(".slider-container .back-bar .pointer-label").css("margin-left","0px"); 
                    $('#h_yearselection').val(value);
                    $("#div_inkomensgegevens_2 :input").attr("disabled", false);
                    $("#div_inkomensgegevens_3 :input").attr("disabled", true);
                    $("#div_solvabiliteit_2 :input").attr("disabled", false);
                    $("#div_solvabiliteit_3 :input").attr("disabled", true);
                    $("#div_liquiditeit_2 :input").attr("disabled", false);
                    $("#div_liquiditeit_3 :input").attr("disabled", true);
                    incomedata_calculation();

                } else if (value == "3") {
                     
                    $(".slider-container .back-bar .pointer-label").css("margin-left","14px");  
                    $('#h_yearselection').val(value);
                    $("#div_inkomensgegevens_2 :input").attr("disabled", false);
                    $("#div_inkomensgegevens_3 :input").attr("disabled", false);
                    $("#div_solvabiliteit_2 :input").attr("disabled", false);
                    $("#div_solvabiliteit_3 :input").attr("disabled", false);
                    $("#div_liquiditeit_2 :input").attr("disabled", false);
                    $("#div_liquiditeit_3 :input").attr("disabled", false);
                    incomedata_calculation();
                }                
            }
        });
       var value = $("#single_slider_ph1").val();

        if (value == "1") {

            $('#h_yearselection').val(value);
            if( $("#txt_eigenvermogen_1").val() != '' ||  $("#txt_balanstotaal_1").val() != '' ){
                $('#card_collapse_11').click();
            } 
            if($("#txt_vlottendeactiva_1").val() != '' ||  $("#txt_kortvreemdvermogen_1").val() != '' ) {
                $('#card_collapse_22').click();
            }
            $("#div_inkomensgegevens_2 :input").attr("disabled", true);
            $("#div_inkomensgegevens_3 :input").attr("disabled", true);
            $("#div_solvabiliteit_2 :input").attr("disabled", true);
            $("#div_solvabiliteit_3 :input").attr("disabled", true);
            $("#div_liquiditeit_2 :input").attr("disabled", true);
            $("#div_liquiditeit_3 :input").attr("disabled", true);
            incomedata_calculation();

        } else if (value == "2") {

            $('#h_yearselection').val(value);
             if( $("#txt_eigenvermogen_1").val() != '' ||  $("#txt_balanstotaal_1").val() != '' || $("#txt_eigenvermogen_2").val() != '' || $("#txt_balanstotaal_2").val() != '' ){
                $('#card_collapse_11').click();
            } 
            if($("#txt_vlottendeactiva_1").val() != '' ||  $("#txt_kortvreemdvermogen_1").val() != '' || $("#txt_vlottendeactiva_2").val() != '' || $("#txt_kortvreemdvermogen_2").val() != '' ) {
                $('#card_collapse_22').click();
            }
            $("#div_inkomensgegevens_2 :input").attr("disabled", false);
            $("#div_inkomensgegevens_3 :input").attr("disabled", true);
            $("#div_solvabiliteit_2 :input").attr("disabled", false);
            $("#div_solvabiliteit_3 :input").attr("disabled", true);
            $("#div_liquiditeit_2 :input").attr("disabled", false);
            $("#div_liquiditeit_3 :input").attr("disabled", true);
            incomedata_calculation();

        } else if (value == "3") {

            $('#h_yearselection').val(value);
            if( $("#txt_eigenvermogen_1").val() != '' ||  $("#txt_balanstotaal_1").val() != '' || $("#txt_eigenvermogen_2").val() != '' || $("#txt_balanstotaal_2").val() != '' || $("#txt_eigenvermogen_3").val() != '' || $("#txt_balanstotaal_3").val() != '' ){
                $('#card_collapse_11').click();
            } 
            if($("#txt_vlottendeactiva_1").val() != '' ||  $("#txt_kortvreemdvermogen_1").val() != '' || $("#txt_vlottendeactiva_2").val() != '' || $("#txt_kortvreemdvermogen_2").val() != '' || $("#txt_vlottendeactiva_3").val() != '' || $("#txt_kortvreemdvermogen_3").val() != '' ) {
                $('#card_collapse_22').click();
            }
            $("#div_inkomensgegevens_2 :input").attr("disabled", false);
            $("#div_inkomensgegevens_3 :input").attr("disabled", false);
            $("#div_solvabiliteit_2 :input").attr("disabled", false);
            $("#div_solvabiliteit_3 :input").attr("disabled", false);
            $("#div_liquiditeit_2 :input").attr("disabled", false);
            $("#div_liquiditeit_3 :input").attr("disabled", false);
            incomedata_calculation();
        }
    }     
}

if(dataId2 == 'tv1') {

    $("#group1_tv1").click();
    $("#p_notcompleted").show(); 
    $('#in1').hide(); 
    $("#div_box6").show();
    var boxNumber = parseInt($(this).parents('.desc').attr("data-box"));

    /*check if the data-box was succesfully retrieved. If not, first option chosen, reset all of it*/
    if (isNaN(boxNumber)) {
        boxNumber = 0;
    }

    var groupval = 'tv1';
    var target = $("#" + groupval);
    var newBoxOpened = target.attr("data-box");
    //check if the last opened box was an earlier one than the newly clicked one
    if (lastBoxOpened > boxNumber) {
        /*hide boxes beyond the one we opened now*/
        $('.desc').each(function () {
            /*if box number is bigger than the currently clicked box, close them.*/
            if ($(this).attr("data-box") > boxNumber) {
                $(this).hide();
                /*uncheck the previously selected radio buttons in now hidden things*/
                $('input', this).prop("checked", false);
            }
        });
    }
    /*render target box*/
    target.show();
    $('[data-toggle="popover"]').popover();
    /*update last opened box to the newly opened one*/
    lastBoxOpened = newBoxOpened;
    $("#div_box2").show();
    $("#div_box3").show();
    $("#h_typeselection").val(groupval);
    incomedata_calculation();

    if (groupval == 'tv1') {

        $("#div_holding").hide();
        $("#div_holdingtext").hide();
        $("#div_winstuitonderneming").show();
        $("#div_forhalfyear").hide();
        $("#div_inkomensgegevens_1").hide();
        $("#div_inkomensgegevens_2").hide();
        $("#div_inkomensgegevens_3").hide();
        $("#div_solvabiliteit_2 :input").attr("disabled", true);
        $("#div_solvabiliteit_3 :input").attr("disabled", true);
        $("#div_liquiditeit_2 :input").attr("disabled", true);
        $("#div_liquiditeit_3 :input").attr("disabled", true);

        var windowSize = $(window).width();
        var newwidth = 400;

        if (windowSize >= 993) {
            newwidth =  400;
        }
        if (windowSize >= 768 && windowSize <= 992 ) {
             newwidth = 370;
        }
        else if (windowSize <= 767 && windowSize >= 480 ) {
        newwidth = 350;
        }
        else if (windowSize <= 767) {
           newwidth =  $(".start-box").width() - 20;
        }
        incomedata_calculation();

        $("#single_slider_tv1").jRange({
            from: 1,
            to: 3,
            step: 1,
            scale: [1.0, 2.0, 3],
            format: "jaar",
            width: newwidth,
            showLabels: true,
            snap: true,
            onstatechange: function (value) {
                $("#h_yearselection").val(value);
                if (value == "1") {

                     
                    $(".slider-container .back-bar .pointer-label").css("margin-left","-11px"); 
                    $('#h_yearselection').val(value);
                    $("#div_winstuitonderneming_2 :input").attr("disabled", true);
                    $("#div_winstuitonderneming_3 :input").attr("disabled", true);

                    $("#div_solvabiliteit_2 :input").attr("disabled", true);
                    $("#div_solvabiliteit_3 :input").attr("disabled", true);

                    $("#div_liquiditeit_2 :input").attr("disabled", true);
                    $("#div_liquiditeit_3 :input").attr("disabled", true);
                    incomedata_calculation();
                } else if (value == "2") {
                     
                    $(".slider-container .back-bar .pointer-label").css("margin-left","0px"); 
                    $('#h_yearselection').val(value);
                    $("#div_winstuitonderneming_2 :input").attr("disabled", false);
                    $("#div_winstuitonderneming_3 :input").attr("disabled", true);

                    $("#div_solvabiliteit_2 :input").attr("disabled", false);
                    $("#div_solvabiliteit_3 :input").attr("disabled", true);

                    $("#div_liquiditeit_2 :input").attr("disabled", false);
                    $("#div_liquiditeit_3 :input").attr("disabled", true);
                    incomedata_calculation();
                } else if (value == "3") {
                     
                    $(".slider-container .back-bar .pointer-label").css("margin-left","14px"); 
                    $('#h_yearselection').val(value);
                    $("#div_winstuitonderneming_2 :input").attr("disabled", false);
                    $("#div_winstuitonderneming_3 :input").attr("disabled", false);

                    $("#div_solvabiliteit_2 :input").attr("disabled", false);
                    $("#div_solvabiliteit_3 :input").attr("disabled", false);

                    $("#div_liquiditeit_2 :input").attr("disabled", false);
                    $("#div_liquiditeit_3 :input").attr("disabled", false);
                    incomedata_calculation();
                }                
            }                
        });
        var value = $("#single_slider_tv1").val();
        if (value == "1") {
            $('#h_yearselection').val(value);
            if( $("#txt_eigenvermogen_1").val() != '' ||  $("#txt_balanstotaal_1").val() != '' ){
                $('#card_collapse_11').click();
            } 
            if($("#txt_vlottendeactiva_1").val() != '' ||  $("#txt_kortvreemdvermogen_1").val() != '' ) {
                $('#card_collapse_22').click();
            }
            $("#div_winstuitonderneming_2 :input").attr("disabled", true);
            $("#div_winstuitonderneming_3 :input").attr("disabled", true);

            $("#div_solvabiliteit_2 :input").attr("disabled", true);
            $("#div_solvabiliteit_3 :input").attr("disabled", true);

            $("#div_liquiditeit_2 :input").attr("disabled", true);
            $("#div_liquiditeit_3 :input").attr("disabled", true);
            incomedata_calculation();
        } else if (value == "2") {
            $('#h_yearselection').val(value);
            if( $("#txt_eigenvermogen_1").val() != '' ||  $("#txt_balanstotaal_1").val() != '' || $("#txt_eigenvermogen_2").val() != '' || $("#txt_balanstotaal_2").val() != '' ){
                $('#card_collapse_11').click();
            } 
            if($("#txt_vlottendeactiva_1").val() != '' ||  $("#txt_kortvreemdvermogen_1").val() != '' || $("#txt_vlottendeactiva_2").val() != '' || $("#txt_kortvreemdvermogen_2").val() != '' ) {
                $('#card_collapse_22').click();
            }
            $("#div_winstuitonderneming_2 :input").attr("disabled", false);
            $("#div_winstuitonderneming_3 :input").attr("disabled", true);

            $("#div_solvabiliteit_2 :input").attr("disabled", false);
            $("#div_solvabiliteit_3 :input").attr("disabled", true);

            $("#div_liquiditeit_2 :input").attr("disabled", false);
            $("#div_liquiditeit_3 :input").attr("disabled", true);
            incomedata_calculation();
        } else if (value == "3") {
            $('#h_yearselection').val(value);
            if( $("#txt_eigenvermogen_1").val() != '' ||  $("#txt_balanstotaal_1").val() != '' || $("#txt_eigenvermogen_2").val() != '' || $("#txt_balanstotaal_2").val() != '' || $("#txt_eigenvermogen_3").val() != '' || $("#txt_balanstotaal_3").val() != '' ){
                $('#card_collapse_11').click();
            } 
            if($("#txt_vlottendeactiva_1").val() != '' ||  $("#txt_kortvreemdvermogen_1").val() != '' || $("#txt_vlottendeactiva_2").val() != '' || $("#txt_kortvreemdvermogen_2").val() != '' || $("#txt_vlottendeactiva_3").val() != '' || $("#txt_kortvreemdvermogen_3").val() != '' ) {
                $('#card_collapse_22').click();
            }
            $("#div_winstuitonderneming_2 :input").attr("disabled", false);
            $("#div_winstuitonderneming_3 :input").attr("disabled", false);

            $("#div_solvabiliteit_2 :input").attr("disabled", false);
            $("#div_solvabiliteit_3 :input").attr("disabled", false);

            $("#div_liquiditeit_2 :input").attr("disabled", false);
            $("#div_liquiditeit_3 :input").attr("disabled", false);
            incomedata_calculation();
        }
    }
}    
   
/*********************************************************** 
         ******************   on click event for 1st click *******************
                                ************************************************************/
var lastBoxOpened = 0;
   
/*based on selected type, related calculation forms showing*/
$("input[name$='group1']").click(function () {

    $("#p_notcompleted").html(ffc.notice);        
    $("#p_notcompleted").show();
    $('#in1').hide();
    $('#ph1').hide();
    $('#tv1').hide();
    $('#div_box6').show();
    $("#div_box111").show();
    var boxNumber = parseInt($(this).parents('.desc').attr("data-box"));

   /* check if the data-box was succesfully retrieved. If not, first option chosen, reset all of it*/
    if (isNaN(boxNumber)) {
        boxNumber = 0;
    }

    var groupval = $(this).val();
    var target = $("#" + groupval);
    var newBoxOpened = target.attr("data-box");
    /*check if the last opened box was an earlier one than the newly clicked one*/
    if (lastBoxOpened > boxNumber) {
        /*hide boxes beyond the one we opened now*/
        $('.desc').each(function () {
            /*if box number is bigger than the currently clicked box, close them.*/
            if ($(this).attr("data-box") > boxNumber) {
                $(this).hide();
                /*uncheck the previously selected radio buttons in now hidden things*/
                $('input', this).prop("checked", false);
            }
        });
    }

    incomedata_calculation();

    /*render target box*/
    target.show();
    $('[data-toggle="popover"]').popover();
    /*update last opened box to the newly opened one*/
    lastBoxOpened = newBoxOpened;
    $("#div_box2").show();
    $("#div_box3").show();
    //$("#div_box5").hide();
    $("#h_typeselection").val(groupval);
   
    if (groupval == 'ph1') {            
        
        $("#ph1").show();            
        /* hide in1 slider */
        $(".sec-sep2").hide();
        $("#div_holding1").hide();
        $(".sec-sep3").hide();          
        $("#div_holdingtext1").hide();  
        /* show ph1 slider*/
        $(".sec-sep6").show();
        $("#div_holding").show();
        $("#div_holdingtext").show();       
        $('.sec-sep7').hide();
        $('#myonoffswitch3').prop("checked", true);

        $('input[name="onoffswitch3"]').click(function(){

            if($(this).prop("checked") == true){
                $('input[name="onoffswitch3"]').val("0");
                $('.sec-sep7').hide();
            } else {
                $('input[name="onoffswitch3"]').val("1");
                $('.sec-sep7').show(); 
            }
        });

    } else {
        $(".sec-sep6").hide();
        $(".sec-sep7").hide();
    }
    if (groupval == 'in1') {  
        $("#myonoffswitch1").prop("checked", true);
        $("#h_yearselection").val('0');   
        $("#div_forhalfyear").show();
        $("#div_winstuitonderneming").hide(); 
        if($("#h_yearselection").val() == '0') {
            $(".sec-sep2").show();
        }  
        $(".sec-sep8").show();
        $("#div_holding1").show();
        $("#h_yearselection").val('0');       
        $('#div_holdingtext1').hide();
        $(".sec-sep3").hide();
       
        /*remove disable inputs*/
        $("#txt_halfyear_first").attr("disabled", false);
        $("#txt_halfyear_second").attr("disabled", false);
        $("#txt_halfyear_third").attr("disabled", false);

        $('input[name="onoffswitch1"]').click(function(){

            if($(this).prop("checked") == true){
                $('input[name="onoffswitch1"]').val('0');
                $('#div_holdingtext1').hide();
                $(".sec-sep3").hide();

                 /*remove disable inputs*/
                $("#txt_halfyear_first").attr("disabled", false);
                $("#txt_halfyear_second").attr("disabled", false);
                $("#txt_halfyear_third").attr("disabled", false);

            } else {
                $('input[name="onoffswitch1"]').val('1');
                $('#div_holdingtext1').show();
                $(".sec-sep3").show();
               
                /*disable inputs*/
                $("#txt_halfyear_first").attr("disabled", true);
                $("#txt_halfyear_second").attr("disabled", true);
                $("#txt_halfyear_third").attr("disabled", true);
            }
        });       

        $("#div_inkomensgegevens_1").hide();
        $("#div_inkomensgegevens_2").hide();
        $("#div_inkomensgegevens_3").hide();
        $("#div_solvabiliteit_2 :input").attr("disabled", true);
        $("#div_solvabiliteit_3 :input").attr("disabled", true);
        $("#div_liquiditeit_2 :input").attr("disabled", true);
        $("#div_liquiditeit_3 :input").attr("disabled", true);
        var windowSize = $(window).width();
        var newwidth = 400;

        if (windowSize >= 993) {
            newwidth =  400; 

        }
        if (windowSize >= 768 && windowSize <= 992 ) {
            newwidth = 370;
        } else if (windowSize <= 767 && windowSize >= 480 ) {
            newwidth = 350;
        }
        else if (windowSize <= 767) {
           newwidth =  $(".start-box").width() - 20;
        }
     
    $("#single_slider_first").jRange({
        from: 0,
        to: 3,
        step: 1,
        scale: [0.5, 1.0, 2.0, 3],
        format: "jaar",
        width: newwidth,
        showLabels: true,
        snap: true,
        onstatechange: function (value) {

            $("#h_yearselection").val(value);

            if (value == "0") {                     
                
                $(".slider-container .back-bar .pointer-label").css("margin-left","-11px"); 
                $(".sec-sep2").show(); 
                $("#div_holding1").show();
                if($('input[name="onoffswitch1"]').val() == '1') {
                    $('#div_holdingtext1').show();
                    $(".sec-sep3").show();
                } else if ($('input[name="onoffswitch1"]').val() == '0'){
                    $('#div_holdingtext1').hide();
                    $(".sec-sep3").hide();
                } else {
                    $('#div_holdingtext1').show();
                    $(".sec-sep3").show();
                    $('input[name="onoffswitch1"]').click(function(){

                        if($(this).prop("checked") == true){
                            $('input[name="onoffswitch1"]').val("0");
                            $('#div_holdingtext1').hide();
                            $(".sec-sep3").hide();
                        } else {
                            $('input[name="onoffswitch1"]').val("1");
                            $('#div_holdingtext1').show();
                            $(".sec-sep3").show();
                        }
                    });
                } 
                $("#div_forhalfyear").show();
                $("#div_winstuitonderneming").hide();

            } else {

                $("#div_forhalfyear").hide();
                $("#div_winstuitonderneming").show();
                $("#div_holding1").hide();
                $(".sec-sep3").hide();
                $(".sec-sep2").hide();
                $("#div_holdingtext1").hide();
            }

            if (value == "1") {
                
                $(".slider-container .back-bar .pointer-label").css("margin-left","0px"); 
                $(".sec-sep2").hide();
                $("#div_holding1").hide();
                $(".sec-sep3").hide();
                $("#div_holdingtext1").hide();
                $("#div_winstuitonderneming_2 :input").attr("disabled", true);
                $("#div_winstuitonderneming_3 :input").attr("disabled", true);
                $("#div_solvabiliteit_2 :input").attr("disabled", true);
                $("#div_solvabiliteit_3 :input").attr("disabled", true);
                $("#div_liquiditeit_2 :input").attr("disabled", true);
                $("#div_liquiditeit_3 :input").attr("disabled", true);

            } else if (value == "2") {
                
                $(".slider-container .back-bar .pointer-label").css("margin-left","0px"); 
                $(".sec-sep2").hide();
                $("#div_holding1").hide();
                $(".sec-sep3").hide();
                $("#div_holdingtext1").hide();
                $("#div_winstuitonderneming_2 :input").attr("disabled", false);
                $("#div_winstuitonderneming_3 :input").attr("disabled", true);
                $("#div_solvabiliteit_2 :input").attr("disabled", false);
                $("#div_solvabiliteit_3 :input").attr("disabled", true);
                $("#div_liquiditeit_2 :input").attr("disabled", false);
                $("#div_liquiditeit_3 :input").attr("disabled", true);

            } else if (value == "3") {                
                
                $(".slider-container .back-bar .pointer-label").css("margin-left","13px"); 
                $(".sec-sep2").hide();
                $("#div_holding1").hide();
                $(".sec-sep3").hide();
                $("#div_holdingtext1").hide();
                $("#div_winstuitonderneming_2 :input").attr("disabled", false);
                $("#div_winstuitonderneming_3 :input").attr("disabled", false);
                $("#div_solvabiliteit_2 :input").attr("disabled", false);
                $("#div_solvabiliteit_3 :input").attr("disabled", false);
                $("#div_liquiditeit_2 :input").attr("disabled", false);
                $("#div_liquiditeit_3 :input").attr("disabled", false);

            }
            incomedata_calculation();
        }
    });

    $('#single_slider_first').jRange('updateRange', '0.5,3', '0');

} else if (groupval == 'tv1') {
    $("#div_winstuitonderneming").show();
    $("#div_forhalfyear").hide();
    $("#div_inkomensgegevens_1").hide();
    $("#div_inkomensgegevens_2").hide();
    $("#div_inkomensgegevens_3").hide();

    $("#div_solvabiliteit_2 :input").attr("disabled", true);
    $("#div_solvabiliteit_3 :input").attr("disabled", true);

    $("#div_liquiditeit_2 :input").attr("disabled", true);
    $("#div_liquiditeit_3 :input").attr("disabled", true);
    var windowSize = $(window).width();
    var newwidth = 400;

    if (windowSize >= 993) {
        newwidth =  400;

    }
    if (windowSize >= 768 && windowSize <= 992 ) {
         newwidth = 370;
    }
     else if (windowSize <= 767 && windowSize >= 480 ) {
        newwidth = 350;
        }
    else if (windowSize <= 767) {
       newwidth =  $(".start-box").width() - 20;
    }
                  
    $("#single_slider_tv1").jRange({

        from: 1,
        to: 3,
        step: 1,
        scale: [1.0, 2.0, 3],
        format: "jaar",
        width: newwidth,
        showLabels: true,
        snap: true,
        onstatechange: function (value) {

            $("#h_yearselection").val(value);

            if (value == "1") {
                 
                $(".slider-container .back-bar .pointer-label").css("margin-left","-11px"); 
                $("#div_winstuitonderneming_2 :input").attr("disabled", true);
                $("#div_winstuitonderneming_3 :input").attr("disabled", true);
                $("#div_solvabiliteit_2 :input").attr("disabled", true);
                $("#div_solvabiliteit_3 :input").attr("disabled", true);
                $("#div_liquiditeit_2 :input").attr("disabled", true);
                $("#div_liquiditeit_3 :input").attr("disabled", true);

            } else if (value == "2") {
                 
                $(".slider-container .back-bar .pointer-label").css("margin-left","0px"); 
                $("#div_winstuitonderneming_2 :input").attr("disabled", false);
                $("#div_winstuitonderneming_3 :input").attr("disabled", true);
                $("#div_solvabiliteit_2 :input").attr("disabled", false);
                $("#div_solvabiliteit_3 :input").attr("disabled", true);
                $("#div_liquiditeit_2 :input").attr("disabled", false);
                $("#div_liquiditeit_3 :input").attr("disabled", true);

            } else if (value == "3") {
                 
                $(".slider-container .back-bar .pointer-label").css("margin-left","14px"); 
                $("#div_winstuitonderneming_2 :input").attr("disabled", false);
                $("#div_winstuitonderneming_3 :input").attr("disabled", false);
                $("#div_solvabiliteit_2 :input").attr("disabled", false);
                $("#div_solvabiliteit_3 :input").attr("disabled", false);
                $("#div_liquiditeit_2 :input").attr("disabled", false);
                $("#div_liquiditeit_3 :input").attr("disabled", false);
            }
            incomedata_calculation();
        }
    });

    $('#single_slider_tv1').jRange('updateRange', '1,3', '1');

    } else {

        $("#div_forhalfyear").hide();
        $("#div_winstuitonderneming").hide();
        $("#div_inkomensgegevens_1").show();
        $("#div_inkomensgegevens_2").show();
        $("#div_inkomensgegevens_3").show();
        var windowSize = $(window).width();
        var newwidth = 400;

        if (windowSize >= 993) {
            newwidth =  400;
        }
        if (windowSize >= 768 && windowSize <= 992 ) {
             newwidth = 370;
        }
         else if (windowSize <= 767 && windowSize >= 480 ) {
        newwidth = 350;
        }
        else if (windowSize <= 767) {
            newwidth =  $(".start-box").width() - 20;
        }
        
        $("#single_slider_ph1").jRange({
            from: 1,
            to: 3,
            step: 1,
            scale: [1.0, 2.0, 3],
            format: "jaar",
            width: newwidth,
            showLabels: true,
            snap: true,
            onstatechange: function (value) {

                $("#h_yearselection").val(value);

                if (value == "1") {
                     
                    $(".slider-container .back-bar .pointer-label").css("margin-left","-11px"); 
                    $("#div_inkomensgegevens_2 :input").attr("disabled", true);
                    $("#div_inkomensgegevens_3 :input").attr("disabled", true);
                    $("#div_solvabiliteit_2 :input").attr("disabled", true);
                    $("#div_solvabiliteit_3 :input").attr("disabled", true);
                    $("#div_liquiditeit_2 :input").attr("disabled", true);
                    $("#div_liquiditeit_3 :input").attr("disabled", true);

                } else if (value == "2") {
                     
                    $(".slider-container .back-bar .pointer-label").css("margin-left","0px"); 
                    $("#div_inkomensgegevens_2 :input").attr("disabled", false);
                    $("#div_inkomensgegevens_3 :input").attr("disabled", true);
                    $("#div_solvabiliteit_2 :input").attr("disabled", false);
                    $("#div_solvabiliteit_3 :input").attr("disabled", true);
                    $("#div_liquiditeit_2 :input").attr("disabled", false);
                    $("#div_liquiditeit_3 :input").attr("disabled", true);

                } else if (value == "3") {
                     
                    $(".slider-container .back-bar .pointer-label").css("margin-left","14px"); 
                    $("#div_inkomensgegevens_2 :input").attr("disabled", false);
                    $("#div_inkomensgegevens_3 :input").attr("disabled", false);
                    $("#div_solvabiliteit_2 :input").attr("disabled", false);
                    $("#div_solvabiliteit_3 :input").attr("disabled", false);
                    $("#div_liquiditeit_2 :input").attr("disabled", false);
                    $("#div_liquiditeit_3 :input").attr("disabled", false);

                }

                incomedata_calculation();
            }
        }); 

        $('#single_slider_ph1').jRange('updateRange', '1,3', '1');
    }
});    

$("input.numbers").keypress(function (e) {
    if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
        return false;
    } else {
        return true;
    }
});
    
$('body').on('click', function (e) {
    $('[data-toggle=popover]').each(function () {
        /* hide any open popovers when the anywhere else in the body is clicked*/
        if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
            $(this).popover('hide');
        }
    });
});
});

/* ---------------------------------------------------------  partner selection starts ---------------------------- */

 jQuery(document).ready(function($){
    
    $("input[name$='rdo_partnertype']").click(function () {
        var partnertypeval = $(this).val();

        $("#h_partnertypeselection").val(partnertypeval);

        /* show sol and liq error in message box*/
        calculate_solvabiliteitp();
        calculate_liquiditeitp();        
        
        $(".sec-sep13").show();
        $("#div_box4_1").show();
        if (partnertypeval == '1') {
            $("#div_loondienst").show();
            $("#accordion1").hide();
            $(".sec-sep16").hide();
            $(".sec-sep13").hide();
            $("#div_box4_1").hide();           
            $(".psec-sep2").hide();
            $(".psec-sep3").hide();  
             $("#div_winstuitondernemingp").hide();          
            $("#div_forhalfyearp").hide();
        } else {
           $("#div_loondienst").hide();
           $("#accordion1").show();
           $(".sec-sep16").show();
            $(".sec-sep13").show();
            $("#div_box4_1").show();
            $("#div_forhalfyearp").show();
        }
        if (partnertypeval == '4') {

            $("#div_inkomensgegevensp_1").show();
            $("#div_inkomensgegevensp_2").show();
            $("#div_inkomensgegevensp_3").show();

            /* in1 toggle hide */
            $(".psec-sep2").hide();
            $(".psec-sep3").hide();
            $('.psec-sep7').hide();
            /*ph1 toggle show code */
            $('.psec-sep6').show(); 
            
            $('input[name="ponoffswitch3"]').click(function(){
                if($(this).prop("checked") == true){
                    $('input[name="ponoffswitch3"]').val("0");
                    $('.psec-sep7').hide(); 
                    /*remove disable inputs*/
                $("#txt_halfyearp_first").attr("disabled", false);
                $("#txt_halfyearp_second").attr("disabled", false);
                $("#txt_halfyearp_third").attr("disabled", false);               
                } else {
                    $('input[name="ponoffswitch3"]').val("1");
                    $('.psec-sep7').show();        
                    /*disable inputs*/
                    $("#txt_halfyearp_first").attr("disabled", true);
                    $("#txt_halfyearp_second").attr("disabled", true);
                    $("#txt_halfyearp_third").attr("disabled", true);           
                }
            });

        } else {
            $("#div_inkomensgegevensp_1").hide();
            $("#div_inkomensgegevensp_2").hide();
            $("#div_inkomensgegevensp_3").hide();
            /*ph1 toggle hide*/
            $('.psec-sep6').hide();
            $('.psec-sep7').hide();
        }

        $("#div_box5").show();
        if (partnertypeval == '2') {
            $("#div_rangeslider").html('<input id="single_slider_2" type="hidden" value="0"/><div class="gray-line1"></div><div class="gray-line2"></div><div class="gray-line3"></div><div class="gray-line4"></div>');
            $("#div_rangeslider").addClass('demo-output2 ptype2');
            $("#h_partneryearselection").val('0');
            //$(".psec-sep2").show();

            /* in1 partner toggl show */
            if($("#h_partneryearselection").val() == '0'){
                $(".psec-sep2").show();
            }
            
            $("#pdiv_holding1").show();
            $("#div_winstuitondernemingp").hide();
                            
            $(".psec-sep3").hide();
            /*remove disable inputs*/
            $("#txt_halfyearp_first").attr("disabled", false);
            $("#txt_halfyearp_second").attr("disabled", false);
            $("#txt_halfyearp_third").attr("disabled", false);

            $('input[name="ponoffswitch1"]').click(function(){
                if($(this).prop("checked") == true){
                    $('input[name="ponoffswitch1"]').val("0");                   
                    $(".psec-sep3").hide();
                    /*remove disable inputs*/
                    $("#txt_halfyearp_first").attr("disabled", false);
                    $("#txt_halfyearp_second").attr("disabled", false);
                    $("#txt_halfyearp_third").attr("disabled", false);
                } else {
                    $('input[name="ponoffswitch1"]').val("1");                   
                    $(".psec-sep3").show();
                    /*disable inputs*/
                    $("#txt_halfyearp_first").attr("disabled", true);
                    $("#txt_halfyearp_second").attr("disabled", true);
                    $("#txt_halfyearp_third").attr("disabled", true);
                }
            }); 
          
        } else {
            $("#div_rangeslider").html('<input id="single_slider_2" type="hidden" value="0"/><div class="gray-line1"></div><div class="gray-line2"></div><div class="gray-line3"></div>');
            $("#div_rangeslider").removeClass('demo-output2');
           
            $(".psec-sep2").hide();
            $(".psec-sep3").hide();
            
        }
        load_year_range_partner();
        if (partnertypeval == '2') {
            $('#single_slider_2').jRange('updateRange', '0.5,3', '0');
        } else {
            $('#single_slider_2').jRange('setValue', '1');
        }

    });
});

function load_year_range_partner() {
    var typeselection = jQuery("#h_partnertypeselection").val();
     if (typeselection == '2') {
        var range_from = 0;
        var range_scale = [0.5, 1, 2, 3];
    } else {
        var range_from = 1;
        var range_scale = [1, 2, 3];
    }

    var windowSize = jQuery(window).width();
            var newwidth = 400;

            if (windowSize >= 993) {
                newwidth =  400;

            }
            if (windowSize >= 768 && windowSize <= 992 ) {
                 newwidth = 370;
            }
             else if (windowSize <= 767 && windowSize >= 480 ) {
                newwidth = 350;
            }
            else if (windowSize <= 767) {
                newwidth =  jQuery(".start-box").width() - 20;
            }

    if (windowSize <= 767) {
        jQuery("#single_slider_2").jRange({
            from: range_from,
            to: 3,
            step: 1,
            scale: range_scale,
            format: "jaar",
            width: newwidth,
            showLabels: true,
            snap: true,
            onstatechange: function (value) {
                
                jQuery("#div_winstuitondernemingp").hide();            

                if (typeselection != '1') {
                    jQuery("#h_partneryearselection").val(value);

                    if (value == '0') {
                         
                        jQuery(".slider-container .back-bar .pointer-label").css("margin-left","-11px"); 
                        jQuery("#div_forhalfyearp").show();

                        /* 0.5 freelancer show hide*/
                        jQuery(".psec-sep2").show();
                        jQuery("#pdiv_holding1").show();
                        jQuery(".psec-sep3").show();
                        jQuery("#pdiv_holdingtext1").show();

                    } else if (value == "1") {
                        
                        if(jQuery('#h_partnertypeselection').val() == '2'){
                            jQuery(".slider-container .back-bar .pointer-label").css("margin-left","0px");
                        } else{
                            jQuery(".slider-container .back-bar .pointer-label").css("margin-left","-11px");
                        }
                         
                        jQuery("#div_forhalfyearp").hide();

                        jQuery(".psec-sep2").hide();
                        jQuery("#pdiv_holding1").hide();
                        jQuery(".psec-sep3").hide();
                        jQuery("#pdiv_holdingtext1").hide();

                        if (typeselection == '4') {
                            
                             
                            jQuery("#div_inkomensgegevensp_2 :input").attr("disabled", true);
                            jQuery("#div_inkomensgegevensp_3 :input").attr("disabled", true);
                        } else {
                           
                            jQuery("#div_winstuitondernemingp").show();
                            jQuery("#div_winstuitondernemingp_2 :input").attr("disabled", true);
                            jQuery("#div_winstuitondernemingp_3 :input").attr("disabled", true);
                        }

                        jQuery("#div_solvabiliteitp_2 :input").attr("disabled", true);
                        jQuery("#div_solvabiliteitp_3 :input").attr("disabled", true);
                        jQuery("#div_liquiditeitp_2 :input").attr("disabled", true);
                        jQuery("#div_liquiditeitp_3 :input").attr("disabled", true);
                    } else if (value == "2") {
                         
                        jQuery(".slider-container .back-bar .pointer-label").css("margin-left","0px"); 
                        jQuery("#div_forhalfyearp").hide();
                        jQuery(".psec-sep2").hide();
                        jQuery("#pdiv_holding1").hide();
                        jQuery(".psec-sep3").hide();
                        jQuery("#pdiv_holdingtext1").hide();

                        if (typeselection == '4') {
                            jQuery("#div_inkomensgegevensp_2 :input").attr("disabled", false);
                            jQuery("#div_inkomensgegevensp_3 :input").attr("disabled", true);
                        } else {
                            jQuery("#div_winstuitondernemingp").show();
                            jQuery("#div_winstuitondernemingp_2 :input").attr("disabled", false);
                            jQuery("#div_winstuitondernemingp_3 :input").attr("disabled", true);
                        }

                        jQuery("#div_solvabiliteitp_2 :input").attr("disabled", false);
                        jQuery("#div_solvabiliteitp_3 :input").attr("disabled", true);
                        jQuery("#div_liquiditeitp_2 :input").attr("disabled", false);
                        jQuery("#div_liquiditeitp_3 :input").attr("disabled", true);

                    } else if (value == "3") {

                         
                        jQuery(".slider-container .back-bar .pointer-label").css("margin-left","14px"); 
                        jQuery("#div_forhalfyearp").hide();
                        jQuery(".psec-sep2").hide();
                        jQuery("#pdiv_holding1").hide();
                        jQuery(".psec-sep3").hide();
                        jQuery("#pdiv_holdingtext1").hide();

                        if (typeselection == '4') {
                             
                            jQuery(".slider-container .back-bar .pointer-label").css("margin-left","14px"); 
                            jQuery("#div_inkomensgegevensp_2 :input").attr("disabled", false);
                            jQuery("#div_inkomensgegevensp_3 :input").attr("disabled", false);
                        } else {
                            
                            jQuery("#div_winstuitondernemingp").show();
                            jQuery("#div_winstuitondernemingp_2 :input").attr("disabled", false);
                            jQuery("#div_winstuitondernemingp_3 :input").attr("disabled", false);
                        }
                       
                        jQuery("#div_solvabiliteitp_2 :input").attr("disabled", false);
                        jQuery("#div_solvabiliteitp_3 :input").attr("disabled", false);
                        jQuery("#div_liquiditeitp_2 :input").attr("disabled", false);
                        jQuery("#div_liquiditeitp_3 :input").attr("disabled", false);
                    }
                } else {
                     
                    jQuery("#div_solvabiliteitp_2 :input").attr("disabled", true);
                    jQuery("#div_solvabiliteitp_3 :input").attr("disabled", true);
                    jQuery("#div_liquiditeitp_2 :input").attr("disabled", true);
                    jQuery("#div_liquiditeitp_3 :input").attr("disabled", true);
                }
            }
        });
    }
    
    var windowSize = jQuery(window).width();
            var newwidth = 400;

            if (windowSize >= 993) {
                newwidth =  400;

            }
            if (windowSize >= 768 && windowSize <= 992 ) {
                 newwidth = 370;
            }
             else if (windowSize <= 767 && windowSize >= 480 ) {
                newwidth = 350;
            }
            else if (windowSize <= 767) {
                newwidth =  jQuery(".start-box").width() - 20;
            }
    jQuery("#single_slider_2").jRange({
        from: range_from,
        to: 3,
        step: 1,
        scale: range_scale,
        format: "jaar",
        width: newwidth,
        showLabels: true,
        snap: true,
        onstatechange: function (value) {
            
            jQuery("#div_winstuitondernemingp").hide();

            if (typeselection != '1') {
                jQuery("#h_partneryearselection").val(value);

                if (value == '0') {
                     
                    jQuery(".slider-container .back-bar .pointer-label").css("margin-left","-11px"); 
                    jQuery("#div_forhalfyearp").show();
                    /* 0.5 freelancer show hide*/
                    jQuery(".psec-sep2").show();
                    jQuery("#pdiv_holding1").show();                  
                    jQuery("#pdiv_holdingtext1").show();

                } else if (value == "1") {
                     
                    if(jQuery('#h_partnertypeselection').val() == '2'){
                            jQuery(".slider-container .back-bar .pointer-label").css("margin-left","0px");
                    } else{
                        jQuery(".slider-container .back-bar .pointer-label").css("margin-left","-11px");
                    }
                    jQuery("#div_forhalfyearp").hide();
                    jQuery(".psec-sep2").hide();
                    jQuery("#pdiv_holding1").hide();
                    jQuery(".psec-sep3").hide();
                    jQuery("#pdiv_holdingtext1").hide();

                    if (typeselection == '4') {
                        jQuery("#div_inkomensgegevensp_2 :input").attr("disabled", true);
                        jQuery("#div_inkomensgegevensp_3 :input").attr("disabled", true);

                      
                    } else {
                       
                        jQuery("#div_winstuitondernemingp").show();
                        jQuery("#div_winstuitondernemingp_2 :input").attr("disabled", true);
                        jQuery("#div_winstuitondernemingp_3 :input").attr("disabled", true);
                    }

                    jQuery("#div_solvabiliteitp_2 :input").attr("disabled", true);
                    jQuery("#div_solvabiliteitp_3 :input").attr("disabled", true);

                    jQuery("#div_liquiditeitp_2 :input").attr("disabled", true);
                    jQuery("#div_liquiditeitp_3 :input").attr("disabled", true);
                } else if (value == "2") {
                     
                    jQuery(".slider-container .back-bar .pointer-label").css("margin-left","0px"); 
                    jQuery("#div_forhalfyearp").hide();
                    jQuery(".psec-sep2").hide();
                    jQuery("#pdiv_holding1").hide();
                    jQuery(".psec-sep3").hide();
                    jQuery("#pdiv_holdingtext1").hide();

                    if (typeselection == '4') {
                        jQuery("#div_inkomensgegevensp_2 :input").attr("disabled", false);
                        jQuery("#div_inkomensgegevensp_3 :input").attr("disabled", true);
                     
                    } else {
                        
                        jQuery("#div_winstuitondernemingp").show();
                        jQuery("#div_winstuitondernemingp_2 :input").attr("disabled", false);
                        jQuery("#div_winstuitondernemingp_3 :input").attr("disabled", true);
                    }

                    jQuery("#div_solvabiliteitp_2 :input").attr("disabled", false);
                    jQuery("#div_solvabiliteitp_3 :input").attr("disabled", true);

                    jQuery("#div_liquiditeitp_2 :input").attr("disabled", false);
                    jQuery("#div_liquiditeitp_3 :input").attr("disabled", true);
                } else if (value == "3") {
                     
                    jQuery(".slider-container .back-bar .pointer-label").css("margin-left","14px"); 
                    jQuery("#div_forhalfyearp").hide();
                    jQuery(".psec-sep2").hide();
                    jQuery("#pdiv_holding1").hide();
                    jQuery(".psec-sep3").hide();
                    jQuery("#pdiv_holdingtext1").hide();

                    if (typeselection == '4') {
                        jQuery(".slider-container .back-bar .pointer-label").css("margin-left","14px"); 
                        jQuery("#div_inkomensgegevensp_2 :input").attr("disabled", false);
                        jQuery("#div_inkomensgegevensp_3 :input").attr("disabled", false);
                       
                    } else {
                    
                        jQuery('.sec-sep3').hide();
                        jQuery("#div_winstuitondernemingp").show();
                        jQuery("#div_winstuitondernemingp_2 :input").attr("disabled", false);
                        jQuery("#div_winstuitondernemingp_3 :input").attr("disabled", false);
                    }

                    jQuery("#div_solvabiliteitp_2 :input").attr("disabled", false);
                    jQuery("#div_solvabiliteitp_3 :input").attr("disabled", false);

                    jQuery("#div_liquiditeitp_2 :input").attr("disabled", false);
                    jQuery("#div_liquiditeitp_3 :input").attr("disabled", false);
                }
            } else {
               
            jQuery('.sec-sep3').hide();
                jQuery("#div_solvabiliteitp_2 :input").attr("disabled", true);
                    jQuery("#div_solvabiliteitp_3 :input").attr("disabled", true);

                    jQuery("#div_liquiditeitp_2 :input").attr("disabled", true);
                    jQuery("#div_liquiditeitp_3 :input").attr("disabled", true);
            }
        }
    });
}

/***********************************
                ************************* partner selectuion end *********************
                *************************      start functions   *********************
                                                                *************************************/
/* solvensiability calculation, if not print otice */
function calculate_solvabiliteit() {

    var yearselection = jQuery("#h_yearselection").val();

    if (yearselection == '0' || yearselection == '1') {

        var eigenvermogen_1 = jQuery("#txt_eigenvermogen_1").val(); 
        var balanstotaal_1 = jQuery("#txt_balanstotaal_1").val();
        if (eigenvermogen_1 != '' && balanstotaal_1 != '') {
            var percent = (eigenvermogen_1 / balanstotaal_1) * 100;
            percent = percent.toFixed(2);
            jQuery("#h_solvabiliteit").val(percent);
        } else{
            jQuery("#h_solvabiliteit").val('');
        }

    } else if (yearselection == '2') {
        
        var eigenvermogen_2 = jQuery("#txt_eigenvermogen_2").val();        
        var balanstotaal_2 = jQuery("#txt_balanstotaal_2").val();
        var eigenvermogen_1 = jQuery("#txt_eigenvermogen_1").val();
        var balanstotaal_1 = jQuery("#txt_balanstotaal_1").val();

        if (eigenvermogen_1 != '' && balanstotaal_1 != '') {
            var percent1 = (eigenvermogen_1 / balanstotaal_1) * 100;
            percent1 = percent1.toFixed(2);
        }
        if (eigenvermogen_2 != '' && balanstotaal_2 != '') {            
            var percent2 = (eigenvermogen_2 / balanstotaal_2) * 100;
            percent2 = percent2.toFixed(2);   

            if(percent1 != ''){
                percent2 = percent2 > percent1 ? percent2 : percent1;
            }       
        }               
        jQuery("#h_solvabiliteit").val(percent2);

    } else if (yearselection == '3') {
        
        var eigenvermogen_3 = jQuery("#txt_eigenvermogen_3").val();        
        var balanstotaal_3 = jQuery("#txt_balanstotaal_3").val();
        var eigenvermogen_2 = jQuery("#txt_eigenvermogen_2").val();        
        var balanstotaal_2 = jQuery("#txt_balanstotaal_2").val();

        if (eigenvermogen_2 != '' && balanstotaal_2 != '') {            
            var percent2 = (eigenvermogen_2 / balanstotaal_2) * 100;
            percent2 = percent2.toFixed(2);            
        }
        if (eigenvermogen_3 != '' && balanstotaal_3 != '') {            
            var percent3 = (eigenvermogen_3 / balanstotaal_3) * 100;
            percent3 = percent3.toFixed(2);

            if(percent2 != ''){
                percent3 = percent3 > percent2 ? percent3 : percent2;
            }
            jQuery("#h_solvabiliteit").val(percent3);
        } else{
            jQuery("#h_solvabiliteit").val('');
        }
    }

    var data = {
    action: 'ffc_final_result',
    is_ajax: 1
    };
    jQuery.post(ffc.ajaxurl, data, function (response) {
        /* Do Response Process */
        data = jQuery.parseJSON(response); 

        var h_solvabiliteit = jQuery("#h_solvabiliteit").val();              
        var h_liquiditeit = jQuery("#h_liquiditeit").val();  

        if(h_solvabiliteit == "" & h_liquiditeit == "") {
            jQuery('#p_notcompleted').html(data.sol_liq_wrong_notice);
        } else if((h_solvabiliteit == "" || h_solvabiliteit < 0) && h_liquiditeit >= 0){            
            jQuery('#p_notcompleted').html(data.sol_wrong_notice);
        }  else if((h_liquiditeit == "" || h_liquiditeit < 0) && h_solvabiliteit >= 0) {             
            jQuery('#p_notcompleted').html(data.liq_wrong_notice);
        }  else if(h_solvabiliteit != "" && h_liquiditeit != ""){
            jQuery('#p_notcompleted').html(data.accurate_calculation);
        }                
    });    
}

function calculate_liquiditeit() {

    var yearselection = jQuery("#h_yearselection").val();

    if (yearselection == '0' || yearselection == '1') {

        var vlottendeactiva_1 = jQuery("#txt_vlottendeactiva_1").val();
        var kortvreemdvermogen_1 = jQuery("#txt_kortvreemdvermogen_1").val();

        if (vlottendeactiva_1 != '' && kortvreemdvermogen_1 != '') {
            var percent = vlottendeactiva_1 / kortvreemdvermogen_1;
            percent = percent.toFixed(2);
            jQuery("#h_liquiditeit").val(percent);
        } else { jQuery("#h_liquiditeit").val(''); }

    } else if (yearselection == '2') {

        var vlottendeactiva_2 = jQuery("#txt_vlottendeactiva_2").val();
        var kortvreemdvermogen_2 = jQuery("#txt_kortvreemdvermogen_2").val();
        var vlottendeactiva_1 = jQuery("#txt_vlottendeactiva_1").val();
        var kortvreemdvermogen_1 = jQuery("#txt_kortvreemdvermogen_1").val();

        if (vlottendeactiva_1 != '' && kortvreemdvermogen_1 != '') {
            var percent1 = vlottendeactiva_1 / kortvreemdvermogen_1;
            percent1 = percent1.toFixed(2);
        }
        if (vlottendeactiva_2 != '' && kortvreemdvermogen_2 != '') {
            var percent2 = vlottendeactiva_2 / kortvreemdvermogen_2;
            percent2 = percent2.toFixed(2);

            if(percent1 != ''){
                percent2 = percent1 > percent2 ? percent1 : percent2;
            }
            jQuery("#h_liquiditeit").val(percent2);
        } else { jQuery("#h_liquiditeit").val(''); }

    } else if (yearselection == '3') {

        var vlottendeactiva_3 = jQuery("#txt_vlottendeactiva_3").val();
        var kortvreemdvermogen_3 = jQuery("#txt_kortvreemdvermogen_3").val();
        var vlottendeactiva_2 = jQuery("#txt_vlottendeactiva_2").val();
        var kortvreemdvermogen_2 = jQuery("#txt_kortvreemdvermogen_2").val();
         if (vlottendeactiva_2 != '' && kortvreemdvermogen_2 != '') {
            var percent2 = vlottendeactiva_2 / kortvreemdvermogen_2;
            percent2 = percent2.toFixed(2);
        }
        if (vlottendeactiva_3 != '' && kortvreemdvermogen_3 != '') {
            var percent3 = vlottendeactiva_3 / kortvreemdvermogen_3;
            percent3 = percent3.toFixed(2);
            if(percent2 != ''){
                percent3 = percent3 > percent2 ? percent3 : percent2;
            }
            jQuery("#h_liquiditeit").val(percent3);
        } else { jQuery("#h_liquiditeit").val(''); }
    }
          
    var data = {
    action: 'ffc_final_result',
    is_ajax: 1
    };
    jQuery.post(ffc.ajaxurl, data, function (response) {

        /* Do Response Process */
        data = jQuery.parseJSON(response);

        var h_solvabiliteit = jQuery("#h_solvabiliteit").val();              
        var h_liquiditeit = jQuery("#h_liquiditeit").val();              

        if(h_solvabiliteit == "" & h_liquiditeit == ""){
            jQuery('#p_notcompleted').html(data.sol_liq_wrong_notice);
        } else if((h_liquiditeit == "" || h_liquiditeit < 0) && h_solvabiliteit >= 0){           
            jQuery('#p_notcompleted').html(data.liq_wrong_notice);
        } else if((h_solvabiliteit == "" || h_solvabiliteit < 0) && h_liquiditeit >= 0){
            jQuery('#p_notcompleted').html(data.sol_wrong_notice);
        } else if(h_solvabiliteit != "" && h_liquiditeit != ""){
            jQuery('#p_notcompleted').html(data.accurate_calculation);
        }     
    });    
}
 /**************************************
                            *********** partner selection toggle on off swith *********
                                                            ************************************/
function partner_selection() {
     
    if(jQuery("#yn_switch").prop("checked") == true){ /* checked */
    
        jQuery("#yn_switch").val("1");     
        jQuery("#div_box4").show();        
        jQuery(".sec-sep13").hide();
        jQuery("#div_box4_1").hide();
        
        var data = {
            action: 'ffc_final_result',
            is_ajax: 1
        };
        jQuery.post(ffc.ajaxurl, data, function (response) {
            /* Do Response Process */
            data = jQuery.parseJSON(response); 
            var h_totalincomep = jQuery('#h_totalincomep').val();
        });  
    }
    else { /* unchecked */       
        jQuery("#yn_switch").val("0");   
        jQuery("#div_box4").hide();
        jQuery("#div_box5").hide();     
    }    
}

function calculate_solvabiliteitp() {

    var yearselection = jQuery("#h_partneryearselection").val();

    if (yearselection == '0' || yearselection == '1') {

        var eigenvermogen_1 = jQuery("#txt_eigenvermogenp_1").val();
        var balanstotaal_1 = jQuery("#txt_balanstotaalp_1").val();

        if (eigenvermogen_1 != '' && balanstotaal_1 != '') {

            var percent = (eigenvermogen_1 / balanstotaal_1) * 100;
            percent = percent.toFixed(2);
            jQuery("#h_solvabiliteitp").val(percent);

        } else{ jQuery("#h_solvabiliteitp").val(''); }

    } else if (yearselection == '2') {

        var eigenvermogen_1 = jQuery("#txt_eigenvermogenp_1").val();
        var balanstotaal_1 = jQuery("#txt_balanstotaalp_1").val();

        if (eigenvermogen_1 != '' && balanstotaal_1 != '') {
            var percent = (eigenvermogen_1 / balanstotaal_1) * 100;
            percent = percent.toFixed(2);
        }

        var eigenvermogen_2 = jQuery("#txt_eigenvermogenp_2").val();
        var balanstotaal_2 = jQuery("#txt_balanstotaalp_2").val();

        if (eigenvermogen_2 != '' && balanstotaal_2 != '') {

            var percent2 = (eigenvermogen_2 / balanstotaal_2) * 100;
            percent2 = percent2.toFixed(2);

            if(percent != ''){
                percent2 = percent2 > percent ? percent2 : percent;
            }

            jQuery("#h_solvabiliteitp").val(percent2);

        } else{ jQuery("#h_solvabiliteitp").val(''); }

    } else if (yearselection == '3') {

        var eigenvermogen_2 = jQuery("#txt_eigenvermogenp_2").val();
        var balanstotaal_2 = jQuery("#txt_balanstotaalp_2").val();

        if (eigenvermogen_2 != '' && balanstotaal_2 != '') {
            var percent2 = (eigenvermogen_2 / balanstotaal_2) * 100;
            percent2 = percent2.toFixed(2);  
        }

        var eigenvermogen_3 = jQuery("#txt_eigenvermogenp_3").val();
        var balanstotaal_3 = jQuery("#txt_balanstotaalp_3").val();

        if (eigenvermogen_3 != '' && balanstotaal_3 != '') {
            var percent3 = (eigenvermogen_3 / balanstotaal_3) * 100;
            percent3 = percent3.toFixed(2);

            if(percent2 != ''){
                percent3 = percent3 > percent2 ? percent3 : percent2;
            }

            jQuery("#h_solvabiliteitp").val(percent3);

        } else{ jQuery("#h_solvabiliteitp").val(''); }
    }

    var data = {
    action: 'ffc_final_result',
    is_ajax: 1
    };
    jQuery.post(ffc.ajaxurl, data, function (response) {

        /* Do Response Process */
        data = jQuery.parseJSON(response); 

        var h_solvabiliteit = jQuery("#h_solvabiliteit").val();              
        var h_liquiditeit = jQuery("#h_liquiditeit").val();              
        var h_solvabiliteitp = jQuery("#h_solvabiliteitp").val();              
        var h_liquiditeitp = jQuery("#h_liquiditeitp").val();              
        var h_partnertypeselection = jQuery("#h_partnertypeselection").val();              

        if(h_solvabiliteit == '' || h_liquiditeit == '') {

            calculate_solvabiliteit();
            calculate_liquiditeit();
            
        } else{

            if(h_partnertypeselection > 1) {

                if(h_solvabiliteitp == "" & h_liquiditeitp == ""){
                    jQuery('#p_notcompleted').html(data.p_sol_liq_wrong_notice);
                } else if(h_solvabiliteitp == "" || h_solvabiliteitp < 1){
                    jQuery('#p_notcompleted').html(data.p_sol_wrong_notice);
                } else if(h_liquiditeitp == "" || h_liquiditeitp < 1){
                    jQuery('#p_notcompleted').html(data.p_liq_wrong_notice);
                } else if(h_solvabiliteitp != "" && h_liquiditeitp != ""){
                    jQuery('#p_notcompleted').html(data.accurate_calculation);
                } 

            } else {
                calculate_solvabiliteit();
                calculate_liquiditeit();
            }
           
        }            
    });    
}

function calculate_liquiditeitp() {
    
    var yearselection = jQuery("#h_partneryearselection").val();

    if (yearselection == '0' || yearselection == '1') {

        var vlottendeactiva_1 = jQuery("#txt_vlottendeactivap_1").val();
        var kortvreemdvermogen_1 = jQuery("#txt_kortvreemdvermogenp_1").val();

        if (vlottendeactiva_1 != '' && kortvreemdvermogen_1 != '') {
            var percent = vlottendeactiva_1 / kortvreemdvermogen_1;
            percent = percent.toFixed(2);
            jQuery("#h_liquiditeitp").val(percent);
        } else { jQuery("#h_liquiditeitp").val(''); }

    } else if (yearselection == '2') {

        var vlottendeactiva_2 = jQuery("#txt_vlottendeactivap_2").val();
        var kortvreemdvermogen_2 = jQuery("#txt_kortvreemdvermogenp_2").val();
        var vlottendeactiva_1 = jQuery("#txt_vlottendeactivap_1").val();
        var kortvreemdvermogen_1 = jQuery("#txt_kortvreemdvermogenp_1").val();

        if (vlottendeactiva_1 != '' && kortvreemdvermogen_1 != '') {
            var percent = vlottendeactiva_1 / kortvreemdvermogen_1;
            percent = percent.toFixed(2);
            jQuery("#h_liquiditeitp").val(percent);
        }
        if (vlottendeactiva_2 != '' && kortvreemdvermogen_2 != '') {
            var percent2 = vlottendeactiva_2 / kortvreemdvermogen_2;
            percent2 = percent2.toFixed(2); 
            if(percent != '') {
                percent2 = percent > percent2 ? percent : percent2;
            }          
            jQuery("#h_liquiditeitp").val(percent2);
        }  else { jQuery("#h_liquiditeitp").val(''); }

    } else if (yearselection == '3') {

        var vlottendeactiva_2 = jQuery("#txt_vlottendeactivap_2").val();
        var kortvreemdvermogen_2 = jQuery("#txt_kortvreemdvermogenp_2").val();
        var vlottendeactiva_3 = jQuery("#txt_vlottendeactivap_3").val();
        var kortvreemdvermogen_3 = jQuery("#txt_kortvreemdvermogenp_3").val();

        if (vlottendeactiva_2 != '' && kortvreemdvermogen_2 != '') {
            var percent2 = vlottendeactiva_2 / kortvreemdvermogen_2;
            percent2 = percent2.toFixed(2);            
        }

        if (vlottendeactiva_3 != '' && kortvreemdvermogen_3 != '') {
            var percent3 = vlottendeactiva_3 / kortvreemdvermogen_3;

             if(percent2 != '') {
                percent3 = percent2 > percent3 ? percent2 : percent3;
            }          
            jQuery("#h_liquiditeitp").val(percent3);            
        }  else { jQuery("#h_liquiditeitp").val(''); }
    }
        var data = {
        action: 'ffc_final_result',
        is_ajax: 1
        };
        jQuery.post(ffc.ajaxurl, data, function (response) {

            /* Do Response Process */
            data = jQuery.parseJSON(response);
            var h_solvabiliteit = jQuery("#h_solvabiliteit").val();              
            var h_liquiditeit = jQuery("#h_liquiditeit").val();              
            var h_solvabiliteitp = jQuery("#h_solvabiliteitp").val();              
            var h_liquiditeitp = jQuery("#h_liquiditeitp").val();              
            var h_partnertypeselection = jQuery("#h_partnertypeselection").val();              

            if(h_solvabiliteit == '' || h_liquiditeit == '') {

                calculate_solvabiliteit();
                calculate_liquiditeit();               

            } else{
                if(h_partnertypeselection > 1) {
                    if(h_solvabiliteitp == "" & h_liquiditeitp == ""){
                        jQuery('#p_notcompleted').html(data.p_sol_liq_wrong_notice);
                    } else  if(h_liquiditeitp == "" || h_liquiditeitp < 1){
                        jQuery('#p_notcompleted').html(data.p_liq_wrong_notice);
                    } else if(h_solvabiliteitp == "" || h_solvabiliteitp < 1){
                        jQuery('#p_notcompleted').html(data.p_sol_wrong_notice);
                    } else if(h_solvabiliteitp != "" && h_liquiditeitp != ""){
                        jQuery('#p_notcompleted').html(data.accurate_calculation);
                    } 
                } else {
                    calculate_solvabiliteit();
                    calculate_liquiditeit();
                }
            }         
            
        });     
}

function incomedata_calculation() {

    var yearselection = jQuery("#h_yearselection").val();
    var typeselection = jQuery("#h_typeselection").val();
    var p_yearselection = jQuery("#h_partneryearselection").val();
    var p_typeselection = jQuery("#h_partnertypeselection").val();
    var halfyear_first = jQuery("#txt_halfyear_first").val();
    var halfyear_second = jQuery("#txt_halfyear_second").val();
    var halfyear_third = jQuery("#txt_halfyear_third").val();
    var loondienst = jQuery("#txt_loondienst").val();
    
    var totalincome = 0;
    var p_totalincome = 0;
    var hy_totalincome = 0;

    /*calculation for Freelancer 0.5 Year  */  
    if (yearselection == '0' && typeselection == 'in1') {
        if (halfyear_third != '' && halfyear_first != '') {
            totalincome = ((parseFloat(halfyear_first) + parseFloat(halfyear_third))/2) * 0.9;
            totalincome = parseFloat(totalincome);
            totalincome = totalincome.toFixed(2);
        }
    } else if (yearselection == '1') {
        if(typeselection == 'in1') {
            var average1 = jQuery("#txt_winstuitonderneming_1").val();
            average1 = (average1*100)/100;
            totalincome = average1.toFixed(2);
        }
        if (typeselection == 'ph1') { 
            /*calculation for v.o.f*/
            var salaris_1 = jQuery("#txt_salaris_1").val();
            var dividend_1 = jQuery("#txt_dividend_1").val();
            var overwinst_1 = jQuery("#txt_overwinst_1").val();
            if (salaris_1 != '' && dividend_1 != '' && overwinst_1 != '') {
                var average1 = (salaris_1 * 75) / 100;
                var average2 = (dividend_1 * 75) / 100;
                average2 = (average2 * 75) / 100;
                var average3 = (overwinst_1 * 75) / 100;
                average3 = (average3 * 75) / 100;

                var average = parseFloat(average1) + parseFloat(average2) + parseFloat(average3);
                totalincome = average.toFixed(2);
            }
        } else { 
            /*calculation of Freelancer / B.V*/
            var average1 = jQuery("#txt_winstuitonderneming_1").val();

            average = (average1 * 100) / 100;
             totalincome = average.toFixed(2);
        }
    } else if (yearselection == '2') {
        if (typeselection == 'ph1') {
            var salaris_1 = jQuery("#txt_salaris_1").val();
            var salaris_2 = jQuery("#txt_salaris_2").val();
            var dividend_1 = jQuery("#txt_dividend_1").val();
            var dividend_2 = jQuery("#txt_dividend_2").val();
            var overwinst_1 = jQuery("#txt_overwinst_1").val();
            var overwinst_2 = jQuery("#txt_overwinst_2").val();

            if (salaris_1 != '' && salaris_2 != '' && dividend_1 != '' && dividend_2 != '' && overwinst_1 != '' && overwinst_2 != '') {
                var average1 = (((parseInt(salaris_1) + parseInt(salaris_2)) / 2) * 90) / 100;

                var average2 = (((parseInt(dividend_1) + parseInt(dividend_2)) / 2) * 75) / 100;
                average2 = (average2 * 90) / 100;

                var average3 = (((parseInt(overwinst_1) + parseInt(overwinst_2)) / 2) * 75) / 100;
                average3 = (average3 * 90) / 100;

                var average = parseFloat(average1) + parseFloat(average2) + parseFloat(average3);
                totalincome = average.toFixed(2);
            }
        } else if(typeselection == 'tv1') {
            var average1 = jQuery("#txt_winstuitonderneming_1").val();
            var average2 = jQuery("#txt_winstuitonderneming_2").val();

            var average = (parseFloat(average1) + parseFloat(average2)) / 2;
            average = (average * 90) / 100;
            totalincome = average.toFixed(2);
        } else {
            var average1 = jQuery("#txt_winstuitonderneming_1").val();
            var average2 = jQuery("#txt_winstuitonderneming_2").val();
            var average = (parseFloat(average1) + parseFloat(average2))/ 2
            totalincome = average.toFixed(2);
        }
    } else if (yearselection == '3') {
        if (typeselection == 'ph1') {
            var salaris_1 = jQuery("#txt_salaris_1").val();
            var salaris_2 = jQuery("#txt_salaris_2").val();
            var salaris_3 = jQuery("#txt_salaris_3").val();
            var dividend_1 = jQuery("#txt_dividend_1").val();
            var dividend_2 = jQuery("#txt_dividend_2").val();
            var dividend_3 = jQuery("#txt_dividend_3").val();
            var overwinst_1 = jQuery("#txt_overwinst_1").val();
            var overwinst_2 = jQuery("#txt_overwinst_2").val();
            var overwinst_3 = jQuery("#txt_overwinst_3").val();

            if (salaris_1 != '' && salaris_2 != '' && salaris_3 != '' && dividend_1 != '' && dividend_2 != '' && dividend_3 != '' && overwinst_1 != '' && overwinst_2 != '' && overwinst_3 != '') {
                var average1 = (parseInt(salaris_1) + parseInt(salaris_2) + parseInt(salaris_3)) / 3;
                var average2 = (((parseInt(dividend_1) + parseInt(dividend_2) + parseInt(dividend_3)) / 3) * 75) / 100;
                var average3 = (((parseInt(overwinst_1) + parseInt(overwinst_2) + parseInt(overwinst_3)) / 3) * 75) / 100;
                var average = parseFloat(average1) + parseFloat(average2) + parseFloat(average3);
                totalincome = average.toFixed(2);
            }
        } else {
            var average1 = jQuery("#txt_winstuitonderneming_1").val();
            var average2 = jQuery("#txt_winstuitonderneming_2").val();
            var average3 = jQuery("#txt_winstuitonderneming_3").val();

            var average = (parseFloat(average1) + parseFloat(average2) + parseFloat(average3)) / 3;
            totalincome = average.toFixed(2);
        }
    }    
    /*Calculation for selected partner's income*/
    if (loondienst != '' && p_typeselection=='1') {
        p_totalincome = loondienst;
    } else if (p_yearselection == '0' && p_typeselection == '2') {
        var salaris_1 = jQuery("#txt_halfyearp_first").val();
        var dividend_1 = jQuery("#txt_halfyearp_second").val();
        var overwinst_1 = jQuery("#txt_halfyearp_third").val();
        if (salaris_1 != '' && dividend_1 != '' && overwinst_1 != '') {
            var average = (parseInt(salaris_1) + parseInt(dividend_1) + parseInt(overwinst_1)) / 3;
            average = (average * 90) / 100;
            p_totalincome = average.toFixed(2);
            
        }
    } else if (p_yearselection == '1') {
        if (p_typeselection == '4') {
            var salaris_1 = jQuery("#txt_salarisp_1").val();
            var dividend_1 = jQuery("#txt_dividendp_1").val();
            var overwinst_1 = jQuery("#txt_overwinstp_1").val();
            if (salaris_1 != '' && dividend_1 != '' && overwinst_1 != '') {
                var average1 = (salaris_1 * 75) / 100;
                var average2 = (dividend_1 * 75) / 100;
                average2 = (average2 * 75) / 100;
                var average3 = (overwinst_1 * 75) / 100;
                average3 = (average3 * 75) / 100;

                var average = parseFloat(average1) + parseFloat(average2) + parseFloat(average3);
                p_totalincome = average.toFixed(2);
            }
        } else {
            var average1 = jQuery("#txt_winstuitondernemingp_1").val();            
            if (average1 != '') {
                var average = (average1 * 100) / 100;
                p_totalincome = average.toFixed(2);
            }
        }
    } else if (p_yearselection == '2') {
        if (p_typeselection == '4') {
            var salaris_1 = jQuery("#txt_salarisp_1").val();
            var salaris_2 = jQuery("#txt_salarisp_2").val();
            var dividend_1 = jQuery("#txt_dividendp_1").val();
            var dividend_2 = jQuery("#txt_dividendp_2").val();
            var overwinst_1 = jQuery("#txt_overwinstp_1").val();
            var overwinst_2 = jQuery("#txt_overwinstp_2").val();

            if (salaris_1 != '' && salaris_2 != '' && dividend_1 != '' && dividend_2 != '' && overwinst_1 != '' && overwinst_2 != '') {

                var average1 = (((parseInt(salaris_1) + parseInt(salaris_2)) / 2) * 90) / 100;

                var average2 = (((parseInt(dividend_1) + parseInt(dividend_2)) / 2) * 75) / 100;
                average2 = (average2 * 90) / 100;

                var average3 = (((parseInt(overwinst_1) + parseInt(overwinst_2)) / 2) * 75) / 100;
                average3 = (average3 * 90) / 100;

                var average = parseFloat(average1) + parseFloat(average2) + parseFloat(average3);
                p_totalincome = average.toFixed(2);
            }
        } else {
            var salaris_1 = jQuery("#txt_winstuitondernemingp_1").val();
            var dividend_1 = jQuery("#txt_winstuitondernemingp_2").val();

            if (salaris_1 != '' && dividend_1 != '') {
                var average = (parseInt(salaris_1) + parseInt(dividend_1)) / 2;
                
                p_totalincome = average.toFixed(2);
            }
        }
    } else if (p_yearselection == '3') {
        if (p_typeselection == '4') {
            var salaris_1 = jQuery("#txt_salarisp_1").val();
            var salaris_2 = jQuery("#txt_salarisp_2").val();
            var salaris_3 = jQuery("#txt_salarisp_3").val();
            var dividend_1 = jQuery("#txt_dividendp_1").val();
            var dividend_2 = jQuery("#txt_dividendp_2").val();
            var dividend_3 = jQuery("#txt_dividendp_3").val();
            var overwinst_1 = jQuery("#txt_overwinstp_1").val();
            var overwinst_2 = jQuery("#txt_overwinstp_2").val();
            var overwinst_3 = jQuery("#txt_overwinstp_3").val();

            if (salaris_1 != '' && salaris_2 != '' && salaris_3 != '' && dividend_1 != '' && dividend_2 != '' && dividend_3 != '' && overwinst_1 != '' && overwinst_2 != '' && overwinst_3 != '') {

                var average1 = (parseInt(salaris_1) + parseInt(salaris_2) + parseInt(salaris_3)) / 3;
                var average2 = (((parseInt(dividend_1) + parseInt(dividend_2) + parseInt(dividend_3)) / 3) * 75) / 100;
                var average3 = (((parseInt(overwinst_1) + parseInt(overwinst_2) + parseInt(overwinst_3)) / 3) * 75) / 100;
                var average = parseFloat(average1) + parseFloat(average2) + parseFloat(average3);
                p_totalincome = average.toFixed(2);
            }
        } else {
            var salaris_1 = jQuery("#txt_winstuitondernemingp_1").val();
            var dividend_1 = jQuery("#txt_winstuitondernemingp_2").val();
            var overwinst_1 = jQuery("#txt_winstuitondernemingp_3").val();
            if (salaris_1 != '' && dividend_1 != '' && overwinst_1 != '') {
                var average = (parseInt(salaris_1) + parseInt(dividend_1) + parseInt(overwinst_1)) / 3;
                p_totalincome = average.toFixed(2);
            }
        }
    }   

    var ti_sum = parseFloat(p_totalincome) + parseFloat(totalincome);
    if (p_totalincome != 0 && p_totalincome != 'NULL') {
       var p_totalincome2 = (p_totalincome * 0.70);
        var totalincome_sum = parseFloat(totalincome) + parseFloat(p_totalincome2);
    } else {
        var totalincome_sum = parseFloat(totalincome);
    } 
    if (jQuery.isNumeric(totalincome_sum) == false) {
        totalincome_sum = 0;
    }
    var pid = jQuery("#div_calculationform").attr('data-pid');
    
    var data = {
        action: 'ffc_final_result',
        is_ajax: 1,
        totalincome: totalincome_sum,
        pid:pid,
        ti_sum: ti_sum
    };
    jQuery.post(ffc.ajaxurl, data, function (response) {
        /* Do Response Process */

        data = jQuery.parseJSON(response); 
        var maximale_hypotheek = parseFloat(data.maximale_hypotheek);
        var maandlasten = parseFloat(data.maandlasten);
        var total_income_disp = parseFloat(data.ti_sum);
        var sol_liq_wrong_notice = data.sol_liq_wrong_notice;
        maximale_hypotheek = maximale_hypotheek.toFixed(3);
        maximale_hypotheek = Math.round(maximale_hypotheek);
        maandlasten = maandlasten.toFixed(3);
        maandlasten = Math.round(maandlasten);
        
       if(p_totalincome == '' || p_totalincome == '0'){
        total_income_disp = Math.round(ti_sum);

       } else {
        total_income_disp = Math.round(ti_sum);

       }
        if (jQuery.isNumeric(maximale_hypotheek) == false) {
            maximale_hypotheek = 0;
        }
        if (jQuery.isNumeric(maandlasten) == false) {
            maandlasten = 0;
        }
        var sub_title_txt_size = jQuery('#sub_title_txt_size').val();

        var finalresult = "";
        finalresult += '<ul>';
        finalresult += '<li>';
        finalresult += '<h3 style="font-size:'+sub_title_txt_size+'px;">Uw totale toetsinkomen</h3>';
        finalresult += '<h4 style="font-size:'+sub_title_txt_size+'px;">&euro; <span>' + accounting.formatMoney(total_income_disp, "", 0, ".", ",") + '</span></h4></li>';
        finalresult += '<li>';
        finalresult += '<h3 style="font-size:'+sub_title_txt_size+'px;">Maximale hypotheek</h3>';
        finalresult += '<h4 style="font-size:'+sub_title_txt_size+'px;">&euro; <span>' + accounting.formatMoney(maximale_hypotheek, "", 0, ".", ",") + '</span></h4>';
        finalresult += '</li>';
        finalresult += '<li>';
        finalresult += '<h3 style="font-size:'+sub_title_txt_size+'px;">Maandlasten</h3>';
        finalresult += '<h4 style="font-size:'+sub_title_txt_size+'px;">&euro; <span>' + accounting.formatMoney(maandlasten, "", 0, ".", ",") + '</span></h4>';
        finalresult += '</li>';
        finalresult += '</ul>';

        if (totalincome_sum != '0') {
            jQuery("#h_totalincome").val(totalincome);
            jQuery("#h_totalincomep").val(p_totalincome);
            jQuery("#h_totalincome_sum").val(totalincome_sum);
            jQuery("#h_max_hypotheek").val(maximale_hypotheek);
            jQuery("#h_maandlasten").val(maandlasten);
            jQuery("#div_overzicht").html(finalresult);

            jQuery("#max_hypotheek_btn").html('Maximale hypotheek &euro; ' + accounting.formatMoney(maximale_hypotheek, "", 0, ".", ","));
            jQuery("#div_overzicht").show(); 

            if(totalincome > 0){
                /* show sol and liq euroror in message box*/
                calculate_solvabiliteit();
                calculate_liquiditeit();                
            } else if(p_totalincome > 0) {
                /* show sol and liq error in message box*/
                calculate_solvabiliteitp();
                calculate_liquiditeitp();               
            }           
        } else {
            jQuery("#h_totalincome").val("0");
            jQuery("#max_hypotheek_btn").html("");
            jQuery("#div_overzicht").html("");
            jQuery("#div_overzicht").hide();
        }
    });
}

if (jQuery(window).width() < 992) {

var iEl = document.querySelector('.numbers');
var fEl = document.querySelector('.fake');
var oEl = document.querySelector('pre');
var cEl = document.querySelector('.caret');

var currentValue = '';
var state;

if(iEl){
    iEl.value = '';
fEl.addEventListener('focus', function () {
iEl.focus();
});
iEl.addEventListener('focus', function () {
cEl.style.display = 'block';
});
iEl.addEventListener('blur', function () {
cEl.style.display = 'none';
});
iEl.addEventListener('input', function () {
var val = iEl.value;

if (state === 'backspace' || (!state && val === '')) {
log('backspace');
currentValue = currentValue.substr(0, currentValue.length - 1);
} else if (state) {
log(state + ' pressed');
currentValue += state;
} else {
log(val.substr(1) + ' pressed');
currentValue += val.replace('5','');
}
fEl.value = currentValue;

fixCaret();
iEl.value = '5';

if (typeof iEl.selectionStart == "number") {
iEl.selectionStart = iEl.selectionEnd = 1;
}
if (typeof iEl.createTextRange != "undefined") {
iEl.focus();
var range = iEl.createTextRange();
range.collapse(false);
range.select();
}
});
}

if(fEl){
    fixCaret();

function fixCaret () {
var coordinates = getCaretPosition(fEl, fEl.value.length);
cEl.style.left = coordinates.left + 'px';
}
}

if(iEl){
    iEl.addEventListener('keypress', function (e) {
var key = {
46: '.',
45: '-',
44: ',',
32: ' ',
13: '\n',
8: 'backspace'
}[e.which];
state = key;
});

    iEl.addEventListener('keyup', function () {
state = 0;
iEl.value = '5';

if (typeof iEl.selectionStart == "number") {
iEl.selectionStart = iEl.selectionEnd = 1;
}
if (typeof iEl.createTextRange != "undefined") {
iEl.focus();
var range = iEl.createTextRange();
range.collapse(false);
range.select();
}
});
    function log(msg) {
oEl.textContent = msg + '\n' + oEl.textContent;
}

}

}
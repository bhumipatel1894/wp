<?php 
/**
 * Total calculation form content
 *
 * @package Finaforte
 * @since 1.0
 */
/* Exit if accessed directly */

/************************ Ajustable css *************************/
$title_font_size = !empty(finaforte_get_option('title_font_size') ) ? finaforte_get_option('title_font_size') : '26'; 
$subtitle_font_size = !empty(finaforte_get_option('subtitle_font_size') ) ? finaforte_get_option('subtitle_font_size') : '18'; 
$text_font_size = !empty(finaforte_get_option('text_font_size') ) ? finaforte_get_option('text_font_size') : '16';
$toggle_font_size = !empty(finaforte_get_option('toggle_font_size') ) ? finaforte_get_option('toggle_font_size') : '16';
$gentext_font_size = !empty(finaforte_get_option('gentext_font_size') ) ? finaforte_get_option('gentext_font_size') : '14';

$title_color = !empty(finaforte_get_option('title_color') ) ? finaforte_get_option('title_color') : '#0c6a6d';
$subtitle_color = !empty(finaforte_get_option('subtitle_color') ) ? finaforte_get_option('subtitle_color') : '#0c6a6d';
$text_color = !empty(finaforte_get_option('text_color') ) ? finaforte_get_option('text_color') : '#424242';
$gentext_color = !empty(finaforte_get_option('gentext_color') ) ? finaforte_get_option('gentext_color') : '#444';
$call_sec_txt_color = !empty(finaforte_get_option('call_sec_txt_color') ) ? finaforte_get_option('call_sec_txt_color') : '#0c6a6d';

$border_radius = !empty(finaforte_get_option('border_radius') ) ? finaforte_get_option('border_radius') : '10'; 
$btn_border_color = !empty(finaforte_get_option('btn_border_color') ) ? finaforte_get_option('btn_border_color') : '#d3d3d3';
$txt_border_color = !empty(finaforte_get_option('txt_border_color') ) ? finaforte_get_option('txt_border_color') : '#d3d3d3';
$backgroundcolor = !empty(finaforte_get_option('theme_bg_color') ) ? finaforte_get_option('theme_bg_color') : '#f5f5f5';
$btn_text_color = !empty(finaforte_get_option('btn_text_color') ) ? finaforte_get_option('btn_text_color') : '#fff';
$btn_bg_color = !empty(finaforte_get_option('btn_bg_color') ) ? finaforte_get_option('btn_bg_color') : '#0c6a6d';
$divider_clr = !empty(finaforte_get_option('divider_clr') ) ? finaforte_get_option('divider_clr') : '#0c6a6d';

/********************* advicer photo ******************************/
$advicer_photo = finaforte_esc_attr(finaforte_get_option('advicer_photo'));
$advice_contact = finaforte_esc_attr(finaforte_get_option("advice_contact"));
$thankyou_page = finaforte_esc_attr(finaforte_get_option('thankyou_page'));

/******************** Icon color ***********************/

$freelancer_icon_clr = finaforte_get_option('freelancer_icon_clr');
$freelancer_bg_clr = finaforte_get_option('freelancer_bg_clr');
$freelancer_text_clr = finaforte_get_option('freelancer_text_clr');
$vof_icon_clr = finaforte_get_option('vof_icon_clr');
$vof_bg_clr = finaforte_get_option('vof_bg_clr');
$vof_text_clr = finaforte_get_option('vof_text_clr');
$bv_dga_icon_clr = finaforte_get_option('bv_dga_icon_clr');
$bv_dga_bg_clr = finaforte_get_option('bv_dga_bg_clr');
$bv_dga_text_clr = finaforte_get_option('bv_dga_text_clr');
$loondienst_icon_clr = finaforte_get_option('loondienst_icon_clr');
$loondienst_bg_clr = finaforte_get_option('loondienst_bg_clr');
$loondienst_text_clr = finaforte_get_option('loondienst_text_clr');
$toggle_bg_clr = finaforte_get_option('toggle_bg_clr');
$toggle_text_clr = finaforte_get_option('toggle_text_clr');

/***************** Adjustable gen Calculation **********************/

$mortgage_interest = finaforte_get_option('mortgage_interest');
$tooltip_mortgage_interest = finaforte_get_option('tooltip_mortgage_interest'); 
$view_cal_button_text = finaforte_get_option('view_cal_button_text');
$popup_button_text = finaforte_get_option('popup_button_text');

/* ****************** Tooltip ************************* */
$tooltip_total_p_incom = finaforte_get_option('tooltip_total_p_incom');
$tooltip_select_year = finaforte_get_option('tooltip_select_year');
$tooltip_salary = finaforte_get_option('tooltip_salary');
$tooltip_mortgage_interest  = finaforte_get_option('tooltip_mortgage_interest');
$cal_sugg_text = finaforte_get_option('cal_sugg_text');
$tooltip_loondienst  = finaforte_get_option('tooltip_loondienst');

/***************** Adjustable Calculation 1 **********************/
$max_hypo_1_per = finaforte_esc_attr(finaforte_get_option('max_hypo_1_per'));
$rent1 = finaforte_esc_attr(finaforte_get_option('calculation_1_rate'));
$year1 = finaforte_esc_attr(finaforte_get_option('calculation_1_y'));
$belastingteruggave1 = finaforte_esc_attr(finaforte_get_option('belastingteruggave_1'));
   
/***************** Adjustable Calculation 2 **********************/
$min_hypo_2_per = finaforte_esc_attr(finaforte_get_option('min_hypo_2_per'));
$rent2 = finaforte_esc_attr(finaforte_get_option('calculation_2_rate'));
$year2 = finaforte_esc_attr(finaforte_get_option('calculation_2_y'));
$belastingteruggave2 = finaforte_esc_attr(finaforte_get_option('belastingteruggave_2'));

/***************** Adjustable Calculation 3 **********************/
$rent3 = finaforte_esc_attr(finaforte_get_option('calculation_3_rate'));
$year3 = finaforte_esc_attr(finaforte_get_option('calculation_3_y'));
$belastingteruggave3 = finaforte_esc_attr(finaforte_get_option('belastingteruggave_3'));
$max_hypo_3_bkd = finaforte_esc_attr(finaforte_get_option('maximale_hypotheek_3'));

/***************** Adjustable Calculation 4 **********************/
$rent4 = finaforte_esc_attr(finaforte_get_option('calculation_4_rate'));
$year4 = finaforte_esc_attr(finaforte_get_option('calculation_4_y'));
$belastingteruggave4 = finaforte_esc_attr(finaforte_get_option('belastingteruggave_4'));
 

/**************** get solvency settings *******************/
$solvency_green = finaforte_get_option('solvency_green_color');
$solvency_yellow = finaforte_get_option('solvency_yellow_color');
$solvency_red = finaforte_get_option('solvency_red_color');

/**************** get liquidity settings *******************/
$liquidity_red = finaforte_get_option('liquidity_red_color');
$liquidity_green = finaforte_get_option('liquidity_green_color');
$liquidity_yellow = finaforte_get_option('liquidity_yellow_color');

/******************start calculation page********************/
$solvabiliteit_text = finaforte_get_option('solvabiliteit_text') ? finaforte_get_option('solvabiliteit_text') : 'Solvabiliteit toevoegen';
$liquiditeit_text = finaforte_get_option('liquiditeit_text') ? finaforte_get_option('liquiditeit_text') : 'Liquiditeit toevoegen';
$solva_liq_header_text = finaforte_get_option('solva_liq_header_text') ? finaforte_get_option('solva_liq_header_text') : 'Vul hier uw balansratio\'s in';
$solva_liq_header_descri = finaforte_get_option('solva_liq_header_descri') ? finaforte_get_option('solva_liq_header_descri') : 'Door de solvabiliteit en de liquiditeit van uw bedrijf in te vullen kriigt u naast inzicht in uw maximale hypotheek ook inzicht in de haalbaarheid hiervan op basis van de financiële gezondheid van uw bedrijf.';

/******************total calculation page********************/
$cal_heading = finaforte_get_option('cal_heading') ? nl2br(finaforte_get_option('cal_heading')) : '';
$total_incom_text = finaforte_get_option('total_incom_text') ? finaforte_get_option('total_incom_text') : '';
$partner_total_incom_text = finaforte_get_option('partner_total_incom_text') ? finaforte_get_option('partner_total_incom_text') : '';
$total_cal_border_clr = finaforte_get_option('total_cal_border_clr') ? finaforte_get_option('total_cal_border_clr') : '';
$total_cal_txt_clr = finaforte_get_option('total_cal_txt_clr') ? finaforte_get_option('total_cal_txt_clr') : '';
$total_cal_bg_clr = finaforte_get_option('total_cal_bg_clr') ? finaforte_get_option('total_cal_bg_clr') : '';

/******************* Email Data ***************************/
$email_subject = finaforte_get_option('email_subject') ? finaforte_get_option('email_subject') : 'Please find your calculation';
$email_title = finaforte_get_option('email_title') ? finaforte_get_option('email_title') : '';
$email_description = finaforte_get_option('email_description') ? finaforte_get_option('email_description') : '';
$emil_footer_l1 = finaforte_get_option('emil_footer_l1') ? finaforte_get_option('emil_footer_l1') : '';
$emil_footer_l2 = finaforte_get_option('emil_footer_l2') ? finaforte_get_option('emil_footer_l2') : '';
$footer_email_id = finaforte_get_option('footer_email_id') ? finaforte_get_option('footer_email_id') : '';
$footer_site_url = finaforte_get_option('footer_site_url') ? finaforte_get_option('footer_site_url') : '';
$email_footer_button_txt = finaforte_get_option('email_footer_button_txt') ? finaforte_get_option('email_footer_button_txt') : '';
$email_footer_button_url = finaforte_get_option('email_footer_button_url') ? finaforte_get_option('email_footer_button_url') : '#';
$email_logo = finaforte_get_option('email_logo') ? finaforte_get_option('email_logo') : '';
$email_cal_bgclr = finaforte_get_option('email_cal_bgclr') ? finaforte_get_option('email_cal_bgclr') : '';
$email_cal_box_bgclr = finaforte_get_option('email_cal_box_bgclr') ? finaforte_get_option('email_cal_box_bgclr') : '';
$email_foo_bgclr = finaforte_get_option('email_foo_bgclr') ? finaforte_get_option('email_foo_bgclr') : '';
$email_cal_borderclr = finaforte_get_option('email_cal_borderclr') ? finaforte_get_option('email_cal_borderclr') : '';
$email_btn_bgclr = finaforte_get_option('email_btn_bgclr') ? finaforte_get_option('email_btn_bgclr') : '';
$email_btn_txtclr = finaforte_get_option('email_btn_txtclr') ? finaforte_get_option('email_btn_txtclr') : '#ffffff';
$email_icon_clr = finaforte_get_option('email_icon_clr') ? finaforte_get_option('email_icon_clr') : '';
$email_topname_clr = finaforte_get_option('email_topname_clr') ? finaforte_get_option('email_topname_clr') : '';
<?php
/**
 * Settings Page
 *
 * @package Fina Forte
 * @since 1.0
 */
/*Exit if accessed directly*/
if (!defined('ABSPATH'))
    exit;
?>
<style type="text/css">
    .aigpl-imgs-preview img{
            width: 110px;
    border-radius: 10px;
    }
</style>

<div class="wrap bwswpos-settings">    
    <ul class="tabs">
    <li>
        <input type="radio" name="tabs" id="tab1" class="" checked />
        <label class="tab-label" for="tab1" id="tab1">Settings</label>       
    </li>  
    <li>
        <input type="radio" name="tabs" id="tab2" class="tab-content2" />
        <label class="tab-label" for="tab2" id="tab2">Adjustable Texts</label>        
    </li>    
    <li>
        <input type="radio" name="tabs" id="tab3" class="tab-content3" />
        <label class="tab-label" for="tab3" id="tab3">Adjustable CSS</label>        
    </li>    
    <li>
        <input type="radio" name="tabs" id="tab4" class="tab-content4" />
        <label class="tab-label" for="tab4" id="tab4">Calculations</label>   
    </li>  
</ul>

<form action="options.php" method="POST" id="finaforte-settings-form" class="finaforte-settings-form">
        <?php settings_fields('finaforte_plugin_options'); ?>
        <?php
        global $finaforte_options;
        $finaforte_options = finaforte_get_settings();
        /*Success message*/
        if (isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true') {
            echo '<div id="message" class="updated notice notice-success is-dismissible">
                <p><strong>Your changes saved successfully</strong></p>
            </div>';
        }  ?>
<div id="tab-content1" class="tab-content">            
                       
    <div id="finaforte-label-sett" class="post-box-container finaforte-label-sett">            
    <!-- advisor Photo -->
             
    <h3 class="hndle" style="margin-top: 24px;">
        <span><?php _e('Advicer Details', 'finaforte'); ?></span>
    </h3> <hr>
        <div class="inside">
            <table class="form-table finaforte-label-tbl">
                <tbody>
                    
                    <tr><th><label for="finaforte-label"><?php _e('Shortcode', 'finaforte'); ?>:</label></th>
                        <td><b>[fina_forte_mortgage] </b><br /><p></p>
                            <span class="description"><?php _e('Copy this shortcode and put it in the page where you want to show calculator.', 'finaforte'); ?></span></td>
                    </tr>

                    <tr>
                        <th scope="row">
                            <label for="finaforte-label"><?php _e('Advicer Photo', 'finaforte'); ?>:</label>
                        </th>   
                        <td>
                            <input type="text" name="finaforte_options[advicer_photo]" value="<?php echo finaforte_get_option('advicer_photo'); ?>" id="aigpl-default-img" class="regular-text aigpl-default-img aigpl-img-upload-input" />
                            <input type="button" name="aigpl_advicer_photo" class="button-secondary aigpl-img-uploader" value="<?php _e('Upload Image', 'finaforte'); ?>" />
                            <input type="button" name="aigpl_advicer_photo_clear" id="aigpl-default-img-clear" class="button button-secondary aigpl-image-clear" value="<?php _e('Clear', 'finaforte'); ?>" /> <br />
                            <span class="description"><?php _e('Photo of advisor.', 'finaforte'); ?></span>
                            <?php
                            $advicer_photo = '';
                            if (finaforte_get_option('advicer_photo')) {
                                $advicer_photo = '<img src="' . finaforte_get_option('advicer_photo') . '" alt="Advicer" />';
                            }
                            ?>
                            <div class="aigpl-imgs-preview"><?php echo $advicer_photo; ?></div>
                        </td>                                       
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="finaforte-label"><?php _e('Contact No', 'finaforte'); ?>:</label>
                        </th>
                        <td>
                            <input type="text" class="width_50" name="finaforte_options[advice_contact]" id="advice_contact" value="<?php echo finaforte_esc_attr(finaforte_get_option('advice_contact')); ?>" 
                                    return false;" /><br/> <!-- onkeyup="check(); -->
                            <span class="description" id="message"><?php _e('Contact no will display below advicer photo on calculation page.', 'finaforte'); ?></span> <br>                                        
                        </td>
                    </tr>   
                    <tr>
                         <th scope="row">
                            <label for="finaforte-label"><?php _e('Thankyou Page', 'finaforte'); ?>:</label>
                        </th>
                        <td>
                            <select name="finaforte_options[thankyou_page]" id="thankyou_page" class="width_50">
                        <?php $pages = get_pages(); 

                        foreach($pages as $page){ ?>
                            <option value="<?php echo $page->ID; ?>" <?php selected(finaforte_get_option('thankyou_page'), $page->ID, true ); ?> ><?php echo $page->post_title; ?></option>
                            <?php
                        }
                        ?>  
                            </select> <br/>
                            <span class="description" id="message"><?php _e('Please choose thankyou page to redirect after emnail send.', 'finaforte'); ?></span> <br>           
                        </td>  
                    </tr>                  
                    <tr>
                        <td colspan="2" valign="top" scope="row">
                            <input type="submit" id="bwswpos-settings-submit" name="bwswpos-settings-submit" class="button button-primary right" value="<?php _e('Save Changes', 'finaforte'); ?>" />
                        </td>
                    </tr>
                </tbody>
            </table>
        </div><!-- .inside -->       
                   
        <!-- SMTP Details -->
        <h3 class="hndle">
            <span><?php _e('SMTP Details'); ?></span>
        </h3><hr>
        <div class="inside">
            <table class="form-table finaforte-label-tbl">
                <tbody>
                    <tr>
                        <th scope="row">
                            <label for="finaforte-label"><?php _e('SMTP server address', 'finaforte'); ?>:</label>
                        </th>
                        <td>
                            <input type="text" class="width_50" name="finaforte_options[smtp_server_add]" id="smtp_server_add" value="<?php echo finaforte_esc_attr(finaforte_get_option('smtp_server_add')); ?>" /><br/>
                            <span class="description" id="message"><?php _e('Please enter SMTP server address.', 'finaforte'); ?></span> <br>
                           
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="finaforte-label"><?php _e('SMTP username', 'finaforte'); ?>:</label>
                        </th>
                        <td>
                            <input type="text" class="width_50" name="finaforte_options[smtp_username]" id="smtp_username" value="<?php echo finaforte_esc_attr(finaforte_get_option('smtp_username')); ?>"/><br/>
                            <span class="description"><?php _e('Please enter SMTP username', 'finaforte'); ?></span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="smtp_password"><?php _e('SMTP password ', 'finaforte'); ?>:</label>
                        </th>
                        <td>
                            <input type="password" class="width_50" name="finaforte_options[smtp_password]" id="smtp_password" value="<?php echo finaforte_esc_attr(finaforte_get_option('smtp_password')); ?>"/><br/>
                            <span class="description"><?php _e('Please enter SMTP password', 'finaforte'); ?></span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="smtp_from_email"><?php _e('From Email Address ', 'finaforte'); ?>:</label>
                        </th>
                        <td>
                            <input type="text" class="width_50" name="finaforte_options[smtp_from_email]" id="smtp_from_email" value="<?php echo finaforte_esc_attr(finaforte_get_option('smtp_from_email')); ?>"/><br/>
                            <span class="description"><?php _e('This address, like the return address printed on an mail template, identifies the account owner to the SMTP server.', 'finaforte'); ?></span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="smtp_from_name"><?php _e('From Name', 'finaforte'); ?>:</label>
                        </th>
                        <td>
                            <input type="text" class="width_50" name="finaforte_options[smtp_from_name]" id="smtp_from_name" value="<?php echo finaforte_esc_attr(finaforte_get_option('smtp_from_name')); ?>"/><br/>
                            <span class="description"><?php _e('This name, like the return address printed on an mail template.', 'finaforte'); ?></span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="finaforte-label"><?php _e('SMTP port type', 'finaforte'); ?>:</label>
                        </th>
                        <td>
                            <select name="finaforte_options[smtp_port_type]" id="smtp_port_type" class="width_50">
                                 <option value="" <?php selected("", finaforte_get_option('smtp_port_type')); ?> >None</option>
                                <option value="tls" <?php selected("tls", finaforte_get_option('smtp_port_type')); ?> >STRTTLS</option>
                                <option value="ssl" <?php selected("ssl", finaforte_get_option('smtp_port_type')); ?> >SMTPS</option>
                            </select><br/>
                            <span class="description"><?php _e('Please select SMTP port type', 'finaforte'); ?></span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="finaforte-label"><?php _e('SMTP port', 'finaforte'); ?>:</label>
                        </th>
                        <td>
                            <input type="text" class="width_50" name="finaforte_options[smtp_port]" id="smtp_port" value="<?php echo finaforte_esc_attr(finaforte_get_option('smtp_port')); ?>"/><br/>
                            <span class="description"><?php _e('Please enter SMTP port', 'finaforte'); ?></span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="finaforte-label"><?php _e(' E-mail CC1 ', 'finaforte'); ?>:</label>
                        </th>
                        <td>
                            <input type="email" class="width_50" name="finaforte_options[cc1_email]" id="cc1_email" value="<?php echo finaforte_esc_attr(finaforte_get_option('cc1_email')); ?>"/><br/>
                            <span class="description"><?php _e('E-mail CC1 receiver of the lead.', 'finaforte'); ?></span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="finaforte-label"><?php _e('E-mail CC2', 'finaforte'); ?>:</label>
                        </th>
                        <td>
                            <input type="email" class="width_50" name="finaforte_options[cc2_email]" id="cc2_email" value="<?php echo finaforte_esc_attr(finaforte_get_option('cc2_email')); ?>"/><br/>
                            <span class="description"><?php _e(' E-mail CC2 recipient of the lead.', 'finaforte'); ?></span>
                        </td>
                    </tr>

                    <tr>
                        <td colspan="2" valign="top" scope="row">
                            <input type="submit" id="bwswpos-settings-submit" name="bwswpos-settings-submit" class="button button-primary right" value="<?php _e('Save Changes', 'finaforte'); ?>" />
                        </td>
                    </tr>

                    <tr>
                        <td colspan="2">
                    <h3 class="hndle">
                        <span><?php _e('Email details'); ?></span>
                    </h3><hr>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="finaforte-label"><?php _e('Email Subject', 'finaforte'); ?>:</label>
                        </th>
                        <td>
                            <input type="text" class="width_50" name="finaforte_options[email_subject]" id="email_subject" value="<?php echo finaforte_esc_attr(finaforte_get_option('email_subject')); ?>"/><br/>
                            <span class="description"><?php _e('This text will display as email subject', 'finaforte'); ?></span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="finaforte-label"><?php _e('Email title', 'finaforte'); ?>:</label>
                        </th>
                        <td>
                            <input type="text" class="width_50" name="finaforte_options[email_title]" id="email_title" value="<?php echo finaforte_esc_attr(finaforte_get_option('email_title')); ?>"/><br/>
                            <span class="description"><?php _e('This title will display in email body and pdf description title', 'finaforte'); ?></span>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">
                            <label for="finaforte-label"><?php _e('Email description', 'finaforte'); ?>:</label>
                        </th>
                        <td>
                            <textarea class="width_50" name="finaforte_options[email_description]" id="email_description" value="<?php echo finaforte_esc_attr(finaforte_get_option('email_description')); ?>"><?php echo finaforte_esc_attr(finaforte_get_option('email_description')); ?></textarea>
                           <br/>
                            <span class="description"><?php _e('This description will display in email and pdf below title', 'finaforte'); ?></span>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">
                            <label for="finaforte-label"><?php _e('Email Footer line 1', 'finaforte'); ?>:</label>
                        </th>
                        <td>
                            <input type="text" class="width_50" name="finaforte_options[emil_footer_l1]" id="emil_footer_l1" value="<?php echo finaforte_esc_attr(finaforte_get_option('emil_footer_l1')); ?>"/><br/>
                            <span class="description"><?php _e('this text will display in email footer line 1', 'finaforte'); ?></span>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">
                            <label for="finaforte-label"><?php _e('Email Footer line 2', 'finaforte'); ?>:</label>
                        </th>
                        <td>
                            <input type="text" class="width_50" name="finaforte_options[emil_footer_l2]" id="emil_footer_l2" value="<?php echo finaforte_esc_attr(finaforte_get_option('emil_footer_l2')); ?>"/><br/>
                            <span class="description"><?php _e('this text will display in email footer line 2', 'finaforte'); ?></span>
                        </td>
                    </tr>

                     <tr>
                        <th scope="row">
                            <label for="email_footer_button_txt"><?php _e('Email Footer Button text', 'finaforte'); ?>:</label>
                        </th>
                        <td>
                            <input type="text" class="width_50" name="finaforte_options[email_footer_button_txt]" id="email_footer_button_txt" value="<?php echo finaforte_esc_attr(finaforte_get_option('email_footer_button_txt')); ?>"/><br/>
                            <span class="description"><?php _e('this text will display in email footer button', 'finaforte'); ?></span>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">
                            <label for="email_footer_button_url"><?php _e('Email Footer Button URL', 'finaforte'); ?>:</label>
                        </th>
                        <td>
                            <input type="text" class="width_50" name="finaforte_options[email_footer_button_url]" id="email_footer_button_url" value="<?php echo finaforte_esc_attr(finaforte_get_option('email_footer_button_url')); ?>"/><br/>
                            <span class="description"><?php _e('this text will display in email footer button for redirection', 'finaforte'); ?></span>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">
                            <label for="footer_email_id"><?php _e('Footer email id', 'finaforte'); ?>:</label>
                        </th>
                        <td>
                            <input type="text" class="width_50" name="finaforte_options[footer_email_id]" id="footer_email_id" value="<?php echo finaforte_esc_attr(finaforte_get_option('footer_email_id')); ?>"/><br/>
                            <span class="description"><?php _e('This text will display in email footer description', 'finaforte'); ?></span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="footer_site_url"><?php _e('Footer Website URL', 'finaforte'); ?>:</label>
                        </th>
                        <td>
                            <input type="text" class="width_50" name="finaforte_options[footer_site_url]" id="footer_site_url" value="<?php echo finaforte_esc_attr(finaforte_get_option('footer_site_url')); ?>"/><br/>
                            <span class="description"><?php _e('This url will display in email footer description', 'finaforte'); ?></span>
                        </td>
                    </tr>    
                    <tr>
                        <th scope="row">
                            <label for="email_topname_clr">Name color:</label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[email_topname_clr]" id="email_topname_clr" value="<?php echo finaforte_esc_attr(finaforte_get_option('email_topname_clr')); ?>"/>
                            <span class="description">This color css will apply on sender name in mail body.</span>
                        </td>
                    </tr>               
                    <tr>
                        <th scope="row">
                            <label for="email_cal_bgclr">Calculation background:</label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[email_cal_bgclr]" id="email_cal_bgclr" value="<?php echo finaforte_esc_attr(finaforte_get_option('email_cal_bgclr')); ?>"/>
                            <span class="description">This color css will apply in calculation box background.</span>
                        </td>
                       
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="email_cal_box_bgclr">Calculation box background:</label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[email_cal_box_bgclr]" id="email_cal_box_bgclr" value="<?php echo finaforte_esc_attr(finaforte_get_option('email_cal_box_bgclr')); ?>"/>
                            <span class="description">This color css will apply in all 4 calculation box background.</span>
                        </td>
                       
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="email_foo_bgclr">Footer background:</label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[email_foo_bgclr]" id="email_foo_bgclr" value="<?php echo finaforte_esc_attr(finaforte_get_option('email_foo_bgclr')); ?>"/>
                            <span class="description">This color css will apply to footer box background.</span>
                        </td>
                       
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="email_cal_borderclr">Calculation border:</label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[email_cal_borderclr]" id="email_cal_borderclr" value="<?php echo finaforte_esc_attr(finaforte_get_option('email_cal_borderclr')); ?>"/>
                            <span class="description">This color css will apply to email calculation box boder</span>
                        </td>  
                    </tr>
                    <tr>
                       <th scope="row">
                            <label for="email_btn_bgclr">Email button background color:</label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[email_btn_bgclr]" id="email_btn_bgclr" value="<?php echo finaforte_esc_attr(finaforte_get_option('email_btn_bgclr')); ?>"/>
                            <span class="description">This css will apply to email button background.</span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="finaforte-label"><?php _e('Email Logo', 'finaforte'); ?>:</label>
                        </th>   
                        <td>
                            <input type="text" name="finaforte_options[email_logo]" value="<?php echo finaforte_get_option('email_logo'); ?>" id="aigpl-default-img2" class="regular-text aigpl-default-img2 aigpl-img-upload-input" />
                            <input type="button" name="aigpl_email_logo" class="button-secondary aigpl-img-uploader" value="<?php _e('Upload Image', 'finaforte'); ?>" />
                            <input type="button" name="aigpl_email_logo_clear" id="aigpl-default-img2-clear" class="button button-secondary aigpl-image-clear" value="<?php _e('Clear', 'finaforte'); ?>" /> <br />
                            <span class="description"><?php _e('Photo of advisor (for next to the total calculation).', 'finaforte'); ?></span>
                            <?php
                            $email_logo = '';
                            if (finaforte_get_option('email_logo')) {
                                $email_logo = '<img src="' . finaforte_get_option('email_logo') . '" alt="Advicer" />';
                            }
                            ?>
                            <div class="aigpl-imgs-preview"><?php echo $email_logo  ; ?></div>
                        </td>                                       
                    </tr>
                    
                    <tr>
                        <td colspan="2" valign="top" scope="row">
                            <input type="submit" id="bwswpos-settings-submit" name="bwswpos-settings-submit" class="button button-primary right" value="<?php _e('Save Changes', 'finaforte'); ?>" />
                        </td>
                    </tr>
                </tbody>
            </table>
        </div><!-- .inside -->
    </div>
            
    </div>
        <!-- tab 2 code -->
        <!--  -->
        <div id="tab-content2" class="tab-content"><!-- tab content-->                
            <div id="finaforte-label-sett" class="post-box-container finaforte-label-sett">
                
                <!-- Settings box title -->                
                <table class="form-table finaforte-label-tbl">
                    <tbody>
                           <h3 class="hndle" style="margin-top: 24px;"><span>Calculation form adjustable text. </span></h3> <hr> 
                        
                        <tr>
                            <th scope="row">
                                <label for="view_cal_button_text">Submit button text:</label>
                            </th>
                            <td>
                                <input type="text" class="width_50" name="finaforte_options[view_cal_button_text]" id="view_cal_button_text" value= "<?php echo finaforte_esc_attr(finaforte_get_option('view_cal_button_text')); ?>" ><br>
                                <span class="description">This text will display on submit buttom of calculation page</span>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="popup_button_text">Popup button text:</label>
                            </th>
                            <td>
                                <input type="text" class="width_50" name="finaforte_options[popup_button_text]" id="popup_button_text" value= "<?php echo finaforte_esc_attr(finaforte_get_option('popup_button_text')); ?>" ><br>
                                <span class="description">This text will display on popup button text</span>
                            </td>
                        </tr>
                       
                        <tr><td colspan="2"><hr>
                           <h3 class="hndle" style="margin-top: 24px;"><span>Total calculation adjustable text. </span></h3> <hr> </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="free_advice_label">Free advice label:</label>
                            </th>
                            <td>
                                <input type="text" class="width_50" name="finaforte_options[free_advice_label]" id="free_advice_label" value= "<?php echo finaforte_esc_attr(finaforte_get_option('free_advice_label')); ?>" ><br>
                                <span class="description">This is the lable of free advice and it will display on total calculation page in section of send email button. </span>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="free_advice_text">Free advice text:</label>
                            </th>
                            <td>
                                <textarea rows="3" cols="65" name="finaforte_options[free_advice_text]" id="free_advice_text"><?php echo finaforte_esc_attr(finaforte_get_option('free_advice_text')); ?></textarea><br>

                                <span class="description">This text will dispaly on all calculation below free advice lable. </span>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="email_button_text">Email button text:</label>
                            </th>
                            <td>
                                <input type="text" class="width_50" name="finaforte_options[email_button_text]" id="email_button_text" value= "<?php echo finaforte_esc_attr(finaforte_get_option('email_button_text')); ?>" ><br>
                                <span class="description">Enter email button text </span>
                            </td>
                        </tr> 
                        <tr>
                            <th scope="row">
                                <label for="cal_heading">Calculation heading:</label>
                            </th>
                            <td>
                                <textarea rows="10" cols="65" name="finaforte_options[cal_heading]" id="cal_heading"><?php echo finaforte_esc_attr(finaforte_get_option('cal_heading')); ?></textarea><br>
                                <span class="description">Note: You can use
                                    &lt;b&gt;your text&lt;/b&gt; for bold text, Press "Enter" key for line break.
                                 </span>
                            </td>
                        </tr> 
                        

                        <!-- <tr>
                            <th scope="row">
                                <label for="total_incom_text">Totale toetsinkomen text:</label>
                            </th>
                            <td>
                                <input type="text" class="width_50" name="finaforte_options[total_incom_text]" id="total_incom_text" value= "<?php //echo finaforte_esc_attr(finaforte_get_option('total_incom_text')); ?>" ><br>
                                <span class="description">Enter email button text </span>
                            </td>
                        </tr> 
                        <tr>
                            <th scope="row">
                                <label for="partner_total_incom_text">partner totale toetsinkomen text:</label>
                            </th>
                            <td>
                                <input type="text" class="width_50" name="finaforte_options[partner_total_incom_text]" id="partner_total_incom_text" value= "<?php // echo finaforte_esc_attr(finaforte_get_option('partner_total_incom_text')); ?>" ><br>
                                <span class="description">Enter email button text </span>
                            </td>
                        </tr>  -->
                        <tr><td colspan="2"><hr>
                           <h3 class="hndle" style="margin-top: 24px;"><span>Send email form adjustable text. </span></h3> <hr> </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="email_form_heading">Email Form Heading:</label>
                            </th>
                            <td>
                                <input type="text" class="width_50" name="finaforte_options[email_form_heading]" id="email_form_heading" value= "<?php echo finaforte_esc_attr(finaforte_get_option('email_form_heading')); ?>" ><br>
                                <span class="description">This is the heading of email form and it will be dispaly on top of the form.. </span>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="email_free_advice_label">Free advice label:</label>
                            </th>
                            <td>
                                <input type="text" class="width_50" name="finaforte_options[email_free_advice_label]" id="email_free_advice_label" value= "<?php echo finaforte_esc_attr(finaforte_get_option('email_free_advice_label')); ?>" ><br>
                                <span class="description">This is the lable of free advice and it will display on send email page. </span>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="email_free_advice_text">Free advice text:</label>
                            </th>
                            <td>
                                <textarea rows="3" cols="65" name="finaforte_options[email_free_advice_text]" id="email_free_advice_text"><?php echo finaforte_esc_attr(finaforte_get_option('email_free_advice_text')); ?></textarea><br>

                                <span class="description">This text will dispaly on all calculation below free advice lable. </span>
                            </td>
                        </tr>                      

                        <tr>                                        
                            <th></th>
                            <td colspan="2" valign="top" scope="row">
                                <input type="submit" id="bwswpos-settings-submit" name="bwswpos-settings-submit" class="button button-primary right" value="<?php _e('Save Changes', 'finaforte'); ?>" />
                            </td>
                        </tr>
                    </tbody>
                </table>

                <!-- Notice Texts -->
                <hr><h3 class="hndle"><span>Notice Fields</span></h3> <hr>
                <div class="inside">
                    <table class="form-table finaforte-label-tbl">
                        <tbody>
                            <tr>
                                <th scope="row">
                                    <label for="sol_liq_wrong_notice">Solvabiliteit and Liquiditeit are not entered:</label>
                                </th>
                                <td>                                            
                                    <input type="text" class="width_50"  name="finaforte_options[sol_liq_wrong_notice]" id="sol_liq_wrong_notice" value="<?php echo finaforte_esc_attr(finaforte_get_option('sol_liq_wrong_notice')); ?>"/><br/>
                                    <span class="description">Add notice text for this field</span>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="finaforte-label">Solvabiliteit is not entered:</label>
                                </th>
                                <td>                                            
                                    <input type="text" class="width_50"  name="finaforte_options[sol_wrong_notice]" id="sol_wrong_notice" value="<?php echo finaforte_esc_attr(finaforte_get_option('sol_wrong_notice')); ?>"/><br/>
                                    <span class="description">Add notice text for this field</span>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="theme_color">Liquiditeit is not entered:</label>
                                </th>
                                <td>                                            
                                    <input type="text" class="width_50" name="finaforte_options[liq_wrong_notice]" id="liq_wrong_notice" value="<?php echo finaforte_esc_attr(finaforte_get_option('liq_wrong_notice')); ?>"/><br/>
                                    <span class="description">Add notice text for this field</span>
                                </td>
                            </tr>   
                            <tr>
                                <th scope="row">
                                    <label for="P_sol_liq_wrong_notice">Partner's Solvabiliteit and Liquiditeit are not entered:</label>
                                </th>
                                <td>
                                    <input type="text" class="width_50" name="finaforte_options[p_sol_liq_wrong_notice]" id="p_sol_liq_wrong_notice" value="<?php echo finaforte_esc_attr(finaforte_get_option('p_sol_liq_wrong_notice')); ?>"/><br/>
                                    <span class="description">Add notice text for this field</span>
                                </td>
                            </tr>  
                            <tr>
                                <th scope="row">
                                    <label for="p_sol_wrong_notice">Partner's Solvabiliteit is not entered:</label>
                                </th>
                                <td>
                                    <input type="text" class="width_50" name="finaforte_options[p_sol_wrong_notice]" id="p_sol_wrong_notice" value="<?php echo finaforte_esc_attr(finaforte_get_option('p_sol_wrong_notice')); ?>"/><br/>
                                    <span class="description">Add notice text for this field</span>
                                </td>
                            </tr> 
                            <tr>
                                <th scope="row">
                                    <label for="P_liq_wrong_notice">Partner's Liquiditeit is not entered:</label>
                                </th>
                                <td>
                                    <input type="text" class="width_50" name="finaforte_options[p_liq_wrong_notice]" id="p_liq_wrong_notice" value="<?php echo finaforte_esc_attr(finaforte_get_option('p_liq_wrong_notice')); ?>"/><br/>
                                    <span class="description">Add notice text for this field</span>
                                </td>
                            </tr>     
                            <tr>
                                <th scope="row">
                                    <label for="P_liq_wrong_notice">Accurate Calculation:</label>
                                </th>
                                <td>
                                    <input type="text" class="width_50" name="finaforte_options[accurate_calculation]" id="accurate_calculation" value="<?php echo finaforte_esc_attr(finaforte_get_option('accurate_calculation')); ?>"/><br/>
                                    <span class="description">Add notice text for this field</span>
                                </td>
                            </tr>                     
                            <tr>                                        
                                <th></th>
                                <td colspan="2" valign="top" scope="row">
                                    <input type="submit" id="bwswpos-settings-submit" name="bwswpos-settings-submit" class="button button-primary right" value="<?php _e('Save Changes', 'finaforte'); ?>" />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <!-- solvency -->            
                <hr><h3 class="hndle"><span>Solvency</span> </h3> <hr>
                <div class="inside">
                    <table class="form-table finaforte-label-tbl">
                        <tbody>
                            <tr>
                                <th style="width: 20%">
                                    <label for="solva_liq_header_text">Section Header text:</label>
                                </th>
                                <td scope="row" style="width: 45%">
                                   
                                    <input type="text" class="width_80" name="finaforte_options[solva_liq_header_text]" id="solva_liq_header_text" value= "<?php echo finaforte_esc_attr(finaforte_get_option('solva_liq_header_text')); ?>" ><br>
                                    <span class="description">This text will display solvabiliteit and liquiditeit header text</span>
                                </td>
                                <td style="width: 35%">                                    
                                </td>
                            </tr>
                            <tr>
                                <th style="width: 20%">
                                    <label for="solva_liq_header_descri">Section Header description:</label>
                                </th>
                                <td scope="row" style="width: 45%">
                                     <textarea rows="10" cols="65" name="finaforte_options[solva_liq_header_descri]" id="solva_liq_header_descri"><?php echo finaforte_esc_attr(finaforte_get_option('solva_liq_header_descri')); ?></textarea> <br>
                                    <span class="description">This text will display solvabiliteit and liquiditeit header text</span>
                                    <span class="description">Note: You can use
                                    &lt;b&gt;your text&lt;/b&gt; for bold text, Press "Enter" key for line break.
                                 </span>
                                </td>
                                <td style="width: 35%">                                    
                                </td>
                            </tr>
                            <tr>
                                <th style="width: 20%">
                                    <label for="solvabiliteit_text">Solvabiliteit text:</label>
                                </th>
                                <td scope="row" style="width: 45%">
                                    <input type="text" class="width_80" name="finaforte_options[solvabiliteit_text]" id="solvabiliteit_text" value= "<?php echo finaforte_esc_attr(finaforte_get_option('solvabiliteit_text')); ?>" ><br>
                                    <span class="description">This text will display solvabiliteit text</span>
                                </td>
                                <td style="width: 35%">                                    
                                </td>
                            </tr>
                           
                            <tr>
                                <td style="width: 20%"></td>
                                <th style="width: 45%" class="title">Insert Text</th>
                                <th style="width: 35%" class="title">Choose Color</th>
                            </tr>
                            <tr>
                                <th scope="row" class="title">
                                    <label for="solvency_green_text">Green:</label>
                                </th>
                                <td>                                            
                                    <input type="text" class="width_80" name="finaforte_options[solvency_green_text]" id="solvency_green_text" value="<?php echo finaforte_esc_attr(finaforte_get_option('solvency_green_text')); ?>"/><br/>
                                    <span class="description">Enter lable for Green Text (if Solvency 20% or more)</span>
                                </td>
                                <td>
                                    <input type="text" name="finaforte_options[solvency_green_color]" id="solvency_green_color" value="<?php echo finaforte_esc_attr(finaforte_get_option('solvency_green_color')); ?>"/><br/>
                                    <span class="description">Choose Green Text Color.</span>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row" class="title">
                                    <label for="solvency_yellow_text">Yellow:</label>
                                </th>
                                <td>                                            
                                    <input type="text" class="width_80" name="finaforte_options[solvency_yellow_text]" id="solvency_yellow_text" value="<?php echo finaforte_esc_attr(finaforte_get_option('solvency_yellow_text')); ?>"/><br/>
                                    <span class="description">Enter lable for Yellow Text</span>
                                </td>
                                <td>                                            
                                    <input type="text" name="finaforte_options[solvency_yellow_color]" id="solvency_yellow_color" value="<?php echo finaforte_esc_attr(finaforte_get_option('solvency_yellow_color')); ?>"/><br/>
                                    <span class="description">Choose Yellow text Color.</span>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row" class="title">
                                    <label for="solvency_red_text">Red:</label>
                                </th>
                                <td>                                            
                                    <input type="text" class="width_80" class="width_80" name="finaforte_options[solvency_red_text]" id="solvency_red_text" value="<?php echo finaforte_esc_attr(finaforte_get_option('solvency_red_text')); ?>"/><br/>
                                    <span class="description">Enter lable for Red Text.</span>
                                </td>
                                <td>

                                    <input type="text" name="finaforte_options[solvency_red_color]" id="solvency_red_color" value="<?php echo finaforte_esc_attr(finaforte_get_option('solvency_red_color')); ?>"/><br/>
                                    <span class="description">Choose Red text Color.</span>
                                </td>
                            </tr>
                            <tr>                                        
                                <td colspan="3" valign="top" scope="row">
                                    <input type="submit" id="bwswpos-settings-submit" name="bwswpos-settings-submit" class="button button-primary right" value="<?php _e('Save Changes', 'finaforte'); ?>" />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div><!-- .inside -->

                <!-- liquidity -->           
                <hr><h3 class="hndle"><span><?php _e('Liquidity', 'finaforte'); ?></span></h3><hr>
                <div class="inside">
                    <table class="form-table finaforte-label-tbl">
                        <tbody>
                            <tr>
                                <th style="width: 20%">
                                    <label for="liquiditeit_text">Liquiditeit text:</label>
                                </th>
                                <td style="width: 45%" class="title">
                                    <input type="text" class="width_80" name="finaforte_options[liquiditeit_text]" id="liquiditeit_text" value= "<?php echo finaforte_esc_attr(finaforte_get_option('liquiditeit_text')); ?>" >
                                    <br>
                                    <span class="description">This text will display liquiditeit text</span>
                                </td>
                                <th style="width: 35%" class="title"></th>
                            </tr>
                            <tr>
                                <td style="width: 20%"></td>
                                <th style="width: 45%" class="title">Insert Text</th>
                                <th style="width: 35%" class="title">Choose Color</th>
                            </tr>
                            <tr>
                                <th scope="row" class="title">
                                    <label for="finaforte-label"><?php _e('Green text', 'finaforte'); ?>:</label>
                                </th>
                                <td>                                            
                                    <input type="text" class="width_80" name="finaforte_options[liquidity_green_text]" id="liquidity_green_text" value="<?php echo finaforte_esc_attr(finaforte_get_option('liquidity_green_text')); ?>"/><br/>
                                    <span class="description"><?php _e('Enter lable for Green Text.', 'finaforte'); ?></span>
                                </td>
                                <td>                                            
                                    <input type="text" name="finaforte_options[liquidity_green_color]" id="liquidity_green_color" value="<?php echo finaforte_esc_attr(finaforte_get_option('liquidity_green_color')); ?>"/><br/>
                                    <span class="description"><?php _e('Choose Green Text Color.', 'finaforte'); ?></span>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row" class="title">
                                    <label for="finaforte-label"><?php _e('Yellow text', 'finaforte'); ?>:</label>
                                </th>
                                <td>                                            
                                    <input type="text" class="width_80" name="finaforte_options[liquidity_yellow_text]" id="liquidity_yellow_text" value="<?php echo finaforte_esc_attr(finaforte_get_option('liquidity_yellow_text')); ?>"/><br/>
                                    <span class="description"><?php _e('Enter lable for Yellow Text.', 'finaforte'); ?></span>
                                </td>
                                <td>                                            
                                    <input type="text" name="finaforte_options[liquidity_yellow_color]" id="liquidity_yellow_color" value="<?php echo finaforte_esc_attr(finaforte_get_option('liquidity_yellow_color')); ?>"/><br/>
                                    <span class="description"><?php _e('Choose Yellow text Color.', 'finaforte'); ?></span>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row" class="title">
                                    <label for="finaforte-label"><?php _e('Red text', 'finaforte'); ?>:</label>
                                </th>
                                <td>                                            
                                    <input type="text" class="width_80" name="finaforte_options[liquidity_red_text]" id="liquidity_red_text" value="<?php echo finaforte_esc_attr(finaforte_get_option('liquidity_red_text')); ?>"/><br/>
                                    <span class="description"><?php _e('Enter lable for Red Text.', 'finaforte'); ?></span>
                                </td>
                                <td>                                            
                                    <input type="text" name="finaforte_options[liquidity_red_color]" id="liquidity_red_color" value="<?php echo finaforte_esc_attr(finaforte_get_option('liquidity_red_color')); ?>"/><br/>
                                    <span class="description"><?php _e('Choose Red text Color.', 'finaforte'); ?></span>
                                </td>
                            </tr>

                            <tr>
                                <td colspan="3" valign="top" scope="row">
                                    <input type="submit" id="bwswpos-settings-submit" name="bwswpos-settings-submit" class="button button-primary right" value="<?php _e('Save Changes', 'finaforte'); ?>" />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div><!-- .inside -->

                <!-- Settings box title -->
                <hr><h3 class="hndle"><span>Tooltip Box</span></h3><hr>
                <div class="inside">
                    <table class="form-table finaforte-label-tbl">
                        <tbody>
                            <tr>
                                <th scope="row">
                                    <label for="tooltip_select_year">select year tooltip:</label>
                                </th>
                                <td>                                            
                                    <input type="text" class="width_80" name="finaforte_options[tooltip_select_year]" id="tooltip_select_year" value="<?php echo finaforte_esc_attr(finaforte_get_option('tooltip_select_year')); ?>"/><br/>
                                    <span class="description">Enter tooltip for selct year radio button</span>
                                </td>
                            </tr>   
                            <tr>
                                <th scope="row">
                                    <label for="tooltip_salary">salary tooltip:</label>
                                </th>
                                <td>                                            
                                    <input type="text" class="width_80" name="finaforte_options[tooltip_salary]" id="tooltip_salary" value="<?php echo finaforte_esc_attr(finaforte_get_option('tooltip_salary')); ?>"/><br/>
                                    <span class="description">Enter tooltip for salary textbox</span>
                                </td>
                            </tr>   
                            <tr>
                                <th scope="row">
                                    <label for="tooltip_loondienst">loondienst tooltip:</label>
                                </th>
                                <td>                                            
                                    <input type="text" class="width_80" name="finaforte_options[tooltip_loondienst]" id="tooltip_loondienst" value="<?php echo finaforte_esc_attr(finaforte_get_option('tooltip_loondienst')); ?>"/><br/>
                                    <span class="description">Enter tooltip for loondienst textbox</span>
                                </td>
                            </tr>   
                            <tr>
                                <th scope="row">
                                    <label for="tooltip_mortgage_interest">mortgage interest tooltip:</label>
                                </th>
                                <td>                                            
                                    <input type="text" class="width_80" name="finaforte_options[tooltip_mortgage_interest]" id="tooltip_mortgage_interest" value="<?php echo finaforte_esc_attr(finaforte_get_option('tooltip_mortgage_interest')); ?>"/><br/>
                                    <span class="description">Enter tooltip for salary textbox</span>
                                </td>
                            </tr>       
                                               
                            <tr>                                        
                                <th></th>
                                <td colspan="2" valign="top" scope="row">
                                    <input type="submit" id="bwswpos-settings-submit" name="bwswpos-settings-submit" class="button button-primary right" value="<?php _e('Save Changes', 'finaforte'); ?>" />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
       
    <!-- end tab content -->
    </div>

    <div id="tab-content3" class="tab-content">
          
        <!-- start tab content -->
        <div id="finaforte-label-sett" class="post-box-container finaforte-label-sett">           
           
            <!-- Settings box title -->            
            <table class="form-table finaforte-label-tbl">
                <tbody>
                    <tr><h3 class="hndle" style="margin-top: 24px;"><span>Theme effect</span> </h3> <hr></tr> 
                    <tr>
                        <th scope="row" style="padding:10px 0; width:25%;">
                            <label for="theme_bg_color">Theme background color:</label>
                        </th>
                        <td style="padding:10px 0; width:25%;">                                            
                            <input type="text" class="width_50" name="finaforte_options[theme_bg_color]" id="theme_bg_color" value="<?php echo finaforte_esc_attr(finaforte_get_option('theme_bg_color')); ?>"/>
                            <span class="description">Choose theme background color.</span>
                        </td> 
                        <th scope="row" style="padding:10px 0; width:25%;">
                            <label for="border_radius">Border radius:</label>
                        </th>
                        <td style="padding:10px 0; width:25%;">                                            
                            <input type="number" min="0" name="finaforte_options[border_radius]" id="border_radius" value="<?php echo finaforte_esc_attr(finaforte_get_option('border_radius')); ?>"/> px<br/>
                            <span class="description">radius must be grater than "0", This border radius will affect all textfields, buttons,some boxes</span>
                        </td>                       
                    </tr>
                     <tr>
                        <th scope="row">
                            <label for="txt_border_color">Textfields Border color:</label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[txt_border_color]" id="txt_border_color" value="<?php echo finaforte_esc_attr(finaforte_get_option('txt_border_color')); ?>"/>
                            <span class="description">This css will apply to all box border.</span>
                        </td>
                        <th scope="row">
                            <label for="total_cal_border_clr">Total calculation border color:</label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[total_cal_border_clr]" id="total_cal_border_clr" value="<?php echo finaforte_esc_attr(finaforte_get_option('total_cal_border_clr')); ?>"/>
                            <span class="description">This css will apply to Total calculation page box boder</span>
                        </td> 
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="total_cal_border_clr">Total cal background color:</label>
                        </th>
                         <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[total_cal_bg_clr]" id="total_cal_bg_clr" value="<?php echo finaforte_esc_attr(finaforte_get_option('total_cal_bg_clr')); ?>"/>
                            <span class="description">This css will apply to Total calculation page box boder</span>
                        </td> 
                        <th scope="row">
                            <label for="divider_clr">Divider color:</label>
                        </th>
                         <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[divider_clr]" id="divider_clr" value="<?php echo finaforte_esc_attr(finaforte_get_option('divider_clr')); ?>"/>
                            <span class="description">This css will apply to divider color</span>
                        </td>
                        
                    </tr>
                    <tr>
                        <td colspan="4" valign="top" scope="row">
                                <input type="submit" id="bwswpos-settings-submit" name="bwswpos-settings-submit" class="button button-primary right" value="<?php _e('Save Changes', 'finaforte'); ?>" />
                            </td>
                    </tr>

                    <!-- Icon effect -->
                    <tr>
                        <td colspan="4" class="colspantd">
                            <h3 class="hndle" style="margin-top: -21px;"><span>Icon effect</span> </h3> <hr> 
                       </td>
                    </tr> 
                    <tr>
                        <th scope="row">
                            <label for="freelancer_icon_clr">Freelancer Icon:</label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[freelancer_icon_clr]" id="freelancer_icon_clr" value="<?php echo finaforte_esc_attr(finaforte_get_option('freelancer_icon_clr')); ?>"/>
                            <span class="description">select color for freelancer icon.</span>
                        </td>
                        <th scope="row">
                            <label for="freelancer_bg_clr">Freelancer background:</label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[freelancer_bg_clr]" id="freelancer_bg_clr" value="<?php echo finaforte_esc_attr(finaforte_get_option('freelancer_bg_clr')); ?>"/>
                            <span class="description">select color for freelancer background.</span>
                        </td>
                    </tr> 
                    
                    <tr>
                        <th scope="row">
                            <label for="freelancer_text_clr">Freelancer Text:</label>
                        </th>
                        <td colspan="3">                                            
                            <input type="text" class="width_50" name="finaforte_options[freelancer_text_clr]" id="freelancer_text_clr" value="<?php echo finaforte_esc_attr(finaforte_get_option('freelancer_text_clr')); ?>"/>
                            <span class="description">select color for freelancer text.</span>
                        </td>
                        
                    </tr> 
                    <!-- cpy -->
                     <tr>
                       
                        <th scope="row">
                            <label for="vof_icon_clr">V.O.F icon:</label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[vof_icon_clr]" id="vof_icon_clr" value="<?php echo finaforte_esc_attr(finaforte_get_option('vof_icon_clr')); ?>"/>
                            <span class="description">select color for v.o.f icon.</span>
                        </td>
                        <th scope="row">
                            <label for="vof_bg_clr">V.O.F Background:</label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[vof_bg_clr]" id="vof_bg_clr" value="<?php echo finaforte_esc_attr(finaforte_get_option('vof_bg_clr')); ?>"/>
                            <span class="description">select color for v.o.f background.</span>
                        </td>
                    </tr> 
                    <tr>                       
                        <th scope="row">
                            <label for="vof_text_clr">V.O.F text:</label>
                        </th>
                        <td colspan="3">                                            
                            <input type="text"  class="width_50" name="finaforte_options[vof_text_clr]" id="vof_text_clr" value="<?php echo finaforte_esc_attr(finaforte_get_option('vof_text_clr')); ?>"/>
                            <span class="description">select color for v.o.f text.</span>
                        </td>                        
                    </tr> 
                    <tr>
                        <th scope="row">
                            <label for="bv_dga_icon_clr">BV/DGA Icon:</label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[bv_dga_icon_clr]" id="bv_dga_icon_clr" value="<?php echo finaforte_esc_attr(finaforte_get_option('bv_dga_icon_clr')); ?>"/>
                            <span class="description">select color for bv/dga icon.</span>
                        </td>
                        <th scope="row">
                            <label for="bv_dga_bg_clr">BV/DGA Background:</label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[bv_dga_bg_clr]" id="bv_dga_bg_clr" value="<?php echo finaforte_esc_attr(finaforte_get_option('bv_dga_bg_clr')); ?>"/>
                            <span class="description">select color for bv/dga background.</span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="bv_dga_text_clr">BV/DGA text:</label>
                        </th>
                        <td colspan="3">                                            
                            <input type="text" class="width_50" name="finaforte_options[bv_dga_text_clr]" id="bv_dga_text_clr" value="<?php echo finaforte_esc_attr(finaforte_get_option('bv_dga_text_clr')); ?>"/>
                            <span class="description">select color for bv/dga text.</span>
                        </td>
                        
                    </tr>
                    <tr>
                       <th scope="row">
                            <label for="loondienst_icon_clr">Loondienst icon:</label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[loondienst_icon_clr]" id="loondienst_icon_clr" value="<?php echo finaforte_esc_attr(finaforte_get_option('loondienst_icon_clr')); ?>"/>
                            <span class="description">select color for Loondienst icon.</span>
                        </td>
                        <th scope="row">
                            <label for="loondienst_bg_clr">Loondienst Background:</label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[loondienst_bg_clr]" id="loondienst_bg_clr" value="<?php echo finaforte_esc_attr(finaforte_get_option('loondienst_bg_clr')); ?>"/>
                            <span class="description">select color for Loondienst background.</span>
                        </td>
                    </tr>
                    <tr>                        
                        <th scope="row">
                            <label for="loondienst_text_clr">Loondienst Text:</label>
                        </th>
                        <td colspan="3">                                            
                            <input type="text" class="width_50" name="finaforte_options[loondienst_text_clr]" id="loondienst_text_clr" value="<?php echo finaforte_esc_attr(finaforte_get_option('loondienst_text_clr')); ?>"/>
                            <span class="description">select color for Loondienst text.</span>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="4" valign="top" scope="row">
                            <input type="submit" id="bwswpos-settings-submit" name="bwswpos-settings-submit" class="button button-primary right" value="<?php _e('Save Changes', 'finaforte'); ?>" />
                        </td>
                    </tr>
                
                    <!-- Button effect section -->
                    <tr>
                        <td colspan="4" class="colspantd">
                            <h3 class="hndle" style="margin-top: -21px;"><span>Button effect</span> </h3> <hr> 
                       </td>
                    </tr> 
                    <tr>
                        <th scope="row">
                            <label for="btn_text_color">All button text color:</label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[btn_text_color]" id="btn_text_color" value="<?php echo finaforte_esc_attr(finaforte_get_option('btn_text_color')); ?>"/>
                            <span class="description">Choose button text color.</span>
                        </td>
                        <th scope="row">
                            <label for="btn_bg_color">Button background color:</label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[btn_bg_color]" id="btn_bg_color" value="<?php echo finaforte_esc_attr(finaforte_get_option('btn_bg_color')); ?>"/>
                            <span class="description">Choose button background color.</span>
                        </td>
                    </tr>                    
                    <tr>
                        <th scope="row">
                            <label for="btn_border_color">Button border color:</label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[btn_border_color]" id="btn_border_color" value="<?php echo finaforte_esc_attr(finaforte_get_option('btn_border_color')); ?>"/>
                            <span class="description">This css will apply to all button border.</span>
                        </td>
                        <td colspan="2"></td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="toggle_text_clr">Toggle button text: </label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[toggle_text_clr]" id="toggle_text_clr" value="<?php echo finaforte_esc_attr(finaforte_get_option('toggle_text_clr')); ?>"/>
                            <span class="description">Choose toggle button text color.</span>
                        </td>
                        <th scope="row">
                            <label for="toggle_bg_clr">Toggle button background:</label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[toggle_bg_clr]" id="toggle_bg_clr" value="<?php echo finaforte_esc_attr(finaforte_get_option('toggle_bg_clr')); ?>"/>
                            <span class="description">Choose toggle button background color.</span>
                        </td>
                    </tr>  
                    
                    <!-- Font effect section -->
                    <tr>
                        <td colspan="4" class="colspantd">
                            <h3 class="hndle" style="margin-top: 24px;"><span>Font effect</span> </h3> <hr> 
                       </td>
                    </tr> 
                        <th scope="row">
                            <label for="title_font_size">Title font size:</label>
                        </th>
                        <td>                                            
                            <input type="number" min="10" name="finaforte_options[title_font_size]" id="title_font_size" value="<?php echo finaforte_esc_attr(finaforte_get_option('title_font_size')); ?>"/> px<br/>
                            <span class="description">Please enter title font size.</span>
                        </td>
                        <th scope="row">
                            <label for="title_color">Title font color:</label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[title_color]" id="title_color" value="<?php echo finaforte_esc_attr(finaforte_get_option('title_color')); ?>"/>
                            <span class="description">all main title color will be changed.</span>
                        </td>
                    </tr>  
                    <tr>
                        <th scope="row">
                            <label for="subtitle_font_size">Subtitle font size:</label>
                        </th>
                        <td>                                            
                            <input type="number" min="8" name="finaforte_options[subtitle_font_size]" id="subtitle_font_size" value="<?php echo finaforte_esc_attr(finaforte_get_option('subtitle_font_size')); ?>"/> px<br/>
                            <span class="description">Please enter subtitle font size.</span>
                        </td>
                        <th scope="row">
                            <label for="subtitle_color">Subtitle font color:</label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[subtitle_color]" id="subtitle_color" value="<?php echo finaforte_esc_attr(finaforte_get_option('subtitle_color')); ?>"/>
                            <span class="description">all subtitle color will be changed.</span>
                        </td>
                    </tr> 
                    <tr>
                        <th scope="row">
                            <label for="text_font_size">Text size:</label>
                        </th>
                        <td>                                            
                            <input type="number" min="8" name="finaforte_options[text_font_size]" id="text_font_size" min="14" max="16" value="<?php echo finaforte_esc_attr(finaforte_get_option('text_font_size')); ?>"/> px<br/>
                            <span class="description">This font size will affect all text below subtitle.</span>
                        </td>
                        <th scope="row">
                            <label for="text_color">font color:</label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[text_color]" id="text_color" value="<?php echo finaforte_esc_attr(finaforte_get_option('text_color')); ?>"/>
                            <span class="description">color of all text below subtitle will be changed.</span>
                        </td>
                    </tr>  
                     <tr>
                        <th scope="row">
                            <label for="gentext_font_size">General font size:</label>
                        </th>
                        <td>                                            
                            <input type="number" min="8" name="finaforte_options[gentext_font_size]" id="gentext_font_size" value="<?php echo finaforte_esc_attr(finaforte_get_option('gentext_font_size')); ?>"/> px<br/>
                            <span class="description">all other general font size will be changed.</span>
                        </td>
                        <th scope="row">
                            <label for="gentext_color">General font color:</label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[gentext_color]" id="gentext_color" value="<?php echo finaforte_esc_attr(finaforte_get_option('gentext_color')); ?>"/>
                            <span class="description">color of all general text of forms will be changed.</span>
                        </td>

                     </tr>   

                     <tr>
                       <th colspan="2"></th>
                        <th scope="row">
                            <label for="gentext_font_size">Total calculation text color:</label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[total_cal_txt_clr]" id="total_cal_txt_clr" value="<?php echo finaforte_esc_attr(finaforte_get_option('total_cal_txt_clr')); ?>"/>
                            <span class="description">This css will be apply to total calculation font color  changed.</span>
                        </td>
                        <th scope="row">
                        </th>
                        <td>                                            
                        </td>

                     </tr>

                      <tr>
                       <th colspan="2"></th>
                        <th scope="row">
                            <label for="gentext_font_size">contact num section font color:</label>
                        </th>
                        <td>                                            
                            <input type="text" class="width_50" name="finaforte_options[call_sec_txt_color]" id="call_sec_txt_color" value="<?php echo finaforte_esc_attr(finaforte_get_option('call_sec_txt_color')); ?>"/>
                            <span class="description">This css will be apply on contact no section on sidebar .</span>
                        </td>
                        <th scope="row">
                        </th>
                        <td>                                            
                        </td>

                     </tr>



                    <tr>
                        <td colspan="4" valign="top" scope="row">
                            <input type="submit" id="bwswpos-settings-submit" name="bwswpos-settings-submit" class="button button-primary right" value="<?php _e('Save Changes', 'finaforte'); ?>" />
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        
    <!-- end tab content -->
    </div>
    <div id="tab-content4" class="tab-content">
             <div id="finaforte-label-sett" class="post-box-container finaforte-label-sett">
           
            <!-- Settings box title -->
            <h3 class="hndle" style="margin-top: 24px;"><span>General Fields</span></h3> <hr>
            <table class="form-table finaforte-label-tbl">
                <tbody>
                    <tr>
                        <th scope="row">
                            <label for="number_of_periods">number of periods:</label>
                        </th>
                        <td>                                            
                            <input type="number" class="width_50" step="0.0001" name="finaforte_options[number_of_periods]" id="number_of_periods" value="<?php echo finaforte_esc_attr(finaforte_get_option('number_of_periods')); ?>"/><br/>
                            <span class="description">Enter number of periods</span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="finaforte-label">Mortgage interest:</label>
                        </th>
                        <td>                                            
                            <input type="number" class="width_50" step="0.0001" name="finaforte_options[mortgage_interest]" id="mortgage_interest" value="<?php echo finaforte_esc_attr(finaforte_get_option('mortgage_interest')); ?>"/><br/>
                            <span class="description">Enter mortgage interest per year</span>
                        </td>
                    </tr>
                                           
                    <tr>                                        
                        <th></th>
                        <td colspan="2" valign="top" scope="row">
                            <input type="submit" id="bwswpos-settings-submit" name="bwswpos-settings-submit" class="button button-primary right" value="<?php _e('Save Changes', 'finaforte'); ?>" />
                        </td>
                    </tr>
                </tbody>
            </table>
            <!-- Hypotheekberekening 1 -->      
                        
            <!-- Settings box title -->
            <h3 class="hndle">
                <span>Hypotheekberekening 1</span>
            </h3> <hr>
            <div class="inside">
                <table class="form-table finaforte-label-tbl">
                    <tbody>
                        <tr>
                            <th scope="row">
                                <label for="max_hypo_1_per">Maximale hypotheek Per:</label>
                            </th>
                            <td>                                
                                <input type="number" step="1" name="finaforte_options[max_hypo_1_per]" id="max_hypo_1_per" value="<?php echo finaforte_esc_attr(finaforte_get_option('max_hypo_1_per')); ?>"/>%<br/>
                                <span class="description">Maximum Hypotheek percentage</span>
                            </td>
                        </tr>                                   
                        <tr>                                
                            <th scope="row">
                                <label for="calculation_1_rate">interest rate:</label>
                            </th>
                            <td>                                            
                                <input type="number" step="0.01" name="finaforte_options[calculation_1_rate]" id="calculation_1_rate" value="<?php echo finaforte_esc_attr(finaforte_get_option('calculation_1_rate')); ?>"/>%<br/>
                                <span class="description">Maximum mortgage calculation interest rate</span>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="calculation_1_y">Year:</label>
                            </th>
                            <td>                                
                                <input type="number" step="0.01" name="finaforte_options[calculation_1_y]" id="calculation_1_y" value="<?php echo finaforte_esc_attr(finaforte_get_option('calculation_1_y')); ?>"/><br/>
                                <span class="description">Maximum mortgage calculation year</span>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="belastingteruggave_1">Belastingteruggave:</label>
                            </th>
                            <td>                                
                                <input type="number" step="0.01" name="finaforte_options[belastingteruggave_1]" id="belastingteruggave_1" value="<?php echo finaforte_esc_attr(finaforte_get_option('belastingteruggave_1')); ?>"/>%<br/>
                                <span class="description">Enter per of belastingteruggave </span>
                            </td>
                        </tr>
                        <tr>                                        
                            <th></th>
                            <td colspan="2" valign="top" scope="row">
                                <input type="submit" id="bwswpos-settings-submit" name="bwswpos-settings-submit" class="button button-primary right" value="<?php _e('Save Changes', 'finaforte'); ?>" />
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
                    
            <!-- Hypotheekberekening 2 -->          
           <hr>
            <h3 class="hndle">
                <span>Hypotheekberekening 2</span>
            </h3><hr>
            <div class="inside">
                <table class="form-table finaforte-label-tbl">
                    <tbody> 
                        <tr>                                
                            <th scope="row">
                                <label for="min_hypo_2_per">Minimale hypotheek per:</label>
                            </th>
                            <td>                                            
                                <input type="number" step="1" name="finaforte_options[min_hypo_2_per]" id="min_hypo_2_per" value="<?php echo finaforte_esc_attr(finaforte_get_option('min_hypo_2_per')); ?>"/>%<br/>
                                <span class="description">Minimum mortgage percentage for only 1,3 year</span>
                            </td>
                        </tr>                               
                        <tr>                                
                            <th scope="row">
                                <label for="calculation_2_rate">Interest rate:</label>
                            </th>
                            <td>                                            
                                <input type="number" step="0.01" name="finaforte_options[calculation_2_rate]" id="calculation_2_rate" value="<?php echo finaforte_esc_attr(finaforte_get_option('calculation_2_rate')); ?>"/>%<br/>
                                <span class="description">Maximum mortgage calculation interest rate</span>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="calculation_2_rate">Year:</label>
                            </th>
                            <td>                                
                                <input type="number" step="0.01" name="finaforte_options[calculation_2_y]" id="calculation_2_y" value="<?php echo finaforte_esc_attr(finaforte_get_option('calculation_2_y')); ?>"/><br/>
                                <span class="description">Maximum mortgage calculation year</span>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="belastingteruggave_2">Belastingteruggave:</label>
                            </th>
                            <td>                                
                                <input type="number" step="0.01" name="finaforte_options[belastingteruggave_2]" id="belastingteruggave_2" value="<?php echo finaforte_esc_attr(finaforte_get_option('belastingteruggave_2')); ?>"/>%<br/>
                                <span class="description">Enter per of belastingteruggave </span>
                            </td>
                        </tr>
                        <tr>                                        
                            <th></th>
                            <td colspan="2" valign="top" scope="row">
                                <input type="submit" id="bwswpos-settings-submit" name="bwswpos-settings-submit" class="button button-primary right" value="<?php _e('Save Changes', 'finaforte'); ?>" />
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
                    
            <!-- Hypotheekberekening 3 -->           <hr>
            <!-- Settings box title -->
            <h3 class="hndle">
                <span>Hypotheekberekening 3</span>
            </h3>
            <div class="inside">
                <table class="form-table finaforte-label-tbl">
                    <tbody>                                 
                        <tr>                                
                            <th scope="row">
                                <label for="calculation_3_rate">Interest rate:</label>
                            </th>
                            <td>                                            
                                <input type="number" step="0.01" name="finaforte_options[calculation_3_rate]" id="calculation_3_rate" value="<?php echo finaforte_esc_attr(finaforte_get_option('calculation_3_rate')); ?>"/>%<br/>
                                <span class="description">Maximum mortgage calculation interest rate</span>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="calculation_3_y">Year:</label>
                            </th>
                            <td>                                
                                <input type="number" step="0.01" name="finaforte_options[calculation_3_y]" id="calculation_3_y" value="<?php echo finaforte_esc_attr(finaforte_get_option('calculation_3_y')); ?>"/><br/>
                                <span class="description">Maximum mortgage calculation year</span>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="belastingteruggave_3">Belastingteruggave:</label>
                            </th>
                            <td>                                
                                <input type="number" step="0.01" name="finaforte_options[belastingteruggave_3]" id="belastingteruggave_3" value="<?php echo finaforte_esc_attr(finaforte_get_option('belastingteruggave_3')); ?>"/>%<br/>
                                <span class="description">Enter per of belastingteruggave </span>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="finaforte-label">Maximale hypotheek:</label>
                            </th>
                            <td>                                            
                                <input type="number" step="0.0001" name="finaforte_options[maximale_hypotheek_3]" id="maximale_hypotheek_3" value="<?php echo finaforte_esc_attr(finaforte_get_option('maximale_hypotheek_3')); ?>"/><br/>
                                <span class="description">Maximale hypotheek for calculation 3 based on 10 years</span>
                            </td>
                        </tr>
                        <tr>                                        
                            <th></th>
                            <td colspan="2" valign="top" scope="row">
                                <input type="submit" id="bwswpos-settings-submit" name="bwswpos-settings-submit" class="button button-primary right" value="<?php _e('Save Changes', 'finaforte'); ?>" />
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
                   
            <!-- calculation 4 -->
            <hr>
            <!-- Settings box title -->
            <h3 class="hndle">
                <span>Hypotheekberekening 4</span>
            </h3>
            <div class="inside">
                <table class="form-table finaforte-label-tbl">
                    <tbody>
                        <tr>                                
                            <th scope="row">
                                <label for="calculation_4_rate">Interest rate:</label>
                            </th>
                            <td>                                            
                                <input type="number" step="0.01" name="finaforte_options[calculation_4_rate]" id="calculation_4_rate" value="<?php echo finaforte_esc_attr(finaforte_get_option('calculation_4_rate')); ?>"/>%<br/>
                                <span class="description">Maximum mortgage calculation interest rate</span>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="calculation_4_y">Year:</label>
                            </th>
                            <td>                                
                                <input type="number" step="0.01" name="finaforte_options[calculation_4_y]" id="calculation_4_y" value="<?php echo finaforte_esc_attr(finaforte_get_option('calculation_4_y')); ?>"/><br/>
                                <span class="description">Maximum mortgage calculation year</span>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="belastingteruggave_4">Belastingteruggave:</label>
                            </th>
                            <td>                                
                                <input type="number" step="0.01" name="finaforte_options[belastingteruggave_4]" id="belastingteruggave_4" value="<?php echo finaforte_esc_attr(finaforte_get_option('belastingteruggave_4')); ?>"/>%<br/>
                                <span class="description">Enter per of belastingteruggave </span>
                            </td>
                        </tr>
                        <tr>                                        
                            <th></th>
                            <td colspan="2" valign="top" scope="row">
                                <input type="submit" id="bwswpos-settings-submit" name="bwswpos-settings-submit" class="button button-primary right" value="<?php _e('Save Changes', 'finaforte'); ?>" />
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    
</div> <!-- end tab content -->

</form>

</div>
<script type="text/javascript">

    jQuery(document).ready(function($) {
        
        $('#tab-content2').hide();
        $('#tab-content3').hide();
        $('#tab-content4').hide();

        $( document ).on( 'click', '.tabs .tab-label', function() {
            var lable = $(this).attr('ID'); 
            if(lable == 'tab1'){
                $('#tab-content2').hide();
                $('#tab-content3').hide();
                $('#tab-content4').hide();
                $('#tab-content1').show();  }
            if(lable == 'tab2') {
                $('#tab-content1').hide();
                $('#tab-content3').hide();
                $('#tab-content4').hide(); 
                $('#tab-content2').show();  }
            if(lable == 'tab3'){ 
                $('#tab-content2').hide();
                $('#tab-content1').hide();
                $('#tab-content4').hide();
                $('#tab-content3').show();  }
            if(lable == 'tab4'){
                $('#tab-content2').hide();
                $('#tab-content1').hide();
                $('#tab-content3').hide();
                $('#tab-content4').show(); }
        });
    });
</script>
<?php 
/**
 * Email form content
 *
 * @package Finaforte
 * @since 1.0
 */

global $post;

require_once "admin-options.php";

$h_totalincome = $_SESSION['finaforte']['totalincome'] ? $_SESSION['finaforte']['totalincome'] : '0';
$h_totalincomep = $_SESSION['finaforte']['totalincomep'] ? $_SESSION['finaforte']['totalincomep'] : '0';
$total_icome_sum = $h_totalincome + $h_totalincomep;

?>
<style type="text/css">
    #form_email span{color: <?php echo $subtitle_color;?> !important; }
    .brd-cover-div { border: 1px solid <?php echo $txt_border_color; ?>; }
    .btn-primary {box-shadow: none;}
    #send_email_form h2.big-heading {line-height: <?php echo $title_font_size + 4; ?>px;}

    #send_email_form .start-box-form h3.big-heading, #send_email_form .sidebar-item h2.big-heading, #send_email_form .sidebar-item h3, #send_email_form .sidebar-item h4, .right-desc a {line-height: <?php echo $subtitle_font_size + 4; ?>px;}

    #send_email_form .form-group label {line-height: <?php echo $gentext_font_size + 4; ?>px;}

    #send_email_form .start-box-form p {line-height: <?php echo $text_font_size + 4; ?>px;}
</style>
<div class="start-page" id="send_email_form" data-pid=<?php echo get_queried_object_id(); ?>>
        <div class="container">
            <h1 style="font-size: <?php echo $title_font_size; ?>px; line-height: <?php echo $title_font_size + 4; ?>px; color: <?php echo $title_color; ?> ;"><?php echo finaforte_esc_attr(finaforte_get_option('email_form_heading'));  ?></h1>
            <div class="start-data">
                <div class="row">                   
                    <div class="col-sm-12 col-md-12 col-lg-8 stat-left">

                        <div class="start-box start-box-form brd-cover-div" style="background: <?php echo $backgroundcolor; ?>">
                            <div class="total-desc">
                                <h2 class="big-heading" style="font-size: <?php echo $subtitle_font_size; ?>px !important; line-height: <?php echo $subtitle_font_size + 4; ?>px; color: <?php echo $subtitle_color;?> !important;"><?php echo finaforte_esc_attr(finaforte_get_option('email_free_advice_label')); ?></h2>
                                <p style="font-size: <?php echo $text_font_size; ?>px !important; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color;?> !important;"><?php echo finaforte_esc_attr(finaforte_get_option('email_free_advice_text')); ?></p>

                                <form name="form_email" id="form_email">
                                    <div class="form-group row">
                                        <label for="naam" class="col-sm-2 col-form-label" style="font-size: <?php echo $gentext_font_size; ?>px !important; color: <?php echo$gentext_color; ?> !important;">Naam</label>
                                        <div class="col-sm-10">
                                            <input type="text" required class="form-control" style="border-radius: <?php echo $border_radius; ?>px !important; border-color: <?php echo  $txt_border_color; ?> !important;" id="txt_name" name="txt_name" placeholder="Naam" maxlength="255" value="<?= $_SESSION['finaforte']['name'] ?>">
                                        </div>
                                    </div>
                                    
                                    <div class="form-group row">
                                        <label for="email" class="col-sm-2 col-form-label" style="font-size: <?php echo $gentext_font_size; ?>px !important; color: <?php echo$gentext_color; ?> !important;">E-mail</label>
                                        <div class="col-sm-10">
                                            <input type="email" required class="form-control" style="border-radius: <?php echo $border_radius; ?>px !important; border-color: <?php echo  $txt_border_color; ?> !important;" id="txt_email" name="txt_email" placeholder="E-mail" maxlength="255" value="<?= $_SESSION['finaforte']['email'] ?>">
                                        </div>
                                    </div>
                                    
                                    <button type="button" class="btn btn-primary btn-yellow" style="margin-top:5px !important; color: <?php echo $btn_text_color; ?> !important; background: <?php echo $btn_bg_color; ?> !important; border-radius:<?php echo $border_radius;?>px !important; border-color: <?php echo $btn_border_color; ?> !important;" onclick="validate_and_send_email()"><?php echo finaforte_esc_attr(finaforte_get_option('email_button_text')); ?></button>
                                </form> 
                                </div>
                        </div>
                    </div>  
                    <div class="col-sm-12 col-md-12 col-lg-4 start-right">                      
                        <div class="sidebar-item">
                            <div class="make-me-sticky">
                                <div class="brd-cover-div">
                                     <button class="btn close-sidebar"><i class="fa fa-chevron-down" aria-hidden="true"></i></button>
                                
                                <div class="start-box plr15" style="background: <?php echo $backgroundcolor; ?>">
                                    <h2 class="big-heading text-center" style="font-size: <?php echo $subtitle_font_size; ?>px !important; color: <?php echo $subtitle_color; ?> !important; ">Overzicht</h2>
                                </div>
                                <div class="start-box" style="background:<?php echo $backgroundcolor; ?>">
                                   
                                    <div class="final-value">
                                        <?php 

                                        $maximale_hypotheek = ($_SESSION['finaforte']['maximale_hypotheek'] > 0) ? number_format($_SESSION['finaforte']['maximale_hypotheek'], 0, ',' , '.') : '';
                                        $maximale_hypotheek_disp = !empty($maximale_hypotheek) ? $maximale_hypotheek : '0,00';

                                        $total_icome_sum_disp = $total_icome_sum ? number_format($total_icome_sum, 0, ',' , '.') : '0,00';

                                        $maandlasten = ($_SESSION['finaforte']['maandlasten'] > 0) ? number_format($_SESSION['finaforte']['maandlasten'], 0, ',' , '.') : '';
                                        $maandlasten_disp = !empty($maandlasten) ? $maandlasten : '0,00';

                                        $mortgage_interest_disp = $mortgage_interest ? number_format($mortgage_interest, 2, ',' , '.') : '0,00';

                                        ?>
                                        <ul>
                                            <li>
                                                <h3 style="font-size: <?php echo $subtitle_font_size; ?>px; color: <?php echo $subtitle_color; ?> !important;">Uw totale toetsinkomen</h3>
                                                <h4 style="font-size: <?php echo $subtitle_font_size; ?>px; color: <?php echo $subtitle_color; ?> !important;"><strong style="color:<?php echo $subtitle_color; ?>; font-size: <?php echo $subtitle_font_size; ?>px;">€</strong> <span><?php echo $total_icome_sum_disp; ?></span></h4>
                                            </li>
                                            <li>
                                                <h3 style="font-size: <?php echo $subtitle_font_size; ?>px !important; color: <?php echo $subtitle_color; ?> !important;">Maximale hypotheek</h3>
                                                <h4 style="font-size: <?php echo $subtitle_font_size; ?>px; color: <?php echo $subtitle_color; ?> !important;"><strong style="color:<?php echo $subtitle_color; ?>; font-size: <?php echo $subtitle_font_size; ?>px;">€</strong> <span><?php echo  $maximale_hypotheek_disp; ?></span></h4>
                                            </li>
                                            <li>
                                                <h3 style="font-size: <?php echo $subtitle_font_size; ?>px; color: <?php echo $subtitle_color; ?> !important;">Maandlasten</h3>
                                                <h4 style="font-size: <?php echo $subtitle_font_size; ?>px; color: <?php echo $subtitle_color; ?> !important;"><strong style="color:<?php echo $subtitle_color; ?>; font-size: <?php echo $subtitle_font_size; ?>px;">€</strong> <span><?php echo $maandlasten_disp; ?></span></h4>
                                            </li>
                                        </ul>
                                    </div>
                                                                        
                                    <h4 class="toetsrente-txt">                                     
                                        <span class="right-span" style="color:<?php echo $text_color; ?> "> Op basis van <?php echo $mortgage_interest_disp; ?>% toetsrente</span>                                       
                                        <a style="color: <?php echo $text_color; ?> " href="javascript:;" title="" data-placement="bottom" data-toggle="popover" data-content="<?php echo $tooltip_mortgage_interest; ?>" data-original-title="" aria-describedby="popover52623"><i class="fa fa-info-circle" aria-hidden="true"></i></a> </h4>   
                                    
                                   
                                    <a href="javascript:;" class="btn btn-primary btn-yellow" onclick="total_calculation2()" style="color: <?php echo $btn_text_color; ?> !important; background: <?php echo $btn_bg_color; ?> !important; border-radius:<?php echo $border_radius;?>px !important; border-color: <?php echo $btn_border_color; ?> !important;" ><?php echo finaforte_get_option('view_cal_button_text') ?></a>
                                </div>
                               
                                </div>   
                                 <div class="right-desc">
                                    <div class="user-images-call">
                                        <h3 class="big-sub-heading" style="font-size: <?php echo $subtitle_font_size; ?>px !important; color: <?php echo $call_sec_txt_color; ?> !important;">Wil je advies of heb je vragen?</h3>   
                                        <div class="user-desc">
                                            <h4 class="big-sub-heading" style="font-size: <?php echo $text_font_size; ?>px !important; color: <?php echo $call_sec_txt_color;?> !important; line-height: <?php echo $text_font_size+4; ?>px;">Bel met een van onze adviseurs</h4>
                                            <p><span><a style="font-size: <?php echo $subtitle_font_size; ?>px !important; color: <?php echo $call_sec_txt_color; ?> !important;" href="tel:<?php echo $advice_contact; ?>"><?php echo $advice_contact; ?></a></span></p>
                                        </div>
                                        <?php if(!empty($advicer_photo)) { ?>
                                        <div class="user-image">
                                            <img src="<?php echo $advicer_photo; ?>" alt="Advicer" title="Advicer">
                                        </div> 
                                        <?php } ?>
                                    </div>                      
                                </div>                            
                            </div>
                        </div>
                    </div> <!-- col 4 -->  
                </div>
            </div>
            <?php $maximale_hypotheek = ($_SESSION['finaforte']['maximale_hypotheek'] > 0) ? number_format($_SESSION['finaforte']['maximale_hypotheek'], 0, ',' , '.') : '';
            if(!empty($maximale_hypotheek)){
                $hypotheek_content = 'Mximale hypotheek €'.$maximale_hypotheek;             
            } 
            ?>
            <button class="btn btn-primary btn-yellow sidebar-hide-show" style="border-top-left-radius: <?php echo $border_radius;?>px; border-top-right-radius: <?php echo $border_radius;?>px; color: <?php echo $btn_text_color; ?>; background: <?php echo $btn_bg_color; ?>;"><?php echo $popup_button_text; ?> <br><span id="max_hypotheek_btn"><?php echo $hypotheek_content; ?></span><div class="fa fa-chevron-up btm-arrow" aria-hidden="true"></div></button>
        </div>
    </div>

 <input type="hidden" name="Show_cal_1" id="Show_cal_1" value='<?php echo $_SESSION['finaforte']['Show_cal_1']; ?>'>
    <input type="hidden" name="Show_cal_2" id="Show_cal_2" value='<?php echo $_SESSION['finaforte']['Show_cal_2']; ?>''>
    <input type="hidden" name="Show_cal_3" id="Show_cal_3" value="<?php echo $_SESSION['finaforte']['Show_cal_3']; ?>">
    <input type="hidden" name="Show_cal_4" id="Show_cal_4" value="<?php echo $_SESSION['finaforte']['Show_cal_4']; ?>">
    <input type="hidden" name="h_totalincome" id="h_totalincome" value="<?php echo $_SESSION['finaforte']['h_totalincome']; ?>">
    <input type="hidden" name="h_totalincomep" id="h_totalincomep" value="<?php echo $_SESSION['finaforte']['h_totalincomep']; ?>">
    <input type="hidden" name="h_max_hypotheek" id="h_max_hypotheek" value="<?php echo $_SESSION['finaforte']['maximale_hypotheek']; ?>">
    <input type="hidden" name="h_maandlasten" id="h_maandlasten" value="<?php echo $_SESSION['finaforte']['maandlasten']; ?>">
    <input type="hidden" name="h_totalincome_sum" id="h_totalincome_sum" value="<?php echo $total_icome_sum_disp; ?>">
   
    <input type="hidden" name="maximale_hypotheek_1" id="maximale_hypotheek_1" value="<?php echo $_SESSION['finaforte']['maximale_hypotheek_1']; ?>">
    <input type="hidden" name="hypo_ber_rent_1" id="hypo_ber_rent_1" value="<?php echo $_SESSION['finaforte']['hypo_ber_rent_1']; ?>">
    <input type="hidden" name="aflossing_1" id="aflossing_1" value="<?php echo $_SESSION['finaforte']['aflossing_1']; ?>">
    <input type="hidden" name="bruto_maandlast" id="bruto_maandlast" value="<?php echo $_SESSION['finaforte']['bruto_maandlast']; ?>">
    <input type="hidden" name="maandlasten2" id="maandlasten2" value="<?php echo $_SESSION['finaforte']['maandlasten2']; ?>">
    <input type="hidden" name="maandlasten3" id="maandlasten3" value="<?php echo $_SESSION['finaforte']['maandlasten3']; ?>">
    <input type="hidden" name="maandlasten4" id="maandlasten4" value="<?php echo $_SESSION['finaforte']['maandlasten4']; ?>">
    <input type="hidden" name="belastingteruggave_1" id="belastingteruggave_1" value="<?php echo $_SESSION['finaforte']['belastingteruggave_1']; ?>">
    <input type="hidden" name="netto_per_maand_1" id="netto_per_maand_1" value="<?php echo $_SESSION['finaforte']['netto_per_maand_1']; ?>">
    <input type="hidden" name="maximale_hypotheek_2" id="maximale_hypotheek_2" value="<?php echo $_SESSION['finaforte']['maximale_hypotheek_2']; ?>">
    <input type="hidden" name="hypo_ber_rent_2" id="hypo_ber_rent_2" value="<?php echo $_SESSION['finaforte']['hypo_ber_rent_2']; ?>">
    <input type="hidden" name="aflossing_2" id="aflossing_2" value="<?php echo $_SESSION['finaforte']['aflossing_2']; ?>">
    <input type="hidden" name="belastingteruggave_2" id="belastingteruggave_2" value="<?php echo $_SESSION['finaforte']['belastingteruggave_2']; ?>">
    <input type="hidden" name="netto_per_maand_2" id="netto_per_maand_2" value="<?php echo $_SESSION['finaforte']['netto_per_maand_2']; ?>">
    <input type="hidden" name="maximale_hypotheek_3" id="maximale_hypotheek_3" value="<?php echo $_SESSION['finaforte']['maximale_hypotheek_3']; ?>">
    <input type="hidden" name="hypo_ber_rent_3" id="hypo_ber_rent_3" value="<?php echo $_SESSION['finaforte']['hypo_ber_rent_3']; ?>">
    <input type="hidden" name="aflossing_3" id="aflossing_3" value="<?php echo $_SESSION['finaforte']['aflossing_3']; ?>">
    <input type="hidden" name="belastingteruggave_3" id="belastingteruggave_3" value="<?php echo $_SESSION['finaforte']['belastingteruggave_3']; ?>">
    <input type="hidden" name="netto_per_maand_3" id="netto_per_maand_3" value="<?php echo $_SESSION['finaforte']['netto_per_maand_3']; ?>">
    <input type="hidden" name="maximale_hypotheek_4" id="maximale_hypotheek_4" value="<?php echo $_SESSION['finaforte']['maximale_hypotheek_4']; ?>">
    <input type="hidden" name="hypo_ber_rent_4" id="hypo_ber_rent_4" value="<?php echo $_SESSION['finaforte']['hypo_ber_rent_4']; ?>">
    <input type="hidden" name="aflossing_4" id="aflossing_4" value="<?php echo $_SESSION['finaforte']['aflossing_4']; ?>">
    <input type="hidden" name="belastingteruggave_4" id="belastingteruggave_4" value="<?php echo $_SESSION['finaforte']['belastingteruggave_4']; ?>">
    <input type="hidden" name="netto_per_maand_4" id="netto_per_maand_4" value="<?php echo $_SESSION['finaforte']['netto_per_maand_4']; ?>">

    <input type="hidden" name="redir_url" id="redir_url" value="<?php echo get_page_link(get_the_ID()); ?>">

  <script type="text/javascript">
       
        jQuery(document).ready(function($){
            $(".sidebar-hide-show").click(function () {
                $(".start-right").show();
                $("body").addClass("static-sidebar");
            });
            $(".close-sidebar").click(function () {
                $(".start-right").hide();
                $("body").removeClass("static-sidebar");
            });
        });
        function total_calculation2() {
           var pid = jQuery("#send_email_form").attr('data-pid');
            jQuery.ajax({
                type: "POST",
                url: "<?php echo admin_url('admin-ajax.php'); ?>",
                pid: pid,
                data: 'action=view_total_calculation2',
                success: function (response) { 
                    console.log(response);       
                    response = jQuery.parseJSON(response);                
                    if(response.success == true) {
                        location.reload(); 
                    } 
                    return false;
                }
            });
        }
        function validate_and_send_email() {
            
            var txt_email = jQuery('#txt_email').val();          
            var txt_name = jQuery('#txt_name').val();
           
           jQuery("#form_email #txt_name, #form_email #txt_email").parent().find("span").remove(); 
            
            
            jQuery("#txt_name, #txt_email").on('keyup keypress click', function(e) {
                jQuery("#form_email #txt_name, #form_email #txt_email").parent().find("span").remove();    
            });

            if(txt_name == '') {
               
                jQuery("#form_email #txt_name").addClass("error");
                jQuery("#form_email #txt_name").parent().append("<span style='color:red;'>*This field is mandatory!</span>");
                return false;
            }
            if(txt_email == ''){
                jQuery("#form_email #txt_email").addClass("error");
                jQuery("#form_email #txt_email").parent().append("<span style='color:red;'>*This field is mandatory!</span>");
                return false;
            }

            var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
              if(!regex.test(txt_email)) {
                jQuery("#form_email #txt_email").addClass("error");
                jQuery("#form_email #txt_email").parent().append("<span>Please enter valid email address!</span>");
                return false;
              }
            
          
            /*total cal*/
            var h_totalincome = jQuery("#h_totalincome").val(); /* without partner*/
            var h_totalincomep = jQuery("#h_totalincomep").val();
            var h_max_hypotheek = jQuery("#h_max_hypotheek").val();
            var h_maandlasten = jQuery("#h_maandlasten").val();
            var h_totalincome_sum = jQuery("#h_totalincome_sum").val(); /* with partner*/
            /*show cal*/
            var Show_cal_1 = jQuery("#Show_cal_1").val(); 
            var Show_cal_2 = jQuery("#Show_cal_2").val(); 
            var Show_cal_3 = jQuery("#Show_cal_3").val(); 
            var Show_cal_4 = jQuery("#Show_cal_4").val(); 
            /*cal 1*/
            var maximale_hypotheek_1 = jQuery("#maximale_hypotheek_1").val();
            var hypo_ber_rent_1 = jQuery("#hypo_ber_rent_1").val();
            var aflossing_1 = jQuery("#aflossing_1").val();
            var bruto_maandlast = jQuery("#bruto_maandlast").val();
            var belastingteruggave_1 = jQuery("#belastingteruggave_1").val();
            var netto_per_maand_1 = jQuery("#netto_per_maand_1").val();
            /*cal 2*/
            var maximale_hypotheek_2 = jQuery("#maximale_hypotheek_2").val();
            var hypo_ber_rent_2 = jQuery("#hypo_ber_rent_2").val();
            var maandlasten2 = jQuery("#maandlasten2").val();
            var aflossing_2 = jQuery("#aflossing_2").val();
            var belastingteruggave_2 = jQuery("#belastingteruggave_2").val();
            var netto_per_maand_2 = jQuery("#netto_per_maand_2").val();
            /*cal 3*/
            var maximale_hypotheek_3 = jQuery("#maximale_hypotheek_3").val();
            var hypo_ber_rent_3 = jQuery("#hypo_ber_rent_3").val();
            var maandlasten3 = jQuery("#maandlasten3").val();
            var aflossing_3 = jQuery("#aflossing_3").val();
            var belastingteruggave_3 = jQuery("#belastingteruggave_3").val();
            var netto_per_maand_3 = jQuery("#netto_per_maand_3").val();
            /*cal 4*/
            var maximale_hypotheek_4 = jQuery("#maximale_hypotheek_4").val();
            var hypo_ber_rent_4 = jQuery("#hypo_ber_rent_4").val();
            var maandlasten4 = jQuery("#maandlasten4").val();
            var aflossing_4 = jQuery("#aflossing_4").val();
            var belastingteruggave_4 = jQuery("#belastingteruggave_4").val();
            var netto_per_maand_4 = jQuery("#netto_per_maand_4").val();
            var redir_url = jQuery("#redir_url").val();
            var pid = jQuery("#send_email_form").val();

            jQuery("#form_email .error").each(function () {
                jQuery(this).removeClass("error");
            });
           
           jQuery.ajax({
                type: "POST",
                url: "<?php echo admin_url('admin-ajax.php'); ?>",
                pid:pid,
                data: 'action=send_email&h_totalincome=' + h_totalincome + '&h_totalincomep=' + h_totalincomep + '&h_max_hypotheek=' + h_max_hypotheek + '&h_maandlasten=' + h_maandlasten + '&h_totalincome_sum=' + h_totalincome_sum + '&maximale_hypotheek_1=' +maximale_hypotheek_1  + '&bruto_maandlast=' +bruto_maandlast + '&hypo_ber_rent_1=' +hypo_ber_rent_1 + '&aflossing_1=' +aflossing_1 + '&bruto_maandlast=' +bruto_maandlast + '&belastingteruggave_1=' +belastingteruggave_1 + '&netto_per_maand_1=' +netto_per_maand_1 + '&maximale_hypotheek_2=' +maximale_hypotheek_2 + '&maandlasten2=' + maandlasten2 + '&hypo_ber_rent_2=' +hypo_ber_rent_2 + '&aflossing_2=' +aflossing_2 + '&belastingteruggave_2=' +belastingteruggave_2 + '&netto_per_maand_2=' + netto_per_maand_2+ '&maximale_hypotheek_3=' + maximale_hypotheek_3 + '&maandlasten3=' + maandlasten3 + '&hypo_ber_rent_3=' +hypo_ber_rent_3 + '&aflossing_3=' +aflossing_3 + '&belastingteruggave_3=' +belastingteruggave_3 + '&netto_per_maand_3=' +netto_per_maand_3 + '&maximale_hypotheek_4=' +maximale_hypotheek_4 + '&maandlasten4=' + maandlasten4 + '&hypo_ber_rent_4=' +hypo_ber_rent_4 + '&aflossing_4=' +aflossing_4 + '&belastingteruggave_4=' +belastingteruggave_4 + '&netto_per_maand_4=' +netto_per_maand_4 + '&Show_cal_1=' +Show_cal_1 + '&Show_cal_2=' +Show_cal_2 + '&Show_cal_3=' +Show_cal_3 + '&Show_cal_4=' +Show_cal_4 + '&txt_email=' +txt_email + '&txt_name=' + txt_name,

                    success: function (response) {     
                
                    console.log(response);    
                    
                    response = jQuery.parseJSON(response); 

                    jQuery('.ff_mail_err').hide();
                        jQuery('.ff_mail_succ').hide();
                      
                    if(response.success == true) {
                        
                        window.location.href = response.thankyou_page_url;
                    } else{  
                        
                        jQuery('#form_email').append('<div class="ff_mail_err" style="color:red;font-size: 16px !important;margin-top: 12px !important;text-align: center;"><span>Email has not sent, please try again.</span></div>');
                    }
                }
            });
            return false;
        }

</script>
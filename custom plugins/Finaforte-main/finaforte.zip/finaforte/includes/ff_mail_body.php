<?php
/**
 * Email form content
 *
 * @package Fina Forte
 * @since 1.0
 */
/* Exit if accessed directly */

$h_totalincome = $_POST['h_totalincome'] ? $_POST['h_totalincome'] : '0';
$h_totalincomep = $_POST['h_totalincomep'] ? $_POST['h_totalincomep'] : '0';
$h_totalincome_sum2 = $_POST['h_totalincome_sum'] ? $_POST['h_totalincome_sum'] : '0';
$footer_email_id = finaforte_get_option('footer_email_id');
require_once "admin-options.php";

$msg_body .= '<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html xmlns:fb="http://www.facebook.com/2008/fbml" xmlns:og="http://opengraph.org/schema/">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;" />
    <title>finafort Newslatter</title>
    <style type="text/css">
        body {
            width: 100%!important;
            -webkit-text-size-adjust: 100%;
            -ms-text-size-adjust: 100%;
            margin: 0;
            padding: 0;
        }        
        .ExternalClass {
            width: 100%;
        }        
        .ReadMsgBody {
            width: 100%;
            background-color: #ffffff;
        }        
        table {
            mso-table-lspace: 0pt;
            mso-table-rspace: 0pt;
        }        
        img {
            -ms-interpolation-mode: bicubic;
        }        
        span {
            font-size: 12px !important;
            line-height: 20px !important;
            color: #555;
        }        
        .fix_head {
            height: 60px !important;
        }        
        .fix_dec {
            height: 70px !important;
        }       
        @media only screen and (max-width: 680px) {
            table[class=content_wrap] {
                width: 99%!important;
            }
            .content_wrap table {
                width: 100%!important;
            }
            .table_box .main-table-data{padding: 0 !important}
            .table_box .main-table-data tbody{display: table;width: 100%;}
        }        
        @media only screen and (max-width: 680px) and (orientation:landscape) {
            .table_box_full {
                width: 46%;
            }
            .table_box_full+.table_box_full {
                width: 54%;
            }
        }        
        @media only screen and (max-width: 680px) and (orientation:portrait) {
            .table_box_full {
                width: 100%;
            }
            .table_box_full+.table_box_full {
                width: 100%;
            }
        }        
        @media only screen and (max-width: 680px) {
            table[class=full_width] {
                width: 100%!important;
            }
            .row {
                width: 100%!important;
                padding: 0 15px !important;
            }
            .td_col {
                border: none!important;
            }
        }        
        @media only screen and (max-width: 680px) {
            table[class=hide],
            img[class=hide],
            td[class=hide] {
                display: none !important;
            }
        }        
        @media only screen and (max-width: 680px) {
            td[class=text-center] {
                text-align: center!important;
            }
        }        
        @media only screen and (max-width: 680px) {
            a[class=button] {
                border-radius: 2px !important;
                -moz-border-radius: 2px !important;
                -webkit-border-radius: 2px !important;
                -khtml-border-radius: 2px !important;  // 
                -o-border-radius: 2px !important;      // Opera    
                -ms-border-radius: 2px !important;  
               
               
                padding: 5px !important;
                display: block;
                text-decoration: none;
                text-transform: uppercase;
                margin: 0 0 10px 0;
            }
        }        
        @media only screen and (max-width: 680px) {
            .edmImg-app {
                height: auto !important;
                max-width: 64px !important;
                width: 100% important;
                margin: auto;
                float: right;
            }
            .left {
                float: left;
            }
        }        
        @media only screen and (max-device-width: 680px) {
            body[yahoo] .table_box {
                padding: 0px 0 10px!important;
                margin-bottom: 0px !important;
                max-width: 270px !important;
            }
        }        
        @media only screen and (max-width: 680px) {
            .edmImg-sport {
                height: auto !important;
                max-width: 100px !important;
                width: 100% important;
            }
            .td_head {
                height: 45px!important;
            }
            .td_none {
                display: none !important;
            }
            .table_box {
                padding: 10px !important;
                vertical-align: top;
            }
            .table_box_full {
                padding: 0px !important;
                max-width: 270px !important;
            }
            .table_box td.td_head .box_Detail {
                height: 80px !important
            }
            .box_title_new {
                padding: 0px !important;
                height: auto !important
            }
        }        
        @media only screen and (max-width: 680px) {
            .edmImg {
                height: auto !important;
                max-width: 99% !important;
                width: 100% important;
                margin: auto !important;
                height: auto !important;
                max-width: 100% !important;
            }
            .big_tit {
                max-width: 100%!important
            }
            .title_box {
                padding-left: 15px !important;
            }
            .table_box .row {
                padding: 0 !important;
            }
            .edmImgbanner {
                max-width: 100% !important
            }
            .pad_top_mob {
                padding: 15px !important;
            }
            .table_box_bottom {
                padding: 20px !important;
            }
            .table_box_bottom.two {
                padding-left: 0px !important;
            }
            .fix_head {
                height: auto;
            }
            .btn-lg {
                padding: 10px 20px !important
            }
            .table_box {width: 95%!important;margin: 0px auto !important;display: block;padding: 0px 0 20px !important;text-align: center !important;}
            .small-font{text-align: center;}
        }        
        @media only screen and (max-width: 480px) {
            .td_none {
                display: none;
            }
            .table_box {
                width: 95%!important;
                margin: 0px auto !important;
                display: block;
                padding: 0px 0 20px !important;
                text-align: center !important;
            }
            .table_box td span {
                font-size: 14px !important;
            }
            .table_box .button-a {
                font-size: 14px !important;
            }
            .table_box_full td {
                text-align: center !important
            }

            .table_box {
                padding: 0px 0 20px!important;
                margin-bottom: 15px !important;
                max-width: 270px !important;
            }
            .header-table .table_box {
                padding: 0px 0 0px!important;
                margin-bottom: 0px !important;
                max-width: 270px !important;
            }
            .table_box td.td_head .box_Detail {
                height: auto !important;
                text-align: center;
            }
            .table_box_full {
                width: 100% !important;
                padding: 0px !important;
                margin: 0px auto!important;
                max-width: 270px !important;
            }
            .box_title_new {
                text-align: center;
            }
            .table_box td.box_title_new span {
                display: block !important;
                font-size: 16px !important
            }
            .text-button {
                text-align: center !important;
            }
            .table_box_full .edmImg {
                padding-top: 15px !important;
            }
            .table_box td span.box_title_bottom {
                font-size: 16px !important
            }
            .table_box td span.pro_head {
                font-size: 18px !important;
            }
            .table_box_bottom {
                width: 95% !important;
                margin-bottom: 15px !important;
                max-width: 270px !important;
                display: block;
                text-align: center;
                margin-left: auto !important;
                margin-right: auto !important;
                padding: 0px !important
            }
            .small-font{font-size: 16px !important;text-align: center;}           
        }        
        @media only screen and (max-width: 375px) {
            .img_title {
                max-width: 270px !important
            } 
        }        
        .td_none {
            border: none;
        }        
        #social-proxy {
            background: #fff;
            -webkit-box-shadow: 4px 4px 8px 2px rgba(0, 0, 0, .2);
            box-shadow: 4px 4px 8px 2px rgba(0, 0, 0, .2);
            padding-bottom: 35px !important;
            z-index: 1000;
        }        
        #social-proxy_close {
            display: block;
            position: absolute;
            top: 0;
            right: 0;
            height: 30px !important;
            width: 32px !important;
            background: transparent url(http://cdn-images.mailchimp.com/awesomebar-sprite.png) 0 -200px !important;
            text-indent: -9999px !important;
            outline: none;
            font-size: 1px !important;
        }        
        #social-proxy_close:hover {
            background-position: 0 -240px !important;
        } 
        @media only screen and (max-width: 590px) {
        .table-data{padding: 0 10px !important;}
            .main-table-data{padding: 0 10px !important}
            
            .main-table-data tr td {word-break: break-all !important; font-size: 12px !important;}
            .main-table-data tr td a {word-break: break-all !important; font-size: 12px !important;}
            .height20{height: 20px !important;}
        }
    </style>
</head>

<body yahoo="fix" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" style="-webkit-font-smoothing:antialiased;width:100% !important;background-color:#d3d3d3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;-webkit-text-size-adjust:none;">   
<table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#fff" style="font-family: Roboto, sans-serif;font-size:15px !important;line-height:20px !important;color:#555; background-color:#fff">        
    <tr>
        <td bgcolor="#f8f8f8" width="100%">
            <table width="700" cellpadding="0" cellspacing="0" border="0" align="center" class="content_wrap" style="margin:0 auto;background:#fff;">
                <tbody>
                    <tr>
                        <td style="width:100%;" bgcolor="#FFFFFF">
                            <table style="border-collapse:collapse; border:none; margin:0 auto;    width: 100%;"  cellspacing="0" cellpadding="0" bordercolor="#FFFFFF" border="0" align="center">
                                <tbody>
                                        
                                    <tr class="header-table" style=" border-width:1px !important; border-style:solid; border-color:#ffffff;">
                                        <td class="table_box" width="35%" style="background:#fff;padding-left: 30px !important;">
                                                <table style="border-collapse:collapse;border:none; margin:0 auto;" width="100%" cellspacing="0" cellpadding="0" bordercolor="#FFFFFF" border="0">
                                            <tbody>                          
                                            <tr>
                                            <td width="100%">
                                            <img src="'.$email_logo.'" alt="finafort" style="-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%;max-width:100%;-ms-interpolation-mode:bicubic;margin:auto" class="edmImg">
                                        </td>
                                    </tr>         
                                                                                                             
                                    </tbody>
                                </table>
                            </td>
                            <td class="table_box" width="65%" style="background:#fff;padding-right: 30px !important;">

                            <table style="border-collapse:collapse;border:none; margin:0 auto;" width="100%" cellspacing="0" cellpadding="0" bordercolor="#FFFFFF" border="0" align="right">
                                <tbody>
                                <tr>
                                    <td align="right" class="small-font" style="font-family: Roboto, sans-serif;font-size:24px !important;color:#393939; line-height:30px !important;font-weight: bold; word-break: keep-all;">Hypotheken voor ondernemers</td>
                                </tr>  
                                <tr>
                                    <td align="right" class="small-font" style="font-family: Roboto, sans-serif;font-size:16px !important;color:#393939; line-height:24px !important;font-weight: bold; word-break: keep-all;">'.date("d/m/Y").'</td>
                                </tr>               
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td  height="30" class="td_none">&nbsp;</td>      
                </tr>
              </tbody>
            </table>
        </td>
    </tr>
    <tr>
        <td width="100%">
            <table width="100%" cellpadding="0" cellspacing="0" border="0" align="center" style="background:#ededed; margin:0 auto;" class="row">
                <tbody>
                    <tr>
                        <td width="100%">
                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tbody>
                                                       
                                <tr> 
                                <td class="no-padding" width="100%"  style="font-family: Roboto, sans-serif;font-size:16px !important;color:'.$email_topname_clr.'; line-height:30px !important;padding: 20px 30px !important;word-break: keep-all;">'.$txt_name.' </td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                    </tbody>
                </table>                               
            </td>
        </tr>
        <tr>
            <td width="100%">
                <table width="100%" cellpadding="0" cellspacing="0" border="0" align="center" style="background:#fff; margin:0 auto;" class="row">
                    <tbody>
                    <tr>
                        <td width="100%">
                           <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tbody>
                                <tr>                                            
                                    <td width="100%" height="20" class="">&nbsp;</td>               
                                </tr>
                                <tr>                          
                                <td class="no-padding" style="word-break: normal;white-space:normal;padding-left: 30px !important;padding-right:30px !important;font-family: Roboto, sans-serif;font-size:24px !important;color:#393939; line-height:50px !important;font-weight: bold; word-break: keep-all;display:block">'.$email_title. ' /td>
                                </tr>
                                <tr>
                                    <td class="no-padding" style="word-break: normal;white-space:normal;padding-left: 30px !important;padding-right:30px !important;font-family: Roboto, sans-serif;font-size:16px !important;color:#393939; line-height:24px !important; word-break: keep-all;display:block">'.$email_description.'  </td>                                  
                                </tr>
                                <tr>                                            
                                <td width="100%" height="30" class="">&nbsp;</td>
                                </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>                              
           </td>
        </tr>
        <tr>
            <td style="border-top:1px solid #ededed;padding-left: 30px !important;padding-right:30px !important;margin:0 auto;" width="640">
                <table style="border-collapse:collapse; border:none; margin:0 auto;" width="640" cellspacing="0" cellpadding="0"  border="0" align="center">
                    <tbody>
                        <tr>
                            <td width="640" height="15" class="full-width">&nbsp;</td>                
                        </tr>
                        <tr>
                            <td class="table_box" width="30%" >
                                <table style="border-collapse:collapse;border:none; margin:0 auto;" width="100%" cellspacing="0" cellpadding="0" bordercolor="#FFFFFF" border="0" align="center">
                                    <tbody>                                        
                                    <tr>
                                        <td align="center" style="word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#393939; line-height:30px !important;font-weight: bold; word-break: keep-all;display:block">Uw totale toetsinkomen </td>
                                    </tr> 
                                    <tr>
                                        <td align="center" style="word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:20px !important;color:#393939; line-height:30px !important;font-weight: bold; word-break: keep-all;display:block">€ '. $h_totalincome_sum2.' </td>
                                    </tr>                               
                                    </tbody>
                                </table>
                            </td>
                            <td class="table_box" width="36%">
                                
                                <table style="border-collapse:collapse;border:none; margin:0 auto;" width="100%" cellspacing="0" cellpadding="0" bordercolor="#FFFFFF" border="0" align="center">
                                    <tbody>                                        
                                    <tr>
                                        <td align="center" style="word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:21px !important;color:#393939; line-height:30px !important;font-weight: bold; word-break: keep-all;display:block">Maximale hypotheek </td>
                                    </tr>
                                    <tr>
                                        <td align="center" style="word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:20px !important; color:#393939; line-height:30px !important;font-weight: bold; word-break: keep-all;display:block">€ '.number_format($h_max_hypotheek, 0, ',' , '.').' </td>
                                    </tr>                                            
                                    </tbody>
                                </table>
                            </td>
                            <td class="table_box" width="33%">
                                <table style="border-collapse:collapse;border:none; margin:0 auto;" width="100%" cellspacing="0" cellpadding="0" bordercolor="#FFFFFF" border="0" align="center">
                                    <tbody>                                        
                                    <tr>
                                        <td align="center" style="word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#393939; line-height:30px !important;font-weight: bold; word-break: keep-all;display:block">Maandlasten max. hypotheek </td>
                                    </tr>                                
                                    <tr>
                                        <td align="center" style="word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:20px !important;color:#393939; line-height:30px !important;font-weight: bold; word-break: keep-all;display:block">€ '.number_format($h_maandlasten, 0, ',' , '.').'</td>
                                    </tr>                                                        
                                                </tbody>
                                            </table>
                                        </td> 
                                    </tr>
                                    <tr>
                                        <td width="640" height="15" class="td_none">&nbsp;</td>                                         
                                    </tr>                                        
                                </tbody>
                            </table>
                        </td>
                    </tr>
                        
                        <tr>
                            <td bgcolor="' . $email_cal_bgclr . '" width="640" style="padding-left: 30px !important;padding-right:30px !important;margin:0 auto;">
                                <table class="box_table" style="border-collapse:collapse; border:none; margin:0 auto;"  width="640" cellspacing="0" cellpadding="0"  border="0"  align="center">
                                    <tbody>
                                        <tr>
                                            <td width="640" height="30" class="full-width">&nbsp;</td>                                                 
                                        </tr>
                                        <tr>';

                                           if($Show_cal_1 == 1) { 
                                        $msg_body .= '<td class="table_box" width="48%">
                                                <table bgcolor="' . $email_cal_bgclr . '" class="main-table-data " width="307"  border="0" cellspacing="0" cellpadding="0" style="background:' . $email_cal_bgclr . ';margin:0 auto;border: 0px solid ' . $email_cal_borderclr . ';border-collapse:separate;display: table;overflow: hidden;border-radius: 20px !important; ">
                                                    <tbody>                                                
                                                        <tr style="border-collapse: collapse;border: 0px solid transparent;">                                                            
                                                            <td width="307" style="border: 1px solid ' . $email_cal_borderclr . ';overflow: hidden;border-radius: 20px !important;" >
                                                                <table bgcolor="' . $email_cal_bgclr . '" class="main-table-data" width="100%" align="center" border="0" cellspacing="0" cellpadding="0" style="background:' . $email_cal_bgclr . ';margin:0 auto;border:0px solid #259599;border-collapse:separate;display: block;width:100%; ">
                                                                    <tbody>
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td colspan="2" height="10" style="border:0px solid transparent;"></td>
                                                                            <td width="10"></td>
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td colspan="2" style="border:0px solid transparent; word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:16px !important;color:#fff; font-weight: bold; word-break: keep-all;">Hypotheekberekening 1 </td>
                                                                            <td width="10"></td>
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td colspan="2" width="277" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff; font-weight: bold; word-break: keep-all;"></td>
                                                                            <td width="10"></td>
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td height="25" width="55%" align="left" style="border:0px solid transparent;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;">Maximale hypotheek</td>
                                                                            <td height="25" width="36%" align="right" style="border:0px solid transparent;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;">€ '. number_format($maximale_hypotheek_1, 0, ',' , '.').' </td>
                                                                            <td width="10"></td>
                                                                                       
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td height="25" width="55%" align="left" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff; word-break: keep-all;">Rente (toetsrente '.$calculation_1_rate.'%)</td>
                                                                            <td height="25" width="36%" align="right" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;  word-break: keep-all;">€ '.number_format($hypo_ber_rent_1, 0, ',' , '.').' </td>
                                                                            <td width="10"></td>
                                                                                                                                      
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td height="25" width="55%" align="left" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff; word-break: keep-all;">Aflossing</td>
                                                                            <td height="25" width="36%" align="right" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;  word-break: keep-all;">€ '.number_format($aflossing_1, 0, ',' , '.').'</td>
                                                                            <td width="10"></td>
                                                                                                                                       
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td height="25" width="55%" align="left" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff; word-break: keep-all;">Bruto maandlast</td>
                                                                            <td height="25" width="36%" align="right" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;  word-break: keep-all;">€ '.number_format($bruto_maandlast, 0, ',' , '.').' </td>
                                                                            <td width="10"></td>
                                                                                                                                         
                                                                        </tr>   
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td height="25" width="55%" align="left" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff; word-break: keep-all;">Belastingteruggave</td>
                                                                            <td height="25" width="36%" align="right" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;  word-break: keep-all;">€ '.number_format($belastingteruggave_1, 0, ',' , '.').' </td>
                                                                            <td width="10"></td>
                                                                                        
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td height="25" width="55%" align="left" style="border-top: 1px solid ' . $email_cal_borderclr . '; border-bottom:0px solid transparent;border-left:0px solid transparent;border-right:0px solid transparent;border-collapse: separate;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff; word-break: keep-all;">Netto per maand</td>
                                                                            <td height="25" width="36%" align="right" style="border-top: 1px solid ' . $email_cal_borderclr . ';border-left:0px solid transparent;border-right:0px solid transparent; border-collapse: separate;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;  word-break: keep-all;"> € '.number_format($netto_per_maand_1, 0, ',' , '.').' </td>   
                                                                            <td width="10"></td>                                                                                                                                    
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td colspan="2" height="10" style="border:0px solid transparent; word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:17px !important;color:#fff; font-weight: bold; word-break: keep-all;"></td>
                                                                            <td width="10"></td>
                                                                        </tr>                                                                        
                                                                    </tbody>
                                                                </table>
                                                            </td>                                                           
                                                        </tr>                                                        
                                                    </tbody>
                                                </table>                                               
                                            </td>';                                              
                                                                                    
                                            } 
                                            if($Show_cal_2 == 1) {
                                            $msg_body .= '<td  width="4%" class="td_none"></td>

                                            <td class="table_box" width="48%">
                                                <table bgcolor="' . $email_cal_bgclr . '" class="main-table-data" width="307"  border="0" cellspacing="0" cellpadding="0" style="background:' . $email_cal_bgclr . ';margin:0 auto;border: 0px solid ' . $email_cal_borderclr . ';border-collapse:separate;display: table;overflow: hidden;border-radius: 20px ">
                                                    <tbody>                                                                                                                                                                        
                                                        <tr style="border-collapse: collapse;border: 0px solid transparent;">                                                            
                                                            <td width="307" style="border: 1px solid ' . $email_cal_borderclr . ';overflow: hidden;border-radius: 20px">
                                                                <table bgcolor="' . $email_cal_bgclr . '" class="main-table-data" width="100%" align="center" border="0" cellspacing="0" cellpadding="0" style="background:' . $email_cal_bgclr . ';margin:0 auto;border:0px solid #259599;border-collapse:separate;display: block;width:100%; ">
                                                                    <tbody>
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td colspan="2" height="10" style="border:0px solid transparent;"></td>
                                                                            <td width="10"></td>
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td colspan="2" style="border:0px solid transparent; word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:16px !important;color:#fff; font-weight: bold; word-break: keep-all;">Hypotheekberekening 2 </td>
                                                                            <td width="10"></td>
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td colspan="2" width="277" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff; font-weight: bold; word-break: keep-all;"></td>
                                                                            <td width="10"></td>
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td height="25" width="55%" align="left" style="border:0px solid transparent;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;">Maximale hypotheek</td>
                                                                            <td height="25" width="36%" align="right" style="border:0px solid transparent;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;">€ '.number_format($maximale_hypotheek_2, 0, ',' , '.').' </td>
                                                                            <td width="10"></td>
                                                                                       
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td height="25" width="55%" align="left" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff; word-break: keep-all;">Rente (toetsrente '.$calculation_2_rate.'%)</td>
                                                                            <td height="25" width="36%" align="right" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;  word-break: keep-all;">€ '.number_format($hypo_ber_rent_2, 0, ',' , '.').' </td>
                                                                            <td width="10"></td>                                                                                                                                      
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td height="25" width="55%" align="left" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff; word-break: keep-all;">Aflossing</td>
                                                                            <td height="25" width="36%" align="right" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;  word-break: keep-all;">€ '.number_format($aflossing_2, 0, ',' , '.').'</td>
                                                                            <td width="10"></td>                                                                                                                                       
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td height="25" width="55%" align="left" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff; word-break: keep-all;">Bruto maandlast</td>
                                                                            <td height="25" width="36%" align="right" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;  word-break: keep-all;">€ '.number_format($maandlasten2, 0, ',' , '.').' </td>
                                                                            <td width="10"></td>                                                                                                                                         
                                                                        </tr>   
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td height="25" width="55%" align="left" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff; word-break: keep-all;">Belastingteruggave</td>
                                                                            <td height="25" width="36%" align="right" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;  word-break: keep-all;">€ '.number_format($belastingteruggave_2, 0, ',' , '.').' </td>
                                                                            <td width="10"></td>                                                                                        
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td height="25" width="55%" align="left" style="border-top: 1px solid ' . $email_cal_borderclr . '; border-bottom:0px solid transparent;border-left:0px solid transparent;border-right:0px solid transparent;border-collapse: separate;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff; word-break: keep-all;">Netto per maand</td>
                                                                            <td height="25" width="36%" align="right" style="border-top: 1px solid ' . $email_cal_borderclr . ';border-left:0px solid transparent;border-right:0px solid transparent; border-collapse: separate;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;  word-break: keep-all;"> € '.number_format($netto_per_maand_2, 0, ',' , '.').' </td>   
                                                                            <td width="10"></td>                                                                                                                                    
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td colspan="2" height="10" style="border:0px solid transparent; word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:17px !important;color:#fff; font-weight: bold; word-break: keep-all;"></td>
                                                                            <td width="10"></td>
                                                                        </tr>                                                                        
                                                                    </tbody>
                                                                </table>
                                                            </td>                                                           
                                                        </tr>                                                        
                                                    </tbody>
                                                </table>                                               
                                            </td>                     
                                        </tr>
                                        <tr>
                                            <td width="640" height="30" class="td_none">&nbsp;</td>                                         
                                        </tr>';  
                                         }
                                          if($Show_cal_3 == 1){
                                            $msg_body .= '<tr>
                                            <td class="table_box" width="48%" style="overflow: hidden;border-radius: 20px !important;">
                                                <table bgcolor="' . $email_cal_bgclr . '" class="main-table-data" width="307"  border="0" cellspacing="0" cellpadding="0" style="background:#' . $email_cal_bgclr . ';margin:0 auto;border: 0px solid ' . $email_cal_borderclr . ';border-collapse:separate;display: table;overflow: hidden;border-radius: 20px ">
                                                    <tbody>                                                                                                                                                                        
                                                        <tr style="border-collapse: collapse;border: 0px solid transparent;">                                                            
                                                            <td width="307" style="border: 1px solid ' . $email_cal_borderclr . ';overflow: hidden;border-radius: 20px">
                                                                <table bgcolor="' . $email_cal_bgclr . '" class="main-table-data" width="100%" align="center" border="0" cellspacing="0" cellpadding="0" style="background:#' . $email_cal_bgclr . ';margin:0 auto;border:0px solid #259599;border-collapse:separate;display: block;width:100%; ">
                                                                    <tbody>
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td colspan="2" height="10" style="border:0px solid transparent;"></td>
                                                                            <td width="10"></td>
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td colspan="2" style="border:0px solid transparent; word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:16px !important;color:#fff; font-weight: bold; word-break: keep-all;">Hypotheekberekening 3 met NHG </td>
                                                                            <td width="10"></td>
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td colspan="2" width="277" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff; font-weight: bold; word-break: keep-all;"></td>
                                                                            <td width="10"></td>
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td height="25" width="55%" align="left" style="border:0px solid transparent;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;">Maximale hypotheek</td>
                                                                            <td height="25" width="36%" align="right" style="border:0px solid transparent;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;">€ '.number_format($maximale_hypotheek_3, 0, ',' , '.').' </td>
                                                                            <td width="10"></td>                                                                                       
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td height="25" width="55%" align="left" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff; word-break: keep-all;">Rente (toetsrente '.$calculation_3_rate.'%)</td>
                                                                            <td height="25" width="36%" align="right" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;  word-break: keep-all;">€ '.number_format($hypo_ber_rent_3, 0, ',' , '.').' </td>
                                                                            <td width="10"></td>                                                                                                                                      
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td height="25" width="55%" align="left" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff; word-break: keep-all;">Aflossing</td>
                                                                            <td height="25" width="36%" align="right" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;  word-break: keep-all;">€ '.number_format($aflossing_3, 0, ',' , '.').'</td>
                                                                            <td width="10"></td>                                                                                                                                       
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td height="25" width="55%" align="left" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff; word-break: keep-all;">Bruto maandlast</td>
                                                                            <td height="25" width="36%" align="right" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;  word-break: keep-all;">€ '.number_format($maandlasten3, 0, ',' , '.').' </td>
                                                                            <td width="10"></td>                                                                                                                                         
                                                                        </tr>   
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td height="25" width="55%" align="left" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff; word-break: keep-all;">Belastingteruggave</td>
                                                                            <td height="25" width="36%" align="right" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;  word-break: keep-all;">€ '.number_format($belastingteruggave_3, 0, ',' , '.').' </td>
                                                                            <td width="10"></td>                                                                                        
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td height="25" width="55%" align="left" style="border-top: 1px solid ' . $email_cal_borderclr . '; border-bottom:0px solid transparent;border-left:0px solid transparent;border-right:0px solid transparent;border-collapse: separate;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff; word-break: keep-all;">Netto per maand</td>
                                                                            <td height="25" width="36%" align="right" style="border-top: 1px solid ' . $email_cal_borderclr . ';border-left:0px solid transparent;border-right:0px solid transparent; border-collapse: separate;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;  word-break: keep-all;"> € '.number_format($netto_per_maand_3, 0, ',' , '.').' </td>   
                                                                            <td width="10"></td>                                                                                                                                    
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td colspan="2" height="10" style="border:0px solid transparent; word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:17px !important;color:#fff; font-weight: bold; word-break: keep-all;"></td>
                                                                            <td width="10"></td>
                                                                        </tr>                                                                        
                                                                    </tbody>
                                                                </table>
                                                            </td>                                                           
                                                        </tr>                                                        
                                                    </tbody>
                                                </table>                                               
                                            </td>';                                            
                                            }
                                            if($Show_cal_4 == 1){ 
                                            $msg_body .= '<td width="4%" class="td_none">&nbsp;</td>
                                            <td class="table_box" width="48%" style="overflow: hidden;border-radius: 20px !important;">
                                                <table bgcolor="' . $email_cal_bgclr . '" class="main-table-data" width="307"  border="0" cellspacing="0" cellpadding="0" style="background:#' . $email_cal_bgclr . ';margin:0 auto;border: 0px solid ' . $email_cal_borderclr . ';border-collapse:separate;display: table;overflow: hidden;border-radius: 20px ">
                                                    <tbody>                                                                                                                                                                        
                                                        <tr style="border-collapse: collapse;border: 0px solid transparent;">                                                            
                                                            <td width="307" style="border: 1px solid ' . $email_cal_borderclr . ';overflow: hidden;border-radius: 20px">
                                                                <table bgcolor="' . $email_cal_bgclr . '" class="main-table-data" width="100%" align="center" border="0" cellspacing="0" cellpadding="0" style="background:#' . $email_cal_bgclr . ';margin:0 auto;border:0px solid #259599;border-collapse:separate;display: block;width:100%; ">
                                                                    <tbody>
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td colspan="2" height="10" style="border:0px solid transparent;"></td>
                                                                            <td width="10"></td>
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td colspan="2" style="border:0px solid transparent; word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:16px !important;color:#fff; font-weight: bold; word-break: keep-all;">Hypotheekberekening 4 - (5 jr. RVS)</td>
                                                                            <td width="10"></td>
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td colspan="2" width="277" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff; font-weight: bold; word-break: keep-all;"> </td>
                                                                            <td width="10"></td>
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td height="25" width="55%" align="left" style="border:0px solid transparent;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;">Maximale hypotheek</td>
                                                                            <td height="25" width="36%" align="right" style="border:0px solid transparent;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;">€ '.number_format($maximale_hypotheek_4, 0, ',' , '.').' </td>
                                                                            <td width="10"></td>                                                                                       
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td height="25" width="55%" align="left" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff; word-break: keep-all;">Rente (toetsrente '.$calculation_4_rate.'%)</td>
                                                                            <td height="25" width="36%" align="right" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;  word-break: keep-all;">€ '.number_format($hypo_ber_rent_4, 0, ',' , '.').' </td>
                                                                            <td width="10"></td>                                                                                                                                      
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td height="25" width="55%" align="left" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff; word-break: keep-all;">Aflossing</td>
                                                                            <td height="25" width="36%" align="right" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;  word-break: keep-all;">€ '.number_format($aflossing_4, 0, ',' , '.').'</td>
                                                                            <td width="10"></td>                                                                                                                                       
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td height="25" width="55%" align="left" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff; word-break: keep-all;">Bruto maandlast</td>
                                                                            <td height="25" width="36%" align="right" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;  word-break: keep-all;">€ '.number_format($maandlasten4, 0, ',' , '.').' </td>
                                                                            <td width="10"></td>                                                                                                                                         
                                                                        </tr>   
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td height="25" width="55%" align="left" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff; word-break: keep-all;">Belastingteruggave</td>
                                                                            <td height="25" width="36%" align="right" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;  word-break: keep-all;">€ '.number_format($belastingteruggave_4, 0, ',' , '.').' </td>
                                                                            <td width="10"></td>                                                                                        
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td height="25" width="55%" align="left" style="border-top: 1px solid ' . $email_cal_borderclr . '; border-bottom:0px solid transparent;border-left:0px solid transparent;border-right:0px solid transparent;border-collapse: separate;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff; word-break: keep-all;">Netto per maand</td>
                                                                            <td height="25" width="36%" align="right" style="border-top: 1px solid ' . $email_cal_borderclr . ';border-left:0px solid transparent;border-right:0px solid transparent; border-collapse: separate;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:#fff;  word-break: keep-all;"> € '.number_format($netto_per_maand_4, 0, ',' , '.').' </td>   
                                                                            <td width="10"></td>                                                                                                                                    
                                                                        </tr> 
                                                                        <tr bgcolor="' . $email_cal_box_bgclr . '" width="277" style="border-collapse: collapse;border: 0px solid transparent;">
                                                                            <td width="10"></td>
                                                                            <td colspan="2" height="10" style="border:0px solid transparent; word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:17px !important;color:#fff; font-weight: bold; word-break: keep-all;"></td>
                                                                            <td width="10"></td>
                                                                        </tr>                                                                        
                                                                    </tbody>
                                                                </table>
                                                            </td>                                                           
                                                        </tr>                                                        
                                                    </tbody>
                                                </table>                                               
                                            </td>'; }

                                         $msg_body .= '</tr>
                                        <tr>
                                            <td width="640" height="30" class="full-width">&nbsp;</td>                                         
                                        </tr>                                        
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        
                        
                        <tr>
                            <td bgcolor="' . $email_foo_bgclr . '" width="640" style="margin:0 auto; padding-left: 30px !important;padding-right: 30px !important;">
                                <table class="box_table" style="border-collapse:collapse; border:none; margin:0 auto;" width="640" cellspacing="0" cellpadding="0"  border="0" >
                                    <tbody>
                                        <tr>
                                            <td width="640" height="30" class="full-width">&nbsp;</td>                                         
                                        </tr>
                                        <tr>
                                            <td class="table_box" width="48%" style="overflow: hidden; border-radius: 20px !important;">
                                                <table class="main-table-data " width="307"  border="0" cellspacing="0" cellpadding="0" style="margin:0 auto;border: 0px solid #259599;border-collapse:separate;display: table; ">
                                                    <tbody>                                                                                                                                                                        
                                                        <tr style="border-collapse: collapse;border: 0px solid transparent;">                                                            
                                                            <td width="307">
                                                                <table bgcolor="#fff" class="main-table-data" width="100%" align="center" border="0" cellspacing="0" cellpadding="0" style="background:#fff;margin:0 auto;border:0px solid #259599;border-collapse:separate;display: block;width:100%; ">
                                                                    <tbody>                                                                     
                                                                        
                                                                        <tr bgcolor="#fff" width="257" style="border-collapse: collapse;border: 0px solid transparent; background-color: #fff">
                                                                            <td width="20"></td>
                                                                            <td  height="20" style="border:0px solid transparent;"></td>
                                                                            <td width="20"></td>
                                                                        </tr> 
                                                                        <tr bgcolor="#fff" width="257" style="border-collapse: collapse;border: 0px solid transparent; background-color: #fff">
                                                                            <td width="20"></td>
                                                                            <td style="border:0px solid transparent;white-space: normal;font-family: Roboto, sans-serif;font-size: 14px !important;color: #282828;line-height: 24px !important;word-break: keep-all;">'.$emil_footer_l1.'<br>'.$emil_footer_l2.' </td>
                                                                            <td width="20"></td>
                                                                        </tr> 
                                                                         <tr bgcolor="#fff" width="257" style="border-collapse: collapse;border: 0px solid transparent; background-color: #fff">
                                                                            <td width="20"></td>
                                                                            <td height="20" style="border:0px solid transparent; word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:17px !important;color:#fff; font-weight: bold; word-break: keep-all;"></td>
                                                                            <td width="20"></td>
                                                                        </tr> 
                                                                        <tr bgcolor="#fff" width="257" style="border-collapse: collapse;border: 0px solid transparent; background-color: #fff">
                                                                            <td width="20"></td>
                                                                            <td width="257" style="border:0px solid transparent;word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:14px !important;color:'.$email_btn_txtclr.'; font-weight: bold; word-break: keep-all;">
                                                                                <a target="_blank" class="button-a" style="-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%;background-color:'.$email_btn_bgclr.';background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;border-width:9px !important;border-style:solid;border-color:'.$email_btn_bgclr.';padding-top:0;padding-bottom:0;padding-right:0px !important;padding-left:3px !important;color:'.$email_btn_txtclr.';font-family:Roboto, sans-serif;font-size:13px !important;line-height:25px !important;text-align:center;text-decoration:none;display:block;border-radius:5px !important;-moz-border-radius: 5px !important;-khtml-border-radius:5px !important; -o-border-radius:5px !important;-webkit-border-radius:5px !important;-ms-border-radius:5px !important;font-weight:bold;transition:all 100ms ease-in;"  href="'.$email_footer_button_url.'">                                                                    
                                                                                    <strong style="-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%;font-size: 20px !important;font-weight: normal;"> '.$email_footer_button_txt.'</strong>
                                                                                </a>
                                                                            </td>
                                                                            <td width="20"></td>
                                                                        </tr>                                                                         
                                                                        <tr bgcolor="#fff" width="257" style="border-collapse: collapse;border: 0px solid transparent;background-color: #fff">
                                                                            <td width="20"></td>
                                                                            <td height="20" style="border:0px solid transparent; word-break: normal;white-space:normal;font-family: Roboto, sans-serif;font-size:17px !important;color:#fff; font-weight: bold; word-break: keep-all;"></td>
                                                                            <td width="20"></td>
                                                                        </tr>                                                                      
                                                                    </tbody>
                                                                </table>
                                                            </td>                                                           
                                                        </tr>                                                        
                                                    </tbody>
                                                </table>                                               
                                            </td>         
                                           
<td width="4%" class="td_none"></td>
<td class="table_box" width="48%" >
<table bgcolor="#ffffff" style="border:none; margin:0 auto;border:1px solid #fff;border-radius: 20px;padding: 20px;" width="100%" cellspacing="0" cellpadding="0" border="0">
<tbody> 
<tr>
<td width="24" height="24"><img src="'.FINAFORTE_URL.'assets/images/call-img.png" alt="fina fort contact number" style="-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%;max-width:100%;-ms-interpolation-mode:bicubic;margin:auto" class="edmImg"></td>
<td style="padding-left:15px;word-break: normal;white-space:normal;font-family: \'Roboto\', sans-serif;font-size:14px;color:#282828; line-height:35px;font-weight: bold; word-break: keep-all;" >  <a style="color: black;" href="tel:'.$advice_contact.'">'.$advice_contact.'</a></td>
</tr> 
<tr>
<td width="24" height="24"><img src="'.FINAFORTE_URL.'assets/images/email-img.png" alt="fina fort email" style="-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%;max-width:100%;-ms-interpolation-mode:bicubic;margin:auto" class="edmImg"></td>
<td style="padding-left:15px;">
<a href="mailto:info@finafort.nl" target="_blank" style="-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;color:#282828;font-family:Roboto, sans-serif;font-size:14px;line-height:35px;text-decoration:none;display:block;border-radius:5px;font-weight:bold;transition:all 100ms ease-in;"> '.$footer_email_id.'</a>
</td>
</tr> 
<tr>
<td width="24" height="24"><img src="'.FINAFORTE_URL.'assets/images/url-img.png" alt="fina fort url" style="-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%;max-width:100%;-ms-interpolation-mode:bicubic;margin:auto" class="edmImg"></td>
<td style="padding-left:15px;"> 
<a href="'.$footer_site_url.'" target="_blank" style="-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;color:#282828;font-family:Roboto, sans-serif;font-size:14px;line-height:35px;text-decoration:none;display:block;border-radius:5px;font-weight:bold;transition:all 100ms ease-in;">  '.$footer_site_url.' </a>
</td>
</tr> 
</tbody>
</table>
</td> 
</tr>
<tr>
<td style="width: 840px" height="30" class="full-width">&nbsp;</td> 
</tr> 
</tbody>
</table>
</td>
</tr>
</tbody>
</table> 
</td>
</tr>
</table>
</body>
</html>';  
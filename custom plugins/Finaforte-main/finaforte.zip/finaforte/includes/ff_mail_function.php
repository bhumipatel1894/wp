<?php
/**
 * Email form content
 *
 * @package Fina Forte
 * @since 1.0
 */
/* Exit if accessed directly */


/* include mailer library to use it's class */
include wp_normalize_path(FINAFORTE_DIR).'/PHPMailer/PHPMailerAutoload.php';

 $mail = new PHPMailer();
$mail->CharSet = 'UTF-8';
$mail->isSMTP();
$mail->SMTPDebug = 0;
$mail->Debugoutput = 'html';
$mail->Host = $smtp_server_add;
if(!empty($smtp_port_type)){
	$mail->SMTPSecure = $smtp_port_type;
}
$mail->Port = $smtp_port;
if($cc1_email){
$mail->AddCC($cc1_email, '');
}
if($cc2_email){
$mail->AddCC($cc2_email, '');
} 
$mail->SMTPAuth = true;
$mail->Username = $smtp_username;
$mail->Password = $smtp_password;

$mail->setFrom($smtp_from_email, $smtp_from_name);
$mail->addAddress($txt_email, $txt_email);

$mail->Subject = $email_subject;
/* $message*/
//$mail->msgHTML($email_message);
$mail->msgHTML($msg_body);
$mail->addAttachment($pdf_dest);

$mail->AltBody = 'calculation is not available yet';
<?php
/**
 * Email form content
 *
 * @package Fina Forte
 * @since 1.0
 */
/* Exit if accessed directly */

$footer_email_id = finaforte_get_option('footer_email_id');
require_once "admin-options.php";
include wp_normalize_path(FINAFORTE_DIR).'/TCPDF-master/tcpdf_include.php';

// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Finaforte');
$pdf->SetTitle('Finaforte Calculation');
$pdf->SetSubject('TCPDF Tutorial');
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');

$pdf->SetFont ('helvetica', '', $font_size , '', 'default', true );
// remove default header/footer
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, 10, PDF_MARGIN_RIGHT);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, 5);

// set image scale facto
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// add a page
$pdf->AddPage();

$h_totalincome = $_POST['h_totalincome'] ? $_POST['h_totalincome'] : '0';
$h_totalincomep = $_POST['h_totalincomep'] ? $_POST['h_totalincomep'] : '0';
//$h_totalincome_sum2 = $h_totalincome+$h_totalincomep;
$h_totalincome_sum2 = $_POST['h_totalincome_sum'] ? $_POST['h_totalincome_sum'] : '0';

$html = '<style> table{border-radius: 20px;} </style>
<table width="100%" cellpadding="0" border="0">
  <tr>
    <td><img src="'.$email_logo.'" alt="finafort" style="-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%;max-width:100%;-ms-interpolation-mode:bicubic;margin:auto" class="edmImg"></td>    
    <td colspan="2" style="text-align:right;">
      Hypotheken voor ondernemers<br><span style="color: '.$email_cal_box_bgclr.';">
      '.date("d/m/Y").'</span></td>
  </tr>
  <tr><td colspan="3" style="hight:10px;"></td></tr> 
  </table>
     
<div style="vertical-align:center; padding-left:8px; padding-top:15px; padding-bottom:0px; background-color:#00000017; vertical-align:center; height:20px;">
  <tr style="padding-bottom:0px;">
    <td height="20" colspan="3" style="padding-bottom:0px; color:'.$email_topname_clr.'; text-align:left; font-size:15px;">'.$txt_name.'</td>
  </tr>
 </div>


<div style="font-size:14px; font: normal normal normal 14px/1 FontAwesome;"><b> '.$email_title.' </b></div>


 <div style="font-size:14px; font: normal normal normal 14px/1 FontAwesome;">'.$email_description.'</div>

<table style="font-size:14px;">
  <tr><td colspan="3" style="hight:10px;"></td></tr>
  <tr>
    <td style="text-align:center;">Uw totale toetsinkomen </td>
    <td style="text-align:center;"><b> Maximale hypotheek </b></td>
    <td style="text-align:center;">Maandlasten max. hypotheek </td>
  </tr>
  <tr><td colspan="3" style="hight:5px;"></td></tr>
   <tr>
    <td style="text-align:center; color='.$email_cal_box_bgclr.';">€ '.$h_totalincome_sum2.'</td>
    <td style="text-align:center; color='.$email_cal_box_bgclr.';"><b>€ '.number_format($h_max_hypotheek, 0, ',' , '.').'</b></td>
    <td style="text-align:center; color='.$email_cal_box_bgclr.';">€ '.number_format($h_maandlasten, 0, ',' , '.').'</td>
  </tr>
  <tr><td colspan="3" style="hight:10px;"></td></tr>
  
</table>


<table width="100%" padding-left:20px; cellpadding="0" border="0" style="font-size:12px; background-color:' . $email_cal_bgclr . '; height:500px; color:white;">
  <tr>
      <td style="height:25px;"></td>
      <td style="height:25px;"></td>
      <td style="height:25px;"></td>
      <td style="height:25px;"></td>
    </tr>

    <tr>';
        if($Show_cal_1 == 1) { 
        if($Show_cal_2 != 1 && $Show_cal_3 != 1 && $Show_cal_4 != 1) {$colspan = 'colspan="3"';} else {$colspan = ''; }
        $html .=
        '<td width="2%"></td>
        <td width="45%" style="hight:255px; border-radius: 50%; border : 1px solid #000;" '.$colspan.' opacity: 0.5;>
            
            <table width="100%" cellpadding="2" cellspacing="3" border="0" style="border: 1px solid ' . $email_cal_borderclr . '; border-radius: 40%;  background-color:'.$email_cal_box_bgclr.';">
                <tr>
                  <td colspan="2" width="100%" >Hypotheekberekening 1 </td>
                </tr>
                
                <tr>
                  <td width="55%">Maximale hypotheek</td>
                  <td width="45%" style="text-align:right;">€ '.number_format($maximale_hypotheek_1, 0, ',' , '.').'</td>
                </tr>
                 <tr>
                  <td width="55%">Rente (toetsrente'.$calculation_1_rate.'%)</td>
                  <td width="45%" style="text-align:right; text-indent:-10px;">€ '.number_format($hypo_ber_rent_1, 0, ',' , '.').'</td>
                </tr>
                 <tr>
                  <td width="55%">Aflossing</td>
                  <td width="45%" style="text-align:right;">€ '.number_format($aflossing_1, 0, ',' , '.').'</td>
                </tr>
                <tr>
                  <td width="55%">Bruto maandlast</td>
                  <td width="45%" style="text-align:right;">€ '.number_format($bruto_maandlast, 0, ',' , '.').'</td>
                </tr>
                <tr>
                  <td width="55%">Belastingteruggave</td>
                  <td width="45%" style="text-align:right;">€ '.number_format($belastingteruggave_1, 0, ',' , '.').'</td>
                </tr>
              </table>
              <table width="100%" border="0" cellpadding="2" cellspacing="3" style="border: 1px solid ' . $email_cal_borderclr . '; border-radius: 40px; background-color:'.$email_cal_box_bgclr.';"> 
                <tr>
                  <td width="55%">Netto per maand</td>
                  <td width="45%" style="text-align:right;">€ '.number_format($netto_per_maand_1, 0, ',' , '.').'</td>
                </tr>
            </table> 
           
        </td>';
      } 

    if($Show_cal_2 == 1) {

       $html .= '<td width="3%"></td>
       <td width="45%" style="hight:255px;">
             <table width="100%" border="0" cellpadding="2" cellspacing="3" style="border: 1px solid ' . $email_cal_borderclr . '; border-radius: 40px; background-color:'.$email_cal_box_bgclr.';">
                <tr>
                  <td colspan="2" width="100%" >Hypotheekberekening 2 </td>
                </tr>
               
                <tr>
                  <td width="55%">Maximale hypotheek</td>
                  <td width="45%" style="text-align:right;">€ '.number_format($maximale_hypotheek_2, 0, ',' , '.').'</td>
                </tr>
                 <tr>
                  <td width="55%">Rente (toetsrente'.$calculation_2_rate.'%)</td>
                  <td width="45%" style="text-align:right;">€ '.number_format($hypo_ber_rent_2, 0, ',' , '.').'</td>
                </tr>
                 <tr>
                  <td width="55%">Aflossing</td>
                  <td width="45%" style="text-align:right;">€ '.number_format($aflossing_2, 0, ',' , '.').'</td>
                </tr>
                <tr>
                  <td width="55%">Bruto maandlast </td>
                  <td width="45%" style="text-align:right;">€ '.number_format($maandlasten2, 0, ',' , '.').' </td>
                </tr>
                <tr>
                  <td width="55%" style="">Belastingteruggave</td>
                  <td width="45%" style="text-align:right;">€ '.number_format($belastingteruggave_2, 0, ',' , '.').'</td>
                </tr>
              </table>
              <table width="100%" border="0" cellpadding="2" cellspacing="3" style="border: 1px solid ' . $email_cal_borderclr . '; border-radius: 40px; background-color:'.$email_cal_box_bgclr.';">      
                <tr>         
                  <td width="55%">Netto per maand</td>
                  <td width="45%" style="text-align:right;">€ '.number_format($netto_per_maand_2, 0, ',' , '.').'</td>
                </tr>
            </table>      
        </td>'; }
       $html .= '</tr>';
         if($Show_cal_3 == 1){
  $html .= '<tr>
      <td style="height:25px;"></td>
      <td style="height:25px;"></td>
      <td style="height:25px;"></td>
      <td style="height:25px;"></td>
    </tr>

          <tr>
            <td width="2%"></td>
            <td width="45%" style="hight:250px; margin-right:40px;">
                <table width="100%" cellpadding="2" cellspacing="3" border="0" style="border: 1px solid ' . $email_cal_borderclr . '; border-radius: 40px; background-color:'.$email_cal_box_bgclr.';">
                    <tr>
                      <td colspan="2" width="100%" >Hypotheekberekening 3 met NHG </td>
                    </tr>
                   
                    <tr>
                      <td width="55%">Maximale hypotheek</td>
                      <td width="45%" style="text-align:right;">€ '.number_format($maximale_hypotheek_3, 0, ',' , '.').'</td>
                    </tr>
                     <tr>
                      <td width="55%">Rente (toetsrente'.$calculation_3_rate.'%)</td>
                      <td width="45%" style="text-align:right;">€ '.number_format($hypo_ber_rent_3, 0, ',' , '.').'</td>
                    </tr>
                     <tr>
                      <td width="55%">Aflossing</td>
                      <td width="45%" style="text-align:right;">€ '.number_format($aflossing_3, 0, ',' , '.').'</td>
                    </tr>
                    <tr>
                      <td width="55%">Bruto maandlast</td>
                      <td width="45%" style="text-align:right;">€ '.number_format($maandlasten3, 0, ',' , '.').'</td>
                    </tr>
                    <tr>
                      <td width="55%">Belastingteruggave</td>
                      <td width="45%" style="text-align:right;">€ '.number_format($belastingteruggave_3, 0, ',' , '.').'</td>
                    </tr>
                  </table>
                  <table width="100%" border="0" cellpadding="2" cellspacing="3" style="border: 1px solid ' . $email_cal_borderclr . '; border-radius: 40px; background-color:'.$email_cal_box_bgclr.';">
                    <tr>
                      <td width="55%">Netto per maand</td>
                      <td width="45%" style="text-align:right;">€ '.number_format($netto_per_maand_3, 0, ',' , '.').'</td>
                    </tr>
                </table>      
            </td>';
          } if($Show_cal_4 == 1){ 
     $html .= '<td width="3%"></td>
            <td width="45%" style="hight:250px; margin-right:40px;">
                <table width="100%" border="0" cellpadding="2" cellspacing="3" style="border: 1px solid ' . $email_cal_borderclr . '; border-radius: 40px; background-color:'.$email_cal_box_bgclr.';">
                    <tr>
                      <td colspan="2" width="100%" >Hypotheekberekening 4</td>
                      
                    </tr>
                    
                    <tr>
                      <td width="55%">Maximale hypotheek</td>
                      <td width="45%" style="text-align:right;">€ '.number_format($maximale_hypotheek_4, 0, ',' , '.').'</td>
                    </tr>
                     <tr>
                      <td width="55%">Rente (toetsrente'.$calculation_4_rate.'%)</td>
                      <td width="45%" style="text-align:right;">€ '.number_format($hypo_ber_rent_4, 0, ',' , '.').'</td>
                    </tr>
                     <tr>
                      <td width="55%">Aflossing</td>
                      <td width="45%" style="text-align:right;">€ '.number_format($aflossing_4, 0, ',' , '.').'</td>
                    </tr>
                    <tr>
                      <td width="55%">Bruto maandlast</td>
                      <td width="45%" style="text-align:right;">€ '.number_format($maandlasten4, 0, ',' , '.').'</td>
                    </tr>
                    <tr>
                      <td width="55%">Belastingteruggave</td>
                      <td width="45%" style="text-align:right;">€ '.number_format($belastingteruggave_4, 0, ',' , '.').'</td>
                    </tr>
                  </table>
                  <table width="100%" border="0" cellpadding="2" cellspacing="3" style="border: 1px solid ' . $email_cal_borderclr . '; border-radius: 40px; background-color:'.$email_cal_box_bgclr.';">   
                    <tr>
                      <td width="55%">Netto per maand</td>
                      <td width="45%" style="text-align:right;">€ '.number_format($netto_per_maand_4, 0, ',' , '.').'</td>
                    </tr>
                </table>      
            </td>
          </tr>
          ';
         }
     $html .= ' <tr>
      <td style="height:25px;"></td>
      <td style="height:25px;"></td>
      <td style="height:25px;"></td>
      <td style="height:25px;"></td>
    </tr>
          </table>';


 $html .= '<table width="100%" cellpadding="0" border="0" style="background-color:' . $email_foo_bgclr . ';" height="400px;">
    
    <tr>
      <td style="height:25px;"></td>
      <td style="height:25px;"></td>
      <td style="height:25px;"></td>
      <td style="height:25px;"></td>
    </tr>
    <tr> 
      <td width="2%"></td>      
        <td width="45%">
            <table width="100%" border="0" cellpadding="3" cellspacing="3" style="font-size:12px; background-color:white">
                <tr height="0%">
                  <td colspan="3" style="height:0px;"></td>
                </tr>
                <tr>
                  <td width="5%" ></td>
                  <td width="90%" >'.$emil_footer_l1.'</td>
                  <td width="5%" ></td>
                </tr>
                <tr>
                <td width="5%" > </td>
                  <td width="90%" >'.$emil_footer_l2.'</td>
                 <td width="5%" ></td>
                </tr>                
                <tr>
                  <td width="5%" ></td>
                  <td  width="90%" style="align:center; background-color:'.$email_btn_bgclr.';  text-align:center;"> <a style="color:'.$email_btn_txtclr.'; text-decoration:none;" href="'.$email_footer_button_url.'">'.$email_footer_button_txt.'</a></td>
                  <td width="5%" ></td>
                </tr>
                <tr height="0%">
                  <td colspan="3" style="height:0px;"></td>
                </tr> 
            </table>    
        </td>
        <td width="3%"></td>
       <td width="45%">
            <table height="100%" width="100%" cellpadding="2" cellspacing="2" border="0" style="font-size:12px; background-color:white">
                <tr><td style="height:28px;" colspan="4"></td>
                </tr>
                <tr>
                  <td width="1%"></td>
                  <td style="height:15px;" width="10%"><img src="'.FINAFORTE_URL.'assets/images/call-img.png" alt="fina fort url"></td>
                  <td width="1%"></td>
                  <td style="height:15px;" vertical-align: text-bottom; width="59%"><a style="color: black;" href="tel:'.$advice_contact.'">'.$advice_contact.'</a> </td>
                  
                </tr>
                <tr>
                  <td width="1%"></td>
                  <td style="height:15px;"><img src="'.FINAFORTE_URL.'assets/images/email-img.png" alt="fina fort url"></td>
                  <td></td>
                  <td style="height:15px; vertical-align: sub; font-family:times">'.$footer_email_id.'</td>
                </tr>
                <tr>
                  <td width="1%"></td>
                  <td style="height:15px;"><img src="'.FINAFORTE_URL.'assets/images/url-img.png" alt="fina fort url"></td>
                  <td></td>
                  <td style="height:15px; vertical-align: sub;">'.$footer_site_url.'</td>
                </tr>
               <tr><td style="height:3px;" colspan="3"></td></tr>
            </table>    
        </td>
    </tr>
    <tr>
      <td style="height:25px;"></td>
      <td style="height:25px;"></td>
      <td style="height:25px;"></td>
      <td style="height:25px;"></td>
    </tr>
    
</table>';

// output the HTML content
$pdf->writeHTML($html, true, false, true, false, '');

//Close and output PDF document
$pdf_dest = wp_normalize_path(FINAFORTE_DIR).'/finaforte-calculation.pdf';

$pdf->Output($pdf_dest, 'F');
<?php

/**
 * Update default settings * 
 * @package Finaforte
 * @since 1.0
 */

error_reporting(E_ERROR | E_PARSE);

function register_session(){
    if( !session_id() )
        session_start();
}
add_action('init','register_session');

function finaforte_default_settings() {
    global $finaforte_options;
    $finaforte_options = array(
        'advicer_photo' => '',
        'advice_contact' => '088 - 543 4564',
        'cc1_email' => '',
        'cc2_email' => '',        
        'smtp_username' => '',
        'smtp_password' => '',
        'smtp_from_email' => '',
        'smtp_from_name' => '',
        'accurate_calculation' => 'calculation is accurate',
        'popup_button_text' => 'Overzicht berekening ',
        'tooltip_loondienst' => 'enter salary of loondienst',
        'sol_liq_wrong_notice' => 'sol and liq are not correct',
        'solvabiliteit_text' => 'Solvabiliteit toevoegen',
        'liquiditeit_text' => 'Liquiditeit toevoegen',
        'soadd_actionl_wrong_notice' => 'sol is not corretct',
        'sol_wrong_notice' => 'sol is not correct',
        'liq_wrong_notice' => 'liq is not corretct',
        'p_sol_liq_wrong_notice' => 'partner sol and liq are not correct',
        'p_liq_wrong_notice' => 'partner liq is not corretct',
        'p_sol_wrong_notice' => 'partner sol is not corretct',
        'tooltip_select_year' => 'Please select year to enter salary',
        'tooltip_salary' => 'Please enter salary',
        'tooltip_mortgage_interest' => 'here is a mortoguage intrest',
        'tooltip_total_p_incom' => 'here is total partner incom',
        'max_hypo_1_per' => '100',
        'min_hypo_2_per' => '80',
        'solvency_green_text' => 'good',
        'solvency_yellow_text' => 'midum',
        'solvency_red_text' => 'poor',
        'solvency_green_color' => '#dada00',
        'solvency_yellow_color' => '#ff8600',
        'solvency_red_color' => '#ff0100',
        'liquidity_green_text' => 'good',
        'liquidity_yellow_text' => 'mid',
        'liquidity_red_text' => 'red',
        'liquidity_green_color' => '#dada00',
        'liquidity_yellow_color' => '#ff8600',
        'liquidity_red_color' => '#ff0100',
        
        'calculation_1_rate' => '3.01',
        'calculation_1_y' => '10',
        'calculation_2_rate' => '3.01',
        'calculation_2_y' => '10',
        'calculation_3_rate' => '3.01',
        'calculation_3_y' => '10',
        'maximale_hypotheek_3' => '300000',
        'calculation_4_rate' => '3.01',
        'calculation_4_y' => '10',
        'belastingteruggave_1' => '35',
        'belastingteruggave_2' => '35',
        'belastingteruggave_3' => '35',
        'belastingteruggave_4' => '35',
        'mortgage_interest' => '2.501',
        'number_of_periods' => '30',      
        
        'theme_bg_color' => '#f4f4f4',
        'txt_border_color' => '#d3d3d3',
        'border_radius' => '10',

        'btn_bg_color' => '#0c6a6d',
        'btn_border_color' => '#d3d3d3',
        'btn_text_color' => '#fff',

        'freelancer_icon_clr' => '#cccc00',
        'freelancer_bg_clr' => '#fff',
        'freelancer_text_clr' => '#0c6a6d',
        'vof_icon_clr' => '#66cc99',
        'vof_bg_clr' => '#fff',
        'vof_text_clr' => '#0c6a6d',
        'bv_dga_icon_clr' => '#666699',
        'bv_dga_bg_clr' => '#fff',
        'bv_dga_text_clr' => '#0c6a6d',
        'loondienst_icon_clr' => '#cc6600',
        'loondienst_bg_clr' => '#fff',
        'loondienst_text_clr' => '#0c6a6d',
        'toggle_bg_clr' => '#0c6a6d',
        'toggle_text_clr' => '#fff',
        
        'title_font_size' => '20',
        'subtitle_font_size' => '16',
        'text_font_size' => '14',
        'gentext_font_size' => '14',
        'title_color' => '#0c6a6d',
        'subtitle_color' => '#0c6a6d',
        'text_color' => '#424242',
        'gentext_color' => '#444',
        'total_cal_txt_clr' => '',
        'total_cal_border_clr' => '',
        'total_cal_bg_clr' => '',

        'cal_sugg_text' => '',
        'cal_heading' => 'De uitgebreide berekening',
        'total_incom_text' => 'Uw totale toetsinkomen',
        'partner_total_incom_text' => 'Toetsinkomen partner',
        'popup_form_title_text' => 'Benieuwd naar uw maximale hypotheek?',
        'popup_form_sub_text' => 'Start met berekenen',
        'login_form_description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed at massaeget justo consequat fermentum ut nec turpis. Morbi tristique temporpurus, ac lacinia risus tincidunt et.',
        'form_semi_description' => 'Na het invullen van uw gegeves kunt U direct starten met berekenen!',             
        'popup_form_below_text' => 'We maken voor u een op maat gemaakte berekening.',
        'company_name' => 'Finaforte',
        'privacy_policy_url' => 'https://www.finaforte.nl/privacy-statement/',   
        'view_cal_button_text' => 'Bekijk totale berekening',
        'free_advice_label' => 'Gratis advies van Finaforte',
        'free_advice_text' => 'Informatie verstrekt in deze berekening is op basis van de door U ingevoerde informatie. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed at massa eget justo consequat fermentum ut necturpis. Morbi tristique tempor.',
        'email_free_advice_label' => 'Gratis advies van Finaforte',
        'email_free_advice_text' => 'Informatie verstrekt in deze berekening is op basis van de door U ingevoerde informatie. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed at massa eget justo consequat fermentum ut necturpis. Morbi tristique tempor.',
        'email_button_text' => 'Ontvang per e-mail',

        'email_title' => '',
        'email_description' => '',
        'emil_footer_l1' => 'Vraag vanclaag nog een gratis vrijblijvend',
        'emil_footer_l2' => 'gesprek oats of bel ons op',
        'footer_email_id' => 'info@finafort.nl',
        'footer_site_url' => 'www.finaforte.nl',
        'email_footer_button_txt' => 'IK wit een gratis gesperk',
        'email_footer_button_url' => '',
        'email_message' => '',
        'email_cal_bgclr' => '#000000',
        'email_cal_box_bgclr' => '#ffffff',
        'email_foo_bgclr' => '#a8a8a8',
        'email_cal_borderclr' => '#0c6a6d',
        'email_btn_bgclr' => '#0c6a6d',
        'email_btn_txtclr' => '#ffffff',
        'email_form_heading' => 'Gratis advies informatie (na klik ontvangen per e-mail)',
        
    );

    $default_options = apply_filters('finaforte_options_default_values', $finaforte_options);

    // Update default options
    update_option('finaforte_options', $default_options);

    // Overwrite global variable when option is update
    $finaforte_options = finaforte_get_settings();
}

/**
 * Get Settings From Option Page * 
 * Handles to return all settings value * 
 * @package Finaforte
 * @since 1.0
 */
function finaforte_get_settings() {
    $options = get_option('finaforte_options');
    $settings = is_array($options) ? $options : array();
    return $settings;
}

/**
 * Escape Tags & Slashes *
 * Handles escapping the slashes and tags *
 * @package Finaforte
 * @since 1.0
 */
function finaforte_esc_attr($data) {
    return esc_attr(stripslashes($data));
}

/**
 * Strip Slashes From Array *
 * @package Finaforte
 * @since 1.0
 */
function finaforte_slashes_deep($data = array(), $flag = false) {

    if ($flag != true) {
        $data = finaforte_nohtml_kses($data);
    }
    $data = stripslashes_deep($data);
    return $data;
}

/**
 * Strip Html Tags 
 * 
 * It will sanitize text input (strip html tags, and escape characters)
 * 
 * @package Finaforte
 */
function finaforte_nohtml_kses($data = array()) {

    if (is_array($data)) {
        $data = array_map('finaforte_nohtml_kses', $data);
    } elseif (is_string($data)) {
        $data = trim($data);
        $data = wp_filter_nohtml_kses($data);
    }
    return $data;
}

/**
 * Get an array key
 * @param value for find key,array
 * @package Finaforte
 * @since 1.0
 */
function get_key_of_array($max, array $search_arr) {

    $newNumbers = array_filter($search_arr, function ($value) use($min, $max) {
        $max_val_arr = ($value <= $max);
        return $max_val_arr;
    });

    $newNumbers = max($newNumbers);
    return array_search($newNumbers, $search_arr);
}

/**
 * Get an option
 * Looks to see if the specified setting exists, returns default if not * 
 * @package Finaforte
 * @since 1.0
 */
function finaforte_get_option($key = '', $default = false) {

    global $finaforte_options;
    $value = !empty($finaforte_options[$key]) ? $finaforte_options[$key] : $default;
    $value = apply_filters('finaforte_get_option', $value, $key, $default);
    return apply_filters('finaforte_get_option_' . $key, $value, $key, $default);
}

function mortgage_basic_form() {
   //require_once "mortage-basic-form.php";
}

function start_calculation_form() {
    include_once "start-calculation-form.php";
}


function start_calculationform() {

    start_calculation_form();
    die;
}

add_action('wp_ajax_start_calculationform', 'start_calculationform');
add_action('wp_ajax_nopriv_start_calculationform', 'start_calculationform');

function view_total_calculation() {
    
    $_SESSION['finaforte']['view_totalcalculation'] = "1";

    
    $_SESSION['finaforte']['totalincome'] = $_POST['totalincome'];
    $_SESSION['finaforte']['totalincomep'] = $_POST['totalincomep'];
    $_SESSION['finaforte']['solvabiliteit'] = $_POST['solvabiliteit'];
    $_SESSION['finaforte']['solvabiliteitp'] = $_POST['solvabiliteitp'];
    $_SESSION['finaforte']['liquiditeit'] = $_POST['liquiditeit'];
    $_SESSION['finaforte']['liquiditeitp'] = $_POST['liquiditeitp'];
    $_SESSION['finaforte']['maximale_hypotheek'] = $_POST['maximale_hypotheek'];
    $_SESSION['finaforte']['maandlasten'] = $_POST['maandlasten'];
    $_SESSION['finaforte']['totalincome_sum'] = $_POST['totalincome_sum'];
    $_SESSION['finaforte']['yearselection'] = $_POST['yearselection'];
    $_SESSION['finaforte']['typeselection'] = $_POST['typeselection'];
    $_SESSION['finaforte']['partnertypeselection'] = $_POST['partnertypeselection'];
    $_SESSION['finaforte']['partneryearselection'] = $_POST['partneryearselection'];
    // on off switches val
    $_SESSION['finaforte']['myonoffswitch1'] = $_POST['myonoffswitch1'];
    $_SESSION['finaforte']['myonoffswitch3'] = $_POST['myonoffswitch3'];
    $_SESSION['finaforte']['ponoffswitch1'] = $_POST['ponoffswitch1'];
    $_SESSION['finaforte']['pmyonoffswitch3'] = $_POST['pmyonoffswitch3'];
    // yearly income
    $_SESSION['finaforte']['txt_halfyear_first'] = $_POST['txt_halfyear_first'];
    $_SESSION['finaforte']['txt_halfyear_second'] = $_POST['txt_halfyear_second'];
    $_SESSION['finaforte']['txt_halfyear_third'] = $_POST['txt_halfyear_third'];
    $_SESSION['finaforte']['txt_winstuitonderneming_1'] = $_POST['txt_winstuitonderneming_1'];
    $_SESSION['finaforte']['txt_winstuitonderneming_2'] = $_POST['txt_winstuitonderneming_2'];
    $_SESSION['finaforte']['txt_winstuitonderneming_3'] = $_POST['txt_winstuitonderneming_3'];
    $_SESSION['finaforte']['txt_salaris_1'] = $_POST['txt_salaris_1'];
    $_SESSION['finaforte']['txt_dividend_1'] = $_POST['txt_dividend_1'];
    $_SESSION['finaforte']['txt_overwinst_1'] = $_POST['txt_overwinst_1'];
    $_SESSION['finaforte']['txt_salaris_2'] = $_POST['txt_salaris_2'];
    $_SESSION['finaforte']['txt_dividend_2'] = $_POST['txt_dividend_2'];
    $_SESSION['finaforte']['txt_overwinst_2'] = $_POST['txt_overwinst_2'];
    $_SESSION['finaforte']['txt_salaris_3'] = $_POST['txt_salaris_3'];
    $_SESSION['finaforte']['txt_dividend_3'] = $_POST['txt_dividend_3'];
    $_SESSION['finaforte']['txt_overwinst_3'] = $_POST['txt_overwinst_3'];
    // partner yearly income
    $_SESSION['finaforte']['txt_loondienst'] = $_POST['txt_loondienst'];
    $_SESSION['finaforte']['txt_halfyearp_first'] = $_POST['txt_halfyearp_first'];
    $_SESSION['finaforte']['txt_halfyearp_second'] = $_POST['txt_halfyearp_second'];
    $_SESSION['finaforte']['txt_halfyearp_third'] = $_POST['txt_halfyearp_third'];
    $_SESSION['finaforte']['txt_winstuitondernemingp_1'] = $_POST['txt_winstuitondernemingp_1'];
    $_SESSION['finaforte']['txt_winstuitondernemingp_2'] = $_POST['txt_winstuitondernemingp_2'];
    $_SESSION['finaforte']['txt_winstuitondernemingp_3'] = $_POST['txt_winstuitondernemingp_3'];
    $_SESSION['finaforte']['txt_salarisp_1'] = $_POST['txt_salarisp_1'];
    $_SESSION['finaforte']['txt_dividendp_1'] = $_POST['txt_dividendp_1'];
    $_SESSION['finaforte']['txt_overwinstp_1'] = $_POST['txt_overwinstp_1'];
    $_SESSION['finaforte']['txt_salarisp_2'] = $_POST['txt_salarisp_2'];
    $_SESSION['finaforte']['txt_dividendp_2'] = $_POST['txt_dividendp_2'];
    $_SESSION['finaforte']['txt_overwinstp_2'] = $_POST['txt_overwinstp_2'];
    $_SESSION['finaforte']['txt_salarisp_3'] = $_POST['txt_salarisp_3'];
    $_SESSION['finaforte']['txt_dividendp_3'] = $_POST['txt_dividendp_3'];
    $_SESSION['finaforte']['txt_overwinstp_3'] = $_POST['txt_overwinstp_3'];
    // sol & liq
    $_SESSION['finaforte']['txt_eigenvermogen_1'] = $_POST['txt_eigenvermogen_1'];
    $_SESSION['finaforte']['txt_balanstotaal_1'] = $_POST['txt_balanstotaal_1'];
    $_SESSION['finaforte']['txt_eigenvermogen_2'] = $_POST['txt_eigenvermogen_2'];
    $_SESSION['finaforte']['txt_balanstotaal_2'] = $_POST['txt_balanstotaal_2'];
    $_SESSION['finaforte']['txt_eigenvermogen_3'] = $_POST['txt_eigenvermogen_3'];
    $_SESSION['finaforte']['txt_balanstotaal_3'] = $_POST['txt_balanstotaal_3'];
    $_SESSION['finaforte']['txt_vlottendeactiva_1'] = $_POST['txt_vlottendeactiva_1'];
    $_SESSION['finaforte']['txt_kortvreemdvermogen_1'] = $_POST['txt_kortvreemdvermogen_1'];
    $_SESSION['finaforte']['txt_vlottendeactiva_2'] = $_POST['txt_vlottendeactiva_2'];
    $_SESSION['finaforte']['txt_kortvreemdvermogen_2'] = $_POST['txt_kortvreemdvermogen_2'];
    $_SESSION['finaforte']['txt_vlottendeactiva_3'] = $_POST['txt_vlottendeactiva_3'];
    $_SESSION['finaforte']['txt_kortvreemdvermogen_3'] = $_POST['txt_kortvreemdvermogen_3'];
    // partner sol & liq
    $_SESSION['finaforte']['txt_eigenvermogenp_1'] = $_POST['txt_eigenvermogenp_1'];
    $_SESSION['finaforte']['txt_balanstotaalp_1'] = $_POST['txt_balanstotaalp_1'];
    $_SESSION['finaforte']['txt_eigenvermogenp_2'] = $_POST['txt_eigenvermogenp_2'];
    $_SESSION['finaforte']['txt_balanstotaalp_2'] = $_POST['txt_balanstotaalp_2'];
    $_SESSION['finaforte']['txt_eigenvermogenp_3'] = $_POST['txt_eigenvermogenp_3'];
    $_SESSION['finaforte']['txt_balanstotaalp_3'] = $_POST['txt_balanstotaalp_3'];
    $_SESSION['finaforte']['txt_vlottendeactivap_1'] = $_POST['txt_vlottendeactivap_1'];
    $_SESSION['finaforte']['txt_kortvreemdvermogenp_1'] = $_POST['txt_kortvreemdvermogenp_1'];
    $_SESSION['finaforte']['txt_vlottendeactivap_2'] = $_POST['txt_vlottendeactivap_2'];
    $_SESSION['finaforte']['txt_kortvreemdvermogenp_2'] = $_POST['txt_kortvreemdvermogenp_2'];
    $_SESSION['finaforte']['txt_vlottendeactivap_3'] = $_POST['txt_vlottendeactivap_3'];
    //other cal
    $_SESSION['finaforte']['group1'] = $_POST['group1'];
    $_SESSION['finaforte']['single_slider_first'] = $_POST['single_slider_first'];
    $_SESSION['finaforte']['single_slider_tv1'] = $_POST['single_slider_tv1'];
    $_SESSION['finaforte']['single_slider_ph1'] = $_POST['single_slider_ph1'];
    $_SESSION['finaforte']['pgroup1'] = $_POST['pgroup1'];
    $_SESSION['finaforte']['yn_switch'] = $_POST['yn_switch'];
    $_SESSION['finaforte']['single_slider_2'] = $_POST['single_slider_2'];
}

add_action('wp_ajax_view_total_calculation', 'view_total_calculation');
add_action('wp_ajax_nopriv_view_total_calculation', 'view_total_calculation');

function backto_calculator_act() {

    unset($_SESSION['finaforte']['view_totalcalculation']);
    // yearly income
    $_SESSION['finaforte']['txt_halfyear_first'] = $_POST['txt_halfyear_first'];
    $_SESSION['finaforte']['txt_halfyear_second'] = $_POST['txt_halfyear_second'];
    $_SESSION['finaforte']['txt_halfyear_third'] = $_POST['txt_halfyear_third'];
    $_SESSION['finaforte']['txt_winstuitonderneming_1'] = $_POST['txt_winstuitonderneming_1'];
    $_SESSION['finaforte']['txt_winstuitonderneming_2'] = $_POST['txt_winstuitonderneming_2'];
    $_SESSION['finaforte']['txt_winstuitonderneming_3'] = $_POST['txt_winstuitonderneming_3'];
    $_SESSION['finaforte']['txt_salaris_1'] = $_POST['txt_salaris_1'];
    $_SESSION['finaforte']['txt_dividend_1'] = $_POST['txt_dividend_1'];
    $_SESSION['finaforte']['txt_overwinst_1'] = $_POST['txt_overwinst_1'];
    $_SESSION['finaforte']['txt_salaris_2'] = $_POST['txt_salaris_2'];
    $_SESSION['finaforte']['txt_dividend_2'] = $_POST['txt_dividend_2'];
    $_SESSION['finaforte']['txt_overwinst_2'] = $_POST['txt_overwinst_2'];
    $_SESSION['finaforte']['txt_salaris_3'] = $_POST['txt_salaris_3'];
    $_SESSION['finaforte']['txt_dividend_3'] = $_POST['txt_dividend_3'];
    $_SESSION['finaforte']['txt_overwinst_3'] = $_POST['txt_overwinst_3'];
    // on off switch button val
    $_SESSION['finaforte']['myonoffswitch1'] = $_POST['myonoffswitch1'];
    $_SESSION['finaforte']['myonoffswitch3'] = $_POST['myonoffswitch3'];
    $_SESSION['finaforte']['ponoffswitch1'] = $_POST['ponoffswitch1'];
    $_SESSION['finaforte']['pmyonoffswitch3'] = $_POST['pmyonoffswitch3'];
    // p yearly income
    $_SESSION['finaforte']['txt_loondienst'] = $_POST['txt_loondienst'];
    $_SESSION['finaforte']['txt_halfyearp_first'] = $_POST['txt_halfyearp_first'];
    $_SESSION['finaforte']['txt_halfyearp_second'] = $_POST['txt_halfyearp_second'];
    $_SESSION['finaforte']['txt_halfyearp_third'] = $_POST['txt_halfyearp_third'];
    $_SESSION['finaforte']['txt_winstuitondernemingp_1'] = $_POST['txt_winstuitondernemingp_1'];
    $_SESSION['finaforte']['txt_winstuitondernemingp_2'] = $_POST['txt_winstuitondernemingp_2'];
    $_SESSION['finaforte']['txt_winstuitondernemingp_3'] = $_POST['txt_winstuitondernemingp_3'];
    $_SESSION['finaforte']['txt_salarisp_1'] = $_POST['txt_salarisp_1'];
    $_SESSION['finaforte']['txt_dividendp_1'] = $_POST['txt_dividendp_1'];
    $_SESSION['finaforte']['txt_overwinstp_1'] = $_POST['txt_overwinstp_1'];
    $_SESSION['finaforte']['txt_salarisp_2'] = $_POST['txt_salarisp_2'];
    $_SESSION['finaforte']['txt_dividendp_2'] = $_POST['txt_dividendp_2'];
    $_SESSION['finaforte']['txt_overwinstp_2'] = $_POST['txt_overwinstp_2'];
    $_SESSION['finaforte']['txt_salarisp_3'] = $_POST['txt_salarisp_3'];
    $_SESSION['finaforte']['txt_dividendp_3'] = $_POST['txt_dividendp_3'];
    $_SESSION['finaforte']['txt_overwinstp_3'] = $_POST['txt_overwinstp_3'];

    // sol & liq
    $_SESSION['finaforte']['txt_eigenvermogen_1'] = $_POST['txt_eigenvermogen_1'];
    $_SESSION['finaforte']['txt_balanstotaal_1'] = $_POST['txt_balanstotaal_1'];
    $_SESSION['finaforte']['txt_eigenvermogen_2'] = $_POST['txt_eigenvermogen_2'];
    $_SESSION['finaforte']['txt_balanstotaal_2'] = $_POST['txt_balanstotaal_2'];
    $_SESSION['finaforte']['txt_eigenvermogen_3'] = $_POST['txt_eigenvermogen_3'];
    $_SESSION['finaforte']['txt_balanstotaal_3'] = $_POST['txt_balanstotaal_3'];
    $_SESSION['finaforte']['txt_vlottendeactiva_1'] = $_POST['txt_vlottendeactiva_1'];
    $_SESSION['finaforte']['txt_kortvreemdvermogen_1'] = $_POST['txt_kortvreemdvermogen_1'];
    $_SESSION['finaforte']['txt_vlottendeactiva_2'] = $_POST['txt_vlottendeactiva_2'];
    $_SESSION['finaforte']['txt_kortvreemdvermogen_2'] = $_POST['txt_kortvreemdvermogen_2'];
    $_SESSION['finaforte']['txt_vlottendeactiva_3'] = $_POST['txt_vlottendeactiva_3'];
    $_SESSION['finaforte']['txt_kortvreemdvermogen_3'] = $_POST['txt_kortvreemdvermogen_3'];
    // partner sol & liq
    $_SESSION['finaforte']['txt_eigenvermogenp_1'] = $_POST['txt_eigenvermogenp_1'];
    $_SESSION['finaforte']['txt_balanstotaalp_1'] = $_POST['txt_balanstotaalp_1'];
    $_SESSION['finaforte']['txt_eigenvermogenp_2'] = $_POST['txt_eigenvermogenp_2'];
    $_SESSION['finaforte']['txt_balanstotaalp_2'] = $_POST['txt_balanstotaalp_2'];
    $_SESSION['finaforte']['txt_eigenvermogenp_3'] = $_POST['txt_eigenvermogenp_3'];
    $_SESSION['finaforte']['txt_balanstotaalp_3'] = $_POST['txt_balanstotaalp_3'];
    $_SESSION['finaforte']['txt_vlottendeactivap_1'] = $_POST['txt_vlottendeactivap_1'];
    $_SESSION['finaforte']['txt_kortvreemdvermogenp_1'] = $_POST['txt_kortvreemdvermogenp_1'];
    $_SESSION['finaforte']['txt_vlottendeactivap_2'] = $_POST['txt_vlottendeactivap_2'];
    $_SESSION['finaforte']['txt_kortvreemdvermogenp_2'] = $_POST['txt_kortvreemdvermogenp_2'];
    $_SESSION['finaforte']['txt_vlottendeactivap_3'] = $_POST['txt_vlottendeactivap_3'];
    // other cal
    $_SESSION['finaforte']['group1'] = $_POST['group1'];
    $_SESSION['finaforte']['single_slider_first'] = $_POST['single_slider_first'];
    $_SESSION['finaforte']['single_slider_tv1'] = $_POST['single_slider_tv1'];
    $_SESSION['finaforte']['single_slider_ph1'] = $_POST['single_slider_ph1'];
    $_SESSION['finaforte']['pgroup1'] = $_POST['pgroup1'];
    $_SESSION['finaforte']['yn_switch'] = $_POST['yn_switch'];
    $_SESSION['finaforte']['single_slider_2'] = $_POST['single_slider_2'];}

add_action('wp_ajax_backto_calculator_act', 'backto_calculator_act');
add_action('wp_ajax_nopriv_backto_calculator_act', 'backto_calculator_act');

function receive_by_email() {
   
    $_SESSION['finaforte']['send_email'] = "1";    
    $_SESSION['finaforte']['h_totalincome'] = $_POST['h_totalincome'];
    $_SESSION['finaforte']['h_totalincomep'] = $_POST['h_totalincomep'];
    $_SESSION['finaforte']['h_max_hypotheek'] = $_POST['h_max_hypotheek'];
    $_SESSION['finaforte']['h_maandlasten'] = $_POST['h_maandlasten'];
    $_SESSION['finaforte']['h_totalincome_sum'] = $_POST['h_totalincome_sum'];
    $_SESSION['finaforte']['maximale_hypotheek_1'] = $_POST['maximale_hypotheek_1'];
    $_SESSION['finaforte']['hypo_ber_rent_1'] = $_POST['hypo_ber_rent_1'];
    $_SESSION['finaforte']['aflossing_1'] = $_POST['aflossing_1'];
    $_SESSION['finaforte']['bruto_maandlast'] = $_POST['bruto_maandlast'];
    $_SESSION['finaforte']['maandlasten2'] = $_POST['maandlasten2'];
    $_SESSION['finaforte']['maandlasten3'] = $_POST['maandlasten3'];
    $_SESSION['finaforte']['maandlasten4'] = $_POST['maandlasten4'];
    $_SESSION['finaforte']['belastingteruggave_1'] = $_POST['belastingteruggave_1'];
    $_SESSION['finaforte']['netto_per_maand_1'] = $_POST['netto_per_maand_1'];
    $_SESSION['finaforte']['maximale_hypotheek_2'] = $_POST['maximale_hypotheek_2'];
    $_SESSION['finaforte']['hypo_ber_rent_2'] = $_POST['hypo_ber_rent_2'];
    $_SESSION['finaforte']['aflossing_2'] = $_POST['aflossing_2'];
    $_SESSION['finaforte']['belastingteruggave_2'] = $_POST['belastingteruggave_2'];
    $_SESSION['finaforte']['netto_per_maand_2'] = $_POST['netto_per_maand_2'];
    $_SESSION['finaforte']['maximale_hypotheek_3'] = $_POST['maximale_hypotheek_3'];
    $_SESSION['finaforte']['hypo_ber_rent_3'] = $_POST['hypo_ber_rent_3'];
    $_SESSION['finaforte']['aflossing_3'] = $_POST['aflossing_3'];
    $_SESSION['finaforte']['belastingteruggave_3'] = $_POST['belastingteruggave_3'];
    $_SESSION['finaforte']['netto_per_maand_3'] = $_POST['netto_per_maand_3'];
    $_SESSION['finaforte']['maximale_hypotheek_4'] = $_POST['maximale_hypotheek_4'];
    $_SESSION['finaforte']['hypo_ber_rent_4'] = $_POST['hypo_ber_rent_4'];
    $_SESSION['finaforte']['aflossing_4'] = $_POST['aflossing_4'];
    $_SESSION['finaforte']['belastingteruggave_4'] = $_POST['belastingteruggave_4'];
    $_SESSION['finaforte']['netto_per_maand_4'] = $_POST['netto_per_maand_4'];
    // show cal
    $_SESSION['finaforte']['Show_cal_1'] = $_POST['Show_cal_1'];
    $_SESSION['finaforte']['Show_cal_2'] = $_POST['Show_cal_2'];
    $_SESSION['finaforte']['Show_cal_3'] = $_POST['Show_cal_3'];
    $_SESSION['finaforte']['Show_cal_4'] = $_POST['Show_cal_4'];    
    die;
}

add_action('wp_ajax_receive_by_email', 'receive_by_email');
add_action('wp_ajax_nopriv_receive_by_email', 'receive_by_email');

function total_calculation_form() {
    require_once "total-calculation-form.php";   
}

function send_email() {

    ini_set('display_errors', 1);
    ini_set('display_errors', 'on');
        
    global $wpdb;

    $result = array();
  
    $txt_email = $_POST['txt_email'];  
    $txt_name = $_POST['txt_name'];
    
    $thankyou_page = finaforte_esc_attr(finaforte_get_option('thankyou_page'));
    $thankyou_page_url = get_page_link($thankyou_page);

    // take some var from post
    $h_totalincome = $_POST['h_totalincome'];
    $h_totalincomep = $_POST['h_totalincomep'];
    $h_max_hypotheek = $_POST['h_max_hypotheek'];
    $h_maandlasten = $_POST['h_maandlasten'];
    $h_totalincome_sum = $_POST['h_totalincome_sum'];

    $maximale_hypotheek_1 = $_POST['maximale_hypotheek_1'];
    $hypo_ber_rent_1 = $_POST['hypo_ber_rent_1'];
    $calculation_1_rate = finaforte_get_option('calculation_1_rate'); 
    $calculation_1_y = finaforte_get_option('calculation_1_y');   
    $aflossing_1 = $_POST['aflossing_1'];

    $bruto_maandlast = $_POST['bruto_maandlast'] ? round($_POST['bruto_maandlast']) : 0.00;
    $maandlasten2 = $_POST['maandlasten2'] ? round($_POST['maandlasten2']) : 0.00;
    $maandlasten3 = $_POST['maandlasten3'] ? round($_POST['maandlasten3']) : 0.00;
    $maandlasten4 = $_POST['maandlasten4'] ? round($_POST['maandlasten4']) : 0.00;

    $belastingteruggave_1 = $_POST['belastingteruggave_1'];
    $netto_per_maand_1 = $_POST['netto_per_maand_1'];
    $maximale_hypotheek_2 = $_POST['maximale_hypotheek_2'];
    $hypo_ber_rent_2 = $_POST['hypo_ber_rent_2'];
    $calculation_2_rate = finaforte_get_option('calculation_2_rate'); 
    $calculation_2_y = finaforte_get_option('calculation_2_y');   
    $aflossing_2 = $_POST['aflossing_2'];
    $belastingteruggave_2 = $_POST['belastingteruggave_2'];
    $netto_per_maand_2 = $_POST['netto_per_maand_2'];
    $maximale_hypotheek_3 = $_POST['maximale_hypotheek_3'];
    $hypo_ber_rent_3 = $_POST['hypo_ber_rent_3'];
    $calculation_3_rate = finaforte_get_option('calculation_3_rate'); 
    $calculation_3_y = finaforte_get_option('calculation_3_y');   
    $aflossing_3 = $_POST['aflossing_3'];
    $belastingteruggave_3 = $_POST['belastingteruggave_3'];
    $netto_per_maand_3 = $_POST['netto_per_maand_3'];
    $maximale_hypotheek_4 = $_POST['maximale_hypotheek_4'];
    $hypo_ber_rent_4 = $_POST['hypo_ber_rent_4'];
    $calculation_4_rate = finaforte_get_option('calculation_4_rate'); 
    $calculation_4_y = finaforte_get_option('calculation_4_y');   
    $aflossing_4 = $_POST['aflossing_4'];
    $belastingteruggave_4 = $_POST['belastingteruggave_4'];
    $netto_per_maand_4 = $_POST['netto_per_maand_4'];
    /*show cal*/
    $Show_cal_1 = $_POST['Show_cal_1'];
    $Show_cal_2 = $_POST['Show_cal_2'];
    $Show_cal_3 = $_POST['Show_cal_3'];
    $Show_cal_4 = $_POST['Show_cal_4'];
    /*SMTP Details*/
    $advice_contact = finaforte_get_option('advice_contact');
    $smtp_server_add = finaforte_get_option('smtp_server_add');
    $smtp_from_email = finaforte_get_option('smtp_from_email');
    $smtp_from_name = finaforte_get_option('smtp_from_name');
    $smtp_username = finaforte_get_option('smtp_username');
    $smtp_password = finaforte_get_option('smtp_password');
    $smtp_port_type = finaforte_get_option('smtp_port_type');
    $smtp_port = finaforte_get_option('smtp_port');
    $cc1_email = finaforte_get_option('cc1_email');
    $cc2_email = finaforte_get_option('cc2_email');
    $cc1_email = $cc1_email != '' ? sanitize_email($cc1_email) : '';
    $cc2_email = $cc2_email != '' ? sanitize_email($cc2_email) : '';
    
    if(!empty($cc1_email)){

        if(!empty($cc2_email)){
            $headers = array(
                            'From: Finaforte', 
                            'CC: '.$cc1_email, 
                            'CC: '.$cc2_email
                            );
        } 
        $headers = array(
                        'From: Finaforte', 
                        'CC: '.$cc1_email
                        );
    } elseif(!empty($cc2_email)){
        $headers = array(
                        'From: Finaforte', 
                        'CC: '.$cc2_email
                        );
    } else {
        $headers = '';
    }

    $msg_body = '';
    
    $email_message = finaforte_get_option('email_message');
    $email_subject = finaforte_get_option('email_subject') ? finaforte_get_option('email_subject') : 'Please find your calculation';

    /* include mail body content*/
    require_once "ff_mail_body.php"; 
    require_once "ff_pdf_generator.php";    
    
    if($smtp_server_add == ''){

        $sent = wp_mail( $txt_email, $email_subject, $msg_body, $headers, $attachments = $pdf_dest );
        if($sent) {            
            $result['success'] = true;
			unset($_SESSION);
    		session_destroy();
            $result['thankyou_page_url'] = $thankyou_page_url;
           
        } else {
            $result['success'] = false;
        }
    }
    else {
        // smtp details
        $smtp_server_add = $smtp_server_add != '' ? $smtp_server_add : '';
        $smtp_from_email = $smtp_from_email != '' ? $smtp_from_email : '';
        $smtp_from_name = $smtp_from_name != '' ? $smtp_from_name : '';
        $smtp_username = $smtp_username != '' ? $smtp_username : '';
        $smtp_password = $smtp_password != '' ? $smtp_password : '';
        $smtp_port_type = $smtp_port_type != '' ? $smtp_port_type : '';
        $smtp_port = $smtp_port != '' ? $smtp_port : '';
        $cc1_email = $cc1_email != '' ? $cc1_email : '';
        $cc2_email = $cc2_email != '' ? $cc2_email : '';    
        
        // mail send functions by smtp
        require_once "ff_mail_function.php";

        if ($mail->send()) {
            $result['success'] = true;
			unset($_SESSION);
    		session_destroy();
            $result['thankyou_page_url'] = $thankyou_page_url;
        } else{
            $result['success'] = false;           
        }
    }

    echo json_encode($result);
   die;
}
function wpse27856_set_content_type(){
    return "text/html";
}
add_filter( 'wp_mail_content_type','wpse27856_set_content_type' );

add_action('wp_ajax_send_email', 'send_email');
add_action('wp_ajax_nopriv_send_email', 'send_email');

add_action('wp_ajax_view_total_calculation2', 'view_total_calculation2');
add_action('wp_ajax_nopriv_view_total_calculation2', 'view_total_calculation2');

function view_total_calculation2() {
    do_action( 'clean_post_cache',  $_POST['pid'] );
    wp_cache_flush();
    unset( $_SESSION['finaforte']['send_email']);
    $_SESSION['finaforte']['view_totalcalculation'] = "1";
    $result['success'] = true;
    echo json_encode($result);
    die;
}

function email_send_form() {
    require_once "email-form.php";
}
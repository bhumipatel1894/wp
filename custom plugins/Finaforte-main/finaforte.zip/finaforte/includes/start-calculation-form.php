<?php 
/**
 * start calculation form content
 *
 * @package Fina Forte
 * @since 1.0
 */

require_once "admin-options.php";

?>
<style type="text/css"> 
    .radiobox2 .checkmark{/*freelancer*/
        background-color: <?php echo $freelancer_bg_clr; ?> !important;
       
    }   
    .radiobox2 strong{/*freelancer*/
       
        color: <?php echo $freelancer_text_clr ; ?>!important; 
    }   
    .radiobox3 .checkmark{/*vof*/
        background-color: <?php echo $vof_bg_clr; ?> !important;
       
    }   
    .radiobox3 strong{/*vof*/
       
        color: <?php echo $vof_text_clr; ?> !important;
    }   
    .radiobox4 .checkmark{/*bvdga*/
        background-color: <?php echo $bv_dga_bg_clr; ?> !important;
       
    }   
     .radiobox4 strong{/*bvdga*/
       
        color: <?php echo $bv_dga_text_clr; ?> !important;
    }   
    .radiobox1 .checkmark{/*loonliest*/
        background-color: <?php echo $loondienst_bg_clr; ?> !important;
        
    }   
     .radiobox1 strong{/*loonliest*/
       
        color: <?php echo $loondienst_text_clr; ?> !important;
    }   

    .sep-after::after, .sep-before::before {background: <?php echo $divider_clr; ?>;}
    .demo-output .theme-green .scale ins,.data-partner-radio label, .slider-container .back-bar .pointer-label{color: <?php echo $subtitle_color; ?>;}
    .theme-green .scale span{border-color: <?php echo $subtitle_color; ?>}
    .demo-output .theme-green .scale ins, .slider-container .back-bar .pointer-label{ font-size: <?php echo $text_font_size; ?>px; }
    .data-partner-radio label{font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 2; ?>px;}
    .demo-output .theme-green .back-bar .pointer{background: <?php echo $subtitle_color; ?>;}
    .demo-output .theme-green .back-bar .selected-bar{
        background: <?php echo $backgroundcolor; ?>; /* Old browsers */
    background: -moz-linear-gradient(top, <?php echo $backgroundcolor; ?> 0%, <?php echo $backgroundcolor; ?> 44%, <?php echo $subtitle_color; ?> 44%, <?php echo $subtitle_color; ?> 54%, <?php echo $subtitle_color; ?> 54%, <?php echo $backgroundcolor; ?> 54%, <?php echo $backgroundcolor; ?> 54%, <?php echo $backgroundcolor; ?> 99%); /* FF3.6-15 */
    background: -webkit-linear-gradient(top, <?php echo $backgroundcolor; ?> 0%, <?php echo $backgroundcolor; ?> 44%, <?php echo $subtitle_color; ?> 44%, <?php echo $subtitle_color; ?> 54%, <?php echo $subtitle_color; ?> 54%, <?php echo $backgroundcolor; ?> 54%, <?php echo $backgroundcolor; ?> 54%, <?php echo $backgroundcolor; ?> 99%); /* Chrome10-25,Safari5.1-6 */
    background: linear-gradient(to bottom,<?php echo $backgroundcolor; ?> 0%, <?php echo $backgroundcolor; ?> 44%, <?php echo $subtitle_color; ?> 44%, <?php echo $subtitle_color; ?> 54%, <?php echo $subtitle_color; ?> 54%, <?php echo $backgroundcolor; ?> 54%, <?php echo $backgroundcolor; ?> 54%, <?php echo $backgroundcolor; ?> 99%);
    }
    .demo-output .theme-green .back-bar {
    background: <?php echo $backgroundcolor; ?>; /* Old browsers */
    background: -moz-linear-gradient(top, <?php echo $backgroundcolor; ?> 0%, <?php echo $backgroundcolor; ?> 44%, #dbe4e3 44%, #dbe4e3 44%, #dbe4e3 54%, <?php echo $backgroundcolor; ?> 54%, <?php echo $backgroundcolor; ?> 54%, <?php echo $backgroundcolor; ?> 99%); /* FF3.6-15 */
    background: -webkit-linear-gradient(top, <?php echo $backgroundcolor; ?> 0%, <?php echo $backgroundcolor; ?> 44%, #dbe4e3 44%, #dbe4e3 44%, #dbe4e3 54%, <?php echo $backgroundcolor; ?> 54%, <?php echo $backgroundcolor; ?> 54%, <?php echo $backgroundcolor; ?> 99%); /* Chrome10-25,Safari5.1-6 */
    background: linear-gradient(to bottom, <?php echo $backgroundcolor; ?> 0%, <?php echo $backgroundcolor; ?> 44%, #dbe4e3 44%, #dbe4e3 44%, #dbe4e3 54%, <?php echo $backgroundcolor; ?> 54%, <?php echo $backgroundcolor; ?> 54%, <?php echo $backgroundcolor; ?> 99%);
}
    
    .onoffswitch-inner:before,.onoffswitch-inner:after,.partner input:checked ~ .checkmark {background-color:<?php echo $toggle_bg_clr; ?>; color: <?php echo $toggle_text_clr; ?>; }
    .partner .checkmark {background-color: #a7a7a7;}
    .start-right .final-value ul li h3, .start-right .final-value ul li h4, h4.small-heading {color: <?php echo $subtitle_color; ?>; font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px;}
    .col-form-label{color:<?php echo $gentext_color; ?>; font-size: <?php echo $gentext_font_size; ?>px; line-height: <?php echo $gentext_font_size + 4; ?>px;}
    a {color: <?php echo $subtitle_color; ?>;}
    #p_notcompleted, #div_holdingtext, #pdiv_holdingtext { border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo $txt_border_color; ?> }
    .radiobox2 input:checked ~ .checkmark{
    background-color: #fff;
    border-bottom: 2px solid <?php echo $freelancer_icon_clr; ?>;
}
.onoffswitch-checkbox:checked + .onoffswitch-label .onoffswitch-switch {background-color: <?php echo $toggle_text_clr; ?>}
.onoffswitch-switch {background: <?php echo $toggle_text_clr; ?>;}
.radiobox2 input:checked ~ .checkmark:after{    border-top: 10px solid <?php echo $freelancer_icon_clr; ?>;}
.radiobox3 input:checked ~ .checkmark {
    background-color: #fff;
    border-bottom: 2px solid <?php echo $vof_icon_clr; ?>;
}
.radiobox3 input:checked ~ .checkmark:after {
    border-top: 10px solid <?php echo $vof_icon_clr; ?>;
}
.radiobox4 input:checked ~ .checkmark {
    background-color: #fff;
    border-bottom: 2px solid <?php echo $bv_dga_icon_clr; ?>;
}
.radiobox4 input:checked ~ .checkmark:after {
    border-top: 10px solid <?php echo $bv_dga_icon_clr; ?>;
}

.radiobox1 input:checked ~ .checkmark{
    background-color: #fff;
    border-bottom: 2px solid <?php echo $loondienst_icon_clr; ?>;
}
.radiobox1 input:checked ~ .checkmark:after {
    border-top: 10px solid <?php echo $loondienst_icon_clr; ?>;
}

.brd-cover-div { border: 1px solid <?php echo $txt_border_color; ?>; }
@media screen and (max-width: 767px){
    .radiobox2 p{
        background: <?php echo $freelancer_icon_clr.';'; ?>
    }
    .radiobox3 p{
        background: <?php echo $vof_icon_clr.';'; ?>
    }
    .radiobox4 p{
        background: <?php echo $bv_dga_icon_clr.';'; ?>
    }
    .radiobox1 p{
        background: <?php echo $loondienst_icon_clr.';'; ?>    
    }
}
</style>
<div id="div_calculationform" data-pid="<?php echo get_queried_object_id(); ?>">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">   
    <div class="start-page">
        <div class="container">
            
            <div class="start-data">
                <div class="row">               
                    <div class="col-md-8 stat-left">
                        <div class="brd-cover-div">
                        <div class="row-min" style="background: <?php echo $backgroundcolor; ?>">
                        <?php $backgroundcolor = !empty(finaforte_get_option('theme_bg_color') ) ? finaforte_get_option('theme_bg_color') : '#f5f5f5'; ?>
                        <div class="start-box start-box-separate" id="div_box1" style="background: <?php echo $backgroundcolor; ?>">
                            
                            <h2 class="big-heading text-center" style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px; color: <?php echo $subtitle_color; ?>;" >Selecteer uw rechtsvorm</h2>
                            <div class="row radiobox-row">
                                <div class="col-md-4">
                                    <label class="rechtsvorm radiobox2">                                          
                                        <input type="radio" name="group1" value="in1" id="group1_in1" data-id="<?php if(isset($_SESSION['finaforte']['group1']) && $_SESSION['finaforte']['group1'] == 'in1'){ echo 'in1'; } ?>" >
                                        <span class="checkmark" style="border-radius: <?php echo $border_radius; ?>px; "></span>
                                        <?php $img2 = FINAFORTE_URL.'/assets/images/user1.png'; ?>   
                                        <p><span class="icon-box" style="background: <?php echo $freelancer_icon_clr.';'; ?>"><img src=' <?php echo $img2; ?>' /></span><strong style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px; ">Freelancer /<br /> Eenmanszaak</strong></p>  
                                    </label>
                                </div>
                                <div class="col-md-4">
                                    <label class="rechtsvorm radiobox3">                                          
                                        <input type="radio" name="group1" value="tv1" id="group1_tv1" data-id="<?php if(isset($_SESSION['finaforte']['group1']) && $_SESSION['finaforte']['group1'] == 'tv1'){ echo 'tv1'; } ?>"  />                                          
                                        <span class="checkmark" style="overflow: hidden; border-radius: <?php echo $border_radius; ?>px;"></span> 
                                        <?php $img3 = FINAFORTE_URL.'/assets/images/group.png'; ?>                                            
                                        <p><span class="icon-box" style="background: <?php echo $vof_icon_clr.';'; ?>"><img src=' <?php echo $img3; ?>' /></span><strong style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px;">V.O.F</strong></p>   
                                                          
                                    </label>
                                </div>
                                <div class="col-md-4">
                                    <label class="rechtsvorm radiobox4">                                          
                                        <input type="radio" name="group1" value="ph1" id="group1_ph1" data-id="<?php if(isset($_SESSION['finaforte']['group1']) && $_SESSION['finaforte']['group1'] == 'ph1'){ echo 'ph1'; } ?>" >                                          
                                        <span class="checkmark" style="border-radius: <?php echo $border_radius; ?>px; "></span>
                                        <?php $img4 = FINAFORTE_URL.'assets/images/building-1.png'; ?>   
                                        <p><span class="icon-box" style="background: <?php echo $bv_dga_icon_clr.';'; ?>"><img src=' <?php echo $img4; ?>' /></span><strong style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px; ">BV / DGA</strong></p>
                                    </label>
                                </div>
                            </div>  
                            
                        </div>
                            <div class="start-box pad-remove" id="div_box111">              
                                <div id="in1" class="desc" data-box="1">
                                 <div class="sec-sep sec-sep1" style="background: <?php echo $backgroundcolor; ?>">
                                    <h2 class="big-heading text-center" style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px; color: <?php echo $subtitle_color; ?> ;" ><span> Hoeveel jaar bent u al ondernemer? <a href="javascript:;" title="" data-placement="bottom" data-toggle="popover" data-content="<?php echo $tooltip_select_year; ?>" data-original-title="" aria-describedby="popover52623"><i class="fa fa-info-circle" aria-hidden="true"></i></a></span> </h2>
                                    <div class="demo-output demo-output2 slider1">
                                    <?php $single_slider_first = (!empty($_SESSION['finaforte']['single_slider_first'])) ? $_SESSION['finaforte']['single_slider_first'] : '0' ?>
                                        <input id="single_slider_first" type="hidden" value="<?php echo $single_slider_first; ?>"/>
                                        <div class="gray-line1"></div>
                                        <div class="gray-line2"></div>
                                        <div class="gray-line3"></div>
                                        <div class="gray-line4"></div>
                                    </div>
                                </div>

                              <div class="sec-sep sec-sep2" style="display:none; background: <?php echo $backgroundcolor; ?>">
                                    <div class="check-swich" id="div_holding1" >
                                        <strong style="font-size:<?php echo $gentext_font_size; ?>px; line-height: 29px; color: <?php echo $gentext_color; ?>">zzp werkzaamheden gelijk aan laatste loondienstverband?</strong>
                                        <div class="onoffswitch">
                                            <?php $myonoffswitch1 = isset($_SESSION['finaforte']['myonoffswitch1']) ? $_SESSION['finaforte']['myonoffswitch1'] : '0'; ?>
                                            <input type="checkbox" name="onoffswitch1" class="onoffswitch-checkbox" id="myonoffswitch1" checked="checked" value="<?php echo $_SESSION['finaforte']['myonoffswitch1']; ?>" onclick="on_off_switch();">
                                            <label class="onoffswitch-label" for="myonoffswitch1">
                                                <span class="onoffswitch-inner"></span>
                                                <span class="onoffswitch-switch"></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                 <div class="sec-sep sec-sep3" style="background: <?php echo $backgroundcolor; ?>">
                                    <div class="box-msg2" id="div_holdingtext1" style=" border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ; font-size:<?php echo $gentext_font_size; ?>px; line-height:<?php echo $gentext_font_size + 4; ?>px; color: <?php echo $gentext_color; ?>"> 
                                        Helaas, een hypotheek als zzp korter dan 1 jr kan alleen indien uw werkzaamheden gelijk zijn aan uw laatste dienstverband.
                                    </div> 
                                </div> 

                                </div>                            
                                <div id="tv1" class="desc" data-box="7">
                                  <div class="sec-sep sec-sep4" style="background: <?php echo $backgroundcolor; ?>">
                                    <h2 class="big-heading text-center" style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px; color: <?php echo $subtitle_color; ?>"><span> Hoeveel jaar bent u al ondernemer? <a href="javascript:;" title="" data-placement="bottom" data-toggle="popover" data-content="<?php echo $tooltip_select_year; ?>" data-original-title="" aria-describedby="popover52623"><i class="fa fa-info-circle" aria-hidden="true"></i></a></span> </h2>
                                    <div class="demo-output slider2">
                                        <?php $single_slider_tv1 = (!empty($_SESSION['finaforte']['single_slider_tv1'])) ? $_SESSION['finaforte']['single_slider_tv1'] : '0' ?>
                                        <input class="single-slider" id="single_slider_tv1" type="hidden" value="<?php echo $single_slider_tv1; ?> "/>
                                        <div class="gray-line1"></div>
                                        <div class="gray-line2"></div>
                                        <div class="gray-line3"></div>
                                    </div> 
                                   </div>  

                                </div>                            
                                <div id="ph1" class="desc" data-box="8">
                                  <div class="sec-sep sec-sep5" style="background: <?php echo $backgroundcolor; ?>">
                                    <h2 class="big-heading text-center" style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px; color: <?php echo $subtitle_color; ?>" ><span> Hoeveel jaar bent u al ondernemer? <a href="javascript:;" title="" data-placement="bottom" data-toggle="popover" data-content="<?php echo $tooltip_select_year; ?>" data-original-title="" aria-describedby="popover52623"><i class="fa fa-info-circle" aria-hidden="true"></i></a></span> </h2>
                                    <div class="demo-output slider3">
                                        <?php $single_slider_ph1 = (!empty($_SESSION['finaforte']['single_slider_ph1'])) ? $_SESSION['finaforte']['single_slider_ph1'] : '0' ?>
                                        <input class="single-slider" id="single_slider_ph1" type="hidden" value="<?php echo $single_slider_ph1; ?>"/>
                                        <div class="gray-line1"></div>
                                        <div class="gray-line2"></div>
                                        <div class="gray-line3"></div>
                                    </div>
                                   </div>

                                  <div class="sec-sep sec-sep6 sec-switch" style="background: <?php echo $backgroundcolor; ?>">
                                    <div class="check-swich" id="div_holding" >
                                        <strong style="font-size:<?php echo $gentext_font_size; ?>px; line-height: 29px; color: <?php echo $gentext_color; ?>;">Is uw onderneming onderdeel van een holding?</strong>
                                        <div class="onoffswitch">
                                            <?php $myonoffswitch3 = isset($_SESSION['finaforte']['myonoffswitch3']) ? $_SESSION['finaforte']['myonoffswitch3'] : '0'; ?>
                                            <input type="checkbox" name="onoffswitch3" class="onoffswitch-checkbox" id="myonoffswitch3" checked="checked" value="<?php echo $myonoffswitch3; ?>">
                                            <label class="onoffswitch-label" for="myonoffswitch3">
                                                <span class="onoffswitch-inner"></span>
                                                <span class="onoffswitch-switch"></span>
                                            </label>
                                        </div>
                                     </div>
                                    </div>

                                    <div class="sec-sep sec-sep7" style="background: <?php echo $backgroundcolor; ?>">
                                    <div class="box-msg2" id="div_holdingtext" style="border-radius: <?php echo $border_radius; ?>px; font-size:<?php echo $gentext_font_size; ?>px; line-height: <?php echo $gentext_font_size + 4; ?>px; color: <?php echo $gentext_color; ?>;"> 
                                        Heeft U meerdere BV's of een holding werk-maatschappij structuur? Gebruik dan altijd de gegevens uit de geconsolideerde jaarcijfers.
                                    </div>
                                    </div>


                                </div>
                            </div>  
                            <?php $backgroundcolor = !empty(finaforte_get_option('theme_bg_color') ) ? finaforte_get_option('theme_bg_color') : '#f5f5f5'; ?>                      
                            <div class="start-box pad-remove" id="div_box2" style="display:none; background: <?php echo $backgroundcolor; ?>;">
                                <div class="jaar-value">
                                     <div class="sec-sep sec-sep8 sep-after sep-before" style="background: <?php echo $backgroundcolor; ?>">
                                    <h2 class="big-heading text-center" style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px; color: <?php echo $subtitle_color; ?> ;"><span>Vul hier uw inkomen in <a href="javascript:;" title="" data-placement="bottom" data-toggle="popover" data-content="<?php echo $tooltip_salary; ?>"><i class="fa fa-info-circle" aria-hidden="true"></i></a></span> 
                                        </h2>
                                    <div class="row1">
                                        <div id="div_forhalfyear" style="width:100%;">
                                            <h4 class="big-sub-heading big-heading-black text-center" style="display:none;"><span>Eerste 1/2 jaar</span> </h4>
                                            <div class="row justify-content-md-center">
                                                <div class="col-md-6 income-data">
                                                    <div class="form-group text-center">                                                         
                                                        <div class="jaar-value-box">    
                                                            <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                            <input class="form-control numbers" pattern="[0-9]*" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" maxlength="256" dir="rtl" type="number" pattern="[0-9]*" placeholder="Laatste jaarsalaris" name="txt_halfyear_third" id="txt_halfyear_third" value="<?php if(isset($_SESSION['finaforte']['txt_halfyear_third'] )){ echo $_SESSION['finaforte']['txt_halfyear_third']; } ?>" onkeyup="incomedata_calculation()">    
                                                        </div>
                                                    </div>                                    
                                                    <div class="form-group text-center">
                                                        
                                                        <div class="jaar-value-box">    
                                                            <i class="fa fa-eur" aria-hidden="true"></i>                    
                                                            <input pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" maxlength="256" dir="rtl" type="number" pattern="[0-9]*" placeholder="Winst uit onderneming" name="txt_halfyear_first" id="txt_halfyear_first" value="<?php if(isset($_SESSION['finaforte']['txt_halfyear_first'] )){ echo $_SESSION['finaforte']['txt_halfyear_first']; } ?>" onkeyup="incomedata_calculation()">
                                                        </div>                   
                                                    </div>
                                                    <div class="form-group text-center">
                                                           
                                                        <div class="jaar-value-box">    
                                                            <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                            <input class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" maxlength="256" dir="rtl" type="number" pattern="[0-9]*" pattern="[0-9]*" placeholder="Prognose hele jaar" name="txt_halfyear_second" id="txt_halfyear_second" value="<?php if(isset($_SESSION['finaforte']['txt_halfyear_second'] )){ echo $_SESSION['finaforte']['txt_halfyear_second']; } ?>" onkeyup="incomedata_calculation()">  
                                                        </div>                                  
                                                    </div>
                                                     
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row" id="div_winstuitonderneming" style="display:none;">
                                            <div class="col-md-4" id="div_winstuitonderneming_1">
                                                <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color; ?> ;">Laatste jaar</h5>
                                                <div class="form-group">
                                                    
                                                    <div class="jaar-value-box">
                                                        <i class="fa fa-eur" aria-hidden="true"></i>
                                                        <input class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" type="number" pattern="[0-9]*" pattern="[0-9]*" placeholder="Winst uit onderneming" name="txt_winstuitonderneming_1" id="txt_winstuitonderneming_1" value="<?php if(isset($_SESSION['finaforte']['txt_winstuitonderneming_1'] )){ echo $_SESSION['finaforte']['txt_winstuitonderneming_1']; } ?>" onkeyup="incomedata_calculation()">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4" id="div_winstuitonderneming_2">
                                                <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color; ?> ;">2 jaar geleden</h5>
                                                <div class="form-group">
                                                    
                                                    <div class="jaar-value-box">
                                                        <i class="fa fa-eur" aria-hidden="true"></i>
                                                        <input class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" type="number" pattern="[0-9]*" name="txt_winstuitonderneming_2" placeholder="Winst uit onderneming" id="txt_winstuitonderneming_2" value="<?php if(isset($_SESSION['finaforte']['txt_winstuitonderneming_2'] )){ echo $_SESSION['finaforte']['txt_winstuitonderneming_2']; } ?>" onkeyup="incomedata_calculation()">
                                                    </div>                                      
                                                </div>                                      
                                            </div>
                                            <div class="col-md-4" id="div_winstuitonderneming_3">
                                                <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color; ?> ;">3 jaar geleden</h5>
                                                <div class="form-group">
                                                    
                                                    <div class="jaar-value-box">
                                                        <i class="fa fa-eur" aria-hidden="true"></i>
                                                        <input class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" type="number" pattern="[0-9]*" placeholder="Winst uit onderneming" name="txt_winstuitonderneming_3" id="txt_winstuitonderneming_3" value="<?php if(isset($_SESSION['finaforte']['txt_winstuitonderneming_3'] )){ echo $_SESSION['finaforte']['txt_winstuitonderneming_3']; } ?>" onkeyup="incomedata_calculation()">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                          
                                        <div class="col-md-4" id="div_inkomensgegevens_1">
                                            <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color; ?> ;">Laatste jaar</h5>
                                            <div class="form-group">
                                                
                                                <div class="jaar-value-box">    
                                                    <i class="fa fa-eur" aria-hidden="true"></i>                                    
                                                    <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Salaris" name="txt_salaris[]" id="txt_salaris_1" value="<?php if(isset($_SESSION['finaforte']['txt_salaris_1'] )){ echo $_SESSION['finaforte']['txt_salaris_1']; } ?>" onkeyup="incomedata_calculation()">
                                                </div>                                      
                                            </div>
                                            <div class="form-group">
                                                
                                                <div class="jaar-value-box">    
                                                    <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                    <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Dividend" name="txt_dividend[]" id="txt_dividend_1" value="<?php if(isset($_SESSION['finaforte']['txt_dividend_1'] )){ echo $_SESSION['finaforte']['txt_dividend_1']; } ?>" onkeyup="incomedata_calculation()">  
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                
                                                <div class="jaar-value-box">    
                                                    <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                    <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Overwinst / Winst BV" name="txt_overwinst[]" id="txt_overwinst_1" value="<?php if(isset($_SESSION['finaforte']['txt_overwinst_1'] )){ echo $_SESSION['finaforte']['txt_overwinst_1']; } ?>" onkeyup="incomedata_calculation()">    
                                                </div>                                  
                                            </div>
                                        </div>
                                        <div class="col-md-4" id="div_inkomensgegevens_2">
                                            <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color; ?> ;">2 jaar geleden</h5>
                                            <div class="form-group">
                                                
                                                <div class="jaar-value-box">    
                                                    <i class="fa fa-eur" aria-hidden="true"></i>                                    
                                                    <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Salaris" name="txt_salaris[]" id="txt_salaris_2" value="<?php if(isset($_SESSION['finaforte']['txt_salaris_2'] )){ echo $_SESSION['finaforte']['txt_salaris_2']; } ?>" onkeyup="incomedata_calculation()">
                                                </div>                                      
                                            </div>
                                            <div class="form-group">
                                                 
                                                <div class="jaar-value-box">    
                                                    <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                    <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Dividend" name="txt_dividend[]" id="txt_dividend_2" value="<?php if(isset($_SESSION['finaforte']['txt_dividend_2'] )){ echo $_SESSION['finaforte']['txt_dividend_2']; } ?>" onkeyup="incomedata_calculation()">  
                                                </div>                                  
                                            </div>
                                            <div class="form-group">
                                                 
                                                <div class="jaar-value-box">    
                                                    <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                    <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Overwinst / Winst BV" name="txt_overwinst[]" id="txt_overwinst_2" value="<?php if(isset($_SESSION['finaforte']['txt_overwinst_2'] )){ echo $_SESSION['finaforte']['txt_overwinst_2']; } ?>" onkeyup="incomedata_calculation()">    
                                                </div>                                  
                                            </div>
                                        </div>
                                        <div class="col-md-4" id="div_inkomensgegevens_3">
                                            <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color; ?> ;">3 jaar geleden</h5>
                                            <div class="form-group">
                                                
                                                <div class="jaar-value-box">    
                                                    <i class="fa fa-eur" aria-hidden="true"></i>                                    
                                                    <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Salaris" name="txt_salaris[]" id="txt_salaris_3" value="<?php if(isset($_SESSION['finaforte']['txt_salaris_3'] )){ echo $_SESSION['finaforte']['txt_salaris_3']; } ?>" onkeyup="incomedata_calculation()">
                                                </div>                                      
                                            </div>
                                            <div class="form-group">
                                                
                                                <div class="jaar-value-box">    
                                                    <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                    <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Dividend" name="txt_dividend[]" id="txt_dividend_3" value="<?php if(isset($_SESSION['finaforte']['txt_dividend_3'] )){ echo $_SESSION['finaforte']['txt_dividend_3']; } ?>" onkeyup="incomedata_calculation()">  
                                                </div>                                  
                                            </div>
                                            <div class="form-group">
                                                 
                                                <div class="jaar-value-box">    
                                                    <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                    <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Overwinst / Winst BV" name="txt_overwinst[]" id="txt_overwinst_3" value="<?php if(isset($_SESSION['finaforte']['txt_overwinst_3'] )){ echo $_SESSION['finaforte']['txt_overwinst_3']; } ?>" onkeyup="incomedata_calculation()">    
                                                </div>                                  
                                            </div>
                                        </div>
                                    </div>
                                     </div>
                                    </div>
                                <div class="sec-sep sec-sep15" style="background: <?php echo $backgroundcolor; ?>">
                                     <h2 class="big-heading text-center" style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px; color: <?php echo $subtitle_color; ?> ;"><?php echo $solva_liq_header_text; ?></h2>
                                     <div class="description text-center" id="" style=" border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ; font-size:<?php echo $gentext_font_size; ?>px; line-height:<?php echo $gentext_font_size + 4; ?>px; color: <?php echo $gentext_color; ?>"> 
                                       <?php echo $solva_liq_header_descri; ?>
                                    </div> 

                                </div>
                                 <div class="sec-sep sec-sep10 sep-after" style="background: <?php echo $backgroundcolor; ?>">
                                    <div id="accordion" class="accordion-value">
                                        <div class="card">
                                            <div class="row">
                                            <div class="col-md-12">
                                            <div class="card-header collapsed" id="headingOne" data-toggle="collapse" href="#collapse_1" aria-expanded="true" aria-controls="collapse_1">
                                                <a class="card-title" id="card_collapse_11" style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px; color: <?php echo $subtitle_color; ?> ;">
                                                    <?php echo $solvabiliteit_text; ?>
                                                </a>
                                             </div>
                                             <div id="collapse_1" class="card-body collapse" role="tabpanel" aria-labelledby="headingOne">
                                                <div class="row">
                                                    <div class="col-md-4" id="div_solvabiliteit_1">
                                                        <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color; ?> ;">Laatste jaar</h5>
                                                        <div class="form-group">
                                                            
                                                            <div class="jaar-value-box">    
                                                                <i class="fa fa-eur" aria-hidden="true"></i>                                    
                                                                <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Eigen vermogen" name="txt_eigenvermogen[]" id="txt_eigenvermogen_1" value="<?php if(isset($_SESSION['finaforte']['txt_eigenvermogen_1'] )){ echo $_SESSION['finaforte']['txt_eigenvermogen_1']; } ?>" onkeyup="calculate_solvabiliteit()">
                                                            </div>                                      
                                                        </div>
                                                        <div class="form-group">
                                                             
                                                            <div class="jaar-value-box">    
                                                                <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                                <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Balanstotaal" name="txt_balanstotaal[]" id="txt_balanstotaal_1" value="<?php if(isset($_SESSION['finaforte']['txt_balanstotaal_1'] )){ echo $_SESSION['finaforte']['txt_balanstotaal_1']; } ?>" onkeyup="calculate_solvabiliteit()">  
                                                            </div>                                  
                                                        </div>                                                    
                                                    </div>
                                                    <div class="col-md-4" id="div_solvabiliteit_2">
                                                        <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color; ?> ;">2 jaar geleden</h5>
                                                        <div class="form-group">
                                                            
                                                            <div class="jaar-value-box">    
                                                                <i class="fa fa-eur" aria-hidden="true"></i>                                    
                                                                <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Eigen vermogen" name="txt_eigenvermogen[]" id="txt_eigenvermogen_2" value="<?php if(isset($_SESSION['finaforte']['txt_eigenvermogen_2'] )){ echo $_SESSION['finaforte']['txt_eigenvermogen_2']; } ?>" onkeyup="calculate_solvabiliteit()">
                                                            </div>                                      
                                                        </div>
                                                        <div class="form-group">
                                                            
                                                            <div class="jaar-value-box">    
                                                                <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                                <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Balanstotaal" name="txt_balanstotaal[]" id="txt_balanstotaal_2" value="<?php if(isset($_SESSION['finaforte']['txt_balanstotaal_2'] )){ echo $_SESSION['finaforte']['txt_balanstotaal_2']; } ?>" onkeyup="calculate_solvabiliteit()">  
                                                            </div>                                  
                                                        </div>                                                    
                                                    </div>
                                                    <div class="col-md-4" id="div_solvabiliteit_3">
                                                        <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color; ?> ;">3 jaar geleden</h5>
                                                        <div class="form-group">
                                                            
                                                            <div class="jaar-value-box">    
                                                                <i class="fa fa-eur" aria-hidden="true"></i>                                    
                                                                <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Eigen vermogen" name="txt_eigenvermogen[]" id="txt_eigenvermogen_3" value="<?php if(isset($_SESSION['finaforte']['txt_eigenvermogen_3'] )){ echo $_SESSION['finaforte']['txt_eigenvermogen_3']; } ?>" onkeyup="calculate_solvabiliteit()">
                                                            </div>                                      
                                                        </div>
                                                        <div class="form-group">
                                                           
                                                            <div class="jaar-value-box">
                                                                <i class="fa fa-eur" aria-hidden="true"></i>
                                                                <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Balanstotaal" name="txt_balanstotaal[]" id="txt_balanstotaal_3" value="<?php if(isset($_SESSION['finaforte']['txt_balanstotaal_3'] )){ echo $_SESSION['finaforte']['txt_balanstotaal_3']; } ?>" onkeyup="calculate_solvabiliteit()">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div id="div_solvabiliteitsscore" class="solvabiliteitsscore" style="display:none;">
                                                        <h6 class="Solvency-total" id="div_solvency_percentage"></h6>
                                                        <div class="radio-color">
                                                            <div class="colorline1 colorline-box">
                                                                <h2 class="big-heading text-center">Uw solvabiliteitsscore</h2> 
                                                                <div class="liner-gradiance">
                                                                    <div class="more-then-color" style="background: #ff0100;background: -moz-linear-gradient(right, #ff0100 0%, #ff8600 33%, #dada00 66%, #92ff00 100%); background: -webkit-linear-gradient(right, #ff0100 0%,#ff8600 33%,#dada00 66%,#92ff00 100%); background: linear-gradient(to right, #ff0100 0%,#ff8600 33%,#dada00 66%,#92ff00 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ff0100', endColorstr='#92ff00',GradientType=0);">
                                                                        <div class="overlay-image" style="left: 65%">
                                                                            <img src="<?php echo FINAFORTE_URL; ?>assets/images/line-arrow.png">
                                                                          
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <p class="text-center">Uw solvabiliteitscore is niet helemaal naar ratio. Let er op bij uw aanvraag.</p>
                                                            </div>                  
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            </div>
                                            
                                            <div class="col-md-12">
                                            <div class="card-header collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse_2" id="headingOne">
                                                <a class="card-title" id="card_collapse_22" style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px; color: <?php echo $subtitle_color; ?> ;">
                                                    <?php echo $liquiditeit_text; ?>
                                                </a>
                                            </div>
                                            <div id="collapse_2" class="card-body collapse" role="tabpanel">
                                                <div class="row">
                                                    <div class="col-md-4" id="div_liquiditeit_1">
                                                        <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color; ?> ;">Laatste jaar</h5>
                                                        <div class="form-group">
                                                            
                                                            <div class="jaar-value-box">    
                                                                <i class="fa fa-eur" aria-hidden="true"></i>                                    
                                                                <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Vlottende activa" name="txt_vlottendeactiva[]" id="txt_vlottendeactiva_1" value="<?php if(isset($_SESSION['finaforte']['txt_vlottendeactiva_1'] )){ echo $_SESSION['finaforte']['txt_vlottendeactiva_1']; } ?>" onkeyup="calculate_liquiditeit()">
                                                            </div>                                      
                                                        </div>
                                                        <div class="form-group">
                                                           
                                                            <div class="jaar-value-box">    
                                                                <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                                <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Kort vreemd vermogen" name="txt_kortvreemdvermogen[]" id="txt_kortvreemdvermogen_1" value="<?php if(isset($_SESSION['finaforte']['txt_kortvreemdvermogen_1'] )){ echo $_SESSION['finaforte']['txt_kortvreemdvermogen_1']; } ?>" onkeyup="calculate_liquiditeit()">  
                                                            </div>                                  
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4" id="div_liquiditeit_2">
                                                        <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color; ?> ;">2 jaar geleden</h5>
                                                        <div class="form-group">
                                                            
                                                            <div class="jaar-value-box">    
                                                                <i class="fa fa-eur" aria-hidden="true"></i>                                    
                                                                <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Vlottende activa" name="txt_vlottendeactiva[]" id="txt_vlottendeactiva_2" value="<?php if(isset($_SESSION['finaforte']['txt_vlottendeactiva_2'] )){ echo $_SESSION['finaforte']['txt_vlottendeactiva_2']; } ?>" onkeyup="calculate_liquiditeit()">
                                                            </div>                                      
                                                        </div>
                                                        <div class="form-group">
                                                            
                                                            <div class="jaar-value-box">    
                                                                <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                                <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Kort vreemd vermogen" name="txt_kortvreemdvermogen[]" id="txt_kortvreemdvermogen_2" value="<?php if(isset($_SESSION['finaforte']['txt_kortvreemdvermogen_2'] )){ echo $_SESSION['finaforte']['txt_kortvreemdvermogen_2']; } ?>" onkeyup="calculate_liquiditeit()">  
                                                            </div>                                  
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4" id="div_liquiditeit_3">
                                                        <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color; ?> ;">3 jaar geleden</h5>
                                                        <div class="form-group">
                                                            
                                                            <div class="jaar-value-box">    
                                                                <i class="fa fa-eur" aria-hidden="true"></i>                                    
                                                                <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Vlottende activa" name="txt_vlottendeactiva[]" id="txt_vlottendeactiva_3" value="<?php if(isset($_SESSION['finaforte']['txt_vlottendeactiva_3'] )){ echo $_SESSION['finaforte']['txt_vlottendeactiva_3']; } ?>" onkeyup="calculate_liquiditeit()">
                                                            </div>                                      
                                                        </div>
                                                        <div class="form-group">
                                                             
                                                            <div class="jaar-value-box">    
                                                                <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                                <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Kort vreemd vermogen" name="txt_kortvreemdvermogen[]" id="txt_kortvreemdvermogen_3" value="<?php if(isset($_SESSION['finaforte']['txt_kortvreemdvermogen_3'] )){ echo $_SESSION['finaforte']['txt_kortvreemdvermogen_3']; } ?>" onkeyup="calculate_liquiditeit()">  
                                                            </div>                                  
                                                        </div>
                                                    </div>
                                                    <div id="div_liquiditeitsscore" class="liquiditeitsscore" style="display:none;">
                                                        <h6 class="Solvency-total" id="div_liquidity_percentage"></h6>
                                                        <div class="radio-color">
                                                            <div class="colorline1 colorline-box">
                                                                <h2 class="big-heading text-center">Uw liquiditeitsscore</h2>   
                                                                <div class="liner-gradiance">
                                                                    <div class="more-then-color" style="background: #ff0100;background: -moz-linear-gradient(right, #ff0100 0%, #ff8600 33%, #dada00 66%, #92ff00 100%); background: -webkit-linear-gradient(right, #ff0100 0%,#ff8600 33%,#dada00 66%,#92ff00 100%); background: linear-gradient(to right, #ff0100 0%,#ff8600 33%,#dada00 66%,#92ff00 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ff0100', endColorstr='#92ff00',GradientType=0);">
                                                                        <div class="overlay-image" style="left: 65%">
                                                                            <img src="<?php echo FINAFORTE_URL; ?>assets/images/line-arrow.png">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <p class="text-center">Uw liquiditeitsscore is niet helemaal naar ratio. Let er op bij uw aanvraag.</p>
                                                            </div>                  
                                                        </div>
                                                    </div>
                                                </div>
                                            </div> 
                                            </div>
                                            
                                            </div> 
                                            <div class="clearfix"></div>
                               
                                        </div>
                                    </div>
                                 </div>

                                </div>
                            </div>
                            <div class="start-box pad-remove" id="div_box3" style="display:none; background: <?php echo $backgroundcolor; ?>">
                                <div class="sec-sep sec-sep11" >
                                
                                    <!-- ************** switch for partner ***************** -->
                                    <div class="check-swich" id="yn_switch_div" >
                                         <strong class="" style="font-size: <?php echo $gentext_font_size; ?>px; line-height: 29px; color: <?php echo $gentext_color; ?> ; float: left; margin-bottom: 4px;">Heeft u een partner?</strong>
                                        <div class="onoffswitch">
                                            <?php $yn_switch = (isset($_SESSION['finaforte']['yn_switch']) && $_SESSION['finaforte']['yn_switch'] == '1') ? '1' : '0';  ?>
                                            <input type="checkbox" name="yn_switch" class="onoffswitch-checkbox" id="yn_switch" value="<?php echo $yn_switch; ?>" onclick="partner_selection()">
                                            <label class="onoffswitch-label" for="yn_switch">
                                                <span class="onoffswitch-inner"></span>
                                                <span class="onoffswitch-switch"></span>
                                            </label>
                                        </div>
                                    </div>
                                <!-- ******************************* -->
                                </div>
                            </div>                           

                            <div class="start-box pad-remove" id="div_box4" style="display:none; ">
                                <div class="sec-sep sec-sep12" style="background: <?php echo $backgroundcolor; ?>;">
                                <h2 class="big-heading text-center" style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px; color: <?php echo $subtitle_color; ?> ;" >Vul hier het inkomen van uw partner in</h2>
                                <div class="row radiobox-row">
                                    <div class="col-md-3">
                                        <label class="rechtsvorm radiobox1" > 
                                        
                                        <?php $rdo_ptype_1 = (isset($_SESSION['finaforte']['pgroup1']) && $_SESSION['finaforte']['pgroup1'] == '1') ? '1' : ''; ?>                                        
                                            <input type="radio" name="rdo_partnertype" id="rdo_ptype_1" data-id="<?php echo $rdo_ptype_1; ?>" value="1" class="check">
                                            <span class="checkmark" style="overflow: hidden; border-radius: <?php echo $border_radius; ?>px;"></span>
                                            <?php $img1 = FINAFORTE_URL.'/assets/images/euro.png'; ?>
                                            <p><span class="icon-box" style="background: <?php echo $loondienst_icon_clr.';'; ?>"><img src=' <?php echo $img1; ?>' /></span><strong style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px; ">Loondienst</strong></p>   
                                        </label>
                                    </div>
                                    <div class="col-md-3">
                                        <label class="rechtsvorm radiobox2">                                          
                                            <?php $rdo_ptype_2 = (isset($_SESSION['finaforte']['pgroup1']) && $_SESSION['finaforte']['pgroup1'] == '2') ? '2' : ''; ?> 
                                            <input type="radio" name="rdo_partnertype" id="rdo_ptype_2" data-id="<?php echo $rdo_ptype_2; ?>" value="2">
                                            <span class="checkmark" style="overflow: hidden; border-radius: <?php echo $border_radius; ?>px;"></span>
                                            <?php $img2 = FINAFORTE_URL.'/assets/images/user1.png'; ?>                                            
                                            <p><span class="icon-box" style="background: <?php echo $freelancer_icon_clr.';'; ?>"><img src=' <?php echo $img2; ?>' /></span><strong style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px; ">Freelancer /<br /> Eenmanszaak</strong></p> 
                                        </label>
                                    </div>
                                    <div class="col-md-3">
                                        <label class="rechtsvorm radiobox3">                                          
                                            <?php $rdo_ptype_3 = (isset($_SESSION['finaforte']['pgroup1']) && $_SESSION['finaforte']['pgroup1'] == '3') ? '3' : ''; ?>
                                            <input type="radio" name="rdo_partnertype" id="rdo_ptype_3" data-id="<?php echo $rdo_ptype_3; ?>" value="3">                                          
                                            <span class="checkmark" style="overflow: hidden; border-radius: <?php echo $border_radius; ?>px;"></span>
                                            <?php $img3 = FINAFORTE_URL.'/assets/images/group.png'; ?>                                            
                                            <p><span class="icon-box" style="background: <?php echo $vof_icon_clr.';'; ?>"><img src=' <?php echo $img3; ?>' /></span><strong style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px;">V.O.F</strong></p>                       
                                        </label>
                                    </div>
                                    <div class="col-md-3">
                                        <label class="rechtsvorm radiobox4">                                          
                                            <?php $rdo_ptype_4 = (isset($_SESSION['finaforte']['pgroup1']) && $_SESSION['finaforte']['pgroup1'] == '4') ? '4' : ''; ?>
                                            <input type="radio" name="rdo_partnertype" id="rdo_ptype_4" data-id="<?php echo $rdo_ptype_4; ?>" value="4">                                          
                                            <span class="checkmark" style="overflow: hidden; border-radius: <?php echo $border_radius; ?>px;"></span>
                                            <?php $img4 = FINAFORTE_URL.'/assets/images/building-1.png'; ?>
                                            <p><span class="icon-box" style="background: <?php echo $bv_dga_icon_clr.';'; ?>"><img src=' <?php echo $img4; ?>' /></span><strong style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px;">BV / DGA</strong></p>
                                        </label>
                                    </div>


                                </div>
                                </div>

                                <div class="sec-sep sec-sep13" style="background: <?php echo $backgroundcolor; ?>">
                                    <div id="div_box4_1" style="display:none;">
                                        <h2 class="big-heading text-center" style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px; color: <?php echo $subtitle_color; ?> ;"><span> Hoeveel jaar bent u al ondernemer? <a href="javascript:;" title="" data-placement="bottom" data-toggle="popover" data-content="<?php echo $tooltip_select_year; ?>" data-original-title="" aria-describedby="popover52623"><i class="fa fa-info-circle" aria-hidden="true"></i></a></span> </h2>
                                        <div class="demo-output" id="div_rangeslider">
                                            <?php $single_slider_2 = isset($_SESSION['finaforte']['single_slider_2']) ? $_SESSION['finaforte']['single_slider_2'] : ''; ?>
                                            <?php $single_slider_2 = $single_slider_2 != '' ? $single_slider_2 : '0'; ?>
                                            <input name="single_slider_2" id="single_slider_2" type="hidden" value="<?php echo $single_slider_2; ?>"/>
                                            <div class="gray-line1"></div>
                                            <div class="gray-line2"></div>
                                            <div class="gray-line3"></div>
                                        </div>
                                    </div>
                                </div>

                                <!-- on off switch -->
                                <div class="sec-sep psec-sep6" style="background: <?php echo $backgroundcolor; ?>">
                                    <div class="check-swich" id="pdiv_holding" >
                                        <strong style="font-size:<?php echo $gentext_font_size; ?>px; line-height: 29px; color: <?php echo $gentext_color; ?>;">Is uw onderneming onderdeel van een holding?</strong>
                                        <div class="onoffswitch">
                                            <?php $pmyonoffswitch3 = isset($_SESSION['finaforte']['pmyonoffswitch3']) ? $_SESSION['finaforte']['pmyonoffswitch3'] : '0'; ?>
                                            <input type="checkbox" name="ponoffswitch3" class="onoffswitch-checkbox" id="pmyonoffswitch3" checked="checked" value="<?php echo $pmyonoffswitch3; ?>">
                                            <label class="onoffswitch-label" for="pmyonoffswitch3">
                                                <span class="onoffswitch-inner"></span>
                                                <span class="onoffswitch-switch"></span>
                                            </label>
                                        </div>
                                     </div>
                                    </div>

                                    <div class="sec-sep psec-sep7" style="display:none; background: <?php echo $backgroundcolor; ?>;">
                                    <div class="box-msg2" id="pdiv_holdingtext" style="border-radius: <?php echo $border_radius; ?>px; font-size:<?php echo $gentext_font_size; ?>px; line-height: <?php echo $gentext_font_size + 4; ?>px; color: <?php echo $gentext_color; ?>;"> 
                                        Heeft U meerdere BV's of een holding werk-maatschappij structuur? Gebruik dan altijd de gegevens uit de geconsolideerde jaarcijfers.
                                    </div>
                                    </div>
                                    <!-- on off switch end -->

                                <div class="sec-sep psec-sep2" style="display:none; background: <?php echo $backgroundcolor; ?>">
                                    <div class="check-swich" id="pdiv_holding1" >
                                        <strong style="font-size:<?php echo $gentext_font_size; ?>px; line-height: 29px; color: <?php echo $gentext_color; ?>">zzp werkzaamheden gelijk aan laatste loondienstverband?</strong>
                                        <div class="onoffswitch">
                                            <?php $ponoffswitch1 = isset($_SESSION['finaforte']['ponoffswitch1']) ? $_SESSION['finaforte']['ponoffswitch1'] : '0'; ?>
                                            <input type="checkbox" name="ponoffswitch1" class="onoffswitch-checkbox" checked="checked" id="ponoffswitch1" value="<?php echo $ponoffswitch1; ?>">
                                            <label class="onoffswitch-label" for="ponoffswitch1">
                                                <span class="onoffswitch-inner"></span>
                                                <span class="onoffswitch-switch"></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                 <div class="sec-sep psec-sep3" style="background: <?php echo $backgroundcolor; ?>">
                                    <div class="box-msg2" id="pdiv_holdingtext1" style=" border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ; font-size:<?php echo $gentext_font_size; ?>px; line-height: <?php echo $gentext_font_size + 4; ?>px; color: <?php echo $gentext_color; ?>"> 
                                        Helaas, een hypotheek als zzp korter dan 1 jr kan alleen indien uw werkzaamheden gelijk zijn aan uw laatste dienstverband.
                                    </div> 
                                </div>

                            </div>

                            <div class="start-box pad-remove" id="div_box5" style="display:none; background: <?php echo $backgroundcolor; ?>">
                                <div class="jaar-value sec-sep sec-sep17 sep-before">
                                    <div class="row1">
                                        <div id="div_forhalfyearp" style="width:100%; display:none;">
                                            <h4 class="big-sub-heading big-heading-black text-center" style="display:none;"><span>Eerste 1/2 jaar</span> </h4>
                                            <div class="row justify-content-md-center">
                                                <div class="col-md-6 income-data">  
                                                     <h2 class="big-heading text-center" style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px; color: <?php echo $subtitle_color; ?> ;"><span>Vul hier uw inkomen in <a href="javascript:;" title="" data-placement="bottom" data-toggle="popover" data-content="<?php echo $tooltip_salary; ?>"><i class="fa fa-info-circle" aria-hidden="true"></i></a></span> 
                                        </h2>
                                                    <div class="form-group text-center">
                                                         
                                                        <div class="jaar-value-box">    
                                                            <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                            <input class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" maxlength="256" dir="rtl" type="number" pattern="[0-9]*" placeholder="Laatste jaarsalaris" name="txt_halfyearp_third" id="txt_halfyearp_third" value="<?php if(isset($_SESSION['finaforte']['txt_halfyearp_third'] )){ echo $_SESSION['finaforte']['txt_halfyearp_third']; } ?>" onkeyup="incomedata_calculation()">    
                                                        </div>                                  
                                                    </div>                                   
                                                    <div class="form-group text-center">
                                                        
                                                        <div class="jaar-value-box">    
                                                            <i class="fa fa-eur" aria-hidden="true"></i>                                    
                                                            <input class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" maxlength="256" dir="rtl" type="number" pattern="[0-9]*" placeholder="Winst uit onderneming" name="txt_halfyearp_first" id="txt_halfyearp_first" value="<?php if(isset($_SESSION['finaforte']['txt_halfyearp_first'] )){ echo $_SESSION['finaforte']['txt_halfyearp_first']; } ?>" onkeyup="incomedata_calculation()">
                                                        </div>                                      
                                                    </div>
                                                    <div class="form-group text-center">
                                                         
                                                        <div class="jaar-value-box">    
                                                            <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                            <input class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" maxlength="256" dir="rtl" type="number" pattern="[0-9]*" placeholder="Prognose hele jaar" name="txt_halfyearp_second" id="txt_halfyearp_second" value="<?php if(isset($_SESSION['finaforte']['txt_halfyearp_second'] )){ echo $_SESSION['finaforte']['txt_halfyearp_second']; } ?>" onkeyup="incomedata_calculation()">  
                                                        </div>                                  
                                                    </div>
                                                   
                                                </div>                                  
                                            </div>
                                        </div>
                                        <div class="row" id="div_winstuitondernemingp" style="display:none;">
                                            <div class="col-md-4" id="div_winstuitondernemingp_1">
                                                <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color; ?> ;">Laatste jaar</h5>
                                                <div class="form-group">
                                                   
                                                    <div class="jaar-value-box">
                                                        <i class="fa fa-eur" aria-hidden="true"></i>
                                                        <input class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" type="number" pattern="[0-9]*" placeholder="Winst uit onderneming" name="txt_winstuitondernemingp_1" placeholder="Winst uit onderneming" id="txt_winstuitondernemingp_1" value="<?php if(isset($_SESSION['finaforte']['txt_winstuitondernemingp_1'] )){ echo $_SESSION['finaforte']['txt_winstuitondernemingp_1']; } ?>" onkeyup="incomedata_calculation()">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4" id="div_winstuitondernemingp_2">
                                                <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color; ?> ;">2 jaar geleden</h5>
                                                <div class="form-group">
                                                    
                                                    <div class="jaar-value-box">
                                                        <i class="fa fa-eur" aria-hidden="true"></i>
                                                        <input class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" type="number" pattern="[0-9]*" placeholder="Winst uit onderneming" name="txt_winstuitondernemingp_2" placeholder="Winst uit onderneming" id="txt_winstuitondernemingp_2" value="<?php if(isset($_SESSION['finaforte']['txt_winstuitondernemingp_2'] )){ echo $_SESSION['finaforte']['txt_winstuitondernemingp_2']; } ?>" onkeyup="incomedata_calculation()">
                                                    </div>                                      
                                                </div>                                      
                                            </div>
                                            <div class="col-md-4" id="div_winstuitondernemingp_3">
                                                <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color; ?> ;">3 jaar geleden</h5>
                                                <div class="form-group">
                                                    
                                                    <div class="jaar-value-box">
                                                        <i class="fa fa-eur" aria-hidden="true"></i>
                                                        <input class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" type="number" pattern="[0-9]*" placeholder="Winst uit onderneming" name="txt_winstuitondernemingp_3" placeholder="Winst uit onderneming" id="txt_winstuitondernemingp_3" value="<?php if(isset($_SESSION['finaforte']['txt_winstuitondernemingp_3'] )){ echo $_SESSION['finaforte']['txt_winstuitondernemingp_3']; } ?>" onkeyup="incomedata_calculation()">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="start-box" id="div_loondienst" style="background: <?php echo $backgroundcolor; ?>" >
                                            <div class="jaar-value">                                            
                                                <h2 class="big-heading big-heading-black text-center" style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px;
                                                    color: <?php echo $text_color; ?> ;"><span>Huidige salaris <a href="javascript:;" title="" data-placement="bottom" data-toggle="popover" data-content="<?php echo $tooltip_loondienst; ?>"><i class="fa fa-info-circle" aria-hidden="true"></i></a></span> </h2>
                                                                               
                                                <div class="row justify-content-md-center">
                                                    <div class="col-md-6 income-data">
                                                        <div class="form-group text-center">                                            
                                                            <div class="jaar-value-box">    
                                                                <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                                <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Jaarsalaris incl. bonussen / vakantiegeld / overwerk" name="txt_loondienst" id="txt_loondienst" value="<?php if(isset($_SESSION['finaforte']['txt_loondienst'] )){ echo $_SESSION['finaforte']['txt_loondienst']; } ?>" onkeyup="incomedata_calculation()">
                                                            </div>                                  
                                                        </div>
                                                    </div>                                  
                                                </div>                              
                                            </div>
                                        </div>
                                        <div class="row" id="div_winstuitondernemingp" style="display:none;">
                                            <div class="col-md-4" id="div_winstuitondernemingp_1">
                                                <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color; ?> ;">Laatste jaar</h5>
                                                <div class="form-group">
                                                    
                                                    <div class="jaar-value-box">
                                                        <i class="fa fa-eur" aria-hidden="true"></i>
                                                        <input class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px;" dir="rtl" maxlength="256" type="number" pattern="[0-9]*" placeholder="Winst uit onderneming" name="txt_winstuitondernemingp_1" placeholder="Winst uit onderneming" id="txt_winstuitondernemingp_1" value="<?php if(isset($_SESSION['finaforte']['txt_winstuitondernemingp_1'] )){ echo $_SESSION['finaforte']['txt_winstuitondernemingp_1']; } ?>" onkeyup="incomedata_calculation()">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4" id="div_winstuitondernemingp_2">
                                                <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color; ?> ;">2 jaar geleden</h5>
                                                <div class="form-group">
                                                    
                                                    <div class="jaar-value-box">
                                                        <i class="fa fa-eur" aria-hidden="true"></i>
                                                        <input class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" type="number" pattern="[0-9]*" placeholder="Winst uit onderneming" name="txt_winstuitondernemingp_2" id="txt_winstuitondernemingp_2" value="<?php if(isset($_SESSION['finaforte']['txt_winstuitondernemingp_2'] )){ echo $_SESSION['finaforte']['txt_winstuitondernemingp_2']; } ?>" onkeyup="incomedata_calculation()">
                                                    </div>                                      
                                                </div>                                      
                                            </div>
                                            <div class="col-md-4" id="div_winstuitondernemingp_3">
                                                <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px;color: <?php echo $text_color; ?> ;">3 jaar geleden</h5>
                                                <div class="form-group">
                                                    
                                                    <div class="jaar-value-box">
                                                        <i class="fa fa-eur" aria-hidden="true"></i>
                                                        <input class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?>;" dir="rtl" maxlength="256" type="number" pattern="[0-9]*" name="txt_winstuitondernemingp_3" placeholder="Winst uit onderneming" id="txt_winstuitondernemingp_3" value="<?php if(isset($_SESSION['finaforte']['txt_winstuitondernemingp_3'] )){ echo $_SESSION['finaforte']['txt_winstuitondernemingp_3']; } ?>" onkeyup="incomedata_calculation()">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                        <div class="col-md-4" id="div_inkomensgegevensp_1">
                                            <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color; ?> ;">Laatste jaar</h5>
                                            <div class="form-group">
                                               
                                                <div class="jaar-value-box">    
                                                    <i class="fa fa-eur" aria-hidden="true"></i>                                    
                                                    <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Salaris" name="txt_salarisp[]" id="txt_salarisp_1" value="<?php if(isset($_SESSION['finaforte']['txt_salarisp_1'] )){ echo $_SESSION['finaforte']['txt_salarisp_1']; } ?>" onkeyup="incomedata_calculation()">
                                                </div>                                      
                                            </div>
                                            <div class="form-group">
                                                  
                                                <div class="jaar-value-box">    
                                                    <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                    <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Dividend" name="txt_dividendp[]" id="txt_dividendp_1" value="<?php if(isset($_SESSION['finaforte']['txt_dividendp_1'] )){ echo $_SESSION['finaforte']['txt_dividendp_1']; } ?>" onkeyup="incomedata_calculation()">  
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                
                                                <div class="jaar-value-box">    
                                                    <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                    <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Overwinst / Winst BV" name="txt_overwinstp[]" id="txt_overwinstp_1" value="<?php if(isset($_SESSION['finaforte']['txt_overwinstp_1'] )){ echo $_SESSION['finaforte']['txt_overwinstp_1']; } ?>" onkeyup="incomedata_calculation()">    
                                                </div>                                  
                                            </div>
                                        </div>

                                        <div class="col-md-4" id="div_inkomensgegevensp_2">
                                            <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color; ?> ;">2 jaar geleden</h5>
                                            <div class="form-group">
                                                
                                                <div class="jaar-value-box">    
                                                    <i class="fa fa-eur" aria-hidden="true"></i>                                    
                                                    <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Salaris" name="txt_salarisp[]" id="txt_salarisp_2" value="<?php if(isset($_SESSION['finaforte']['txt_salarisp_2'] )){ echo $_SESSION['finaforte']['txt_salarisp_2']; } ?>" onkeyup="incomedata_calculation()">
                                                </div>                                      
                                            </div>
                                            <div class="form-group">
                                                  
                                                <div class="jaar-value-box">    
                                                    <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                    <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Dividend" name="txt_dividendp[]" id="txt_dividendp_2" value="<?php if(isset($_SESSION['finaforte']['txt_dividendp_2'] )){ echo $_SESSION['finaforte']['txt_dividendp_2']; } ?>" onkeyup="incomedata_calculation()">  
                                                </div>                                  
                                            </div>
                                            <div class="form-group">
                                                 
                                                <div class="jaar-value-box">    
                                                    <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                    <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Overwinst / Winst BV" name="txt_overwinstp[]" id="txt_overwinstp_2" value="<?php if(isset($_SESSION['finaforte']['txt_overwinstp_2'] )){ echo $_SESSION['finaforte']['txt_overwinstp_2']; } ?>" onkeyup="incomedata_calculation()">    
                                                </div>                                  
                                            </div>
                                        </div>
                                        <div class="col-md-4" id="div_inkomensgegevensp_3">
                                            <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color; ?> ;">3 jaar geleden</h5>
                                            <div class="form-group">
                                               
                                                <div class="jaar-value-box">    
                                                    <i class="fa fa-eur" aria-hidden="true"></i>                                    
                                                    <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Salaris" name="txt_salarisp[]" id="txt_salarisp_3" value="<?php if(isset($_SESSION['finaforte']['txt_salarisp_3'] )){ echo $_SESSION['finaforte']['txt_salarisp_3']; } ?>" onkeyup="incomedata_calculation()">
                                                </div>                                      
                                            </div>
                                            <div class="form-group">
                                                  
                                                <div class="jaar-value-box">    
                                                    <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                    <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Dividend" name="txt_dividendp[]" id="txt_dividendp_3" value="<?php if(isset($_SESSION['finaforte']['txt_dividendp_3'] )){ echo $_SESSION['finaforte']['txt_dividendp_3']; } ?>" onkeyup="incomedata_calculation()">  
                                                </div>                                  
                                            </div>
                                            <div class="form-group">
                                                
                                                <div class="jaar-value-box">    
                                                    <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                    <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Overwinst / Winst BV" name="txt_overwinstp[]" id="txt_overwinstp_3" value="<?php if(isset($_SESSION['finaforte']['txt_overwinstp_3'] )){ echo $_SESSION['finaforte']['txt_overwinstp_3']; } ?>" onkeyup="incomedata_calculation()">    
                                                </div>                                  
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    </div>
                                    <div class="sec-sep sec-sep16" style="background: <?php echo $backgroundcolor; ?>">
                                     <h2 class="big-heading text-center" style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px; color: <?php echo $subtitle_color; ?> ;"><?php echo $solva_liq_header_text; ?></h2>
                                     <div class="description text-center" id="" style=" border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ; font-size:<?php echo $gentext_font_size; ?>px; line-height:<?php echo $gentext_font_size + 4; ?>px; color: <?php echo $gentext_color; ?>"> 
                                       <?php echo $solva_liq_header_descri; ?>
                                    </div> 

                                 </div>
                                    <div id="accordion1" class="accordion-value">
                                        <div class="card">
                                            <div class="row">
                                                <div class="col-md-12">
                                                     <div class="card-header collapsed" id="headingThree" href="#collapse_11" data-toggle="collapse" data-target="#collapse_11" aria-expanded="false" aria-controls="collapse_11">
                                                        <a class="card-title" id="card_sol_11" style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px; color: <?php echo $subtitle_color; ?> ;">
                                                            <?php echo $solvabiliteit_text; ?>
                                                        </a>
                                                    </div>
                                                    <div id="collapse_11" class="card-body collapse" role="tabpanel" aria-labelledby="headingThree">
                                                        <div class="row">
                                                        <div class="col-md-4" id="div_solvabiliteitp_1">
                                                            <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color; ?> ;">Laatste jaar</h5>
                                                            <div class="form-group">
                                                                
                                                                <div class="jaar-value-box">    
                                                                    <i class="fa fa-eur" aria-hidden="true"></i>                                    
                                                                    <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" placeholder="Eigen vermogen" maxlength="256" name="txt_eigenvermogenp[]" id="txt_eigenvermogenp_1" value="<?php if(isset($_SESSION['finaforte']['txt_eigenvermogenp_1'] )){ echo $_SESSION['finaforte']['txt_eigenvermogenp_1']; } ?>" onkeyup="calculate_solvabiliteitp()">
                                                                </div>                                      
                                                            </div>
                                                            <div class="form-group">
                                                                
                                                                <div class="jaar-value-box">    
                                                                    <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                                    <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Balanstotaal" name="txt_balanstotaalp[]" id="txt_balanstotaalp_1" value="<?php if(isset($_SESSION['finaforte']['txt_balanstotaalp_1'] )){ echo $_SESSION['finaforte']['txt_balanstotaalp_1']; } ?>" onkeyup="calculate_solvabiliteitp()">  
                                                                </div>                                  
                                                            </div>                                                    
                                                        </div>
                                                        <div class="col-md-4" id="div_solvabiliteitp_2">
                                                            <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color; ?> ;">2 jaar geleden</h5>
                                                            <div class="form-group">
                                                                
                                                                <div class="jaar-value-box">    
                                                                    <i class="fa fa-eur" aria-hidden="true"></i>                                    
                                                                    <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Eigen vermogen" name="txt_eigenvermogenp[]" id="txt_eigenvermogenp_2" value="<?php if(isset($_SESSION['finaforte']['txt_eigenvermogenp_2'] )){ echo $_SESSION['finaforte']['txt_eigenvermogenp_2']; } ?>" onkeyup="calculate_solvabiliteitp()">
                                                                </div>                                      
                                                            </div>
                                                            <div class="form-group">
                                                                
                                                                <div class="jaar-value-box">    
                                                                    <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                                    <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Balanstotaal" name="txt_balanstotaalp[]" id="txt_balanstotaalp_2" value="<?php if(isset($_SESSION['finaforte']['txt_balanstotaalp_2'] )){ echo $_SESSION['finaforte']['txt_balanstotaalp_2']; } ?>" onkeyup="calculate_solvabiliteitp()">  
                                                                </div>                                  
                                                            </div>                                                    
                                                        </div>
                                                        <div class="col-md-4" id="div_solvabiliteitp_3">
                                                            <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color; ?> ;">3 jaar geleden</h5>
                                                            <div class="form-group">
                                                                
                                                                <div class="jaar-value-box">    
                                                                    <i class="fa fa-eur" aria-hidden="true"></i>                                    
                                                                    <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Eigen vermogen" name="txt_eigenvermogenp[]" id="txt_eigenvermogenp_3" value="<?php if(isset($_SESSION['finaforte']['txt_eigenvermogenp_3'] )){ echo $_SESSION['finaforte']['txt_eigenvermogenp_3']; } ?>" onkeyup="calculate_solvabiliteitp()">
                                                                </div>                                      
                                                            </div>
                                                            <div class="form-group">
                                                                
                                                                <div class="jaar-value-box">
                                                                    <i class="fa fa-eur" aria-hidden="true"></i>
                                                                    <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" name="txt_balanstotaalp[]" placeholder="Balanstotaal" id="txt_balanstotaalp_3" value="<?php if(isset($_SESSION['finaforte']['txt_balanstotaalp_3'] )){ echo $_SESSION['finaforte']['txt_balanstotaalp_3']; } ?>" onkeyup="calculate_solvabiliteitp()">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div id="div_solvabiliteitsscorep" class="solvabiliteitsscore" style="display:none;">
                                                            <h6 class="Solvency-total" id="div_solvencyp_percentage"></h6>
                                                            <div class="radio-color">
                                                                <div class="colorline1 colorline-box">
                                                                    <h2 class="big-heading text-center">Uw solvabiliteitsscore</h2> 
                                                                    <div class="liner-gradiance">
                                                                        <div class="more-then-color" style="background: #ff0100; background: -moz-linear-gradient(right, #ff0100 0%, #ff8600 33%, #dada00 66%, #92ff00 100%); background: -webkit-linear-gradient(right, #ff0100 0%,#ff8600 33%,#dada00 66%,#92ff00 100%); background: linear-gradient(to right, #ff0100 0%,#ff8600 33%,#dada00 66%,#92ff00 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ff0100', endColorstr='#92ff00',GradientType=0);">
                                                                            <div class="overlay-image" style="left: 65%">
                                                                                <img src="<?php echo FINAFORTE_URL; ?>assets/images/line-arrow.png">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <p class="text-center">Uw solvabiliteitscore is niet helemaal naar ratio. Let er op bij uw aanvraag.</p>
                                                                </div>                  
                                                            </div>
                                                        </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                 <div class="col-md-12">
                                                     <div class="card-header collapsed" id="headingFour" href="#collapse_22" data-toggle="collapse" data-parent="#accordion1" data-target="#collapse_22" aria-expanded="false" aria-controls="collapse_22">
                                                        <a class="card-title" id="card_liq_22" style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px; color: <?php echo $subtitle_color; ?> ;">
                                                            <?php echo $liquiditeit_text; ?>
                                                        </a>
                                                    </div>
                                                    <div id="collapse_22" class="card-body collapse" role="tabpanel">
                                                <div class="row">
                                                    <div class="col-md-4" id="div_liquiditeitp_1">
                                                        <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color; ?> ;">Laatste jaar</h5>
                                                        <div class="form-group">
                                                           
                                                            <div class="jaar-value-box">    
                                                                <i class="fa fa-eur" aria-hidden="true"></i>                                    
                                                                <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Vlottende activa" name="txt_vlottendeactivap[]" id="txt_vlottendeactivap_1" value="<?php if(isset($_SESSION['finaforte']['txt_vlottendeactivap_1'] )){ echo $_SESSION['finaforte']['txt_vlottendeactivap_1']; } ?>" onkeyup="calculate_liquiditeitp()">
                                                            </div>                                      
                                                        </div>
                                                        <div class="form-group">
                                                             
                                                            <div class="jaar-value-box">    
                                                                <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                                <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Kort vreemd vermogen" name="txt_kortvreemdvermogenp[]" id="txt_kortvreemdvermogenp_1" value="<?php  if(isset($_SESSION['finaforte']['txt_kortvreemdvermogenp_1'] )){ echo $_SESSION['finaforte']['txt_kortvreemdvermogenp_1']; } ?>" onkeyup="calculate_liquiditeitp()">  
                                                            </div>                                  
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4" id="div_liquiditeitp_2">
                                                        <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color; ?> ;">2 jaar geleden</h5>
                                                        <div class="form-group">
                                                           
                                                            <div class="jaar-value-box">    
                                                                <i class="fa fa-eur" aria-hidden="true"></i>                                    
                                                                <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Vlottende activa" name="txt_vlottendeactivap[]" id="txt_vlottendeactivap_2" value="<?php if(isset($_SESSION['finaforte']['txt_vlottendeactivap_2'] )){ echo $_SESSION['finaforte']['txt_vlottendeactivap_2']; } ?>" onkeyup="calculate_liquiditeitp()">
                                                            </div>                                      
                                                        </div>
                                                        <div class="form-group">
                                                              
                                                            <div class="jaar-value-box">    
                                                                <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                                <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Kort vreemd vermogen" name="txt_kortvreemdvermogenp[]" id="txt_kortvreemdvermogenp_2" value="<?php if(isset($_SESSION['finaforte']['txt_kortvreemdvermogenp_2'] )){ echo $_SESSION['finaforte']['txt_kortvreemdvermogenp_2']; } ?>" onkeyup="calculate_liquiditeitp()">  
                                                            </div>                                  
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4" id="div_liquiditeitp_3">
                                                        <h5 style="font-size: <?php echo $text_font_size; ?>px; line-height: <?php echo $text_font_size + 4; ?>px; color: <?php echo $text_color; ?> ;">3 jaar geleden</h5>
                                                        <div class="form-group">
                                                            
                                                            <div class="jaar-value-box">    
                                                                <i class="fa fa-eur" aria-hidden="true"></i>                                    
                                                                <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Vlottende activa" name="txt_vlottendeactivap[]" id="txt_vlottendeactivap_3" onkeyup="calculate_liquiditeitp()">
                                                            </div>                                      
                                                        </div>
                                                        <div class="form-group">
                                                            
                                                            <div class="jaar-value-box">    
                                                                <i class="fa fa-eur" aria-hidden="true"></i>                                        
                                                                <input type="number" pattern="[0-9]*" class="form-control numbers" style="border-radius: <?php echo $border_radius; ?>px; border-color: <?php echo  $txt_border_color; ?> ;" dir="rtl" maxlength="256" placeholder="Kort vreemd vermogen" name="txt_kortvreemdvermogenp[]" id="txt_kortvreemdvermogenp_3" onkeyup="calculate_liquiditeitp()">  
                                                            </div>                                  
                                                        </div>
                                                    </div>
                                                    <div id="div_liquiditeitsscorep" class="liquiditeitsscore" style="display:none;">
                                                        <h6 class="Solvency-total" id="div_liquidityp_percentage"></h6>
                                                        <div class="radio-color">
                                                            <div class="colorline1 colorline-box">
                                                                <h2 class="big-heading text-center">Uw liquiditeitsscore</h2>   
                                                                <div class="liner-gradiance">
                                                                    <div class="more-then-color" style="background: #ff0100;background: -moz-linear-gradient(right, #ff0100 0%, #ff8600 33%, #dada00 66%, #92ff00 100%); background: -webkit-linear-gradient(right, #ff0100 0%,#ff8600 33%,#dada00 66%,#92ff00 100%); background: linear-gradient(to right, #ff0100 0%,#ff8600 33%,#dada00 66%,#92ff00 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ff0100', endColorstr='#92ff00',GradientType=0);">
                                                                        <div class="overlay-image" style="left: 65%">
                                                                            <img src="<?php echo FINAFORTE_URL;?>assets/images/line-arrow.png">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <p class="text-center">Uw liquiditeitsscore is niet helemaal naar ratio. Let er op bij uw aanvraag.</p>
                                                            </div>                  
                                                        </div>
                                                    </div>
                                                </div>
                                            </div> 
                                                    
                                                </div>
                                                </div>
                                                <div class="clearfix"></div>                                  
                                                                          
                                        </div>
                                    </div>
                                </div>
                            </div> 
                            </div> 
                            <!-- button ******************************** -->
                             <div class="start-box pad-remove" id="div_box6" style="display:none; background: <?php echo $backgroundcolor; ?>">
                            <div class="sec-sep sec-sep14 sep-before">
                            <a href="javascript:;" class="btn btn-primary btn-yellow"  onclick="total_calculation()"  style="color: <?php echo $btn_text_color; ?>; background: <?php echo $btn_bg_color; ?>; border-radius:<?php echo $border_radius;?>px; border-color: <?php echo $btn_border_color; ?> ;"><?php echo $view_cal_button_text; ?></a>
                            </div>
                            </div>
                            </div>
                        </div>                    
                        <div class="col-md-4 start-right"> 
                                             
                            <div class="sidebar-item">
                              
                                <div class="make-me-sticky">
                                <div class="brd-cover-div">
                                    <button class="btn close-sidebar"><i class="fa fa-chevron-down" aria-hidden="true"></i></button>
                                    <div class="start-box plr15" style="background: <?php echo $backgroundcolor; ?>;">
                                        <h2 class="big-heading text-center" style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px; color: <?php echo $subtitle_color; ?>;" >Overzicht</h2>
                                    </div>
                                    <div class="start-box" style="background: <?php echo $backgroundcolor; ?>;">
                                        <input type="hidden" name="sub_title_txt_size" id="sub_title_txt_size" value="<?php echo $subtitle_font_size; ?>">
                                        <div  class="final-value" id="div_overzicht" >
                                            <ul>
                                                <li>
                                                     <h3 style="color: <?php echo 
                                                    $subtitle_color; ?>; line-height: <?php echo $subtitle_font_size + 4; ?>px;  font-size: <?php echo $subtitle_font_size; ?>px; " >Uw totale toetsinkomen</h3>
                                                    <h4 style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px; color: <?php echo $subtitle_color; ?>;" >&euro; <span>0</span></h4>
                                                </li>
                                                <li>
                                                    <h3 style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px; color: <?php echo $subtitle_color; ?>;" >Maximale hypotheek</h3>
                                                    <h4 style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px; color: <?php echo $subtitle_color; ?>;" >&euro; <span>0</span></h4>
                                                </li>
                                                <li>
                                                    <h3 style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px; color: <?php echo $subtitle_color; ?>;" >Maandlasten</h3>
                                                    <h4 style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px; color: <?php echo $subtitle_color; ?>;" >&euro; <span>0</span></h4>
                                                </li>
                                            </ul>
                                        </div>

                                        <?php

                                         $mortgage_interest = !empty($mortgage_interest) ? number_format($mortgage_interest, 2, ',' , '.') : '0,00'; ?>

                                        <h4 class="toetsrente-txt" ><span class="right-span" style="font-size: <?php echo $text_font_size; ?>px; color: <?php echo $text_color; ?>; line-height: <?php echo $text_font_size+4; ?>px;" > Op basis van <?php echo $mortgage_interest; ?>% toetsrente <a style="color: <?php echo $text_color; ?> ;" href="javascript:;" title="" data-placement="bottom" data-toggle="popover" data-content="<?php echo $tooltip_mortgage_interest; ?>" data-original-title="" aria-describedby="popover52623"><i class="fa fa-info-circle" aria-hidden="true"></i></a></span> </h4>
                                        <p class="box-msg" id="p_notcompleted" style="font-size: <?php echo $gentext_font_size; ?>px !important; line-height: <?php echo $gentext_font_size + 4; ?>px !important; color: <?php echo $gentext_color; ?>; padding-bottom: 9px !important;"><?php echo $cal_sugg_text; ?></p>
                                                                                
                                        <a href="javascript:;" class="btn btn-primary btn-yellow"  onclick="total_calculation()"  style="color: <?php echo $btn_text_color; ?>; background: <?php echo $btn_bg_color; ?>; border-radius:<?php echo $border_radius;?>px; border-color: <?php echo $btn_border_color; ?> ;"><?php echo $view_cal_button_text; ?></a>
                                    </div>
                                    </div>
                                    <div class="right-desc">
                                        <h3 style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px; color: <?php echo $call_sec_txt_color; ?> ;"  class="big-sub-heading">Wil je advies of heb je vragen?</h3>
                                        <div class="user-desc">
                                           <h4 class="big-sub-heading" style="font-size: <?php echo $text_font_size; ?>px !important; color: <?php echo $call_sec_txt_color;?> !important; line-height: <?php echo $text_font_size+4; ?>px;">Bel met een van onze adviseurs</h4> <p><span> <a style="font-size: <?php echo $subtitle_font_size; ?>px; line-height: <?php echo $subtitle_font_size + 4; ?>px; color: <?php echo $call_sec_txt_color; ?>;" href="tel:<?php echo $advice_contact; ?>"> <?php echo $advice_contact; ?></a> </span>
                                             </p>
                                        </div>
                                        <?php  if(!empty($advicer_photo)){ ?>
                                        <div class="user-image">                                    
                                            <img src="<?php echo $advicer_photo; ?>" alt="user name" title="user name">
                                        </div>
                                        <?php } ?>
                                        
                                    </div>
                                    
                                </div>
                              
                            </div>
                           
                        </div>
                    </div>
                </div>
                <button class="btn btn-primary btn-yellow sidebar-hide-show" style="border-top-left-radius: <?php echo $border_radius;?>px; border-top-right-radius: <?php echo $border_radius;?>px; color: <?php echo $btn_text_color; ?>; background: <?php echo $btn_bg_color; ?>;"><?php echo $popup_button_text; ?> <br><span id="max_hypotheek_btn"></span><div class="fa fa-chevron-up btm-arrow" aria-hidden="true"></div></button>
            </div>

        </div>
        <input type="hidden" name="h_yearselection" id="h_yearselection" value="0" />
        <input type="hidden" name="h_typeselection" id="h_typeselection" />
        <input type="hidden" name="h_partneryearselection" id="h_partneryearselection" value="<?php if( isset($_SESSION['finaforte']['single_slider_2']) && !empty($_SESSION['finaforte']['single_slider_2'])) { echo $_SESSION['finaforte']['single_slider_2']; } else {echo '1'; } ?>" />
        <input type="hidden" name="cal_sugg_text" id="cal_sugg_text" value="<?php echo $cal_sugg_text; ?>">
        <input type="hidden" name="h_partnertypeselection" id="h_partnertypeselection" />
        <input type="hidden" name="h_solvabiliteit" id="h_solvabiliteit" />
        <input type="hidden" name="h_solvabiliteitp" id="h_solvabiliteitp" />
        <input type="hidden" name="h_liquiditeit" id="h_liquiditeit" />
        <input type="hidden" name="h_liquiditeitp" id="h_liquiditeitp" />
        <input type="hidden" name="h_totalincome" id="h_totalincome" value="<?php if(isset($_SESSION['finaforte']['totalincome']) && !empty($_SESSION['finaforte']['totalincome'])){ echo $_SESSION['finaforte']['totalincome']; } ?>" />
        <input type="hidden" name="h_totalincomep" id="h_totalincomep" />
        <input type="hidden" name="h_max_hypotheek" id="h_max_hypotheek" />
        <input type="hidden" name="h_maandlasten" id="h_maandlasten" />
        <input type="hidden" name="h_totalincome_sum" id="h_totalincome_sum" />
    </div>
<script type="text/javascript">

        jQuery(document).ready(function($){

            $(".sidebar-hide-show").click(function () {
            $(".start-right").show();
            $("body").addClass("static-sidebar");
            });
        $(".close-sidebar").click(function () {
            $(".start-right").hide();
            $("body").removeClass("static-sidebar");
        });

        });

        function total_calculation() {

            var totalincome = jQuery("#h_totalincome").val();
            var totalincomep = jQuery("#h_totalincomep").val();
            var solvabiliteit = jQuery("#h_solvabiliteit").val();
            var solvabiliteitp = jQuery("#h_solvabiliteitp").val();
            var liquiditeit = jQuery("#h_liquiditeit").val();
            var liquiditeitp = jQuery("#h_liquiditeitp").val();
            var maximale_hypotheek = jQuery("#h_max_hypotheek").val();
            var maandlasten = jQuery("#h_maandlasten").val();
            var totalincome_sum = jQuery("#h_totalincome_sum").val();
            var yearselection = jQuery("#h_yearselection").val();
            var typeselection = jQuery("#h_typeselection").val();
            var partneryearselection = jQuery("#h_partneryearselection").val();
            var partnertypeselection = jQuery("#h_partnertypeselection").val();
            var cal_sugg_text = jQuery("#cal_sugg_text").val();

            // income
            var txt_halfyear_first = jQuery("#txt_halfyear_first").val();
            var txt_halfyear_second = jQuery("#txt_halfyear_second").val();
            var txt_halfyear_third = jQuery("#txt_halfyear_third").val();
            var txt_winstuitonderneming_1 = jQuery("#txt_winstuitonderneming_1").val();
            var txt_winstuitonderneming_2 = jQuery("#txt_winstuitonderneming_2").val();
            var txt_winstuitonderneming_3 = jQuery("#txt_winstuitonderneming_3").val();
            
            var txt_salaris_1 = jQuery("#txt_salaris_1").val();
            var txt_dividend_1 = jQuery("#txt_dividend_1").val();
            var txt_overwinst_1 = jQuery("#txt_overwinst_1").val();
            var txt_salaris_2 = jQuery("#txt_salaris_2").val();
            var txt_dividend_2 = jQuery("#txt_dividend_2").val();
            var txt_overwinst_2 = jQuery("#txt_overwinst_2").val();
            var txt_salaris_3 = jQuery("#txt_salaris_3").val();
            var txt_dividend_3 = jQuery("#txt_dividend_3").val();
            var txt_overwinst_3 = jQuery("#txt_overwinst_3").val();
            // on off switch
            var myonoffswitch1 = jQuery("#myonoffswitch1").val();
            var myonoffswitch3 = jQuery("#myonoffswitch3").val();
            var ponoffswitch1 = jQuery("#ponoffswitch1").val();
            var pmyonoffswitch3 = jQuery("#pmyonoffswitch3").val();
            //partner income
            var txt_loondienst = jQuery("#txt_loondienst").val();
            var txt_halfyearp_first = jQuery("#txt_halfyearp_first").val();
            var txt_halfyearp_second = jQuery("#txt_halfyearp_second").val();
            var txt_halfyearp_third = jQuery("#txt_halfyearp_third").val();
            var txt_winstuitondernemingp_1 = jQuery("#txt_winstuitondernemingp_1").val();
            var txt_winstuitondernemingp_2 = jQuery("#txt_winstuitondernemingp_2").val();
            var txt_winstuitondernemingp_3 = jQuery("#txt_winstuitondernemingp_3").val();
            
            var txt_salarisp_1 = jQuery("#txt_salarisp_1").val();
            var txt_dividendp_1 = jQuery("#txt_dividendp_1").val();
            var txt_overwinstp_1 = jQuery("#txt_overwinstp_1").val();
            var txt_salarisp_2 = jQuery("#txt_salarisp_2").val();            
            var txt_dividendp_2 = jQuery("#txt_dividendp_2").val();
            var txt_overwinstp_2 = jQuery("#txt_overwinstp_2").val();
            var txt_salarisp_3 = jQuery("#txt_salarisp_3").val();
            var txt_dividendp_3 = jQuery("#txt_dividendp_3").val();
            var txt_overwinstp_3 = jQuery("#txt_overwinstp_3").val();
            // liq & sol
            var txt_eigenvermogen_1 = jQuery("#txt_eigenvermogen_1").val();
            var txt_balanstotaal_1 = jQuery("#txt_balanstotaal_1").val();
            var txt_eigenvermogen_2 = jQuery("#txt_eigenvermogen_2").val();
            var txt_balanstotaal_2 = jQuery("#txt_balanstotaal_2").val();
            var txt_eigenvermogen_3 = jQuery("#txt_eigenvermogen_3").val();
            var txt_balanstotaal_3 = jQuery("#txt_balanstotaal_3").val();
            var txt_vlottendeactiva_1 = jQuery("#txt_vlottendeactiva_1").val();
            var txt_kortvreemdvermogen_1 = jQuery("#txt_kortvreemdvermogen_1").val();
            var txt_vlottendeactiva_2 = jQuery("#txt_vlottendeactiva_2").val();
            var txt_kortvreemdvermogen_2 = jQuery("#txt_kortvreemdvermogen_2").val();
            var txt_vlottendeactiva_3 = jQuery("#txt_vlottendeactiva_3").val();
            var txt_kortvreemdvermogen_3 = jQuery("#txt_kortvreemdvermogen_3").val();
            // partner sol & liq
            var txt_eigenvermogenp_1 = jQuery("#txt_eigenvermogenp_1").val();
            var txt_balanstotaalp_1 = jQuery("#txt_balanstotaalp_1").val();
            var txt_eigenvermogenp_2 = jQuery("#txt_eigenvermogenp_2").val();
            var txt_balanstotaalp_2 = jQuery("#txt_balanstotaalp_2").val();
            var txt_eigenvermogenp_3 = jQuery("#txt_eigenvermogenp_3").val();
            var txt_balanstotaalp_3 = jQuery("#txt_balanstotaalp_3").val();
            var txt_vlottendeactivap_1 = jQuery("#txt_vlottendeactivap_1").val();
            var txt_kortvreemdvermogenp_1 = jQuery("#txt_kortvreemdvermogenp_1").val();
            var txt_vlottendeactivap_2 = jQuery("#txt_vlottendeactivap_2").val();
            var txt_kortvreemdvermogenp_2 = jQuery("#txt_kortvreemdvermogenp_2").val();
            var txt_vlottendeactivap_3 = jQuery("#txt_vlottendeactivap_3").val();
            // other fields
            var group1 = jQuery("input[name='group1']:checked").val();
            var single_slider_first = jQuery("#single_slider_first").val();
            var single_slider_tv1 = jQuery("#single_slider_tv1").val();
            var single_slider_ph1 = jQuery("#single_slider_ph1").val();
            // partner other fields
            var pgroup1 = jQuery("input[name='rdo_partnertype']:checked").val();           
            //var rdo_partner = jQuery("input[name='rdo_partner']:checked").val();
            var yn_switch = jQuery("#yn_switch").val();
            
            var single_slider_2 = jQuery("#single_slider_2").val();
           // var pid = jQuery("#div_calculationform").attr('data-pid');

            jQuery.ajax({
                type: "POST",
                url: "<?php echo admin_url('admin-ajax.php'); ?>",               
                data: 'action=view_total_calculation&totalincome=' + totalincome + '&totalincomep=' + totalincomep + '&solvabiliteit=' + solvabiliteit +
                        '&solvabiliteitp=' + solvabiliteitp + '&liquiditeit=' + liquiditeit + '&liquiditeitp=' + liquiditeitp + '&maximale_hypotheek=' + maximale_hypotheek + '&maandlasten=' + maandlasten + '&totalincome_sum=' + totalincome_sum + '&yearselection=' + yearselection + '&typeselection=' + typeselection + '&partneryearselection='+ partneryearselection + '&partnertypeselection=' + partnertypeselection +  '&txt_halfyear_first=' +txt_halfyear_first+ '&txt_halfyear_second=' + txt_halfyear_second + '&txt_halfyear_third=' + txt_halfyear_third + '&txt_winstuitonderneming_1=' + txt_winstuitonderneming_1 + '&txt_winstuitonderneming_2=' + txt_winstuitonderneming_2 + '&txt_winstuitonderneming_3=' + txt_winstuitonderneming_3 + '&txt_salaris_1=' + txt_salaris_1 + '&txt_dividend_1=' + txt_dividend_1 + '&txt_overwinst_1=' + txt_overwinst_1 + '&txt_salaris_2=' + txt_salaris_2 + '&txt_dividend_2=' + txt_dividend_2 +  '&txt_overwinst_2=' + txt_overwinst_2 + '&txt_salaris_3=' + txt_salaris_3 + '&txt_dividend_3=' + txt_dividend_3 + '&txt_overwinst_3=' + txt_overwinst_3 + '&txt_eigenvermogen_1=' +txt_eigenvermogen_1 + '&txt_balanstotaal_1=' +txt_balanstotaal_1 + '&txt_eigenvermogen_2=' +txt_eigenvermogen_2 + '&txt_balanstotaal_2=' +txt_balanstotaal_2 + '&txt_eigenvermogen_3=' +txt_eigenvermogen_3 + '&txt_balanstotaal_3=' +txt_balanstotaal_3 + '&txt_vlottendeactiva_1=' +txt_vlottendeactiva_1 + '&txt_kortvreemdvermogen_1=' +txt_kortvreemdvermogen_1 + '&txt_vlottendeactiva_2=' +txt_vlottendeactiva_2 + '&txt_kortvreemdvermogen_2=' +txt_kortvreemdvermogen_2 + '&txt_vlottendeactiva_3=' +txt_vlottendeactiva_3 + '&txt_kortvreemdvermogen_3=' +txt_kortvreemdvermogen_3 + '&txt_eigenvermogenp_1=' +txt_eigenvermogenp_1 + '&txt_balanstotaalp_1=' +txt_balanstotaalp_1 + '&txt_eigenvermogenp_2=' +txt_eigenvermogenp_2 + '&txt_balanstotaalp_2=' +txt_balanstotaalp_2 + '&txt_eigenvermogenp_3=' +txt_eigenvermogenp_3 + '&txt_balanstotaalp_3=' +txt_balanstotaalp_3 + '&txt_vlottendeactivap_1=' + txt_vlottendeactivap_1 + '&txt_kortvreemdvermogenp_1=' +txt_kortvreemdvermogenp_1 + '&txt_vlottendeactivap_2=' +txt_vlottendeactivap_2 + '&txt_kortvreemdvermogenp_2=' +txt_kortvreemdvermogenp_2 + '&txt_vlottendeactivap_3=' + txt_vlottendeactivap_3 + '&txt_loondienst=' + txt_loondienst + '&txt_halfyearp_first=' +txt_halfyearp_first + '&txt_halfyearp_second=' +txt_halfyearp_second + '&txt_halfyearp_third=' +txt_halfyearp_third + '&txt_salarisp_1=' +txt_salarisp_1 + '&txt_dividendp_1=' +txt_dividendp_1 + '&txt_overwinstp_1=' +txt_overwinstp_1 + '&txt_salarisp_2=' + txt_salarisp_2 + '&txt_dividendp_2=' +txt_dividendp_2 + '&txt_overwinstp_2=' +txt_overwinstp_2 + '&txt_winstuitondernemingp_1=' +txt_winstuitondernemingp_1 + '&txt_winstuitondernemingp_2=' +txt_winstuitondernemingp_2 + '&txt_winstuitondernemingp_3=' +txt_winstuitondernemingp_3 + '&txt_salarisp_3=' +txt_salarisp_3 + '&txt_dividendp_3=' +txt_dividendp_3 + '&txt_overwinstp_3=' +txt_overwinstp_3 + '&group1=' +group1 + '&single_slider_first=' +single_slider_first + '&single_slider_tv1=' +single_slider_tv1 + '&single_slider_ph1=' +single_slider_ph1 + '&pgroup1=' +pgroup1 + '&yn_switch=' +yn_switch + '&single_slider_2=' +single_slider_2 + '&myonoffswitch1=' + myonoffswitch1 + '&myonoffswitch3='+ myonoffswitch3 + '&ponoffswitch1=' + ponoffswitch1+ '&pmyonoffswitch3=' + pmyonoffswitch3 ,
                success: function (responseText) {
                   console.log(responseText);
                    location.reload();         
                    jQuery(document).scrollTop(0);
                }
            });
        }
       
</script>
<?php 
/**
 * Total calculation form content
 * Solvabiliteit toevoegen & Liquiditeit toevoegen Grapg result
 * @package Finaforte
 * @since 1.0
 */

include( "admin-options.php");
?>
<style type="text/css">

    .start-total-page h1, .start-total-page h2.big-heading{line-height: <?php echo $title_font_size + 4; ?>px;}
    .start-total-page .back-page, .final-value2.emailDesc, .start-total-page .final-value ul li span, .start-total-page .total-description-wrapper p, .start-total-page .colorline-box p, .user-desc h4.big-sub-heading {line-height: <?php echo $text_font_size + 4; ?>px;}

    .start-total-page .final-value h3, .start-total-page .final-value h4, .start-total-page .radio-color h2.big-heading, .start-total-page h3.big-heading, .start-total-page h1, 
    .start-total-page .final-value2 h2.big-heading, .total_cal_ul li span {line-height: <?php echo $subtitle_font_size + 4; ?>px;}

    .total-box ul li {line-height: <?php echo $gentext_font_size + 4; ?>px;}
   
    .start-box.p0 {border: 1px solid <?php echo $total_cal_border_clr; ?>; padding: 8px; border-radius: <?php echo $border_radius; ?>px; }
    .final-value2{border: 1px solid <?php echo $total_cal_border_clr; ?>; padding: 8px; border-radius: <?php echo $border_radius; ?>px; }   
</style>

<?php
$solvability_graph = "";
$p_solvability_graph = "";
$solvency_text = "";

if (isset($_SESSION['finaforte']['solvabiliteit']) && $_SESSION['finaforte']['solvabiliteit'] != '') {
    $solvability = $_SESSION['finaforte']['solvabiliteit'];
    if ($solvability >= 20) {  /*green*/
        $solvability_graph = 87.5;
        $solvency_text = finaforte_get_option('solvency_green_text');
    } else if ($solvability > 15 && $solvability < 20) {  
        /*yellow*/
        $solvability_graph = 57.5;
        $solvency_text = finaforte_get_option('solvency_yellow_text');
    } else if ($solvability < 15) { /*red*/
        $solvability_graph = 9.5;
        $solvency_text = finaforte_get_option('solvency_red_text');
    }
}
if (isset($_SESSION['finaforte']['solvabiliteitp']) && $_SESSION['finaforte']['solvabiliteitp'] != '') {
        $solvability = $_SESSION['finaforte']['solvabiliteitp'];
        if ($solvability >= 20) {
            $p_solvability_graph = 87.5;
            $solvency_textp = finaforte_get_option('solvency_green_text');
        } else if ($solvability > 15 && $solvability < 20) {
            $p_solvability_graph = 57.5;
            $solvency_textp = finaforte_get_option('solvency_yellow_text');
        } else if ($solvability < 15) {
            $p_solvability_graph = 9.5;
            $solvency_textp = finaforte_get_option('solvency_red_text');
        }
}

$liquidity_graph = "";
$p_liquidity_graph = "";
$liquidity_text = "";

if (isset($_SESSION['finaforte']['liquiditeit']) && $_SESSION['finaforte']['liquiditeit'] != '') {
    $liquidity = $_SESSION['finaforte']['liquiditeit'];
    if ($liquidity >= 1) {  /*green*/
        $liquidity_graph = 88;
        $liquidity_text = finaforte_get_option('liquidity_green_text');
    } else if ($liquidity < 1 && $liquidity > 0.9) { /*yellow*/
        $liquidity_graph = 58;
        $liquidity_text = finaforte_get_option('liquidity_yellow_text');
    } else if ($liquidity <= 0.9) { /*red*/            
        $liquidity_graph = 8;
        $liquidity_text = finaforte_get_option('liquidity_red_text');
    }
}
if (isset($_SESSION['finaforte']['liquiditeitp']) && $_SESSION['finaforte']['liquiditeitp'] != '') {
    $liquidity = $_SESSION['finaforte']['liquiditeitp'];
    if ($liquidity >= 1) {
        $p_liquidity_graph = 88;
        $liquidity_text = finaforte_get_option('liquidity_green_text');
    } else if ($liquidity < 1 && $liquidity > 0.9) {
        $p_liquidity_graph = 58;
        $liquidity_text = finaforte_get_option('liquidity_yellow_text');
    } else if ($liquidity <= 0.9) {
        $p_liquidity_graph = 8;
        $liquidity_text = finaforte_get_option('liquidity_red_text');
    }
}

$total_incom = isset($_SESSION['finaforte']['totalincome']) ? $_SESSION['finaforte']['totalincome'] : 0.00;
$totalincome_sum = ($_SESSION['finaforte']['totalincome_sum'] != '') ? number_format($_SESSION['finaforte']['totalincome_sum'], 2, ',' , '.') : '0,00';

$maximale_hypotheek = round($_SESSION['finaforte']['maximale_hypotheek']);
$maximale_hypotheek = ($maximale_hypotheek!= '') ? number_format($maximale_hypotheek, 0, ',' , '.') : '0,00';

$maandlasten = round($_SESSION['finaforte']['maandlasten']);
$maandlasten = ($maandlasten!= '') ? number_format($maandlasten, 0, ',' , '.') : '0,00';

$totalincom_p = $_SESSION['finaforte']['totalincomep'] ? $_SESSION['finaforte']['totalincomep'] : '0.00';
$show_total_income = !empty($_SESSION['finaforte']['totalincome']) ? number_format($_SESSION['finaforte']['totalincome'], 0, ',' , '.') : '0,00';
$disp_total_income = $totalincom_p + $total_incom;
$disp_total_income = round($disp_total_income);
$disp_total_income = !empty($disp_total_income) ? number_format($disp_total_income, 0, ',' , '.') : '0,00';
$mortgage_interest_disp = !empty($mortgage_interest) ? number_format($mortgage_interest, 2, ',' , '.') : '0,00';

if(!empty($solvability_graph) || !empty( $liquidity_graph)){ ?>

    <style type="text/css">
        .border-top1 { border-top: 1px solid <?php echo $subtitle_color; ?>; margin-left: 1px; margin-right: 1px;  padding-top: 16px; }
    </style>
<?php }

$show_partner_html = '';
if ($totalincom_p > 0) {
    $totalincom_p = round($totalincom_p);
    $show_partner_html = ' <li>
                            <h3 style="font-size:'.$subtitle_font_size.'px !important; color: '.$total_cal_txt_clr.'!important;" >Toetsinkomen partner</h3>
                            <h4 style="font-size:'.$subtitle_font_size.'px !important; color: '.$total_cal_txt_clr.'!important;">€ <span>' . number_format($totalincom_p, 0, ',' , '.') . '</span></h4>
                            </li>';
}

$form_html = '<div class="start-pag start-total-page" id="total_cal_form" data-pid=""> <div class="container"> <h1 style="font-size:'.$title_font_size.'px !important; color: '.$title_color.'!important;">De totale berekening</h1> <div class="total-page" style="background: ' . $backgroundcolor . ';"> <a href="javascript:;" onclick="backto_calculator()" class="back-page" style="font-size:'. $subtitle_font_size .'px; color:'.$subtitle_color.'; border-color: '.$subtitle_color.'; "> <i class="fa fa-arrow-left" aria-hidden="true"></i><span>Terug naar calculator<br></span></a> <div class="container"> <div class="top-section"> <div class="row"> <div class="col-md-6 total-left-part"> <div class="start-box p0" style="background: '.$total_cal_bg_clr.';"> <h2 class="big-heading" style="font-size:'. $title_font_size.'px !important; color: '.$total_cal_txt_clr.'!important;">Overzicht</h2> <div class="final-value"> <ul><li> <h3 style="font-size:'.$subtitle_font_size.'px !important; color: '.$total_cal_txt_clr.'!important;" >Uw toetsinkomen</h3> <h4 style="font-size:'.$subtitle_font_size.'px !important; color: '.$total_cal_txt_clr.'!important;">€ <span>' . $show_total_income. '</span></h4></li>'. $show_partner_html.'<li><h3 style="font-size:'.$subtitle_font_size.'px !important; color: '.$total_cal_txt_clr.'!important;" >Maximale hypotheek</h3> <h4 style="font-size:'.$subtitle_font_size.'px !important; color: '.$total_cal_txt_clr.'!important;" >€ <span>' . $maximale_hypotheek. '</span></h4> </li> <li><h3 style="font-size:'.$subtitle_font_size.'px !important; color: '.$total_cal_txt_clr.'!important;" >Maandlasten max. hypotheek</h3> <h4 style="font-size:'.$subtitle_font_size.'px !important; color: '.$total_cal_txt_clr.'!important;" >€ <span>' . $maandlasten . '</span></h4></li> <li> <span style="font-size:'.$text_font_size.'px !important; color: '.$total_cal_txt_clr.'!important;">Bij toetsrente <i>'.$mortgage_interest_disp.'</i>%</span></li><div class="clearfix"></div></ul></div></div></div><div class="col-md-6 total-desc total-right-part"> <div class="total-right-innerpart"> <div class="total-description-wrapper"> <h3 class="big-heading" style="font-size:'.$subtitle_font_size.'px !important; color: '.$subtitle_color.'!important;">'.finaforte_esc_attr(finaforte_get_option("free_advice_label")).'</h3> <p style="font-size:'.$text_font_size.'px !important; color: '.$text_color.'!important;">'.finaforte_esc_attr(finaforte_get_option('free_advice_text')).'</p></div> <div class="email-link">                            <a href="javascript:;" onclick="receive_by_email()" class="btn btn-primary btn-yellow btn-email" style="color: '.$btn_text_color.'; background: '.$btn_bg_color.'; border-color: '.$btn_border_color.'!important; border-radius: '.$border_radius.'px !important;">'.finaforte_esc_attr(finaforte_get_option('email_button_text')).'</a> </div> </div> </div> </div> </div> <div class="radio-color row">';

$sol_col = ($p_solvability_graph != '' && $solvability_graph != '') ? '6' : '12';

$psol_col = ($p_solvability_graph != '' && $solvability_graph != '') ? '6' : '12';

if ($solvability_graph != '') {

    $form_html.='<div class="col-md-' . $sol_col . ' colorline1 colorline-box"> <h2 style="font-size: '.$subtitle_font_size.'px !important; color: '.$subtitle_color.'!important;" class="big-heading text-center">Uw solvabiliteitsscore</h2> <div class="liner-gradiance"> <div class="more-then-color" style="background: #ff0100;background: -moz-linear-gradient(right, #ff0100 0%, #ff8600 33%, #dada00 66%, #92ff00 100%); background: -webkit-linear-gradient(right, #ff0100 0%,#ff8600 33%,#dada00 66%,#92ff00 100%); background: linear-gradient(to right, ' . $solvency_red . ' 0%,#ff8600 33%,' . $solvency_yellow . ' 66%,' . $solvency_green . ' 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr=\'#ff0100\', endColorstr=\'#92ff00\',GradientType=0);"> <div class="overlay-image" style="left: ' . $solvability_graph . '%"> <img src="'.FINAFORTE_URL.'assets/images/line-arrow.png"> </div> </div></div> <p class="text-center" style="font-size: '.$text_font_size.'px !important; color: '.$text_color.'">' . $solvency_text . '</p> </div>';
}
if ($p_solvability_graph != '') {

    $form_html.='<div class="col-md-' . $sol_col . ' colorline1 colorline-box"> <h2 style="font-size: '.$subtitle_font_size.'px !important; color: '.$subtitle_color.' !important;" class="big-heading text-center"> solvabiliteitsscore partner</h2> <div class="liner-gradiance"><div class="more-then-color" style="background: #ff0100;background: -moz-linear-gradient(right, #ff0100 0%, #ff8600 33%, #dada00 66%, #92ff00 100%); background: -webkit-linear-gradient(right, #ff0100 0%,#ff8600 33%,#dada00 66%,#92ff00 100%); background: linear-gradient(to right, ' . $solvency_red . ' 0%,#ff8600 33%,' . $solvency_yellow . ' 66%,' . $solvency_green . ' 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr=\'#ff0100\', endColorstr=\'#92ff00\',GradientType=0);"> <div class="overlay-image" style="left: ' . $p_solvability_graph . '%"> <img src="'.FINAFORTE_URL.'assets/images/line-arrow.png"> </div> </div></div> <p class="text-center" style="font-size: '.$text_font_size.'px !important; color: '.$text_color.'">' . $solvency_textp . '</p> </div>';
}
/* not tab */
$liq_col = ($p_liquidity_graph != '' && $liquidity_graph != '') ? '6' : '12';
if ($liquidity_graph != '') {
        $form_html.='<div class="col-md-' . $liq_col . ' colorline2 colorline-box" style="clear:both; float:left;">
                        <h2 style="font-size: '.$subtitle_font_size.'px !important; color: '.$subtitle_color.' !important;" class="big-heading text-center">Uw liquiditeitsscore</h2>   
                        <div class="liner-gradiance">
                            <div class="more-then-color" style="background: #ff0100;background: -moz-linear-gradient(right, #ff0100 0%, #ff8600 33%, #dada00 66%, #92ff00 100%); background: -webkit-linear-gradient(right, #ff0100 0%,#ff8600 33%,#dada00 66%,#92ff00 100%); background: linear-gradient(to right, ' . $liquidity_red . ' 0%,#ff8600 33%,' . $liquidity_yellow . ' 66%,' . $liquidity_green . ' 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr=\'#ff0100\', endColorstr=\'#92ff00\',GradientType=0);">
                                <div class="overlay-image" style="left: ' . $liquidity_graph . '%">
                                    <img src="'.FINAFORTE_URL.'assets/images/line-arrow.png">
                                </div>
                            </div>
                        </div>
                        <p class="text-center" style="font-size: '.$text_font_size.'px !important; color: '.$text_color.'">' . $liquidity_text . '</p>
                    </div>';
}
if ($p_liquidity_graph != '') {
    $form_html.='<div class="col-md-' . $liq_col . ' colorline2 colorline-box" style="clear:both; float:left;">
                    <h2 style="font-size: '.$subtitle_font_size.'px !important; color: '.$subtitle_color.' !important;" class="big-heading text-center"> liquiditeitsscore partner</h2>   
                    <div class="liner-gradiance">
                        <div class="more-then-color" style="background: #ff0100;background: -moz-linear-gradient(right, #ff0100 0%, #ff8600 33%, #dada00 66%, #92ff00 100%); background: -webkit-linear-gradient(right, #ff0100 0%,#ff8600 33%,#dada00 66%,#92ff00 100%); background: linear-gradient(to right, ' . $liquidity_red . ' 0%,#ff8600 33%,' . $liquidity_yellow . ' 66%,' . $liquidity_green . ' 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr=\'#ff0100\', endColorstr=\'#92ff00\',GradientType=0);">
                            <div class="overlay-image" style="left: ' . $p_liquidity_graph . '%">
                                <img src="'.FINAFORTE_URL.'assets/images/line-arrow.png">
                            </div>
                        </div>
                    </div>
                    <p class="text-center" style="font-size: '.$text_font_size.'px !important; color: '.$text_color.'">' . $liquidity_text . '</p>
                </div>';
}

// get values from admin side
$totalincome_sum = $_SESSION['finaforte']['totalincome_sum']; // with .70%
$totalincome_sum = $totalincome_sum ? $totalincome_sum : 0;
$ti_sum = $totalincom_p + $_SESSION['finaforte']['totalincome'];
$maximale_hypotheek = $_SESSION['finaforte']['maximale_hypotheek'];
$bruto_maandlast = $_SESSION['finaforte']['maandlasten'];
$h_yearselection = $_SESSION['finaforte']['yearselection'];

$bruto_maandlast = round($bruto_maandlast,2);
$maandrente = ($mortgage_interest / 100) / 12;
 
// calculation 1
$cyear1 = $year1 * 12;
$maximale_hypotheek_1 = $bruto_maandlast / ($maandrente / (1 - (pow((1 + $maandrente), -$cyear1) )));
$maximale_hypotheek_1 = ($max_hypo_1_per * $maximale_hypotheek_1)/100 ; 
$maximale_hypotheek_1 = round($maximale_hypotheek_1, 2);
$hypo_ber_rent_1 = $maximale_hypotheek_1 * ($rent1 / 100);
$hypo_ber_rent_1 = round($hypo_ber_rent_1, 2);
$aflossing_1 = $bruto_maandlast - ($hypo_ber_rent_1/12);
$aflossing_1 = round($aflossing_1,2);
$belastingteruggave_1 = (($belastingteruggave1 * $hypo_ber_rent_1) / 100)/12;
$belastingteruggave_1 = round($belastingteruggave_1, 2);
$netto_per_maand_1 = round(($bruto_maandlast - $belastingteruggave_1), 2);

// calculation 2
$cyear2 = $year2 * 12;
if($h_yearselection == '2'){$min_hypo_2_per = '90'; }
$ti_sum2 = ($ti_sum * $min_hypo_2_per)/100;
$totalincome_sum2 = ($totalincome_sum * $min_hypo_2_per)/100;

$intrest_ammt2 = maximale_hypotheek_val($rent2, $totalincome_sum2, $ti_sum2);
$maandrente2 = ($rent2 / 100) / 12;
$maandlasten2 = $intrest_ammt2 / 12;
$maximale_hypotheek_2 = $maandlasten2 / ($maandrente2 / (1 - (pow((1 + $maandrente2), -$cyear2) )));
$maximale_hypotheek_2 = round($maximale_hypotheek_2, 2);
$hypo_ber_rent_2 = $maximale_hypotheek_2 * ($rent2 / 100);
$hypo_ber_rent_2 = round($hypo_ber_rent_2, 2);
$aflossing_2 = $maandlasten2 - ($hypo_ber_rent_2/12);
$aflossing_2 = round($aflossing_2,2);
$belastingteruggave_2 = (($belastingteruggave2 * $hypo_ber_rent_2) / 100)/12;
$belastingteruggave_2 = round($belastingteruggave_2, 2);
$netto_per_maand_2 = round(($maandlasten2 - $belastingteruggave_2), 2);

// calculation 3
$cyear3 = $year3 * 12;    
$ti_sum3 = $ti_sum;
$totalincome_sum3 = $totalincome_sum;

$intrest_ammt3 = maximale_hypotheek_val($rent3, $totalincome_sum3, $ti_sum3);
$maandrente3 = ($rent3 / 100) / 12;
$maandlasten3 = $intrest_ammt3 / 12;
$max_hypo_3 = $maandlasten3 / ($maandrente3 / (1 - (pow((1 + $maandrente3), -$cyear3) )));
$max_hypo_3 = round($max_hypo_3, 2);

$maximale_hypotheek_3 = (($max_hypo_3_bkd > $max_hypo_3) || (empty($max_hypo_3_bkd))) ? $max_hypo_3 : $max_hypo_3_bkd;

$maximale_hypotheek_3 = round($maximale_hypotheek_3, 2);
$hypo_ber_rent_3 = $maximale_hypotheek_3 * ($rent3 / 100);
$hypo_ber_rent_3 = round($hypo_ber_rent_3, 2);
$aflossing_3 = $maandlasten3-($hypo_ber_rent_3/12);
$aflossing_3 = round($aflossing_3,2);
$belastingteruggave_3 = (($belastingteruggave3 * $hypo_ber_rent_3) / 100)/12;
$belastingteruggave_3 = round($belastingteruggave_3, 2);
$netto_per_maand_3 = round(($maandlasten3 - $belastingteruggave_3), 2);

// calculation 4
$cyear4 = $year4 * 12;   
$ti_sum4 = $ti_sum;
$totalincome_sum4 = $totalincome_sum;

$intrest_ammt4 = maximale_hypotheek_val($rent4, $totalincome_sum4, $ti_sum4);
$maandrente4 = ($rent4 / 100) / 12;
$maandlasten4 = $intrest_ammt4 / 12;
$maximale_hypotheek_4 = $maandlasten4 / ($maandrente4 / (1 - (pow((1 + $maandrente4), -$cyear4) )));

$maximale_hypotheek_4 = round($maximale_hypotheek_4, 2);
$hypo_ber_rent_4 = $maximale_hypotheek_4 * ($rent4 / 100);
$hypo_ber_rent_4 = round($hypo_ber_rent_4, 2);
$aflossing_4 = $maandlasten4-($hypo_ber_rent_4/12);
$aflossing_4 = round($aflossing_4,2);
$belastingteruggave_4 = (($belastingteruggave4 * $hypo_ber_rent_4) / 100)/12;
$belastingteruggave_4 = round($belastingteruggave_4, 2);
$netto_per_maand_4 = round(($maandlasten4 - $belastingteruggave_4), 2);

$maximale_hypotheek_1 = round($maximale_hypotheek_1);
$maximale_hypotheek_2 = round($maximale_hypotheek_2);
$maximale_hypotheek_3 = round($maximale_hypotheek_3);
$maximale_hypotheek_4 = round($maximale_hypotheek_4);
$hypo_ber_rent_1 = round($hypo_ber_rent_1);
$hypo_ber_rent_2 = round($hypo_ber_rent_2);
$hypo_ber_rent_3 = round($hypo_ber_rent_3);
$hypo_ber_rent_4 = round($hypo_ber_rent_4);
$aflossing_1 = round($aflossing_1);
$aflossing_2 = round($aflossing_2);
$aflossing_3 = round($aflossing_3);
$aflossing_4 = round($aflossing_4);
$bruto_maandlast = round($bruto_maandlast);
$belastingteruggave_1 = round($belastingteruggave_1);
$belastingteruggave_2 = round($belastingteruggave_2);
$belastingteruggave_3 = round($belastingteruggave_3);
$belastingteruggave_4 = round($belastingteruggave_4);
$netto_per_maand_1 = round($netto_per_maand_1);
$netto_per_maand_2 = round($netto_per_maand_2);
$netto_per_maand_3 = round($netto_per_maand_3);
$netto_per_maand_4 = round($netto_per_maand_4);

$totalincom_p = $_SESSION['finaforte']['totalincomep'] ? $_SESSION['finaforte']['totalincomep'] : '0.00';

$calculation_1_html = '<div class="col-lg-6 col-md-12 type:'.$totalincom_p.' ptype:'.$_SESSION['finaforte']['typeselection'].'" style="color: '.$gentext_color.';">
<div class="total-box" style="border-radius: '.$border_radius.'px !important; border-color: '. $total_cal_border_clr.'!important;">
    <h3 class="big-heading" style="font-size: '.$subtitle_font_size.'px !important; color: '.$subtitle_color.' !important;">Hypotheekberekening 1</h3>
   
    <ul class="head-value">
        <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Maximale hypotheek</strong> <p>€ <span>' . number_format($maximale_hypotheek_1, 0, ',' , '.') . '</span></p><div class="clearfix"></div></li>
    </ul>
    <ul class="body-value">
    <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Rente (toetsrente ' . $rent1 . '%)</strong> <p>€ <span>' . number_format($hypo_ber_rent_1/12, 0, ',' , '.') . '</span></p><div class="clearfix"></div></li>
    <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Aflossing</strong> <p>€ <span>' . number_format($aflossing_1, 0, ',' , '.') . '</span></p><div class="clearfix"></div></li>

    <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Bruto maandlast</strong> <p>€ <span>' . number_format($bruto_maandlast, 0, ',' , '.') . '</span></p><div class="clearfix"></div></li>
    <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Belastingteruggave</strong> <p>€ <span>' . number_format($belastingteruggave_1, 0, ',' , '.') . '</span></p><div class="clearfix"></div></li>
    </ul>
    <ul class="footer-value">
        <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Netto per maand</strong> <p>€ <span>' . number_format($netto_per_maand_1, 0, ',' , '.') . '</span></p></li>
    </ul>
</div>
</div>';
    
$yearselection = isset($_SESSION['finaforte']['yearselection']) ? $_SESSION['finaforte']['yearselection'] : '';
$typeselection = isset($_SESSION['finaforte']['typeselection']) ? $_SESSION['finaforte']['typeselection'] : '';
$partneryearselection = isset($_SESSION['finaforte']['partneryearselection']) ? $_SESSION['finaforte']['partneryearselection'] : '';
$partnertypeselection = isset($_SESSION['finaforte']['partnertypeselection']) ? $_SESSION['finaforte']['partnertypeselection'] : '';

if(!empty($totalincom_p)) {

    if($yearselection == '0' && $typeselection == 'in1' && $_SESSION['finaforte']['partneryearselection'] < '1' && ($partnertypeselection == '1' || $partnertypeselection == '2')){
        $calculation_2_html = '';
    } else {
          $calculation_2_html = '<div class="col-lg-6 col-md-12" style="color: '.$gentext_color.'">
        <div class="total-box" style="border-radius: '.$border_radius.'px !important; border-color: '. $total_cal_border_clr.'!important;">
        <h3 class="big-heading" style="font-size: '.$subtitle_font_size.'px !important; color: '.$subtitle_color.' !important;">Hypotheekberekening 2</h3>
       
        <ul class="head-value">
            <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Maximale hypotheek</strong> <p>€ <span>' . number_format($maximale_hypotheek_2, 0, ',' , '.') . '</span></p><div class="clearfix"></div></li>
        </ul>
        <ul class="body-value">
            <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Rente (toetsrente ' . $rent2 . '%)</strong> <p>€ <span>' . number_format($hypo_ber_rent_2/12, 0, ',' , '.') . '</span></p><div class="clearfix"></div></li>
            <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Aflossing</strong> <p>€ <span>' . number_format($aflossing_2, 0, ',' , '.') . '</span></p><div class="clearfix"></div></li>

            <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Bruto maandlast</strong> <p>€ <span>' . number_format($maandlasten2, 0, ',' , '.') . '</span></p><div class="clearfix"></div></li>
            <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Belastingteruggave</strong> <p>€ <span>' . number_format($belastingteruggave_2, 0, ',' , '.') . '</span></p><div class="clearfix"></div></li>
        </ul>
        <ul class="footer-value">
            <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Netto per maand</strong> <p>€ <span>' . number_format($netto_per_maand_2, 0, ',' , '.') . '</span></p></li>
        </ul>
        </div>
        </div>';
    }
} else {
    if($yearselection == '0' && $typeselection == 'in1') {
           
         $calculation_2_html = '<div class="col-lg-6 col-md-12" style="color: '.$gentext_color.'">
        <div class="total-box" style="border-radius: '.$border_radius.'px !important; border-color: '. $total_cal_border_clr.'!important;">
        <h3 class="big-heading" style="font-size: '.$subtitle_font_size.'px !important; color: '.$subtitle_color.' !important;">Hypotheekberekening 2</h3>
       
        <ul class="head-value">
            <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Maximale hypotheek</strong> <p>€ <span>' . number_format($maximale_hypotheek_2, 0, ',' , '.') . '</span></p></li>
        </ul>
        <ul class="body-value">
            <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Rente (toetsrente ' . $rent2 . '%)</strong> <p>€ <span>' . number_format($hypo_ber_rent_2/12, 0, ',' , '.') . '</span></p><div class="clearfix"></div><div class="clearfix"></div></li>
            <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Aflossing</strong> <p>€ <span>' . number_format($aflossing_2, 0, ',' , '.') . '</span></p><div class="clearfix"></div><div class="clearfix"></div></li>

            <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Bruto maandlast</strong> <p>€ <span>' . number_format($maandlasten2, 0, ',' , '.') . '</span></p><div class="clearfix"></div><div class="clearfix"></div></li>
            <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Belastingteruggave</strong> <p>€ <span>' . number_format($belastingteruggave_2, 0, ',' , '.') . '</span></p><div class="clearfix"></div></li>
        </ul>
        <ul class="footer-value">
            <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Netto per maand</strong> <p>€ <span>' . number_format($netto_per_maand_2, 0, ',' , '.') . '</span></p></li>
        </ul>
        </div>
        </div>';
    } else {
         $calculation_2_html = '';
    }
}

/* SHOW / HIDE CALCULATION 3 */

if(!empty($totalincom_p)) {

    if($yearselection == '0' && $typeselection == 'in1' && $_SESSION['finaforte']['partneryearselection'] < '1'){
       
        $calculation_3_html = '';
    } else {
        
        $calculation_3_html = '<div class="col-lg-6 col-md-12" style="color: '.$gentext_color.'">
        <div class="total-box" style="border-radius: '.$border_radius.'px !important; border-color: '. $total_cal_border_clr.'!important;">
            <h3 class="big-heading" style="font-size: '.$subtitle_font_size.'px !important; color: '.$subtitle_color.' !important;">Hypotheekberekening 3 met NHG</h3>
            
            <ul class="head-value">
                <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Maximale hypotheek</strong> <p>€ <span>' . number_format($maximale_hypotheek_3, 0, ',' , '.') . '</span></p></li>
            </ul>
            <ul class="body-value">
                <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Rente (toetsrente ' . $rent3 . '%)</strong> <p>€ <span>' . number_format($hypo_ber_rent_3/12, 0, ',' , '.') . '</span></p><div class="clearfix"></div></li>
                <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Aflossing</strong> <p>€ <span>' . number_format($aflossing_3, 0, ',' , '.') . '</span></p><div class="clearfix"></div></li>
                <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Bruto maandlast</strong> <p>€ <span>' . number_format($maandlasten3, 0, ',' , '.') . '</span></p><div class="clearfix"></div></li>
                <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Belastingteruggave</strong> <p>€ <span>' . number_format($belastingteruggave_3, 0, ',' , '.') . '</span></p><div class="clearfix"></div></li>
            </ul>
            <ul class="footer-value">
                <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Netto per maand</strong> <p>€ <span>' . number_format($netto_per_maand_3, 0, ',' , '.') . '</span></p></li>
            </ul>
            </div>
        </div>';
    }
} else {
    if($yearselection == '0' && $typeselection == 'in1') {
           
        $calculation_3_html = '<div class="col-lg-6 col-md-12" style="color: '.$gentext_color.'">
        <div class="total-box" style="border-radius: '.$border_radius.'px !important; border-color: '. $total_cal_border_clr.'!important;">
            <h3 class="big-heading" style="font-size: '.$subtitle_font_size.'px !important; color: '.$subtitle_color.' !important;">Hypotheekberekening 3 met NHG</h3>
            
            <ul class="head-value">
                <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Maximale hypotheek</strong> <p>€ <span>' . number_format($maximale_hypotheek_3, 0, ',' , '.') . '</span></p><div class="clearfix"></div></li>
            </ul>
            <ul class="body-value">
                <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Rente (toetsrente ' . $rent3 . '%)</strong> <p>€ <span>' . number_format($hypo_ber_rent_3/12, 0, ',' , '.') . '</span></p><div class="clearfix"></div></li>
                <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Aflossing</strong> <p>€ <span>' . number_format($aflossing_3, 0, ',' , '.') . '</span></p><div class="clearfix"></div></li>
                <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Bruto maandlast</strong> <p>€ <span>' . number_format($maandlasten3, 0, ',' , '.') . '</span></p><div class="clearfix"></div></li>
                <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Belastingteruggave</strong> <p>€ <span>' . number_format($belastingteruggave_3, 0, ',' , '.') . '</span></p><div class="clearfix"></div></li>
            </ul>
            <ul class="footer-value">
                <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Netto per maand</strong> <p>€ <span>' . number_format($netto_per_maand_3, 0, ',' , '.') . '</span></p></li>
            </ul>
        </div>
    </div>';
    } else{
        $calculation_3_html = '';
    }
}

 /* show/hide cal 4 */

 if(!empty($totalincom_p)) {

    if($yearselection == '0' && $typeselection == 'in1' && $_SESSION['finaforte']['partneryearselection'] < '1'){
        $calculation_4_html = '';
    } else {
         $calculation_4_html = '<div class="col-lg-6 col-md-12" style="color: '.$gentext_color.'">
        <div class="total-box" style="border-radius: '.$border_radius.'px !important; border-color: '. $total_cal_border_clr.'!important;">
            <h3 class="big-heading" style="font-size: '.$subtitle_font_size.'px !important; color: '.$subtitle_color.' !important;">Hypotheekberekening 4</h3>
            
            <ul class="head-value">
                <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Maximale hypotheek</strong> <p>€ <span>' . number_format($maximale_hypotheek_4, 0, ',' , '.') . '</span></p><div class="clearfix"></div></li>
            </ul>
            <ul class="body-value">
                <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Rente (toetsrente ' . $rent4 . '%)</strong> <p>€ <span>' . number_format($hypo_ber_rent_4/12, 0, ',' , '.') . '</span></p><div class="clearfix"></div></li>
                <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Aflossing</strong> <p>€ <span>' . number_format($aflossing_4, 0, ',' , '.') . '</span></p><div class="clearfix"></div></li>
                <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Bruto maandlast</strong> <p>€ <span>' . number_format($maandlasten4, 0, ',' , '.') . '</span></p><div class="clearfix"></div></li>
                <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Belastingteruggave</strong> <p>€ <span>' . number_format($belastingteruggave_4, 0, ',' , '.') . '</span></p><div class="clearfix"></div></li>
            </ul>
            <ul class="footer-value">
                <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Netto per maand</strong> <p>€ <span>' . number_format($netto_per_maand_4, 0, ',' , '.') . '</span></p></li>
            </ul>
        </div>
    </div>';
    }
} else {
    if($yearselection == '0' && $typeselection == 'in1') {
           
       $calculation_4_html = '<div class="col-lg-6 col-md-12" style="color: '.$gentext_color.'">
        <div class="total-box" style="border-radius: '.$border_radius.'px !important; border-color: '. $total_cal_border_clr.'!important;">
            <h3 class="big-heading" style="font-size: '.$subtitle_font_size.'px !important; color: '.$subtitle_color.' !important;">Hypotheekberekening 4</h3>
            
            <ul class="head-value">
                <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Maximale hypotheek</strong> <p>€ <span>' . number_format($maximale_hypotheek_4, 0, ',' , '.') . '</span></p></li>
            </ul>
            <ul class="body-value">
                <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Rente (toetsrente ' . $rent4 . '%)</strong> <p>€ <span>' . number_format($hypo_ber_rent_4/12, 0, ',' , '.') . '</span></p></li>
                <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Aflossing</strong> <p>€ <span>' . number_format($aflossing_4, 0, ',' , '.') . '</span></p></li>
                <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Bruto maandlast</strong> <p>€ <span>' . number_format($maandlasten4, 0, ',' , '.') . '</span></p></li>
                <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Belastingteruggave</strong> <p>€ <span>' . number_format($belastingteruggave_4, 0, ',' , '.') . '</span></p><div class="clearfix"></div></li>
            </ul>
            <ul class="footer-value">
                <li style="font-size: '.$gentext_font_size.'px !important;"><strong>Netto per maand</strong> <p>€ <span>' . number_format($netto_per_maand_4, 0, ',' , '.') . '</span></p></li>
            </ul>
        </div>
    </div>';
    } else{
        $calculation_4_html = '';
    }
}

if($cal_heading){
    $cal_heading_display ='<div class="final-value2 emailDesc" style="font-size: '.$text_font_size.'px !important; color: '.$text_color.' !important;">
                '.$cal_heading.'</div>';
}else{
    $cal_heading_display = '';
}

$disp_total_income = $totalincom_p + $_SESSION['finaforte']['totalincome'];
$disp_total_income = round($disp_total_income);
$disp_total_income = !empty($disp_total_income) ? number_format($disp_total_income, 0, ',' , '.') : '0,00';
$advicer_photo_html = '';
if(!empty($advicer_photo)){
    $advicer_photo_html = '<div class="user-image">                                    
                        <img src="' .$advicer_photo. '" alt="Advicer" title="Advicer">
                    </div> ';
}
$form_html.= '</div>'.$cal_heading_display.'<div class="row">' . $calculation_1_html . ' ' . $calculation_2_html . '' . $calculation_3_html . ' ' . $calculation_4_html . '</div>
            <div class="row">
                <div class="right-desc right-desc2 d-flex flex-row justify-content-end my-flex-container">   
                     <h3 class="big-heading deskt-hide" style="font-size: '.$subtitle_font_size.'px !important; color: '.$subtitle_color.' !important;">Wil je advies of heb je vragen?</h3>                                         
                    <div class="user-desc ">
                        <h3 class="big-heading deskt-show" style="font-size: '.$subtitle_font_size.'px !important; color: '.$subtitle_color.' !important;">Wil je advies of heb je vragen?</h3>
                        <h4 class="big-sub-heading" style="font-size: '.$text_font_size.'px !important; color: '.$text_color.' !important;">Bel met een van onze adviseurs</h4>
                        <h3 class="big-heading big-heading-black" style="font-size: '.$subtitle_font_size.'px !important; color: '.$subtitle_color.' !important;"><span><a style="color: '.$subtitle_color.' !important;" href="tel:'.finaforte_esc_attr(finaforte_get_option("advice_contact")).'">'.finaforte_esc_attr(finaforte_get_option("advice_contact")).'</a></span></h3>
                    </div>'.$advicer_photo_html.'                        
                </div>
            </div>
        </div>
    </div>
</div></div>';
echo $form_html;
$Show_cal_1 = $calculation_1_html != '' ? 1 : 0;
$Show_cal_2 = $calculation_2_html != '' ? 1 : 0;
$Show_cal_3 = $calculation_3_html != '' ? 1 : 0;
$Show_cal_4 = $calculation_4_html != '' ? 1 : 0;
    ?>

     <div class="hidden" style="display: none;">
        <input type="hidden" name="txt_halfyear_first" id="txt_halfyear_first" value="<?php echo $_SESSION['finaforte']['txt_halfyear_first']; ?>" />
        <input type="hidden" name="txt_halfyear_second" id="txt_halfyear_second" value="<?php echo $_SESSION['finaforte']['txt_halfyear_second']; ?>" />
        <input type="hidden" name="txt_halfyear_third" id="txt_halfyear_third" value="<?php echo $_SESSION['finaforte']['txt_halfyear_third']; ?>" />
        <input type="hidden" name="txt_winstuitonderneming_1" id="txt_winstuitonderneming_1" value="<?php echo $_SESSION['finaforte']['txt_winstuitonderneming_1']; ?>" />
        <input type="hidden" name="txt_winstuitonderneming_2" id="txt_winstuitonderneming_2" value="<?php echo $_SESSION['finaforte']['txt_winstuitonderneming_2']; ?>" />
        <input type="hidden" name="txt_winstuitonderneming_3" id="txt_winstuitonderneming_3" value="<?php echo $_SESSION['finaforte']['txt_winstuitonderneming_3']; ?>" />
        <input type="hidden" name="txt_salaris_1" id="txt_salaris_1" value="<?php echo $_SESSION['finaforte']['txt_salaris_1']; ?>" />
        <input type="hidden" name="txt_dividend_1" id="txt_dividend_1" value="<?php echo $_SESSION['finaforte']['txt_dividend_1']; ?>" />
        <input type="hidden" name="txt_overwinst_1" id="txt_overwinst_1" value="<?php echo $_SESSION['finaforte']['txt_overwinst_1']; ?>" />
        <input type="hidden" name="txt_salaris_2" id="txt_salaris_2" value="<?php echo $_SESSION['finaforte']['txt_salaris_2']; ?>" />
        <input type="hidden" name="txt_dividend_2" id="txt_dividend_2" value="<?php echo $_SESSION['finaforte']['txt_dividend_2']; ?>" />
        <input type="hidden" name="txt_overwinst_2" id="txt_overwinst_2" value="<?php echo $_SESSION['finaforte']['txt_overwinst_2']; ?>" />
        <input type="hidden" name="txt_salaris_3" id="txt_salaris_3" value="<?php echo $_SESSION['finaforte']['txt_salaris_3']; ?>" />
        <input type="hidden" name="txt_dividend_3" id="txt_dividend_3" value="<?php echo $_SESSION['finaforte']['txt_dividend_3']; ?>" />
        <input type="hidden" name="txt_overwinst_3" id="txt_overwinst_3" value="<?php echo $_SESSION['finaforte']['txt_overwinst_3']; ?>" />
        <!-- show hide button -->
         <input type="hidden" name="myonoffswitch1" id="myonoffswitch1" value="<?php echo $_SESSION['finaforte']['myonoffswitch1']; ?>" />
         <input type="hidden" name="myonoffswitch3" id="myonoffswitch3" value="<?php echo $_SESSION['finaforte']['myonoffswitch3']; ?>" />
         <input type="hidden" name="ponoffswitch1" id="ponoffswitch1" value="<?php echo $_SESSION['finaforte']['ponoffswitch1']; ?>" />
         <input type="hidden" name="pmyonoffswitch3" id="pmyonoffswitch3" value="<?php echo $_SESSION['finaforte']['pmyonoffswitch3']; ?>" />
        <!-- partner income -->
        <input type="hidden" name="txt_loondienst" id="txt_loondienst" value="<?php echo $_SESSION['finaforte']['txt_loondienst']; ?>" />
        <input type="hidden" name="txt_halfyearp_first" id="txt_halfyearp_first" value="<?php echo $_SESSION['finaforte']['txt_halfyearp_first']; ?>" />
        <input type="hidden" name="txt_halfyearp_second" id="txt_halfyearp_second" value="<?php echo $_SESSION['finaforte']['txt_halfyearp_second']; ?>" />
        <input type="hidden" name="txt_halfyearp_third" id="txt_halfyearp_third" value="<?php echo $_SESSION['finaforte']['txt_halfyearp_third']; ?>" />
        
        <input type="hidden" name="txt_winstuitondernemingp_1" id="txt_winstuitondernemingp_1" value="<?php echo $_SESSION['finaforte']['txt_winstuitondernemingp_1']; ?>" />
        <input type="hidden" name="txt_winstuitondernemingp_2" id="txt_winstuitondernemingp_2" value="<?php echo $_SESSION['finaforte']['txt_winstuitondernemingp_2']; ?>" />
        <input type="hidden" name="txt_winstuitondernemingp_3" id="txt_winstuitondernemingp_3" value="<?php echo $_SESSION['finaforte']['txt_winstuitondernemingp_3']; ?>" />

        <input type="hidden" name="txt_salarisp_1" id="txt_salarisp_1" value="<?php echo $_SESSION['finaforte']['txt_salarisp_1']; ?>" />
        <input type="hidden" name="txt_dividendp_1" id="txt_dividendp_1" value="<?php echo $_SESSION['finaforte']['txt_dividendp_1']; ?>" />
        <input type="hidden" name="txt_overwinstp_1" id="txt_overwinstp_1" value="<?php echo $_SESSION['finaforte']['txt_overwinstp_1']; ?>" />
        <input type="hidden" name="txt_salarisp_2" id="txt_salarisp_2" value="<?php echo $_SESSION['finaforte']['txt_salarisp_2']; ?>" />
        <input type="hidden" name="txt_dividendp_2" id="txt_dividendp_2" value="<?php echo $_SESSION['finaforte']['txt_dividendp_2']; ?>" />
        <input type="hidden" name="txt_overwinstp_2" id="txt_overwinstp_2" value="<?php echo $_SESSION['finaforte']['txt_overwinstp_2']; ?>" />
        <input type="hidden" name="txt_salarisp_3" id="txt_salarisp_3" value="<?php echo $_SESSION['finaforte']['txt_salarisp_3']; ?>" />
        <input type="hidden" name="txt_dividendp_3" id="txt_dividendp_3" value="<?php echo $_SESSION['finaforte']['txt_dividendp_3']; ?>" />
        <input type="hidden" name="txt_overwinstp_3" id="txt_overwinstp_3" value="<?php echo $_SESSION['finaforte']['txt_overwinstp_3']; ?>" />
        <!-- sol & liq -->
        <input type="hidden" name="txt_eigenvermogen_1" id="txt_eigenvermogen_1" value="<?php echo $_SESSION['finaforte']['txt_eigenvermogen_1']; ?>">
        <input type="hidden" name="txt_balanstotaal_1" id="txt_balanstotaal_1" value="<?php echo $_SESSION['finaforte']['txt_balanstotaal_1']; ?>">
        <input type="hidden" name="txt_eigenvermogen_2" id="txt_eigenvermogen_2" value="<?php echo $_SESSION['finaforte']['txt_eigenvermogen_2']; ?>">
        <input type="hidden" name="txt_balanstotaal_2" id="txt_balanstotaal_2" value="<?php echo $_SESSION['finaforte']['txt_balanstotaal_2']; ?>">
        <input type="hidden" name="txt_eigenvermogen_3" id="txt_eigenvermogen_3" value="<?php echo $_SESSION['finaforte']['txt_eigenvermogen_3']; ?>">
        <input type="hidden" name="txt_balanstotaal_3" id="txt_balanstotaal_3" value="<?php echo $_SESSION['finaforte']['txt_balanstotaal_3']; ?>">
        <input type="hidden" name="txt_vlottendeactiva_1" id="txt_vlottendeactiva_1" value="<?php echo $_SESSION['finaforte']['txt_vlottendeactiva_1']; ?>">
        <input type="hidden" name="txt_kortvreemdvermogen_1" id="txt_kortvreemdvermogen_1" value="<?php echo $_SESSION['finaforte']['txt_kortvreemdvermogen_1']; ?>">
        <input type="hidden" name="txt_vlottendeactiva_2" id="txt_vlottendeactiva_2" value="<?php echo $_SESSION['finaforte']['txt_vlottendeactiva_2']; ?>">
        <input type="hidden" name="txt_kortvreemdvermogen_2" id="txt_kortvreemdvermogen_2" value="<?php echo $_SESSION['finaforte']['txt_kortvreemdvermogen_2']; ?>">
        <input type="hidden" name="txt_vlottendeactiva_3" id="txt_vlottendeactiva_3" value="<?php echo $_SESSION['finaforte']['txt_vlottendeactiva_3']; ?>">
        <input type="hidden" name="txt_kortvreemdvermogen_3" id="txt_kortvreemdvermogen_3" value="<?php echo $_SESSION['finaforte']['txt_kortvreemdvermogen_3']; ?>">
        <!--partner sol & liq -->
        <input type="hidden" name="txt_eigenvermogenp_1" id="txt_eigenvermogenp_1" value="<?php echo $_SESSION['finaforte']['txt_eigenvermogenp_1']; ?>">
        <input type="hidden" name="txt_balanstotaalp_1" id="txt_balanstotaalp_1" value="<?php echo $_SESSION['finaforte']['txt_balanstotaalp_1']; ?>">
        <input type="hidden" name="txt_eigenvermogenp_2" id="txt_eigenvermogenp_2" value="<?php echo $_SESSION['finaforte']['txt_eigenvermogenp_2']; ?>">
        <input type="hidden" name="txt_balanstotaalp_2" id="txt_balanstotaalp_2" value="<?php echo $_SESSION['finaforte']['txt_balanstotaalp_2']; ?>">
        <input type="hidden" name="txt_eigenvermogenp_3" id="txt_eigenvermogenp_3" value="<?php echo $_SESSION['finaforte']['txt_eigenvermogenp_3']; ?>">
        <input type="hidden" name="txt_balanstotaalp_3" id="txt_balanstotaalp_3" value="<?php echo $_SESSION['finaforte']['txt_balanstotaalp_3']; ?>">
        <input type="hidden" name="txt_vlottendeactivap_1" id="txt_vlottendeactivap_1" value="<?php echo $_SESSION['finaforte']['txt_vlottendeactivap_1']; ?>">
        <input type="hidden" name="txt_kortvreemdvermogenp_1" id="txt_kortvreemdvermogenp_1" value="<?php echo $_SESSION['finaforte']['txt_kortvreemdvermogenp_1']; ?>">
        <input type="hidden" name="txt_vlottendeactivap_2" id="txt_vlottendeactivap_2" value="<?php echo $_SESSION['finaforte']['txt_vlottendeactivap_2']; ?>">
        <input type="hidden" name="txt_kortvreemdvermogenp_2" id="txt_kortvreemdvermogenp_2" value="<?php echo $_SESSION['finaforte']['txt_kortvreemdvermogenp_2']; ?>">
        <input type="hidden" name="txt_vlottendeactivap_3" id="txt_vlottendeactivap_3" value="<?php echo $_SESSION['finaforte']['txt_vlottendeactivap_3']; ?>">
        <!-- other cal -->
        <input type="hidden" name="group1" id="group1" value="<?php echo $_SESSION['finaforte']['group1']; ?>">
        <input type="hidden" name="single_slider_first" id="single_slider_first" value="<?php echo $_SESSION['finaforte']['single_slider_first']; ?>">
        <input type="hidden" name="single_slider_tv1" id="single_slider_tv1" value="<?php echo $_SESSION['finaforte']['single_slider_tv1']; ?>">
        <input type="hidden" name="single_slider_ph1" id="single_slider_ph1" value="<?php echo $_SESSION['finaforte']['single_slider_ph1']; ?>">
        <input type="hidden" name="pgroup1" id="pgroup1" value="<?php echo $_SESSION['finaforte']['pgroup1']; ?>">
        <input type="hidden" name="yn_switch" id="yn_switch" value="<?php echo $_SESSION['finaforte']['yn_switch']; ?>">
        <input type="hidden" name="single_slider_2" id="single_slider_2" value="<?php echo $_SESSION['finaforte']['single_slider_2']; ?>">        
</div>

<input type="hidden" name="h_totalincome" id="h_totalincome" value="<?php if($_SESSION['finaforte']['totalincome'] != ''){ echo $_SESSION['finaforte']['totalincome']; }?>">
<input type="hidden" name="h_totalincomep" id="h_totalincomep" value="<?php if($_SESSION['finaforte']['totalincomep'] != ''){ echo $_SESSION['finaforte']['totalincomep']; }?>">
<input type="hidden" name="h_max_hypotheek" id="h_max_hypotheek" value="<?php if($_SESSION['finaforte']['maximale_hypotheek'] != ''){ echo number_format($_SESSION['finaforte']['maximale_hypotheek'], 2, ',' , '.'); } ?>">
<input type="hidden" name="h_maandlasten" id="h_maandlasten" value="<?php if($_SESSION['finaforte']['maandlasten'] != ''){ echo number_format($_SESSION['finaforte']['maandlasten'], 2, ',' , '.'); }?>">
<input type="hidden" name="h_totalincome_sum" id="h_totalincome_sum" value="<?php if($_SESSION['finaforte']['totalincome_sum'] != ''){ echo number_format($_SESSION['finaforte']['totalincome_sum'], 2, ',' , '.'); }?>">

<input type="hidden" name="Show_cal_1" id="Show_cal_1" value="<?php echo $Show_cal_1; ?>">
<input type="hidden" name="Show_cal_2" id="Show_cal_2" value="<?php echo $Show_cal_2; ?>">
<input type="hidden" name="Show_cal_3" id="Show_cal_3" value="<?php echo $Show_cal_3; ?>">
<input type="hidden" name="Show_cal_4" id="Show_cal_4" value="<?php echo $Show_cal_4; ?>">
<!-- cal 1 -->
<input type="hidden" name="maximale_hypotheek_1" id="maximale_hypotheek_1" value="<?php echo $maximale_hypotheek_1; ?>">
<input type="hidden" name="hypo_ber_rent_1" id="hypo_ber_rent_1" value="<?php echo $hypo_ber_rent_1/12; ?>">
<input type="hidden" name="aflossing_1" id="aflossing_1" value="<?php echo $aflossing_1; ?>">
<input type="hidden" name="bruto_maandlast" id="bruto_maandlast" value="<?php echo $bruto_maandlast; ?>">
<input type="hidden" name="belastingteruggave_1" id="belastingteruggave_1" value="<?php echo $belastingteruggave_1; ?>">
<input type="hidden" name="netto_per_maand_1" id="netto_per_maand_1" value="<?php echo $netto_per_maand_1; ?>">
<!-- cal 2 -->
<input type="hidden" name="maximale_hypotheek_2" id="maximale_hypotheek_2" value="<?php echo $maximale_hypotheek_2; ?>">
<input type="hidden" name="hypo_ber_rent_2" id="hypo_ber_rent_2" value="<?php echo $hypo_ber_rent_2/12; ?>">
<input type="hidden" name="aflossing_2" id="aflossing_2" value="<?php echo $aflossing_2; ?>">
<input type="hidden" name="maandlasten2" id="maandlasten2" value="<?php echo $maandlasten2; ?>">
<input type="hidden" name="belastingteruggave_2" id="belastingteruggave_2" value="<?php echo $belastingteruggave_2; ?>">
<input type="hidden" name="netto_per_maand_2" id="netto_per_maand_2" value="<?php echo $netto_per_maand_2; ?>">
<!-- cal 3 -->
<input type="hidden" name="maximale_hypotheek_3" id="maximale_hypotheek_3" value="<?php echo $maximale_hypotheek_3; ?>">
<input type="hidden" name="hypo_ber_rent_3" id="hypo_ber_rent_3" value="<?php echo $hypo_ber_rent_3/12; ?>">
<input type="hidden" name="aflossing_3" id="aflossing_3" value="<?php echo $aflossing_3; ?>">
<input type="hidden" name="maandlasten3" id="maandlasten3" value="<?php echo $maandlasten3; ?>">
<input type="hidden" name="belastingteruggave_3" id="belastingteruggave_3" value="<?php echo $belastingteruggave_3; ?>">
<input type="hidden" name="netto_per_maand_3" id="netto_per_maand_3" value="<?php echo $netto_per_maand_3; ?>">
<!-- cal 4 -->
<input type="hidden" name="maximale_hypotheek_4" id="maximale_hypotheek_4" value="<?php echo $maximale_hypotheek_4; ?>">
<input type="hidden" name="hypo_ber_rent_4" id="hypo_ber_rent_4" value="<?php echo $hypo_ber_rent_4/12; ?>">
<input type="hidden" name="aflossing_4" id="aflossing_4" value="<?php echo $aflossing_4; ?>">
<input type="hidden" name="maandlasten4" id="maandlasten4" value="<?php echo $maandlasten4; ?>">
<input type="hidden" name="belastingteruggave_4" id="belastingteruggave_4" value="<?php echo $belastingteruggave_4; ?>">
<input type="hidden" name="netto_per_maand_4" id="netto_per_maand_4" value="<?php echo $netto_per_maand_4; ?>">

<!-- on off switch val -->
<input type="hidden" name="myonoffswitch1" id="myonoffswitch1" value="<?php echo $_SESSION['finaforte']['myonoffswitch1']; ?>">
<input type="hidden" name="myonoffswitch3" id="myonoffswitch3" value="<?php echo $_SESSION['finaforte']['myonoffswitch3']; ?>">
<input type="hidden" name="ponoffswitch1" id="ponoffswitch1" value="<?php echo $_SESSION['finaforte']['ponoffswitch1']; ?>">
<input type="hidden" name="pmyonoffswitch3" id="pmyonoffswitch3" value="<?php echo $_SESSION['finaforte']['pmyonoffswitch3']; ?>">

<script type="text/javascript">
                        
    function backto_calculator() {

        var txt_halfyear_first = jQuery("#txt_halfyear_first").val();
        var txt_halfyear_second = jQuery("#txt_halfyear_second").val();
        var txt_halfyear_third = jQuery("#txt_halfyear_third").val();
        var txt_winstuitonderneming_1 = jQuery("#txt_winstuitonderneming_1").val();
        var txt_winstuitonderneming_2 = jQuery("#txt_winstuitonderneming_2").val();
        var txt_winstuitonderneming_3 = jQuery("#txt_winstuitonderneming_3").val();
        var txt_salaris_1 = jQuery("#txt_salaris_1").val();
        var txt_dividend_1 = jQuery("#txt_dividend_1").val();
        var txt_overwinst_1 = jQuery("#txt_overwinst_1").val();
        var txt_salaris_2 = jQuery("#txt_salaris_2").val();
        var txt_dividend_2 = jQuery("#txt_dividend_2").val();
        var txt_overwinst_2 = jQuery("#txt_overwinst_2").val();
        var txt_salaris_3 = jQuery("#txt_salaris_3").val();
        var txt_dividend_3 = jQuery("#txt_dividend_3").val();
        var txt_overwinst_3 = jQuery("#txt_overwinst_3").val();
        /*partner income*/
        var txt_loondienst = jQuery("#txt_loondienst").val();
        var txt_halfyearp_first = jQuery("#txt_halfyearp_first").val();
        var txt_halfyearp_second = jQuery("#txt_halfyearp_second").val();
        var txt_halfyearp_third = jQuery("#txt_halfyearp_third").val();
        
        var txt_winstuitondernemingp_1 = jQuery("#txt_winstuitondernemingp_1").val();
        var txt_winstuitondernemingp_2 = jQuery("#txt_winstuitondernemingp_2").val();
        var txt_winstuitondernemingp_3 = jQuery("#txt_winstuitondernemingp_3").val();

        var txt_salarisp_1 = jQuery("#txt_salarisp_1").val();
        var txt_dividendp_1 = jQuery("#txt_dividendp_1").val();
        var txt_overwinstp_1 = jQuery("#txt_overwinstp_1").val();
        var txt_salarisp_2 = jQuery("#txt_salarisp_2").val();
        var txt_dividendp_2 = jQuery("#txt_dividendp_2").val();
        var txt_overwinstp_2 = jQuery("#txt_overwinstp_2").val();
        var txt_salarisp_3 = jQuery("#txt_salarisp_3").val();
        var txt_dividendp_3 = jQuery("#txt_dividendp_3").val();
        var txt_overwinstp_3 = jQuery("#txt_overwinstp_3").val();
        /*liq & sol*/
        var txt_eigenvermogen_1 = jQuery("#txt_eigenvermogen_1").val();
        var txt_balanstotaal_1 = jQuery("#txt_balanstotaal_1").val();
        var txt_eigenvermogen_2 = jQuery("#txt_eigenvermogen_2").val();
        var txt_balanstotaal_2 = jQuery("#txt_balanstotaal_2").val();
        var txt_eigenvermogen_3 = jQuery("#txt_eigenvermogen_3").val();
        var txt_balanstotaal_3 = jQuery("#txt_balanstotaal_3").val();
        var txt_vlottendeactiva_1 = jQuery("#txt_vlottendeactiva_1").val();
        var txt_kortvreemdvermogen_1 = jQuery("#txt_kortvreemdvermogen_1").val();
        var txt_vlottendeactiva_2 = jQuery("#txt_vlottendeactiva_2").val();
        var txt_kortvreemdvermogen_2 = jQuery("#txt_kortvreemdvermogen_2").val();
        var txt_vlottendeactiva_3 = jQuery("#txt_vlottendeactiva_3").val();
        var txt_kortvreemdvermogen_3 = jQuery("#txt_kortvreemdvermogen_3").val();
        /*partner sol & liq*/
        var txt_eigenvermogenp_1 = jQuery("#txt_eigenvermogenp_1").val();
        var txt_balanstotaalp_1 = jQuery("#txt_balanstotaalp_1").val();
        var txt_eigenvermogenp_2 = jQuery("#txt_eigenvermogenp_2").val();
        var txt_balanstotaalp_2 = jQuery("#txt_balanstotaalp_2").val();
        var txt_eigenvermogenp_3 = jQuery("#txt_eigenvermogenp_3").val();
        var txt_balanstotaalp_3 = jQuery("#txt_balanstotaalp_3").val();
        var txt_vlottendeactivap_1 = jQuery("#txt_vlottendeactivap_1").val();
        var txt_kortvreemdvermogenp_1 = jQuery("#txt_kortvreemdvermogenp_1").val();
        var txt_vlottendeactivap_2 = jQuery("#txt_vlottendeactivap_2").val();
        var txt_kortvreemdvermogenp_2 = jQuery("#txt_kortvreemdvermogenp_2").val();
        var txt_vlottendeactivap_3 = jQuery("#txt_vlottendeactivap_3").val();
        /*other cal*/
        var group1 = jQuery("input[name=group1]").val();
        var single_slider_first = jQuery("#single_slider_first").val();
        var single_slider_tv1 = jQuery("#single_slider_tv1").val();
        var single_slider_ph1 = jQuery("#single_slider_ph1").val();
        /*total cal*/
        var h_totalincome = jQuery("#h_totalincome").val(); /* without partner*/
        var h_totalincomep = jQuery("#h_totalincomep").val();
        var h_max_hypotheek = jQuery("#h_max_hypotheek").val();
        var h_maandlasten = jQuery("#h_maandlasten").val();
        var h_totalincome_sum = jQuery("#h_totalincome_sum").val(); /* with partner*/
        /*cal 1*/
        var maximale_hypotheek_1 = jQuery("#maximale_hypotheek_1").val();
        var hypo_ber_rent_1 = jQuery("#hypo_ber_rent_1").val();
        var aflossing_1 = jQuery("#aflossing_1").val();
        var bruto_maandlast = jQuery("#bruto_maandlast").val();
        var belastingteruggave_1 = jQuery("#belastingteruggave_1").val();
        var netto_per_maand_1 = jQuery("#netto_per_maand_1").val();
        /*cal 2*/
        var maximale_hypotheek_2 = jQuery("#maximale_hypotheek_2").val();
        var hypo_ber_rent_2 = jQuery("#hypo_ber_rent_2").val();
        var aflossing_2 = jQuery("#aflossing_2").val();
        var maandlasten2 = jQuery("#maandlasten2").val();
        var belastingteruggave_2 = jQuery("#belastingteruggave_2").val();
        var netto_per_maand_2 = jQuery("#netto_per_maand_2").val();
        /*cal 3*/
        var maximale_hypotheek_3 = jQuery("#maximale_hypotheek_3").val();
        var hypo_ber_rent_3 = jQuery("#hypo_ber_rent_3").val();
        var aflossing_3 = jQuery("#aflossing_3").val();
        var maandlasten3 = jQuery("#maandlasten3").val();
        var belastingteruggave_3 = jQuery("#belastingteruggave_3").val();
        var netto_per_maand_3 = jQuery("#netto_per_maand_3").val();
        /*cal 4*/
        var maximale_hypotheek_4 = jQuery("#maximale_hypotheek_4").val();
        var hypo_ber_rent_4 = jQuery("#hypo_ber_rent_4").val();
        var aflossing_4 = jQuery("#aflossing_4").val();
        var maandlasten4 = jQuery("#maandlasten4").val();
        var belastingteruggave_4 = jQuery("#belastingteruggave_4").val();
        var netto_per_maand_4 = jQuery("#netto_per_maand_4").val();
        /*show cal*/
        var Show_cal_1 = jQuery("#Show_cal_1").val();
        var Show_cal_2 = jQuery("#Show_cal_2").val();
        var Show_cal_3 = jQuery("#Show_cal_3").val();
        var Show_cal_4 = jQuery("#Show_cal_4").val();
        /*partner other fields*/
        var pgroup1 = jQuery("#pgroup1").val();
        var yn_switch = jQuery("#yn_switch").val();
        var single_slider_2 = jQuery("#single_slider_2").val();
        var pid = jQuery("#total_cal_form").attr('data-pid');   
        /*on off button*/  
        var myonoffswitch1 = jQuery("#myonoffswitch1").val();
        var myonoffswitch3 = jQuery("#myonoffswitch3").val();     
        var ponoffswitch1 = jQuery("#ponoffswitch1").val();     
        var pmyonoffswitch3 = jQuery("#pmyonoffswitch3").val();   
      
        jQuery.ajax({
            type: "POST",
            url: "<?php echo admin_url('admin-ajax.php'); ?>",           
            data: 'action=backto_calculator_act&txt_halfyear_first=' + txt_halfyear_first + '&txt_halfyear_second=' + txt_halfyear_second + '&txt_halfyear_third=' +txt_halfyear_third + '&txt_winstuitonderneming_1=' +txt_winstuitonderneming_1 + '&txt_winstuitonderneming_2=' +txt_winstuitonderneming_2 + '&txt_winstuitonderneming_3=' +txt_winstuitonderneming_3 + '&txt_salaris_1=' +txt_salaris_1 + '&txt_dividend_1=' +txt_dividend_1 + '&txt_overwinst_1=' +txt_overwinst_1 + '&txt_salaris_2=' +txt_salaris_2 + '&txt_dividend_2=' +txt_dividend_2 + '&txt_overwinst_2=' +txt_overwinst_2 + '&txt_salaris_3=' +txt_salaris_3 + '&txt_dividend_3=' +txt_dividend_3 + '&txt_overwinst_3=' + txt_overwinst_3 + '&txt_eigenvermogen_1=' +txt_eigenvermogen_1 + '&txt_balanstotaal_1=' +txt_balanstotaal_1 + '&txt_eigenvermogen_2=' +txt_eigenvermogen_2 + '&txt_balanstotaal_2=' +txt_balanstotaal_2 + '&txt_eigenvermogen_3=' +txt_eigenvermogen_3 + '&txt_balanstotaal_3=' +txt_balanstotaal_3 + '&txt_vlottendeactiva_1=' +txt_vlottendeactiva_1 + '&txt_kortvreemdvermogen_1=' +txt_kortvreemdvermogen_1 + '&txt_vlottendeactiva_2=' +txt_vlottendeactiva_2 + '&txt_kortvreemdvermogen_2=' +txt_kortvreemdvermogen_2 + '&txt_vlottendeactiva_3=' +txt_vlottendeactiva_3 + '&txt_kortvreemdvermogen_3=' +txt_kortvreemdvermogen_3 + '&txt_eigenvermogenp_1=' +txt_eigenvermogenp_1 + '&txt_balanstotaalp_1=' +txt_balanstotaalp_1 + '&txt_eigenvermogenp_2=' +txt_eigenvermogenp_2 + '&txt_balanstotaalp_2=' +txt_balanstotaalp_2 + '&txt_eigenvermogenp_3=' +txt_eigenvermogenp_3 + '&txt_balanstotaalp_3=' +txt_balanstotaalp_3 + '&txt_vlottendeactivap_1=' + txt_vlottendeactivap_1 + '&txt_kortvreemdvermogenp_1=' +txt_kortvreemdvermogenp_1 + '&txt_vlottendeactivap_2=' +txt_vlottendeactivap_2 + '&txt_kortvreemdvermogenp_2=' +txt_kortvreemdvermogenp_2 + '&txt_vlottendeactivap_3=' + txt_vlottendeactivap_3 + '&txt_winstuitondernemingp_1=' +txt_winstuitondernemingp_1 + '&txt_winstuitondernemingp_2=' +txt_winstuitondernemingp_2 + '&txt_winstuitondernemingp_3=' +txt_winstuitondernemingp_3 + '&txt_loondienst=' + txt_loondienst + '&txt_halfyearp_first=' +txt_halfyearp_first + '&txt_halfyearp_second=' +txt_halfyearp_second + '&txt_halfyearp_third=' +txt_halfyearp_third + '&txt_salarisp_1=' +txt_salarisp_1 + '&txt_dividendp_1=' +txt_dividendp_1 + '&txt_overwinstp_1=' +txt_overwinstp_1 + '&txt_salarisp_2=' + txt_salarisp_2 + '&txt_dividendp_2=' +txt_dividendp_2 + '&txt_overwinstp_2=' +txt_overwinstp_2 + '&txt_salarisp_3=' +txt_salarisp_3 + '&txt_dividendp_3=' +txt_dividendp_3 + '&txt_overwinstp_3=' +txt_overwinstp_3 + '&group1=' +group1 + '&single_slider_first=' +single_slider_first + '&single_slider_tv1=' +single_slider_tv1 + '&single_slider_ph1=' +single_slider_ph1 + '&pgroup1=' +pgroup1 + '&yn_switch=' +yn_switch + '&single_slider_2=' +single_slider_2 + '&myonoffswitch1=' + myonoffswitch1+ '&myonoffswitch3=' +myonoffswitch3 + '&ponoffswitch1=' +ponoffswitch1 + '&pmyonoffswitch3=' + pmyonoffswitch3,
            success: function (responseText) {
                location.reload();
            }
        });
    } 

      function receive_by_email() {

            var txt_halfyear_first = jQuery("#txt_halfyear_first").val();
            var txt_halfyear_second = jQuery("#txt_halfyear_second").val();
            var txt_halfyear_third = jQuery("#txt_halfyear_third").val();
            var txt_winstuitonderneming_1 = jQuery("#txt_winstuitonderneming_1").val();
            var txt_winstuitonderneming_2 = jQuery("#txt_winstuitonderneming_2").val();
            var txt_winstuitonderneming_3 = jQuery("#txt_winstuitonderneming_3").val();
            var txt_salaris_1 = jQuery("#txt_salaris_1").val();
            var txt_dividend_1 = jQuery("#txt_dividend_1").val();
            var txt_overwinst_1 = jQuery("#txt_overwinst_1").val();
            var txt_salaris_2 = jQuery("#txt_salaris_2").val();
            var txt_dividend_2 = jQuery("#txt_dividend_2").val();
            var txt_overwinst_2 = jQuery("#txt_overwinst_2").val();
            var txt_salaris_3 = jQuery("#txt_salaris_3").val();
            var txt_dividend_3 = jQuery("#txt_dividend_3").val();
            var txt_overwinst_3 = jQuery("#txt_overwinst_3").val();
            /*partner income*/
            var txt_loondienst = jQuery("#txt_loondienst").val();
            var txt_halfyearp_first = jQuery("#txt_halfyearp_first").val();
            var txt_halfyearp_second = jQuery("#txt_halfyearp_second").val();
            var txt_halfyearp_third = jQuery("#txt_halfyearp_third").val();
            
            var txt_winstuitondernemingp_1 = jQuery("#txt_winstuitondernemingp_1").val();
            var txt_winstuitondernemingp_2 = jQuery("#txt_winstuitondernemingp_2").val();
            var txt_winstuitondernemingp_3 = jQuery("#txt_winstuitondernemingp_3").val();

            var txt_salarisp_1 = jQuery("#txt_salarisp_1").val();
            var txt_dividendp_1 = jQuery("#txt_dividendp_1").val();
            var txt_overwinstp_1 = jQuery("#txt_overwinstp_1").val();
            var txt_salarisp_2 = jQuery("#txt_salarisp_2").val();
            var txt_dividendp_2 = jQuery("#txt_dividendp_2").val();
            var txt_overwinstp_2 = jQuery("#txt_overwinstp_2").val();
            var txt_salarisp_3 = jQuery("#txt_salarisp_3").val();
            var txt_dividendp_3 = jQuery("#txt_dividendp_3").val();
            var txt_overwinstp_3 = jQuery("#txt_overwinstp_3").val();
            /*liq & sol*/
            var txt_eigenvermogen_1 = jQuery("#txt_eigenvermogen_1").val();
            var txt_balanstotaal_1 = jQuery("#txt_balanstotaal_1").val();
            var txt_eigenvermogen_2 = jQuery("#txt_eigenvermogen_2").val();
            var txt_balanstotaal_2 = jQuery("#txt_balanstotaal_2").val();
            var txt_eigenvermogen_3 = jQuery("#txt_eigenvermogen_3").val();
            var txt_balanstotaal_3 = jQuery("#txt_balanstotaal_3").val();
            var txt_vlottendeactiva_1 = jQuery("#txt_vlottendeactiva_1").val();
            var txt_kortvreemdvermogen_1 = jQuery("#txt_kortvreemdvermogen_1").val();
            var txt_vlottendeactiva_2 = jQuery("#txt_vlottendeactiva_2").val();
            var txt_kortvreemdvermogen_2 = jQuery("#txt_kortvreemdvermogen_2").val();
            var txt_vlottendeactiva_3 = jQuery("#txt_vlottendeactiva_3").val();
            var txt_kortvreemdvermogen_3 = jQuery("#txt_kortvreemdvermogen_3").val();
            /*partner sol & liq*/
            var txt_eigenvermogenp_1 = jQuery("#txt_eigenvermogenp_1").val();
            var txt_balanstotaalp_1 = jQuery("#txt_balanstotaalp_1").val();
            var txt_eigenvermogenp_2 = jQuery("#txt_eigenvermogenp_2").val();
            var txt_balanstotaalp_2 = jQuery("#txt_balanstotaalp_2").val();
            var txt_eigenvermogenp_3 = jQuery("#txt_eigenvermogenp_3").val();
            var txt_balanstotaalp_3 = jQuery("#txt_balanstotaalp_3").val();
            var txt_vlottendeactivap_1 = jQuery("#txt_vlottendeactivap_1").val();
            var txt_kortvreemdvermogenp_1 = jQuery("#txt_kortvreemdvermogenp_1").val();
            var txt_vlottendeactivap_2 = jQuery("#txt_vlottendeactivap_2").val();
            var txt_kortvreemdvermogenp_2 = jQuery("#txt_kortvreemdvermogenp_2").val();
            var txt_vlottendeactivap_3 = jQuery("#txt_vlottendeactivap_3").val();
            /*other cal*/
            var group1 = jQuery("input[name=group1]").val();
            var single_slider_first = jQuery("#single_slider_first").val();
            var single_slider_tv1 = jQuery("#single_slider_tv1").val();
            var single_slider_ph1 = jQuery("#single_slider_ph1").val();
            /*total cal*/
            var h_totalincome = jQuery("#h_totalincome").val(); /* without partner*/
            var h_totalincomep = jQuery("#h_totalincomep").val();
            var h_max_hypotheek = jQuery("#h_max_hypotheek").val();
            var h_maandlasten = jQuery("#h_maandlasten").val();
            var h_totalincome_sum = jQuery("#h_totalincome_sum").val(); /* with partner*/
            /*cal 1*/
            var maximale_hypotheek_1 = jQuery("#maximale_hypotheek_1").val();
            var hypo_ber_rent_1 = jQuery("#hypo_ber_rent_1").val();
            var aflossing_1 = jQuery("#aflossing_1").val();
            var bruto_maandlast = jQuery("#bruto_maandlast").val();
            var belastingteruggave_1 = jQuery("#belastingteruggave_1").val();
            var netto_per_maand_1 = jQuery("#netto_per_maand_1").val();
            /*cal 2*/
            var maximale_hypotheek_2 = jQuery("#maximale_hypotheek_2").val();
            var hypo_ber_rent_2 = jQuery("#hypo_ber_rent_2").val();
            var aflossing_2 = jQuery("#aflossing_2").val();
            var maandlasten2 = jQuery("#maandlasten2").val();
            var belastingteruggave_2 = jQuery("#belastingteruggave_2").val();
            var netto_per_maand_2 = jQuery("#netto_per_maand_2").val();
            /*cal 3*/
            var maximale_hypotheek_3 = jQuery("#maximale_hypotheek_3").val();
            var hypo_ber_rent_3 = jQuery("#hypo_ber_rent_3").val();
            var aflossing_3 = jQuery("#aflossing_3").val();
            var maandlasten3 = jQuery("#maandlasten3").val();
            var belastingteruggave_3 = jQuery("#belastingteruggave_3").val();
            var netto_per_maand_3 = jQuery("#netto_per_maand_3").val();
            /*cal 4*/
            var maximale_hypotheek_4 = jQuery("#maximale_hypotheek_4").val();
            var hypo_ber_rent_4 = jQuery("#hypo_ber_rent_4").val();
            var aflossing_4 = jQuery("#aflossing_4").val();
            var maandlasten4 = jQuery("#maandlasten4").val();
            var belastingteruggave_4 = jQuery("#belastingteruggave_4").val();
            var netto_per_maand_4 = jQuery("#netto_per_maand_4").val();
            /*show cal*/
            var Show_cal_1 = jQuery("#Show_cal_1").val();
            var Show_cal_2 = jQuery("#Show_cal_2").val();
            var Show_cal_3 = jQuery("#Show_cal_3").val();
            var Show_cal_4 = jQuery("#Show_cal_4").val();
            /*partner other fields*/
            var pgroup1 = jQuery("#pgroup1").val();
            var yn_switch = jQuery("#yn_switch").val();
            var single_slider_2 = jQuery("#single_slider_2").val();
            var pid = jQuery("#total_cal_form").attr('data-pid');   
            /*on off button*/  
            var myonoffswitch1 = jQuery("#myonoffswitch1").val();
            var myonoffswitch3 = jQuery("#myonoffswitch3").val();     
            var ponoffswitch1 = jQuery("#ponoffswitch1").val();     
            var pmyonoffswitch3 = jQuery("#pmyonoffswitch3").val();   

            jQuery.ajax({
                type: "POST",
                url: "<?php echo admin_url('admin-ajax.php'); ?>",               
                data: 'action=receive_by_email&h_totalincome=' + h_totalincome + '&h_totalincomep=' +h_totalincomep + '&h_max_hypotheek=' +h_max_hypotheek + '&h_maandlasten=' +h_maandlasten + '&h_totalincome_sum=' +h_totalincome_sum + '&maximale_hypotheek_1=' +maximale_hypotheek_1 + '&hypo_ber_rent_1=' +hypo_ber_rent_1 + '&aflossing_1=' +aflossing_1 + '&bruto_maandlast=' +bruto_maandlast + '&belastingteruggave_1=' +belastingteruggave_1 + '&netto_per_maand_1=' +netto_per_maand_1 + '&maximale_hypotheek_2=' +maximale_hypotheek_2 + '&maandlasten2=' + maandlasten2 + '&hypo_ber_rent_2=' +hypo_ber_rent_2 + '&aflossing_2=' +aflossing_2 + '&belastingteruggave_2=' +belastingteruggave_2 + '&netto_per_maand_2=' + netto_per_maand_2+ '&maximale_hypotheek_3=' + maximale_hypotheek_3 + '&maandlasten3=' + maandlasten3 + '&hypo_ber_rent_3=' +hypo_ber_rent_3 + '&aflossing_3=' +aflossing_3 + '&belastingteruggave_3=' +belastingteruggave_3 + '&netto_per_maand_3=' +netto_per_maand_3 + '&maximale_hypotheek_4=' +maximale_hypotheek_4 + '&maandlasten4=' + maandlasten4 + '&hypo_ber_rent_4=' +hypo_ber_rent_4 + '&aflossing_4=' +aflossing_4 + '&belastingteruggave_4=' + belastingteruggave_4 + '&netto_per_maand_4=' +netto_per_maand_4 + '&Show_cal_1=' +Show_cal_1 + '&Show_cal_2=' +Show_cal_2 + '&Show_cal_3=' +Show_cal_3 + '&Show_cal_4=' +Show_cal_4 ,
                success: function (response) {                   
                 location.reload();               
                 console.log(response);                   
                }
            });
        }
</script>
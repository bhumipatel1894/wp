<?php
// WordPress environment
dirname(__FILE__) . '/../../../wp-load.php';
require( dirname(__FILE__) . '/../../../wp-load.php' );
 
$wordpress_upload_dir = wp_upload_dir();
// $wordpress_upload_dir['path'] is the full server path to wp-content/uploads/2017/05, for multisite works good as well
// $wordpress_upload_dir['url'] the absolute URL to the same folder, actually we do not need it, just to show the link to file
$i = 1; // number of tries when the file with the same name is already exists
global $wpdb;
print_r($_POST);
$loggedin_user = wp_get_current_user();  
$loggedin_userID = $loggedin_user->ID;
echo $loggedin_userID;
exit;
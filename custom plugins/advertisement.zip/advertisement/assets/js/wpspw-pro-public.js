
       /***********************************************************************************************************************************************************************
       **************************************************** Jquery Starts from here ***********************************************************/
        jQuery("#usub_img1_block").hide();
        jQuery("#data_sub_btn").hide();

        jQuery(document).on("change", "#submissiontype", function($){

            var typeval = jQuery(this).val();
            jQuery("#submissiontypeval").val(typeval);

            if(typeval == '1'){ /* Image with caption Free*/
                jQuery("#usub_img1_block").show();
                jQuery("#article_block").hide();
                jQuery("#page_block").hide(); 
                jQuery("#advertisement_block").hide();
                jQuery("#data_sub_btn").show();
            }
            if(typeval == '2'){ /* Article Free */
                jQuery("#article_block").show(); 
                jQuery("#usub_img1_block").hide();
                jQuery("#advertisement_block").hide();
                jQuery("#page_block").hide(); 
                jQuery("#data_sub_btn").show();
            }
            if(typeval == '3'){ /* page not free */
                jQuery("#page_block").show(); 
                jQuery("#article_block").hide(); 
                jQuery("#usub_img1_block").hide();
                jQuery("#advertisement_block").hide();
                jQuery("#data_sub_btn").hide();
            }
            if(typeval == '4'){ /* Advertisement not free*/
                jQuery("#advertisement_block").show();
                jQuery("#page_block").hide(); 
                jQuery("#article_block").hide(); 
                jQuery("#usub_img1_block").hide();
                jQuery("#data_sub_btn").hide();
            }
        });

        jQuery(document).on("change", "#page_block_size", function($){  /* On change Page size */

            var pagesizeval = jQuery(this).val();
            jQuery(".paypal-pay-btn").show();
            var dataname = jQuery("#page_block_size option:selected").html();
        
            jQuery("input[name='amount']").val(pagesizeval);
            jQuery("input[name='item_name']").val(dataname);  
           
           
        });  

        jQuery(document).on("change", "#advertisement_block_size", function($){  /* On change advertisement size */

            var pagesizeval = jQuery(this).val();
            jQuery(".paypal-pay-btn").show();
            var dataname = jQuery("#advertisement_block_size option:selected").html();
          
            jQuery("input[name='amount']").val(pagesizeval);
            jQuery("input[name='item_name']").val(dataname);  
             

        });

         var getUrlParameter = function getUrlParameter(sParam) {
            var sPageURL = window.location.search.substring(1),
                sURLVariables = sPageURL.split('&'),
                sParameterName,
                i;

            for (i = 0; i < sURLVariables.length; i++) {
                sParameterName = sURLVariables[i].split('=');

                if (sParameterName[0] === sParam) {
                    return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
                }
            }
        };

        /* Payment gateway Functions */
        jQuery(document).ready(function(){

            /* Set Initial Values after Payment Success */
            var pay_done_subtypeval = jQuery("#submissiontypeval").val();
            var pay_done_currpagesizeval = jQuery("#pagesizeval").val();

            /* if item size */
            if(pay_done_currpagesizeval == ''){
                 var st = getUrlParameter('st');
                var tx = getUrlParameter('tx');
                var item_name = getUrlParameter('item_name');

                var amt = getUrlParameter('amt');
                //var plugin_path = "<?php echo plugins_url('blog-designer-for-post-and-widget-pro'); ?>";
              
                if(st=="Completed" && tx != ''){

                    jQuery('#myform1').show();
                    jQuery('#sub_type').show();
                    jQuery('#submission1').hide();  
                    
                    jQuery.ajax({
                        type: 'POST',                  
                       url: WpspwPro.ajaxurl,
                        data: {'action': 'add_page_data', item_name: item_name, amt: amt, st: st, tx: tx}, // Sending data dname to post_word_count function.
                        success: function(data){ 



                           
                             item_name = jQuery.trim(item_name);
                             if(jQuery.isNumeric( data )){   console.log(data);
                                 jQuery("#data_sub_btn").show();
            console.log(item_name);
                                if( (item_name == 'Page Size 8.5X11') || (item_name == 'Page Size 6X9') ){
                                   
                                    jQuery("#page_block, .page_block_uploadsec, .page_ic1, .page_ic2, .page_ic3, .page_ic4").show();
                                    jQuery("#submissiontypeval").val('3');
                                    jQuery("#pagesizeval").val(item_name);
                                }
                                if( (item_name == 'Page Size 4.25X5.5') || (item_name == 'Page Size 3X4.5') ){

                                    jQuery("#page_block, .page_block_uploadsec, .page_ic1, .page_ic2").show();
                                    jQuery("#submissiontypeval").val('3');
                                    jQuery("#pagesizeval").val(item_name);
                                }
                                if( (item_name == 'Page Size 1.5X2.25') || (item_name == 'Page Size 2.125X2.75') ){

                                    alert(item_name);
                                    jQuery("#page_block, .page_block_uploadsec, .page_ic1").show();
                                    jQuery("#submissiontypeval").val('3');
                                    jQuery("#pagesizeval").val(item_name);
                                }

                                if( (item_name == 'Advertisement size 8.5X11') || (item_name == 'Advertisement size 6X9') ){
                                    alert('item name is: ' +item_name);
                                    jQuery("#advertisement_block, .advertisement_block_uploadsec, #advertisement_ic_img1, #advertisement_ic_img2, #advertisement_ic_img3, #advertisement_ic_img4").show();
                                    jQuery("#submissiontypeval").val('4');
                                    jQuery("#pagesizeval").val(item_name);
                                }
                                if( (item_name == 'Advertisement size 4.25X5.5') || (item_name == 'Advertisement size 3X4.5') ){

                                    jQuery("#advertisement_block, .advertisement_block_uploadsec, #advertisement_ic_img1, #advertisement_ic_img2").show();
                                    jQuery("#submissiontypeval").val('4');
                                    jQuery("#pagesizeval").val(item_name);
                                }
                                if( (item_name == 'Advertisement size 1.5X2.25') || (item_name == 'Advertisement size 2.125X2.75') ){

                                    jQuery("#advertisement_block, .advertisement_block_uploadsec, #advertisement_ic_img1").show();
                                    jQuery("#submissiontypeval").val('4');
                                    jQuery("#pagesizeval").val(item_name);
                                }

                                jQuery("#data_sub_btn").show();


                                /*var next_page = jQuery("#current_url").val();
                                window.location = next_page;*/                             
                              
                              
                            } else{
                                var next_page = jQuery("#current_url").val();
                                 window.location = next_page;  
                            }
                        }
                    });
                }
            }

           

            jQuery("#adlogin").click( function(){
                event.preventDefault();
               jQuery("#userregiform").hide();
               jQuery(".userloginform").show();
            });

            jQuery(".myImg").click(function(){

                console.log(jQuery(this).attr('src'));
                var imgsrc = jQuery(this).attr('src');
                jQuery("#img01").attr('src',imgsrc );
                jQuery("#admyModal").show();

            });

            jQuery(".admclose").click(function(){
                jQuery("#admyModal").hide();
            });
        });
<?php
/**
 * Plugin Name: Advertisement Pro
 * Plugin URI: 
 * Description: Display Advertisements
 * Text Domain: advertisement
 * Domain Path: /languages/
 * Author: 
 * Author URI: 
 * Contributors: 
 * Version: 1.0
*/

// Exit if accessed directly
// abs pth is start ffrom folder path upto proj folder
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Basic plugin definitions
 * 
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0.0
 */
if( !defined( 'WPSPW_PRO_VERSION' ) ) {
    define( 'WPSPW_PRO_VERSION', '1.1' ); // Version of plugin
}
if( !defined( 'WPSPW_PRO_DIR' ) ) {
    define( 'WPSPW_PRO_DIR', dirname( __FILE__ ) ); // Plugin dir
}
if( !defined( 'WPSPW_PRO_URL' ) ) {
    define( 'WPSPW_PRO_URL', plugin_dir_url( __FILE__ ) ); // Plugin url
}
if( !defined( 'WPSPW_PRO_PLUGIN_BASENAME' ) ) {
    define( 'WPSPW_PRO_PLUGIN_BASENAME', plugin_basename( __FILE__ ) ); // Plugin base name
}

if( !defined( 'WPSPW_META_PREFIX' ) ) {
    define( 'WPSPW_META_PREFIX', '_ad_' ); // Plugin metabox prefix
}

/**
 * Load Text Domain
 * This gets the plugin ready for translation
 * 
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0.0
 */
function wpspw_load_textdomain() {
    load_plugin_textdomain( 'blog-designer-for-post-and-widget', false, dirname( plugin_basename(__FILE__) ) . '/languages/' );
}

// Action to load plugin text domain
add_action('plugins_loaded', 'wpspw_load_textdomain');

/**
 * Activation Hook
 * 
 * Register plugin activation hook.
 * 
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0.0
 */
register_activation_hook( __FILE__, 'wpspw_pro_install' );

/**
 * Deactivation Hook
 * 
 * Register plugin deactivation hook.
 * 
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0.0
 */
register_deactivation_hook( __FILE__, 'wpspw_pro_uninstall');

/**
 * Plugin Activation Function
 * Does the initial setup, sets the default values for the plugin options
 * 
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0.0
 */
function wpspw_pro_install() {
    
    // Get settings for the plugin
    $wpspw_pro_options = get_option( 'wpspw_pro_options' );
    
    if( empty( $wpspw_pro_options ) ) { // Check plugin version option
        
        // Set default settings
        wpspw_pro_default_settings();        
       
    }    
   
} 

/**
 * Function to display admin notice of activated plugin.
 * 
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0.0
 */
function wpspw_pro_admin_notice() {

    $dir = WP_PLUGIN_DIR . '/Advertisements/blog-designer-post-and-widget.php';
    
    // If free plugin exist
    if( file_exists($dir) ) {
        
        global $pagenow;
        
        if ( $pagenow == 'plugins.php' && current_user_can( 'install_plugins' ) ) {
            echo '<div id="message" class="updated notice is-dismissible"><p><strong>Thank you for activating Blog Designer - Post and Widget Pro</strong>.<br /> It looks like you had FREE version <strong>(<em>Blog Designer - Post and Widget</em>)</strong> of this plugin activated. To avoid conflicts the extra version has been deactivated and we recommend you delete it. </p></div>';
        }
    }
}

// Action to display notice
add_action( 'admin_notices', 'wpspw_pro_admin_notice');

/**
 * Plugin Deactivation Function
 * Delete  plugin options
 * 
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0.0
 */
function wpspw_pro_uninstall() {
    // Uninstall functionality
}


/***** Updater Code Ends *****/

// Global variables
global $wpspw_pro_options, $wpspw_userentry_options;

// Functions file
require_once( WPSPW_PRO_DIR . '/includes/wpspw-functions.php' );
$wpspw_pro_options = wpspw_pro_get_settings();
$wpspw_userentry_options = wpspw_pro_get_settings2();

// Admin Class
require_once( WPSPW_PRO_DIR . '/includes/admin/class-wpspw-admin.php' );

// Script Class
require_once( WPSPW_PRO_DIR . '/includes/class-wpspw-script.php' );

// Shortcode files
require_once( WPSPW_PRO_DIR . '/includes/shortcodes/add-userform.php' );
require_once( WPSPW_PRO_DIR . '/includes/shortcodes/user-history-shortcode.php' );
require_once( WPSPW_PRO_DIR . '/includes/shortcodes/alluserssubmission.php' );
require_once( WPSPW_PRO_DIR . '/includes/shortcodes/user-login.php' );
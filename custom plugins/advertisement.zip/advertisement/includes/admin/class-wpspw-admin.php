<?php
/**
 * Admin Class
 *
 * Handles the Admin side functionality of plugin
 *
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Wpspw_Pro_Admin {
	
	function __construct() {
		
		// Action to register admin menu
		add_action( 'admin_menu', array($this, 'wpspw_pro_register_menu'), 9 );

		// Action to register plugin settings
		add_action( 'admin_init', array($this, 'wpspw_pro_register_settings') );

		add_action( 'wp_ajax_add_page_data', array($this, 'add_page_data'));
		add_action( 'wp_ajax_nopriv_add_page_data',array( $this, 'add_page_data'));
	}


	/* Call Ajax and get data from payment gateway */
	function add_page_data(){
		global $wpdb;
		
		$user_id = get_current_user_id();

		$item_name = $_POST['item_name'];
		$item_name = rtrim($item_name," ");
		$amt = $_POST['amt'];
		$st = $_POST['st'];

		$pagedata = array(	'item_name' 	=> $item_name,
							'amount' 		=> $amt,
							'sub_imgdata' 	=> '',
	  					);
		add_user_meta($user_id, 'user_pagesub_data', $pagedata);

		$lastid = $wpdb->insert_id;
		
		if($lastid != ''){
			echo $lastid;
			
		} else{
			echo '';
		}
		
		exit();
	}


	/**
	 * Function to register admin menus
	 * 
	 * @package Blog Designer - Post and Widget Pro
	 * @since 1.0.0
	 */
	function wpspw_pro_register_menu() {
		add_menu_page( 'Advertisement', 'Advertise Form', 'manage_options', 'add_options', array($this, 'wpspw_pro_settings_page'), 'dashicons-media-spreadsheet' );
		//add_submenu_page( 'edit.php', __('Blog Designer Settings', 'blog-designer-for-post-and-widget'), __('Blog Designer Setting', 'blog-designer-for-post-and-widget'), 'manage_options', 'wpspw-pro-settings', array($this, 'wpspw_pro_settings_page') );
		add_submenu_page( 'add_options', 'User Entries', 'User Entries', 'manage_options', 'advertise-user-entry', array($this, 'ad_user_entry_fun'));
	}

	function ad_user_entry_fun(){
		include_once( WPSPW_PRO_DIR . '/includes/admin/settings/userentry.php' );
	}
	
	/**
	 * Function to handle the setting page html
	 * 
	 * @package Blog Designer - Post and Widget Pro
	 * @since 1.0.0
	 */
	function wpspw_pro_settings_page() {
		include_once( WPSPW_PRO_DIR . '/includes/admin/settings/wpspw-settings.php' );
	}

	/**
	 * Function register setings
	 * 
	 * @package Blog Designer - Post and Widget Pro
	 * @since 1.0.0
	 */
	function wpspw_pro_register_settings() {
		register_setting( 'wpspw_pro_plugin_options', 'wpspw_pro_options', array($this, 'wpspw_pro_validate_options') );
		register_setting( 'wpspw_user_options', 'wpspw_userentry_options', array($this, 'wpspw_pro_validate_options') );
	}  // (option group name in detting_field, option name to save, callback fun)

	/**
	 * Validate Settings Options
	 * 
	 * @package Blog Designer - Post and Widget Pro
	 * @since 1.0.0
	 */
	function wpspw_pro_validate_options($input) {
		
		$input['default_img'] 	= isset($input['default_img']) 	? wpspw_slashes_deep($input['default_img']) 		: '';
		global $wp, $post, $wpdb;
		$results = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}usermeta WHERE `meta_key`='user_pagesub_data' AND `user_id`='".$uid."' ORDER BY `umeta_id` DESC ", OBJECT );
	
		foreach($results as $resdataarr){
			
			$umeta_id 		= $resdataarr->umeta_id;
			$curr_uid 		= $resdataarr->curr_uid;
			$userdataarr1 	= $resdataarr->meta_value;

			$userdataarr = maybe_unserialize($userdataarr1);	
			$item_name = $userdataarr['item_name'];

			if($item_name == 'Image With caption'){
				$input['imgcap_'.$ic_umeta_id] = isset($input['imgcap_'.$ic_umeta_id]) 	? wpspw_slashes_deep($input['imgcap_'.$ic_umeta_id]) : '';
			}

			if($item_name == 'page'){
				$input['imgcap_'.$ic_umeta_id] = isset($input['imgcap_'.$ic_umeta_id]) 	? wpspw_slashes_deep($input['imgcap_'.$ic_umeta_id]) : '';
			}

			


		}
		
		return $input;


	}

	function wpspw_ue_validate_options($input){
		return $input;
	}


}

$wpspw_pro_admin = new Wpspw_Pro_Admin();
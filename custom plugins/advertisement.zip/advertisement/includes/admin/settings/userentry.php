<?php
/**
 * Settings Page
 *
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit; ?>

<div class="wrap wpspw-settings">
	<h2><?php _e( 'User Entries', 'blog-designer-for-post-and-widget' ); ?></h2><br />
<?php
	if( isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true' ) {
	echo '<div id="message" class="updated notice notice-success is-dismissible">
			<p><strong>'.__("Your changes saved successfully.", "blog-designer-for-post-and-widget").'</strong></p>
		  </div>';
} ?>

	<style>

.user_cap{
	display: block;
    padding: 8px 2px 12px 2px;
    max-width: 142px;
}
.page_parent, .sub_block{ clear: both; }

table th, table td{text-align: center !important;}

</style>
<form action="options.php" method="POST" id="wpspw-settings-form1" class="wpspw-settings-form1">
	
	<?php
	    settings_fields( 'wpspw_user_options' );
	    global $wpspw_userentry_options; 
	?>
	<div id="wpspw-layout-sett" class="post-box-container wpspw-layout-sett  form-table wpspw-general-sett-tbl">
		<div class="metabox-holder">
			<div class="meta-box-sortables ui-sortable">
				<div class="postbox">

					<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'Page Settings', 'blog-designer-for-post-and-widget' ); ?></span>
						</h3>					

						<div class="inside">

			<table>
				<tr>
					<td style="width: 100%;"></td>
					<td valign="top" scope="row" >
						<input type="submit" id="wpspw-settings-submit1" name="wpspw-settings-submit1" class="button button-primary right" value="Save Changes">
					</td>
				</tr>
			</table>

	<?php
	$imagewithcaptionarr = array();
	$articlearr = array();
	$advarr = array();
	$pagearr = array();
	$users = get_users( array( 'fields' => array( 'ID','display_name' ) ) );
	global $wp, $post, $wpdb;
	foreach($users as $user){

	$uid =  $user->ID;  
	$display_name =  $user->display_name;  									
	$usersubdataarr2 = get_user_meta($uid, 'user_pagesub_data');

	/*********** '".$uid."' ***********/
	$results = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}usermeta WHERE `meta_key`='user_pagesub_data' AND `user_id`='".$uid."' ORDER BY `umeta_id` ASC ", OBJECT );

	
	foreach($results as $resdataarr){
		
		$umeta_id 		= $resdataarr->umeta_id;
		$curr_uid 		= $resdataarr->curr_uid;
		$userdataarr1 	= $resdataarr->meta_value;

		$userdataarr1 = maybe_unserialize($userdataarr1);	
		
	}

	/**********************/
		
	wp_enqueue_style( 'ad-bootstrap-style' );
	wp_enqueue_script('ad-bootstrap.min');
		
	$ic = 1; $art = 1; $ad = 1;  $page = 1; 

	/*

		foreach($usersubdataarr2 as $usersubdataarr1){	
	    
        $count = count($usersubdataarr1);
		$num = $count-1;
		$userdataarr = maybe_unserialize($usersubdataarr1);	
			
		 For User Image With Caption 
		$item_name = $userdataarr['item_name'];
	*/

	foreach($results as $resdataarr){	

		$umeta_id 		= $resdataarr->umeta_id;
		$curr_uid 		= $resdataarr->curr_uid;
		$userdataarr1 	= $resdataarr->meta_value;
	
		$userdataarr = maybe_unserialize($userdataarr1);	
		
		/* For User Image With Caption */
		$item_name = $userdataarr['item_name'];
			
		if($item_name == 'Image With caption'){

			$imagewithcaptionarr[] =  $userdataarr['sub_imgdata'];
			$imagewithcaptionarr['uname'][] =  $display_name;
			$imagewithcaptionarr['uid'][] =  $uid;
			$imagewithcaptionarr['umeta_id'][] =  $umeta_id;

			
		}

		


		/* Articles */		
		if($item_name == 'article'){

			$articlearr[] = $userdataarr['sub_imgdata'];
			$articlearr['uname'][] =  $display_name;
			$articlearr['uid'][] =  $uid;
			$articlearr['umeta_id'][] =  $umeta_id;
		}			
		/* advertisement */
		if($item_name == 'advertisement'){

			$advarr[] = $userdataarr['sub_imgdata'];  
			$advarrsize['item_name_size'][] = $userdataarr['item_name_size'];
			$advarr['uname'][] =  $display_name;
			$advarr['uid'][] =  $uid;
			$advarr['umeta_id'][] =  $umeta_id;
		}
		/* page */
		if($item_name == 'page'){

			$pagearr[] = $userdataarr['sub_imgdata']; 
			$pagearrsize['item_name_size'][] = $userdataarr['item_name_size']; 
			$pagearr['uname'][] =  $display_name;	
			$pagearr['uid'][] =  $uid;				
			$pagearr['umeta_id'][] =  $umeta_id;				
		}

	} /* end foreach*/

} /* end foreach user loop*/

if(!empty($imagewithcaptionarr)){	
	?>
	<div class="sub_block"> 
		<div> <h3> Image With caption Submission </h3></div>
		<table style="width: 100%;">
			<tr>
				<th style="width: 25%; ">USer</th>
				<th style="width: 25%; ">Photo</th>
				<th style="width: 25%; ">Caption</th>
				<th style="width: 25%; ">Approve</th>
			</tr>
		
		<?php $ic= 0;

		foreach($imagewithcaptionarr as $ickey => $icval){  

			if($icval['imageid'] != ''){
			//if($ic == 0){ echo '<div>'; }
				
				//foreach($icval as $key => $val){					
					
				$imageid = $icval['imageid'];  
				$ic_umeta_id = $imagewithcaptionarr['umeta_id'][$ickey];

				$sel_value2 = wpspw_pro_get_option2('imgcap_'.$ic_umeta_id);

				$sub_cap = ($sel_value2) ? $sel_value2 : $icval['sub_cap'];


				$image_src = wp_get_attachment_image_src($imageid);
				$image_src = $image_src[0];
				$sel_value = wpspw_pro_get_option2($imageid);
				
				
				?>
				<!-- <div style="float: left; margin-right: 38px;"> -->
				<tr>
					<td style="width: 25%; "> <?php echo $imagewithcaptionarr['uname'][$ickey];  ?> </td>
					<td style="width: 25%; "><a href="<?php echo $image_src; ?>" download><img src="<?php echo $image_src; ?>" class="myImg" style="width: 142px; height:auto;"> </a></td>
					<td style="width: 25%; ">
						<input type="text" name="wpspw_userentry_options[imgcap_<?php echo $ic_umeta_id; ?>]" value="<?php echo $sub_cap; ?>" >
					</td>
					<td style="width: 25%; "><input type="checkbox" <?php checked($imageid, $sel_value, true); ?> name="wpspw_userentry_options[<?php echo $imageid; ?>]"  value="<?php echo $imageid; ?>"></td>
				</tr>
				
				<!-- </div>	 -->	
				<?php
					
				++$ic;
				if($ic%4 == 0){$ic = 0;}
			//if($ic == 0){ echo '</div>'; }	
			}
		}
		?>
		</table>
	</div>
	<?php 	
}

if(!empty($articlearr)){
	
	?>
	<div class="sub_block"> 
		<div> <h3>Article Submission </h3></div>
		<table style="width: 100%;">
			<tr>
				<th style="width: 25%; ">USer</th>
				<th style="width: 25%; ">Photo</th>
				<th style="width: 25%; ">Size</th>
				<th style="width: 25%; ">Approve</th>
			</tr>
		<?php $ar= 0;
		foreach($articlearr as $arkey => $arval){ 
			if($arval['imageid'] != ''){

				$imageid = $arval['imageid'];
				$pagesize = $arval['pagesize'];
				$image_src = wp_get_attachment_image_src($imageid);
				$image_src = $image_src[0];
				$sel_value = wpspw_pro_get_option2($imageid);
				?>
				<tr>
					<td style="width: 25%; "> <?php echo $articlearr['uname'][$arkey];  ?> </td>
					<td><a href="<?php echo $image_src; ?>" download> <img src="<?php echo $image_src; ?>" class="myImg" style="width: 142px; height:auto;"> </a> </td>
					<td><?php echo $pagesize; ?></td>
					<td><input type="checkbox" <?php checked($imageid, $sel_value, true); ?> name="wpspw_userentry_options[<?php echo $imageid; ?>]"  value="<?php echo $imageid; ?>"></td>
				</tr>
				
				<?php		
				++$ar;		
			}			
		}
		?>
		</table>
	</div>
	<?php 	
}

if(!empty($advarr)){ /* Advertisement */ 
	?>
	<div class="sub_block"> 
		<div> <h3>Advertisement Submission </h3></div>
		<table style="width: 100%;">
			<tr>
				<th style="width: 25%; ">User</th>
				<th style="width: 25%; ">Photo</th>
				<th style="width: 25%; ">Size</th>
				<th style="width: 25%; ">Approve</th>
			</tr>
		<?php 
		foreach($advarr as $adkey => $adval){ 

			foreach($adval as $key => $val){ 
				if(is_int($val['imageid'])){

					$imageid = $val['imageid']; 
					$pagesize = $advarrsize['item_name_size'][$adkey];
					$image_src = wp_get_attachment_image_src($imageid);
					$image_src = $image_src[0];
					$sel_value = wpspw_pro_get_option2($imageid);
					?>
					<tr>
						<td style="width: 25%; "> <?php echo $advarr['uname'][$adkey];  ?> </td>
						<td><a href="<?php echo $image_src; ?>" download><img src="<?php echo $image_src; ?>" class="myImg" style="width: 142px; height:auto;"> </a> </td>
						<td><?php echo $pagesize; ?></td>
						<td><input type="checkbox" <?php checked($imageid, $sel_value, true); ?> name="wpspw_userentry_options[<?php echo $imageid; ?>]"  value="<?php echo $imageid; ?>"></td>
					</tr>
					
					<?php	
				}	
			} 
					
		}
		?>
		</table>
	</div>
	<?php 	
}

if(!empty($pagearr)){
	
	?>
	<div class="sub_block"> 
		<div> <h3>Page Submission </h3></div>
		<table style="width: 100%;">
			<tr>
				<th style="width: 10%; ">User</th>
				<th style="width: 25%; ">Photo</th>
				<th style="width: 25%; ">Caption</th>
				<th style="width: 10%; ">Size</th>
				<th style="width: 25%; ">Approve</th>
			</tr>
			<?php 
			foreach($pagearr as $pagekey => $pageval){  ?>
				
				<?php
				$pa = 0;
				foreach($pageval as $key => $val){  
					
					if(is_int($val['imageid'])){

						$imageid = $val['imageid']; 
						$item_name_size = $val['item_name_size'];
						$imagecaption = $val['caption'];

						$ic_umeta_id2 = $pagearr['umeta_id'][$key];

						$sel_value2 = wpspw_pro_get_option2('imgcap_'.$ic_umeta_id2);

						$sub_cap = ($sel_value2) ? $sel_value2 : $imagecaption;

						$image_src = wp_get_attachment_image_src($imageid);
						$image_src = $image_src[0];
						$pagesize = $pagearrsize['item_name_size'][$pagekey];
						$sel_value = wpspw_pro_get_option2($imageid);
						?>
						<tr>
							<td style="width: 10%; "> <?php echo $pagearr['uname'][$key];  ?> </td>
							<td><a href="<?php echo $image_src; ?>" download><img src="<?php echo $image_src; ?>" class="myImg" style="width: 142px; height:auto;"></a> </td>
							<td>
								
								<input type="text" name="wpspw_userentry_options[imgcap_<?php echo $ic_umeta_id2; ?>]" value="<?php echo $sub_cap; ?>" >

							</td>
							<td><?php echo $pagesize; ?></td>
							<td><input type="checkbox" <?php checked($imageid, $sel_value, true); ?> name="wpspw_userentry_options[<?php echo $imageid; ?>]"  value="<?php echo $imageid; ?>"></td>
						</tr>					 					
						<?php
					}						
				} 					
			}
		?>
		</table>
	</div>
	<?php 	
}

?>

					</div><!-- .inside -->
				</div><!-- .postbox -->
			</div><!-- .meta-box-sortables ui-sortable -->
		</div><!-- .metabox-holder -->
	</div><!-- #wpspw-layout-sett -->
	<!-- Layout Settings Ends -->

</form><!-- end .wpspw-settings-form -->
</div>
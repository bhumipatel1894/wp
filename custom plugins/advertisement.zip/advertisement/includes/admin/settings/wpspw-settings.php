<?php
/**
 * Settings Page
 *
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// Taking some globals
global $wp_version;
?>

<div class="wrap wpspw-settings">

<h2><?php _e( 'Admin Mag Settings', 'blog-designer-for-post-and-widget' ); ?></h2><br />

<?php
// Success message 
if(isset($_POST['wpspw_reset_setts']) && !empty($_POST['wpspw_reset_setts'])) {
		
		wpspw_pro_default_settings(); // set default settings
		
		// Resett message
		echo '<div id="message" class="updated fade"><p><strong>' . __( 'All settings reset successfully.', 'blog-designer-for-post-and-widget') . '</strong></p></div>';
		
} else if( isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true' ) {
	echo '<div id="message" class="updated notice notice-success is-dismissible">
			<p><strong>'.__("Your changes saved successfully.", "blog-designer-for-post-and-widget").'</strong></p>
		  </div>';
}
?>
<div class="shortcode" style="background: white; padding: 20px; margin-bottom: 18px;">
	<table>
		<tr> <td><b>User Submission form Shortcode: </b> </td><td><b> [advertise_userform]</b></td></tr>
		<tr><td><b>All User Submission Shortcode: </b> </td><td><b> [allusersubmission]</b></td> </tr>
		<tr><td><b>User Submission History Shortcode: </b> </td><td><b> [user_history]</b></td> </tr>
		<tr><td><b>User Login & Registration Form: </b> </td><td><b> [userloginform]</b></td></tr>
	</table>
	
</div>
<form action="" method="post">
	<div class="textright">
		<input type="submit" name="wpspw_reset_setts" value="<?php _e('Reset All Settings', 'blog-designer-for-post-and-widget'); ?>" class="button button-primary wpspw-reset-sett" />
	</div>
</form><!-- Reset settings form -->

<form action="options.php" method="POST" id="wpspw-settings-form" class="wpspw-settings-form">
	
	<?php
	    settings_fields( 'wpspw_pro_plugin_options' );
	    global $wpspw_pro_options; 
	?>
	
	<!-- General Settings Starts -->
	<div id="wpspw-general-sett" class="post-box-container wpspw-general-sett">
		<div class="metabox-holder">
			<div class="meta-box-sortables ui-sortable">
				<div id="general" class="postbox">

					<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'General Settings', 'blog-designer-for-post-and-widget' ); ?></span>
						</h3>
						
						<div class="inside">
						
						<table class="form-table wpspw-general-sett-tbl">
							<tbody>
								<tr>
									<th scope="row">
										<label for="wpspw-pro-default-img"><?php _e('Submission Page Background Image', 'blog-designer-for-post-and-widget'); ?>:</label>
									</th>
									<td>
										<input type="text" name="wpspw_pro_options[default_img]" value="<?php echo wpspw_pro_esc_attr( wpspw_pro_get_option('default_img') ); ?>" id="wpspw-pro-default-img" class="regular-text wpspw-pro-default-img wpspw-pro-img-upload-input" />
										<input type="button" name="wpspw_pro_default_img" class="button-secondary wpspw-pro-image-upload" value="<?php _e( 'Upload Image', 'blog-designer-for-post-and-widget'); ?>" data-uploader-title="<?php _e('Choose Logo', 'blog-designer-for-post-and-widget'); ?>" data-uploader-button-text="<?php _e('Insert Logo', 'blog-designer-for-post-and-widget'); ?>" /> <input type="button" name="wpspw_pro_default_img_clear" id="wpspw-pro-default-img-clear" class="button button-secondary wpspw-pro-image-clear" value="<?php _e( 'Clear', 'blog-designer-for-post-and-widget'); ?>" /> <br />
										<span class="description"><?php _e( 'Upload default image or provide an external URL of image. ', 'blog-designer-for-post-and-widget' ); ?></span>
										<?php
											$default_img = '';
											if( wpspw_pro_get_option('default_img') ) { 
												$default_img = '<img src="'.wpspw_pro_get_option('default_img').'" alt="" />';
											}
										?>
										<div class="wpspw-pro-img-view"><?php echo $default_img; ?></div>
									</td>
								</tr>
								<tr>
									<td colspan="2" valign="top" scope="row">
										<input type="submit" id="wpspw-settings-submit" name="wpspw-settings-submit" class="button button-primary right" value="<?php _e('Save Changes','blog-designer-for-post-and-widget'); ?>" />
									</td>
								</tr>
							</tbody>
						 </table>

					</div><!-- .inside -->
				</div><!-- #general -->
			</div><!-- .meta-box-sortables ui-sortable -->
		</div><!-- .metabox-holder -->
	</div><!-- #wpspw-general-sett -->
	<!-- General Settings Ends -->

	<!-- Layout Settings Starts -->
	<div id="wpspw-layout-sett" class="post-box-container wpspw-layout-sett">
		<div class="metabox-holder">
			<div class="meta-box-sortables ui-sortable">
				<div class="postbox">

					<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'Page Settings', 'blog-designer-for-post-and-widget' ); ?></span>
						</h3>
						
						<div class="inside">
						<table class="form-table wpspw-custom-css-sett-tbl">
							<tbody>
								<tr>
									<th colspan="4"><div class="wpspw-sett-title"><?php _e('Full Page Settings', 'blog-designer-for-post-and-widget'); ?></div></th>
								</tr>

								<tr>
									<th scope="row">
										<label for="wpspw-post-title-clr"><?php _e('Full Page Price (8.5*11)', 'blog-designer-for-post-and-widget'); ?>:</label>
									</th>
									<td>
										<input type='text' name="wpspw_pro_options[full_page_price_1]" value="<?php echo wpspw_pro_get_option('full_page_price_1'); ?>" class=" " /><br>
										<span class="description"><?php _e('Enter Price For Full Page Size (8.5*11)', 'blog-designer-for-post-and-widget'); ?></span>
									</td>

									<th scope="row">
										<label for="wpspw-post-title-clr"><?php _e('Full Page Price (6*9)', 'blog-designer-for-post-and-widget'); ?>:</label>
									</th>
									<td>
										<input type='text' name="wpspw_pro_options[full_page_price_2]" value="<?php echo wpspw_pro_get_option('full_page_price_2'); ?>" class=" " /><br>
										<span class="description"><?php _e('Enter Price For Full Page Size (6*9)', 'blog-designer-for-post-and-widget'); ?></span>
									</td>
								</tr><!-- Post Title Color -->

								

								<tr>
									<th colspan="4"><div class="wpspw-sett-title"><?php _e('Quarter Page Settings', 'blog-designer-for-post-and-widget'); ?></div></th>
								</tr>

								<tr>
									<th scope="row">
										<label for="wpspw-post-title-clr"><?php _e('Quarter Page Price (1.5*2.25)', 'blog-designer-for-post-and-widget'); ?>:</label>
									</th>
									<td>
										<input type='text' name="wpspw_pro_options[quarter_page_price_1]" value="<?php echo wpspw_pro_get_option('quarter_page_price_1'); ?>" class=" " /><br>
										<span class="description"><?php _e('Enter Price For Quarter Page Size (1.5*2.25)', 'blog-designer-for-post-and-widget'); ?></span>
									</td>
									<th scope="row">
										<label for="wpspw-post-title-clr"><?php _e('Quarter Page Price (2.125*2.75)', 'blog-designer-for-post-and-widget'); ?>:</label>
									</th>
									<td>
										<input type='text' name="wpspw_pro_options[quarter_page_price_2]" value="<?php echo wpspw_pro_get_option('quarter_page_price_2'); ?>" class=" " /><br>
										<span class="description"><?php _e('Enter Price For Quarter Page Size (2.125*2.75)', 'blog-designer-for-post-and-widget'); ?></span>
									</td>
								</tr>

								<tr>
									<th colspan="4"><div class="wpspw-sett-title"><?php _e('Select page Size For UserForm', 'blog-designer-for-post-and-widget'); ?></div></th>
								</tr>

								<tr>

									<th scope="row" >
										<label for="wpspw-post-title-clr"><?php _e('Select Page Size', 'blog-designer-for-post-and-widget'); ?>:</label>
									</th>
									<th colspan="">
										<select name="wpspw_pro_options[sel_page_size]">
											
											<option value="8.5x11" <?php selected( wpspw_pro_get_option('sel_page_size'), '8.5x11' ); ?> > 8.5 x 11</option>
											<option value="6x9" <?php selected( wpspw_pro_get_option('sel_page_size'), '6x9' ); ?> > 6 x 9 </option>
										</select>
									</th>
									<th scope="row" colspan="2"></th>
								</tr>
								

								<tr>
									<td colspan="4" valign="top" scope="row">
										<input type="submit" id="wpspw-layout-sett-submit" name="wpspw-settings-submit" class="button button-primary right wpspw-layout-sett-submit" value="<?php _e('Save Changes','blog-designer-for-post-and-widget'); ?>" />
									</td>
								</tr>
							</tbody>
						 </table>
					</div><!-- .inside -->
				</div><!-- .postbox -->
			</div><!-- .meta-box-sortables ui-sortable -->
		</div><!-- .metabox-holder -->
	</div><!-- #wpspw-layout-sett -->
	<!-- Layout Settings Ends -->

</form><!-- end .wpspw-settings-form -->

</div><!-- end .wpspw-settings -->
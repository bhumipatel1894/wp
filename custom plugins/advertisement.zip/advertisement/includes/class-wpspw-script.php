<?php
/**
 * Script Class
 *
 * Handles the script and style functionality of plugin
 *
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Wpspw_Pro_Script {
	
	function __construct() {
		
		// Action to add style at front side
		add_action( 'wp_enqueue_scripts', array($this, 'wpspw_pro_front_style') );
		
		// Action to add script at front side
		add_action( 'wp_enqueue_scripts', array($this, 'wpspw_pro_front_script') );

		// Action to add style in backend
		add_action( 'admin_enqueue_scripts', array($this, 'wpspw_pro_admin_style') );

		// Action to add script at admin side
		add_action( 'admin_enqueue_scripts', array($this, 'wpspw_pro_admin_script') );

		// Action to add custom css in head
		add_action( 'wp_head', array($this, 'wpspw_pro_custom_css'), 20 );
	}


	/**
	 * Function to add style at front side
	 * 
	 * @package Blog Designer - Post and Widget Pro
	 * @since 1.0.4
	 */
	function wpspw_pro_front_style() {

		// Registring and enqueing slick slider css
		if( !wp_style_is( 'wpos-slick-style', 'registered' ) ) {
			wp_register_style( 'wpos-slick-style', WPSPW_PRO_URL.'assets/css/slick.css', array(), WPSPW_PRO_VERSION );
			wp_enqueue_style( 'wpos-slick-style' );
		}

		// Registring and enqueing public css
		wp_register_style( 'wpspw-pro-public-style', WPSPW_PRO_URL.'assets/css/wpspw-pro-public.css', array(), WPSPW_PRO_VERSION );
		wp_enqueue_style( 'wpspw-pro-public-style' );

		// Bootstrap css
		wp_register_style( 'ad-bootstrap-style', WPSPW_PRO_URL.'assets/css/bootstrap.min.css', array(), WPSPW_PRO_VERSION );
		
	}

	/**
	 * Function to add script at front side
	 * 
	 * @package Blog Designer - Post and Widget Pro
	 * @since 1.0.0
	 */
	function wpspw_pro_front_script() {

		// Registring slick slider script
		if( !wp_script_is( 'ad-bootstrap.min', 'registered' ) ) {
			wp_register_script( 'ad-bootstrap.min', WPSPW_PRO_URL. 'assets/js/bootstrap.min.js', array('jquery'), WPSPW_PRO_VERSION, true);
		}
		
		
		// Registring and enqueing public script
		wp_register_script( 'wpspw-pro-public-script', WPSPW_PRO_URL. 'assets/js/wpspw-pro-public.js', array('jquery'), WPSPW_PRO_VERSION, true );
		wp_localize_script( 'wpspw-pro-public-script', 'WpspwPro', array(
																		'ajaxurl' 		=> admin_url( 'admin-ajax.php', ( is_ssl() ? 'https' : 'http' ) ),
																		'is_rtl' 	=> (is_rtl()) ? 1 : 0
																	));
		
	}

	/**
	 * Enqueue admin styles
	 * 
	 * @package Blog Designer - Post and Widget Pro
	 * @since 1.0.0
	 */
	function wpspw_pro_admin_style( $hook ) {

		// Pages array
		$pages_array = array( 'posts_page_wpspw-pro-settings' );

		// Registring admin script
		wp_register_style( 'wpspw-pro-admin-css', WPSPW_PRO_URL.'assets/css/wpspw-pro-admin.css', null, WPSPW_PRO_VERSION );
		wp_enqueue_style( 'wpspw-pro-admin-css' );
		
	}
	

	/**
	 * Function to add script at admin side
	 * 
	 * @package Blog Designer - Post and Widget Pro
	 * @since 1.0.0
	 */
	function wpspw_pro_admin_script( $hook ) {
		
		global $wp_version, $wp_query, $post_type;
		
		$new_ui = $wp_version >= '3.5' ? '1' : '0'; // Check wordpress version for older scripts		
			
		// Registring admin script
		wp_register_script( 'wpspw-pro-admin-js', WPSPW_PRO_URL.'assets/js/wpspw-pro-admin.js', array('jquery'), WPSPW_PRO_VERSION, true );
		wp_localize_script( 'wpspw-pro-admin-js', 'WpspwProAdmin', array(
																'new_ui' 	=> $new_ui,
																'reset_msg'	=> __('Click OK to reset all options. All settings will be lost!', 'blog-designer-for-post-and-widget'),
															));
		wp_enqueue_script( 'wpspw-pro-admin-js' );
		wp_enqueue_media(); // For media uploader
		
		
	}

}

$wpspw_pro_script = new Wpspw_Pro_Script();
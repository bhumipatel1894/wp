<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

add_shortcode('advertise_userform', 'add_userform_fun');

function add_userform_fun($atts, $content = null){
	
	ob_start();
	global $wp, $post, $wpdb;
	global $current_user;
	$user_id = get_current_user_id();	
	
	$disp_cls = 'none';
	$item_name = '';	
	$current_url = home_url( $wp->request );

	$results = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}usermeta WHERE `meta_key`='user_pagesub_data' AND `user_id`='".$user_id."' ORDER BY `umeta_id` DESC LIMIT 1", OBJECT );
	
	$umeta_id 		= $results[0]->umeta_id;
	$userdataarr1 	= $results[0]->meta_value;
    
	wp_enqueue_style( 'ad-bootstrap-style' );
	
	$count 	= count($userdataarr1);
	$num 	= $count-1;
	
	$userdataarr = maybe_unserialize($userdataarr1);	

	if(!empty($userdataarr) ){
		$item_name 		= $userdataarr['item_name'];  
		$item_amount 	= $userdataarr['amount'];  		
	}
	
	if($user_id){ /* If Userloggedin then only form should display */ 

		if(isset($_POST['but_submit'])){ 
			//$current_url = home_url( $wp->request );
			require( get_template_directory() . '/../../../wp-load.php' );
			$wordpress_upload_dir = wp_upload_dir();
			
			$submissiontypeval 	= $_POST['submissiontypeval'];

			if( ($submissiontypeval == '1') && ($_FILES['sub_img_free']['name'] != '') ){
				
				$sub_cap = $_POST['sub_img_free_cap'];  
				$new_file_path = $wordpress_upload_dir['path'] . '/' . $_FILES['sub_img_free']['name'];
				$new_file_mime = mime_content_type( $_FILES['sub_img_free']['tmp_name'] );

				if( empty( $_FILES['sub_img_free'] ) )
				die( 'File is not selected.' );
				
				if( $_FILES['sub_img_free']['error'] )
				die( $_FILES['sub_img_free']['error'] );
				
				if( $_FILES['sub_img_free']['size'] > wp_max_upload_size() )
				die( 'It is too large than expected.' );

				if( !in_array( $new_file_mime, get_allowed_mime_types() ) )
				die( 'WordPress doesn\'t allow this type of uploads.' );

				while( file_exists( $new_file_path ) ) {
					$i++;
					$new_file_path = $wordpress_upload_dir['path'] . '/' . $i . '_' . $_FILES['sub_img_free']['name'];
				}

				// looks like everything is OK
				if( move_uploaded_file( $_FILES['sub_img_free']['tmp_name'], $new_file_path ) ) {				 
				 
					$upload_id = wp_insert_attachment( array(
						'guid'           => $new_file_path, 
						'post_mime_type' => $new_file_mime,
						'post_title'     => preg_replace( '/\.[^.]+$/', '', $_FILES['sub_img_free']['name'] ),
						'post_content'   => '',
						'post_status'    => 'inherit'
					), $new_file_path );
				 
					// wp_generate_attachment_metadata() won't work if you do not include this file
					require_once( ABSPATH . 'wp-admin/includes/image.php' );
				 
					// Generate and save the attachment metas into the database
					wp_update_attachment_metadata( $upload_id, wp_generate_attachment_metadata( $upload_id, $new_file_path ) );

					$subimagedata = array(  
										'item_name' 	=> 'Image With caption',
										'amount' 		=> '0',
										'sub_imgdata' 	=> array( 	'imageid' => $upload_id,
											 						'sub_cap' => $sub_cap,		
																),
									);

					add_user_meta($user_id, 'user_pagesub_data', $subimagedata);	
					echo '<div>Image & Caption Has Been Submitted...<br> Go back to submit another submission <a href="'.$current_url.'">Go back</a></div>';
					exit;							 
				} 
				
			}
			if( ($submissiontypeval == '2') && ($_FILES['article_free']['name'] != '')  ){

				$article_pagesize = $_POST['article_page_size'];  

				$new_file_path = $wordpress_upload_dir['path'] . '/' . $_FILES['article_free']['name'];
				$new_file_mime = mime_content_type( $_FILES['article_free']['tmp_name'] );

				if( empty( $_FILES['article_free'] ) )
				die( 'File is not selected.' );
				
				if( $_FILES['article_free']['error'] )
				die( $_FILES['article_free']['error'] );
				
				if( $_FILES['article_free']['size'] > wp_max_upload_size() )
				die( 'It is too large than expected.' );

				if( !in_array( $new_file_mime, get_allowed_mime_types() ) )
				die( 'WordPress doesn\'t allow this type of uploads.' );

				while( file_exists( $new_file_path ) ) {
					$i++;
					$new_file_path = $wordpress_upload_dir['path'] . '/' . $i . '_' . $_FILES['article_free']['name'];
				}

				// looks like everything is OK
				if( move_uploaded_file( $_FILES['article_free']['tmp_name'], $new_file_path ) ) {				 
				 
					$upload_id = wp_insert_attachment( array(
						'guid'           => $new_file_path, 
						'post_mime_type' => $new_file_mime,
						'post_title'     => preg_replace( '/\.[^.]+$/', '', $_FILES['article_free']['name'] ),
						'post_content'   => '',
						'post_status'    => 'inherit'
					), $new_file_path );
				 
					// wp_generate_attachment_metadata() won't work if you do not include this file
					require_once( ABSPATH . 'wp-admin/includes/image.php' );
				 
					// Generate and save the attachment metas into the database
					wp_update_attachment_metadata( $upload_id, wp_generate_attachment_metadata( $upload_id, $new_file_path ) );

					$subimagedata = array(  
										'item_name' 	=> 'article',
										'sub_imgdata' 	=> array( 	'imageid' => $upload_id,
											 						'pagesize' => $article_pagesize,		
																),
									);

					add_user_meta($user_id, 'user_pagesub_data', $subimagedata);	
					//wp_redirect($current_url);
					echo '<div>Article Has Been Submitted...<br> Go back to submit another submission <a href="'.$current_url.'">Go back</a></div>';
					exit;
							 
				} 

			}
			if($submissiontypeval == '3'){ /* Page Submit */

				$pagesizeval = $_POST['pagesizeval']; 
				$filearr = array();

				$results = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}usermeta WHERE `meta_key`='user_pagesub_data' AND `user_id`='".$user_id."' ORDER BY `umeta_id` DESC LIMIT 1", OBJECT );
				$umeta_id = $results[0]->umeta_id;
				$userdataarr1 = $results[0]->meta_value;
				$userdataarr = maybe_unserialize($userdataarr1);
				$item_name = $userdataarr['item_name']; 
				$item_amount = $userdataarr['amount']; 

				$filearr[] = $_FILES['page_ic_img1'];
				$filearr[] = $_FILES['page_ic_img2'];
				$filearr[] = $_FILES['page_ic_img3'];
				$filearr[] = $_FILES['page_ic_img4'];

				$page_caption[] = $_POST['page_ic_cap1'];
				$page_caption[] = $_POST['page_ic_cap2'];
				$page_caption[] = $_POST['page_ic_cap3'];
				$page_caption[] = $_POST['page_ic_cap4'];

				$caption = '';

				foreach($filearr as $filekey => $fileval){

					if($fileval['name'] != ''){

						$new_file_path = $wordpress_upload_dir['path'] . '/' . $fileval['name'];
						$new_file_mime = mime_content_type( $fileval['tmp_name'] );

						if( empty( $fileval ) )
						die( 'File is not selected.' );
						
						if( $fileval['error'] )
						die( $fileval['error'] );
						
						if( $fileval['size'] > wp_max_upload_size() )
						die( 'It is too large than expected.' );

						if( !in_array( $new_file_mime, get_allowed_mime_types() ) )
						die( 'WordPress doesn\'t allow this type of uploads.' );

						while( file_exists( $new_file_path ) ) {
							$i++;
							$new_file_path = $wordpress_upload_dir['path'] . '/' . $i . '_' . $fileval['name'];
						}

						// looks like everything is OK
						if( move_uploaded_file( $fileval['tmp_name'], $new_file_path ) ) {				 
						 
							$upload_id = wp_insert_attachment( array(
								'guid'           => $new_file_path, 
								'post_mime_type' => $new_file_mime,
								'post_title'     => preg_replace( '/\.[^.]+$/', '', $fileval['name'] ),
								'post_content'   => '',
								'post_status'    => 'inherit'
							), $new_file_path );
						 
							// wp_generate_attachment_metadata() won't work if you do not include this file
							require_once( ABSPATH . 'wp-admin/includes/image.php' );
						 
							// Generate and save the attachment metas into the database
							wp_update_attachment_metadata( $upload_id, wp_generate_attachment_metadata( $upload_id, $new_file_path ) );

							$sub_imgdata[] = array( 'imageid' => $upload_id,
													'caption' => $page_caption[$filekey],
													);							 
						}

					} /* end if */

				} /* end foreach */		

				$subimagedata = array(  
									'item_name' 	=> 'page',
									'item_name_size' => $item_name,
									'amount' 		=> $item_amount,									
									'sub_imgdata' 	=> $sub_imgdata,
								);

				$table = '{$wpdb->prefix}usermeta';
				$wpdb->delete( $table, array( 'umeta_id' => $umeta_id ) );						
	     		add_user_meta($user_id, 'user_pagesub_data', $subimagedata );
				//wp_redirect($current_url);
				echo '<div>Submissions Has Been Submitted...<br> Go back to submit another submission <a href="'.$current_url.'">Go back</a></div>';
				exit;											

			}
			if($submissiontypeval == '4'){

				$pagesizeval = $_POST['pagesizeval']; 
				$filearr = array();

				$results = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}usermeta WHERE `meta_key`='user_pagesub_data' AND `user_id`='".$user_id."' ORDER BY `umeta_id` DESC LIMIT 1", OBJECT );
				$umeta_id = $results[0]->umeta_id;
				$userdataarr1 = $results[0]->meta_value;
				$userdataarr = maybe_unserialize($userdataarr1);
				$item_name = $userdataarr['item_name']; 
				$item_amount = $userdataarr['amount']; 

				$filearr[] = $_FILES['advertisement_ic_img1'];
				$filearr[] = $_FILES['advertisement_ic_img2'];
				$filearr[] = $_FILES['advertisement_ic_img3'];
				$filearr[] = $_FILES['advertisement_ic_img4'];					

				foreach($filearr as $filekey => $fileval){

					if($fileval['name'] != ''){

						$new_file_path = $wordpress_upload_dir['path'] . '/' . $fileval['name'];
						$new_file_mime = mime_content_type( $fileval['tmp_name'] );

						if( empty( $fileval ) )
						die( 'File is not selected.' );
						
						if( $fileval['error'] )
						die( $fileval['error'] );
						
						if( $fileval['size'] > wp_max_upload_size() )
						die( 'It is too large than expected.' );

						if( !in_array( $new_file_mime, get_allowed_mime_types() ) )
						die( 'WordPress doesn\'t allow this type of uploads.' );

						while( file_exists( $new_file_path ) ) {
							$i++;
							$new_file_path = $wordpress_upload_dir['path'] . '/' . $i . '_' . $fileval['name'];
						}

						// looks like everything is OK
						if( move_uploaded_file( $fileval['tmp_name'], $new_file_path ) ) {				 
						 
							$upload_id = wp_insert_attachment( array(
								'guid'           => $new_file_path, 
								'post_mime_type' => $new_file_mime,
								'post_title'     => preg_replace( '/\.[^.]+$/', '', $fileval['name'] ),
								'post_content'   => '',
								'post_status'    => 'inherit'
							), $new_file_path );
						 
							// wp_generate_attachment_metadata() won't work if you do not include this file
							require_once( ABSPATH . 'wp-admin/includes/image.php' );
						 
							// Generate and save the attachment metas into the database
							wp_update_attachment_metadata( $upload_id, wp_generate_attachment_metadata( $upload_id, $new_file_path ) );

							$sub_imgdata[] = array( 'imageid' => $upload_id);							 
						}

					} /* end if */

				} /* end foreach */		

				$subimagedata = array(  
									'item_name' 	=> 'advertisement',
									'item_name_size' => $item_name,
									'amount' 		=> $item_amount,									
									'sub_imgdata' 	=> $sub_imgdata,
								);

				$table = '{$wpdb->prefix}usermeta';
				$wpdb->delete( $table, array( 'umeta_id' => $umeta_id ) );						
	     		add_user_meta($user_id, 'user_pagesub_data', $subimagedata );
	     		$_POST = array();
				echo '<div>Advertisement Has Been Submitted...<br> Go back to submit another submission <a href="'.$current_url.'">Go back</a></div>';
				exit;				
			}
			
		} ?>


		<div class="user-form">

			<?php
			$pagesize = wpspw_pro_get_option('sel_page_size');

			?>
			
			<form method="post" name="userdatasubmission" clas="form-submission" enctype="multipart/form-data">

				<input type="hidden" name="pageurl" value="<?php echo $current_url; ?>" id="current_url">
				<input type="hidden" name="submissiontypeval" value="" id="submissiontypeval">
				<input type="hidden" name="pagesizeval" value="" id="pagesizeval">

				<div class="row">
					<div class="col-md-12 form-group">						
						
						<select name="submissiontype" id="submissiontype" class="form-control submissiontype">
							<option> -- SELECT SUBMISSION TYPE -- </option>									
							<option value="1">Image With Caption</option>									
							<option value="2">Articles</option>									
							<option value="3">Pages</option>									
							<option value="4">Advertisement</option>									
						</select>
					</div>
				</div>

				<div id="usub_img1_block" class="sub-block row">
					<div class="col-md-12" style="text-align: center; margin-bottom: 10px; "><label>Upload Image With caption </label></div>
					<div class="col-md-6 form-group"><input class="custom-file-input" type="file" id="sub_img_free" name="sub_img_free" size="25" /></div>	
					<div class="col-md-6 form-group"><input class="form-control" placeholder="Image Caption" type="text" id="sub_img_free_cap" name="sub_img_free_cap" size="25" /></div>
				</div>

				<div id="article_block" class="sub-block row" style="display:none;">

					<div class="col-md-4">
						<label style="padding: 0px 0px 8px 0px;" for="article_page_size">Please Choose Article Page Size</label>
					</div>
					<div class="col-md-8 form-group">
						<select name="article_page_size" id="article_page_size" class="form-control custom-select">
							<option value="">--- SELECT PAGE Size ---</option>
							
								<?php 
								if($pagesize == '6x9'){ ?>

									<optgroup label="Article Full Page">										
										<option  value="6X9">Page Size: 6X9 </option>
									</optgroup>
									<optgroup label="Article Half Page">										
										<option value="6X4.5">Page Size: 6X4.5 </option>
									</optgroup>
									<optgroup label="Article Quarter Page">										
										<option value="6X2.25">Page Size: 6X2.25 </option>
									</optgroup>

								<?php  } else { ?>

									<optgroup label="Article Full Page">
										<option  value="8.5X11">Page Size: 8.5X11 </option>										
									</optgroup>
									<optgroup label="Article Half Page">
										<option value=" 8.5X5.5">Page Size: 8.5X5.5 </option>										
									</optgroup>
									<optgroup label="Article Quarter Page">
										<option value="8.5X2.75">Page Size: 8.5X2.75 </option>										
									</optgroup>

								<?php  } ?>

						</select>
					</div>

					<div class="col-md-4"><label>Upload Article Image</label></div>
					<div class="col-md-8 form-group"><input class="custom-file-input" type="file" id="article_free" name="article_free" size="25" /></div>	

				</div>

				<div id="page_block" class="sub-block row" style="display:none;">

					<div class="col-md-4">
						<label style="padding: 0px 0px 8px 0px;" for="page_size">Please Buy Page</label>
						<div class="col-md-12 form-group">
							<div class="col-md-12 form-group">
								<select name="page_block_size" id="page_block_size" class="form-control custom-select">
									<option value="">--- SELECT PAGE TYPE ---</option>

									<?php 
									if($pagesize == '6x9'){ ?>

										<optgroup label="Full Page Options">											
											<option data-name="6X9" value="<?php echo wpspw_pro_get_option('full_page_price_2'); ?>">Page Size 6X9 </option>
										</optgroup>
										<optgroup label="Half Page Options">											
											<option data-name="6X4.5"  value="<?php echo wpspw_pro_get_option('full_page_price_2')/2; ?>">Page Size 6X4.5</option>
										</optgroup>
										<optgroup label="Quarter Page Options">											
											<option data-name="6X2.75" value="<?php echo wpspw_pro_get_option('quarter_page_price_2'); ?>">Page Size 6X2.75</option>
										</optgroup>

									<?php  } else { ?>

										<optgroup label="Full Page Options">
											<option data-name="8.5X11" value="<?php echo wpspw_pro_get_option('full_page_price_1'); ?>">Page Size 8.5X11</option>
											
										</optgroup>
										<optgroup label="Half Page Options">
											<option data-name="8X5.5" value="<?php echo wpspw_pro_get_option('full_page_price_1')/2; ?>">Page Size 8.5X5.5</option>
											
										</optgroup>
										<optgroup label="Quarter Page Options">
											<option data-name="8X2.25" value="<?php echo wpspw_pro_get_option('quarter_page_price_1'); ?>">Page Size 8.5X2.25</option>
											
										</optgroup>

									<?php  } ?>
									
								</select>							
							</div>
						</div>
					</div>
					
					<div class="col-md-12 page_block_uploadsec" style="display:none;">

						<div class="col-md-12"><label>Upload Image With caption </label></div>

						<div class="row page_ic1" style="display:none;">
							<div class="col-md-4 form-group"><input class="custom-file-input" type="file" id="page_ic_img1" name="page_ic_img1" size="25" /></div>	
							<div class="col-md-4 form-group"><input class="form-control" placeholder="Image Caption" type="text" id="page_ic_cap1" name="page_ic_cap1" size="25" /></div>
						</div>
						
						<div class="row page_ic2" style="display:none;"> 
							<div class="col-md-4 form-group"><input class="custom-file-input" type="file" id="page_ic_img2" name="page_ic_img2" size="25" /></div>	
							<div class="col-md-4 form-group"><input class="form-control" placeholder="Image Caption" type="text" id="page_ic_cap2" name="page_ic_cap2" size="25" /></div>
						</div>
						
						<div class="row page_ic3" style="display:none;">
							<div class="col-md-4 form-group"><input class="custom-file-input" type="file" id="page_ic_img3" name="page_ic_img3" size="25" /></div>	
							<div class="col-md-4 form-group"><input class="form-control" placeholder="Image Caption" type="text" id="page_ic_cap3" name="page_ic_cap3" size="25" /></div>
						</div>
						
						<div class="row page_ic4" style="display:none;"> 
							<div class="col-md-4 form-group"><input class="custom-file-input" type="file" id="page_ic_img4" name="page_ic_img4" size="25" /></div>	
							<div class="col-md-4 form-group"><input class="form-control" placeholder="Image Caption" type="text" id="page_ic_cap4" name="page_ic_cap4" size="25" /></div>
						</div>

					</div>					

				</div>

				<div id="advertisement_block" class="sub-block row" style="display:none;">

					<div class="col-md-4">
						<label style="padding: 0px 0px 8px 0px;" for="advertisement_block_size">Please Buy Advertise Page</label>
						<div class="col-md-12 form-group">
							<div class="col-md-12 form-group">
								<select name="advertisement_block_size" id="advertisement_block_size" class="form-control custom-select">
									<option value="">--- SELECT PAGE TYPE ---</option>

									<?php 
									if($pagesize == '6x9'){ ?>

										<optgroup label="Full Page Options"> 											
											<option data-name="6X9" value="<?php echo wpspw_pro_get_option('full_page_price_2'); ?>"> Advertisement size 6X9 </option>
										</optgroup>
										<optgroup label="Half Page Options">
											
											<option data-name="6X4.5" value="<?php echo wpspw_pro_get_option('full_page_price_2')/2; ?>">Advertisement size 6X4.5</option>
										</optgroup>
										<optgroup label="Quarter Page Options">
											
											<option data-name="6X2.25" value="<?php echo wpspw_pro_get_option('quarter_page_price_2'); ?>">Advertisement size 6X2.25</option> 
										</optgroup>

									<?php  } else { ?>

										<optgroup label="Full Page Options"> 
											<option data-name="8.5X11" value="<?php echo wpspw_pro_get_option('full_page_price_1'); ?>"> Advertisement size 8.5X11</option>
											
										</optgroup>
										<optgroup label="Half Page Options">
											<option data-name="8.5X5.5" value="<?php echo wpspw_pro_get_option('full_page_price_1')/2; ?>">Advertisement size 8.5X5.5</option>
											
										</optgroup>
										<optgroup label="Quarter Page Options">
											<option data-name="8.5X2.75" value="<?php echo wpspw_pro_get_option('quarter_page_price_1'); ?>">Advertisement size 8.5X2.75</option>
											 
										</optgroup>

									<?php  } ?>

									
								</select>								
							</div>
						</div>
					</div>

					<div class="col-md-12 advertisement_block_uploadsec" style="display:none;">

						<div class="col-md-12"><label>Upload Image With caption </label></div>

						<div class="col-md-4 form-group"><input class="custom-file-input" style="display:none;" type="file" id="advertisement_ic_img1" name="advertisement_ic_img1" size="25" /></div>	
						<div class="col-md-4 form-group"><input class="custom-file-input" style="display:none;" type="file" id="advertisement_ic_img2" name="advertisement_ic_img2" size="25" /></div>	
						<div class="col-md-4 form-group"><input class="custom-file-input" style="display:none;" type="file" id="advertisement_ic_img3" name="advertisement_ic_img3" size="25" /></div>	
						<div class="col-md-4 form-group"><input class="custom-file-input" style="display:none;" type="file" id="advertisement_ic_img4" name="advertisement_ic_img4" size="25" /></div>

					</div>
				</div>

				<input type="submit" style="display: none;"  id="data_sub_btn" class="form-control" name="but_submit" value="Submit" />
			</form>

			<div class="paypal-pay-btn" style="display:none;">
				<?php echo do_shortcode("[wpecpp name='' price='0']"); ?>
			</div>

			<!-- ********************************************************************************************************************************************* -->
			


		<style type="text/css">
			.paypal-pay-btn{
				    text-align: center;
    				margin-top: 80px;
			}
			.sub-block{margin-top: 30px;     border: 1px solid lightgray;
    padding: 20px;}
    .data_sub_btn{margin-top: 40px;}
			.user-form {    min-width: 1290px !important;
						    align: center;
						    margin: auto;
						    padding: 40px 42px;
						    margin-top: 20px;
						    color: black;}  

						    .user-form .form-title {margin: 20px 4px;
						    text-align: center;
						    padding: 6px 0px;
						        font-size: 20px;
						    font-weight: 600;
						    color: black;}

						    .fullpage_data{margin: 25px 0px 14px 0px;}
						    .article-title{font-size: 14px;
						    font-weight: 600;
						    text-align: center;
						    margin-bottom: 42px;}
		</style>

	<?php 

	wp_enqueue_script('ad-bootstrap.min');	
	wp_enqueue_script('wpspw-pro-public-script');	
	wp_enqueue_script('jquery');	
	} /* end if user is loggedin */
		
	$content .= ob_get_clean();
    return $content;

    exit();
} 
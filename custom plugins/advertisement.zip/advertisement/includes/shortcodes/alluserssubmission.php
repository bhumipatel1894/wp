<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

add_shortcode('allusersubmission', 'alluserssub_fun');

function alluserssub_fun($atts, $content = null){
	ob_start();
	//wp_enqueue_style( 'ad-bootstrap-style' );
	wp_enqueue_script('wpspw-pro-public-script');
	
	?>

	<style>

.myImg {
  border-radius: 5px;
  cursor: pointer;
  transition: 0.3s;
}

.myImg:hover {opacity: 0.7;}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.9); /* Black w/ opacity */
}

/* Modal Content (image) */
.modal-content {
  margin: auto;
  display: block;
  width: 80%;
  max-width: 700px;
}

/* Caption of Modal Image */
#caption {
  margin: auto;
  display: block;
  width: 80%;
  max-width: 700px;
  text-align: center;
  color: #ccc;
  padding: 10px 0;
  height: 150px;
}

/* Add Animation */
.modal-content, #caption {  
  -webkit-animation-name: zoom;
  -webkit-animation-duration: 0.6s;
  animation-name: zoom;
  animation-duration: 0.6s;
}

@-webkit-keyframes zoom {
  from {-webkit-transform:scale(0)} 
  to {-webkit-transform:scale(1)}
}

@keyframes zoom {
  from {transform:scale(0)} 
  to {transform:scale(1)}
}

/* The Close Button */
.admclose {
  position: absolute;
  top: 15px;
  right: 35px;
  color: #f1f1f1;
  font-size: 40px;
  font-weight: bold;
  transition: 0.3s;
}

.user_cap{
	display: block;
    padding: 8px 2px 12px 2px;
    max-width: 142px;
}
.page_parent{ clear: both; }

/* 100% Image Width on Smaller Screens */
@media only screen and (max-width: 700px){
  .modal-content {
    width: 100%;
  }
}
</style>

	<!-- <img id="myImg" src="http://localhost/practice/wp-content/uploads/2020/07/11_dress.jpg" alt="Snow" style="width:100%;max-width:300px"> -->

<!-- The Modal -->
<div id="admyModal" class="modal">
  <span class="admclose">&times;</span>
  <img class="modal-content" id="img01">
  <div id="caption"></div>
</div>
	
<?php
$imagewithcaptionarr = array();
	$articlearr = array();
	$advarr = array();
	$pagearr = array();
$users = get_users( array( 'fields' => array( 'ID','display_name' ) ) );
global $wp, $post, $wpdb;

foreach($users as $user){

	$uid =  $user->ID;  
	$display_name =  $user->display_name;  									
	$usersubdataarr2 = get_user_meta($uid, 'user_pagesub_data');

	$results = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}usermeta WHERE `meta_key`='user_pagesub_data' AND `user_id`='".$uid."' ORDER BY `umeta_id` ASC ", OBJECT );
		
	wp_enqueue_style( 'ad-bootstrap-style' );
	wp_enqueue_script('ad-bootstrap.min');

	
		
	$ic = 1; $art = 1; $ad = 1;  $page = 1; 

	foreach($results as $resdataarr){	
	    
        /*$count = count($usersubdataarr1);
		$num = $count-1;*/
		$umeta_id 		= $resdataarr->umeta_id;
		$userdataarr1 	= $resdataarr->meta_value;
		$userdataarr = maybe_unserialize($userdataarr1);	
		
		/* For User Image With Caption */
		$item_name = $userdataarr['item_name'];
		//$sel_value = wpspw_pro_get_option2($imageid);
			
		if($item_name == 'Image With caption'){

			$imagewithcaptionarr[] =  $userdataarr['sub_imgdata'];
			$imagewithcaptionarr['uid'][] =  $uid;
			$imagewithcaptionarr['umeta_id'][] =  $umeta_id;
			
		}		
		/* Articles */		
		if($item_name == 'article'){

			$articlearr[] = $userdataarr['sub_imgdata'];
			$articlearr['uid'][] =  $uid;
			$articlearr['umeta_id'][] =  $umeta_id;

		}			
		/* advertisement */
		if($item_name == 'advertisement'){

			$advarr[] = $userdataarr['sub_imgdata'];
			$advarr['uid'][] =  $uid;
			$advarr['umeta_id'][] =  $umeta_id;

		}
		/* page */
		if($item_name == 'page'){

			$pagearr[] = $userdataarr['sub_imgdata'];
			$pagearr['uid'][] =  $uid;				
			$pagearr['umeta_id'][] =  $umeta_id;	
			
		}

	} /* end foreach*/

} /* end foreach user loop*/

if(!empty($imagewithcaptionarr)){
	?>
	<div class="sub_block"> 
		<!-- <div> <h3> Image With caption Submission </h3></div> -->
		<?php $ic= 0;
		foreach($imagewithcaptionarr as $ickey => $icval){  
			//if($ic == 0){ echo '<div>'; }
				
				//foreach($icval as $key => $val){
			if($icval['imageid'] != ''){	
				$imageid = $icval['imageid'];
				$sel_value = wpspw_pro_get_option2($imageid);
				
				if($imageid == $sel_value) {
				    
				   
				    $ic_umeta_id = $imagewithcaptionarr['umeta_id'][$ickey];

					$sel_value2 = wpspw_pro_get_option2('imgcap_'.$ic_umeta_id);

					$sub_cap = ($sel_value2) ? $sel_value2 : $icval['sub_cap'];
					
    				$image_src = wp_get_attachment_image_src($imageid, 'full');
    				$image_src = $image_src[0];
    				?>
    				<div style="margin-right: 38px;">
    				<img src="<?php echo $image_src; ?>" class="myImg" style="width: 142px; height:auto;"><br> <span class="user_cap"><?php echo $sub_cap; ?></span>
    				</div>		
    			<?php
				}
			
			++$ic;
			if($ic%4 == 0){$ic = 0;}
			//if($ic == 0){ echo '</div>'; }	
			}
		}
		?>
	</div>
	<?php 	
}

if(!empty($articlearr)){
	
	?>
	<div class="sub_block"> 
		<!-- <div> <h3>Article Submission </h3></div> -->
		<?php $ar= 0;
		foreach($articlearr as $arkey => $arval){ 

			if($arval['imageid'] != ''){
			//if($ar == 0){ echo '<div>'; } ?>
			<div style="float: left; margin-right: 38px;"> 
			<?php

				$imageid = $arval['imageid'];
				$sel_value = wpspw_pro_get_option2($imageid);
				if($imageid == $sel_value) {
				    $image_src = wp_get_attachment_image_src($imageid , 'full');
    				$image_src = $image_src[0];
    				?>
    				<img src="<?php echo $image_src; ?>" class="myImg" style="width: 142px; height:auto;">
    				<?php
				}
					
				++$ar;
				if($ar%4 == 0){$ar = 0;}
				//if($ar == 0){ echo '</div>'; }	
			?>
			</div> 
			<?php	
			}		
		}
		?>
	</div>
	<?php 	
}

if(!empty($advarr)){ /* Advertisement */
	?>
	<div class="sub_block"> 
		<!-- <div> <h3>Advertisement Submission </h3></div> -->
		<?php 
		foreach($advarr as $adkey => $adval){ ?>
			<div> 
			<?php

				foreach($adval as $key => $val){
					if(is_int($val['imageid'])){
						$imageid = $val['imageid'];
						$sel_value = wpspw_pro_get_option2($imageid);
					    if($imageid == $sel_value) {
					       
					       	$image_src = wp_get_attachment_image_src($imageid , 'full');
	    					$image_src = $image_src[0];
	    					?>
	    					<img src="<?php echo $image_src; ?>" class="myImg" style="width: 142px; height:auto;">
	    					<?php	 
					    }
					}
				} 
			?>
			</div> 
			<?php			
		}
		?>
	</div>
	<?php 	
}

if(!empty($pagearr)){
	
	?>
	<div class="sub_block"> 
		<!-- <div> <h3>Page Submission </h3></div> -->
		<?php 
		foreach($pagearr as $pagekey => $pageval){  ?>
			 <div class="page_parent">  
			<?php
				 $pa = 0;
				foreach($pageval as $key => $val){  

					if(is_int($val['imageid'])){
					//if($pa == 0){ echo '<div class="df">'; }

						$imageid = $val['imageid'];
						$sel_value = wpspw_pro_get_option2($imageid);
					    if($imageid == $sel_value) {
					        $imagecaption = $val['caption'];

							$ic_umeta_id2 = $pagearr['umeta_id'][$key];

							$sel_value2 = wpspw_pro_get_option2('imgcap_'.$ic_umeta_id2);

							$sub_cap = ($sel_value2) ? $sel_value2 : $imagecaption;

	    					$image_src = wp_get_attachment_image_src($imageid , 'full');
	    					$image_src = $image_src[0];
	    					?>
	    					<div style="margin-right: 38px;">
	    					<img src="<?php echo $image_src; ?>" class="myImg" style="width: 142px; height:auto;"> <br> <span class="user_cap"><?php echo $sub_cap; ?></span>
	    					</div>
	    					<?php
					    }
				    }
						
				} 						
			?>
			 </div> 
			<?php			
		}
		?>
	</div>
	<?php 	
}
?>

<script  type="text/javascript">

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function() { 
  modal.style.display = "none";
}

</script>

	<?php
	wp_enqueue_script('ad-bootstrap.min');	
	$content .= ob_get_clean();
    return $content;

    exit();

}
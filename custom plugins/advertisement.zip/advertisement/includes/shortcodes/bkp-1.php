<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

add_shortcode('advertise_userform', 'add_userform_fun');

function add_userform_fun($atts, $content = null){
	
	ob_start();
	global $wp, $post, $wpdb;
	$user_id = get_current_user_id();	
	$disp_cls = 'none';
	$item_name = '';	

	//$userdataarr1 = get_user_meta($user_id, 'user_pagesub_data');
	$results = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}usermeta WHERE `meta_key`='user_pagesub_data' AND `user_id`='".$user_id."' ORDER BY `umeta_id` DESC LIMIT 1", OBJECT );
	
	$umeta_id = $results[0]->umeta_id;
	$userdataarr1 = $results[0]->meta_value;
    var_dump($userdataarr1);

	wp_enqueue_style( 'ad-bootstrap-style' );
	wp_enqueue_script('ad-bootstrap.min');	
	wp_enqueue_script('wpspw-pro-public-script');	

	$count = count($userdataarr1);
	$num = $count-1;
	
	$userdataarr = maybe_unserialize($userdataarr1);	

	if(!empty($userdataarr) ){
		$item_name = $userdataarr['item_name'];  
		$sub_imgdata = $userdataarr['sub_imgdata']; 
		if( $sub_imgdata == '' || empty($sub_imgdata) ){
			$disp_cls = 'block';
		}
	}
	
	if($user_id){ /* If Userloggedin then only form should display */ 

		if(isset($_POST['but_submit'])){
			
			$sub_type 	= $_POST['sub_type'];
			$metaval	= array();
			$subimagedata	= array();

			if($sub_type == '1'){ /*Image Caption */

				foreach($_FILES as $filekey => $fileval){
					if( $fileval['name'] != ''){
						
						require( get_template_directory() . '/../../../wp-load.php' );

					    $wordpress_upload_dir = wp_upload_dir();

					    $sub_cap = $_POST[$filekey.'_cap'];	
						
						$profilepicture = $fileval;
						$new_file_path = $wordpress_upload_dir['path'] . '/' . $profilepicture['name'];
						$new_file_mime = mime_content_type( $profilepicture['tmp_name'] );

						if( empty( $profilepicture ) )
						die( 'File is not selected.' );
						
						if( $profilepicture['error'] )
						die( $profilepicture['error'] );
						
						if( $profilepicture['size'] > wp_max_upload_size() )
						die( 'It is too large than expected.' );

						if( !in_array( $new_file_mime, get_allowed_mime_types() ) )
						die( 'WordPress doesn\'t allow this type of uploads.' );

						while( file_exists( $new_file_path ) ) {
							$i++;
							$new_file_path = $wordpress_upload_dir['path'] . '/' . $i . '_' . $profilepicture['name'];
						}

						// looks like everything is OK
						if( move_uploaded_file( $profilepicture['tmp_name'], $new_file_path ) ) {
						 
						 
							$upload_id = wp_insert_attachment( array(
								'guid'           => $new_file_path, 
								'post_mime_type' => $new_file_mime,
								'post_title'     => preg_replace( '/\.[^.]+$/', '', $profilepicture['name'] ),
								'post_content'   => '',
								'post_status'    => 'inherit'
							), $new_file_path );
						 
							// wp_generate_attachment_metadata() won't work if you do not include this file
							require_once( ABSPATH . 'wp-admin/includes/image.php' );
						 
							// Generate and save the attachment metas into the database
							wp_update_attachment_metadata( $upload_id, wp_generate_attachment_metadata( $upload_id, $new_file_path ) );

							$subimagedata[] = array( 'keyname' => $filekey,
													 'imageid' => $upload_id,
													 'sub_cap' => $sub_cap,													
													);
							
							// Show the uploaded file in browser
							//wp_redirect( $wordpress_upload_dir['url'] . '/' . basename( $new_file_path ) );
						 
						} 

				  	} /* end foreach */
				  	var_dump($subimagedata);
				  	
				  			  	
					//update_user_meta($user_id, 'user_pagesub_data', $metaval[0]);	
				}
				$metaval[] = array( 
				  						'item_name' 	=> $item_name,
				  						'sub_imgdata' => $subimagedata,				  						
				  						'sub_type' => $sub_type,
				  		 			);

				//var_dump($metaval);		
			}

			if($sub_type == '2'){  /* Article */

				require( get_template_directory() . '/../../../wp-load.php' );

			    $wordpress_upload_dir = wp_upload_dir();	
				$profilepicture = $_FILES['sub_article'];
				$new_file_path = $wordpress_upload_dir['path'] . '/' . $profilepicture['name'];
				$new_file_mime = mime_content_type( $profilepicture['tmp_name'] );

				if( empty( $profilepicture ) )
				die( 'File is not selected.' );
				
				if( $profilepicture['error'] )
				die( $profilepicture['error'] );
				
				if( $profilepicture['size'] > wp_max_upload_size() )
				die( 'It is too large than expected.' );

				if( !in_array( $new_file_mime, get_allowed_mime_types() ) )
				die( 'WordPress doesn\'t allow this type of uploads.' );

				while( file_exists( $new_file_path ) ) {
					$i++;
					$new_file_path = $wordpress_upload_dir['path'] . '/' . $i . '_' . $profilepicture['name'];
				}

				// looks like everything is OK
				if( move_uploaded_file( $profilepicture['tmp_name'], $new_file_path ) ) {				 
				 
					$upload_id = wp_insert_attachment( array(
						'guid'           => $new_file_path, 
						'post_mime_type' => $new_file_mime,
						'post_title'     => preg_replace( '/\.[^.]+$/', '', $profilepicture['name'] ),
						'post_content'   => '',
						'post_status'    => 'inherit'
					), $new_file_path );
				 
					// wp_generate_attachment_metadata() won't work if you do not include this file
					require_once( ABSPATH . 'wp-admin/includes/image.php' );
				 
					// Generate and save the attachment metas into the database
					wp_update_attachment_metadata( $upload_id, wp_generate_attachment_metadata( $upload_id, $new_file_path ) );

					$subimagedata[] = array(	'keyname' => 'sub_article',
												'imageid' => $upload_id,											
											);
									 
					// Show the uploaded file in browser
					wp_redirect( $wordpress_upload_dir['url'] . '/' . basename( $new_file_path ) );
				} 

		  	

		  	$metaval[] = array( 'item_name' 	=> $item_name,
		  						'sub_imgdata' => $subimagedata,		  						
		  						'sub_type' 	=> $sub_type,
		  		 			);
		  		
			}
			if($sub_type == '3'){ 
				
				foreach($_FILES as $filekey => $fileval){

					if($fileval['name'] != ''){

						require( get_template_directory() . '/../../../wp-load.php' );

					    $wordpress_upload_dir = wp_upload_dir();

					    $sub_cap = $_POST[$filekey.'_cap'];	
						
						$profilepicture = $fileval;
						$new_file_path = $wordpress_upload_dir['path'] . '/' . $profilepicture['name'];
						$new_file_mime = mime_content_type( $profilepicture['tmp_name'] );

						if( empty( $profilepicture ) )
						die( 'File is not selected.' );
						
						if( $profilepicture['error'] )
						die( $profilepicture['error'] );
						
						if( $profilepicture['size'] > wp_max_upload_size() )
						die( 'It is too large than expected.' );

						if( !in_array( $new_file_mime, get_allowed_mime_types() ) )
						die( 'WordPress doesn\'t allow this type of uploads.' );

						while( file_exists( $new_file_path ) ) {
							$i++;
							$new_file_path = $wordpress_upload_dir['path'] . '/' . $i . '_' . $profilepicture['name'];
						}

						// looks like everything is OK
						if( move_uploaded_file( $profilepicture['tmp_name'], $new_file_path ) ) {
						 
						 
							$upload_id = wp_insert_attachment( array(
								'guid'           => $new_file_path, 
								'post_mime_type' => $new_file_mime,
								'post_title'     => preg_replace( '/\.[^.]+$/', '', $profilepicture['name'] ),
								'post_content'   => '',
								'post_status'    => 'inherit'
							), $new_file_path );
						 
							// wp_generate_attachment_metadata() won't work if you do not include this file
							require_once( ABSPATH . 'wp-admin/includes/image.php' );
						 
							// Generate and save the attachment metas into the database
							wp_update_attachment_metadata( $upload_id, wp_generate_attachment_metadata( $upload_id, $new_file_path ) );

							$subimagedata[] = array(	'keyname' => $filekey,
														'imageid' => $upload_id,
														'sub_cap' => $sub_cap,													
														);						
						 	
						 	// Show the uploaded file in browser
							//wp_redirect( $wordpress_upload_dir['url'] . '/' . basename( $new_file_path ) );		
						} 				

				  	} /* end if */				  	
				}
				
				if($_FILES['sub_article']['name'] != ''){
				    
				         $wordpress_upload_dir = wp_upload_dir();	
        				$profilepicture = $_FILES['sub_article'];
        				$new_file_path = $wordpress_upload_dir['path'] . '/' . $profilepicture['name'];
        				$new_file_mime = mime_content_type( $profilepicture['tmp_name'] );

						if( empty( $profilepicture ) )
						die( 'File is not selected.' );
						
						if( $profilepicture['error'] )
						die( $profilepicture['error'] );
						
						if( $profilepicture['size'] > wp_max_upload_size() )
						die( 'It is too large than expected.' );

						if( !in_array( $new_file_mime, get_allowed_mime_types() ) )
						die( 'WordPress doesn\'t allow this type of uploads.' );

						while( file_exists( $new_file_path ) ) {
							$i++;
							$new_file_path = $wordpress_upload_dir['path'] . '/' . $i . '_' . $profilepicture['name'];
						}

						// looks like everything is OK
						if( move_uploaded_file( $profilepicture['tmp_name'], $new_file_path ) ) {
						 
						 
							$upload_id = wp_insert_attachment( array(
								'guid'           => $new_file_path, 
								'post_mime_type' => $new_file_mime,
								'post_title'     => preg_replace( '/\.[^.]+$/', '', $profilepicture['name'] ),
								'post_content'   => '',
								'post_status'    => 'inherit'
							), $new_file_path );
						 
							// wp_generate_attachment_metadata() won't work if you do not include this file
							require_once( ABSPATH . 'wp-admin/includes/image.php' );
						 
							// Generate and save the attachment metas into the database
							wp_update_attachment_metadata( $upload_id, wp_generate_attachment_metadata( $upload_id, $new_file_path ) );

							$subimagedata[] = array(	'keyname' => $filekey,
														'imageid' => $upload_id,
														'sub_cap' => $sub_cap,													
														);						
						 	
						 	// Show the uploaded file in browser
							//wp_redirect( $wordpress_upload_dir['url'] . '/' . basename( $new_file_path ) );		
						} 
				}
					
				$metaval[] = array( 	'item_name' 	=> $item_name,
										'sub_imgdata' 	=> $subimagedata,
				  						'sub_type' 		=> $sub_type,
				  		 			);
				  		 									
			} 
					    
			$table = '{$wpdb->prefix}usermeta';
			$wpdb->delete( $table, array( 'umeta_id' => $umeta_id ) );						
     		add_user_meta($user_id, 'user_pagesub_data',  $metaval[0]);
			?>
			<script type="text/javascript">

				jQuery(document).ready(function(){
					
                	jQuery('#sub_type').hide();
                	jQuery('#page_area').show();

				});

			</script>
			<?php
 
		} ?>


		<div class="user-form">
			<?php 
			$usredata = get_user_meta($user_id, 'user_pagesub');
			
			//if($usredata == '' || empty($usredata)){  $show = 'none';					
			?>
				<div class="row">
					<div class="col-md-12 col-sm-12">
						<div class="form-title">Advertise Magazine Form</div>
													
								<div class="row">
									<div id="page_area">
										<div class="col-md-4">
											<label style="padding: 0px 0px 8px 0px;" for="ad_page_size">Please Choose Page Type</label>
										</div>
										<div class="col-md-12 form-group">
											<select name="ad_page_size" id="ad_page_size" class="form-control custom-select">
												<option value="">--- SELECT PAGE TYPE ---</option>
												<optgroup label="Article Page Options">
													<option   value="<?php echo wpspw_pro_get_option('full_page_price_1'); ?>">Page Size: 8.5*11 | Price: $<?php echo wpspw_pro_get_option('full_page_price_1'); ?> </option>
													<option  value="<?php echo wpspw_pro_get_option('full_page_price_2'); ?>">Page Size: 6*9 | Price: $<?php echo wpspw_pro_get_option('full_page_price_2'); ?> </option>
												</optgroup>
												<optgroup label="Half Page Ad Options">
													<option value="<?php echo wpspw_pro_get_option('full_page_price_1')/2; ?>">Page Size: 4.25*5.5 | Price: $<?php echo wpspw_pro_get_option('full_page_price_1')/2; ?> </option>
													<option  value="<?php echo wpspw_pro_get_option('full_page_price_2')/2; ?>">Page Size: 3*4.5 | Price: $<?php echo wpspw_pro_get_option('full_page_price_2')/2; ?> </option>
												</optgroup>
												<optgroup label="Quarter Page Ad Options">
													<option  value="<?php echo wpspw_pro_get_option('quarter_page_price_1'); ?>">Page Size: 1.5*2.25 | Price: $<?php echo wpspw_pro_get_option('quarter_page_price_1'); ?> </option>
													<option  value="<?php echo wpspw_pro_get_option('quarter_page_price_2'); ?>">Page Size: 2.125*2.75 | Price: $<?php echo wpspw_pro_get_option('quarter_page_price_2'); ?> </option>
												</optgroup>
											</select>
											<div id="page_err" style="color:red; display:none">This field is required.</div>
										</div>
									</div>	
								</div>
							
							<div class="paypal-pay-btn">
								<?php echo do_shortcode("[wpecpp name='' price='0']"); ?>
							</div>
						</div>
				</div>
			<?php //} ?> <!-- end if userdata -->
					
					
			<!-- Submission Form -->
			<form method="post" name="myform1" clas="form-submission" style="display: <?php echo $disp_cls; ?>;" enctype="multipart/form-data">
				<div class="row">
					<div class="col-md-12" id="upload_images" >					
						<div class="fullpage_data input-group">
							
							<?php
							
							$current_url = home_url( $wp->request );

							$userpagesubarr = get_user_meta( $user_id , 'user_pagesub');
							
							foreach($userpagesubarr as $k=> $v){
								$userpagesub = $v;
							}
							if($userpagesub == ''){$userpagesub ='';}
							?>

							<input type="hidden" name="pageurl" value="<?php echo $current_url; ?>" id="current_url">
							<input type="hidden" name="usersubpagesize" value="<?php echo rtrim($item_name," "); ?>" id="usersubpagesize">
							

							<div class="article-title">You can upload fullpage Articles OR Images with Caption here</div>
							<div class="row">	
								<div class="col-md-12">
									<select name="sub_type" id="sub_type" class="form-control sub_type">
										<option> -- SELECT SUBMISSION TYPE -- </option>									
										<option value="1">Image With Caption</option>									
										<option value="2">Article</option>									
										<option value="3">Page Submission</option>									
									</select>	
								</div>

								<div id="submission1" style="display: none;"> <!-- Image With Caption -->
									
									<div class="row">

									<div id="usersub_img1">
										<div class="col-md-4"><label>Upload First Image</label></div>
										<div class="col-md-4 form-group"><input class="custom-file-input" type="file" id="sub_img1" name="sub_img1" size="25" /></div>	
										<div class="col-md-4 form-group"><input class="form-control" placeholder="Image Caption" type="text" id="sub_img1_cap" name="sub_img1_cap" size="25" /></div>
									</div>
									
									<div id="usersub_img2">
										<div class="col-md-4"><label>Upload Second Image</label></div>
										<div class="col-md-4 form-group"><input class="" type="file" id="sub_img2" name="sub_img2" size="25" /></div>
										<div class="col-md-4 form-group"><input class="form-control" placeholder="Image Caption" type="text" id="sub_img2_cap" name="sub_img2_cap" size="25" /></div>
									</div>

									<div id="usersub_img3">
										<div class="col-md-4"><label>Upload Third Image</label></div>
										<div class="col-md-4 form-group"><input class="" type="file" id="sub_img3" name="sub_img3" size="25" /></div>
										<div class="col-md-4 form-group"><input class="form-control" placeholder="Image Caption" type="text" id="sub_img3_cap" name="sub_img3_cap" size="25" /></div>
									</div>

									</div>								

								</div> <!-- end Image With Caption -->

								<div id="submission2" style="display: none;"> <!--  Article -->
									<div class="col-md-4"><label>Upload Article Image</label></div>
									<div class="col-md-4 form-group"><input class="" type="file" id="sub_article" name="sub_article" size="25" /></div>
								</div>	
							</div> <!-- end Article -->
						</div>
					</div>
				</div>				
				<input type="submit" style="display: none;"  id="data_sub_btn" class="form-control" name="but_submit" value="Submit" />
			</form>
			
		</div>

		<style type="text/css">
			.user-form {    min-width: 1290px !important;
						    align: center;
						    margin: auto;
						    padding: 40px 42px;
						    margin-top: 20px;
						    border: 1px solid lightgray;
						    /*background: lightseagreen;*/
						    color: black;}  

						    .user-form .form-title {margin: 20px 4px;
						    text-align: center;
						    padding: 6px 0px;
						        font-size: 20px;
						    font-weight: 600;
						    color: black;}

						    .fullpage_data{margin: 25px 0px 14px 0px;}
						    .article-title{font-size: 14px;
						    font-weight: 600;
						    text-align: center;
						    margin-bottom: 42px;}
		</style>

	<?php 
	} /* end if user is loggedin */
		
	$content .= ob_get_clean();
    return $content;

    exit();
} 
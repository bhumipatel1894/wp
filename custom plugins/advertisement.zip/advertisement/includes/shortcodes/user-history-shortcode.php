<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

add_shortcode('user_history', 'userhistory_fun');

function userhistory_fun($atts, $content = null){
	ob_start();
	//wp_enqueue_style( 'ad-bootstrap-style' );
	wp_enqueue_script('wpspw-pro-public-script');
	
	?>

	<style>

.myImg {
  border-radius: 5px;
  cursor: pointer;
  transition: 0.3s;
}

.myImg:hover {opacity: 0.7;}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.9); /* Black w/ opacity */
}

/* Modal Content (image) */
.modal-content {
  margin: auto;
  display: block;
  width: 80%;
  max-width: 700px;
}

/* Caption of Modal Image */
#caption {
  margin: auto;
  display: block;
  width: 80%;
  max-width: 700px;
  text-align: center;
  color: #ccc;
  padding: 10px 0;
  height: 150px;
}

/* Add Animation */
.modal-content, #caption {  
  -webkit-animation-name: zoom;
  -webkit-animation-duration: 0.6s;
  animation-name: zoom;
  animation-duration: 0.6s;
}

@-webkit-keyframes zoom {
  from {-webkit-transform:scale(0)} 
  to {-webkit-transform:scale(1)}
}

@keyframes zoom {
  from {transform:scale(0)} 
  to {transform:scale(1)}
}

/* The Close Button */
.admclose {
  position: absolute;
  top: 15px;
  right: 35px;
  color: #f1f1f1;
  font-size: 40px;
  font-weight: bold;
  transition: 0.3s;
}

.user_cap{
	display: block;
    padding: 8px 2px 12px 2px;
    max-width: 142px;
}
.page_parent{ clear: both; }

/* 100% Image Width on Smaller Screens */
@media only screen and (max-width: 700px){
  .modal-content {
    width: 100%;
  }
}
</style>

	<!-- <img id="myImg" src="http://localhost/practice/wp-content/uploads/2020/07/11_dress.jpg" alt="Snow" style="width:100%;max-width:300px"> -->

<!-- The Modal -->
<div id="admyModal" class="modal">
  <span class="admclose">&times;</span>
  <img class="modal-content" id="img01">
  <div id="caption"></div>
</div>
	
<?php
	$cuuuser_id = get_current_user_id();	
	global $wp, $post, $wpdb;

	$imagewithcaptionarr = array();
	$articlearr = array();
	$advarr = array();
	$pagearr = array();
$users = get_users( array( 'fields' => array( 'ID','display_name' ) ) );
foreach($users as $user){

	$uid =  $user->ID; 

	if($cuuuser_id == $uid){

		$display_name =  $user->display_name;  									
		//$usersubdataarr2 = get_user_meta($uid, 'user_pagesub_data');

		$results = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}usermeta WHERE `meta_key`='user_pagesub_data' AND `user_id`='".$uid."' ORDER BY `umeta_id` ASC ", OBJECT );
		
		wp_enqueue_style( 'ad-bootstrap-style' );
		wp_enqueue_script('ad-bootstrap.min');

		foreach($results as $resdataarr){
		
			$umeta_id 		= $resdataarr->umeta_id;
			$curr_uid 		= $resdataarr->curr_uid;
			$userdataarr1 	= $resdataarr->meta_value;

			//$userdataarr1 = maybe_unserialize($userdataarr1);	
			
		
	    
        /*$count = count($usersubdataarr1);
		$num = $count-1;*/
		$userdataarr = maybe_unserialize($userdataarr1);	
		
		/* For User Image With Caption */
		$item_name = $userdataarr['item_name'];
		
		if($item_name == 'Image With caption'){

			$imagewithcaptionarr[] =  $userdataarr['sub_imgdata'];
			$imagewithcaptionarr['uid'][] =  $uid;
			$imagewithcaptionarr['umeta_id'][] =  $umeta_id;

		}		
		/* Articles */		
		if($item_name == 'article'){

			$articlearr[] = $userdataarr['sub_imgdata'];
			$articlearr['uid'][] =  $uid;
			$articlearr['umeta_id'][] =  $umeta_id;

		}			
		/* advertisement */
		if($item_name == 'advertisement'){

			$advarr[] = $userdataarr['sub_imgdata'];  
			$advarrsize['item_name_size'][] = $userdataarr['item_name_size'];
			$advarr['uid'][] =  $uid;
			$advarr['umeta_id'][] =  $umeta_id;
		}
		/* page */
		if($item_name == 'page'){

			$pagearr[] = $userdataarr['sub_imgdata']; 
			$pagearrsize['item_name_size'][] = $userdataarr['item_name_size']; 	
			$pagearr['uid'][] =  $uid;				
			$pagearr['umeta_id'][] =  $umeta_id;				
		}

	} /* end foreach*/
	
	} 


} /* end foreach user loop*/

if(!empty($imagewithcaptionarr)){	
	?>
	<div class="sub_block"> 
		<!-- <div> <h3> Image With caption Submission </h3></div> -->
		<table style="width: 100%;">
			<tr>
				<th style="width: 30%; ">Photo</th>
				<th style="width: 30%; ">Caption</th>
				<th style="width: 30%; ">Status</th>
			</tr>
		
		<?php $ic= 0;
		foreach($imagewithcaptionarr as $ickey => $icval){  
			//if($ic == 0){ echo '<div>'; }
				
				//foreach($icval as $key => $val){
			if($icval['imageid'] != ''){
					
				$imageid = $icval['imageid'];
				$ic_umeta_id = $imagewithcaptionarr['umeta_id'][$ickey];
				$sel_value2 = wpspw_pro_get_option2('imgcap_'.$ic_umeta_id);

				$sub_cap = ($sel_value2) ? $sel_value2 : $icval['sub_cap'];

				$image_src = wp_get_attachment_image_src($imageid , 'full');
				$image_src = $image_src[0];
				$sel_value = wpspw_pro_get_option2($imageid);
				?>
				<!-- <div style="float: left; margin-right: 38px;"> -->
				<tr>
					<th style="width: 30%; "><img src="<?php echo $image_src; ?>" class="myImg" style="width: 142px; height:auto;"></th>
					<th style="width: 30%; "><?php echo $sub_cap; ?></th>
					<th style="width: 30%; "> <?php if($imageid == $sel_value){echo 'Approved'; } else{ echo 'Pending'; } ?> </th>
				</tr>
				
				<!-- </div>	 -->	
			<?php
					
			++$ic;
			if($ic%4 == 0){$ic = 0;}
			//if($ic == 0){ echo '</div>'; }
			}	
		}
		?>
	</table>
	</div>
	<?php 	
}

if(!empty($articlearr)){
	
	?>
	<div class="sub_block"> 
		<!-- <div> <h3>Article Submission </h3></div> -->
		<table style="width: 100%;">
			<tr>
				<th style="width: 30%; ">Photo</th>
				<!-- <th style="width: 30%; ">Size</th> -->
				<th style="width: 30%; ">Status</th>
			</tr>
		<?php $ar= 0;
		foreach($articlearr as $arkey => $arval){ 
			if($arval['imageid'] != ''){
			$imageid = $arval['imageid'];
			$pagesize = $arval['pagesize'];
			$image_src = wp_get_attachment_image_src($imageid , 'full');
			$image_src = $image_src[0];
			$sel_value = wpspw_pro_get_option2($imageid);
			?>
			<tr>
				<th><img src="<?php echo $image_src; ?>" class="myImg" style="width: 142px; height:auto;"></th>
				<!-- <th><?php //echo $pagesize; ?></th> -->
				<th><?php if($imageid == $sel_value){echo 'Approved'; } else{ echo 'Pending'; } ?></th>
			</tr>
			
			<?php		
			++$ar;		
			}			
		}
		?>
		</table>
	</div>
	<?php 	
}

if(!empty($advarr)){ /* Advertisement */ 
	?>
	<div class="sub_block"> 
		<!-- <div> <h3>Advertisement Submission </h3></div> -->
		<table style="width: 100%;">
			<tr>
				<th style="width: 30%; ">Photo</th>
				<!-- <th style="width: 30%; ">Size</th> -->
				<th style="width: 30%; ">Status</th>
			</tr>
		<?php 
		foreach($advarr as $adkey => $adval){ 

			foreach($adval as $key => $val){
				if(is_int($val['imageid'])){

				$imageid = $val['imageid']; 
				$pagesize = $advarrsize['item_name_size'][$adkey];
				$image_src = wp_get_attachment_image_src($imageid , 'full');
				$image_src = $image_src[0];
				$sel_value = wpspw_pro_get_option2($imageid);
				?>
				<tr>
					<th><img src="<?php echo $image_src; ?>" class="myImg" style="width: 142px; height:auto;"></th>
					<!-- <th><?php //echo $pagesize; ?></th> -->
					<th><?php if($imageid == $sel_value){echo 'Approved'; } else{ echo 'Pending'; } ?></th>
				</tr>
				
				<?php	
				}	
			} 
					
		}
		?>
		</table>
	</div>
	<?php 	
}

if(!empty($pagearr)){
	
	?>
	<div class="sub_block"> 
		<!-- <div> <h3>Page Submission </h3></div> -->
		<table style="width: 100%;">
			<tr>
				<th style="width: 25%; ">Photo</th>
				<th style="width: 25%; ">Caption</th>
				<!-- <th style="width: 25%; ">Size</th> -->
				<th style="width: 25%; ">Status</th>
			</tr>
			<?php 
			foreach($pagearr as $pagekey => $pageval){  ?>
				
				<?php
				$pa = 0;
				foreach($pageval as $key => $val){  

					if(is_int($val['imageid'])){
					
					$imageid = $val['imageid'];
					$item_name_size = $val['item_name_size'];
					$imagecaption = $val['caption'];

						$ic_umeta_id2 = $pagearr['umeta_id'][$key];

						$sel_value2 = wpspw_pro_get_option2('imgcap_'.$ic_umeta_id2);

						$sub_cap = ($sel_value2) ? $sel_value2 : $imagecaption;
					$image_src = wp_get_attachment_image_src($imageid , 'full');
					$image_src = $image_src[0];
					$pagesize = $pagearrsize['item_name_size'][$pagekey];
					$sel_value = wpspw_pro_get_option2($imageid);
					?>
					<tr>
						<th><img src="<?php echo $image_src; ?>" class="myImg" style="width: 142px; height:auto;"></th>
						<th><?php echo $sub_cap; ?></th>
						<!-- <th><?php //echo $pagesize; ?></th> -->
						<th><?php if($imageid == $sel_value){echo 'Approved'; } else{ echo 'Pending'; } ?></th>
					</tr>					 					
					<?php	
					}						
				} 					
			}
		?>
		</table>
	</div>
	<?php 	
}

?>
<script  type="text/javascript">

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function() { 
  modal.style.display = "none";
}

</script>

<?php
wp_enqueue_script('ad-bootstrap.min');	
$content .= ob_get_clean();
return $content;

exit();

}
<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

add_shortcode('userloginform', 'userlogin_fun');

function userlogin_fun($atts, $content = null){
	ob_start();
	wp_enqueue_style( 'ad-bootstrap-style' );
	?>
	<div>
		
    <style>
	    div {
	        margin-bottom:2px;
	    }     
	    input{
	        margin-bottom:4px;
	    }
    </style>
   <?php 

	wp_enqueue_script('wpspw-pro-public-script');	
	
	if(isset($_POST['aduserreg'])){ 
		
		global $reg_errors;
		$reg_errors = new WP_Error;
		
		$username = $_POST['username'];
		$password = $_POST['password'];
		$email = $_POST['email'];
		$fname = $_POST['fname'];
		$lname = $_POST['lname'];

		if ( ( $username == '' ) || ( $password == '' ) || ( $email == '' ) ) {
		    $reg_errors->add('field', 'Required form field is missing');
		}

		//  We also check to make sure the number of username characters is not less than 4.
		if ( 4 > strlen( $username ) ) {
		    $reg_errors->add( 'username_length', 'Username too short. At least 4 characters is required' );
		}

		//Check if the username is already registered.
		if ( username_exists( $username ) )
    		$reg_errors->add('user_name', 'Sorry, that username already exists!');

    	//Employ the services of WordPress validate_username function to make sure the username is valid
    	if ( ! validate_username( $username ) ) {
		    $reg_errors->add( 'username_invalid', 'Sorry, the username you entered is not valid' );
		}

		//Ensure the password entered by users is not less than 5 characters.
		if ( 5 > strlen( $password ) ) {
	        $reg_errors->add( 'password', 'Password length must be greater than 5' );
	    }

	    //Check if the email is a valid email
	    if ( !is_email( $email ) ) {
		    $reg_errors->add( 'email_invalid', 'Email is not valid' );
		}

		//Check if the email is already registered.
		if ( email_exists( $email ) ) {
		    $reg_errors->add( 'email', 'Email Already in use' );
		}

		// Loop 
		if ( is_wp_error( $reg_errors ) ) { 
		    foreach ( $reg_errors->get_error_messages() as $error ) {
		     
		        echo '<div>';
		        echo '<strong>ERROR</strong>:';
		        echo $error . '<br/>';
		        echo '</div>';		         
		    }		 
		}

		if ( 1 > count( $reg_errors->get_error_messages() ) ) {
	        $userdata = array(
	        'user_login'    =>   $username,
	        'user_email'    =>   $email,
	        'user_pass'     =>   $password,
	        'user_url'      =>   $website,
	        'first_name'    =>   $first_name,
	        'last_name'     =>   $last_name,
	        'nickname'      =>   $nickname,
	        'description'   =>   $bio,
	        );
	        $user = wp_insert_user( $userdata );
	        echo 'Registration complete. Goto <button class="btn bg-small" id="adlogin">Sign In</button>  '; 
	    }	


	}
   ?>
  
 
    <form method="post" id="userregiform" name="userregiform" clas="formregistration form-group">

    	<h2>User Registration Form</h2>	
    <div>
	    <label for="username">Username <strong>*</strong></label>
	    <input type="text" name="username" class="form-control" value="">
    </div>
     
    <div>
	    <label for="password">Password <strong>*</strong></label>
	    <input type="password" name="password" class="form-control" value="">
    </div>
     
    <div>
	    <label for="email">Email <strong>*</strong></label>
	    <input type="text" name="email" class="form-control" value="">
    </div>
     
    <div>
	    <label for="firstname">First Name</label>
	    <input type="text" name="fname" class="form-control" value="">
    </div>
     
    <div>
	    <label for="website">Last Name</label>
	    <input type="text" name="lname" class="form-control" value="">
    </div>
       
    	<input type="submit" name="aduserreg" value="Register"/>
    	<br>
    	<span>Already Registered ? </span> <button class="btn bg-small" id="adlogin">Sign In</button>
    </form>    
    
	</div>


	<form   name="loginform" id="loginform" action="<?php echo site_url( '/wp-login.php' ); ?>" method="post"   class="userloginform formsubmission" style="display: none;">

		<?php $redirect_to = 'https://travelingskateboarders.com/user-history/'; ?>
		<h2>User Login Form</h2>	
		<div class="row form-group">
			<div class="col-md-12">
				<input type="text" id="user_login" class="form-control" name="log" value="" placeholder="USER NAME">			
			</div>
			<div class="col-md-12">
				<input id="user_pass" type="password"  class="form-control" name="pwd" value="" placeholder="PASSWORD">
			</div>
			<div class="col-md-12">
				<input id="wp-submit" type="submit" class="form-control" name="wp-submit" value="Login" />
			</div>
			<p>Remember Me?  <input id="rememberme" type="checkbox" value="forever" name="rememberme"></p>
			<p><input  value="Login" name="wp-submit"></p>
			<input type="hidden" value="<?php echo esc_attr( $redirect_to ); ?>" name="redirect_to">
			<input type="hidden" value="1" name="testcookie">

			<span class="usererr" style="display: none;"></span>
		</div>

	</form>


<?php
	$content .= ob_get_clean();
    return $content;

    exit();
}
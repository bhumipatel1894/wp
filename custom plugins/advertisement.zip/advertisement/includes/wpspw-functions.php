<?php
/**
 * Plugin generic functions file
 *
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;
//echo __FILE__;
/**
 * Update default settings
 * 
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0.0
 */
function wpspw_pro_default_settings() {

	global $wpspw_pro_options, $wpspw_userentry_options;
	
	$wpspw_pro_options = array(
							'default_img'			=> '',
							'full_page_price_1' 			=> '',
							'full_page_price_2'		=> '',
							'quarter_page_price_1'	=> '',
							'quarter_page_price_2'		=> '',							
						);
	$wpspw_userentry_options = array();
	
	$default_options = apply_filters('wpspw_pro_options_default_values', $wpspw_pro_options );
	
	// Update default options
	update_option( 'wpspw_pro_options', $default_options );

	// Overwrite global variable when option is update
	$wpspw_pro_options = wpspw_pro_get_settings();
	$wpspw_userentry_options = wpspw_pro_get_settings2();
}

/**
 * Get Settings From Option Page
 * 
 * Handles to return all settings value
 * 
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0.0
*/
function wpspw_pro_get_settings() {

	$options = get_option('wpspw_pro_options');
	
	$settings = is_array($options) 	? $options : array();
	
	return $settings;
}
function wpspw_pro_get_settings2() {

	$options = get_option('wpspw_userentry_options');
	
	$settings = is_array($options) 	? $options : array();
	
	return $settings;
}


/**
 * Get an option
 * Looks to see if the specified setting exists, returns default if not
 * 
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0.0
 */
function wpspw_pro_get_option( $key = '', $default = false ) {
	global $wpspw_pro_options;

	$value = ! empty( $wpspw_pro_options[ $key ] ) ? $wpspw_pro_options[ $key ] : $default;
	$value = apply_filters( 'wpspw_pro_get_option', $value, $key, $default );
	return apply_filters( 'wpspw_pro_get_option_' . $key, $value, $key, $default );
}
function wpspw_pro_get_option2( $key = '', $default = false ) {
	global $wpspw_userentry_options;

	$value = ! empty( $wpspw_userentry_options[ $key ] ) ? $wpspw_userentry_options[ $key ] : $default;
	$value = apply_filters( 'wpspw_pro_get_option2', $value, $key, $default );
	return apply_filters( 'wpspw_pro_get_option2_' . $key, $value, $key, $default );
}


/**
 * Function to get limit word of post
 * 
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0.0
 */
function wpspw_pro_limit_words($string, $word_limit) {
	$words = explode(' ', $string, ($word_limit + 1));
	if(count($words) > $word_limit)
		array_pop($words);
	return implode(' ', $words);
}

/**
 * Escape Tags & Slashes
 *
 * Handles escapping the slashes and tags
 *
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0.0
 */
function wpspw_pro_esc_attr($data) {
	return esc_attr( stripslashes($data) );
}

/**
 * Strip Slashes From Array
 * If $flag is passed then it will allow HTML
 *
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0.0
 */
function wpspw_slashes_deep($data = array(), $flag = false){
	
	if($flag != true) {
		$data = wpspw_nohtml_kses($data);  // avoid html tag
	}

	$data = stripslashes_deep($data);
	return $data;
}

/**
 * Strip Html Tags 
 * 
 * It will sanitize text input fields. Strip html tags and escape characters)
 * 
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0.0
 */
function wpspw_nohtml_kses($data = array()){
	
	if ( is_array($data) ) {
		
		$data = array_map('wtwp_nohtml_kses', $data);
		
	} elseif ( is_string( $data ) ) {
		
		$data = wp_filter_nohtml_kses($data);
	}
	
	return $data;
}

/**
 * Function to unique number value
 * 
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0.0
 */
function wpspw_pro_get_unique() {
	static $unique = 0;
	$unique++;

	return $unique;
}
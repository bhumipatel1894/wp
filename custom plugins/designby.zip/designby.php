<?php
/**
 * Plugin Name: DesignBy
 * Plugin URI: https://www.designnbuy.com/
 * Description: Change WooCommerce product price after add to cart
 * Text Domain: designby
 * Domain Path: /languages/
 * Author: DesignBy | Contributor: Bhumi Patel
 * Author URI: https://www.designnbuy.com/
 * Contributors: Bhumi Patel
 * Version: 1.0
*/

// Exit if accessed directly
// abs pth is start ffrom folder path upto proj folder
if ( !defined( 'ABSPATH' ) ) exit;

if( !defined( 'WP_DB_DIR' ) ) {
    define( 'WP_DB_DIR', dirname( __FILE__ ) ); // Plugin dir
}
if( !defined( 'WP_DB_URL' ) ) {
    define( 'WP_DB_URL', plugin_dir_url( __FILE__ ) ); // Plugin url
}
/**
 * Activation Hook
 * 
 * Register plugin activation hook.
 * 
 * @package wp-postCounter
 * @since 1.0.0
 */
register_activation_hook( __FILE__, 'wp_DB_install' );

/**
 * Deactivation Hook
 * 
 * Register plugin deactivation hook.
 * 
 * @package wp-postCounter
 * @since 1.0.0
 */
register_deactivation_hook( __FILE__, 'wp_DB_uninstall');

/**
 * Plugin Activation Function
 * Does the initial setup, sets the default values for the plugin options
 * 
 * @package wp-postCounter
 * @since 1.0.0
 */
function wp_DB_install() {
      
}

/**
 * Plugin Deactivation Function
 * Delete  plugin options
 * 
 * @package wp-postCounter
 * @since 1.0.0
 */
function wp_DB_uninstall() {
    // Uninstall functionality
}

/**
 * Function to display admin notice of activated plugin.
 */
function wp_DB_admin_notice() {
    
    $dir = WP_DB_DIR . '/designby/designby.php';
    
    // If PRO plugin is active and free plugin exist
    if( is_plugin_active( 'designby/designby.php' ) && file_exists($dir)) {
        
        global $pagenow;
        
        if ( $pagenow == 'plugins.php' && current_user_can( 'install_plugins' ) ) {
            echo '<div id="message" class="updated notice is-dismissible"><p><strong>Thank you for activating DesignBy Plugin</strong>. </p></div>';
        }

    }
}

// Action to display notice
add_action( 'admin_notices', 'wp_DB_admin_notice');

/* Includes function file */
require_once( WP_DB_DIR . '/inc/db-functions.php' );

/* Includes Shortcode file */
require_once( WP_DB_DIR . '/inc/db-shortcodes.php' );
<?php
/**
 * Functions
 * 
 * Description: Woocommecr Product Price Change after add to cart
 * 
 * @package DesignBy
 * @since 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

add_action( 'woocommerce_before_calculate_totals', 'add_custom_price', 20, 1);

	function add_custom_price( $cart_obj ) {

		// This is necessary for WC 3.0+
		if ( is_admin() && ! defined( 'DOING_AJAX' ) )
			return;

		// Avoiding hook repetition (when using price calculations for example)
		if ( did_action( 'woocommerce_before_calculate_totals' ) >= 2 )
			return;

		// Loop through cart items
		foreach ( $cart_obj->get_cart() as $cart_item ) {
			$product_id = $cart_item['product_id'];
			$product_price = $cart_item['data']->price;			
			$dc_prodprice = $product_id+$product_price;
			$cart_item['data']->set_price($dc_prodprice);
		}
	}
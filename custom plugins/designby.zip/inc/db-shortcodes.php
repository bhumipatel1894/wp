<?php
/**
 *
 * Register plugin Shortcodes
 * 
 * @package DesignBy
 * @since 1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/* Pattern 1 Shortcode */
function wpdb_first_pattern_fun( $atts, $content = null ) {

	ob_start(); ?>
	<h3>Pattern 1</h3>
	<?php
	
	for($k = 5; $k >= 1; $k-- ){
		
		for($i = 5; $i >= $k; $i--){
			if($i % 2 == 0){
				echo '1';
			} else {
				echo '0';
			}

		}
		echo '<br>';
	}	

	$content .= ob_get_clean();
    return $content;
}

// 'wpdb_first_pattern' Shortcode
add_shortcode('wpdb_first_pattern', 'wpdb_first_pattern_fun');

/* Pattern 2 Shortcode 6*6 */
function wpdb_second_pattern_fun( $atts, $content = null ) {

	ob_start(); ?>
	<h3>Pattern 2</h3>
	<?php

	for($i=0; $i < 6; $i++ ){
		for($j=1; $j<7; $j++){
			if($j==1){
				echo ($j+$i).' ';
			}else{
				echo ($j+$i*$j).' ';
			}	
		}
		echo '<br>';		
	}

	$content .= ob_get_clean();
    return $content;
}

// 'wpdb_second_pattern' Shortcode
add_shortcode('wpdb_second_pattern', 'wpdb_second_pattern_fun');
jQuery( document ).ready(function($) {

	/* Initial set price for material */
	var sel1val = $('#sel1').val();
	var sel2val = $('#sel2').val();

	gettotalprice();
	setheaderimage();


	/* CODE FOR SELECTED MATERIAL*/
	$(".material-radio").each(function(){

		/* Kitchen */
		if($("#cocina_tiradores").val() == $(this).find("input[name='cocina_tiradores']").val()){
			$(this).addClass("current");
		}
		if($("#cocina_suelo_cocina").val() == $(this).find("input[name='cocina_suelo_cocina']").val()){
			$(this).addClass("current");
		}
		if($("#cocina_pintura").val() == $(this).find("input[name='cocina_pintura']").val()){
			$(this).addClass("current");
		}
		if($("#cocina_muebles_bajos").val() == $(this).find("input[name='cocina_muebles_bajos']").val()){
			$(this).addClass("current");
		}
		if($("#cocina_muebles_altos").val() == $(this).find("input[name='cocina_muebles_altos']").val()){
			$(this).addClass("current");
		}
		if($("#cocina_grifo").val() == $(this).find("input[name='cocina_grifo']").val()){
			$(this).addClass("current");
		}
		if($("#cocina_frontal").val() == $(this).find("input[name='cocina_frontal']").val()){
			$(this).addClass("current");
		}
		if($("#cocina_encimera").val() == $(this).find("input[name='cocina_encimera']").val()){
			$(this).addClass("current");
		}
		/* Bathroom */
		if($("#bano_suelo_bano").val() == $(this).find("input[name='bano_suelo_bano']").val()){
			$(this).addClass("current");
		}
		if($("#bano_mampara").val() == $(this).find("input[name='bano_mampara']").val()){
			$(this).addClass("current");
		}
		if($("#bano_luz_espejo").val() == $(this).find("input[name='bano_luz_espejo']").val()){
			$(this).addClass("current");
		}
		if($("#bano_lavamanos").val() == $(this).find("input[name='bano_lavamanos']").val()){
			$(this).addClass("current");
		}
		if($("#bano_grifo_lavamanos").val() == $(this).find("input[name='bano_grifo_lavamanos']").val()){
			$(this).addClass("current");
		}
		if($("#bano_grifo_ducha").val() == $(this).find("input[name='bano_grifo_ducha']").val()){
			$(this).addClass("current");
		}
		if($("#bano_espejo").val() == $(this).find("input[name='bano_espejo']").val()){
			$(this).addClass("current");
		}
		if($("#bano_ceramica_pared").val() == $(this).find("input[name='bano_ceramica_pared']").val()){
			$(this).addClass("current");
		}		
		 
	});

	$(".tab-content-inner span").each(function(){

	 	if($(this).attr("data-room")  == sel1val){
	 		$(this).show();
	 		$(this).addClass('currentprice');
	 		
	 	} else {
	 		$(this).hide();
	 		$(this).removeClass('currentprice');
	 	}	 

	 	if($(this).attr("data-room")  == sel2val){
	 		$(this).show();
	 		$(this).addClass('currentprice');

	 	} /*else {
	 		$(this).hide();
	 		$(this).removeClass('currentprice');
	 	}	*/
	 });


	
	
	/* On change room type "Kitchen" matrial price change*/
	$('#sel1').on('change', function() {
	 	
	 var cocina_sel_room = this.value;
	 
	 $(".tab-content-inner span").each(function(){

	 	if($(this).attr("data-room")  == cocina_sel_room){
	 		$(this).show();
	 		$(this).addClass('currentprice');

	 	} else {
	 		$(this).hide();
	 		$(this).removeClass('currentprice');
	 	}
	 	
	 });

	 gettotalprice();
	setheaderimage();

	});

	/* On change room type "Bathroom" matrial price change*/
	$('.sel2 #sel2').on('change', function() { 
	 
	 var bano_sel_room = this.value;
	
	 
	 $(".tab-content-inner span").each(function(){

	 	if($(this).attr("data-room")  == bano_sel_room){
	 		$(this).show();
	 		$(this).addClass('currentprice');
	 		/*var price =  $(this).attr("data-price");
	 		$(this).closest("input[name='price']").val(price);*/

	 	} else {
	 		$(this).hide();
	 		$(this).removeClass('currentprice');
	 	}
	 	
	 });

	 gettotalprice();
	//setheaderimage();
	 
	});


/* Radio Button chsnge*/
$("#menu li").on('click', function(){

	var valbtn = $(this).find("input[type='radio']").val();
	var inputtype = $(this).find("input[type='radio']").attr("data-title");
	inputtype = inputtype.replace("-", "_");	

	var headerimg = $(this).find("input[type='radio']").attr("data-headerimg");
	var price = $(this).find(".tab-content-inner span.currentprice").html();
	price = (price) ? parseInt(price) : 0;

	/* Kitchen */
	$("#cocina_"+inputtype+'url').val(headerimg);
	$("#cocina_"+inputtype).val(valbtn);
	 $("#cocina_"+inputtype+'price').val(price);
	/* Bathroom*/
	$("#bano_"+inputtype+'url').val(headerimg);
	$("#bano_"+inputtype).val(valbtn);
	$("#bano_"+inputtype+'price').val(price);	 
	
	gettotalprice();
	setheaderimage();
});


function gettotalprice(){	

	/* Kitchen vars*/
	var cocina_tiradoresprice = $("#cocina_tiradoresprice").val();
	var cocina_suelo_cocinaprice = $("#cocina_suelo_cocinaprice").val();
	var cocina_pinturaprice = $("#cocina_pinturaprice").val();
	var cocina_muebles_bajosprice = $("#cocina_muebles_bajosprice").val();
	var cocina_muebles_altosprice = $("#cocina_muebles_altosprice").val();
	var cocina_grifoprice = $("#cocina_grifoprice").val();
	var cocina_frontalprice = $("#cocina_frontalprice").val();
	var cocina_encimeraprice = $("#cocina_encimeraprice").val();

	 cocina_tiradoresprice = (cocina_tiradoresprice ) ? parseInt(cocina_tiradoresprice) : 0;
	 cocina_suelo_cocinaprice = (cocina_suelo_cocinaprice) ? parseInt(cocina_suelo_cocinaprice) : 0;
	 cocina_pinturaprice = (cocina_pinturaprice) ? parseInt(cocina_pinturaprice) : 0;
	 cocina_muebles_bajosprice = (cocina_muebles_bajosprice) ? parseInt(cocina_muebles_bajosprice) : 0;
	 cocina_muebles_altosprice = (cocina_muebles_altosprice) ? parseInt(cocina_muebles_altosprice) : 0;
	 cocina_grifoprice = (cocina_grifoprice) ? parseInt(cocina_grifoprice) : 0;
	 cocina_frontalprice = (cocina_frontalprice) ? parseInt(cocina_frontalprice) : 0;
	 cocina_encimeraprice = (cocina_encimeraprice) ? parseInt(cocina_encimeraprice) : 0;

	/* Bathroom vars */
	var bano_suelo_banoprice = $("#bano_suelo_banoprice").val();
	var bano_mamparaprice = $("#bano_mamparaprice").val();
	var bano_luz_espejoprice = $("#bano_luz_espejoprice").val();
	var bano_lavamanosprice = $("#bano_lavamanosprice").val();
	var bano_grifo_lavamanosprice = $("#bano_grifo_lavamanosprice").val();
	var bano_grifo_duchaprice = $("#bano_grifo_duchaprice").val();
	var bano_espejoprice = $("#bano_espejoprice").val();
	var bano_ceramica_paredprice = $("#bano_ceramica_paredprice").val();

	bano_suelo_banoprice = (bano_suelo_banoprice ) ? parseInt(bano_suelo_banoprice) : 0;
	bano_mamparaprice = (bano_mamparaprice) ? parseInt(bano_mamparaprice) : 0;
	bano_luz_espejoprice = (bano_luz_espejoprice) ? parseInt(bano_luz_espejoprice) : 0;
	bano_lavamanosprice = (bano_lavamanosprice) ? parseInt(bano_lavamanosprice) : 0;
	bano_grifo_lavamanosprice = (bano_grifo_lavamanosprice) ? parseInt(bano_grifo_lavamanosprice) : 0;
	bano_grifo_duchaprice = (bano_grifo_duchaprice) ? parseInt(bano_grifo_duchaprice) : 0;
	bano_espejoprice = (bano_espejoprice) ? parseInt(bano_espejoprice) : 0;
	bano_ceramica_paredprice = (bano_ceramica_paredprice) ? parseInt(bano_ceramica_paredprice) : 0;

	var total = cocina_tiradoresprice+cocina_suelo_cocinaprice+cocina_pinturaprice+cocina_muebles_bajosprice+cocina_muebles_altosprice+cocina_grifoprice+cocina_frontalprice +cocina_encimeraprice +bano_suelo_banoprice+bano_mamparaprice+bano_luz_espejoprice+bano_lavamanosprice+bano_grifo_lavamanosprice+bano_grifo_duchaprice+bano_espejoprice+bano_ceramica_paredprice;

	$(".showtotalprice").html(total);
	$(".totalprice").val(total);

}

function setheaderimage(){

	/* Kitchen vars*/
	var cocina_tiradoresurl = $("#cocina_tiradoresurl").val();
	var cocina_suelo_cocinaurl = $("#cocina_suelo_cocinaurl").val();
	var cocina_pinturaurl = $("#cocina_pinturaurl").val();
	var cocina_muebles_bajosurl = $("#cocina_muebles_bajosurl").val();
	var cocina_muebles_altosurl = $("#cocina_muebles_altosurl").val();
	var cocina_grifourl = $("#cocina_grifourl").val();
	var cocina_frontalurl = $("#cocina_frontalurl").val();
	var cocina_encimeraurl = $("#cocina_encimeraurl").val();

	cocina_tiradoresurl = (cocina_tiradoresurl) ? cocina_tiradoresurl : '';
	cocina_suelo_cocinaurl = (cocina_suelo_cocinaurl) ? cocina_suelo_cocinaurl : 'http://www.earchitect.es/wp-content/themes/twentyseventeen-child/assets/images/render/cocina/suelo/gris_claro_30x60.png';
	cocina_pinturaurl = (cocina_pinturaurl) ? cocina_pinturaurl : 'http://www.earchitect.es/wp-content/themes/twentyseventeen-child/assets/images/render/cocina/pintura/azul.png';
	cocina_muebles_bajosurl = (cocina_muebles_bajosurl) ? cocina_muebles_bajosurl : 'http://www.earchitect.es/wp-content/themes/twentyseventeen-child/assets/images/render/cocina/muebles_bajos/blanco.png';
	cocina_muebles_altosurl = (cocina_muebles_altosurl) ? cocina_muebles_altosurl : 'http://www.earchitect.es/wp-content/themes/twentyseventeen-child/assets/images/render/cocina/muebles_altos/azul.png';
	cocina_grifourl = (cocina_grifourl) ? cocina_grifourl : 'http://www.earchitect.es/wp-content/themes/twentyseventeen-child/assets/images/render/cocina/encimera/beige.png';
	cocina_frontalurl = (cocina_frontalurl) ? cocina_frontalurl : 'http://www.earchitect.es/wp-content/themes/twentyseventeen-child/assets/images/render/cocina/frontal/ceramico_alineado_7x20.png';
	cocina_encimeraurl = (cocina_encimeraurl) ? cocina_encimeraurl : 'http://www.earchitect.es/wp-content/themes/twentyseventeen-child/assets/images/render/cocina/encimera/blanco.png';


	/* Bathroom vars*/
	var bano_suelo_banourl = $("#bano_suelo_banourl").val();
	var bano_mamparaurl = $("#bano_mamparaurl").val();
	var bano_luz_espejourl = $("#bano_luz_espejourl").val();
	var bano_lavamanosurl = $("#bano_lavamanosurl").val();
	var bano_grifo_lavamanosurl = $("#bano_grifo_lavamanosurl").val();
	var bano_grifo_duchaurl = $("#bano_grifo_duchaurl").val();
	var bano_espejourl = $("#bano_espejourl").val();
	var bano_ceramica_paredurl = $("#bano_ceramica_paredurl").val();

	bano_suelo_banourl = (bano_suelo_banourl) ? bano_suelo_banourl : '';
	bano_mamparaurl = (bano_mamparaurl) ? bano_mamparaurl : 'http://www.earchitect.es/wp-content/themes/twentyseventeen-child/assets/images/render/cocina/suelo/gris_claro_30x60.png';
	bano_luz_espejourl = (bano_luz_espejourl) ? bano_luz_espejourl : 'http://www.earchitect.es/wp-content/themes/twentyseventeen-child/assets/images/render/cocina/pintura/azul.png';
	bano_lavamanosurl = (bano_lavamanosurl) ? bano_lavamanosurl : 'http://www.earchitect.es/wp-content/themes/twentyseventeen-child/assets/images/render/cocina/muebles_bajos/blanco.png';
	bano_grifo_lavamanosurl = (bano_grifo_lavamanosurl) ? bano_grifo_lavamanosurl : 'http://www.earchitect.es/wp-content/themes/twentyseventeen-child/assets/images/render/cocina/muebles_altos/azul.png';
	bano_grifo_duchaurl = (bano_grifo_duchaurl) ? bano_grifo_duchaurl : 'http://www.earchitect.es/wp-content/themes/twentyseventeen-child/assets/images/render/cocina/encimera/beige.png';
	bano_espejourl = (bano_espejourl) ? bano_espejourl : 'http://www.earchitect.es/wp-content/themes/twentyseventeen-child/assets/images/render/cocina/frontal/ceramico_alineado_7x20.png';
	bano_ceramica_paredurl = (bano_ceramica_paredurl) ? bano_ceramica_paredurl : 'http://www.earchitect.es/wp-content/themes/twentyseventeen-child/assets/images/render/cocina/encimera/blanco.png';

	/* Kitchen Image*/
	/*var kitchenimgs = 'url("http://www.earchitect.es/wp-content/themes/twentyseventeen-child/assets/images/render/cocina/fondo/fondo.png"), url("'+pinturaurl+'"), url("'+suelourl+'"), url(""), url("'+muebles_bajosurl+'"), url("'+encimeraurl+'"), url("'+grifourl+'"), url("'+frontalurl+'"), url("'+muebles_altosurl+'");';*/

	$(".render_cocina").css('background-image' , 'url("http://www.earchitect.es/wp-content/themes/twentyseventeen-child/assets/images/render/cocina/fondo/fondo.png"), url("'+cocina_pinturaurl+'"), url("'+cocina_suelo_cocinaurl+'"), url(""), url("'+cocina_muebles_bajosurl+'"), url("'+cocina_grifourl+'"), url("'+cocina_encimeraurl+'"), url("'+cocina_frontalurl+'"), url("'+cocina_muebles_altosurl+'")' );

	$(".render_bano").css('background-image' , 'url("http://www.earchitect.es/wp-content/themes/twentyseventeen-child/assets/images/render/cocina/fondo/fondo.png"), url("'+bano_mamparaurl+'"), url("'+bano_luz_espejourl+'"), url(""), url("'+bano_lavamanosurl+'"), url("'+bano_grifo_lavamanosurl+'"), url("'+bano_grifo_duchaurl+'"), url("'+bano_espejourl+'"), url("'+bano_ceramica_paredurl+'")' );

	 }



	 $(".material-submit-btn").on('click', function(){ 

	 	event.preventDefault();

	 	var total = $(".totalprice").val(); 
	 	var loggedin = $( "#loggedin" ).val();

	 	/*Kitchen Fields*/	 	
	 	var cocina_selected_room = $( "#sel1" ).val();

	 	/* Price + Name + URL */
	 	var cocina_tiradoresprice = $( "#cocina_tiradoresprice" ).val();
	 	var cocina_tiradores = $( "#cocina_tiradores" ).val();
	 	var cocina_tiradoresurl =$( "#cocina_tiradoresurl" ).val();

	 	var cocina_suelo_cocina = $( "#cocina_suelo_cocina" ).val();
	 	var cocina_suelo_cocinaprice = $( "#cocina_suelo_cocinaprice" ).val();
	 	var cocina_suelo_cocinaurl =$( "#cocina_suelo_cocinaurl" ).val();

	 	var cocina_pintura = $( "#cocina_pintura" ).val();
	 	var cocina_pinturaprice = $( "#cocina_pinturaprice" ).val();
	 	var cocina_pinturaurl =$( "#cocina_pinturaurl" ).val();

	 	var cocina_muebles_bajos = $( "#cocina_muebles_bajos" ).val();
	 	var cocina_muebles_bajosprice = $( "#cocina_muebles_bajosprice" ).val();
	 	var cocina_muebles_bajosurl =$( "#cocina_muebles_bajosurl" ).val();
	 	
	 	var cocina_muebles_altos = $( "#cocina_muebles_altos" ).val();
	 	var cocina_muebles_altosprice = $( "#cocina_muebles_altosprice" ).val();
	 	var cocina_muebles_altosurl =$( "#cocina_muebles_altosurl" ).val();

	 	var cocina_grifo = $( "#cocina_grifo" ).val();
	 	var cocina_grifoprice = $( "#cocina_grifoprice" ).val();
	 	var cocina_grifourl =$( "#cocina_grifourl" ).val();

	 	var cocina_frontal = $( "#cocina_frontal" ).val();
	 	var cocina_frontalprice = $( "#cocina_frontalprice" ).val();
	 	var cocina_frontalurl =$( "#cocina_frontalurl" ).val();

	 	var cocina_encimera = $( "#cocina_encimera" ).val();
	 	var cocina_encimeraprice = $( "#cocina_encimeraprice" ).val();
	 	var cocina_encimeraurl =$( "#cocina_encimeraurl" ).val();

		/*Bathroom Fields*/
		var bano_selected_room = $( "#sel2" ).val();

		/* Price + Name + URL */
	 	var bano_suelo_banoprice = $( "#bano_suelo_banoprice" ).val();
	 	var bano_suelo_bano = $( "#bano_suelo_bano" ).val();
	 	var bano_suelo_banourl = $( "#bano_suelo_banourl" ).val();

	 	var bano_mampara = $( "#bano_mampara" ).val();
	 	var bano_mamparaprice = $( "#bano_mamparaprice" ).val();
	 	var bano_mamparaurl = $( "#bano_mamparaurl" ).val();

	 	var bano_luz_espejo = $( "#bano_luz_espejo" ).val();
	 	var bano_luz_espejoprice = $( "#bano_luz_espejoprice" ).val();
	 	var bano_luz_espejourl = $( "#bano_luz_espejourl" ).val();

	 	var bano_lavamanos = $( "#bano_lavamanos" ).val();
	 	var bano_lavamanosprice = $( "#bano_lavamanosprice" ).val();
	 	var bano_lavamanosurl = $( "#bano_lavamanosurl" ).val();
	 	
	 	var bano_grifo_lavamanos = $( "#bano_grifo_lavamanos" ).val();
	 	var bano_grifo_lavamanosprice = $( "#bano_grifo_lavamanosprice" ).val();
	 	var bano_grifo_lavamanosurl = $( "#bano_grifo_lavamanosurl" ).val();

	 	var bano_grifo_ducha = $( "#bano_grifo_ducha" ).val();
	 	var bano_grifo_duchaprice = $( "#bano_grifo_duchaprice" ).val();
	 	var bano_grifo_duchaurl = $( "#bano_grifo_duchaurl" ).val();

	 	var bano_espejo = $( "#bano_espejo" ).val();
	 	var bano_espejoprice = $( "#bano_espejoprice" ).val();
	 	var bano_espejourl = $( "#bano_espejourl" ).val();

	 	var bano_ceramica_pared = $( "#bano_ceramica_pared" ).val();
	 	var bano_ceramica_paredprice = $( "#bano_ceramica_paredprice" ).val();
	 	var bano_ceramica_paredurl = $( "#bano_ceramica_paredurl" ).val();

	 	var data = {
			'action': 'my_action',
			'total'							: total,
			'cocina_selected_room'			: cocina_selected_room,
			'loggedin' 						: loggedin,
		 	'cocina_tiradoresprice' 		: cocina_tiradoresprice,
		 	'cocina_tiradores' 				: cocina_tiradores,
		 	'cocina_tiradoresurl' 			: cocina_tiradoresurl,
		 	'cocina_suelo_cocina' 					: cocina_suelo_cocina,
		 	'cocina_suelo_cocinaprice' 			: cocina_suelo_cocinaprice,
		 	'cocina_suelo_cocinaurl' 				: cocina_suelo_cocinaurl,
		 	'cocina_pintura' 				: cocina_pintura,
		 	'cocina_pinturaprice' 			: cocina_pinturaprice,
		 	'cocina_pinturaurl' 			: cocina_pinturaurl,
		 	'cocina_muebles_bajos' 			: cocina_muebles_bajos,
		 	'cocina_muebles_bajosprice' 	: cocina_muebles_bajosprice,
		 	'cocina_muebles_bajosurl' 		: cocina_muebles_bajosurl,		 	
		 	'cocina_tiradores' 				: cocina_tiradores,
		 	'cocina_tiradoresurl' 			: cocina_tiradoresurl,
		 	'cocina_muebles_altos' 			: cocina_muebles_altos,
		 	'cocina_muebles_altosprice' 	: cocina_muebles_altosprice,
		 	'cocina_muebles_altosurl' 		: cocina_muebles_altosurl,
		 	'cocina_grifo' 					: cocina_grifo,
		 	'cocina_grifoprice' 			: cocina_grifoprice,
		 	'cocina_grifourl' 				: cocina_grifourl,
		 	'cocina_frontal' 				: cocina_frontal,
		 	'cocina_frontalprice' 			: cocina_frontalprice,
		 	'cocina_frontalurl' 			: cocina_frontalurl,
		 	'cocina_encimera' 				: cocina_encimera,
		 	'cocina_encimeraprice' 			: cocina_encimeraprice,
		 	'cocina_encimeraurl' 			: cocina_encimeraurl,

		 	'bano_selected_room'			: bano_selected_room,
			'bano_suelo_banoprice'			: bano_suelo_banoprice,
			'bano_suelo_bano'				: bano_suelo_bano,
			'bano_suelo_banourl'			: bano_suelo_banourl,
			'bano_mampara'					: bano_mampara,
			'bano_mamparaprice'				: bano_mamparaprice,
			'bano_mamparaurl'				: bano_mamparaurl,
			'bano_luz_espejo'				: bano_luz_espejo,
			'bano_luz_espejoprice'			: bano_luz_espejoprice,
			'bano_luz_espejourl'			: bano_luz_espejourl,
			'bano_lavamanos'				: bano_lavamanos,
			'bano_lavamanosprice'			: bano_lavamanosprice,
			'bano_lavamanosurl'				: bano_lavamanosurl,
			'bano_grifo_lavamanos'			: bano_grifo_lavamanos,
			'bano_grifo_lavamanosprice'		: bano_grifo_lavamanosprice,
			'bano_grifo_lavamanosurl'		: bano_grifo_lavamanosurl,
			'bano_grifo_ducha'				: bano_grifo_ducha,
			'bano_grifo_duchaprice'			: bano_grifo_duchaprice,
			'bano_grifo_duchaurl'			: bano_grifo_duchaurl,
			'bano_espejo'					: bano_espejo,
			'bano_espejoprice'				: bano_espejoprice,
			'bano_espejourl'				: bano_espejourl,
			'bano_ceramica_pared'			: bano_ceramica_pared,
			'bano_ceramica_paredprice'		: bano_ceramica_paredprice,
			'bano_ceramica_paredurl'		: bano_ceramica_paredurl,
		};

		//console.log(data);

		var ajaxurl = $( "#ajaxurl" ).val();

		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		jQuery.post(ajaxurl, data, function(response) {
			console.log(response);
			return false;
		});
		

	 });

});



<?php
/*
Plugin Name: Materials
Text Domain: materials
Domain Path: /languages/
Description: This Plugin will generate furniture selection functionality
Version: 1.0
Author: Dimple
*/

if( !defined( 'WPNW_DIR' ) ) {
	define( 'WPNW_DIR', dirname( __FILE__ ) ); // Plugin dir
}


function furniture_load_textdomain() {
	load_plugin_textdomain( 'materials', false, dirname( plugin_basename(__FILE__) ) . '/languages/' );
}
add_action('plugins_loaded', 'furniture_load_textdomain');

function wpnawstyle_css_script() {
	wp_enqueue_style( 'roboto-font',  plugin_dir_url( __FILE__ ). 'assets/css/fonts-roboto-googleapis.css', array() );
	wp_enqueue_script( 'fontawesome', plugin_dir_url( __FILE__ ) . 'assets/fontawesome/js/all.min.js', array( 'jquery' ));
	wp_enqueue_style( 'bootstrap-min', plugin_dir_url( __FILE__ ) . 'assets/css/bootstrap.min.css');
	wp_enqueue_script( 'material-custom-js', plugin_dir_url( __FILE__ ) . 'assets/js/material-custom.js', array( 'jquery' ));
	wp_enqueue_script( 'jquery-min', plugin_dir_url( __FILE__ ) . 'assets/js/jquery.min.js', array( 'jquery' ));
	wp_enqueue_script( 'bootstrap', plugin_dir_url( __FILE__ ) . 'assets/js/bootstrap.min.js', array( 'jquery' ));

}
add_action( 'wp_enqueue_scripts', 'wpnawstyle_css_script' );

// Posttype
require_once( WPNW_DIR . '/includes/furniture-post-type.php' );

// Shortcode
require_once( WPNW_DIR . '/includes/material-shortcode.php' );
require_once( WPNW_DIR . '/acf.php' );


// How it work file, Load admin files
if ( is_admin() || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
	//require_once( WPNW_DIR . '/admin/wpnw-how-it-work.php' );
}

add_action( 'wp_ajax_my_action', 'my_action' );

function my_action() {	

	$loggedin = $_POST['loggedin'];	
	$total =   ($_POST['total']) ? $_POST['total'] : 0;

	/* Kitchen Fields*/
	$cocina_selected_room 			= $_POST['cocina_selected_room'];
	$cocina_tiradoresprice 			= 	($_POST['cocina_tiradoresprice']) ? $_POST['cocina_tiradoresprice'] : 0;
	$cocina_tiradores 				= 	($_POST['cocina_tiradores']) ? $_POST['cocina_tiradores'] : '';
	$cocina_tiradoresurl 			=   ($_POST['cocina_tiradoresurl']) ? $_POST['cocina_tiradoresurl'] : '';
	$cocina_suelo 					=   ($_POST['cocina_suelo']) ? $_POST['cocina_suelo'] : '';
	$cocina_sueloprice 				=   ($_POST['cocina_sueloprice']) ? $_POST['cocina_sueloprice'] : 0;
	$cocina_suelourl 				=   ($_POST['cocina_suelourl']) ? $_POST['cocina_suelourl'] : '';
	$cocina_pintura 				=   ($_POST['cocina_pintura']) ? $_POST['cocina_pintura'] : '';
	$cocina_pinturaprice 			=   ($_POST['cocina_pinturaprice']) ? $_POST['cocina_pinturaprice'] : 0;
	$cocina_pinturaurl 				=   ($_POST['cocina_pinturaurl']) ? $_POST['cocina_pinturaurl'] : '';
	$cocina_muebles_bajos 			=   ($_POST['cocina_muebles_bajos']) ? $_POST['cocina_muebles_bajos'] : '';
	$cocina_muebles_bajosprice 		=   ($_POST['cocina_muebles_bajosprice']) ? $_POST['cocina_muebles_bajosprice'] : 0;
	$cocina_muebles_bajosurl 		=   ($_POST['cocina_muebles_bajosurl']) ? $_POST['cocina_muebles_bajosurl'] : '';	
	$cocina_muebles_altos 			=   ($_POST['cocina_muebles_altos']) ? $_POST['cocina_muebles_altos'] : '';
	$cocina_muebles_altosprice 		=   ($_POST['cocina_muebles_altosprice']) ? $_POST['cocina_muebles_altosprice'] : 0;
	$cocina_muebles_altosurl 		=   ($_POST['cocina_muebles_altosurl']) ? $_POST['cocina_muebles_altosurl'] : '';
	$cocina_grifo 					=   ($_POST['cocina_grifo']) ? $_POST['cocina_grifo'] : '';
	$cocina_grifoprice 				=   ($_POST['cocina_grifoprice']) ? $_POST['cocina_grifoprice'] : 0;
	$cocina_grifourl 				=   ($_POST['cocina_grifourl']) ? $_POST['cocina_grifourl'] : '';
	$cocina_frontal 				=   ($_POST['cocina_frontal']) ? $_POST['cocina_frontal'] : '';
	$cocina_frontalprice 			=   ($_POST['cocina_frontalprice']) ? $_POST['cocina_frontalprice'] : 0;
	$cocina_frontalurl 				=   ($_POST['cocina_frontalurl']) ? $_POST['cocina_frontalurl'] : '';
	$cocina_encimera 				=   ($_POST['cocina_encimera']) ? $_POST['cocina_encimera'] : '';
	$cocina_encimeraprice 			=   ($_POST['cocina_encimeraprice']) ? $_POST['cocina_encimeraprice'] : 0;
	$cocina_encimeraurl 			=   ($_POST['cocina_encimeraurl']) ? $_POST['cocina_encimeraurl'] : '';

	/* Bathroom Fields*/
	$bano_selected_room 			= ($_POST['bano_selected_room']) ? $_POST['bano_selected_room'] :'' ;
	$bano_suelo_banoprice 			= ($_POST['bano_suelo_banoprice']) ? $_POST['bano_suelo_banoprice'] : 0 ;
	$bano_suelo_bano 				= ($_POST['bano_suelo_bano']) ? $_POST['bano_suelo_bano']	: '' ;
	$bano_suelo_banourl 			= ($_POST['bano_suelo_banourl']) ? $_POST['bano_suelo_banourl'] :'' ;
	$bano_mampara 					= ($_POST['bano_mampara']) ? $_POST['bano_mampara'] : '' ;
	$bano_mamparaprice 				= ($_POST['bano_mamparaprice']) ? $_POST['bano_mamparaprice']	: 0 ;
	$bano_mamparaurl 				= ($_POST['bano_mamparaurl']) ? $_POST['bano_mamparaurl']	: '' ;
	$bano_luz_espejo 				= ($_POST['bano_luz_espejo']) ? $_POST['bano_luz_espejo']	: '' ;
	$bano_luz_espejoprice 			= ($_POST['bano_luz_espejoprice']) ? $_POST['bano_luz_espejoprice'] : 0 ;
	$bano_luz_espejourl 			= ($_POST['bano_luz_espejourl']) ? $_POST['bano_luz_espejourl'] : '' ;
	$bano_lavamanos 				= ($_POST['bano_lavamanos']) ? $_POST['bano_lavamanos'] : '' ;
	$bano_lavamanosprice 			= ($_POST['bano_lavamanosprice']) ? $_POST['bano_lavamanosprice']	: 0 ;
	$bano_lavamanosurl 				= ($_POST['bano_lavamanosurl']) ? $_POST['bano_lavamanosurl']	: '' ;
	$bano_grifo_lavamanos 			= ($_POST['bano_grifo_lavamanos']) ? $_POST['bano_grifo_lavamanos'] :'' ;
	$bano_grifo_lavamanosprice 		= ($_POST['bano_grifo_lavamanosprice']) ? $_POST['bano_grifo_lavamanosprice']	: 0 ;
	$bano_grifo_lavamanosurl 		= ($_POST['bano_grifo_lavamanosurl']) ? $_POST['bano_grifo_lavamanosurl']	: '' ;
	$bano_grifo_ducha 				= ($_POST['bano_grifo_ducha']) ? $_POST['bano_grifo_ducha'] : '' ;
	$bano_grifo_duchaprice 			= ($_POST['bano_grifo_duchaprice']) ? $_POST['bano_grifo_duchaprice']	: 0 ;
	$bano_grifo_duchaurl 			= ($_POST['bano_grifo_duchaurl']) ? $_POST['bano_grifo_duchaurl']	: '' ;
	$bano_espejo 					= ($_POST['bano_espejo']) ? $_POST['bano_espejo']	: '' ;
	$bano_espejoprice 				= ($_POST['bano_espejoprice']) ? $_POST['bano_espejoprice'] : 0 ;
	$bano_espejourl 				= ($_POST['bano_espejourl']) ? $_POST['bano_espejourl'] : '' ;
	$bano_ceramica_pared 			= ($_POST['bano_ceramica_pared']) ? $_POST['bano_ceramica_pared']	:'' ;
	$bano_ceramica_paredprice 		= ($_POST['bano_ceramica_paredprice']) ? $_POST['bano_ceramica_paredprice'] : 0 ;
	$bano_ceramica_paredurl 		= ($_POST['bano_ceramica_paredurl']) ? $_POST['bano_ceramica_paredurl'] : '' ;

	$user_material = array(
		'total' => $total,
		/* Kitchen Filelds*/
		'cocina_selected_room' 		=> $cocina_selected_room,
		'cocina_tiradoresprice' 			=> $cocina_tiradoresprice,
		'cocina_tiradores' 			=> $cocina_tiradores,
		'cocina_tiradoresurl' 			=> $cocina_tiradoresurl,
		'cocina_suelo' 					=> $cocina_suelo,
		'cocina_sueloprice' 			=> $cocina_sueloprice,
		'cocina_suelourl' 				=> $cocina_suelourl,
		'cocina_pintura' 				=> $cocina_pintura,
		'cocina_pinturaprice' 			=> $cocina_pinturaprice,
		'cocina_pinturaurl' 			=> $cocina_pinturaurl,
		'cocina_muebles_bajos' 			=> $cocina_muebles_bajos,
		'cocina_muebles_bajosprice' 	=> $cocina_muebles_bajosprice,
		'cocina_muebles_bajosurl' 		=> $cocina_muebles_bajosurl,		
		'cocina_muebles_altos' 			=> $cocina_muebles_altos,
		'cocina_muebles_altosprice' 	=> $cocina_muebles_altosprice,
		'cocina_muebles_altosurl' 		=> $cocina_muebles_altosurl,
		'cocina_grifo' 					=> $cocina_grifo,
		'cocina_grifoprice' 			=> $cocina_grifoprice,
		'cocina_grifourl' 			=> $cocina_grifourl,
		'cocina_frontal' 			=> $cocina_frontal,
		'cocina_frontalprice' 			=> $cocina_frontalprice,
		'cocina_frontalurl' 			=> $cocina_frontalurl,
		'cocina_encimera' 			=> $cocina_encimera,
		'cocina_encimeraprice' 			=> $cocina_encimeraprice,
		'cocina_encimeraurl' 			=> $cocina_encimeraurl,

		'bano_selected_room'			=>  $bano_selected_room,
		'bano_suelo_banoprice'			=>  $bano_suelo_banoprice,
		'bano_suelo_bano'				=>  $bano_suelo_bano,
		'bano_suelo_banourl'			=>  $bano_suelo_banourl,
		'bano_mampara'					=>  $bano_mampara,
		'bano_mamparaprice'				=>  $bano_mamparaprice,
		'bano_mamparaurl'				=>  $bano_mamparaurl,
		'bano_luz_espejo'				=>  $bano_luz_espejo,
		'bano_luz_espejoprice'			=>  $bano_luz_espejoprice,
		'bano_luz_espejourl'			=>  $bano_luz_espejourl,
		'bano_lavamanos'				=>  $bano_lavamanos,
		'bano_lavamanosprice'			=>  $bano_lavamanosprice,
		'bano_lavamanosurl'				=>  $bano_lavamanosurl,
		'bano_grifo_lavamanos'			=>  $bano_grifo_lavamanos,
		'bano_grifo_lavamanosprice'		=>  $bano_grifo_lavamanosprice,
		'bano_grifo_lavamanosurl'		=>  $bano_grifo_lavamanosurl,
		'bano_grifo_ducha'				=>  $bano_grifo_ducha,
		'bano_grifo_duchaprice'			=>  $bano_grifo_duchaprice,
		'bano_grifo_duchaurl'			=>  $bano_grifo_duchaurl,
		'bano_espejo'					=>  $bano_espejo,
		'bano_espejoprice'				=>  $bano_espejoprice,
		'bano_espejourl'				=>  $bano_espejourl,
		'bano_ceramica_pared'			=>  $bano_ceramica_pared,
		'bano_ceramica_paredprice'		=>  $bano_ceramica_paredprice,
		'bano_ceramica_paredurl'		=>  $bano_ceramica_paredurl,
	); 

	
	$usermeta = update_user_meta($loggedin, 'user_material', $user_material);
	echo $usermeta;
	/*var_dump($user_material);*/
	exit();
	wp_die(); // this is required to terminate immediately and return a proper response
}

/*add_action('edit_user_profile_update', 'update_extra_profile_fields');
 
 function update_extra_profile_fields($user_id) {
     if ( current_user_can('edit_user',$user_id) )
         update_user_meta($user_id, 'user_material', $_POST['user_material']);
 }*/

 /**
 * Show custom user profile fields
 * 
 * @param  object $profileuser A WP_User object
 * @return void
 */
function custom_user_profile_fields( $profileuser ) {

	$loggedin = get_current_user_id();
	$usermetadata = get_user_meta($loggedin , 'user_material');
	$total = $usermetadata[0]['total'];
	//var_dump($usermetadata);

	/* Kitchen Fields*/ 					 
	 $cocina_selected_room = $usermetadata[0]['cocina_selected_room'];
	 $cocina_tiradores = $usermetadata[0]['cocina_tiradores'];
	 $cocina_tiradoresurl = $usermetadata[0]['cocina_tiradoresurl'];
	 $cocina_tiradoresprice = $usermetadata[0]['cocina_tiradoresprice'];
	 $cocina_suelo = $usermetadata[0]['cocina_suelo'];
	 $cocina_sueloprice = $usermetadata[0]['cocina_sueloprice'];
	 $cocina_suelourl = $usermetadata[0]['cocina_suelourl'];
	 $cocina_pintura = $usermetadata[0]['cocina_pintura'];
	 $cocina_pinturaprice = $usermetadata[0]['cocina_pinturaprice'];
	 $cocina_pinturaurl = $usermetadata[0]['cocina_pinturaurl'];
	 $cocina_muebles_bajos = $usermetadata[0]['cocina_muebles_bajos'];
	 $cocina_muebles_bajosprice = $usermetadata[0]['cocina_muebles_bajosprice'];
	 $cocina_muebles_bajosurl	 = $usermetadata[0]['cocina_muebles_bajosurl'];
	 $cocina_muebles_altos = $usermetadata[0]['cocina_muebles_altos'];
	 $cocina_muebles_altosprice = $usermetadata[0]['cocina_muebles_altosprice'];
	 $cocina_muebles_altosurl = $usermetadata[0]['cocina_muebles_altosurl'];
	 $cocina_grifo = $usermetadata[0]['cocina_grifo'];
	 $cocina_grifoprice = $usermetadata[0]['cocina_grifoprice'];
	 $cocina_grifourl = $usermetadata[0]['cocina_grifourl'];
	 $cocina_frontal = $usermetadata[0]['cocina_frontal'];
	 $cocina_frontalprice = $usermetadata[0]['cocina_frontalprice'];
	 $cocina_frontalurl = $usermetadata[0]['cocina_frontalurl'];
	 $cocina_encimera = $usermetadata[0]['cocina_encimera'];
	 $cocina_encimeraprice = $usermetadata[0]['cocina_encimeraprice'];
	 $cocina_encimeraurl = $usermetadata[0]['cocina_encimeraurl'];

	$bano_selected_room				=  $usermetadata[0]['bano_selected_room'];
	$bano_suelo_banoprice			=  $usermetadata[0]['bano_suelo_banoprice'];
	$bano_suelo_bano				=  $usermetadata[0]['bano_suelo_bano'];
	$bano_suelo_banourl				=  $usermetadata[0]['bano_suelo_banourl'];
	$bano_mampara					=  $usermetadata[0]['bano_mampara'];
	$bano_mamparaprice				=  $usermetadata[0]['bano_mamparaprice'];
	$bano_mamparaurl				=  $usermetadata[0]['bano_mamparaurl'];
	$bano_luz_espejo				=  $usermetadata[0]['bano_luz_espejo'];
	$bano_luz_espejoprice			=  $usermetadata[0]['bano_luz_espejoprice'];
	$bano_luz_espejourl				=  $usermetadata[0]['bano_luz_espejourl'];
	$bano_lavamanos					=  $usermetadata[0]['bano_lavamanos'];
	$bano_lavamanosprice			=  $usermetadata[0]['bano_lavamanosprice'];
	$bano_lavamanosurl				=  $usermetadata[0]['bano_lavamanosurl'];
	$bano_grifo_lavamanos			=  $usermetadata[0]['bano_grifo_lavamanos'];
	$bano_grifo_lavamanosprice		=  $usermetadata[0]['bano_grifo_lavamanosprice'];
	$bano_grifo_lavamanosurl		=  $usermetadata[0]['bano_grifo_lavamanosurl'];
	$bano_grifo_ducha				=  $usermetadata[0]['bano_grifo_ducha'];
	$bano_grifo_duchaprice			=  $usermetadata[0]['bano_grifo_duchaprice'];
	$bano_grifo_duchaurl			=  $usermetadata[0]['bano_grifo_duchaurl'];
	$bano_espejo					=  $usermetadata[0]['bano_espejo'];
	$bano_espejoprice				=  $usermetadata[0]['bano_espejoprice'];
	$bano_espejourl					=  $usermetadata[0]['bano_espejourl'];
	$bano_ceramica_pared			=  $usermetadata[0]['bano_ceramica_pared'];
	$bano_ceramica_paredprice		=  $usermetadata[0]['bano_ceramica_paredprice'];
	$bano_ceramica_paredurl			=  $usermetadata[0]['bano_ceramica_paredurl'];
	
	?>

	<table class="form-table" style="background-color: #80808038;  margin-top: 20px;">

		<tr style="background-color: #1291ce;">
			<th style="text-align: center; color: white; font-size: 18px;">Kitchen</th>
			<th style="text-align: center; color: white; font-size: 18px;">Bathroom</th>
		</tr>

		<tr>
			<th style="text-align: center;  font-size: 18px;"><label for="total"><?php esc_html_e( 'Total' ); ?></label>

			<input type="text" name="total" id="total" value="<?php echo esc_attr($total ); ?>" class="regular-text" /></th>
			<td></td>
		</tr>

		<tr>
			<th>
				<table style="margin-left: 96px;">
					
					<tr>
						<th><label for="cocina_selected_room"><?php esc_html_e( 'Type Of Room' ); ?></label></th>
						<td><input type="text" name="cocina_selected_room" id="cocina_selected_room" value="<?php echo esc_attr( $cocina_selected_room ); ?>" class="regular-text" />
						</td>
					</tr>
					<tr>
						<th><label for="cocina_muebles_altosprice"><?php esc_html_e( 'Muebles altos' ); ?></label></th>
						<td><input type="text" name="cocina_muebles_altosprice" id="cocina_muebles_altosprice" value="<?php echo esc_attr( $cocina_muebles_altosprice ); ?>" class="regular-text" />
						</td>
					</tr>
					<tr>
						<th><label for="cocina_frontalprice"><?php esc_html_e( 'Frontal' ); ?></label></th>
						<td><input type="text" name="cocina_frontalprice" id="cocina_frontalprice" value="<?php echo esc_attr( $cocina_frontalprice ); ?>" class="regular-text" />
						</td>
					</tr>
					<tr>
						<th><label for="cocina_encimeraprice"><?php esc_html_e( 'Encimera' ); ?></label></th>
						<td><input type="text" name="cocina_encimeraprice" id="cocina_encimeraprice" value="<?php echo esc_attr( $cocina_encimeraprice); ?>" class="regular-text" />
						</td>
					</tr>
					<tr>
						<th><label for="cocina_grifoprice"><?php esc_html_e( 'Grifo' ); ?></label></th>
						<td><input type="text" name="cocina_grifoprice" id="cocina_grifoprice" value="<?php echo esc_attr( $cocina_grifoprice ); ?>" class="regular-text" />
						</td>
					</tr>
					<tr>
						<th><label for="cocina_muebles_bajosprice"><?php esc_html_e( 'Muebles bajos' ); ?></label></th>
						<td><input type="text" name="cocina_muebles_bajosprice" id="cocina_muebles_bajosprice" value="<?php echo esc_attr( $cocina_muebles_bajosprice ); ?>" class="regular-text" />
						</td>
					</tr>
					<tr>
						<th><label for="cocina_tiradoresprice"><?php esc_html_e( 'Tiradores' ); ?></label></th>
						<td><input type="text" name="cocina_tiradoresprice" id="cocina_tiradoresprice" value="<?php echo esc_attr( $cocina_tiradoresprice ); ?>" class="regular-text" />
						</td>
					</tr>
					<tr>
						<th><label for="cocina_sueloprice"><?php esc_html_e( 'Suelo' ); ?></label></th>
						<td><input type="text" name="cocina_sueloprice" id="cocina_sueloprice" value="<?php echo esc_attr( $cocina_sueloprice); ?>" class="regular-text" />
						</td>
					</tr>
					<tr>
						<th><label for="cocina_pinturaprice"><?php esc_html_e( 'Pintura' ); ?></label></th>
						<td><input type="text" name="cocina_pinturaprice" id="cocina_pinturaprice" value="<?php echo esc_attr( $cocina_pinturaprice ); ?>" class="regular-text" />
						</td>
					</tr>
				</table>
				
			</th>
			<th>
				<table>
					<tr>
						<th><label for="bano_selected_room"><?php esc_html_e( 'Type Of Room' ); ?></label></th>
						<td><input type="text" name="bano_selected_room" id="bano_selected_room" value="<?php echo esc_attr( $bano_selected_room); ?>" class="regular-text" />
						</td>
					</tr>
					<tr>
						<th><label for="bano_suelo_banoprice"><?php esc_html_e( 'Suelo' ); ?></label></th>
						<td><input type="text" name="bano_suelo_banoprice" id="bano_suelo_banoprice" value="<?php echo esc_attr( $bano_suelo_banoprice); ?>" class="regular-text" />
						</td>
					</tr>
					<tr>
						<th><label for="bano_mamparaprice"><?php esc_html_e( 'Mampara' ); ?></label></th>
						<td><input type="text" name="bano_mamparaprice" id="bano_mamparaprice" value="<?php echo esc_attr( $bano_mamparaprice); ?>" class="regular-text" />
						</td>
					</tr>
					<tr>
						<th><label for="bano_luz_espejoprice"><?php esc_html_e( 'Luz espejo' ); ?></label></th>
						<td><input type="text" name="bano_luz_espejoprice" id="bano_luz_espejoprice" value="<?php echo esc_attr( $bano_luz_espejoprice); ?>" class="regular-text" />
						</td>
					</tr>
					<tr>
						<th><label for="bano_lavamanosprice"><?php esc_html_e( 'Lavamanos' ); ?></label></th>
						<td><input type="text" name="bano_lavamanosprice" id="bano_lavamanosprice" value="<?php echo esc_attr( $bano_lavamanosprice); ?>" class="regular-text" />
						</td>
					</tr>
					<tr>
						<th><label for="bano_grifo_lavamanosprice"><?php esc_html_e( 'Grifo Lavamanos' ); ?></label></th>
						<td><input type="text" name="bano_grifo_lavamanosprice" id="bano_grifo_lavamanosprice" value="<?php echo esc_attr( $bano_grifo_lavamanosprice); ?>" class="regular-text" />
						</td>
					</tr>
					<tr>
						<th><label for="bano_grifo_duchaprice"><?php esc_html_e( 'Grifo Ducha' ); ?></label></th>
						<td><input type="text" name="bano_grifo_duchaprice" id="bano_grifo_duchaprice" value="<?php echo esc_attr( $bano_grifo_duchaprice); ?>" class="regular-text" />
						</td>
					</tr>
					<tr>
						<th><label for="bano_espejoprice"><?php esc_html_e( 'Espejo' ); ?></label></th>
						<td><input type="text" name="bano_espejoprice" id="bano_espejoprice" value="<?php echo esc_attr( $bano_espejoprice); ?>" class="regular-text" />
						</td>
					</tr>
					<tr>
						<th><label for="bano_ceramica_paredprice"><?php esc_html_e( 'Cerámica pared' ); ?></label></th>
						<td><input type="text" name="bano_ceramica_paredprice" id="bano_ceramica_paredprice" value="<?php echo esc_attr( $bano_ceramica_paredprice); ?>" class="regular-text" />
						</td>
					</tr>
				</table>
				
			</th>
		</tr>

		
		
	</table> 
<?php
}
add_action( 'show_user_profile', 'custom_user_profile_fields', 10, 1 );
add_action( 'edit_user_profile', 'custom_user_profile_fields', 10, 1 );





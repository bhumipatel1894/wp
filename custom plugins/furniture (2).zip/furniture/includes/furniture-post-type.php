<?php

if ( !defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Initialization function
add_action('init', 'sp_cpt_kitchen_init');

function sp_cpt_kitchen_init() {
  // Create new News custom post type
    $news_labels = array(
                    'name'                 => _x('Materials', 'sp-news-and-widget'),
                    'singular_name'        => _x('Materials', 'sp-news-and-widget'),
                    'add_new'              => _x('Add Materials Item', 'sp-news-and-widget'),
                    'add_new_item'         => __('Add New Materials Item', 'sp-news-and-widget'),
                    'edit_item'            => __('Edit Materials Item', 'sp-news-and-widget'),
                    'new_item'             => __('New Materials Item', 'sp-news-and-widget'),
                    'view_item'            => __('View Materials Item', 'sp-news-and-widget'),
                    'search_items'         => __('Search  Materials Items','sp-news-and-widget'),
                    'not_found'            =>  __('No Materials Items found', 'sp-news-and-widget'),
                    'not_found_in_trash'   => __('No Materials Items found in Trash', 'sp-news-and-widget'),
                    'parent_item_colon'    => '',
                    'menu_name'          => _x( 'Materials', 'admin menu', 'sp-news-and-widget' )
  );

    $labels = array(
                    'name'                 => _x('Room Types', 'sp-news-and-widget'),
                    'singular_name'        => _x('Room Types', 'sp-news-and-widget'),
                    'add_new'              => _x('Add Room Type', 'sp-news-and-widget'),
                    'add_new_item'         => __('Add New Room Type', 'sp-news-and-widget'),
                    'edit_item'            => __('Edit Room Type', 'sp-news-and-widget'),
                    'new_item'             => __('New Room Type', 'sp-news-and-widget'),
                    'view_item'            => __('View Room Type', 'sp-news-and-widget'),
                    'search_items'         => __('Search Room Type','sp-news-and-widget'),
                    'not_found'            =>  __('No Room Type found', 'sp-news-and-widget'),
                    'not_found_in_trash'   => __('No Room Type found in Trash', 'sp-news-and-widget'),
                    'parent_item_colon'    => '',
                    'menu_name'          => _x( 'Room Types', 'admin menu', 'sp-news-and-widget' )
  );

  $news_args = array(
                    'labels'              => $news_labels,
                    'public'              => true,
                    'publicly_queryable'  => true,
                    'exclude_from_search' => false,
                    'show_ui'             => true,
                    'show_in_menu'        => true, 
                    'query_var'           => true,
                    'rewrite'             => array( 
                                                'slug'       => 'material',
                                                'with_front' => false
                                            ),
                    'capability_type'     => 'post',
                    'has_archive'         => true,
                    'hierarchical'        => false,
                    'menu_position'       => 5,
                    'menu_icon'           => 'dashicons-feedback',
                    'supports'            => array('title','thumbnail','excerpt', 'author'),
                    'show_in_rest'        => true,
                    'taxonomies'          => array('post_tag')
  );

  $args = array(
                    'labels'              => $labels,
                    'public'              => true,
                    'publicly_queryable'  => true,
                    'exclude_from_search' => false,
                    'show_ui'             => true,
                    'show_in_menu'        => true, 
                    'query_var'           => true,
                    'rewrite'             => array( 
                                                'slug'       => 'room',
                                                'with_front' => false
                                            ),
                    'capability_type'     => 'post',
                    'has_archive'         => true,
                    'hierarchical'        => false,
                    'menu_position'       => 5,
                    'menu_icon'           => 'dashicons-feedback',
                    'supports'            => array('title','thumbnail','excerpt', 'author'),
                    'show_in_rest'        => true,
                    'taxonomies'          => array('post_tag')
  );

    register_post_type( 'room_type', apply_filters( 'kitchen_registered_post_type_args', $args ) );
    
    register_post_type( 'earchitect', apply_filters( 'kitchen_registered_post_type_args', $news_args ) );
}

/* Register Taxonomy */
add_action( 'init', 'kitchen_taxonomies');

function kitchen_taxonomies() {
    $labels = array(
                'name'              => _x( 'Category', 'sp-news-and-widget' ),
                'singular_name'     => _x( 'Category', 'sp-news-and-widget' ),
                'search_items'      => __( 'Search Category', 'sp-news-and-widget' ),
                'all_items'         => __( 'All Category', 'sp-news-and-widget' ),
                'parent_item'       => __( 'Parent Category', 'sp-news-and-widget' ),
                'parent_item_colon' => __( 'Parent Category:', 'sp-news-and-widget' ),
                'edit_item'         => __( 'Edit Category', 'sp-news-and-widget' ),
                'update_item'       => __( 'Update Category', 'sp-news-and-widget' ),
                'add_new_item'      => __( 'Add New Category', 'sp-news-and-widget' ),
                'new_item_name'     => __( 'New Category Name', 'sp-news-and-widget' ),
                'menu_name'         => __( 'Category', 'sp-news-and-widget' ),
    );

    $args = array(
                'hierarchical'      => true,
                'labels'            => $labels,
                'show_ui'           => true,
                'show_admin_column' => true,
                'query_var'         => true,
                'show_in_rest'      => true,
                'rewrite'           => array( 'slug' => 'earchitect_cat' ),
    );
    register_taxonomy( 'earchitect_cat', array( 'earchitect', 'room_type' ), $args );
}
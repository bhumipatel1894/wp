<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;	// Exit if accessed directly
}

// "material_selection_form" Shortcode

function wpnaw_get_materials( $atts, $content = null ){

	ob_start();
	
	global $post;

	$loggedin = get_current_user_id();

   $termarr = get_terms( array(
	    'taxonomy' => 'earchitect_cat',
	    'hide_empty' => false,
	    'order' => 'desc',
	    'parent' => 0
	) );

   $term_id_arr = array();
   $term_name_arr = array();
   $term_title_arr = array();

   foreach($termarr as $key => $val) {
   		//	var_dump($val);
   		$term_id_arr[] = $val->term_id;
   		$term_name_arr[] = $val->name;
   		$term_title_arr[] = $val->slug;
   }

   $i = 0;

   $childterm_ID = array();
   $childterm_name = array();   
   $childterm_descri = array();
   
?>

<style type="text/css">

    	.wpos-select-main .form-control:focus{box-shadow:unset;border-color:#ddd;}
    	.wpos-select-main .form-control{width: 50%;}
    	.wpbtn-1, .wpbtn-2{cursor: pointer;}
    	.form-submit-btn{background: #ddd;float: right;padding: 0px 15px;border-radius: 5px;margin-bottom: 5px;}
    	.cont-form-tab .form-radio-btn.current{border: 1px solid #61ce70;}
    	.cont-form-tab .form-radio-btn{display: block; margin-bottom: 15px;padding: 10px;}
    	.cont-form-tab .form-radio-btn input{float: left;margin-right: 10px;}
    	.form-radio-btn h4{font-weight: normal;font-size: 22px;}
    	.form-radio-btn span{font-weight: normal;font-size: 15px;}
    	.cont-form-tab .nav-tabs {border-bottom: none;overflow: hidden;}
    	.cont-form-tab .tab-img{background-size: cover;background-position: center;background-repeat: no-repeat;margin-bottom: 5px;}
    	.cont-form-tab .tab-pane{padding: 20px;}
    	.cont-form-tab .nav-tabs .nav-link.active{color: #61ce70}
    	.cont-form-tab .nav-tabs .nav-link{color: #457e7b;font-weight: 600;font-size: 16px;}
		.tab-content{border: 1px solid #d4d4d4;}
		.cont-form-tab .tab-bg-img{background-size: cover; background-position: center; background-repeat: no-repeat;  margin-bottom: 0px;}
		.render_cocina2, .render_cocina{width: 100%; height: 400px;}
 </style>

 <div class="wpos-form-section" style="max-width: 1200px;margin: 0 auto;">
	    <div class="container">
		    <div class="row">
		    	<?php
		    	$tabind = 1;
				$childtmind = 1;
		    	 $tnind = 1;
		    	foreach($term_name_arr as $term_name){ ?>
		    		<div class="col-12 col-md-6 text-right">
			    		<span class="wpbtn-<?php echo $tnind; ?>"><?php echo $term_name; ?> </span>
			    	</div>
		    	<?php $tnind++; }	?>
		    	
			    
			    <br><br>
			    <div class="col-12 col-md-12 text-center">

			    	<?php 
			    	$Headerimg_Query = get_posts(array(
							    'showposts' => -1,
							    'post_type' => 'earchitect',							    
							));			    	

			    	?>

			    	<div data-header="" class="render_cocina" style="width: 100%; height: 400px; background-position: center; background-repeat: no-repeat; background-size: contain; background-image: url(&quot;http://localhost/practice/wp-content/uploads/2020/06/fondo-fondo.png&quot;), url(&quot;http://localhost/practice/wp-content/uploads/2020/06/pintura-rosa.png&quot;), url(&quot;http://localhost/practice/wp-content/uploads/2020/06/suelo-hexagonos.png&quot;), url(&quot;&quot;), url(&quot;http://localhost/practice/wp-content/uploads/2020/06/muebles_bajos-gris.png&quot;), url(&quot;http://localhost/practice/wp-content/uploads/2020/06/encimera-beige.png&quot;), url(&quot;http://localhost/practice/wp-content/uploads/2020/06/encimera-blanco.png&quot;), url(&quot;http://localhost/practice/wp-content/uploads/2020/06/frontal-ceramico_ladrillo_7x20.png&quot;), url(&quot;http://localhost/practice/wp-content/uploads/2020/06/muebles_altos-madera.png&quot;);

			    	">
    				</div>
    				<div data-header=""  class="render_banu" style="display: none; width: 100%; height: 400px; background-position: center; background-repeat: no-repeat; background-size: contain; background-image: url(&quot;http://localhost/practice/wp-content/uploads/2020/06/fondo-fondo.png&quot;), url(&quot;http://localhost/practice/wp-content/uploads/2020/06/pintura-rosa.png&quot;), url(&quot;http://localhost/practice/wp-content/uploads/2020/06/suelo-hexagonos.png&quot;), url(&quot;&quot;), url(&quot;http://localhost/practice/wp-content/uploads/2020/06/muebles_bajos-gris.png&quot;), url(&quot;http://localhost/practice/wp-content/uploads/2020/06/encimera-beige.png&quot;), url(&quot;http://localhost/practice/wp-content/uploads/2020/06/encimera-blanco.png&quot;), url(&quot;http://localhost/practice/wp-content/uploads/2020/06/frontal-ceramico_ladrillo_7x20.png&quot;), url(&quot;http://localhost/practice/wp-content/uploads/2020/06/muebles_altos-madera.png&quot;);

			    	">
    				</div>
    				
			    </div>
		    </div>

		    <br>
	    </div>

	    <?php $termind = 1;
	    $childterm_ID = array();
		$childterm_name = array();
		$childterm_descri = array();

    	foreach($term_id_arr as $term_id){ 

    		$usermetadata = get_user_meta($loggedin , 'user_material');
    		if(!empty($usermetadata)){
    			
    			 $total = $usermetadata[0]['total'];

    			 $cocina_cocina_selected_room = $usermetadata[0]['cocina_cocina_selected_room'];
				 $cocina_tiradores = $usermetadata[0]['cocina_tiradores'];
				 $cocina_tiradoresurl = $usermetadata[0]['cocina_tiradoresurl'];
				 $cocina_tiradoresprice = $usermetadata[0]['cocina_tiradoresprice'];
				 $cocina_suelo = $usermetadata[0]['cocina_suelo'];
				 $cocina_sueloprice = $usermetadata[0]['cocina_sueloprice'];
				 $cocina_suelourl = $usermetadata[0]['cocina_suelourl'];
				 $cocina_pintura = $usermetadata[0]['cocina_pintura'];
				 $cocina_pinturaprice = $usermetadata[0]['cocina_pinturaprice'];
				 $cocina_pinturaurl = $usermetadata[0]['cocina_pinturaurl'];
				 $cocina_muebles_bajos = $usermetadata[0]['cocina_muebles_bajos'];
				 $cocina_muebles_bajosprice = $usermetadata[0]['cocina_muebles_bajosprice'];
				 $cocina_muebles_bajosurl	 = $usermetadata[0]['cocina_muebles_bajosurl'];
				 $cocina_muebles_altos = $usermetadata[0]['cocina_muebles_altos'];
				 $cocina_muebles_altosprice = $usermetadata[0]['cocina_muebles_altosprice'];
				 $cocina_muebles_altosurl = $usermetadata[0]['cocina_muebles_altosurl'];
				 $cocina_grifo = $usermetadata[0]['cocina_grifo'];
				 $cocina_grifoprice = $usermetadata[0]['cocina_grifoprice'];
				 $cocina_grifourl = $usermetadata[0]['cocina_grifourl'];
				 $cocina_frontal = $usermetadata[0]['cocina_frontal'];
				 $cocina_frontalprice = $usermetadata[0]['cocina_frontalprice'];
				 $cocina_frontalurl = $usermetadata[0]['cocina_frontalurl'];
				 $cocina_encimera = $usermetadata[0]['cocina_encimera'];
				 $cocina_encimeraprice = $usermetadata[0]['cocina_encimeraprice'];
				 $cocina_encimeraurl = $usermetadata[0]['cocina_encimeraurl'];


				/* var_dump( $cocina_muebles_altos);*/
    		}
    		?>
    		

    		<form class="material-form">

    		<input type="hidden" name="loggedin" value="<?php echo $loggedin; ?>" id="loggedin">
    		<input type="hidden" name="ajaxurl" value="<?php echo admin_url( "admin-ajax.php" ); ?>" id="ajaxurl">

		    <div id="wpbtn-<?php echo $termind; ?>" class="button-<?php echo $termind; ?>">
			    <div class="col-12 col-md-12">
						
							<div class="row">
								<div class="col-md-6 total">
									Total: <span class="showtotalprice"></span>
									<input type="hidden" name="totalprice" class="totalprice"  value="0">
								</div>
								<div class="col-md-6"><button type="submit" class="form-submit-btn material-submit-btn">Submit</button>
									</div>

							</div>

							
							<?php

							$selecttermind = 1;
							foreach($term_id_arr as $selectterm_id){

								?>
								<div class="form-group wpos-select-main sel<?php echo $selecttermind; ?>">
								<label for="sel<?php echo $selecttermind; ?>">Select Rooms: </label>
								<select class="form-control" id="sel<?php echo $selecttermind; ?>">
								<?php

									$roomtypeQuery = get_posts(array(
								    'showposts' => -1,
								    'post_type' => 'room_type',
								    'tax_query' => array(
								        array(
								        'taxonomy' => 'earchitect_cat',
								        'field' => 'term_id',
								        'terms' => array($selectterm_id))
								    ))
								);


							/*	$roomtypeQuery = new WP_Query( array(
									'post_type'      => 'room_type',
									'orderby'        => 'desc',
									'cat '  => array($selectterm_id),					
								) );*/

								foreach($roomtypeQuery as $rtkey){
						    		
							    		$childterm_ID[] =  $rtkey->ID;
							    		$childterm_name[] =  $rtkey->post_title;
							    		$childterm_descri[] =  get_field('room_dimention', $rtkey->ID); 
							    		
							    		
							    		?>
							    		<option value="<?php echo $rtkey->post_title; ?>"> <?php echo $rtkey->post_title; ?> </option>
								
						    		<?php
						    		}
						    	?>
						    	</select>

						    	</div>
						    	<?php

							$selecttermind++;
							}
							?>
						
				</div>				
				<div class="col-12 col-md-12 cont-form-tab">

					<nav>
						<div class="nav nav-tabs" id="nav-tab" role="tablist">

							<?php
									$childterm_tID = array();							  	
									$childterm_tname = array();							  	
									$childterm_tdescri = array();	

									
									$tabind2 = 1;
									$tname = 1;
							   		$childtermarr = get_terms( 'earchitect_cat' , array(

							   		 	'hide_empty' => 0,
							       	 	'parent' => $term_id,
							       	 	'order' => 'asc',
							       	 	'orderby' => 'term_id',
            
							    	));

							    	foreach($childtermarr as $child_key => $child_val){
							    		
							    		$childterm_tID[] =  $child_val->term_id;
							    		$childterm_tname[] =  $child_val->name;
							    		$childterm_title[] =  $child_val->slug;
							    		
							    		$childterm_tdescri[] =  $child_val->description;
							    		
							    		$par_tname = $term_title_arr[$termind-1];

							    		$keyname = esc_attr($par_tname.'_'.$child_val->slug);
							    		$keyname = str_replace("-","_",$keyname); 
							    		?>
							    		<input type="hidden" name="<?php echo $keyname; ?>" id="<?php echo $keyname; ?>" value="<?php echo $usermetadata[0][$keyname]; ?>">
							    		<input type="hidden" name="<?php echo $keyname.'price'; ?>" id="<?php echo $keyname.'price'; ?>" value="<?php echo $usermetadata[0][$keyname.'price']; ?>">
							    		<input type="hidden" name="<?php echo $keyname.'url'; ?>" id="<?php echo $keyname.'url'; ?>"  value="<?php echo $usermetadata[0][$keyname.'url']; ?>">

							    		<a class="nav-item nav-link <?php if($tabind2 == 1){ echo 'active'; } ?>" id="nav-tab<?php echo $tabind; ?>" data-toggle="tab" href="#tab<?php echo $tabind; ?>" role="tab" aria-controls="nav-home" aria-selected="true"><?php echo $child_val->name; ?></a>
							    		
							    		<?php
							    									
							   		 $tabind2++;
							   		 $tabind ++;
							    	}
								?>
							
							<!-- <a class="nav-item nav-link" id="nav-tab2" data-toggle="tab" href="#tab2" role="tab" aria-controls="nav-profile" aria-selected="false">Tab2</a>
							<a class="nav-item nav-link" id="nav-tab3" data-toggle="tab" href="#tab3" role="tab" aria-controls="nav-contact" aria-selected="false">Tab3</a>
							<a class="nav-item nav-link" id="nav-tab4" data-toggle="tab" href="#tab4" role="tab" aria-controls="nav-contact" aria-selected="false">Tab4</a> -->
						</div>
					</nav>


					<div class="tab-content" id="nav-tabContent">

						<?php
						
						$childtmind2 = 1;

						foreach($childterm_tID as $child_key){

							
							$childtab_Query = get_posts(array(
							    'showposts' => -1,
							    'post_type' => 'earchitect',
							    'tax_query' => array(
							        array(
							        'taxonomy' => 'earchitect_cat',
							        'field' => 'term_id',
							        'terms' => array($child_key))
							    ))
							);
							
							?>
							<div class="tab-pane fade show <?php if($childtmind2 == 1){ echo 'active'; } ?>" id="tab<?php echo $childtmind; ?>" role="tabpanel" aria-labelledby="nav-tab<?php echo $childtmind; ?>">
								<ul id="menu" style="padding: 0;list-style: none;">

									<?php 
									foreach($childtab_Query as $mypost){

								    		$childterm_ID[] =  $mypost->ID;
								    		$childterm_name[] =  $mypost->post_title;
								    		$postname = $mypost->post_name;

								    		$par_tname = $term_title_arr[$termind-1];
								    		$posttitle = $par_tname.'_'.$childterm_title[$childtmind-1];
								    		$posttitle = str_replace("-","_",$posttitle);

								    		$feat_img_url = get_the_post_thumbnail_url($mypost->ID, 'post-thumbnail');							    		
								    		$bg_url = get_field('background_image', $mypost->ID);
								    		$header_url = get_field('header_image_part', $mypost->ID);							    		
								    		
							    			?>
							    			
							    			<li>	
												<div class="form-radio-btn material-radio">
													<!-- data-title="<?php //echo $mypost->post_title; ?>" -->
													<!-- <?php //echo $childterm_title[$childtmind2-1]; ?> -->
													<input type="radio" data-headerimg="<?php echo $header_url; ?>" data-title="<?php echo $childterm_title[$childtmind-1]; ?>"  name="<?php echo $posttitle; ?>" class="radio-btn  material-radio-btn" value="<?php echo $mypost->post_title; ?>" >
													<input type="hidden" name="headerurl" id="headerurl" value="">


												    <div class="row">
												    	<div class="col-12 tab-bg-img" style="background-image: url(<?php echo $bg_url; ?>);">
												    <div class="row">
														<div class="col-3 tab-content-img">
												    		<img src="<?php echo $feat_img_url; ?>" width="120" height="100">
												    	</div>
												      	<div class="col-9 tab-content-inner ">
												      		<h4><?php echo $mypost->post_title; ?></h4>

												      		<?php
												      		if( have_rows('material', $mypost->ID) ):

															 	// loop through the rows of data
															    while ( have_rows('material', $mypost->ID) ) : the_row();

															        // display a sub field value
															        $room_type = get_sub_field('room_type', $mypost->ID)->post_title;								        
															        $material_price = get_sub_field('material_price', $mypost->ID);
															        $material_specification = get_sub_field('material_specification', $mypost->ID);

															        ?>
															        <span data-price="<?php echo $material_price; ?>"  data-room = "<?php echo $room_type; ?>" > <?php if($material_price){ echo $material_price.' &euro;'; } ?> </span>

															        <span  data-room = "<?php echo $room_type; ?>" ><?php if($material_specification){ echo $material_specification; } ?></span>

															        <?php
															    endwhile;										

															endif;	
												      		?>
												      		
												      	</div>
											      	</div>
											      	</div>
											      	</div>
											    </div>
											</li>
						    			<?php
						    			
						    			} ?>										
								</ul>
							</div>
							<?php						    	
						    $childtmind2++;
						    $childtmind++;
						    wp_reset_query();
						}	?>						
						
					</div>
				</div>
				<br><br>
			</div>
		</form>

    	<?php $termind++; }	?>

	</div>
    
     <!-- Javascript -->          
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script>
    	$(document).ready(function(){
    		 $(".button-2").hide();
		  	$(".button-1").show();
		  	$(".sel2").hide();
		  	$(".render_banu").hide();
		  				
		  	$(".wpbtn-2").css("color", "#dddddd");

		  $(".wpbtn-1").click(function(){
		    $(".button-2").hide();
		    $(".button-1").show();
		    $(".sel1").show();
		    $(".sel2").hide();
		    $(".render_cocina").show();
		    $(".render_banu").hide();
		    $(".wpbtn-1").css("color", "#000");
		    $(".wpbtn-2").css("color", "#dddddd");
		  });
		  $(".wpbtn-2").click(function(){
		  	
		    $(".button-1").hide();
		    $(".button-2").show();

		    $(".render_cocina").hide();
		    $(".render_banu").show();

		   	$(".sel1").hide();
		    $(".sel2").show();		    

		    $(".wpbtn-2").css("color", "#000");
		    $(".wpbtn-1").css("color", "#dddddd");
		  });
		});

		$('#menu li .form-radio-btn').on('click', function(){
		    $('li .form-radio-btn.current').removeClass('current');
		    $(this).addClass('current');
		});
    </script>

  <?php
}

add_shortcode('material_selection_form','wpnaw_get_materials');
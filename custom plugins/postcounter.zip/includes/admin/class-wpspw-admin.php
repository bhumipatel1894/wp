<?php
/**
 * Admin Class
 *
 * Handles the Admin side functionality of plugin
 *
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Wppc_Admin {
	
	function __construct() {
		
		// Action to register admin menu
		add_action( 'admin_menu', array($this, 'wppc_register_menu'), 9 );

		// Action to register plugin settings
		add_action( 'admin_init', array($this, 'wppc_register_settings') );

	}


	/**
	 * Function to register admin menus
	 * 
	 * @package Blog Designer - Post and Widget Pro
	 * @since 1.0.0
	 */
	function wppc_register_menu() {
		
		add_menu_page( 'Post Counter', 'Post Counter', 'manage_options', 'wppc-options',array($this, 'ad_form_function') , 'dashicons-media-spreadsheet' );
	}
	
	/**
	 * Function to handle the setting page html
	 * 
	 * @package Blog Designer - Post and Widget Pro
	 * @since 1.0.0
	 */
	function ad_form_function() {
		include_once( WP_PC_DIR . '/includes/admin/settings/wpspw-settings.php' );
	}
	

	/**
	 * Function register setings
	 * 
	 * @package Blog Designer - Post and Widget Pro
	 * @since 1.0.0
	 */
	function wppc_register_settings() {
		register_setting( 'wppc_plugin_options', 'wppc_options', array($this, 'wppc_validate_options') );
	}  // (option group name in detting_field, option name to save, callback fun)

	/**
	 * Validate Settings Options
	 * 
	 * @package Blog Designer - Post and Widget Pro
	 * @since 1.0.0
	 */
	function wppc_validate_options($input) {
		
		//$input['full_page_price_1'] 	= isset($input['full_page_price_1']) 	? wpspw_slashes_deep($input['full_page_price_1']) 		: '';
				
		return $input;
	}


}

$wppc_admin = new Wppc_Admin();
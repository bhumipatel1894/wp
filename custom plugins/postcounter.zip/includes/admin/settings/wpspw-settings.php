<?php
/**
 * Settings Page
 *
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// Taking some globals
global $wp_version;
?>

<div class="wrap wpspw-settings">

<h2><?php _e( 'Post Count Setting', 'postcounter' ); ?></h2><br />

<?php
// Success message 
if( isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true' ) {
	echo '<div id="message" class="updated notice notice-success is-dismissible">
			<p><strong>'.__("Your changes saved successfully.", "postcounter").'</strong></p>
		  </div>';
}
?>

<form action="options.php" method="POST" id="wppc-settings-form" class="wppc-settings-form">
	
	<?php
	    settings_fields( 'wppc_plugin_options' );
	    global $wppc_options;


	?>
	

	<!-- Layout Settings Starts -->
	<div id="wpspw-layout-sett" class="post-box-container wpspw-layout-sett">
		<div class="metabox-holder">
			<div class="meta-box-sortables ui-sortable">
				<div class="postbox">

					<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'Select Post types to display post counter', 'postcounter' ); ?></span>
						</h3>
						
						<div class="inside">
						<table class="form-table wpspw-custom-css-sett-tbl">
							<tbody>
								

								<?php
								$post_arr = get_post_types();

								$arrayA = array('page','attachment', 'revision', 'nav_menu_item', 'custom_css', 'customize_changeset', 'oembed_cache', 'user_request', 'wp_block');

							    			    

							    $newArray = array_diff($post_arr,$arrayA);
							    
							    ?>
							    <tr>
							    <?php
							    $i = 0;
							    
								foreach($newArray as $key => $val){ 
									$sel_value = wppc_get_option($val);
									
									?>
									<th scope="row">
									<label><input type="checkbox" value="<?php echo $val; ?>" <?php checked($val, $sel_value, true); ?> name="wppc_options[<?php echo $val; ?>]" /><?php _e($val, 'pmg'); ?></label> <br>
								</th>
								<?php $i++; }
								
								?>

								</tr>


								 

								<tr>
									<td colspan="4" valign="top" scope="row">
										<input type="submit" id="wppc-layout-sett-submit" name="wppc-settings-submit" class="button button-primary right wpspw-layout-sett-submit" value="<?php _e('Save Changes','postcounter'); ?>" />
									</td>
								</tr>
							</tbody>
						 </table>
					</div><!-- .inside -->
				</div><!-- .postbox -->
			</div><!-- .meta-box-sortables ui-sortable -->
		</div><!-- .metabox-holder -->
	</div><!-- #wpspw-layout-sett -->
	<!-- Layout Settings Ends -->

</form><!-- end .wpspw-settings-form -->

</div><!-- end .wpspw-settings -->
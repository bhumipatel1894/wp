<?php
/**
 * Plugin generic functions file
 *
 * @package Wp PostCounter
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;
//echo __FILE__;
/**
 * Update default settings
 * 
 * @package Wp PostCounter
 * @since 1.0.0
 */
function wppc_default_settings() {

	global $wppc_options;
	
	$wppc_options = array(
							
							'quarter_page_price_2'		=> '',
							
						);
	
	$default_options = apply_filters('wppc_options_default_values', $wppc_options );
	
	// Update default options
	update_option( 'wppc_options', $default_options );

	// Overwrite global variable when option is update
	$wppc_options = wppc_get_settings();
}

/**
 * Get Settings From Option Page
 * 
 * Handles to return all settings value
 * 
 * @package Wp PostCounter
 * @since 1.0.0
*/
function wppc_get_settings() {

	$options = get_option('wppc_options');
	
	$settings = is_array($options) 	? $options : array();
	
	return $settings;
}

/**
 * Get an option
 * Looks to see if the specified setting exists, returns default if not
 * 
 * @package Wp PostCounter
 * @since 1.0.0
 */
function wppc_get_option( $key = '', $default = false ) {
	global $wppc_options;

	$value = ! empty( $wppc_options[ $key ] ) ? $wppc_options[ $key ] : $default;
	$value = apply_filters( 'wppc_get_option', $value, $key, $default );
	return apply_filters( 'wppc_get_option_' . $key, $value, $key, $default );
}


/**
 * Escape Tags & Slashes
 *
 * Handles escapping the slashes and tags
 *
 * @package Wp PostCounter
 * @since 1.0.0
 */
function wppc_esc_attr($data) {
	return esc_attr( stripslashes($data) );
}

/**
 * Strip Slashes From Array
 * If $flag is passed then it will allow HTML
 *
 * @package Wp PostCounter
 * @since 1.0.0
 */
function wppc_slashes_deep($data = array(), $flag = false){
	
	if($flag != true) {
		$data = wppc_nohtml_kses($data);  // avoid html tag
	}

	$data = stripslashes_deep($data);
	return $data;
}

/**
 * Strip Html Tags 
 * 
 * It will sanitize text input fields. Strip html tags and escape characters)
 * 
 * @package Wp PostCounter
 * @since 1.0.0
 */
function wppc_nohtml_kses($data = array()){
	
	if ( is_array($data) ) {
		
		$data = array_map('wtwp_nohtml_kses', $data);
		
	} elseif ( is_string( $data ) ) {
		
		$data = wp_filter_nohtml_kses($data);
	}
	
	return $data;
}

/**
 * Function to unique number value
 * 
 * @package Wp PostCounter
 * @since 1.0.0
 */
function wppc_get_unique() {
	static $unique = 0;
	$unique++;

	return $unique;
}

function rm_post_view_count(){
	if ( is_single() ){
		global $post;
		$currposttype = $post->post_type;

		setPostViews($post->ID);

		$post_arr = get_post_types();
		$arrayA = array('page','attachment', 'revision', 'nav_menu_item', 'custom_css', 'customize_changeset', 'oembed_cache', 'user_request', 'wp_block');

		$newArray = array_diff($post_arr,$arrayA);

		foreach ($newArray as $key => $value) {

			$sel_value = wppc_get_option($value);
			
			if($currposttype == $sel_value){
				var_dump($currposttype);

				
				?>
				<div style="  bottom: 37px; left: 0px; background: lightseagreen;  padding: 4px 10px; position: fixed;"><?php echo getPostViews($post->ID); ?> </div>
				<?php

			}
		}

	}
}
add_action('wp_head', 'rm_post_view_count');

// function to display number of posts.
function getPostViews($postID){
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return "0 View";
    }
    return $count.' Views';
}
 
// function to count views.
function setPostViews($postID) {
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}
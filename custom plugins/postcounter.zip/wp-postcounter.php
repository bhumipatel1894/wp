<?php
/**
 * Plugin Name: Wp PostCounter
 * Plugin URI: http://alchemytech.ca
 * Description: Display Post View Count for all post types  
 * Text Domain: wp-postCounter
 * Domain Path: /languages/
 * Author: alchemytec | Contributor: Bhumi Patel
 * Author URI: http://alchemytech.ca
 * Contributors: Bhumi Patel
 * Version: 1.1
*/

// Exit if accessed directly
// abs pth is start ffrom folder path upto proj folder
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Basic plugin definitions
 * 
 * @package wp-postCounter
 * @since 1.0.0
 */
if( !defined( 'WP_PC_VERSION' ) ) {
    define( 'WP_PC_VERSION', '1.1' ); // Version of plugin
}
if( !defined( 'WP_PC_DIR' ) ) {
    define( 'WP_PC_DIR', dirname( __FILE__ ) ); // Plugin dir
}
if( !defined( 'WP_PC_URL' ) ) {
    define( 'WP_PC_URL', plugin_dir_url( __FILE__ ) ); // Plugin url
}
if( !defined( 'WP_PC_PLUGIN_BASENAME' ) ) {
    define( 'WP_PC_PLUGIN_BASENAME', plugin_basename( __FILE__ ) ); // Plugin base name
}

if( !defined( 'WPSPW_META_PREFIX' ) ) {
    define( 'WPSPW_META_PREFIX', '_wppc_' ); // Plugin metabox prefix
}

/**
 * Load Text Domain
 * This gets the plugin ready for translation
 * 
 * @package wp-postCounter
 * @since 1.0.0
 */
function wp_pc_load_textdomain() {
    load_plugin_textdomain( 'blog-designer-for-post-and-widget', false, dirname( plugin_basename(__FILE__) ) . '/languages/' );
}

// Action to load plugin text domain
add_action('plugins_loaded', 'wp_pc_load_textdomain');

/**
 * Activation Hook
 * 
 * Register plugin activation hook.
 * 
 * @package wp-postCounter
 * @since 1.0.0
 */
register_activation_hook( __FILE__, 'wp_pc_install' );

/**
 * Deactivation Hook
 * 
 * Register plugin deactivation hook.
 * 
 * @package wp-postCounter
 * @since 1.0.0
 */
register_deactivation_hook( __FILE__, 'wp_pc_uninstall');

/**
 * Plugin Activation Function
 * Does the initial setup, sets the default values for the plugin options
 * 
 * @package wp-postCounter
 * @since 1.0.0
 */
function wp_pc_install() {
      
}
 
/**
 * Plugin Deactivation Function
 * Delete  plugin options
 * 
 * @package wp-postCounter
 * @since 1.0.0
 */
function wp_pc_uninstall() {
    // Uninstall functionality
}

/**
 * Function to display admin notice of activated plugin.
 */
function wp_pc_admin_notice() {
    
    $dir = WP_PC_DIR . '/wp-postcounter/wp-postcounter.php';
    
    // If PRO plugin is active and free plugin exist
    if( is_plugin_active( 'wp-postcounter/wp-postcounter.php' ) && file_exists($dir)) {
        
        global $pagenow;
        
        if ( $pagenow == 'plugins.php' && current_user_can( 'install_plugins' ) ) {
            echo '<div id="message" class="updated notice is-dismissible"><p><strong>Thank you for activating Post Counter Plugin</strong>. </p></div>';
        }

    }
}

// Action to display notice
add_action( 'admin_notices', 'wp_pc_admin_notice');



/***** Updater Code Ends *****/

// Global variables
global $wppc_options;

// Functions file
require_once( WP_PC_DIR . '/includes/wpspw-functions.php' );
$wppc_options = wppc_get_settings();

// Admin Class
require_once( WP_PC_DIR . '/includes/admin/class-wpspw-admin.php' );

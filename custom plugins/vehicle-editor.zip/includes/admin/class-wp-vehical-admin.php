<?php
/**
 * Admin Class
 *
 * Handles the Admin side functionality of plugin
 *
 * @package Vehials
 * @since 1.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Wp_Vehical_Admin {

	function __construct() {

		// Filter to add row data
		add_filter( 'post_row_actions', array($this, 'wp_vehical_add_post_row_data'), 10, 2 );

		
	}

	/**
	 * Function to add custom quick links at post listing page
	 * 
	 * @package Vehials
	 * @since 1.0
	 */
	function wp_vehical_add_post_row_data( $actions, $post ) {
		
		if( $post->post_type == WP_PAP_PRO_POST_TYPE ) {
			return array_merge( array( 'wp_pap_pro_id' => 'ID: ' . $post->ID ), $actions );
		}
		return $actions;
	}

}

$wp_vehical_admin = new Wp_Vehical_Admin();
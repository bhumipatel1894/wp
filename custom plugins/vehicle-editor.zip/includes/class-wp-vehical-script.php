<?php
/**
 * Script Class
 *
 * Handles the script and style functionality of plugin
 *
 * @package Vehials
 * @since 1.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class WP_Vehials_Script{
	
	function __construct() {
		
		// Action to add style at front side
		add_action( 'wp_enqueue_scripts', array($this, 'wp_vehicals_front_style') );
		
		// Action to add script at front side
		add_action( 'wp_enqueue_scripts', array($this, 'wp_vehicals_front_script') );
				
	}

	/**
	 * Function to add style at front side
	 * 
	 * @package Vehials
	 * @since 1.0
	 */
	function wp_vehicals_front_style() {

		// Registring and enqueing public css
		wp_register_style( 'wp-vehicals-public-css', WP_PAP_PRO_URL.'assets/css/wp-vehicals-public.css', null, WP_PAP_PRO_VERSION );
		wp_enqueue_style( 'wp-vehicals-public-css' );

		// Registring and enqueing slick css		
		if( !wp_style_is( 'wpos-slick-style', 'registered' ) ) {
			wp_register_style( 'wpos-slick-style', WP_PAP_PRO_URL.'assets/css/slick.css', array(), WP_PAP_PRO_VERSION );
			wp_enqueue_style( 'wpos-slick-style');	
		}
	}
	
	/**
	 * Function to add script at front side
	 * 
	 * @package Vehials
	 * @since 1.0
	 */
	function wp_vehicals_front_script() {

		// Registring slick slider script
		if( !wp_script_is( 'wpos-slick-jquery', 'registered' ) ) {
			wp_register_script( 'wpos-slick-jquery', WP_PAP_PRO_URL. 'assets/js/slick.min.js', array('jquery'), WP_PAP_PRO_VERSION, true);
		}
		
		// Registring portfolio script
		wp_register_script( 'wp-vehicals-portfolio-js', WP_PAP_PRO_URL.'assets/js/wp-vehicals-portfolio.js', array('jquery'), WP_PAP_PRO_VERSION, true );

		// Registring public script
		wp_register_script( 'wp-vehicals-public-js', WP_PAP_PRO_URL.'assets/js/wp-vehicals-public.js', array('jquery'), WP_PAP_PRO_VERSION, true );
		wp_localize_script( 'wp-vehicals-public-js', 'WpPap', array(
															'is_mobile' 		=>	(wp_is_mobile()) 			? 1 : 0,
															'is_old_browser'	=> 	wp_vehicals_old_browser() 	? 1 : 0,
														));
	}

}

$wp_vehials_script = new WP_Vehials_Script();
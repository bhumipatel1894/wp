<?php
/**
 * 'vehicals_list_filter' Shortcode
 * 
 * @package  Vehials
 * @since 1.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

if( function_exists('acf_add_local_field_group') ):

function wp_vehicals_list_shortcode( $atts, $content = '') {

	// Shortcode Parameter
	extract(shortcode_atts(array(
		
	), $atts, 'vehicals_list_filter'));
	
	// Taking some globals
	global $post;
	
	$wppapterms = get_terms( array(
			'taxonomy' 		=> WP_PAP_PRO_CAT,
			'hide_empty' 	=> true,
			'fields'		=> 'id=>name',			
			'order'			=> 'desc',	
			'orderby' => 'name',
			'parent' => 0
		)
	);

	// If category is there
	if( !is_wp_error($wppapterms) && !empty($wppapterms) ) {
		
		// Getting ids 
		$wppap_cats = array_keys( $wppapterms );

	ob_start(); ?>	

	<div id="content" role="main" class="vehicle-listing">
     <h3 class="heading-primary">Medium Duty Trucks - Tank Trucks - Gasoline / Fuel</h3>
  
        <ul id="vahicle_tabs">
        	<?php 
        	$catindex = 0;
        	foreach($wppapterms as $vehcat){ 
        		$catindex++; ?>

        		<li><a id="tab<?php echo $catindex; ?>"><?php echo $vehcat; ?></a></li>        	
        	<?php } ?>              
        </ul>

        <?php 
        // Query Parameter for get posts by cat id
        $catpostind = 0;
        foreach ($wppap_cats as $catkey => $catvalue) {
        	$catpostind++;        		
		    	
		        $term_children = get_term_children($catvalue, WP_PAP_PRO_CAT); 

		        $args = array ( 
								'post_type'      		=> WP_PAP_PRO_POST_TYPE,
								'post_status' 			=> array( 'publish' ),			
								'posts_per_page' 		=> -1,
								'ignore_sticky_posts'	=> true,
							);
		        $cat_arr = get_term( $catvalue);
						
				$cat_name = $cat_arr->name;

		        if(!empty($term_children)){ ?>

		        	<div class="container-vehicle" id="tab<?php echo $catpostind; ?>C">
					    <h2><?php echo $cat_name; ?></h2>

		        	<?php foreach($term_children as $child_term){
		        		
		        		// Category Parameter	
						$child_args['tax_query'] = array(
											array(
												'taxonomy' 			=> WP_PAP_PRO_CAT,
												'field' 			=> 'term_id',
												'terms' 			=> $child_term,		
												'order'			=> 'desc',
											)
										);
						$child_query 			= new WP_Query($child_args);
						$child_post_count 	= $child_query->post_count;

						$child_cat_arr = get_term( $child_term);							
						$child_cat_name = $child_cat_arr->name;
						?>

						<div class="vehiclecat-box">
					        <h3 class="heading-primary"><?php echo $child_cat_name; ?><br></h3>
					     	<?php

							while ($child_query->have_posts()) : $child_query->the_post();
							
								$portfolio_img 			= wp_vehicals_get_image_src( get_post_thumbnail_id($post->ID) );
								$portfolio_url 			= get_post_permalink($post->ID);
								?>

					                <div class="vehiclecat-list">
					                    <div class="porto-image-frame "><a href="<?php echo $portfolio_url; ?>" title="" target="_self"><img alt="" src="<?php echo $portfolio_img; ?>" class="img-responsive img-rounded img-box-shadow"></a></div>

					                    <div class="vehicle-description">
					                        <h3><strong><?php echo get_the_title(); ?> </strong></h3>

					                         <?php 

				                        $stocknum = get_field( "stock_number", $post->ID );
				                        $mileage = get_field( "mileage", $post->ID );
				                        $horsepower = get_field( "horsepower", $post->ID );
				                        $engine_manufacturer = get_field( "engine_manufacturer", $post->ID ); 
				                        $vehicle_contact = get_field( "contact", $post->ID ); 

				                       ?>
				                        <p> 

				                        <?php if($stocknum){ ?>
				                        	<strong>Stock Number:</strong> 
				                        	<?php echo  $stocknum; ?>
				                        	<br> 
				                       <?php } 
				                        if($mileage){  ?>
				                        	 <strong>Mileage:</strong> 
				                        	 <?php echo  $mileage; ?>
				                        	 <br> 
				                       <?php } 
				                        if($engine_manufacturer){ ?>
				                        	<strong>Engine Manufacturer:</strong> 
				                        	<?php echo  $engine_manufacturer; ?>
				                        	<br> 
				                        <?php } 
				                        if($horsepower){ ?>
				                        	<strong>Horsepower:</strong> 
				                        	<?php echo  $horsepower;
				                          } 
				                        ?>
					                      
					                    </div>

					                    <div class="vehicle-buttons">
					                        <a class="pricing-btn vc_btn3 vc_btn3-shape-square vc_btn3-block btn btn-lg btn-secondary" href="tel:<?php echo $vehicle_contact; ?>" title="">Call For Pricing</a>
					                        <a class="detail-btn vc_btn3 vc_btn3-shape-square vc_btn3-block btn btn-lg btn-primary" href="<?php echo $portfolio_url; ?>" title="">View Details</a>
					                    </div>
					                </div>
					        
								<?php endwhile; ?>  
							</div>						

		        		<?php } //end foreach chield terms ?>
		        	</div>
		        	<?php
		        	//wp_reset_query(); // Reset WP Query


		        } else{  // No Chield cat available 
		        	
		        	// Category Parameter	
					$args['tax_query'] = array(
											array(
												'taxonomy' 			=> WP_PAP_PRO_CAT,
												'field' 			=> 'term_id',
												'terms' 			=> $catvalue,		
												'order'			=> 'desc',
											)
										);

					// WP Query
					$query 			= new WP_Query($args);
					$post_count 	= $query->post_count;
					
					$cat_arr = get_term( $catvalue);						
					$cat_name = $cat_arr->name;
					?>
					<div class="container-vehicle" id="tab<?php echo $catpostind; ?>C">
				            <h2><?php echo $cat_name; ?></h2>
				    <?php
					while ($query->have_posts()) : $query->the_post();
						
						$portfolio_img 			= wp_vehicals_get_image_src( get_post_thumbnail_id($post->ID) );
						$portfolio_url 			= get_post_permalink($post->ID);
						
						?>		

				            <div class="vehiclecat-box">
				                
				                <div class="vehiclecat-list">
				                    <div class="porto-image-frame "><a href="<?php echo $portfolio_url; ?>" title="" target="_self"><img alt="" src="<?php echo $portfolio_img; ?>" class="img-responsive img-rounded img-box-shadow"></a></div>

				                    <div class="vehicle-description">
				                        <h3><strong><?php echo get_the_title(); ?> </strong></h3>

				                        <?php 

				                        $stocknum = get_field( "stock_number", $post->ID );
				                        $mileage = get_field( "mileage", $post->ID );
				                        $horsepower = get_field( "horsepower", $post->ID );
				                        $engine_manufacturer = get_field( "engine_manufacturer", $post->ID ); 

				                       ?>
				                        <p> 

				                        <?php if($stocknum){ ?>
				                        	<strong>Stock Number:</strong> 
				                        	<?php echo  $stocknum; ?>
				                        	<br> 
				                       <?php } 
				                        if($mileage){  ?>
				                        	 <strong>Mileage:</strong> 
				                        	 <?php echo  $mileage; ?>
				                        	 <br> 
				                       <?php } 
				                        if($engine_manufacturer){ ?>
				                        	<strong>Engine Manufacturer:</strong> 
				                        	<?php echo  $engine_manufacturer; ?>
				                        	<br> 
				                        <?php } 
				                        if($horsepower){ ?>
				                        	<strong>Horsepower:</strong> 
				                        	<?php echo  $horsepower;
				                          } 
				                        ?>
				                        </p>
				                    </div>

				                    <div class="vehicle-buttons">
				                        <a class="pricing-btn vc_btn3 vc_btn3-shape-square vc_btn3-block btn btn-lg btn-secondary" href="tel:+19132793077" title="">Call For Pricing</a>
				                        <a class="detail-btn vc_btn3 vc_btn3-shape-square vc_btn3-block btn btn-lg btn-primary" href="<?php echo $portfolio_url; ?>" title="">View Details</a>
				                    </div>
				                </div>
				                
				            </div>

				       
				        <?php
					endwhile;
					?>  </div> <?php
		         } // end if no chield 		

        } /*  end foreach catids */		
        ?>
          

    </div>
<script type="text/javascript">
    jQuery(document).ready(function($) {

        $('#vahicle_tabs li a:not(:first)').addClass('inactive');
        $('.container-vehicle').hide();
        $('.container-vehicle:first').show();
            
        $('#vahicle_tabs li a').click(function(){
            var t = $(this).attr('id');
          if($(this).hasClass('inactive')){ //this is the start of our condition 
            $('#vahicle_tabs li a').addClass('inactive');           
            $(this).removeClass('inactive');
            
            $('.container-vehicle').hide();
            $('#'+ t + 'C').fadeIn('slow');
         }
        });

});
</script>
		<?php
		
		wp_reset_query(); // Reset WP Query

		$content .= ob_get_clean();
		return $content;
	}// End of category check
}

// 'vehicals_list_filter' shortcode
add_shortcode('vehicals_list_filter', 'wp_vehicals_list_shortcode');

endif;
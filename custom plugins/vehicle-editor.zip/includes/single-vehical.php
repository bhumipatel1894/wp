<?php
//global $post;

global $post; 

if( function_exists('acf_add_local_field_group') ):

//$vehc_title = $post->post_title;
$vehc_id 					= $post->ID;

if($vehc_id ){
	// Vehical Description
$vehc_title 				= get_field( "vehical_display_title", $vehc_id);
$vehc_descri 				= get_field( "vehical_description", $vehc_id);
// Vehical Category Specific
$vehc_capacity 				= get_field( "capacity", $vehc_id);
// Vehical General Specification
$vehc_quantity 				= get_field( "quantity", $vehc_id);
$vehc_stock_number			= get_field( "stock_number", $vehc_id);
$vehc_year					= get_field( "year", $vehc_id);
$vehc_manufacturer 			= get_field( "manufacturer", $vehc_id);
$vehc_model					= get_field( "model", $vehc_id);
$vehc_condition				= get_field( "condition", $vehc_id);
$vehc_mileage				= get_field( "mileage", $vehc_id);
$vehc_vin 					= get_field( "vin", $vehc_id);
//Vehical Engine 1
$vehc_drive 				= get_field( "drive", $vehc_id);
$vehc_suspension 			= get_field( "suspension", $vehc_id);
$vehc_number_of_rear_axles 	= get_field( "number_of_rear_axles", $vehc_id);
$vehc_wheels 				= get_field( "wheels", $vehc_id);
$vehc_gross_vehicle_weight 	= get_field( "gross_vehicle_weight", $vehc_id);
$vehc_front_axle_weight 	= get_field( "front_axle_weight", $vehc_id);
$vehc_rear_axle_weight 		= get_field( "rear_axle_weight", $vehc_id);
//Vehical Engine 2
$vehc_horsepower 			= get_field( "horsepower", $vehc_id);
$vehc_engine_manufacturer 	= get_field( "engine_manufacturer", $vehc_id);
$vehc_engine_type 			= get_field( "engine_type", $vehc_id);
$vehc_engine_displacement 	= get_field( "engine_displacement", $vehc_id);
$vehc_fuel_type 			= get_field( "fuel_type", $vehc_id);
//Vehical Gallary
$vehc_gallary_images 		= get_field( "gallary_images", $vehc_id);
// Vehical Interior
$vehc_drive_side 			= get_field( "drive_side", $vehc_id);
$vehc_ac_condition 			= get_field( "ac_condition", $vehc_id);
// Vehical Powertrain
$vehc_transmission 			= get_field( "transmission", $vehc_id);
$transmission_manufacturer 	= get_field( "transmission_manufacturer", $vehc_id);

//contact Information
$contact 					= get_field( "contact", $vehc_id);
$address 					= get_field( "address", $vehc_id);
$contact_person 			= get_field( "contact_person", $vehc_id);
}

?>

<link rel='stylesheet'  href='<?php echo get_template_directory_uri(); ?>/css/slick.css' type='text/css' media='all' />
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/magnific-popup.css">
  
<div id="content" role="main" class="vehicle-detail">

	<div class="vehicle-detail-left">
			<h3><?php echo $vehc_title ; ?></h3>
			<p class="theme-text-color"><strong>Description</strong></p>
			<div class="vehicle-description"><p><?php echo $vehc_descri ; ?></p></div>

			<p class="m-bottom-10"><strong>Contact Information</strong></p>

			<div class="fixed-column6 left print-full">
					<div><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp;<?php echo $address; ?>
					</div>
					<div class="non-mobile-numbers hide-785">
						<div class="mobile-call"><span class="bold hide-785">Phone:</span>&nbsp;<a class="js-phone-clicktotrack underline call-it " href="tel:<?php echo $contact; ?>"><span class="hide-785"><?php echo $contact; ?></span></a>
						</div>
					</div>
					<div class="contact"><span class="bold">Contact:</span>&nbsp;<?php echo $contact_person; ?></div>
				</div>


          <div class="btn-details">
			<a class="btn-modal ult-responsive btn-primary btn-modal-lg overlay-show ult-align-left" id="open-popup" href="#my-popup">Order Now</a>
			
			<a class="vc_btn3 vc_btn3-shape-rounded btn btn-lg btn-secondary" href="tel:<?php echo $contact; ?>" title="">Call for Pricing</a>
		 </div>

	</div>

	<div class="vehicle-detail-right">
	<?php if(!empty($vehc_gallary_images)){ ?>

		<div class="slick-carousel">

			<?php foreach($vehc_gallary_images as $gallery){ ?>
				
				<div>
		    		<img src="<?php echo $gallery['url']; ?>">
		  		</div>
			<?php } ?>		  
      	</div>

		<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.magnific-popup.min.js"></script>
	  	<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/slick.min.js"></script>

	<?php }  ?>		
	</div>

	<div class="specification-vehicle">
		<h3 class="spec-h3">Specifications</h3>
		<div class="spec-left">
			<div id="tablepress-1_wrapper" class="dataTables_wrapper no-footer">
				<table id="tablepress-1" class="tablepress tablepress-id-1 dataTable no-footer" role="grid">
					<thead>
						<tr class="row-1 odd" role="row">
							<th class="column-1 sorting_disabled" rowspan="1" colspan="1" style="width: 187px;">General</th>
							<th class="column-2 sorting_disabled" rowspan="1" colspan="1" style="width: 321px;">&nbsp;</th>
						</tr>
					</thead>
					<tbody class="row-hover">

						<tr class="row-2 even" role="row">
							<td class="column-1">Quantity</td>
							<td class="column-2"><?php echo $vehc_quantity; ?></td>
						</tr>
						<tr class="row-3 odd" role="row">
							<td class="column-1">Stock Number</td>
							<td class="column-2"><?php echo $vehc_stock_number; ?></td>
						</tr>
						<tr class="row-4 even" role="row">
							<td class="column-1">Year</td>
							<td class="column-2"><?php echo $vehc_year; ?></td>
						</tr>
						<tr class="row-5 odd" role="row">
							<td class="column-1">Manufacturer</td>
							<td class="column-2"><?php echo $vehc_manufacturer; ?></td>
						</tr>
						<tr class="row-6 even" role="row">
							<td class="column-1">Model</td>
							<td class="column-2"><?php echo $vehc_model; ?></td>
						</tr>
						<tr class="row-7 odd" role="row">
							<td class="column-1">Condition</td>
							<td class="column-2"><?php echo $vehc_condition; ?></td>
						</tr>
						<tr class="row-8 even" role="row">
							<td class="column-1">Mileage</td>
							<td class="column-2"><?php echo $vehc_mileage; ?></td>
						</tr>
						<tr class="row-9 odd" role="row">
							<td class="column-1">VIN</td>
							<td class="column-2"><?php echo $vehc_vin; ?></td>
						</tr>
					</tbody>
				</table>
			</div>
      <div id="tablepress-3_wrapper" class="dataTables_wrapper no-footer">
		<table id="tablepress-3" class="tablepress tablepress-id-3 dataTable no-footer" role="grid">
			<thead>
				<tr class="row-1 odd" role="row">
					<th class="column-1 sorting_disabled" rowspan="1" colspan="1" style="width: 338px;">Engine</th>
					<th class="column-2 sorting_disabled" rowspan="1" colspan="1" style="width: 170px;">&nbsp;</th>
				</tr>
			</thead>
			<tbody class="row-hover">				

				<tr class="row-2 even" role="row">
					<td class="column-1">Drive</td>
					<td class="column-2"><?php echo $vehc_drive; ?>
						<br>
					</td>
				</tr>
				<tr class="row-3 odd" role="row">
					<td class="column-1">Suspension</td>
					<td class="column-2"><?php echo $vehc_suspension; ?>
						<br>
					</td>
				</tr>
				<tr class="row-4 even" role="row">
					<td class="column-1">Number of Rear Axles</td>
					<td class="column-2"><?php echo $vehc_number_of_rear_axles; ?>
						<br>
					</td>
				</tr>
				<tr class="row-5 odd" role="row">
					<td class="column-1">Wheels</td>
					<td class="column-2"><?php echo $vehc_wheels; ?>
						<br>
					</td>
				</tr>
				<tr class="row-6 even" role="row">
					<td class="column-1">Gross Vehicle Weight</td>
					<td class="column-2"><?php echo $vehc_gross_vehicle_weight; ?>
						<br>
					</td>
				</tr>
				<tr class="row-7 odd" role="row">
					<td class="column-1">Front Axle Weight</td>
					<td class="column-2"><?php echo $vehc_front_axle_weight; ?>
						<br>
					</td>
				</tr>
				<tr class="row-8 even" role="row">
					<td class="column-1">Rear Axle Weight</td>
					<td class="column-2"><?php echo $vehc_rear_axle_weight; ?>
						<br>
					</td>
				</tr>
			</tbody>
		</table>
      </div>

		</div>
		<div class="spec-right">
			<div id="tablepress-2_wrapper" class="dataTables_wrapper no-footer">
				<table id="tablepress-2" class="tablepress tablepress-id-2 dataTable no-footer" role="grid">
					<thead>
						<tr class="row-1 odd" role="row">
							<th class="column-1 sorting_disabled" rowspan="1" colspan="1" style="width: 344px;">Engine</th>
							<th class="column-2 sorting_disabled" rowspan="1" colspan="1" style="width: 164px;">&nbsp;</th>
						</tr>
					</thead>
					<tbody class="row-hover">

						<tr class="row-2 even" role="row">
							<td class="column-1">Horsepower</td>
							<td class="column-2"><?php echo $vehc_horsepower; ?>
								<br>
							</td>
						</tr>
						<tr class="row-3 odd" role="row">
							<td class="column-1">Engine Manufacturer</td>
							<td class="column-2"><?php echo $vehc_engine_manufacturer; ?>
								<br>
							</td>
						</tr>
						<tr class="row-4 even" role="row">
							<td class="column-1">Engine Type</td>
							<td class="column-2"><?php echo $vehc_engine_type; ?>
								<br>
							</td>
						</tr>
						<tr class="row-5 odd" role="row">
							<td class="column-1">Engine Displacement</td>
							<td class="column-2"><?php echo $vehc_engine_displacement; ?>
								<br>
							</td>
						</tr>
						<tr class="row-6 even" role="row">
							<td class="column-1">Fuel Type</td>
							<td class="column-2"><?php echo $vehc_fuel_type; ?>
								<br>
							</td>
						</tr>
					</tbody>
				</table>
			</div> 

			<div id="tablepress-4_wrapper" class="dataTables_wrapper no-footer">
				<table id="tablepress-4" class="tablepress tablepress-id-4 dataTable no-footer" role="grid">
					<thead>
						<tr class="row-1 odd" role="row">
							<th class="column-1 sorting_disabled" rowspan="1" colspan="1" style="width: 361px;">Powertrain</th>
							<th class="column-2 sorting_disabled" rowspan="1" colspan="1" style="width: 147px;">&nbsp;</th>
						</tr>
					</thead>
					<tbody class="row-hover">
						<tr class="row-2 even" role="row">
							<td class="column-1">Transmission</td>
							<td class="column-2"><?php echo $vehc_transmission; ?>
								<br>
							</td>
						</tr>
						<tr class="row-3 odd" role="row">
							<td class="column-1">Transmission Manufacturer</td>
							<td class="column-2"><?php echo $transmission_manufacturer; ?>
								<br>
							</td>
						</tr>
					</tbody>
				</table>
			</div>

		<div id="tablepress-6_wrapper" class="dataTables_wrapper no-footer">
			<table id="tablepress-6" class="tablepress tablepress-id-6 dataTable no-footer" role="grid">
				<thead>
					<tr class="row-1 odd" role="row">
						<th class="column-1 sorting_disabled" rowspan="1" colspan="1" style="width: 329px;">Category Specific
							<br>
						</th>
						<th class="column-2 sorting_disabled" rowspan="1" colspan="1" style="width: 179px;">&nbsp;</th>
					</tr>
				</thead>
				<tbody class="row-hover">
					<tr class="row-2 even" role="row">
						<td class="column-1">Capacity</td>
						<td class="column-2"><?php echo $vehc_capacity; ?>
							<br>
						</td>
					</tr>
				</tbody>
			</table>
		</div>

		<div id="tablepress-5_wrapper" class="dataTables_wrapper no-footer">
			<table id="tablepress-5" class="tablepress tablepress-id-5 dataTable no-footer" role="grid">
				<thead>
					<tr class="row-1 odd" role="row">
						<th class="column-1 sorting_disabled" rowspan="1" colspan="1" style="width: 244px;">Interior</th>
						<th class="column-2 sorting_disabled" rowspan="1" colspan="1" style="width: 264px;">&nbsp;</th>
					</tr>
				</thead>
				<tbody class="row-hover">
					<tr class="row-2 even" role="row">
						<td class="column-1">Drive Side</td>
						<td class="column-2"><?php echo $vehc_drive_side; ?></td>
					</tr>
					<tr class="row-3 odd" role="row">
						<td class="column-1">A/C Condition</td>
						<td class="column-2"><?php echo $vehc_ac_condition; ?>
							<br>
						</td>
					</tr>
				</tbody>
			</table>
		</div>


		</div>
	</div>

    </div>

    <div id="my-popup" class="mfp-hide white-popup">
	   <div class="gform_heading">
		<h3 class="gform_title">inventory</h3>  <span class="gform_description"></span>
	</div>
	<div class="gform_body">
		<ul id="gform_fields_8" class="gform_fields top_label form_sublabel_below description_below">
			<li id="field_8_1" class="gfield gfield_contains_required field_sublabel_below field_description_below gfield_visibility_visible">
				<div class="ginput_complex ginput_container no_prefix has_first_name no_middle_name has_last_name no_suffix gf_name_has_2 ginput_container_name gfield_trigger_change" id="input_8_1"> <span id="input_8_1_3_container" class="name_first"> <input type="text" name="input_1.3" id="input_8_1_3" value="" aria-label="First name" tabindex="2" aria-required="true" aria-invalid="false"> <label for="input_8_1_3">First</label> </span>  <span id="input_8_1_6_container" class="name_last"> <input type="text" name="input_1.6" id="input_8_1_6" value="" aria-label="Last name" tabindex="4" aria-required="true" aria-invalid="false"> <label for="input_8_1_6">Last</label> </span>
				</div>
			</li>
			<li id="field_8_2" class="gfield field_sublabel_below field_description_below gfield_visibility_visible">
				<label class="gfield_label" for="input_8_2">Company</label>
				<div class="ginput_container ginput_container_text">
					<input name="input_2" id="input_8_2" type="text" value="" class="large" tabindex="6" aria-invalid="false">
				</div>
			</li>
			<li id="field_8_3" class="gfield gfield_contains_required field_sublabel_below field_description_below gfield_visibility_visible">
				<label class="gfield_label gfield_label_before_complex" for="input_8_3_1">Address<span class="gfield_required">*</span>
				</label>
				<div class="ginput_container ginput_container_text">
					<input name="input_2" id="input_country" type="text" value="" class="large" tabindex="6" aria-invalid="false">
				</div>
			</li>
			<li id="field_8_1" class="gfield gfield_contains_required field_sublabel_below field_description_below gfield_visibility_visible">
				<div class="ginput_complex ginput_container no_prefix has_first_name no_middle_name has_last_name no_suffix gf_name_has_2 ginput_container_name gfield_trigger_change" id="input_8_1"> <span id="input_8_1_3_container" class="name_first"> <input type="text" name="city" id="input_8_1_3" value="" aria-label="First name" tabindex="2" aria-required="true" aria-invalid="false"> <label for="input_8_1_3">City</label> </span>  <span id="input_8_1_6_container" class="name_last"> <input type="text" name="state" id="input_8_1_6" value="" aria-label="Last name" tabindex="4" aria-required="true" aria-invalid="false"> <label for="input_8_1_6">State / Province / Region</label> </span>
				</div>
			</li>
			<li id="field_8_1" class="gfield gfield_contains_required field_sublabel_below field_description_below gfield_visibility_visible">
				<div class="ginput_complex ginput_container no_prefix has_first_name no_middle_name has_last_name no_suffix gf_name_has_2 ginput_container_name gfield_trigger_change" id="input_8_1"> <span id="input_8_1_3_container" class="name_first"> <input type="text" name="postal-code" id="input_8_1_3" value="" aria-label="First name" tabindex="2" aria-required="true" aria-invalid="false"> <label for="input_8_1_3">ZIP / Postal Code</label> </span>  <span id="input_8_1_6_container" class="name_last"> <input type="text" name="country" id="input_8_1_6" value="" aria-label="Last name" tabindex="4" aria-required="true" aria-invalid="false"> <label for="input_8_1_6">Country</label> </span>
				</div>
			</li>
			<li id="field_8_4" class="gfield gfield_contains_required field_sublabel_below field_description_below gfield_visibility_visible">
				<label class="gfield_label" for="input_8_4">Phone<span class="gfield_required">*</span>
				</label>
				<div class="ginput_container ginput_container_phone">
					<input name="input_4" id="input_8_4" type="text" value="" class="large" tabindex="14" placeholder="Phone Number" aria-required="true" aria-invalid="false">
				</div>
			</li>
			<li id="field_8_5" class="gfield gfield_contains_required field_sublabel_below field_description_below gfield_visibility_visible">
				<label class="gfield_label" for="input_8_5">Email<span class="gfield_required">*</span>
				</label>
				<div class="ginput_container ginput_container_email">
					<input name="input_5" id="input_8_5" type="text" value="" class="large" tabindex="15" placeholder="Email">
				</div>
			</li>
			<li id="field_8_6" class="gfield field_sublabel_below field_description_below gfield_visibility_visible">
				<label class="gfield_label" for="input_8_6">Additional Details</label>
				<div class="ginput_container ginput_container_textarea">
					<textarea name="input_6" id="input_8_6" class="textarea medium" tabindex="16" aria-invalid="false" rows="10" cols="50"></textarea>
				</div>
			</li>
		</ul>
	</div>
	<div class="gform_footer top_label">
		<input type="submit" id="gform_submit_button_8" class="gform_button button" value="Submit" >
	</div>
	</div>
<script type="text/javascript">
    jQuery(document).ready(function($) {
    	$('.slick-carousel').slick({
		  infinite: true,
		  slidesToShow: 1, 
		  slidesToScroll: 1, 
		  arrows: false, 
		  dots: true,
		  autoplay:true,
		  autoplaySpeed:3000,
		  speed:600,
		  pauseOnHover:true,
		});

	//magnific popup
     $('#open-popup').magnificPopup({
		  type:'inline',
		  closeOnBgClick:false,
		  closeBtnInside:true,
       });

});
</script>



  

<?php endif;
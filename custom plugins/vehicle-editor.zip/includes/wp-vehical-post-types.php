<?php
/**
 * Register plugin post type functionality
 *
 * @package Vehicle
 * @since 1.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Function to register post type
 * 
 * @package Vehials
 * @since 1.0
 */
function wp_vehicals_register_post_type() {
	
	$wp_vehicals_post_lbls = apply_filters( 'wp_vehicals_post_labels', array(
								'name'                 	=> __('Vehicles', 'vehicals'),
								'singular_name'        	=> __('Vehicle', 'vehicals'),
								'add_new'              	=> __('Add Vehicle', 'vehicals'),
								'add_new_item'         	=> __('Add New Vehicle', 'vehicals'),
								'edit_item'            	=> __('Edit Vehicle', 'vehicals'),
								'new_item'             	=> __('New Vehicle', 'vehicals'),
								'view_item'            	=> __('View Vehicle', 'vehicals'),
								'search_items'         	=> __('Search Vehicle', 'vehicals'),
								'not_found'            	=> __('No Vehicle found', 'vehicals'),
								'not_found_in_trash'   	=> __('No Vehicle found in Trash', 'vehicals'),
								'menu_name'           	=> __('Vehicle List', 'vehicals'),
                                'featured_image'        => __('Vehicle Cover Image', 'vehicals'),
                                'set_featured_image'    => __('Set Vehicle Cover Image', 'vehicals'),
                                'remove_featured_image' => __('Remove Vehicle Cover Image', 'vehicals'),
                                'use_featured_image'    => __('Use as Vehicle Cover Image', 'vehicals'),
							));

	$wp_vehicals_slider_args = array(
        'labels'            => $wp_vehicals_post_lbls,
        'public'            => true,
        'show_ui'           => true,
        'query_var'         => true,
        'rewrite'           => array( 
                                        'slug'       => apply_filters('wp_pap_pro_portfolio_post_slug', 'wp-portfolio'),
                                        'with_front' => false
                                    ),
        'capability_type'   => 'post',
        'hierarchical'      => false,
        'menu_icon'			=> 'dashicons-portfolio',
        'supports'          => apply_filters('wp_pap_pro_post_supports', array('title', 'thumbnail', 'page-attributes', 'publicize'))
	);

	// Register portfolio post type
	register_post_type( WP_PAP_PRO_POST_TYPE, apply_filters( 'wp_vehicals_registered_post_type_args', $wp_vehicals_slider_args ) );
}

// Action to register plugin post type
add_action('init', 'wp_vehicals_register_post_type');

/**
 * Function to regoster category for portfolio
 * 
 * @package Vehials
 * @since 1.0
 */
function wp_vehicals_register_taxonomies() {
    
    // Register Portfolio Category
    $cat_labels = apply_filters('wp_vehicals_cat_labels', array(
                    'name'              => __( 'Vehicle Categories', 'vehicals' ),
                    'singular_name'     => __( 'Category', 'vehicals' ),
                    'search_items'      => __( 'Search Vehicle Category', 'vehicals' ),
                    'all_items'         => __( 'All Category', 'vehicals' ),
                    'parent_item'       => __( 'Parent Category', 'vehicals' ),
                    'parent_item_colon' => __( 'Parent Category:', 'vehicals' ),
                    'edit_item'         => __( 'Edit Vehicle Category', 'vehicals' ),
                    'update_item'       => __( 'Update Vehicle Category', 'vehicals' ),
                    'add_new_item'      => __( 'Add New Vehicle Category', 'vehicals' ),
                    'new_item_name'     => __( 'New Category Name', 'vehicals' ),
                    'menu_name'         => __( 'Categories', 'vehicals' ),
    ));

    $cat_args = array(
        'labels'            => $cat_labels,
    	'public'			=> true,
        'hierarchical'      => true,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array('slug' => apply_filters('wp_vehicals_cat_slug', 'vehicals')),
    );

    register_taxonomy( WP_PAP_PRO_CAT, array(WP_PAP_PRO_POST_TYPE), apply_filters('wp_vehicals_register__cat', $cat_args) );


    // Register Portfolio tag (Skill)
    /*$tag_labels = apply_filters('wp_vehicals_tag_labels', array(
        'name'                          => __( 'Vehicle Skills', 'vehicals' ),
        'singular_name'                 => __( 'Skill', 'vehicals' ),
        'search_items'                  =>  __( 'Search Vehicle Skills', 'vehicals' ),
        'popular_items'                 => __( 'Popular Skills', 'vehicals' ),
        'all_items'                     => __( 'All Skills', 'vehicals' ),
        'parent_item'                   => null,
        'parent_item_colon'             => null,
        'edit_item'                     => __( 'Edit Vehicle Skill', 'vehicals' ), 
        'update_item'                   => __( 'Update Vehicle Skill', 'vehicals' ),
        'add_new_item'                  => __( 'Add New Vehicle Skill', 'vehicals' ),
        'new_item_name'                 => __( 'New Skill Name', 'vehicals' ),
        'separate_items_with_commas'    => __( 'Separate skills with commas', 'vehicals' ),
        'add_or_remove_items'           => __( 'Add or remove portfolios', 'vehicals' ),
        'choose_from_most_used'         => __( 'Choose from the most used portfolios', 'vehicals' ),
        'menu_name'                     => __( 'Skills', 'vehicals' ),
    ));

    $tag_args = array(
        'labels'                => $tag_labels,
        'hierarchical'          => false,
        'show_ui'               => true,
        'query_var'             => true,
        'show_admin_column'     => true,
        'rewrite'               => array('slug' => apply_filters('wp_vehicals_tag_slug', 'vehicals-skill')),
    );

    register_taxonomy( WP_PAP_PRO_TAG, array( WP_PAP_PRO_POST_TYPE ), apply_filters('wp_vehicals_register_tag', $tag_args) ); */
}

// Action to register plugin taxonomy
add_action( 'init', 'wp_vehicals_register_taxonomies');

/**
 * Function to update post message for portfolio
 * 
 * @package Vehials
 * @since 1.0
 */
function wp_vehicals_post_updated_messages( $messages ) {
	
	global $post, $post_ID;
	
	$messages[WP_PAP_PRO_POST_TYPE] = array(
		0 => '', // Unused. Messages start at index 1.
		1 => sprintf( __( 'vehicals updated.', 'vehicals' ) ),
		2 => __( 'Custom field updated.', 'vehicals' ),
		3 => __( 'Custom field deleted.', 'vehicals' ),
		4 => __( 'vehicals updated.', 'vehicals' ),
		5 => isset( $_GET['revision'] ) ? sprintf( __( 'Image Gallery restored to revision from %s', 'vehicals' ), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
		6 => sprintf( __( 'vehicals published.', 'vehicals' ) ),
		7 => __( 'vehicals saved.', 'vehicals' ),
		8 => sprintf( __( 'vehicals submitted.', 'vehicals' ) ),
		9 => sprintf( __( 'vehicals scheduled for: <strong>%1$s</strong>.', 'vehicals' ),
		  date_i18n( 'M j, Y @ G:i', strtotime( $post->post_date ) ) ),
		10 => sprintf( __( 'vehicals draft updated.', 'vehicals' ) ),
	);
	
	return $messages;
}

// Filter to update post message
add_filter( 'post_updated_messages', 'wp_vehicals_post_updated_messages' );
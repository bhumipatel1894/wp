<?php
/**
 * Plugin Name: Album and Image Gallery Plus Lightbox Pro
 * Plugin URI: https://www.wponlinesupport.com
 * Description: Easy to add and display image gallery, gallery slider, Image album and Image album slider with various design.
 * Author: WP Online Support
 * Text Domain: album-and-image-gallery-plus-lightbox
 * Domain Path: /languages/
 * Version: 1.2.5
 * Author URI: https://www.wponlinesupport.com
 * 
 * @package WordPress
 * @author WP Online Support
 */

/**
 * Basic plugin definitions
 * 
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */
if( !defined( 'AIGPL_PRO_VERSION' ) ) {
    define( 'AIGPL_PRO_VERSION', '1.2.5' ); // Version of plugin
}
if( !defined( 'AIGPL_PRO_DIR' ) ) {
    define( 'AIGPL_PRO_DIR', dirname( __FILE__ ) ); // Plugin dir
}
if( !defined( 'AIGPL_PRO_URL' ) ) {
    define( 'AIGPL_PRO_URL', plugin_dir_url( __FILE__ ) ); // Plugin url
}
if( !defined( 'AIGPL_PRO_PLUGIN_BASENAME' ) ) {
    define( 'AIGPL_PRO_PLUGIN_BASENAME', plugin_basename( __FILE__ ) ); // plugin base name
}
if( !defined( 'AIGPL_PRO_POST_TYPE' ) ) {
    define( 'AIGPL_PRO_POST_TYPE', 'aigpl_gallery' ); // Plugin post type
}
if( !defined( 'AIGPL_PRO_CAT' ) ) {
    define( 'AIGPL_PRO_CAT', 'aigpl_cat' ); // Plugin category name
}
if( !defined( 'AIGPL_PRO_META_PREFIX' ) ) {
    define( 'AIGPL_PRO_META_PREFIX', '_aigpl_' ); // Plugin metabox prefix
}

/**
 * Load Text Domain
 * This gets the plugin ready for translation
 * 
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */
function aigpl_pro_load_textdomain() {

    global $wp_version;

    // Set filter for plugin's languages directory
    $aigpl_lang_dir = dirname( plugin_basename( __FILE__ ) ) . '/languages/';
    $aigpl_lang_dir = apply_filters( 'aigpl_pro_languages_directory', $aigpl_lang_dir );
    
    // Traditional WordPress plugin locale filter.
    $get_locale = get_locale();

    if ( $wp_version >= 4.7 ) {
        $get_locale = get_user_locale();
    }

    // Traditional WordPress plugin locale filter
    $locale = apply_filters( 'plugin_locale',  $get_locale, 'album-and-image-gallery-plus-lightbox' );
    $mofile = sprintf( '%1$s-%2$s.mo', 'album-and-image-gallery-plus-lightbox', $locale );

    // Setup paths to current locale file
    $mofile_global  = WP_LANG_DIR . '/plugins/' . basename( AIGPL_PRO_DIR ) . '/' . $mofile;

    if ( file_exists( $mofile_global ) ) { // Look in global /wp-content/languages/plugin-name folder
        load_textdomain( 'album-and-image-gallery-plus-lightbox', $mofile_global );
    } else { // Load the default language files
        load_plugin_textdomain( 'album-and-image-gallery-plus-lightbox', false, $aigpl_lang_dir );
    }
}
add_action('plugins_loaded', 'aigpl_pro_load_textdomain');

/**
 * Activation Hook
 * 
 * Register plugin activation hook.
 * 
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */
register_activation_hook( __FILE__, 'aigpl_pro_install' );

/**
 * Deactivation Hook
 * 
 * Register plugin deactivation hook.
 * 
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */
register_deactivation_hook( __FILE__, 'aigpl_pro_uninstall');

/**
 * Plugin Setup (On Activation)
 * 
 * Does the initial setup,
 * stest default values for the plugin options.
 * 
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */
function aigpl_pro_install() {

    // Get settings for the plugin
    $aigpl_pro_options = get_option( 'aigpl_pro_options' );
    
    if( empty( $aigpl_pro_options ) ) { // Check plugin version option
        
        // Set default settings
        aigpl_pro_default_settings();
        
        // Update plugin version to option
        update_option( 'aigpl_pro_plugin_version', '1.0' );
    }
    
    // Register post type function
    aigpl_pro_register_post_type();
    aigpl_pro_register_taxonomies();

    // IMP need to flush rules for custom registered post type
    flush_rewrite_rules();

    // Deactivate free version
    if( is_plugin_active('album-and-image-gallery-plus-lightbox/album-and-image-gallery.php') ) {
        add_action('update_option_active_plugins', 'aigpl_pro_deactivate_free_version');
    }
}

/**
 * Plugin Setup (On Deactivation)
 * 
 * Delete  plugin options.
 * 
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */
function aigpl_pro_uninstall() {
    
    // IMP need to flush rules for custom registered post type
    flush_rewrite_rules();
}

/**
 * Deactivate free plugin
 * 
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */
function aigpl_pro_deactivate_free_version() {
    deactivate_plugins('album-and-image-gallery-plus-lightbox/album-and-image-gallery.php', true);
}

/**
 * Function to display admin notice of activated plugin.
 * 
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */
function aigpl_pro_admin_notice() {
    
    $dir = WP_PLUGIN_DIR . '/album-and-image-gallery-plus-lightbox/album-and-image-gallery.php';
    
    // If free plugin exist
    if( file_exists($dir) ) {
        
        global $pagenow;
        
        if ( $pagenow == 'plugins.php' && current_user_can( 'install_plugins' ) ) {
            echo '<div id="message" class="updated notice is-dismissible"><p><strong>Thank you for activating Album and Image Gallery Plus Lightbox Pro</strong>.<br /> It looks like you had FREE version <strong>(<em>Album and Image Gallery Plus Lightbox</em>)</strong> of this plugin activated. To avoid conflicts the extra version has been deactivated and we recommend you delete it. </p></div>';
        }
    }
}

// Action to display notice
add_action( 'admin_notices', 'aigpl_pro_admin_notice');

/***** Updater Code Starts *****/
define( 'EDD_AIGPL_PRO_STORE_URL', 'https://www.wponlinesupport.com' );
define( 'EDD_AIGPL_PRO_ITEM_NAME', 'Album and Image Gallery Plus Lightbox Pro' );

// Plugin Updator Class 
if( !class_exists( 'EDD_SL_Plugin_Updater' ) ) {    
    include( dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php' );
}

/**
 * Updater Function
 * 
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */
function aigpl_pro_plugin_updater() {
    
    $license_key = trim( get_option( 'aigpl_pro_plugin_license_key' ) );

    $edd_updater = new EDD_SL_Plugin_Updater( EDD_AIGPL_PRO_STORE_URL, __FILE__, array(
                'version'   => AIGPL_PRO_VERSION,       // current version number
                'license'   => $license_key,            // license key (used get_option above to retrieve from DB)
                'item_name' => EDD_AIGPL_PRO_ITEM_NAME, // name of this plugin
                'author'    => 'WP Online Support'      // author of this plugin
            )
    );
}
add_action( 'admin_init', 'aigpl_pro_plugin_updater', 0 );
include( dirname( __FILE__ ) . '/aigpl-plugin-updater.php' );
/***** Updater Code Ends *****/

// Taking some globals
global $aigpl_pro_options;

// Functions file
require_once( AIGPL_PRO_DIR . '/includes/aigpl-functions.php' );
$aigpl_pro_options = aigpl_pro_get_settings();

// Plugin Post Type File
require_once( AIGPL_PRO_DIR . '/includes/aigpl-post-types.php' );

// Script Class File
require_once( AIGPL_PRO_DIR . '/includes/class-aigpl-script.php' );

// Admin Class File
require_once( AIGPL_PRO_DIR . '/includes/admin/class-aigpl-admin.php' );

// Public Class File
require_once( AIGPL_PRO_DIR . '/includes/class-aigpl-public.php' );

// Shortcode File
require_once( AIGPL_PRO_DIR . '/includes/shortcode/aigpl-gallery.php' );
require_once( AIGPL_PRO_DIR . '/includes/shortcode/aigpl-gallery-slider.php' );
require_once( AIGPL_PRO_DIR . '/includes/shortcode/aigpl-gallery-album.php' );
require_once( AIGPL_PRO_DIR . '/includes/shortcode/aigpl-gallery-album-slider.php' );

// Load admin files
if ( is_admin() || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
    require_once( AIGPL_PRO_DIR . '/includes/admin/aigpl-how-it-work.php' );
}

/**
 * Function call when all plugin is loaded
 * 
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */
function aigpl_pro_plugins_loaded() {

    // VC Shortcode File
    if( class_exists('Vc_Manager') ) {
        require_once( AIGPL_PRO_DIR . '/includes/admin/class-aigpl-vc.php' );
    }
}
add_action('plugins_loaded', 'aigpl_pro_plugins_loaded');
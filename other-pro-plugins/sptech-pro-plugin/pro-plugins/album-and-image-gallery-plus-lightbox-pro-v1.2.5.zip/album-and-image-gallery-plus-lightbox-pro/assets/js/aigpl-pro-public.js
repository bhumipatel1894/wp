jQuery(document).ready(function($) {
	
	// For Slider
	$( '.aigpl-gallery-slider' ).each(function( index ) {
		
		var slider_id   = $(this).attr('id');
		var slider_conf = $.parseJSON( $(this).closest('.aigpl-gallery-slider-wrp').find('.aigpl-gallery-slider-conf').text());
		
		jQuery('#'+slider_id).slick({
			dots			: (slider_conf.dots) == "true" ? true : false,
			infinite		: (slider_conf.loop) == "true" ? true : false,
			arrows			: (slider_conf.arrows) == "true" ? true : false,
			speed			: parseInt(slider_conf.speed),
			autoplay		: (slider_conf.autoplay) == "true" ? true : false,
			autoplaySpeed	: parseInt(slider_conf.autoplay_interval),
			slidesToShow	: parseInt(slider_conf.slidestoshow),
			slidesToScroll	: parseInt(slider_conf.slidestoscroll),
			centerMode 		: (slider_conf.centermode) == "true" ? true : false,
			rtl             : (AigplPro.is_rtl == 1) ? true : false,
			mobileFirst    	: (AigplPro.is_mobile == 1) ? true : false,
			responsive 		: [{
				breakpoint 	: 1023,
				settings 	: {
					slidesToShow 	: (parseInt(slider_conf.slidestoshow) > 3) ? 3 : parseInt(slider_conf.slidestoshow),
					slidesToScroll 	: 1,
					infinite 		: (slider_conf.loop) == "true" ? true : false,
					dots 			: (slider_conf.dots) == "true" ? true : false,
				}
			},{
				breakpoint	: 767,	  			
				settings	: {
					slidesToShow 	: (parseInt(slider_conf.slidestoshow) > 2) ? 2 : parseInt(slider_conf.slidestoshow),
					slidesToScroll 	: 1,
					infinite 		: (slider_conf.loop) == "true" ? true : false,
					dots 			: (slider_conf.dots) == "true" ? true : false,
					centerMode 		: false,
				}
			},
			{
				breakpoint	: 479,
				settings	: {
					slidesToShow 	: 1,
					slidesToScroll 	: 1,
					dots 			: false,
					centerMode 		: false,
					infinite 		: (slider_conf.loop) == "true" ? true : false,
				}
			},
			{
				breakpoint	: 319,
				settings	: {
					slidesToShow 	: 1,
					slidesToScroll 	: 1,
					dots 			: false,
					centerMode 		: false,
					infinite 		: (slider_conf.loop) == "true" ? true : false,
				}
			}]
		});
	});

	// Popup Gallery
	$( '.aigpl-popup-gallery' ).each(function( index ) {
		
		var gallery_id 	= $(this).attr('id');
		var total_item	= $('#'+gallery_id+' .aigpl-cnt-wrp:not(.slick-cloned) a.aigpl-img-link').length;
		
		if( typeof('gallery_id') !== 'undefined' && gallery_id != '' ) { //.slick-image-slide:not(.slick-cloned) a
			$('#'+gallery_id).magnificPopup({
				delegate: '.aigpl-cnt-wrp a.aigpl-img-link',
				type: 'image',
				mainClass: 'aigpl-mfp-popup',
				tLoading: 'Loading image #%curr%...',
				gallery: {
					enabled: true,
					navigateByImgClick: true,
					preload: [0,1], // Will preload 0 - before current, and 1 after the current image
					tCounter: ''
				},
				image: {
					tError: '<a href="%url%">The image #%curr%</a> could not be loaded.',
					titleSrc: function(item) {
						return item.el.closest('.aigpl-img-wrp').find('.aigpl-img').attr('title');
					}
				},
				zoom: {
					enabled: false,
					duration: 300, // don't foget to change the duration also in CSS
					opener: function(element) {
						return element.closest('.aigpl-img-wrp').find('.aigpl-img');
					}
				},
				callbacks: {
					/*beforeOpen: function() {
						// just a hack that adds mfp-anim class to markup 
						this.st.image.markup = this.st.image.markup.replace('mfp-figure', 'mfp-figure mfp-with-anim');
						this.st.mainClass = this.st.mainClass +' '+ this.st.el.attr('data-effect');
					},*/
					markupParse: function(template, values, item) {
						var current_indx 	= item.el.closest('.aigpl-cnt-wrp').attr('data-item-index');
						values.counter 		= current_indx+' of '+total_item;

						$('body').trigger('aigpl_mfp_markup_parse', [ template, values, item ]);
					}
				},
			});
		}
	});

	// Initialize masonry
	$('.aigpl-gallery-masonry').each(function( index ) {
		
		var obj_id 		= $(this).attr('id');
		var $container 	= $('#'+obj_id);

		// Creating object
		var masonry_param_obj = {itemSelector: '.aigpl-cnt-wrp'};
		
		if( !$(this).hasClass('aigpl-effect-1') ) {
			masonry_param_obj['transitionDuration'] = 0;
		}

		$container.imagesLoaded( function() {
			$container.masonry(masonry_param_obj);
		});
	});

	// Initialize album lightbox
	$(document).on('click', '.aigpl-lightbox-gallery .aigpl-img-link', function(e) {
		e.preventDefault();

		var cls_ele = $(this).closest('.aigpl-cnt-wrp');

		// Enable loader
		$('.aigpl-lightbox-loader').remove();
		$('body').append('<div class="aigpl-lightbox-loader">Please Wait...</div>');
		$('.aigpl-lightbox-loader').animate({bottom: '50px'}, 400);

		// Ajax
		var data 	= {
                        action 		: 'aigpl_pro_get_album_images',
                        album_id 	: cls_ele.attr('data-id'),
                    };

        $.post(AigplPro.ajaxurl,data,function(response) {
			var result = $.parseJSON(response);

			if( result.success == 1 && result.data ) {
				$('.aigpl-ilightbox-popup .ilightbox-close').trigger('click');
				$.iLightBox(result.data, {
                    skin:'metro-black aigpl-ilightbox-popup',
                    path: 'horizontal',
                    minScale: 0.075,
                    smartRecognition: false,
                    isMobile: true,
                    show: {
                        title: true,
						speed: 400
                    },
                    caption: {
                        start: true,
                        show: '',
                        hide: ''
                    },
                    controls: {
                        slideshow: true,
                        arrows: true,
                    },
                    overlay: {
                        opacity: 0.97
                    },
                    slideshow: {
                        pauseTime: 3000,
                        pauseOnHover: false,
                        startPaused: true
                    },
                });
				$('.aigpl-lightbox-loader').remove();
			} else {
				$('.aigpl-lightbox-loader').addClass('aigpl-lightbox-loader-err').html(result.msg);
			}

			setTimeout(function() {
				$(".aigpl-lightbox-loader").fadeOut("normal", function() {
					$(this).remove();
			    });
			}, 2000 );
		});
	});

});
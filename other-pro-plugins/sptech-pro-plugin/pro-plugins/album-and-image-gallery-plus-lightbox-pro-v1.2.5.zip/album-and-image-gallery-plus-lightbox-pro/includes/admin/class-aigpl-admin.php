<?php
/**
 * Admin Class
 *
 * Handles the Admin side functionality of plugin
 *
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Aigpl_Pro_Admin {

	function __construct() {
		
		// Action to add metabox
		add_action( 'add_meta_boxes', array($this, 'aigpl_pro_post_sett_metabox') );

		// Action to save metabox
		add_action( 'save_post', array($this, 'aigpl_pro_save_metabox_value') );

		// Action to register admin menu
		add_action( 'admin_menu', array($this, 'aigpl_pro_register_menu') );

		// Action to register plugin settings
		add_action ( 'admin_init', array($this, 'aigpl_pro_register_settings') );

		// Action to add category filter dropdown
		add_action( 'restrict_manage_posts', array($this, 'aigpl_pro_add_post_filters'), 50 );

		// Filter to add extra column in gallery `category` table
		add_filter( 'manage_edit-'.AIGPL_PRO_CAT.'_columns', array($this, 'aigpl_pro_manage_category_columns') );
		add_filter( 'manage_'.AIGPL_PRO_CAT.'_custom_column', array($this, 'aigpl_pro_category_data'), 10, 3 );

		// Action to add custom column to Gallery listing
		add_filter( 'manage_'.AIGPL_PRO_POST_TYPE.'_posts_columns', array($this, 'aigpl_pro_posts_columns') );

		// Action to add custom column data to Gallery listing
		add_action('manage_'.AIGPL_PRO_POST_TYPE.'_posts_custom_column', array($this, 'aigpl_pro_post_columns_data'), 10, 2);

		// Filter to add row data
		add_filter( 'post_row_actions', array($this, 'aigpl_pro_add_post_row_data'), 10, 2 );

		// Action to add sorting link at Gallery listing page
		add_filter( 'views_edit-'.AIGPL_PRO_POST_TYPE, array($this, 'aigpl_pro_sorting_link') );

		// Action to add `Save Order` button
		add_action( 'restrict_manage_posts', array($this, 'aigpl_pro_restrict_manage_posts') );

		// Action to add Attachment Popup HTML
		add_action( 'admin_footer', array($this,'aigpl_pro_image_update_popup_html') );

		// Ajax call to update option
		add_action( 'wp_ajax_aigpl_pro_get_attachment_edit_form', array($this, 'aigpl_pro_get_attachment_edit_form'));
		add_action( 'wp_ajax_nopriv_aigpl_pro_get_attachment_edit_form',array( $this, 'aigpl_pro_get_attachment_edit_form'));

		// Ajax call to update attachment data
		add_action( 'wp_ajax_aigpl_pro_save_attachment_data', array($this, 'aigpl_pro_save_attachment_data'));
		add_action( 'wp_ajax_nopriv_aigpl_pro_save_attachment_data',array( $this, 'aigpl_pro_save_attachment_data'));

		// Ajax call to update sort order option
		add_action( 'wp_ajax_aigpl_pro_update_post_order', array($this, 'aigpl_pro_update_post_order'));
		add_action( 'wp_ajax_nopriv_aigpl_pro_update_post_order',array( $this, 'aigpl_pro_update_post_order'));

		// Filter to add plugin links
		add_filter( 'plugin_row_meta', array( $this, 'aigpl_pro_plugin_row_meta' ), 10, 2 );
	}

	/**
	 * Post Settings Metabox
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_post_sett_metabox() {
		add_meta_box( 'aigpl-post-sett', __( 'Album and Image Gallery Plus Lightbox Pro - Settings', 'album-and-image-gallery-plus-lightbox' ), array($this, 'aigpl_pro_post_sett_mb_content'), AIGPL_PRO_POST_TYPE, 'normal', 'high' );
	}

	/**
	 * Post Settings Metabox HTML
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_post_sett_mb_content() {
		include_once( AIGPL_PRO_DIR .'/includes/admin/metabox/aigpl-sett-metabox.php');
	}

	/**
	 * Function to save metabox values
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_save_metabox_value( $post_id ) {

		global $post_type;
		
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )                	// Check Autosave
		|| ( ! isset( $_POST['post_ID'] ) || $post_id != $_POST['post_ID'] )  	// Check Revision
		|| ( $post_type !=  AIGPL_PRO_POST_TYPE ) )              					// Check if current post type is supported.
		{
		  return $post_id;
		}

		$prefix = AIGPL_PRO_META_PREFIX; // Taking metabox prefix
		
		// Taking variables
		$gallery_imgs = isset($_POST['aigpl_img']) ? aigpl_pro_slashes_deep($_POST['aigpl_img']) : '';
		
		update_post_meta($post_id, $prefix.'gallery_imgs', $gallery_imgs);
	}

	/**
	 * Function to register admin menus
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_register_menu() {
		add_submenu_page( 'edit.php?post_type='.AIGPL_PRO_POST_TYPE, __('Settings', 'album-and-image-gallery-plus-lightbox'), __('Settings', 'album-and-image-gallery-plus-lightbox'), 'manage_options', 'aigpl-settings', array($this, 'aigpl_pro_settings_page') );
	}

	/**
	 * Function to handle the setting page html
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_settings_page() {
		include_once( AIGPL_PRO_DIR . '/includes/admin/settings/aigpl-settings.php' );
	}

	/**
	 * Function register setings
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_register_settings() {
		register_setting( 'aigpl_pro_plugin_options', 'aigpl_pro_options', array($this, 'aigpl_pro_validate_options') );
	}
	
	/**
	 * Validate Settings Options
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_validate_options( $input ) {
		
		$input['default_img'] 	= isset($input['default_img']) 	? aigpl_pro_slashes_deep($input['default_img']) 		: '';
		$input['custom_css'] 	= isset($input['custom_css']) 	? aigpl_pro_slashes_deep($input['custom_css'], true) 	: '';
		
		return $input;
	}

	/**
	 * Add category dropdown to Slider listing page
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_add_post_filters() {
		
		global $typenow;
		
		if( $typenow == AIGPL_PRO_POST_TYPE ) {

			$dropdown_options = apply_filters('aigpl_cat_filter_args', array(
					'show_option_none'  => __('All Categories', 'album-and-image-gallery-plus-lightbox'),
					'option_none_value' => '',
					'hide_empty' 		=> 1,
					'hierarchical' 		=> 1,
					'show_count' 		=> 0,
					'orderby' 			=> 'name',
					'name'				=> AIGPL_PRO_CAT,
					'taxonomy'			=> AIGPL_PRO_CAT,
					'selected' 			=> isset($_GET[AIGPL_PRO_CAT]) ? $_GET[AIGPL_PRO_CAT] : '',
					'value_field'		=> 'slug',
				));
			wp_dropdown_categories( $dropdown_options );
		}
	}

	/**
	 * Add extra column to news category
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_manage_category_columns($columns) {

		$new_columns['aigpl_shortcode'] = __( 'Category Shortcode', 'album-and-image-gallery-plus-lightbox' );

		$columns = aigpl_pro_add_array( $columns, $new_columns, 2 );

		return $columns;
	}

	/**
	 * Add data to extra column to news category
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_category_data($ouput, $column_name, $tax_id) {
		
		if( $column_name == 'aigpl_shortcode' ) {
			$ouput .= '[aigpl-gallery category="' . $tax_id. '"]<br/>';
			$ouput .= '[aigpl-gallery-slider category="' . $tax_id. '"]';
	    }
		
	    return $ouput;
	}

	/**
	 * Add custom column to Post listing page
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_posts_columns( $columns ) {

	    $new_columns['aigpl_shortcode'] 	= __('Shortcode', 'album-and-image-gallery-plus-lightbox');
	    $new_columns['aigpl_photos'] 		= __('Number of Photos', 'album-and-image-gallery-plus-lightbox');
	    $new_columns['aigpl_order'] 		= __('Order', 'album-and-image-gallery-plus-lightbox');

	    $columns = aigpl_pro_add_array( $columns, $new_columns, 1, true );

	    return $columns;
	}

	/**
	 * Add custom column data to Post listing page
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_post_columns_data( $column, $post_id ) {

		global $post;

		// Taking some variables
		$prefix = AIGPL_PRO_META_PREFIX;

	    switch ($column) {
	    	case 'aigpl_shortcode':
	    		
	    		echo '<div class="aigpl-shortcode-preview">[aigpl-gallery id="'.$post_id.'"]</div> <br/>';
	    		echo '<div class="aigpl-shortcode-preview">[aigpl-gallery-slider id="'.$post_id.'"]</div>';
	    		break;

	    	case 'aigpl_photos':
	    		$total_photos = get_post_meta($post_id, $prefix.'gallery_imgs', true);
	    		echo !empty($total_photos) ? count($total_photos) : '--';
	    		break;

			case 'aigpl_order':

		        $post_menu_order = isset($post->menu_order) ? $post->menu_order : '';
		        
		        echo $post_menu_order;
		        echo "<input type='hidden' value='{$post_id}' name='aigpl_post[]' class='aigpl-post-order' id='aigpl-post-order-{$post_id}' />";
		        break;
		}
	}

	/**
	 * Function to add custom quick links at post listing page
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_add_post_row_data( $actions, $post ) {
		
		if( $post->post_type == AIGPL_PRO_POST_TYPE ) {
			return array_merge( array( 'aigpl_id' => 'ID: ' . $post->ID ), $actions );
		}
		
		return $actions;
	}

	/**
	 * Add 'Sort Slides' link at Slider listing page
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_sorting_link( $views ) {
	    
	    global $post_type, $wp_query;

	    $class            = ( isset( $wp_query->query['orderby'] ) && $wp_query->query['orderby'] == 'menu_order title' ) ? 'current' : '';
	    $query_string     = remove_query_arg(array( 'orderby', 'order' ));
	    $query_string     = add_query_arg( 'orderby', urlencode('menu_order title'), $query_string );
	    $query_string     = add_query_arg( 'order', urlencode('ASC'), $query_string );
	    $views['byorder'] = '<a href="' . esc_url( $query_string ) . '" class="' . esc_attr( $class ) . '">' . __( 'Sort Gallery', 'album-and-image-gallery-plus-lightbox' ) . '</a>';

	    return $views;
	}

	/**
	 * Add Save button to Slider listing page
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_restrict_manage_posts() {

		global $typenow, $wp_query;

		if( $typenow == AIGPL_PRO_POST_TYPE && isset($wp_query->query['orderby']) && $wp_query->query['orderby'] == 'menu_order title' ) {

			$html  = '';
			$html .= "<span class='spinner aigpl-spinner'></span>";
			$html .= "<input type='button' name='aigpl_save_order' class='button button-secondary right aigpl-save-order' id='aigpl-save-order' value='".__('Save Sort Order', 'album-and-image-gallery-plus-lightbox')."' />";
			echo $html;
		}
	}

	/**
	 * Image data popup HTML
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_image_update_popup_html() {

		global $typenow;

		if( $typenow == AIGPL_PRO_POST_TYPE ) {
			include_once( AIGPL_PRO_DIR .'/includes/admin/settings/aigpl-img-popup.php');
		}
	}

	/**
	 * Get attachment edit form
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_get_attachment_edit_form() {

		// Taking some defaults
		$result 			= array();
		$result['success'] 	= 0;
		$result['msg'] 		= __('Sorry, Something happened wrong.', 'album-and-image-gallery-plus-lightbox');
		$attachment_id 		= !empty($_POST['attachment_id']) ? trim($_POST['attachment_id']) : '';

		if( !empty($attachment_id) ) {
			$attachment_post = get_post( $_POST['attachment_id'] );

			if( !empty($attachment_post) ) {
				
				ob_start();

				// Popup Data File
				include( AIGPL_PRO_DIR . '/includes/admin/settings/aigpl-img-popup-data.php' );

				$attachment_data = ob_get_clean();

				$result['success'] 	= 1;
				$result['msg'] 		= __('Attachment Found.', 'album-and-image-gallery-plus-lightbox');
				$result['data']		= $attachment_data;
			}
		}

		echo json_encode($result);
		exit;
	}

	/**
	 * Get attachment edit form
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_save_attachment_data() {

		$prefix 			= AIGPL_PRO_META_PREFIX;
		$result 			= array();
		$result['success'] 	= 0;
		$result['msg'] 		= __('Sorry, Something happened wrong.', 'album-and-image-gallery-plus-lightbox');
		$attachment_id 		= !empty($_POST['attachment_id']) ? trim($_POST['attachment_id']) : '';
		$form_data 			= parse_str($_POST['form_data'], $form_data_arr);

		if( !empty($attachment_id) && !empty($form_data_arr) ) {
			
			// Getting attachment post
			$aigpl_attachment_post = get_post( $attachment_id );
			
			// If post type is attachment
			if( isset($aigpl_attachment_post->post_type) && $aigpl_attachment_post->post_type == 'attachment' ) {
				$post_args = array(
									'ID'			=> $attachment_id,
									'post_title'	=> !empty($form_data_arr['aigpl_attachment_title']) ? $form_data_arr['aigpl_attachment_title'] : $aigpl_attachment_post->post_name,
									'post_content'	=> $form_data_arr['aigpl_attachment_desc'],
									'post_excerpt'	=> $form_data_arr['aigpl_attachment_caption'],
								);
				$update = wp_update_post( $post_args, $wp_error );

				if( !is_wp_error( $update ) ) {

					update_post_meta( $attachment_id, '_wp_attachment_image_alt', aigpl_pro_slashes_deep($form_data_arr['aigpl_attachment_alt']) );
					update_post_meta( $attachment_id, $prefix.'attachment_link', aigpl_pro_slashes_deep($form_data_arr['aigpl_attachment_link']) );

					$result['success'] 	= 1;
					$result['msg'] 		= __('Your changes saved successfully.', 'album-and-image-gallery-plus-lightbox');
				}
			}
		}
		echo json_encode($result);
		exit;
	}

	/**
	 * Update album sort order
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_update_post_order() {

		// Taking some defaults
		$result 			= array();
		$result['success'] 	= 0;
		$result['msg'] 		= __('Sorry, Something happened wrong.', 'album-and-image-gallery-plus-lightbox');

		if( !empty($_POST['form_data']) ) {

			$form_data 		= parse_str($_POST['form_data'], $output_arr);
			$aigpl_posts 	= !empty($output_arr['aigpl_post']) ? $output_arr['aigpl_post'] : '';

			if( !empty($aigpl_posts) ) {

				$post_menu_order = 0;

				// Loop od ids
				foreach ($aigpl_posts as $aigpl_post_key => $aigpl_post) {
					
					// Update post order
					$update_post = array(
						'ID'           => $aigpl_post,
						'menu_order'   => $post_menu_order,
					);

					// Update the post into the database
					wp_update_post( $update_post );

					$post_menu_order++;
				}

				$result['success'] 	= 1;
				$result['msg'] 		= __('Gallery order saved successfully.', 'album-and-image-gallery-plus-lightbox');
			}
		}

		echo json_encode($result);
		exit;
	}

	/**
	 * Function to unique number value
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_plugin_row_meta( $links, $file ) {
		
		if ( $file == AIGPL_PRO_PLUGIN_BASENAME ) {
			
			$row_meta = array(
				'docs'    => '<a href="' . esc_url('https://www.wponlinesupport.com/pro-plugin-document/document-album-image-gallery-plus-lightbox-pro/') . '" title="' . esc_attr( __( 'View Documentation', 'album-and-image-gallery-plus-lightbox' ) ) . '" target="_blank">' . __( 'Docs', 'album-and-image-gallery-plus-lightbox' ) . '</a>',
				'support' => '<a href="' . esc_url('https://www.wponlinesupport.com/welcome-wp-online-support-forum/') . '" title="' . esc_attr( __( 'Visit Customer Support Forum', 'album-and-image-gallery-plus-lightbox' ) ) . '" target="_blank">' . __( 'Support', 'album-and-image-gallery-plus-lightbox' ) . '</a>',
			);
			return array_merge( $links, $row_meta );
		}
		return (array) $links;
	}
}

$aigpl_pro_admin = new Aigpl_Pro_Admin();
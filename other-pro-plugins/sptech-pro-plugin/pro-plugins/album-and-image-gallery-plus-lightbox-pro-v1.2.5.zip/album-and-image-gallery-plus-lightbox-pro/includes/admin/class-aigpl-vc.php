<?php
/**
 * Visual Composer Class
 *
 * Handles the visual composer shortcode functionality of plugin
 *
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Wpaigpl_Vc {
	
	function __construct() {

		// Action to add 'aigpl-gallery' shortcode in vc
		add_action( 'vc_before_init', array($this, 'aigpl_pro_integrate_gallery_grid_vc') );

		// Action to add 'aigpl-gallery-slider' shortcode in vc
		add_action( 'vc_before_init', array($this, 'aigpl_pro_integrate_gallery_slider_vc') );

		// Action to add 'aigpl-gallery-album' shortcode in vc
		add_action( 'vc_before_init', array($this, 'aigpl_pro_integrate_gallery_album_vc') ); 

		// Action to add 'aigpl-gallery-album-slider' shortcode in vc
		add_action( 'vc_before_init', array($this, 'aigpl_pro_integrate_gallery_album_slider_vc') );

		// Action to create new shortcode param type
		add_action( 'init', array($this, 'aigpl_pro_create_vc_custom_param') );
	}

	/**
	 * Function to add 'aigpl-gallery' shortcode in vc
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_integrate_gallery_grid_vc() {
		vc_map( array(
			'name' 			=> __( 'WPOS - Album Gallery Grid', 'album-and-image-gallery-plus-lightbox' ),
			'base' 			=> 'aigpl-gallery',
			'icon' 			=> 'icon-wpb-wp',
			'class' 		=> '',
			'category' 		=> __( 'Content', 'album-and-image-gallery-plus-lightbox'),
			'description' 	=> __( 'Display image gallery in grid view.', 'album-and-image-gallery-plus-lightbox' ),
			'params' 	=> array(
								// General settings
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Design', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'design',
									'value' 		=> array(
															__( 'Gallery Grid Design 1', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-1',
															__( 'Gallery Grid Design 2', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-2',
															__( 'Gallery Grid Design 3', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-3',
															__( 'Gallery Grid Design 4', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-4',
															__( 'Gallery Grid Design 5', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-5',
															__( 'Gallery Grid Design 6', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-6',
															__( 'Gallery Grid Design 7', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-7',
															__( 'Gallery Grid Design 8', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-8',
															__( 'Gallery Grid Design 9', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-9',
															__( 'Gallery Grid Design 10', 'album-and-image-gallery-plus-lightbox' ) => 'design-10',
															__( 'Gallery Grid Design 11', 'album-and-image-gallery-plus-lightbox' ) => 'design-11',
															__( 'Gallery Grid Design 12', 'album-and-image-gallery-plus-lightbox' ) => 'design-12',
															__( 'Gallery Grid Design 13', 'album-and-image-gallery-plus-lightbox' ) => 'design-13',
															__( 'Gallery Grid Design 14', 'album-and-image-gallery-plus-lightbox' ) => 'design-14',
															__( 'Gallery Grid Design 15', 'album-and-image-gallery-plus-lightbox' ) => 'design-15',	
														),
									'description' 	=> __( 'Choose gallery grid design.', 'album-and-image-gallery-plus-lightbox' ),
									'admin_label' 	=> true,
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Album ID', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'id',
									'value' 		=> '',
									'description' 	=> sprintf(__( 'Enter id of the Album. You can find id at listing <a href="%1$s" target="_blank">page</a>. Note: You must have to pass the Album ID.', 'album-and-image-gallery-plus-lightbox'), add_query_arg( array( 'post_type' => AIGPL_PRO_POST_TYPE ), 'edit.php' )),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Show Title', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'show_title',
									'value' 		=> array(
															__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
															__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														),
									'description' 	=> __( 'Display image title.', 'album-and-image-gallery-plus-lightbox' )
								),								
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Show Description', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'show_description',
									'value' 		=> array(
															__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
															__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														),
									'description' 	=> __( 'Display image description.', 'album-and-image-gallery-plus-lightbox' )
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Display Caption', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'show_caption',
									'value' 		=> array(
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
													),
									'description' 	=> __( 'Display image caption.', 'album-and-image-gallery-plus-lightbox' ),
								),								
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Image Size', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'image_size',
									'value' 		=> array(
														__( 'Full', 'album-and-image-gallery-plus-lightbox' ) 		=> 'full',
														__( 'Medium', 'album-and-image-gallery-plus-lightbox' ) 	=> 'medium',
														__( 'Large', 'album-and-image-gallery-plus-lightbox' ) 		=> 'large',
														__( 'Thumbnail', 'album-and-image-gallery-plus-lightbox' ) 	=> 'thumbnail',
													),
									'description' 	=> __( 'Choose image size.', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Gallery Height', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'gallery_height',
									'value' 		=> '',
									'description' 	=> __( 'Enter gallery height. Leave empty for default height. e.g 500 or auto.', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Open Image in Popup', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'popup',
									'value' 		=> array(
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
													),
									'description' 	=> __( 'Display gallery image in a popup.', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Link Behaviour', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'link_target',
									'value' 		=> array(
														__( 'Same Window', 'album-and-image-gallery-plus-lightbox' ) 	=> 'self',
														__( 'New Window', 'album-and-image-gallery-plus-lightbox' ) 	=> 'blank',
													),
									'description' 	=> __( 'Choose link bahaviour.', 'album-and-image-gallery-plus-lightbox' ),
									'dependency' 	=> array(
														'element' 	=> 'popup',
														'value' 	=> array( 'false' ),
														),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Masonry Layout', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'masonry',
									'value' 		=> array(
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',														
													),
									'description' 	=> __( 'Display gallery images in a masonry layout.', 'album-and-image-gallery-plus-lightbox' ),
								),

								// Grid Settings
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Grid', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'grid',
									'value' 		=> array(
															__( 'Grid 1', 'album-and-image-gallery-plus-lightbox' ) => '1',
															__( 'Grid 2', 'album-and-image-gallery-plus-lightbox' ) => '2',
															__( 'Grid 3', 'album-and-image-gallery-plus-lightbox' ) => '3',
															__( 'Grid 4', 'album-and-image-gallery-plus-lightbox' ) => '4',
															__( 'Grid 5', 'album-and-image-gallery-plus-lightbox' ) => '5',
															__( 'Grid 6', 'album-and-image-gallery-plus-lightbox' ) => '6',
															__( 'Grid 7', 'album-and-image-gallery-plus-lightbox' ) => '7',
															__( 'Grid 8', 'album-and-image-gallery-plus-lightbox' ) => '8',
															__( 'Grid 9', 'album-and-image-gallery-plus-lightbox' ) => '9',
															__( 'Grid 10', 'album-and-image-gallery-plus-lightbox' ) => '10',
															__( 'Grid 11', 'album-and-image-gallery-plus-lightbox' ) => '11',
															__( 'Grid 12', 'album-and-image-gallery-plus-lightbox' ) => '12',
														),
									'std'			=> 3,
									'description' 	=> __( 'Choose number of column for image gallery.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Grid Settings', 'album-and-image-gallery-plus-lightbox' )
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Offset (Padding between two images)', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'offset',
									'value' 		=> '',
									'description' 	=> __( 'Space between two images. You can enter any numeric number. e.g 5', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Grid Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
							)
		));
	}

	/**
	 * Function to add 'aigpl-gallery-slider' shortcode in vc
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_integrate_gallery_slider_vc() {
		vc_map( array(
			'name' 			=> __( 'WPOS - Album Gallery Slider', 'album-and-image-gallery-plus-lightbox' ),
			'base' 			=> 'aigpl-gallery-slider',
			'icon' 			=> 'icon-wpb-wp',
			'class' 		=> '',
			'category' 		=> __( 'Content', 'album-and-image-gallery-plus-lightbox'),
			'description' 	=> __( 'Display image gallery in slider view.', 'album-and-image-gallery-plus-lightbox' ),
			'params' 	=> array(
								// General settings
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Design', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'design',
									'value' 		=> array(
															__( 'Gallery Slider Design 1', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-1',
															__( 'Gallery Slider Design 2', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-2',
															__( 'Gallery Slider Design 3', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-3',
															__( 'Gallery Slider Design 4', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-4',
															__( 'Gallery Slider Design 5', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-5',
															__( 'Gallery Slider Design 6', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-6',
															__( 'Gallery Slider Design 7', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-7',
															__( 'Gallery Slider Design 8', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-8',
															__( 'Gallery Slider Design 9', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-9',
															__( 'Gallery Slider Design 10', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-10',
															__( 'Gallery Slider Design 11', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-11',
															__( 'Gallery Slider Design 12', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-12',
															__( 'Gallery Slider Design 13', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-13',
															__( 'Gallery Slider Design 14', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-14',
															__( 'Gallery Slider Design 15', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-15',	
														),
									'description' 	=> __( 'Choose image gallery slider design.', 'album-and-image-gallery-plus-lightbox' ),
									'admin_label' 	=> true,
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Album ID', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'id',
									'value' 		=> '',
									'description' 	=> sprintf(__( 'Enter id of the Album. You can find id at listing <a href="%1$s" target="_blank">page</a>. Note: You must have to pass the Album ID.', 'album-and-image-gallery-plus-lightbox'), add_query_arg( array( 'post_type' => AIGPL_PRO_POST_TYPE ), 'edit.php' )),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Show Title', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'show_title',
									'value' 		=> array(
															__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
															__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														),
									'description' 	=> __( 'Display image title.', 'album-and-image-gallery-plus-lightbox' )
								),								
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Show Description', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'show_description',
									'value' 		=> array(
															__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
															__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														),
									'description' 	=> __( 'Display image description.', 'album-and-image-gallery-plus-lightbox' )
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Display Caption', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'show_caption',
									'value' 		=> array(
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
													),
									'description' 	=> __( 'Display image caption.', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Image Size', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'image_size',
									'value' 		=> array(
														__( 'Full', 'album-and-image-gallery-plus-lightbox' ) 		=> 'full',
														__( 'Medium', 'album-and-image-gallery-plus-lightbox' ) 	=> 'medium',
														__( 'Large', 'album-and-image-gallery-plus-lightbox' ) 		=> 'large',
														__( 'Thumbnail', 'album-and-image-gallery-plus-lightbox' ) 	=> 'thumbnail',
													),
									'description' 	=> __( 'Choose image size.', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Open Image in Popup', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'popup',
									'value' 		=> array(
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
													),
									'description' 	=> __( 'Display gallery image in a popup.', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Link Behaviour', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'link_target',
									'value' 		=> array(
														__( 'Same Window', 'album-and-image-gallery-plus-lightbox' ) 	=> 'self',
														__( 'New Window', 'album-and-image-gallery-plus-lightbox' ) 	=> 'blank',
													),
									'description' 	=> __( 'Choose link bahaviour.', 'album-and-image-gallery-plus-lightbox' ),
									'dependency' 	=> array(
														'element' 	=> 'popup',
														'value' 	=> array( 'false' ),
														),
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Gallery Height', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'gallery_height',
									'value' 		=> '',
									'description' 	=> __( 'Enter gallery height. Leave empty for default height. e.g 500 or auto', 'album-and-image-gallery-plus-lightbox' ),
								),							

								// Slider Settings
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Slides Column', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'slidestoshow',
									'value' 		=> '3',
									'description' 	=> __( 'Enter number of column for image gallery slider.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Slider Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Slides Scroll', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'slidestoscroll',
									'value' 		=> '1',
									'description' 	=> __( 'Enter number of slides to scroll at a time.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Slider Settings', 'album-and-image-gallery-plus-lightbox' ),
								),								
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Dots', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'dots',
									'value' 		=> array(
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
													),
									'description' 	=> __( 'Show dots indicators.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Slider Settings', 'album-and-image-gallery-plus-lightbox' )
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Arrows', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'arrows',
									'value' 		=> array(
															__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
															__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
														),
									'description' 	=> __( 'Show Prev - Next arrows.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Slider Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Autoplay', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'autoplay',
									'value' 		=> array(
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
													),
									'description' 	=> __( 'Enable autoplay.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Slider Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Autoplay Interval', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'autoplay_interval',
									'value' 		=> '3000',
									'description' 	=> __( 'Enter autoplay speed.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Slider Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Speed', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'speed',
									'value' 		=> '300',
									'description' 	=> __( 'Enter slide speed.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Slider Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Infinite', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'loop',
									'value' 		=> array(
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
													),
									'description' 	=> __( 'Enable infinite loop for continuous sliding.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Slider Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Center Mode', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'centermode',
									'value' 		=> array(
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
													),
									'description' 	=> __( 'Enable slider center mode effect.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Slider Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
							)
		));
	}

	/**
	 * Function to add 'aigpl-gallery-album' shortcode in vc
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_integrate_gallery_album_vc() {
		vc_map( array(
			'name' 			=> __( 'WPOS - Album Grid', 'album-and-image-gallery-plus-lightbox' ),
			'base' 			=> 'aigpl-gallery-album',
			'icon' 			=> 'icon-wpb-wp',
			'class' 		=> '',
			'category' 		=> __( 'Content', 'album-and-image-gallery-plus-lightbox'),
			'description' 	=> __( 'Display album in grid view.', 'album-and-image-gallery-plus-lightbox' ),
			'params' 		=> array(
								// General settings
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Design', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'album_design',
									'value' 		=> array(
															__( 'Album Design 1', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-1',
															__( 'Album Design 2', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-2',
															__( 'Album Design 3', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-3',
															__( 'Album Design 4', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-4',
															__( 'Album Design 5', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-5',
															__( 'Album Design 6', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-6',
															__( 'Album Design 7', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-7',
															__( 'Album Design 8', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-8',
															__( 'Album Design 9', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-9',
															__( 'Album Design 10', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-10',
															__( 'Album Design 11', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-11',
															__( 'Album Design 12', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-12',
															__( 'Album Design 13', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-13',
															__( 'Album Design 14', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-14',
															__( 'Album Design 15', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-15',
															__( 'Album Design 16', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-16',
															__( 'Album Design 17', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-17',
														),
									'description' 	=> __( 'Choose album design.', 'album-and-image-gallery-plus-lightbox' ),
									'admin_label' 	=> true,
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Album Grid', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'album_grid',
									'value' 		=> array(
															__( 'Grid 1', 'album-and-image-gallery-plus-lightbox' ) => '1',
															__( 'Grid 2', 'album-and-image-gallery-plus-lightbox' ) => '2',
															__( 'Grid 3', 'album-and-image-gallery-plus-lightbox' ) => '3',
															__( 'Grid 4', 'album-and-image-gallery-plus-lightbox' ) => '4',
															__( 'Grid 5', 'album-and-image-gallery-plus-lightbox' ) => '5',
															__( 'Grid 6', 'album-and-image-gallery-plus-lightbox' ) => '6',
															__( 'Grid 7', 'album-and-image-gallery-plus-lightbox' ) => '7',
															__( 'Grid 8', 'album-and-image-gallery-plus-lightbox' ) => '8',
															__( 'Grid 9', 'album-and-image-gallery-plus-lightbox' ) => '9',
															__( 'Grid 10', 'album-and-image-gallery-plus-lightbox' ) => '10',
															__( 'Grid 11', 'album-and-image-gallery-plus-lightbox' ) => '11',
															__( 'Grid 12', 'album-and-image-gallery-plus-lightbox' ) => '12',
														),
									'std'			=> 3,
									'description' 	=> __( 'Choose number of columns for album.', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Album Title', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'album_title',
									'value' 		=> array(
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
													),
									'description' 	=> __( 'Display album title.', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Album Description', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'album_description',
									'value' 		=> array(
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
													),
									'description' 	=> __( 'Display album description.', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Album Full Content', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'album_full_content',
									'value' 		=> array(
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
													),
									'description' 	=> __( 'Display album full description.', 'album-and-image-gallery-plus-lightbox' ),
									'dependency' 	=> array(
															'element' 	=> 'album_description',
															'value' 	=> array( 'true' ),
														),
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Content Tail', 'wp-responsive-recent-post-slider' ),
									'param_name' 	=> 'content_tail',
									'value' 		=> '...',
									'description' 	=> __( 'Display dots after the post content.', 'wp-responsive-recent-post-slider' ),
									'dependency' 	=> array(
														'element' 	=> 'album_full_content',
														'value' 	=> array( 'false' ),
														),
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Words Limit for Album Description', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'words_limit',
									'value' 		=> 40,
									'description' 	=> __( 'Display number of words for album description.', 'album-and-image-gallery-plus-lightbox' ),
									'dependency' 	=> array(
														'element' 	=> 'album_full_content',
														'value' 	=> array( 'false' ),
														),
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Album Height', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'album_height',
									'value' 		=> '',
									'description' 	=> __( 'Control height of the album. You can enter any numeric number. e.g 500', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Total Photos', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'total_photo',
									'value' 		=> '{total} Photos',
									'description' 	=> __( 'Control photo count label. "{total}" will replace the number of album photos.', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Album Pagination', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'pagination',
									'value' 		=> array(
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
													),
									'description' 	=> __( 'Enable album pagination.', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Pagination Type', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'pagination_type',
									'value' 		=> array(
															__( 'Numeric Pagination', 'album-and-image-gallery-plus-lightbox' ) 			=> 'numeric',
															__( 'Previous - Next Pagination', 'album-and-image-gallery-plus-lightbox' ) 	=> 'prev-next',
														),
									'description' 	=> __( 'Display Pagination for News Post', 'album-and-image-gallery-plus-lightbox' ),
									'dependency' 	=> array(
															'element' 	=> 'pagination',
															'value' 	=> array( 'true' ),
														),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Album Behaviour', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'album_popup',
									'value' 		=> array(
														__( 'Page Reload', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
														__( 'Popup View', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
													),
									'description' 	=> __( 'Choose album gallery behaviour.', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Album Link Behaviour', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'album_link_target',
									'value' 		=> array(
														__( 'Same Window', 'album-and-image-gallery-plus-lightbox' ) 	=> 'self',
														__( 'New Window', 'album-and-image-gallery-plus-lightbox' ) 	=> 'blank',
													),
									'description' 	=> __( 'Choose link behaviour whether to open in a new tab or not.', 'album-and-image-gallery-plus-lightbox' ),
									'dependency' 	=> array(
															'element' 	=> 'album_popup',
															'value' 	=> array( 'false' ),
														),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Album Masonry Layout', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'album_masonry',
									'value' 		=> array(
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
													),
									'description' 	=> __( 'Display album in a masonry layout.', 'album-and-image-gallery-plus-lightbox' ),
								),

								// Album Gallery Setting
								array(
									'type' 			=> 'wpos_desc',
									'class' 		=> '',
									'param_name' 	=> 'wpos_desc_alert',
									'value' 		=> __( "Note: This all parameters only works if you had chosen 'Album Behaviour' as a 'Page Reload'.", 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Album Gallery Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Gallery Image Design', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'design',
									'value' 		=> array(
															__( 'Gallery Image Design 1', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-1',
															__( 'Gallery Image Design 2', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-2',
															__( 'Gallery Image Design 3', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-3',
															__( 'Gallery Image Design 4', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-4',
															__( 'Gallery Image Design 5', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-5',
															__( 'Gallery Image Design 6', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-6',
															__( 'Gallery Image Design 7', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-7',
															__( 'Gallery Image Design 8', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-8',
															__( 'Gallery Image Design 9', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-9',
															__( 'Gallery Image Design 10', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-10',
															__( 'Gallery Image Design 11', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-11',
															__( 'Gallery Image Design 12', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-12',
															__( 'Gallery Image Design 13', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-13',
															__( 'Gallery Image Design 14', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-14',
															__( 'Gallery Image Design 15', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-15',
														),
									'description' 	=> __( 'Choose Gallery Images design. Display when you click on any Album.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Album Gallery Settings', 'album-and-image-gallery-plus-lightbox' ),
									'admin_label' 	=> true,
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Gallery Image Grid', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'grid',
									'value' 		=> array(
															__( 'Grid 1', 'album-and-image-gallery-plus-lightbox' ) => '1',
															__( 'Grid 2', 'album-and-image-gallery-plus-lightbox' ) => '2',
															__( 'Grid 3', 'album-and-image-gallery-plus-lightbox' ) => '3',
															__( 'Grid 4', 'album-and-image-gallery-plus-lightbox' ) => '4',
															__( 'Grid 5', 'album-and-image-gallery-plus-lightbox' ) => '5',
															__( 'Grid 6', 'album-and-image-gallery-plus-lightbox' ) => '6',
															__( 'Grid 7', 'album-and-image-gallery-plus-lightbox' ) => '7',
															__( 'Grid 8', 'album-and-image-gallery-plus-lightbox' ) => '8',
															__( 'Grid 9', 'album-and-image-gallery-plus-lightbox' ) => '9',
															__( 'Grid 10', 'album-and-image-gallery-plus-lightbox' ) => '10',
															__( 'Grid 11', 'album-and-image-gallery-plus-lightbox' ) => '11',
															__( 'Grid 12', 'album-and-image-gallery-plus-lightbox' ) => '12',
														),
									'std'			=> 3,
									'description' 	=> __( 'Choose number of column for image gallery.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Album Gallery Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Gallery Image Title', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'show_title',
									'value' 		=> array(
															__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
															__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														),
									'description' 	=> __( 'Display gallery image Title.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Album Gallery Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Gallery Image Description', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'show_description',
									'value' 		=> array(
															__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
															__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														),
									'description' 	=> __( 'Display gallery image Description.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Album Gallery Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Gallery Image Caption', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'show_caption',
									'value' 		=> array(
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
													),
									'description' 	=> __( 'Display gallery image Caption.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Album Gallery Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Popup Image', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'popup',
									'value' 		=> array(
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
													),
									'description' 	=> __( 'Display gallery image in a popup.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Album Gallery Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Gallery Image Link Behaviour', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'link_target',
									'value' 		=> array(
														__( 'Same Window', 'album-and-image-gallery-plus-lightbox' ) 	=> 'self',
														__( 'New Window', 'album-and-image-gallery-plus-lightbox' ) 	=> 'blank',
													),
									'description' 	=> __( 'Choose link bahaviour.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Album Gallery Settings', 'album-and-image-gallery-plus-lightbox' ),
									'dependency' 	=> array(
														'element' 	=> 'popup',
														'value' 	=> array( 'false' ),
														),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Gallery Image Size', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'image_size',
									'value' 		=> array(
														__( 'Full', 'album-and-image-gallery-plus-lightbox' ) 		=> 'full',
														__( 'Medium', 'album-and-image-gallery-plus-lightbox' ) 	=> 'medium',
														__( 'Large', 'album-and-image-gallery-plus-lightbox' ) 		=> 'large',
														__( 'Thumbnail', 'album-and-image-gallery-plus-lightbox' ) 	=> 'thumbnail',
													),
									'description' 	=> __( 'Choose gallery image size.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Album Gallery Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Gallery Height', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'gallery_height',
									'value' 		=> '',
									'description' 	=> __( 'Enter Gallery height. Leave empty for default. e.g 500', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Album Gallery Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Offset (Space Between Two Images)', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'offset',
									'value' 		=> '',
									'description' 	=> __( 'Space between two gallery images. You can enter any numeric number. e.g 5', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Album Gallery Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Masonry Layout', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'masonry',
									'value' 		=> array(
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
													),
									'description' 	=> __( 'Display gallery images in a masonry layout.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Album Gallery Settings', 'album-and-image-gallery-plus-lightbox' ),
								),

								// Data Settings								
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Total Items', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'limit',
									'value' 		=> 15,
									'description' 	=> __( 'Enter number of album to be displayed. Enter -1 to display all.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Data Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Order By', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'orderby',
									'value' 		=> array(
														__( 'Album Date', 'album-and-image-gallery-plus-lightbox' ) 			=> 'date',
														__( 'Album Modified Date', 'album-and-image-gallery-plus-lightbox' ) 	=> 'modified',
														__( 'Album Title', 'album-and-image-gallery-plus-lightbox' ) 			=> 'title',
														__( 'Random', 'album-and-image-gallery-plus-lightbox' ) 				=> 'rand',
														__( 'Menu Order', 'album-and-image-gallery-plus-lightbox' ) 			=> 'menu_order',														
													),
									'description' 	=> __( 'Select order type.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Data Settings', 'album-and-image-gallery-plus-lightbox' )
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Sort Order', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'order',
									'value' 		=> array(
														__( 'Descending', 'album-and-image-gallery-plus-lightbox' ) 	=> 'desc',
														__( 'Ascending', 'album-and-image-gallery-plus-lightbox' ) 	=> 'asc',
													),
									'description' 	=> __( 'Select sorting order.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Data Settings', 'album-and-image-gallery-plus-lightbox' )
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Display Specific Album', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'id',
									'value' 		=> '',
									'description' 	=> sprintf(__( 'Enter id of the album. You can find id at listing <a href="%1$s" target="_blank">page</a>. You can pass multiple ids with comma seperated.', 'album-and-image-gallery-plus-lightbox' ), add_query_arg( array( 'post_type' => AIGPL_PRO_POST_TYPE ), 'edit.php' )),
									'group' 		=> __( 'Data Settings', 'album-and-image-gallery-plus-lightbox' )
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Exclude Album', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'exclude_post',
									'value' 		=> '',
									'description' 	=> sprintf(__( 'Enter id of the album which you do not want to display. You can find id at listing <a href="%1$s" target="_blank">page</a>. You can pass multiple ids with comma seperated.', 'album-and-image-gallery-plus-lightbox' ), add_query_arg( array( 'post_type' => AIGPL_PRO_POST_TYPE ), 'edit.php' )),
									'group' 		=> __( 'Data Settings', 'album-and-image-gallery-plus-lightbox' )
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Category', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'category',
									'value' 		=> '',
									'description' 	=> sprintf(__( 'Enter album category id to display album categories wise. You can pass multiple ids with comma seperated. You can find id at listing <a href="%1$s" target="_blank">page</a>.', 'album-and-image-gallery-plus-lightbox' ), add_query_arg( array( 'taxonomy' => AIGPL_PRO_CAT, 'post_type' => AIGPL_PRO_POST_TYPE ), 'edit-tags.php' )),
									'group' 		=> __( 'Data Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Exclude Category', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'exclude_cat',
									'value' 		=> '',
									'description' 	=> sprintf(__( 'Exclude album category. You can pass multiple ids with comma seperated. Works only if `Category` field is empty. You can find id at listing <a href="%1$s" target="_blank">page</a>.', 'album-and-image-gallery-plus-lightbox' ), add_query_arg( array( 'taxonomy' => AIGPL_PRO_CAT, 'post_type' => AIGPL_PRO_POST_TYPE ), 'edit-tags.php' )),
									'group' 		=> __( 'Data Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Include Category Children', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'include_cat_child',
									'value' 		=> array(
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
													),
									'description' 	=> __( 'Include category children or not. If you choose parent category then whether to display child category album.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Data Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
							)
		));
	}

	/**
	 * Function to add 'aigpl-gallery-album-slider' shortcode in vc
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_integrate_gallery_album_slider_vc() {
		vc_map( array(
			'name' 			=> __( 'WPOS - Album Slider', 'album-and-image-gallery-plus-lightbox' ),
			'base' 			=> 'aigpl-gallery-album-slider',
			'icon' 			=> 'icon-wpb-wp',
			'class' 		=> '',
			'category' 		=> __( 'Content', 'album-and-image-gallery-plus-lightbox'),
			'description' 	=> __( 'Display album in slider view.', 'album-and-image-gallery-plus-lightbox' ),
			'params' 		=> array(
								// General settings
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Design', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'album_design',
									'value' 		=> array(
															__( 'Album Design 1', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-1',
															__( 'Album Design 2', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-2',
															__( 'Album Design 3', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-3',
															__( 'Album Design 4', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-4',
															__( 'Album Design 5', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-5',
															__( 'Album Design 6', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-6',
															__( 'Album Design 7', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-7',
															__( 'Album Design 8', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-8',
															__( 'Album Design 9', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-9',
															__( 'Album Design 10', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-10',
															__( 'Album Design 11', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-11',
															__( 'Album Design 12', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-12',
															__( 'Album Design 13', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-13',
															__( 'Album Design 14', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-14',
															__( 'Album Design 15', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-15',
															__( 'Album Design 16', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-16',
															__( 'Album Design 17', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-17',
														),
									'description' 	=> __( 'Choose album design.', 'album-and-image-gallery-plus-lightbox' ),
									'admin_label' 	=> true,
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Album Title', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'album_title',
									'value' 		=> array(
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
													),
									'description' 	=> __( 'Display album title.', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Album Description', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'album_description',
									'value' 		=> array(
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
													),
									'description' 	=> __( 'Display album description.', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Album Full Content', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'album_full_content',
									'value' 		=> array(
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
													),
									'description' 	=> __( 'Display album full description.', 'album-and-image-gallery-plus-lightbox' ),
									'dependency' 	=> array(
															'element' 	=> 'album_description',
															'value' 	=> array( 'true' ),
														),
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Content Tail', 'wp-responsive-recent-post-slider' ),
									'param_name' 	=> 'content_tail',
									'value' 		=> '...',
									'description' 	=> __( 'Display dots after the post content.', 'wp-responsive-recent-post-slider' ),
									'dependency' 	=> array(
														'element' 	=> 'album_full_content',
														'value' 	=> array( 'false' ),
														),
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Words Limit for Album Description', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'words_limit',
									'value' 		=> 40,
									'description' 	=> __( 'Display number of words for album description.', 'album-and-image-gallery-plus-lightbox' ),
									'dependency' 	=> array(
														'element' 	=> 'album_full_content',
														'value' 	=> array( 'false' ),
														),
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Album Height', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'album_height',
									'value' 		=> '',
									'description' 	=> __( 'Control height of the album. You can enter any numeric number. e.g 500', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Total Photos', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'total_photo',
									'value' 		=> '{total} Photos',
									'description' 	=> __( 'Control photo count label. "{total}" will replace the number of album photos.', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Album Behaviour', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'album_popup',
									'value' 		=> array(
														__( 'Page Reload', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
														__( 'Popup View', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
													),
									'description' 	=> __( 'Choose album gallery behaviour.', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Album Link Behaviour', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'album_link_target',
									'value' 		=> array(
														__( 'Same Window', 'album-and-image-gallery-plus-lightbox' ) 	=> 'self',
														__( 'New Window', 'album-and-image-gallery-plus-lightbox' ) 	=> 'blank',
													),
									'description' 	=> __( 'Choose link behaviour whether to open in a new tab or not.', 'album-and-image-gallery-plus-lightbox' ),
									'dependency' 	=> array(
															'element' 	=> 'album_popup',
															'value' 	=> array( 'false' ),
														),
								),

								// Album Gallery Setting
								array(
									'type' 			=> 'wpos_desc',
									'class' 		=> '',
									'param_name' 	=> 'wpos_desc_alert',
									'value' 		=> __( "Note: This all parameters only works if you had chosen 'Album Behaviour' as a 'Page Reload'.", 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Album Gallery Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Gallery Image Design', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'design',
									'value' 		=> array(
															__( 'Gallery Image Design 1', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-1',
															__( 'Gallery Image Design 2', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-2',
															__( 'Gallery Image Design 3', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-3',
															__( 'Gallery Image Design 4', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-4',
															__( 'Gallery Image Design 5', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-5',
															__( 'Gallery Image Design 6', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-6',
															__( 'Gallery Image Design 7', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-7',
															__( 'Gallery Image Design 8', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-8',
															__( 'Gallery Image Design 9', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-9',
															__( 'Gallery Image Design 10', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-10',
															__( 'Gallery Image Design 11', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-11',
															__( 'Gallery Image Design 12', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-12',
															__( 'Gallery Image Design 13', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-13',
															__( 'Gallery Image Design 14', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-14',
															__( 'Gallery Image Design 15', 'album-and-image-gallery-plus-lightbox' ) 	=> 'design-15',
														),
									'description' 	=> __( 'Choose Gallery Images design. Display when you click on any Album.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Album Gallery Settings', 'album-and-image-gallery-plus-lightbox' ),
									'admin_label' 	=> true,
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Gallery Image Grid', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'grid',
									'value' 		=> array(
															__( 'Grid 1', 'album-and-image-gallery-plus-lightbox' ) => '1',
															__( 'Grid 2', 'album-and-image-gallery-plus-lightbox' ) => '2',
															__( 'Grid 3', 'album-and-image-gallery-plus-lightbox' ) => '3',
															__( 'Grid 4', 'album-and-image-gallery-plus-lightbox' ) => '4',
															__( 'Grid 5', 'album-and-image-gallery-plus-lightbox' ) => '5',
															__( 'Grid 6', 'album-and-image-gallery-plus-lightbox' ) => '6',
															__( 'Grid 7', 'album-and-image-gallery-plus-lightbox' ) => '7',
															__( 'Grid 8', 'album-and-image-gallery-plus-lightbox' ) => '8',
															__( 'Grid 9', 'album-and-image-gallery-plus-lightbox' ) => '9',
															__( 'Grid 10', 'album-and-image-gallery-plus-lightbox' ) => '10',
															__( 'Grid 11', 'album-and-image-gallery-plus-lightbox' ) => '11',
															__( 'Grid 12', 'album-and-image-gallery-plus-lightbox' ) => '12',
														),
									'std'			=> 3,
									'description' 	=> __( 'Choose number of column for image gallery.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Album Gallery Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Gallery Image Title', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'show_title',
									'value' 		=> array(
															__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
															__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														),
									'description' 	=> __( 'Display gallery image Title.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Album Gallery Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Gallery Image Description', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'show_description',
									'value' 		=> array(
															__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
															__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														),
									'description' 	=> __( 'Display gallery image Description.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Album Gallery Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Gallery Image Caption', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'show_caption',
									'value' 		=> array(
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
													),
									'description' 	=> __( 'Display gallery image Caption.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Album Gallery Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Popup Image', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'popup',
									'value' 		=> array(
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
													),
									'description' 	=> __( 'Display gallery image in a popup.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Album Gallery Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Gallery Image Link Behaviour', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'link_target',
									'value' 		=> array(
														__( 'Same Window', 'album-and-image-gallery-plus-lightbox' ) 	=> 'self',
														__( 'New Window', 'album-and-image-gallery-plus-lightbox' ) 	=> 'blank',
													),
									'description' 	=> __( 'Choose link bahaviour.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Album Gallery Settings', 'album-and-image-gallery-plus-lightbox' ),
									'dependency' 	=> array(
														'element' 	=> 'popup',
														'value' 	=> array( 'false' ),
														),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Gallery Image Size', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'image_size',
									'value' 		=> array(
														__( 'Full', 'album-and-image-gallery-plus-lightbox' ) 		=> 'full',
														__( 'Medium', 'album-and-image-gallery-plus-lightbox' ) 	=> 'medium',
														__( 'Large', 'album-and-image-gallery-plus-lightbox' ) 		=> 'large',
														__( 'Thumbnail', 'album-and-image-gallery-plus-lightbox' ) 	=> 'thumbnail',
													),
									'description' 	=> __( 'Choose gallery image size.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Album Gallery Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Gallery Height', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'gallery_height',
									'value' 		=> '',
									'description' 	=> __( 'Enter Gallery height. Leave empty for default. e.g 500', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Album Gallery Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Offset (Space Between Two Images)', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'offset',
									'value' 		=> '',
									'description' 	=> __( 'Space between two gallery images. You can enter any numeric number. e.g 5', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Album Gallery Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Masonry Layout', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'masonry',
									'value' 		=> array(
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
													),
									'description' 	=> __( 'Display gallery images in a masonry layout.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Album Gallery Settings', 'album-and-image-gallery-plus-lightbox' ),
								),

								// Data Settings								
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Total Items', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'limit',
									'value' 		=> 15,
									'description' 	=> __( 'Enter number of album to be displayed. Enter -1 to display all.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Data Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Order By', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'orderby',
									'value' 		=> array(
														__( 'Album Date', 'album-and-image-gallery-plus-lightbox' ) 			=> 'date',
														__( 'Album Modified Date', 'album-and-image-gallery-plus-lightbox' ) 	=> 'modified',
														__( 'Album Title', 'album-and-image-gallery-plus-lightbox' ) 			=> 'title',
														__( 'Random', 'album-and-image-gallery-plus-lightbox' ) 				=> 'rand',
														__( 'Menu Order', 'album-and-image-gallery-plus-lightbox' ) 			=> 'menu_order',														
													),
									'description' 	=> __( 'Select order type.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Data Settings', 'album-and-image-gallery-plus-lightbox' )
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Sort Order', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'order',
									'value' 		=> array(
														__( 'Descending', 'album-and-image-gallery-plus-lightbox' ) 	=> 'desc',
														__( 'Ascending', 'album-and-image-gallery-plus-lightbox' ) 	=> 'asc',
													),
									'description' 	=> __( 'Select sorting order.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Data Settings', 'album-and-image-gallery-plus-lightbox' )
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Display Specific Album', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'id',
									'value' 		=> '',
									'description' 	=> sprintf(__( 'Enter id of the album. You can find id at listing <a href="%1$s" target="_blank">page</a>. You can pass multiple ids with comma seperated.', 'album-and-image-gallery-plus-lightbox' ), add_query_arg( array( 'post_type' => AIGPL_PRO_POST_TYPE ), 'edit.php' )),
									'group' 		=> __( 'Data Settings', 'album-and-image-gallery-plus-lightbox' )
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Exclude Album', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'exclude_post',
									'value' 		=> '',
									'description' 	=> sprintf(__( 'Enter id of the album which you do not want to display. You can find id at listing <a href="%1$s" target="_blank">page</a>. You can pass multiple ids with comma seperated.', 'album-and-image-gallery-plus-lightbox' ), add_query_arg( array( 'post_type' => AIGPL_PRO_POST_TYPE ), 'edit.php' )),
									'group' 		=> __( 'Data Settings', 'album-and-image-gallery-plus-lightbox' )
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Category', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'category',
									'value' 		=> '',
									'description' 	=> sprintf(__( 'Enter album category id to display album categories wise. You can pass multiple ids with comma seperated. You can find id at listing <a href="%1$s" target="_blank">page</a>.', 'album-and-image-gallery-plus-lightbox' ), add_query_arg( array( 'taxonomy' => AIGPL_PRO_CAT, 'post_type' => AIGPL_PRO_POST_TYPE ), 'edit-tags.php' )),
									'group' 		=> __( 'Data Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Exclude Category', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'exclude_cat',
									'value' 		=> '',
									'description' 	=> sprintf(__( 'Exclude album category. You can pass multiple ids with comma seperated. Works only if `Category` field is empty. You can find id at listing <a href="%1$s" target="_blank">page</a>.', 'album-and-image-gallery-plus-lightbox' ), add_query_arg( array( 'taxonomy' => AIGPL_PRO_CAT, 'post_type' => AIGPL_PRO_POST_TYPE ), 'edit-tags.php' )),
									'group' 		=> __( 'Data Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Include Category Children', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'include_cat_child',
									'value' 		=> array(
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
													),
									'description' 	=> __( 'Include category children or not. If you choose parent category then whether to display child category album.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Data Settings', 'album-and-image-gallery-plus-lightbox' ),
								),

								// Slider Setting
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Slides Column', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'album_slidestoshow',
									'value' 		=> 3,
									'description' 	=> __( 'Enter number of column for album slider.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Slider Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Slides Column', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'album_slidestoscroll',
									'value' 		=> '1',
									'description' 	=> __( 'Enter number of slides to scroll at a time.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Slider Settings', 'album-and-image-gallery-plus-lightbox' ),
								),								
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Dots', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'album_dots',
									'value' 		=> array(
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) => 'false',
													),
									'description' 	=> __( 'Show dots indicators.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Slider Settings', 'album-and-image-gallery-plus-lightbox' )
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Arrows', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'album_arrows',
									'value' 		=> array(
															__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
															__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
														),
									'description' 	=> __( 'Show Prev - Next arrows.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Slider Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Autoplay', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'album_autoplay',
									'value' 		=> array(
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
													),
									'description' 	=> __( 'Enable autoplay.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Slider Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Autoplay Interval', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'album_autoplay_interval',
									'value' 		=> '3000',
									'description' 	=> __( 'Enter autoplay speed.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Slider Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'textfield',
									'class' 		=> '',
									'heading' 		=> __( 'Speed', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'album_speed',
									'value' 		=> '300',
									'description' 	=> __( 'Enter slide speed.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Slider Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Infinite', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'album_loop',
									'value' 		=> array(
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
													),
									'description' 	=> __( 'Enable infinite loop sliding.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Slider Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Center Mode', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'album_centermode',
									'value' 		=> array(
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',														
													),
									'description' 	=> __( 'Enable Slider center mode effect.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Slider Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
								array(
									'type' 			=> 'dropdown',
									'class' 		=> '',
									'heading' 		=> __( 'Popup Image', 'album-and-image-gallery-plus-lightbox' ),
									'param_name' 	=> 'popup',
									'value' 		=> array(
														__( 'True', 'album-and-image-gallery-plus-lightbox' ) 	=> 'true',
														__( 'False', 'album-and-image-gallery-plus-lightbox' ) 	=> 'false',
													),
									'description' 	=> __( 'Display gallery image in a popup.', 'album-and-image-gallery-plus-lightbox' ),
									'group' 		=> __( 'Slider Settings', 'album-and-image-gallery-plus-lightbox' ),
								),
							)
		));
	}

	/**
	 * Function to create the new shortcode param
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_create_vc_custom_param() {
		vc_add_shortcode_param( 'wpos_desc', array($this, 'aigpl_pro_vc_param_settings_field') );
	}

	/**
	 * Function for shortcode param html
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_vc_param_settings_field( $settings, $value ) {
		$value = !empty($value) ? $value : $settings['value'];
		return '<div class="aigpl-vc-desc-field" style="background-color:#f2dede; border:1px solid #ebccd1; border-radius:3px; color:#a94442; padding:5px;"><i class="dashicons dashicons-info"></i> '.esc_attr($value).'</div>';
	}
}

$wpaigpl_vc = new Wpaigpl_Vc();
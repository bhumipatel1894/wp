<?php
/**
 * Settings Page
 *
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;
?>

<div class="wrap aigpl-settings">
	
	<h2><?php _e( 'WP Image Gallery and Slider Pro Settings', 'album-and-image-gallery-plus-lightbox' ); ?></h2><br/>
	
	<?php
	// Success message
	if( isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true' ) {
		echo '<div id="message" class="updated notice notice-success is-dismissible">
				<p><strong>'.__("Your changes saved successfully.", "album-and-image-gallery-plus-lightbox").'</strong></p>
			  </div>';
	}
	?>
	
	<form action="options.php" method="POST" id="aigpl-settings-form" class="aigpl-settings-form">
		
		<?php
		    settings_fields( 'aigpl_pro_plugin_options' );
		    global $aigpl_pro_options;
		?>
		
		<!-- General Settings Starts -->
		<div id="aigpl-general-sett" class="post-box-container aigpl-general-sett">
			<div class="metabox-holder">
				<div class="meta-box-sortables ui-sortable">
					<div id="general" class="postbox">

						<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

							<!-- Settings box title -->
							<h3 class="hndle">
								<span><?php _e( 'General Settings', 'album-and-image-gallery-plus-lightbox' ); ?></span>
							</h3>
							
							<div class="inside">
							
							<table class="form-table aigpl-general-sett-tbl">
								<tbody>
									<tr>
										<th scope="row">
											<label for="aigpl-default-img"><?php _e('Default Featured Image', 'album-and-image-gallery-plus-lightbox'); ?>:</label>
										</th>
										<td>
											<input type="text" name="aigpl_pro_options[default_img]" value="<?php echo aigpl_pro_esc_attr( aigpl_pro_get_option('default_img') ); ?>" id="aigpl-default-img" class="regular-text aigpl-default-img aigpl-img-upload-input" />
											<input type="button" name="aigpl_default_img" class="button-secondary aigpl-img-uploader" value="<?php _e( 'Upload Image', 'album-and-image-gallery-plus-lightbox'); ?>" />
											<input type="button" name="aigpl_default_img_clear" id="aigpl-default-img-clear" class="button button-secondary aigpl-image-clear" value="<?php _e( 'Clear', 'album-and-image-gallery-plus-lightbox'); ?>" /> <br />
											<span class="description"><?php _e( 'Upload default featured image or provide an external URL of image. If your post does not have featured image then this will be displayed instead of blank grey box.', 'album-and-image-gallery-plus-lightbox' ); ?></span>
											<?php
												$default_img = '';
												if( aigpl_pro_get_option('default_img') ) { 
													$default_img = '<img src="'.aigpl_pro_get_option('default_img').'" alt="" />';
												}
											?>
											<div class="aigpl-imgs-preview"><?php echo $default_img; ?></div>
										</td>
									</tr>
									<tr>
										<td colspan="2" valign="top" scope="row">
											<input type="submit" id="aigpl-settings-submit" name="aigpl-settings-submit" class="button button-primary right" value="<?php _e('Save Changes','album-and-image-gallery-plus-lightbox'); ?>" />
										</td>
									</tr>
								</tbody>
							 </table>

						</div><!-- .inside -->
					</div><!-- #general -->
				</div><!-- .meta-box-sortables ui-sortable -->
			</div><!-- .metabox-holder -->
		</div><!-- #aigpl-general-sett -->
		<!-- General Settings Ends -->

		
		<!-- Custom CSS Settings Starts -->
		<div id="aigpl-custom-css-sett" class="post-box-container aigpl-custom-css-sett">
			<div class="metabox-holder">
				<div class="meta-box-sortables ui-sortable">
					<div class="postbox">

						<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

							<!-- Settings box title -->
							<h3 class="hndle">
								<span><?php _e( 'Custom CSS Settings', 'album-and-image-gallery-plus-lightbox' ); ?></span>
							</h3>
							
							<div class="inside">
							
							<table class="form-table aigpl-custom-css-tbl">
								<tbody>
									<tr>
										<th scope="row">
											<label for="aigpl-custom-css"><?php _e('Custom CSS', 'album-and-image-gallery-plus-lightbox'); ?>:</label>
										</th>
										<td>
											<textarea name="aigpl_pro_options[custom_css]" class="large-text aigpl-custom-css" id="aigpl-custom-css" rows="15"><?php echo aigpl_pro_esc_attr(aigpl_pro_get_option('custom_css')); ?></textarea><br/>
											<span class="description"><?php _e('Enter custom CSS to override plugin CSS.', 'album-and-image-gallery-plus-lightbox'); ?></span>
										</td>
									</tr>
									<tr>
										<td colspan="2" valign="top" scope="row">
											<input type="submit" id="aigpl-settings-submit" name="aigpl-settings-submit" class="button button-primary right" value="<?php _e('Save Changes','album-and-image-gallery-plus-lightbox');?>" />
										</td>
									</tr>
								</tbody>
							 </table>

						</div><!-- .inside -->
					</div><!-- #aigpl-custom-css -->
				</div><!-- .meta-box-sortables ui-sortable -->
			</div><!-- .metabox-holder -->
		</div><!-- #aigpl-custom-css-sett -->
		<!-- Custom CSS Settings Ends -->
		
	</form><!-- end .aigpl-settings-form -->
	
</div><!-- end .aigpl-settings -->
<?php
/**
 * Plugin generic functions file
 *
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Update default settings
 * 
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */
function aigpl_pro_default_settings() {
    
    global $aigpl_pro_options;
    
    $aigpl_pro_options = array(
        'default_img'   => '',
        'custom_css'    => '',
    );
    
    $default_options = apply_filters('aigpl_options_default_values', $aigpl_pro_options );
    
    // Update default options
    update_option( 'aigpl_pro_options', $default_options );
    
    // Overwrite global variable when option is update
    $aigpl_pro_options = aigpl_pro_get_settings();
}

/**
 * Get Settings From Option Page
 * 
 * Handles to return all settings value
 * 
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */
function aigpl_pro_get_settings() {
  
    $options    = get_option('aigpl_pro_options');
    $settings   = is_array($options)  ? $options : array();
    
    return $settings;
}

/**
 * Get an option
 * Looks to see if the specified setting exists, returns default if not
 * 
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */
function aigpl_pro_get_option( $key = '', $default = false ) {
    global $aigpl_pro_options;

    $value = ! empty( $aigpl_pro_options[ $key ] ) ? $aigpl_pro_options[ $key ] : $default;
    $value = apply_filters( 'aigpl_get_option', $value, $key, $default );
    
    return apply_filters( 'aigpl_get_option_' . $key, $value, $key, $default );
}

/**
 * Escape Tags & Slashes
 *
 * Handles escapping the slashes and tags
 *
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */
function aigpl_pro_esc_attr($data) {
    return esc_attr( stripslashes($data) );
}

/**
 * Strip Slashes From Array
 *
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */
function aigpl_pro_slashes_deep($data = array(), $flag = false) {
  
    if($flag != true) {
        $data = aigpl_pro_nohtml_kses($data);
    }
    $data = stripslashes_deep($data);
    return $data;
}

/**
 * Strip Html Tags 
 * 
 * It will sanitize text input (strip html tags, and escape characters)
 * 
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */

function aigpl_pro_nohtml_kses($data = array()) {
  
  if ( is_array($data) ) {
    
    $data = array_map('aigpl_pro_nohtml_kses', $data);
    
  } elseif ( is_string( $data ) ) {
    $data = trim( $data );
    $data = wp_filter_nohtml_kses($data);
  }
  
  return $data;
}

/**
 * Function to unique number value
 * 
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */
function aigpl_pro_get_unique() {
	static $unique = 0;
	$unique++;

	return $unique;
}

/**
 * Function to unique number value
 * 
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */
function aigpl_pro_unique_num() {
    static $unique = 0;
    $unique++;
    
    return $unique;
}

/**
 * Function to add array after specific key
 * 
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */
function aigpl_pro_add_array(&$array, $value, $index, $from_last = false) {
    
    if( is_array($array) && is_array($value) ) {

        if( $from_last ) {
            $total_count    = count($array);
            $index          = (!empty($total_count) && ($total_count > $index)) ? ($total_count-$index): $index;
        }
        
        $split_arr  = array_splice($array, max(0, $index));
        $array      = array_merge( $array, $value, $split_arr);
    }
    
    return $array;
}

/**
 * Function to get post featured image
 * 
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */
function aigpl_pro_get_image_src( $post_id = '', $size = 'full', $default_img = false ) {
    $size   = !empty($size) ? $size : 'full';
    $image  = wp_get_attachment_image_src( $post_id, $size );

    if( !empty($image) ) {
        $image = isset($image[0]) ? $image[0] : '';
    }

    // Getting default image
    if( $default_img && empty($image) ) {
        $image = aigpl_pro_get_option( 'default_img' );
    }

    return $image;
}

/**
 * Function to get post excerpt
 * 
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */
function aigpl_pro_get_post_excerpt( $post_id = null, $content = '', $word_length = '55', $more = '...' ) {
    
    $has_excerpt    = false;
    $word_length    = !empty($word_length) ? $word_length : '55';
    
    // If post id is passed
    if( !empty($post_id) ) {
        if (has_excerpt($post_id)) {

            $has_excerpt    = true;
            $content        = get_the_excerpt();

        } else {
            $content = !empty($content) ? $content : get_the_content();
        }
    }

    if( !empty($content) && (!$has_excerpt) ) {
        $content = strip_shortcodes( $content ); // Strip shortcodes
        $content = wp_trim_words( $content, $word_length, $more );
    }

    return $content;
}

/**
 * Pagination function for grid
 * 
 * @package WP Blog and Widgets Pro
 * @since 1.2.2
 */
function aigpl_pro_pagination($args = array()) {

    $big = 999999999; // need an unlikely integer

    $paging = apply_filters('aigpl_pro_paging_args', array(
                    'base'      => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                    'format'    => '?paged=%#%',
                    'current'   => max( 1, $args['paged'] ),
                    'total'     => $args['total'],
                    'prev_next' => true,
                    'prev_text' => __('« Previous', 'album-and-image-gallery-plus-lightbox'),
                    'next_text' => __('Next »', 'album-and-image-gallery-plus-lightbox'),
                ));
    
    return paginate_links($paging);
}

/**
 * Function to get `igsp-gallery` shortcode designs
 * 
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */
function aigpl_pro_designs() {
    $design_arr = array(
                    'design-1'  => __('Design 1', 'album-and-image-gallery-plus-lightbox'),
                    'design-2'  => __('Design 2', 'album-and-image-gallery-plus-lightbox'),
                    'design-3'  => __('Design 3', 'album-and-image-gallery-plus-lightbox'),
                    'design-4'  => __('Design 4', 'album-and-image-gallery-plus-lightbox'),
                    'design-5'  => __('Design 5', 'album-and-image-gallery-plus-lightbox'),
                    'design-6'  => __('Design 6', 'album-and-image-gallery-plus-lightbox'),
                    'design-7'  => __('Design 7', 'album-and-image-gallery-plus-lightbox'),
                    'design-8'  => __('Design 8', 'album-and-image-gallery-plus-lightbox'),
                    'design-9'  => __('Design 9', 'album-and-image-gallery-plus-lightbox'),
                    'design-10' => __('Design 10', 'album-and-image-gallery-plus-lightbox'),
                    'design-11' => __('Design 11', 'album-and-image-gallery-plus-lightbox'),
                    'design-12' => __('Design 12', 'album-and-image-gallery-plus-lightbox'),
                    'design-13' => __('Design 13', 'album-and-image-gallery-plus-lightbox'),
                    'design-14' => __('Design 14', 'album-and-image-gallery-plus-lightbox'),
                    'design-15' => __('Design 15', 'album-and-image-gallery-plus-lightbox'),
                );
    return apply_filters('aigpl_designs', $design_arr );
}

/**
 * Function to get `igsp-gallery` shortcode designs
 * 
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */
function aigpl_pro_album_designs() {
    $design_arr = array(
                'design-1'  => __('Design 1', 'album-and-image-gallery-plus-lightbox'),
                'design-2'  => __('Design 2', 'album-and-image-gallery-plus-lightbox'),
                'design-3'  => __('Design 3', 'album-and-image-gallery-plus-lightbox'),
                'design-4'  => __('Design 4', 'album-and-image-gallery-plus-lightbox'),
                'design-5'  => __('Design 5', 'album-and-image-gallery-plus-lightbox'),
                'design-6'  => __('Design 6', 'album-and-image-gallery-plus-lightbox'),
                'design-7'  => __('Design 7', 'album-and-image-gallery-plus-lightbox'),
                'design-8'  => __('Design 8', 'album-and-image-gallery-plus-lightbox'),
                'design-9'  => __('Design 9', 'album-and-image-gallery-plus-lightbox'),
                'design-10' => __('Design 10', 'album-and-image-gallery-plus-lightbox'),
                'design-11' => __('Design 11', 'album-and-image-gallery-plus-lightbox'),
                'design-12' => __('Design 12', 'album-and-image-gallery-plus-lightbox'),
                'design-13' => __('Design 13', 'album-and-image-gallery-plus-lightbox'),
                'design-14' => __('Design 14', 'album-and-image-gallery-plus-lightbox'),
                'design-15' => __('Design 15', 'album-and-image-gallery-plus-lightbox'),
                'design-16' => __('Design 16', 'album-and-image-gallery-plus-lightbox'),
                'design-17' => __('Design 17', 'album-and-image-gallery-plus-lightbox'),
            );
    return apply_filters('aigpl_album_designs', $design_arr );
}
<?php
/**
 * Public Class
 *
 * Handles the public side functionality of plugin
 *
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.2.5
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Aigpl_Pro_Public {

	function __construct() {

		// Ajax call to get album images
		add_action( 'wp_ajax_aigpl_pro_get_album_images', array($this, 'aigpl_pro_get_album_images'));
		add_action( 'wp_ajax_nopriv_aigpl_pro_get_album_images',array( $this, 'aigpl_pro_get_album_images'));
	}

	/**
	 * Function to get album images
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_get_album_images() {

		// Taking some variables
		$prefix = AIGPL_PRO_META_PREFIX;
		$result = array(
							'success' 	=> 0,
							'msg'		=> __('Sorry, Something happened wrong.', 'album-and-image-gallery-plus-lightbox'),
						);

		if( !empty($_POST['album_id']) ) {

			$album_id		= $_POST['album_id'];
			$album_images 	= get_post_meta( $album_id, $prefix.'gallery_imgs', true );

			if( !empty($album_images) ) {
				foreach ($album_images as $img_key => $img_val) {

					$gallery_post	= get_post( $img_val );
					$image_url 		= aigpl_pro_get_image_src( $img_val, 'full' );

					$result['data'][$img_key]['url'] 		= $image_url;
					$result['data'][$img_key]['title'] 		= $gallery_post->post_title;
					$result['data'][$img_key]['caption'] 	= $gallery_post->post_excerpt;
				}
				
				$result['success'] 	= 1;
				$result['msg'] 		= __('success', 'album-and-image-gallery-plus-lightbox');
			}
		}

		echo json_encode($result);
		die();
	}
}

$aigpl_pro_public = new Aigpl_Pro_Public();
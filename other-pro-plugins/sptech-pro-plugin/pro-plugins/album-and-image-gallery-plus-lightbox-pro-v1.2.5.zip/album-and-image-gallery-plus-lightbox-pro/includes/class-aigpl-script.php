<?php
/**
 * Script Class
 *
 * Handles the script and style functionality of plugin
 *
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Aigpl_Pro_Script {
	
	function __construct() {
		
		// Action to add style at front side
		add_action( 'wp_enqueue_scripts', array($this, 'aigpl_pro_front_style') );
		
		// Action to add script at front side
		add_action( 'wp_enqueue_scripts', array($this, 'aigpl_pro_front_script') );
		
		// Action to add style in backend
		add_action( 'admin_enqueue_scripts', array($this, 'aigpl_pro_admin_style') );
		
		// Action to add script at admin side
		add_action( 'admin_enqueue_scripts', array($this, 'aigpl_pro_admin_script') );

		// Action to add custom css in head
		add_action( 'wp_head', array($this, 'aigpl_pro_add_custom_css'), 20 );
	}

	/**
	 * Function to add style at front side
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_front_style() {

		// Registring and enqueing magnific css
		if( !wp_style_is( 'wpos-magnific-style', 'registered' ) ) {
			wp_register_style( 'wpos-magnific-style', AIGPL_PRO_URL.'assets/css/magnific-popup.css', array(), AIGPL_PRO_VERSION );
			wp_enqueue_style( 'wpos-magnific-style');
		}

		// Registring and enqueing ilightbox css
		if( !wp_style_is( 'wpos-ilightbox-style', 'registered' ) ) {
			wp_register_style( 'wpos-ilightbox-style', AIGPL_PRO_URL.'assets/css/lightbox.css', array(), AIGPL_PRO_VERSION );
			wp_enqueue_style( 'wpos-ilightbox-style');
		}

		// Registring and enqueing slick css
		if( !wp_style_is( 'wpos-slick-style', 'registered' ) ) {
			wp_register_style( 'wpos-slick-style', AIGPL_PRO_URL.'assets/css/slick.css', array(), AIGPL_PRO_VERSION );
			wp_enqueue_style( 'wpos-slick-style');	
		}
		
		// Registring and enqueing public css
		wp_register_style( 'aigpl-pro-public-css', AIGPL_PRO_URL.'assets/css/aigpl-pro-public.css', null, AIGPL_PRO_VERSION );
		wp_enqueue_style( 'aigpl-pro-public-css' );
	}
	
	/**
	 * Function to add script at front side
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_front_script() {

		// Registring magnific popup script
		if( !wp_script_is( 'wpos-magnific-script', 'registered' ) ) {
			wp_register_script( 'wpos-magnific-script', AIGPL_PRO_URL.'assets/js/jquery.magnific-popup.min.js', array('jquery'), AIGPL_PRO_VERSION, true );
		}

		// Registring ilightbox popup script
		if( !wp_script_is( 'wpos-ilightbox-script', 'registered' ) ) {
			wp_register_script( 'wpos-ilightbox-script', AIGPL_PRO_URL.'assets/js/ilightbox.min.js', array('jquery'), AIGPL_PRO_VERSION, true );
		}
		
		// Registring slick slider script
		if( !wp_script_is( 'wpos-slick-jquery', 'registered' ) ) {
			wp_register_script( 'wpos-slick-jquery', AIGPL_PRO_URL.'assets/js/slick.min.js', array('jquery'), AIGPL_PRO_VERSION, true );
		}

		// Registring public script
		wp_register_script( 'aigpl-pro-public-js', AIGPL_PRO_URL.'assets/js/aigpl-pro-public.js', array('jquery'), AIGPL_PRO_VERSION, true );
		wp_localize_script( 'aigpl-pro-public-js', 'AigplPro', array(
															'is_mobile' 		=> (wp_is_mobile()) 	? 1 : 0,
															'is_rtl' 			=> (is_rtl()) 			? 1 : 0,
															'ajaxurl' 			=> admin_url( 'admin-ajax.php', ( is_ssl() ? 'https' : 'http' ) ),
														));
	}
	
	/**
	 * Enqueue admin styles
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_admin_style( $hook ) {

		global $typenow;
		
		// If page is plugin setting page then enqueue script
		if( $typenow == AIGPL_PRO_POST_TYPE ) {
			
			// Registring admin script
			wp_register_style( 'aigpl-pro-admin-style', AIGPL_PRO_URL.'assets/css/aigpl-pro-admin.css', null, AIGPL_PRO_VERSION );
			wp_enqueue_style( 'aigpl-pro-admin-style' );
		}
	}

	/**
	 * Function to add script at admin side
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_admin_script( $hook ) {

		global $wp_version, $wp_query, $typenow;
		
		$new_ui = $wp_version >= '3.5' ? '1' : '0'; // Check wordpress version for older scripts

		if( $typenow == AIGPL_PRO_POST_TYPE ) {

			// Enqueue required inbuilt sctipt
			wp_enqueue_script( 'jquery-ui-sortable' );

			// Registring admin script
			wp_register_script( 'aigpl-pro-admin-script', AIGPL_PRO_URL.'assets/js/aigpl-pro-admin.js', array('jquery'), AIGPL_PRO_VERSION, true );
			wp_localize_script( 'aigpl-pro-admin-script', 'AigplProAdmin', array(
																	'new_ui' 					=>	$new_ui,
																	'img_edit_popup_text'		=> __('Edit Image in Popup', 'album-and-image-gallery-plus-lightbox'),
																	'attachment_edit_text'		=> __('Edit Image', 'album-and-image-gallery-plus-lightbox'),
																	'img_delete_text'			=> __('Remove Image', 'album-and-image-gallery-plus-lightbox'),
																	'remove_gallery_imgs_text'	=> __('Are you sure to remove all images from this gallery!', 'album-and-image-gallery-plus-lightbox')
																));
			wp_enqueue_script( 'aigpl-pro-admin-script' );
			wp_enqueue_media(); // For media uploader
		}

		// Gallery Sorting - only when sorting by menu order on the blog listing page
		if ( $typenow == AIGPL_PRO_POST_TYPE && isset( $wp_query->query['orderby'] ) && $wp_query->query['orderby'] == 'menu_order title' ) {
			wp_register_script( 'aigpl-pro-ordering', AIGPL_PRO_URL . 'assets/js/aigpl-pro-ordering.js', array( 'jquery-ui-sortable' ), AIGPL_PRO_VERSION, true );
			wp_enqueue_script( 'aigpl-pro-ordering' );
		}
	}
	
	/**
	 * Add custom css to head
	 * 
	 * @package Album and Image Gallery Plus Lightbox Pro
	 * @since 1.0.0
	 */
	function aigpl_pro_add_custom_css() {

		$custom_css = aigpl_pro_get_option('custom_css');
		
		if( !empty($custom_css) ) {
			$css  = '<style type="text/css">' . "\n";
			$css .= $custom_css;
			$css .= "\n" . '</style>' . "\n";

			echo $css;
		}
	}
}

$aigpl_pro_script = new Aigpl_Pro_Script();
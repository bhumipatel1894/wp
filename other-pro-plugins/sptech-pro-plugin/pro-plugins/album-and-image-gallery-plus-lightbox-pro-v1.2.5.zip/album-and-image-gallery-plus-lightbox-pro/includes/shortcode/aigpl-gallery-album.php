<?php
/**
 * 'aigpl-gallery-album' Shortcode
 * 
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

function aigpl_pro_gallery_album( $atts, $content = null ) {
	
	// Shortcode Parameter
	extract(shortcode_atts(array(
		'limit'				=> 15,
		'album_grid'    	=> '3',
		'album_design' 		=> 'design-1',
		'album_link_target'	=> 'self',
		'album_height'		=> '',
		'album_title'		=> 'true',
		'album_description'	=> 'true',
		'album_full_content'=> 'false',
		'words_limit' 		=> 40,
		'content_tail' 		=> '...',
		'order'				=> 'DESC',
		'orderby'			=> 'date',
		'include_cat_child'	=> true,
		'id'				=> array(),
		'exclude_post'		=> array(),
		'category' 			=> '',
		'exclude_cat'		=> array(),
		'total_photo'		=> '{total}'.' '.__('Photos','album-and-image-gallery-plus-lightbox'),
		'pagination'		=> 'false',
		'pagination_type'	=> 'numeric',
		'album_masonry'		=> 'false',
		'album_popup'		=> 'false',

		'popup'				=> 'true',
		'grid'				=> '3',
		'gallery_height'	=> '',
		'offset'			=> '',
		'design'			=> 'design-1',
		'show_caption'		=> 'true',
		'show_title'		=> 'false',
		'show_description'	=> 'false',
		'link_target'		=> 'self',
		'image_size'		=> 'full',
		'masonry'			=> 'false',
	), $atts));
	
	$unique_album_no 	= aigpl_pro_unique_num();
	$album_designs 		= aigpl_pro_album_designs();
	$content_tail 		= html_entity_decode($content_tail);
	$limit 				= !empty($limit) 					? $limit 							: 15;
	$post_ids			= !empty($id)						? explode(',', $id) 				: array();
	$album_grid 		= (!empty($album_grid) && $album_grid <= 12) 	? $album_grid 			: '3';
	$album_design 		= ($album_design && (array_key_exists(trim($album_design), $album_designs))) ? trim($album_design) : 'design-1';
	$album_link_target 	= ($album_link_target == 'blank') 	? '_blank' 							: '_self';
	$album_title		= ($album_title == 'true')			? 'true'							: 'false';
	$album_description	= ($album_description == 'true')	? 'true'							: 'false';
	$album_full_content	= ($album_full_content == 'true')	? 'true'							: 'false';
	$pagination			= ($pagination == 'true')			? 1									: 0;
	$pagination_type 	= ($pagination_type == 'prev-next')	? 'prev-next' 						: 'numeric';
	$order 				= ( strtolower($order) == 'asc' ) 	? 'ASC' 							: 'DESC';
	$orderby 			= (!empty($orderby))				? $orderby							: 'date';
	$exclude_post 		= !empty($exclude_post)				? explode(',', $exclude_post) 		: array();
	$category 			= (!empty($category))				? explode(',',$category) 			: '';
	$exclude_cat		= !empty($exclude_cat)				? explode(',', $exclude_cat) 		: array();
	$album_height		= !empty($album_height)				? $album_height 					: '';
	$total_photo 		= !empty($total_photo) 				? $total_photo						: '';
	$album_masonry 		= ($album_masonry == 'true')		? 1									: 0;
	$album_popup		= ($album_popup == 'true')			? 1									: 0;
	$album_ses 			= !empty($_GET['album_ses']) 		? $_GET['album_ses'] 				: '';
	$album_height_css	= '';

	// Height
	if( $album_height == 'auto' || ($album_masonry && empty($album_height)) ) {
		$album_height_css = "height:auto;";
	} elseif ( !empty($album_height) ) {
		$album_height_css = "height:{$album_height}px;";
	}
	
	// Taking some global
	global $post;
	
	// Pagination parameter
	if(is_home() || is_front_page()) {
		$paged = get_query_var('page');
	} else {
		$paged = get_query_var('paged');
	}

	// If album id passed and album_ses match to passed number
	if ( isset($_GET['album']) && !empty($_GET['album']) && ($album_ses == $unique_album_no) ) {
		$post_ids = $_GET['album'];
	}

	// Enqueue required script
	if( $album_masonry ) {
		wp_enqueue_script('masonry');
	}
	if( $album_popup ) {
		wp_enqueue_script('wpos-ilightbox-script');
	}
	if( $album_masonry || $album_popup ) {
		wp_enqueue_script('aigpl-pro-public-js');
	}

	// Shortcode file
	$design_file_path 	= AIGPL_PRO_DIR . '/templates/album/' . $album_design . '.php';
	$design_file 		= (file_exists($design_file_path)) ? $design_file_path : '';

	// Taking some variables
	$prefix 			= AIGPL_PRO_META_PREFIX;
	$unique				= aigpl_pro_get_unique();
	$album_page 		= get_permalink();
	$loop_count			= 1;
	$main_cls 			= "aigpl-cnt-wrp aigpl-col-{$album_grid} aigpl-columns";
	$main_wrap_cls		= "aigpl-album-{$album_design}";
	$main_wrap_cls 		.= ($album_masonry) ? ' aigpl-gallery-masonry' 	: '';
	$main_wrap_cls 		.= ($album_popup) 	? ' aigpl-lightbox-gallery' : '';

	// If album id is not passed then take all albums else album images
	if( $album_ses != $unique_album_no ) {

		// WP Query Parameters
		$args = array (
			'post_type'     	 	=> AIGPL_PRO_POST_TYPE,
			'post_status' 			=> array( 'publish' ),
			'post__in'		 		=> $post_ids,
			'ignore_sticky_posts'	=> true,
			'posts_per_page'		=> $limit,
			'paged'         		=> ($pagination) ? $paged : 1,
			'order'					=> $order,
			'orderby'				=> $orderby,
			'post__not_in'			=> $exclude_post,
		);

		// Meta Query
		$args['meta_query'] = array(
								array(
									'key'     => $prefix.'gallery_imgs',
									'value'   => '',
									'compare' => '!=',
								));

		// Category Parameter
		if( !empty($category) ) {

			$args['tax_query'] = array(
									array( 
										'taxonomy' 			=> AIGPL_PRO_CAT,
										'field' 			=> 'term_id',
										'terms' 			=> $category,
										'include_children'	=> $include_cat_child,
								));

		} else if( !empty($exclude_cat) ) {
			
			$args['tax_query'] = array(
										array(
											'taxonomy' 			=> AIGPL_PRO_CAT,
											'field' 			=> 'term_id',
											'terms' 			=> $exclude_cat,
											'operator'			=> 'NOT IN',
											'include_children'	=> $include_cat_child,
									));
		}

		// WP Query Parameters
		$aigpl_query = new WP_Query($args);
	}

	ob_start();

	// If post is there
	if ( ($album_ses != $unique_album_no) && $aigpl_query->have_posts() ) { ?>

		<div class="aigpl-gallery-album-wrp aigpl-gallery-album <?php echo $main_wrap_cls; ?> aigpl-clearfix" id="aigpl-gallery-<?php echo $unique; ?>">

		<?php while ( $aigpl_query->have_posts() ) : $aigpl_query->the_post();
				
				$wrpper_cls			= ($loop_count == 1) 	? $main_cls.' aigpl-first' : $main_cls;
				$album_image 		= (empty($album_popup)) ? add_query_arg( array('album' => $post->ID, 'album_ses' => $unique_album_no), $album_page ) : 'javascript:void(0);';
				$image_link			= aigpl_pro_get_image_src( get_post_thumbnail_id($post->ID), 'full', true );
				$total_photo_no		= get_post_meta($post->ID, $prefix.'gallery_imgs', true);
				$total_photo_no 	= !empty($total_photo_no) ? count($total_photo_no) : '';
				$total_photo_lbl	= str_replace('{total}', $total_photo_no, $total_photo);
				$album_content 		= ($album_full_content == 'true') ? wpautop($post->post_content) : aigpl_pro_get_post_excerpt( $post->ID, $post->post_content, $words_limit, $content_tail );
				
				// Include shortcode html file
				if( $design_file ) {
					include( $design_file );
				}
				
				$loop_count++; // Increment loop count
				
				// Reset loop count
				if( $loop_count == $album_grid ) {
					$loop_count = 0;
				}
		endwhile;
		?>
		</div>

		<?php if( $pagination && ($aigpl_query->max_num_pages > 1) ) { ?>
			<div class="aigpl-paging aigpl-album-<?php echo $album_design; ?> aigpl-clearfix">
				<?php if($pagination_type == "numeric") {
				echo aigpl_pro_pagination( array( 'paged' => $paged , 'total' => $aigpl_query->max_num_pages ) );
				} else { ?>
					<div class="aigpl-pagi-btn aigpl-prev-btn"><?php previous_posts_link( '&laquo; '.__('Previous', 'album-and-image-gallery-plus-lightbox') ); ?></div>
					<div class="aigpl-pagi-btn aigpl-next-btn"><?php next_posts_link( __('Next', 'album-and-image-gallery-plus-lightbox').' &raquo;', $aigpl_query->max_num_pages ); ?></div>
				<?php } ?>
			</div>
		<?php } ?>

	<?php
		wp_reset_query(); // Reset WP Query

	} elseif( !empty($_GET['album']) && ($album_ses == $unique_album_no) ) { // If album id is passed

		echo "<div class='aigpl-breadcrumb-wrp'><a class='aigpl-breadcrumb' href='{$album_page}'>".__('Main Album', 'album-and-image-gallery-plus-lightbox')."</a> &raquo; ".get_the_title($post_ids)."</div>";
		
		echo do_shortcode( '[aigpl-gallery id="'.$post_ids.'" grid="'.$grid.'" gallery_height="'.$gallery_height.'" show_title="'.$show_title.'" show_description="'.$show_description.'" popup="'.$popup.'" offset="'.$offset.'" link_target="'.$link_target.'" design="'.$design.'" image_size="'.$image_size.'" masonry="'.$masonry.'"]' );

	} // end else
	
	$content .= ob_get_clean();
	return $content;
}

// 'aigpl-gallery-album' shortcode
add_shortcode('aigpl-gallery-album', 'aigpl_pro_gallery_album');
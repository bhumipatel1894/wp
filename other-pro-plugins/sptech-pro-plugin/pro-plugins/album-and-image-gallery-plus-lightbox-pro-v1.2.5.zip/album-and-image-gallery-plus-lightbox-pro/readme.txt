=== Album and Image Gallery plus Lightbox Pro ===
Contributors: wponlinesupport, anoopranawat 
Tags: album, image album, gallery, image gallery, responsive image gallery, image slider, image gallery slider, gallery slider, album slider, lightbox
Requires at least: 3.1
Tested up to: 4.7.2

A quick, easy way to add and display responsive image gallery and image album in a grid or slider with lightbox.

== Description ==
A very simple plugin to add image gallery, image album in your post, page and custom post type section and display it on frontend of your website in a Grid, Slider OR carousel view with the help of shorcode. The gallery field provides a simple and intuitive interface for managing a collection of images.

**This testimonial plugin contain two shortcode**
<code>[aigpl-gallery] [aigpl-gallery-slider] [aigpl-gallery-album] and [aigpl-gallery-album-slider]</code>
Where you can display image gallery and image album with lightbox

= Shortcode Examples =

= Here is the shortcode example =
<code>[aigpl-gallery]</code> - Gallery Grid Shortcode
<code>[aigpl-gallery-slider]</code> - Gallery Slider Shortcode
<code>[aigpl-gallery-album]</code> - Image Album Grid Shortcode
<code>[aigpl-gallery-album-slider]</code> - Image Album Slider Shortcode

= Complete shortcode with all parameters =
Gallery Grid Shortcode
<code>[aigpl-gallery id="5" grid="3" design="design-1" link_target="blank" offset="5" gallery_height="400" show_title="false" show_description="false" show_caption="true" image_size="full" popup="true" masonry="false"]</code>

Gallery Slider Shortcode
<code>[aigpl-gallery-slider id="5" grid="3" design="design-1" gallery_height="400" show_title="false" show_description="false" show_caption="true" show_caption="true" image_size="full" popup="true" slidestoshow="3" slidestoscroll="1" loop="true" dots="true" arrows="true" autoplay="true" autoplay_interval="3000" speed="300" centermode="false"]</code>

Image Album Grid Shortcode
<code>[aigpl-gallery-album limit="15" album_grid="3" album_link_target="blank" album_height="400" album_title="true" album_description="true" album_full_content="true" words_limit="40" content_tail="..." order="DESC" orderby="date" id="5,10" exclude_post="5,10" category="5,10" exclude_cat="5,10" total_photo="{total} Photos" popup="true" grid="3" gallery_height="300" offset="5" design="design-1" show_caption="true" show_title="false" show_description="false" link_target="self"]</code>

Image Album Slider Shortcode
<code>[aigpl-gallery-album-slider limit="15" album_grid="3" album_link_target="blank" album_height="400" album_title="true" album_description="true" album_full_content="true" words_limit="40" content_tail="..." order="DESC" orderby="date" id="5,10" exclude_post="5,10" category="5,10" exclude_cat="5,10" total_photo="{total} Photos" popup="true" grid="3" gallery_height="300" offset="5" design="design-1" show_caption="true" show_title="false" show_description="false" link_target="self" album_slidestoshow="3" album_slidestoscroll="1" album_loop="true" album_dots="true" album_arrows="true" album_autoplay="true" album_autoplay_interval="3000" album_speed="300" album_centermode="false"]</code>

= Use Following Gallery parameters with shortcode =
<code>[aigpl-gallery]</code>

* **ID:** [aigpl-gallery id="5"] (Gallery id for which you want to display images.)
* **Grid:** [aigpl-gallery grid="1"] (Number of columns for image gallery. Values are 1 to 12)
* **Design:** [aigpl-gallery design="design-1"] (Select design for image gallery. Designs are design-1 to design-12)
* **Link Behaviour:** [aigpl-gallery link_target="self"] (Choose link behaviour. Values are "self" OR "blank")
* **Offset:** [aigpl-gallery offset="5"] (Space between two images. You can enter any numeric number.)
* **Gallery Height:** [aigpl-gallery gallery_height="400"] (Control height of the image. You can enter any numeric number. You can set "auto" for auto height.)
* **Display Title:** [aigpl-gallery show_title="true"] (Display image title or not. Values are "true" OR "false")
* **Display Description:** [aigpl-gallery show_description="true"] (Display image description. Values are "true" OR "false")
* **Display Caption:** [aigpl-gallery show_caption="true"] (Display image caption. Values are "true" OR "false")
* **Image Size:** [aigpl-gallery image_size="full"] (Choose appropriate image size from the WordPress. Values are "full", "medium", "large" OR "thumbnail".)
* **Popup:** [aigpl-gallery popup="true"] (Display gallery image in a popup. Values are "true" OR "false")
* **Masonry:** [aigpl-gallery masonry="true"] (Display gallery images in a masonry layout.)


= Use Following Gallery Slider parameters with shortcode =
<code>[aigpl-gallery-slider]</code>

* **ID:** [aigpl-gallery-slider id="5"] (Gallery id for which you want to display images.)
* **Grid:** [aigpl-gallery-slider grid="1"] (Number of columns for image gallery. Values are 1 to 12)
* **Design:** [aigpl-gallery-slider design="design-1"] (Select design for image gallery. Designs are design-1 to design-12)
* **Link Behaviour:** [aigpl-gallery-slider link_target="self"] (Choose link behaviour. Values are "self" OR "blank")
* **Gallery Height:** [aigpl-gallery-slider gallery_height="400"] (Control height of the image. You can enter any numeric number. You can set "auto" for auto height.)
* **Display Title:** [aigpl-gallery-slider show_title="true"] (Display image title or not. Values are "true" OR "false")
* **Display Description:** [aigpl-gallery-slider show_description="true"] (Display image description. Values are "true" OR "false")
* **Display Caption:** [aigpl-gallery-slider show_caption="true"] (Display image caption. Values are "true" OR "false")
* **Image Size:** [aigpl-gallery-slider image_size="full"] (Choose appropriate image size from the WordPress. Values are "full", "medium", "large" OR "thumbnail".)
* **Popup:** [aigpl-gallery-slider popup="true"] (Display gallery image in a popup. Values are "true" OR "false")
* **Slider Columns:** [aigpl-gallery-slider slidestoshow="2"] (Display number of images at a time in slider.)
* **Slides to Scroll:** [aigpl-gallery-slider slidestoscroll="2"] (Scroll number of images at a time.)
* **Loop:** [aigpl-gallery-slider loop="true"] (Run slider contineously. Values are "true" OR "false")
* **Slider Pagination and Arrows:** [aigpl-gallery-slider dots="false" arrows="false"]
* **Autoplay : ** [aigpl-gallery-slider autoplay="true"] (Start slider automatically. Values are "true" OR "false".)
* **Autoplay Interval : ** [aigpl-gallery-slider autoplay_interval="3000"] (Delay between two slides.)
* **Slider Speed:** [aigpl-gallery-slider speed="3000"] (Control speed of slider.)
* **Center Mode:** [aigpl-gallery-slider centermode="true"] (Slider center mode effect.)


= Use Following Gallery Album parameters with shortcode =
<code>[aigpl-gallery-album]</code>

* **Limit:** [aigpl-gallery-album limit="5"] (Gallery id for which you want to display images.)
* **Album Grid:** [aigpl-gallery-album album_grid="3"] (Number of columns for image album. Values are 1 to 12.)
* **Link Behaviour:** [aigpl-gallery-album album_link_target="self"] (Choose link behaviour whether to open in a new tab or not. Values are "self" OR "blank")
* **Album Height:** [aigpl-gallery-album album_height="400"] (Control height of the album. You can enter any numeric number.)
* **Album Title:** [aigpl-gallery-album album_title="true"] (Display album title. Values are "true" or "false".)
* **Album Description:** [aigpl-gallery-album album_description="true"] (Display album description. Values are "true" or "false".)
* **Album Full Content:** [aigpl-gallery-album album_full_content="true"] (Display album full description. Values are "true" or "false".)
* **Album Masonry:** [aigpl-gallery-album album_masonry="true"] (Display album in a masonry layout. Values are "true" or "false".)
* **Album Popup:** [aigpl-gallery-album album_popup="true"] (Display album images in a popup view else page will be reload. Values are "true" or "false".)
* **Words Limit:** [aigpl-gallery-album words_limit="40"] (Display number of words for album description.)
* **Content Tail (Continue Reading):** [aigpl-gallery-album content_tail="..."] (Display three dots as a contineous reading.)
* **Order:** [aigpl-gallery-album order="DESC"] (Set album order. Values are "ASC" OR "DESC")
* **Orderby:** [aigpl-gallery-album orderby="date"] (Set orderby for album. You can set "date" (Album Date), "modified" (Album updated date), "title" (Album Title), "rand" (Random), "menu_order" (Sort Order))
* **Display Specific Album:** [aigpl-gallery-album id="5,10"] (Display specific album.)
* **Exclude Specific Testimonial:** [aigpl-gallery-album exclude_post="5,10"] (Exclude some album which you do not want to display.)
* **Display By Category:** [aigpl-gallery-album category="category_id"] (Display album by their category ID.)
* **Exclude Category:** [aigpl-gallery-album exclude_cat="5,10"] (Exclude specific album category which you do not want to display.)
* **Pagination:** [aigpl-gallery-album pagination="true"] (Enable Album pagination.)
* **Total Photo Label:** [aigpl-gallery-album total_photo="{total} Photos"] (Control photo count label. "{total}" will replace the number of album photos.)
* **Popup:** [aigpl-gallery-album popup="true"] (Display gallery image in a popup. Values are "true" OR "false")
* **Grid:** [aigpl-gallery-album grid="1"] (Number of columns for image gallery. Values are 1 to 12)
* **Gallery Height:** [aigpl-gallery-album gallery_height="400"] (Control height of the image. You can enter any numeric number. You can set "auto" for auto height.)
* **Offset:** [aigpl-gallery-album offset="5"] (Space between two images. You can enter any numeric number.)
* **Design:** [aigpl-gallery-album design="design-1"] (Select design for image gallery. Designs are design-1 to design-12)
* **Display Caption:** [aigpl-gallery-album show_caption="true"] (Display image caption. Values are "true" OR "false")
* **Link Behaviour:** [aigpl-gallery-album link_target="self"] (Choose link behaviour. Values are "self" OR "blank")
* **Display Title:** [aigpl-gallery-album show_title="true"] (Display image title or not. Values are "true" OR "false")
* **Display Description:** [aigpl-gallery-album show_description="true"] (Display image description. Values are "true" OR "false")
* **Popup:** [aigpl-gallery-album popup="true"] (Display gallery image in a popup. Values are "true" OR "false")
* **Image Size:** [aigpl-gallery-album image_size="full"] (Choose appropriate image size from the WordPress. Values are "full", "medium", "large" OR "thumbnail".)
* **Masonry:** [aigpl-gallery-album masonry="true"] (Display gallery images in a masonry layout.)


= Use Following Gallery Album Slider parameters with shortcode =
<code>[aigpl-gallery-album-slider]</code>

* **Limit:** [aigpl-gallery-album-slider limit="5"] (Gallery id for which you want to display images.)
* **Link Behaviour:** [aigpl-gallery-album-slider album_link_target="self"] (Choose link behaviour whether to open in a new tab or not. Values are "self" OR "blank")
* **Album Height:** [aigpl-gallery-album-slider album_height="400"] (Control height of the album. You can enter any numeric number.)
* **Album Title:** [aigpl-gallery-album-slider album_title="true"] (Display album title. Values are "true" or "false".)
* **Album Description:** [aigpl-gallery-album-slider album_description="true"] (Display album description. Values are "true" or "false".)
* **Album Full Content:** [aigpl-gallery-album-slider album_full_content="true"] (Display album full description. Values are "true" or "false".)
* **Album Popup:** [aigpl-gallery-album-slider album_popup="true"] (Display album images in a popup view else page will be reload. Values are "true" or "false".)
* **Words Limit:** [aigpl-gallery-album-slider words_limit="40"] (Display number of words for album description.)
* **Content Tail (Continue Reading):** [aigpl-gallery-album-slider content_tail="..."] (Display three dots as a contineous reading.)
* **Order:** [aigpl-gallery-album-slider order="DESC"] (Set album order. Values are "ASC" OR "DESC")
* **Orderby:** [aigpl-gallery-album-slider orderby="date"] (Set orderby for album. You can set "date" (Album Date), "modified" (Album updated date), "title" (Album Title), "rand" (Random), "menu_order" (Sort Order))
* **Display Specific Album:** [aigpl-gallery-album-slider id="5,10"] (Display specific album.)
* **Exclude Specific Album:** [aigpl-gallery-album-slider exclude_post="5,10"] (Exclude some album which you do not want to display.)
* **Display By Category:** [aigpl-gallery-album-slider category="category_id"] (Display album by their category ID.)
* **Include Category Child:** [aigpl-gallery-album-slider include_cat_child="true"] (If you are using parent category then whether to display child category album or not. Values are "true" OR "false")
* **Exclude Category:** [aigpl-gallery-album-slider exclude_cat="5,10"] (Exclude specific album category which you do not want to display.)
* **Total Photo Label:** [aigpl-gallery-album-slider total_photo="{total} Photos"] (Control photo count label. "{total}" will replace the number of album photos.)
* **Popup:** [aigpl-gallery-album-slider popup="true"] (Display gallery image in a popup. Values are "true" OR "false")
* **Grid:** [aigpl-gallery-album-slider grid="1"] (Number of columns for image gallery. Values are 1 to 12)
* **Gallery Height:** [aigpl-gallery-album-slider gallery_height="400"] (Control height of the image. You can enter any numeric number. You can set "auto" for auto height.)
* **Offset:** [aigpl-gallery-album-slider offset="5"] (Space between two images. You can enter any numeric number.)
* **Design:** [aigpl-gallery-album-slider design="design-1"] (Select design for image gallery. Designs are design-1 to design-12)
* **Display Caption:** [aigpl-gallery-album-slider show_caption="true"] (Display image caption. Values are "true" OR "false")
* **Link Behaviour:** [aigpl-gallery-album-slider link_target="self"] (Choose link behaviour. Values are "self" OR "blank")
* **Display Title:** [aigpl-gallery-album-slider show_title="true"] (Display image title or not. Values are "true" OR "false")
* **Display Description:** [aigpl-gallery-album-slider show_description="true"] (Display image description. Values are "true" OR "false")
* **Image Size:** [aigpl-gallery-album-slider image_size="full"] (Choose appropriate image size from the WordPress. Values are "full", "medium", "large" OR "thumbnail".)
* **Masonry:** [aigpl-gallery-album-slider masonry="true"] (Display gallery images in a masonry layout.)
* **Slider Columns:** [aigpl-gallery-slider album_slidestoshow="2"] (Display number of images at a time in slider.)
* **Slides to Scroll:** [aigpl-gallery-slider album_slidestoscroll="2"] (Scroll number of images at a time.)
* **Loop:** [aigpl-gallery-slider album_loop="true"] (Run slider contineously. Values are "true" OR "false")
* **Slider Pagination and Arrows:** [aigpl-gallery-slider album_dots="false" album_arrows="false"]
* **Autoplay : ** [aigpl-gallery-slider album_autoplay="true"] (Start slider automatically. Values are "true" OR "false".)
* **Autoplay Interval : ** [aigpl-gallery-slider album_autoplay_interval="3000"] (Delay between two slides.)
* **Slider Speed:** [aigpl-gallery-slider album_speed="3000"] (Control speed of slider.)
* **Center Mode:** [aigpl-gallery-slider album_centermode="true"] (Slider center mode effect.)


= Template code is =
<code><?php echo do_shortcode('[aigpl-gallery]'); ?></code>
<code><?php echo do_shortcode('[aigpl-gallery-slider]'); ?></code>
<code><?php echo do_shortcode('[aigpl-gallery-album]'); ?></code>
<code><?php echo do_shortcode('[aigpl-gallery-album-slider]'); ?></code>

= Available Features : =
* Gallery Grid
* Gallery Slider
* Image Album Grid
* Image Album Slider
* Category wise album
* 15 Gallery Designs
* Display gallery image with title and description
* Display image album with title and description
* Masonry Style for Gallery
* Easy Drag & Drop Image Feature
* Custom link to gallery image
* Strong Shortcode Parameters
* Slider CenterMode Effect
* Slider RTL support
* Fully responsive
* 100% Multilanguage

== Installation ==

1. Upload the 'Album and Image Gallery plus Lightbox Pro' folder to the '/wp-content/plugins/' directory.
2. Activate the "Album and Image Gallery plus Lightbox Pro" list plugin through the 'Plugins' menu in WordPress.
3. Add a new page and add desired short code in that.


== Changelog ==

= 1.2.5 (25, Feb 2017) =
* [+] Added masonry option for album grid. [aigpl-gallery-album album_masonry="true"]
* [+] Added popup view for album grid and slider. Now user can see all album photos without page load.
* [*] Resolve image overlap issue for masonry on page load.
* [*] Taken care for 'CenterMode' for album slider when slidestoshow is equal to total limit of album.
* [*] Taken care of escaping in image title and alter tag so tag will not be break with quote text.

= 1.2.4 (30, Dec 2016) =
* [+] Added 'Visual Composer' page builder support.
* [*] Updated plugin translation code. Now user can put plugin languages file in WordPress 'language' folder so plugin language file will not be loss while plugin update.

= 1.2.3 (29, Nov 2016) =
* [+] Added action 'aigpl_after_img_data' for gallery grid and slider for future enhancement
* [*] Taken care for unique album to render gallery when multiple album is used in a page and other will be displayed.
* [*] Taken better care for 'CenterMode'. Now 'CenterMode' will be work if it is enable and there is odd number of 'slidestoshow' is passed.
* [*] Optimized some CSS.

= 1.2.2 (25, Nov 2016) =
* [+] Added 16 new designs for album.
* [*] Optimized some CSS.

= 1.2.1 (15, Nov 2016) =
* [+] Added pagination to '[aigpl-gallery-album]' shortcode.
* [*] Resolved CSS float issue with album gridding.
* [*] Resolved one JS error when masonary enabled and popup is false.
* [*] Updated plugin document link.

= 1.2 (10, Nov 2016) =
* [+] Added 'How it Work' page for better user interface.
* [-] Removed 'Plugin Design' page.

= 1.1 (13, Sep 2016) =
* [*] Updated plugin license page.
* Added SSL to https://www.wponlinesupport.com/ for secure updates.

= 1.0 =
* Initial release.

== Upgrade Notice ==

= 1.2.5 (25, Feb 2017) =
* [+] Added masonry option for album grid. [aigpl-gallery-album album_masonry="true"]
* [+] Added popup view for album grid and slider. Now user can see all album photos without page load.
* [*] Resolve image overlap issue for masonry on page load.
* [*] Taken care for 'CenterMode' for album slider when slidestoshow is equal to total limit of album.
* [*] Taken care of escaping in image title and alter tag so tag will not be break with quote text.

= 1.2.4 (30, Dec 2016) =
* [+] Added 'Visual Composer' page builder support.
* [*] Updated plugin translation code. Now user can put plugin languages file in WordPress 'language' folder so plugin language file will not be loss while plugin update.

= 1.2.3 (29, Nov 2016) =
* [+] Added action 'aigpl_after_img_data' for gallery grid and slider for future enhancement
* [*] Taken care for unique album to render gallery when multiple album is used in a page and other will be displayed.
* [*] Taken better care for 'CenterMode'. Now 'CenterMode' will be work if it is enable and there is odd number of 'slidestoshow' is passed.
* [*] Optimized some CSS.

= 1.2.2 (25, Nov 2016) =
* [+] Added 16 new designs for album.
* [*] Optimized some CSS.

= 1.2.1 (15, Nov 2016) =
* [+] Added pagination to '[aigpl-gallery-album]' shortcode.
* [*] Resolved CSS float issue with album gridding.  
* [*] Resolved one JS error when masonary enabled and popup is false.
* [*] Updated plugin document link.

= 1.2 (10, Nov 2016) =
* [+] Added 'How it Work' page for better user interface.
* [-] Removed 'Plugin Design' page.

= 1.1 (13, Sep 2016) =
* [*] Updated plugin license page.
* Added SSL to https://www.wponlinesupport.com/ for secure updates.

= 1.0 =
* Initial release.
<?php
/**
 * Album Design 6 HTML
 * 
 * @package Album and Image Gallery Plus Lightbox Pro
 * @since 1.2.2
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;
?>
<div class="<?php echo $wrpper_cls; ?>" data-id="<?php the_ID(); ?>">
	<div class="aigpl-inr-wrp">

		<div class="aigpl-img-wrp" style="<?php echo $album_height_css; ?>">
			<a class="aigpl-img-link" href="<?php echo $album_image; ?>" target="<?php echo $album_link_target; ?>">
				<?php if($image_link) { ?>
				<img class="aigpl-img" src="<?php echo $image_link; ?>" title="<?php echo aigpl_pro_esc_attr($post->post_title); ?>" alt="<?php _e('Album Image', 'album-and-image-gallery-plus-lightbox'); ?>" />
				<?php } ?>
			</a>
			<?php if( $album_title == 'true' ) { ?>
				<a href="<?php echo $album_image; ?>" target="<?php echo $album_link_target; ?>">
					<div class="aigpl-img-title aigpl-center"><?php echo $post->post_title; ?></div>
				</a>
			<?php } ?>
		</div>

		<?php if( !empty($total_photo_lbl) ) { ?>
		<div class="aigpl-img-count aigpl-center"><?php echo $total_photo_lbl; ?></div>
		<?php } ?>

		<?php if( $album_description == 'true' && $album_content ) { ?>
			<div class="aigpl-img-desc aigpl-center"><?php echo $album_content; ?></div>
		<?php } ?>

	</div>
</div>
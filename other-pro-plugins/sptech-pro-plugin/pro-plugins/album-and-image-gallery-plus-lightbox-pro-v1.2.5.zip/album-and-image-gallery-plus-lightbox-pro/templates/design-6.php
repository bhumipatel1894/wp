<?php
/**
 * Design 6 HTML
 * 
 * @package WP Image Gallery and Slider Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;
?>
<div class="<?php echo $wrpper_cls; ?>" <?php echo $offset_css; ?> data-item-index="<?php echo $count; ?>">
	<div class="aigpl-inr-wrp">

		<div class="aigpl-img-wrp" style="<?php echo $height_css; ?>">
			<?php if($image_link) { ?>
				<img class="aigpl-img" src="<?php echo $gallery_img_src ?>" title="<?php echo aigpl_pro_esc_attr($gallery_post->post_title); ?>" alt="<?php echo aigpl_pro_esc_attr($image_alt_text); ?>" />
				<a class="aigpl-img-link" href="<?php echo $image_link; ?>" target="<?php echo $link_target; ?>"></a>
			<?php } else { ?>
				<img class="aigpl-img" src="<?php echo $gallery_img_src ?>" title="<?php echo aigpl_pro_esc_attr($gallery_post->post_title); ?>" alt="<?php echo aigpl_pro_esc_attr($image_alt_text); ?>" />
			<?php } ?>

			<?php if( $show_caption == 'true' && $gallery_post->post_excerpt ) { ?>
			<div class="aigpl-img-caption">
				<span>
					<?php echo $gallery_post->post_excerpt; ?>
				</span>
			</div>
			<?php } ?>
		</div>

       	<div class="aigpl-img-caption-wrap">
			<?php if( $show_title == 'true' ) { ?>
			<div class="aigpl-img-title"><?php echo $gallery_post->post_title; ?></div>
			<?php } ?>

			<?php if( $show_description == 'true' && !empty($gallery_post->post_content) ) { ?>
			<hr>
			<div class="aigpl-img-desc "><?php echo wpautop($gallery_post->post_content); ?></div>
			<?php } ?>
    	</div>

    	<?php do_action('aigpl_after_img_data', $gallery_post); ?>

	</div>
</div>
<?php
/**
 * Plugin Name: Author Box Ultimate by WPOS
 * Plugin URI: https://www.wponlinesupport.com/
 * Description: Enhance your website with powerpack features.
 * Author: WP Online Support
 * Author URI: https://www.wponlinesupport.com/
 * Text Domain: author-box-ultimate-by-wpos
 * Domain Path: /languages/
 * Version: 1.0
 * 
 * @package WordPress
 * @author WP Online Support
 */

 // Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

if( !defined( 'ABUBWPOS_VERSION' ) ) {
	define( 'ABUBWPOS_VERSION', '1.0' );	// Version of plugin
}

if( !defined( 'ABUBWPOS_DIR' ) ) {
	 define( 'ABUBWPOS_DIR', dirname( __FILE__ ) );  
}
	
if( !defined( 'ABUBWPOS_URL' ) ) {
    define( 'ABUBWPOS_URL', plugin_dir_url( __FILE__ ) ); // Plugin url
}
if( !defined( 'ABUBWPOS_PLUGIN_BASENAME' ) ) {
    define( 'ABUBWPOS_PLUGIN_BASENAME', plugin_basename( __FILE__ ) ); // Plugin base name
}			

/**
 * Activation Hook
 * 
 * Register plugin activation hook.
 * 
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */

register_activation_hook( __FILE__, 'abubwpos_install' );

/**
 * Plugin Setup (On Activation)
 * 
 * Does the initial setup,
 * stest default values for the plugin options.
 * 
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */
function abubwpos_install(){

	// Get settings for the plugin
    $abubwpos_options = get_option( 'abubwpos_options' );
    
    if( empty( $abubwpos_options ) ) { // Check plugin version option
        
        // Set default settings
        abubwpos_default_settings();
        
        // Update plugin version to option
        update_option( 'abubwpos_plugin_version', '1.0' );
    }
}

/**
 * Deactivation Hook
 * 
 * Register plugin deactivation hook.
 * 
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */
register_deactivation_hook( __FILE__, 'abubwpos_uninstall');

/**
 * Plugin Setup (On Deactivation)
 * 
 * Delete  plugin options.
 * 
 * @package WP Responsive Recent Post Slider Pro
 * @since 1.0.0
 */
function abubwpos_uninstall() {
    // Uninstall functionality
}

/**
 * Load Text Domain
 * This gets the plugin ready for translation
 * 
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */
function abubwpos_load_textdomain() {

    global $wp_version;

    // Set filter for plugin's languages directory
    $abubwpos_lang_dir = dirname( plugin_basename( __FILE__ ) ) . '/languages/';
    $abubwpos_lang_dir = apply_filters( 'abubwpos_languages_directory', $abubwpos_lang_dir );
    
    // Traditional WordPress plugin locale filter.
    $get_locale = get_locale();

    if ( $wp_version >= 4.7 ) {
        $get_locale = get_user_locale();
    }

    // Traditional WordPress plugin locale filter
    $locale = apply_filters( 'plugin_locale',  $get_locale, 'author-box-ultimate-by-wpos' );
    $mofile = sprintf( '%1$s-%2$s.mo', 'author-box-ultimate-by-wpos', $locale );

    // Setup paths to current locale file
    $mofile_global  = WP_LANG_DIR . '/plugins/' . basename( ABUBWPOS_DIR ) . '/' . $mofile;

    if ( file_exists( $mofile_global ) ) { // Look in global /wp-content/languages/plugin-name folder
        load_textdomain( 'author-box-ultimate-by-wpos', $mofile_global );
    } else { // Load the default language files
        load_plugin_textdomain( 'author-box-ultimate-by-wpos', false, $abubwpos_lang_dir );
    }
}

// Action to load plugin text domain
add_action('plugins_loaded', 'abubwpos_load_textdomain');

/***** Updater Code Starts *****/
define( 'EDD_ABUBWPOS_STORE_URL', 'https://www.wponlinesupport.com' );
define( 'EDD_ABUBWPOS_ITEM_NAME', 'Author Box Ultimate by WPOS' );

// Plugin Updator Class 
if( !class_exists( 'EDD_SL_Plugin_Updater' ) ) {    
    include( dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php' );
}

/**
 * Updater Function
 * 
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */
function abubwops_plugin_updater() {
    
    $license_key = trim( get_option( 'abubwops_plugin_license_key' ) );

    $edd_updater = new EDD_SL_Plugin_Updater( EDD_ABUBWPOS_STORE_URL, __FILE__, array(
                'version'   => ABUBWPOS_VERSION,          // current version number
                'license'   => $license_key,            // license key (used get_option above to retrieve from DB)
                'item_name' => EDD_ABUBWPOS_ITEM_NAME,     // name of this plugin
                'author'    => 'WP Online Support'      // author of this plugin
            )
    );
}
add_action( 'admin_init', 'abubwops_plugin_updater', 0 );
include( dirname( __FILE__ ) . '/abubwops-plugin-updater.php' );
/***** Updater Code Ends *****/

global $abubwpos_options;
//public generic function
require_once( ABUBWPOS_DIR . '/includes/abubwops-function.php' );
$abubwpos_options = abubwpos_get_settings();

//templating functions
require_once( ABUBWPOS_DIR . '/includes/abubwpos-template-tag.php' );

// Script Class
require_once( ABUBWPOS_DIR . '/includes/class-abubwops-script.php' );

// Admin class
require_once( ABUBWPOS_DIR . '/includes/admin/class-abubwops-admin.php' );

// Public Class
require_once( ABUBWPOS_DIR . '/includes/class-abubwops-public.php' );

// Author Box widgets
require_once( ABUBWPOS_DIR . '/includes/widgets/abubwops-author-widgets.php' );


// Load admin files
if ( is_admin() || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
    
    // Plugin design file
    //require_once( WPRPSP_DIR . '/includes/admin/wprpsp-how-it-work.php' );
}


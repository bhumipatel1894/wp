<?php
/**
 * Plugin generic functions file
 *
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Update default settings
 * 
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */
function abubwpos_default_settings(){
    
    global $abubwpos_options;
    
    $abubwpos_options = array(
                                'abubwpos_autoinsert'                   => '0',
                                'abubwpos_box_margin_top'               => '10',
                                'abubwpos_box_margin_bottom'            => '10',
                                'abubwpos_no_description'               => '0',
                                'abubwpos_avatar_style'                 => 'square',
                                'abubwpos_avatar_hover'                 => '0',
                                'abubwpos_web'                          => '1',
                                'abubwpos_birth_date'                   => '1',
                                'abubwpos_web_position'                 => 'left',
                                'abubwpos_web_target'                   => '',
                                'abubwpos_social_icon_type'             => '',                                
                                'abubwpos_social_icon_style'            => '',                                
                                'abubwpos_social_link_target'           => '',
                                'abubwpos_hide_social_icon'             => '0',                              
                                'abubwpos_design'                       => 'design-1',                              
                                'abubwpos_authore_name_color'           => '',
                                'abubwpos_authore_website_link_color'   => '',
                                'abubwpos_authore_border_color'         => '',
                                'abubwpos_authore_bg_iconbar_color'     => '',
                                'abubwpos_authore_social_icon_color'    => '',
                                'abubwpos_font_subset'                  => '',
                                'abubwpos_name_font'                    => '',
                                'abubwpos_name_font_size'               => '',
                                'abubwpos_website_font'                 => '',
                                'abubwpos_website_font_size'            => '',
                                'abubwpos_description_font'             => '',
                                'abubwpos_description_font_size'        => '',
                                'abubwpos_description_font_style'       => '',
                                'abubwpos_icon_size'                    => '',
                                'abubwpos_load_fa'                      => '',
                                'abubwpos_footer_inline_style'          => '',                                
                            );
    
    $default_options = apply_filters('abubwpos_options_default_values', $abubwpos_options );
    
    // Update default options
    update_option( 'abubwpos_options', $default_options );
    
    // Overwrite global variable when option is update
    $abubwpos_options = abubwpos_get_settings();
}

/**
 * Get Settings From Option Page
 * 
 * Handles to return all settings value
 * 
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */
function abubwpos_get_settings() {
    
    $options = get_option('abubwpos_options');

    $settings = is_array($options)  ? $options : array();
    
    return $settings;
}

/**
 * Get an option
 * Looks to see if the specified setting exists, returns default if not
 * 
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
*/
function abubwpos_get_option( $key = '', $default = false ) {
    global $abubwpos_options;
    
    $value = ! empty( $abubwpos_options[ $key ] ) ? $abubwpos_options[ $key ] : $default;
    $value = apply_filters( 'abubwpos_get_option', $value, $key, $default );
    return apply_filters( 'abubwpos_get_option_' . $key, $value, $key, $default );
}

/**
 * Escape Tags & Slashes
 *
 * Handles escapping the slashes and tags
 *
 * @package  Author Box Ultimate by WPOS
 * @since 1.0.0
 */
function abubwpos_escape_attr($data) {
    return esc_attr( stripslashes($data) );
}

/**
 * Strip Slashes From Array
 *
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */
function abubwpos_slashes_deep($data = array(), $flag = false) {
    
    if($flag != true) {
        $data = abubwpos_nohtml_kses($data);
    }
    $data = stripslashes_deep($data);
    return $data;
}

/**
 * Strip Html Tags 
 * 
 * It will sanitize text input (strip html tags, and escape characters)
 * 
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */
function abubwpos_nohtml_kses($data = array()) {
    
    if ( is_array($data) ) {
        
        $data = array_map('abubwpos_nohtml_kses', $data);
        
    } elseif ( is_string( $data ) ) {
        
        $data = wp_filter_nohtml_kses($data);
    }
    
    return $data;
}

/**
 * Author box design
 * 
 * It will sanitize text input (strip html tags, and escape characters)
 * 
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */
function abubwpos_designs() {
    
    $designs  = array(  'design-1'   => __('Design 1','author-box-ultimate-by-wpos'),
                        'design-2'   => __('Design 2','author-box-ultimate-by-wpos'),
                        'design-3'   => __('Design 3','author-box-ultimate-by-wpos'),
                        'design-4'   => __('Design 4','author-box-ultimate-by-wpos'),
                    ); 
    
    return apply_filters('abubwpos_designs',$designs);
}

/**
 * Get avatar styles
 * 
 * It will sanitize text input (strip html tags, and escape characters)
 * 
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */
function abubwpos_avatar_styles() {
    
    $avatar_styles  = array( 'square'   => __('Square','author-box-ultimate-by-wpos'),
                             'circle'   => __('Circle','author-box-ultimate-by-wpos'),
                        ); 
    
    return apply_filters('abubwpos_avatar_styles',$avatar_styles);
}

/**
 * Function to get icon type
 * 
 * It will sanitize text input (strip html tags, and escape characters)
 * 
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */
function abubwpos_icon_type()
{
    $avatar_position  = array( 'symbols'   => __('Symbols','author-box-ultimate-by-wpos'),
                               'colored'   => __('Colored','author-box-ultimate-by-wpos'),
                        ); 
    
    return apply_filters('abubwpos_icon_type',$avatar_position);
}

/**
 * Function get icon style
 * 
 * It will sanitize text input (strip html tags, and escape characters)
 * 
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */
function abubwpos_icon_style()
{
    $avatar_position  = array( 'squares'    => __('Squares','author-box-ultimate-by-wpos'),
                               'circle'     => __('Circle','author-box-ultimate-by-wpos'),
                        ); 
    
    return apply_filters('abubwpos_icon_style',$avatar_position);
}


/**
 * Decription styles
 * 
 * It will sanitize text input (strip html tags, and escape characters)
 * 
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */
function abubwpos_description_style()
{
    $desc_style  = array(   'normal'   => __('Normal','author-box-ultimate-by-wpos'),
                            'italic'   => __('Italic','author-box-ultimate-by-wpos'),
                        ); 
    
    return apply_filters('abubwpos_description_style',$desc_style);
}

/**
 * Get Post author ID
 * 
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */
function abubwpos_get_post_authorid()
{
    $author_id = 0;
    if ( is_single() || is_author() || is_archive() ) {
        global $post;
        $author_id  = $post->post_author;
    }
    
    return $author_id;
}

/**
 * Function social icon list
 * 
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
*/
function abubwpos_social_icons(){
    $abubwposbox_social_icons_array['abubwpos_social'] = array(
                                            'addthis'       =>  array(  'label'         => __('Add This','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-plus',
                                                                        'class'         => 'abubwpos-addthis',  
                                                                        'description'   => __('Add This','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'behance'       =>  array(  'label'         => __('Behance','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-behance',
                                                                        'class'         => 'abubwpos-addthis',  
                                                                        'description'   => __('Behance','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'delicious'     =>  array(  'label'         => __('Delicious','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-delicious',
                                                                        'class'         => 'abubwpos-delicious',  
                                                                        'description'   => __('Delicious','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'deviantart'    =>  array(  'label'         => __('Deviantart','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-deviantart',
                                                                        'class'         => 'abubwpos-deviantart',  
                                                                        'description'   => __('Deviantart','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'digg'          =>  array(  'label'         => __('Digg','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-digg',
                                                                        'class'         => 'abubwpos-digg',  
                                                                        'description'   => __('Digg','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'dribbble'          =>  array(  'label'         => __('Dribbble','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-dribbble',
                                                                        'class'         => 'abubwpos-dribbble',  
                                                                        'description'   => __('Dribbble','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'facebook'          =>  array(  'label'         => __('Facebook','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-facebook',
                                                                        'class'         => 'abubwpos-facebook',  
                                                                        'description'   => __('Facebook','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'flickr'          =>  array(  'label'         => __('Flickr','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-flickr',
                                                                        'class'         => 'abubwpos-flickr',  
                                                                        'description'   => __('Flickr','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'github'          =>  array(  'label'         => __('Github','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-github',
                                                                        'class'         => 'abubwpos-github',  
                                                                        'description'   => __('Github','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'google'          =>  array(  'label'         => __('Google','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-google',
                                                                        'class'         => 'abubwpos-google',  
                                                                        'description'   => __('Google','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'googleplus'          =>  array(  'label'         => __('Google Plus','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-googleplus',
                                                                        'class'         => 'abubwpos-googleplus',  
                                                                        'description'   => __('Google Plus','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'html5'          =>  array(  'label'         => __('Html5','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-html5',
                                                                        'class'         => 'abubwpos-html5',  
                                                                        'description'   => __('Html5','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'instagram'          =>  array(  'label'         => __('Instagram','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-instagram',
                                                                        'class'         => 'abubwpos-instagram',  
                                                                        'description'   => __('Instagram','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'linkedin'          =>  array(  'label'         => __('Linkedin','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-linkedin',
                                                                        'class'         => 'abubwpos-linkedin',  
                                                                        'description'   => __('Linkedin','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'pinterest'          =>  array(  'label'         => __('Pinterest','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-pinterest',
                                                                        'class'         => 'abubwpos-pinterest',  
                                                                        'description'   => __('Pinterest','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'reddit'          =>  array(  'label'         => __('Reddit','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-reddit',
                                                                        'class'         => 'abubwpos-reddit',  
                                                                        'description'   => __('Reddit','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'rss'          =>  array(  'label'         => __('Rss','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-rss',
                                                                        'class'         => 'abubwpos-rss',  
                                                                        'description'   => __('Rss','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'sharethis'          =>  array(  'label'         => __('Sharethis','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-sharethis',
                                                                        'class'         => 'abubwpos-sharethis',  
                                                                        'description'   => __('Sharethis','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'skype'          =>  array(  'label'         => __('Skype','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-skype',
                                                                        'class'         => 'abubwpos-skype',  
                                                                        'description'   => __('Skype','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'soundcloud'          =>  array(  'label'         => __('Soundcloud','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-soundcloud',
                                                                        'class'         => 'abubwpos-soundcloud',  
                                                                        'description'   => __('Soundcloud','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'spotify'          =>  array(  'label'         => __('Spotify','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-spotify',
                                                                        'class'         => 'abubwpos-spotify',  
                                                                        'description'   => __('Spotify','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'stackoverflow'          =>  array(  'label'         => __('Stackoverflow','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-stackoverflow',
                                                                        'class'         => 'abubwpos-stackoverflow',  
                                                                        'description'   => __('Stackoverflow','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'steam'          =>  array(  'label'         => __('Steam','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-steam',
                                                                        'class'         => 'abubwpos-steam',  
                                                                        'description'   => __('Steam','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'stumbleUpon'          =>  array(  'label'         => __('StumbleUpon','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-stumbleUpon',
                                                                        'class'         => 'abubwpos-stumbleUpon',  
                                                                        'description'   => __('StumbleUpon','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'tumblr'          =>  array(  'label'         => __('Tumblr','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-tumblr',
                                                                        'class'         => 'abubwpos-tumblr',  
                                                                        'description'   => __('Tumblr','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'twitter'          =>  array(  'label'         => __('Twitter','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-twitter',
                                                                        'class'         => 'abubwpos-twitter',  
                                                                        'description'   => __('Twitter','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'vimeo'          =>  array(  'label'         => __('Vimeo','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-vimeo',
                                                                        'class'         => 'abubwpos-vimeo',  
                                                                        'description'   => __('Vimeo','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'windows'          =>  array(  'label'         => __('Windows','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-windows',
                                                                        'class'         => 'abubwpos-windows',  
                                                                        'description'   => __('Windows','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'wordpress'          =>  array(  'label'         => __('Wordpress','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-wordpress',
                                                                        'class'         => 'abubwpos-wordpress',  
                                                                        'description'   => __('Wordpress','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'yahoo'          =>  array(  'label'         => __('Yahoo','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-yahoo',
                                                                        'class'         => 'abubwpos-yahoo',  
                                                                        'description'   => __('Yahoo','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'youtube'          =>  array(  'label'         => __('Youtube','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-youtube',
                                                                        'class'         => 'abubwpos-youtube',  
                                                                        'description'   => __('Youtube','author-box-ultimate-by-wpos'),
                                                                    ),
                                            'xing'          =>  array(  'label'         => __('Xing','author-box-ultimate-by-wpos'),
                                                                        'icon'          => 'fa-xing',
                                                                        'class'         => 'abubwpos-xing',  
                                                                        'description'   => __('Xing','author-box-ultimate-by-wpos'),
                                                                    )
                                            );
    return apply_filters('abubwpos_social_icons',$abubwposbox_social_icons_array);
}

/**
 * Function to merge social link
 * 
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */
function abubwpos_social_link_merge($arra1,$arra2){
    $return_arra = array();
    if(!empty($arra1)){
        foreach ($arra1 as $key => $value) {
            $return_arra[$key] = array( 'label'=>$arra2[$key]['label'],
                                        'description'=>$arra2[$key]['description'],
                                        'icon'=>$arra2[$key]['icon'],
                                        'class'=>$arra2[$key]['class'],
                                        );
            
        }
    }
    foreach ($arra2 as $key => $value) {
        if (!array_key_exists($key,$return_arra)){
            $return_arra[$key] = $value;
        }
    }
    return $return_arra;
    
}

/**
 * function get users list
 * 
 * 
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */
function abubwpos_get_users_list(){
    $users = get_users( array( 'fields' => array( 'ID' ) ) );
    $users_list = array();
    foreach($users as $user_id){
        $users_list[] =array('id'=>$user_id->ID,
            'display_name'=>get_the_author_meta( 'display_name', $user_id->ID));
    }
    return $users_list;
}

/**
 * function to google subset
 * 
 * 
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */
function abubwpos_google_subset(){
    $abubwpos_google_subset = array(
    'None',
    'latin',
    'latin-ext',
    'cyrillic',
    'cyrillic-ext',
    'devanagari',
    'greek',
    'greek-ext',
    'vietnamese',
    'khmer'
    );
    return $abubwpos_google_subset;
}

/**
 * function to google font
 * 
 * 
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */
function abubwpos_google_fonts(){
    

$abubwpos_google_fonts = array (
    'None',
    'ABeeZee',
    'Abel',
    'Abril Fatface',
    'Aclonica',
    'Acme',
    'Actor',
    'Adamina',
    'Advent Pro',
    'Aguafina Script',
    'Akronim',
    'Aladin',
    'Aldrich',
    'Alef',
    'Alegreya',
    'Alegreya SC',
    'Alegreya Sans',
    'Alegreya Sans SC',
    'Alex Brush',
    'Alfa Slab One',
    'Alice',
    'Alike',
    'Alike Angular',
    'Allan',
    'Allerta',
    'Allerta Stencil',
    'Allura',
    'Almendra',
    'Almendra Display',
    'Almendra SC',
    'Amarante',
    'Amaranth',
    'Amatic SC',
    'Amethysta',
    'Anaheim',
    'Andada',
    'Andika',
    'Angkor',
    'Annie Use Your Telescope',
    'Anonymous Pro',
    'Antic',
    'Antic Didone',
    'Antic Slab',
    'Anton',
    'Arapey',
    'Arbutus',
    'Arbutus Slab',
    'Architects Daughter',
    'Archivo Black',
    'Archivo Narrow',
    'Arimo',
    'Arizonia',
    'Armata',
    'Artifika',
    'Arvo',
    'Asap',
    'Asset',
    'Astloch',
    'Asul',
    'Atomic Age',
    'Aubrey',
    'Audiowide',
    'Autour One',
    'Average',
    'Average Sans',
    'Averia Gruesa Libre',
    'Averia Libre',
    'Averia Sans Libre',
    'Averia Serif Libre',
    'Bad Script',
    'Balthazar',
    'Bangers',
    'Basic',
    'Battambang',
    'Baumans',
    'Bayon',
    'Belgrano',
    'Belleza',
    'BenchNine',
    'Bentham',
    'Berkshire Swash',
    'Bevan',
    'Bigelow Rules',
    'Bigshot One',
    'Bilbo',
    'Bilbo Swash Caps',
    'Bitter',
    'Black Ops One',
    'Bokor',
    'Bonbon',
    'Boogaloo',
    'Bowlby One',
    'Bowlby One SC',
    'Brawler',
    'Bree Serif',
    'Bubblegum Sans',
    'Bubbler One',
    'Buda',
    'Buenard',
    'Butcherman',
    'Butterfly Kids',
    'Cabin',
    'Cabin Condensed',
    'Cabin Sketch',
    'Caesar Dressing',
    'Cagliostro',
    'Calligraffitti',
    'Cambo',
    'Candal',
    'Cantarell',
    'Cantata One',
    'Cantora One',
    'Capriola',
    'Cardo',
    'Carme',
    'Carrois Gothic',
    'Carrois Gothic SC',
    'Carter One',
    'Caudex',
    'Cedarville Cursive',
    'Ceviche One',
    'Changa One',
    'Chango',
    'Chau Philomene One',
    'Chela One',
    'Chelsea Market',
    'Chenla',
    'Cherry Cream Soda',
    'Cherry Swash',
    'Chewy',
    'Chicle',
    'Chivo',
    'Cinzel',
    'Cinzel Decorative',
    'Clicker Script',
    'Coda',
    'Coda Caption',
    'Codystar',
    'Combo',
    'Comfortaa',
    'Coming Soon',
    'Concert One',
    'Condiment',
    'Content',
    'Contrail One',
    'Convergence',
    'Cookie',
    'Copse',
    'Corben',
    'Courgette',
    'Cousine',
    'Coustard',
    'Covered By Your Grace',
    'Crafty Girls',
    'Creepster',
    'Crete Round',
    'Crimson Text',
    'Croissant One',
    'Crushed',
    'Cuprum',
    'Cutive',
    'Cutive Mono',
    'Damion',
    'Dancing Script',
    'Dangrek',
    'Dawning of a New Day',
    'Days One',
    'Delius',
    'Delius Swash Caps',
    'Delius Unicase',
    'Della Respira',
    'Denk One',
    'Devonshire',
    'Didact Gothic',
    'Diplomata',
    'Diplomata SC',
    'Domine',
    'Donegal One',
    'Doppio One',
    'Dorsa',
    'Dosis',
    'Dr Sugiyama',
    'Droid Sans',
    'Droid Sans Mono',
    'Droid Serif',
    'Duru Sans',
    'Dynalight',
    'EB Garamond',
    'Eagle Lake',
    'Eater',
    'Economica',
    'Ek Mukta',
    'Electrolize',
    'Elsie',
    'Elsie Swash Caps',
    'Emblema One',
    'Emilys Candy',
    'Engagement',
    'Englebert',
    'Enriqueta',
    'Erica One',
    'Esteban',
    'Euphoria Script',
    'Ewert',
    'Exo',
    'Exo 2',
    'Expletus Sans',
    'Fanwood Text',
    'Fascinate',
    'Fascinate Inline',
    'Faster One',
    'Fasthand',
    'Fauna One',
    'Federant',
    'Federo',
    'Felipa',
    'Fenix',
    'Finger Paint',
    'Fira Mono',
    'Fira Sans',
    'Fjalla One',
    'Fjord One',
    'Flamenco',
    'Flavors',
    'Fondamento',
    'Fontdiner Swanky',
    'Forum',
    'Francois One',
    'Freckle Face',
    'Fredericka the Great',
    'Fredoka One',
    'Freehand',
    'Fresca',
    'Frijole',
    'Fruktur',
    'Fugaz One',
    'GFS Didot',
    'GFS Neohellenic',
    'Gabriela',
    'Gafata',
    'Galdeano',
    'Galindo',
    'Gentium Basic',
    'Gentium Book Basic',
    'Geo',
    'Geostar',
    'Geostar Fill',
    'Germania One',
    'Gilda Display',
    'Give You Glory',
    'Glass Antiqua',
    'Glegoo',
    'Gloria Hallelujah',
    'Goblin One',
    'Gochi Hand',
    'Gorditas',
    'Goudy Bookletter 1911',
    'Graduate',
    'Grand Hotel',
    'Gravitas One',
    'Great Vibes',
    'Griffy',
    'Gruppo',
    'Gudea',
    'Habibi',
    'Hammersmith One',
    'Hanalei',
    'Hanalei Fill',
    'Handlee',
    'Hanuman',
    'Happy Monkey',
    'Headland One',
    'Henny Penny',
    'Herr Von Muellerhoff',
    'Hind',
    'Holtwood One SC',
    'Homemade Apple',
    'Homenaje',
    'IM Fell DW Pica',
    'IM Fell DW Pica SC',
    'IM Fell Double Pica',
    'IM Fell Double Pica SC',
    'IM Fell English',
    'IM Fell English SC',
    'IM Fell French Canon',
    'IM Fell French Canon SC',
    'IM Fell Great Primer',
    'IM Fell Great Primer SC',
    'Iceberg',
    'Iceland',
    'Imprima',
    'Inconsolata',
    'Inder',
    'Indie Flower',
    'Inika',
    'Irish Grover',
    'Istok Web',
    'Italiana',
    'Italianno',
    'Jacques Francois',
    'Jacques Francois Shadow',
    'Jim Nightshade',
    'Jockey One',
    'Jolly Lodger',
    'Josefin Sans',
    'Josefin Slab',
    'Joti One',
    'Judson',
    'Julee',
    'Julius Sans One',
    'Junge',
    'Jura',
    'Just Another Hand',
    'Just Me Again Down Here',
    'Kalam',
    'Kameron',
    'Kantumruy',
    'Karla',
    'Karma',
    'Kaushan Script',
    'Kavoon',
    'Kdam Thmor',
    'Keania One',
    'Kelly Slab',
    'Kenia',
    'Khmer',
    'Kite One',
    'Knewave',
    'Kotta One',
    'Koulen',
    'Kranky',
    'Kreon',
    'Kristi',
    'Krona One',
    'La Belle Aurore',
    'Lancelot',
    'Lato',
    'League Script',
    'Leckerli One',
    'Ledger',
    'Lekton',
    'Lemon',
    'Libre Baskerville',
    'Life Savers',
    'Lilita One',
    'Lily Script One',
    'Limelight',
    'Linden Hill',
    'Lobster',
    'Lobster Two',
    'Londrina Outline',
    'Londrina Shadow',
    'Londrina Sketch',
    'Londrina Solid',
    'Lora',
    'Love Ya Like A Sister',
    'Loved by the King',
    'Lovers Quarrel',
    'Luckiest Guy',
    'Lusitana',
    'Lustria',
    'Macondo',
    'Macondo Swash Caps',
    'Magra',
    'Maiden Orange',
    'Mako',
    'Marcellus',
    'Marcellus SC',
    'Marck Script',
    'Margarine',
    'Marko One',
    'Marmelad',
    'Marvel',
    'Mate',
    'Mate SC',
    'Maven Pro',
    'McLaren',
    'Meddon',
    'MedievalSharp',
    'Medula One',
    'Megrim',
    'Meie Script',
    'Merienda',
    'Merienda One',
    'Merriweather',
    'Merriweather Sans',
    'Metal',
    'Metal Mania',
    'Metamorphous',
    'Metrophobic',
    'Michroma',
    'Milonga',
    'Miltonian',
    'Miltonian Tattoo',
    'Miniver',
    'Miss Fajardose',
    'Modern Antiqua',
    'Molengo',
    'Molle',
    'Monda',
    'Monofett',
    'Monoton',
    'Monsieur La Doulaise',
    'Montaga',
    'Montez',
    'Montserrat',
    'Montserrat Alternates',
    'Montserrat Subrayada',
    'Moul',
    'Moulpali',
    'Mountains of Christmas',
    'Mouse Memoirs',
    'Mr Bedfort',
    'Mr Dafoe',
    'Mr De Haviland',
    'Mrs Saint Delafield',
    'Mrs Sheppards',
    'Muli',
    'Mystery Quest',
    'Neucha',
    'Neuton',
    'New Rocker',
    'News Cycle',
    'Niconne',
    'Nixie One',
    'Nobile',
    'Nokora',
    'Norican',
    'Nosifer',
    'Nothing You Could Do',
    'Noticia Text',
    'Noto Sans',
    'Noto Serif',
    'Nova Cut',
    'Nova Flat',
    'Nova Mono',
    'Nova Oval',
    'Nova Round',
    'Nova Script',
    'Nova Slim',
    'Nova Square',
    'Numans',
    'Nunito',
    'Odor Mean Chey',
    'Offside',
    'Old Standard TT',
    'Oldenburg',
    'Oleo Script',
    'Oleo Script Swash Caps',
    'Open Sans',
    'Open Sans Condensed',
    'Oranienbaum',
    'Orbitron',
    'Oregano',
    'Orienta',
    'Original Surfer',
    'Oswald',
    'Over the Rainbow',
    'Overlock',
    'Overlock SC',
    'Ovo',
    'Oxygen',
    'Oxygen Mono',
    'PT Mono',
    'PT Sans',
    'PT Sans Caption',
    'PT Sans Narrow',
    'PT Serif',
    'PT Serif Caption',
    'Pacifico',
    'Paprika',
    'Parisienne',
    'Passero One',
    'Passion One',
    'Pathway Gothic One',
    'Patrick Hand',
    'Patrick Hand SC',
    'Patua One',
    'Paytone One',
    'Peralta',
    'Permanent Marker',
    'Petit Formal Script',
    'Petrona',
    'Philosopher',
    'Piedra',
    'Pinyon Script',
    'Pirata One',
    'Plaster',
    'Play',
    'Playball',
    'Playfair Display',
    'Playfair Display SC',
    'Podkova',
    'Poiret One',
    'Poller One',
    'Poly',
    'Pompiere',
    'Pontano Sans',
    'Port Lligat Sans',
    'Port Lligat Slab',
    'Prata',
    'Preahvihear',
    'Press Start 2P',
    'Princess Sofia',
    'Prociono',
    'Prosto One',
    'Puritan',
    'Purple Purse',
    'Quando',
    'Quantico',
    'Quattrocento',
    'Quattrocento Sans',
    'Questrial',
    'Quicksand',
    'Quintessential',
    'Qwigley',
    'Racing Sans One',
    'Radley',
    'Rajdhani',
    'Raleway',
    'Raleway Dots',
    'Rambla',
    'Rammetto One',
    'Ranchers',
    'Rancho',
    'Rationale',
    'Redressed',
    'Reenie Beanie',
    'Revalia',
    'Ribeye',
    'Ribeye Marrow',
    'Righteous',
    'Risque',
    'Roboto',
    'Roboto Condensed',
    'Roboto Slab',
    'Rochester',
    'Rock Salt',
    'Rokkitt',
    'Romanesco',
    'Ropa Sans',
    'Rosario',
    'Rosarivo',
    'Rouge Script',
    'Rubik Mono One',
    'Rubik One',
    'Ruda',
    'Rufina',
    'Ruge Boogie',
    'Ruluko',
    'Rum Raisin',
    'Ruslan Display',
    'Russo One',
    'Ruthie',
    'Rye',
    'Sacramento',
    'Sail',
    'Salsa',
    'Sanchez',
    'Sancreek',
    'Sansita One',
    'Sarina',
    'Satisfy',
    'Scada',
    'Schoolbell',
    'Seaweed Script',
    'Sevillana',
    'Seymour One',
    'Shadows Into Light',
    'Shadows Into Light Two',
    'Shanti',
    'Share',
    'Share Tech',
    'Share Tech Mono',
    'Shojumaru',
    'Short Stack',
    'Siemreap',
    'Sigmar One',
    'Signika',
    'Signika Negative',
    'Simonetta',
    'Sintony',
    'Sirin Stencil',
    'Six Caps',
    'Skranji',
    'Slabo 13px',
    'Slabo 27px',
    'Slackey',
    'Smokum',
    'Smythe',
    'Sniglet',
    'Snippet',
    'Snowburst One',
    'Sofadi One',
    'Sofia',
    'Sonsie One',
    'Sorts Mill Goudy',
    'Source Code Pro',
    'Source Sans Pro',
    'Source Serif Pro',
    'Special Elite',
    'Spicy Rice',
    'Spinnaker',
    'Spirax',
    'Squada One',
    'Stalemate',
    'Stalinist One',
    'Stardos Stencil',
    'Stint Ultra Condensed',
    'Stint Ultra Expanded',
    'Stoke',
    'Strait',
    'Sue Ellen Francisco',
    'Sunshiney',
    'Supermercado One',
    'Suwannaphum',
    'Swanky and Moo Moo',
    'Syncopate',
    'Tangerine',
    'Taprom',
    'Tauri',
    'Teko',
    'Telex',
    'Tenor Sans',
    'Text Me One',
    'The Girl Next Door',
    'Tienne',
    'Tinos',
    'Titan One',
    'Titillium Web',
    'Trade Winds',
    'Trocchi',
    'Trochut',
    'Trykker',
    'Tulpen One',
    'Ubuntu',
    'Ubuntu Condensed',
    'Ubuntu Mono',
    'Ultra',
    'Uncial Antiqua',
    'Underdog',
    'Unica One',
    'UnifrakturCook',
    'UnifrakturMaguntia',
    'Unkempt',
    'Unlock',
    'Unna',
    'VT323',
    'Vampiro One',
    'Varela',
    'Varela Round',
    'Vast Shadow',
    'Vibur',
    'Vidaloka',
    'Viga',
    'Voces',
    'Volkhov',
    'Vollkorn',
    'Voltaire',
    'Waiting for the Sunrise',
    'Wallpoet',
    'Walter Turncoat',
    'Warnes',
    'Wellfleet',
    'Wendy One',
    'Wire One',
    'Yanone Kaffeesatz',
    'Yellowtail',
    'Yeseva One',
    'Yesteryear',
    'Zeyada'
);

    return $abubwpos_google_fonts;
}
<?php
/**
 * Plugin Tempalte function
 *
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Function to get users social links
 * 
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */
function abubwpos_social_links($users_social_links = array()){
    $abubwpos_social_links  = abubwpos_social_icons();
    $content = '';
    if(!empty( $users_social_links)){
        foreach ( $users_social_links as $abubwposbox_social_id => $abubwposbox_social_name ) {
            $class = 'abubwpos-icon';
            if ( !empty( $abubwposbox_social_name ) ) {

                if(!empty($abubwpos_social_links['abubwpos_social'][$abubwposbox_social_id]['icon'])){
                $class .= ' fa '.$abubwpos_social_links['abubwpos_social'][$abubwposbox_social_id]['icon'];
                }

                if(!empty($abubwpos_social_links['abubwpos_social'][$abubwposbox_social_id]['class'])){
                $class .= ' '.$abubwpos_social_links['abubwpos_social'][$abubwposbox_social_id]['class'];
                }               

                if(abubwpos_get_option('abubwpos_social_icon_style') =='squares'){
                $class .= ' abubwpos-icon-style-squares';
                }
                else{
                $class .= ' abubwpos-icon-style-circle';
                }

                if( abubwpos_get_option('abubwpos_social_link_target') ) {
                $abubwpos_social_target = '_blank';
                } else {
                $abubwpos_social_target = '_self';
                }

                $content .= '<a class="abubwpos-social-link" href="'.$abubwposbox_social_name.'" target="'.$abubwpos_social_target.'"><i class="'.$class.'"></i></a>';
                }
        }
    }
    return $content;
}
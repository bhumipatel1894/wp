<?php
/**
 * Public Class
 *
 * Handles front side functionality of plugin
 *
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Abubwops_Public {
	
	function __construct() {
		
		// Action to handle submission of testimonial
		add_action('the_content', array($this, 'abubwpos_author_box'));
	}	

	function abubwpos_author_box($content){
		if ( is_single() || is_author() || is_archive() ) {
			global $post;
			$author_id 	= $post->post_author;
			$author_img = '';
			if(abubwpos_get_option('abubwpos_no_description') && get_the_author_meta( 'description', $author_id ) == ''){
				return $content;
			}
			$design = abubwpos_get_option('abubwpos_design');
			// Shortcode file
			$design_file_path 	= ABUBWPOS_DIR . '/templates/' . $design . '.php';
			$design_file 		= (file_exists($design_file_path)) ? $design_file_path : ABUBWPOS_DIR . '/templates/design-1.php';
			$avatar_style 		= 'abubwpos-'.abubwpos_get_option('abubwpos_avatar_style');
			$author_weblink_target = abubwpos_get_option('abubwpos_web_target')? '_blank' : '_self';
			if(!empty(get_the_author_meta( 'display_name', $author_id ))){
				$author_name = get_the_author_meta( 'display_name', $author_id );
			}
			if(!empty(get_the_author_meta( 'description', $author_id ))){
				$author_description = get_the_author_meta( 'description', $author_id );
			}
			if(abubwpos_get_option('abubwpos_web') && !empty(get_the_author_meta( 'url', $author_id ))){
				$author_website = get_the_author_meta( 'url', $author_id );
			}
			if(abubwpos_get_option('abubwpos_birth_date') && !empty(get_the_author_meta( 'abubwpos_data_of_birth', $author_id ))){
				$author_date_of_birth = get_the_author_meta( 'abubwpos_data_of_birth', $author_id );
			}
			if(!empty(get_the_author_meta( 'abubwpos_social', $author_id ))){
				$users_social_links 	= get_the_author_meta( 'abubwpos_social', $author_id );
			}
			ob_start();
			include( $design_file );
			$content .= ob_get_clean();
				
		}
		return $content;
	}
}

$abubwpos_public = new Abubwops_Public();
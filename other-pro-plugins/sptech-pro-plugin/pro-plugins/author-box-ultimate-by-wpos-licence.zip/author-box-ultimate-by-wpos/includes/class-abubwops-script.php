<?php
/**
 * Script Class
 *
 * Handles the script and style functionality of plugin
 *
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Abubwpos_Script {
	
	function __construct() {

        // Action to add style at front side
        add_action( 'wp_enqueue_scripts', array($this, 'abubwpos_front_style') );
        
        // Action to add style in backend
        add_action( 'admin_enqueue_scripts', array($this, 'abubwpos_admin_style') );

        // Action to add script at admin side
        add_action( 'admin_enqueue_scripts', array($this, 'abubwpos_admin_script') );

        // Action to add custom css 
        if(!abubwpos_get_option( 'abubwpos_footer_inline_style' )){
            add_action( 'wp_head', array($this, 'abubwpos_add_custom_css'), 20 );
        } else{
           add_action( 'wp_footer', array( $this, 'abubwpos_add_custom_css' ) ); 
        }
    }

    /**
     * Function to add style at front side
     * 
     * @package Author Box Ultimate by WPOS
     * @since 1.0.0
    */
    function abubwpos_front_style($hook) {
        
        if( !is_single() and !is_page() and !is_author() and !is_archive() ) {
                return;
        }
        global $abubwpos_options;
        // Registring and enqueing public css
        wp_register_style( 'abubwpos-public-style', ABUBWPOS_URL.'assets/css/abubwpos-public.css', array(), ABUBWPOS_VERSION );
        wp_enqueue_style( 'abubwpos-public-style' );

        if(!abubwpos_get_option('abubwpos_load_fa')){
            wp_register_style( 'abubwpos-font-awsome', ABUBWPOS_URL.'assets/css/font-awesome.min.css', array(), ABUBWPOS_VERSION );
            wp_enqueue_style( 'abubwpos-font-awsome' );  
        }

        $abubwpos_protocol = is_ssl() ? 'https' : 'http';

        if ( abubwpos_get_option( 'abubwpos_font_subset' ) != 'none' ) {
            $abubwpos_font_subset = abubwpos_get_option( 'abubwpos_font_subset' );
            $abubwpos_subset = 'subset='.$abubwpos_font_subset;

        } else {
            $abubwpos_subset = 'subset=latin';
        }

        $abubwpos_author_font    = abubwpos_get_option( 'abubwpos_name_font' );
        $abubwpos_desc_font      = abubwpos_get_option( 'abubwpos_description_font' );
        $abubwpos_web_font       = abubwpos_get_option( 'abubwpos_website_font' );

        if ( abubwpos_get_option( 'abubwpos_name_font' ) != 'none' ) {
            wp_enqueue_style( 'abubwpos-author-name-font', $abubwpos_protocol . '://fonts.googleapis.com/css?family='.str_replace(' ', '+', $abubwpos_author_font).':400,700,400italic,700italic'.$abubwpos_subset, array(), null );
        }

        if ( abubwpos_get_option( 'abubwpos_description_font' ) != 'none' ) {
            wp_enqueue_style( 'abubwpos-author-desc-font', $abubwpos_protocol . '://fonts.googleapis.com/css?family='.str_replace(' ', '+', $abubwpos_desc_font).':400,700,400italic,700italic'.$abubwpos_subset, array(), null );
        }

        if ( abubwpos_get_option( 'abubwpos_web' ) && abubwpos_get_option( 'abubwpos_website_font' ) != 'none' ) {
            wp_enqueue_style( 'abubwpos-author-web-font', $abubwpos_protocol . '://fonts.googleapis.com/css?family='.str_replace(' ', '+', $abubwpos_web_font).':400,700,400italic,700italic'.$abubwpos_subset, array(), null );
        }          
    }

    /**
     * Function to add style at admin side
     * 
     * @package Author Box Ultimate by WPOS
     * @since 1.0.0
    */
    function abubwpos_admin_style($hook){

        // Pages array
        $pages_array = array( 'toplevel_page_abubwpos-settings','profile.php','user-edit.php' );
       
        // If page is plugin setting page then enqueue script
        if( in_array($hook, $pages_array) ) {
            // Registring Public Style
            wp_enqueue_style( 'abubwpos-admin-style', ABUBWPOS_URL.'assets/css/abubwpos-admin.css', null, ABUBWPOS_VERSION );
            wp_enqueue_style( 'abubwpos-ui-datepicker', ABUBWPOS_URL.'assets/css/jquery-ui.min.css', null, ABUBWPOS_VERSION );
            // Enqueu built in style for color picker
            if( wp_style_is( 'wp-color-picker', 'registered' ) ) { // Since WordPress 3.5
                wp_enqueue_style( 'wp-color-picker' );
            } else {
                wp_enqueue_style( 'farbtastic' );
            }
        }

    }

    /**
     * Function to add script at admin side
     * 
     * @package Author Box Ultimate by WPOS
     * @since 1.0.0
    */
    function abubwpos_admin_script($hook){
        global $wp_version;

        $new_ui = $wp_version >= '3.5' ? '1' : '0'; // Check wordpress version for older scripts

        // Pages array
        $pages_array = array( 'toplevel_page_abubwpos-settings','profile.php','user-edit.php' );
        
        // If page is plugin setting page then enqueue script
        if( in_array($hook, $pages_array) ) {
            wp_enqueue_script( 'jquery-ui-sortable' );
             wp_enqueue_script( 'jquery-ui-datepicker' );
            // Enqueu built-in script for color picker
            if( wp_script_is( 'wp-color-picker', 'registered' ) ) { // Since WordPress 3.5
                wp_enqueue_script( 'wp-color-picker' );
            } else {
                wp_enqueue_script( 'farbtastic' );
            }

            // Registring admin script
            wp_register_script( 'abubwpos-admin-js', ABUBWPOS_URL.'assets/js/abubwpos-admin.js', array('jquery'), ABUBWPOS_VERSION, true );
            wp_localize_script( 'abubwpos-admin-js', 'Abubwpos_Admin', array(
                                                                    'new_ui' => $new_ui
                                                                ));
            wp_enqueue_script( 'abubwpos-admin-js' );
        }
    }

    function abubwpos_add_custom_css(){
        
        if ( abubwpos_get_option( 'abubwpos_box_margin_top' ) ) {
                $abubwpos_box_margin_top = abubwpos_get_option( 'abubwpos_box_margin_top' );
            } else {
                $abubwpos_box_margin_top = 0;
            }

            if ( abubwpos_get_option( 'abubwpos_box_margin_bottom' ) ) {
                $abubwpos_box_margin_bottom = abubwpos_get_option( 'abubwpos_box_margin_bottom' );
            } else {
                $abubwpos_box_margin_bottom = 0;
            }

             if ( abubwpos_get_option( 'abubwpos_name_font_size' ) ) {
                $abubwpos_name_font_size = abubwpos_get_option( 'abubwpos_name_font_size' );
            } else {
                $abubwpos_name_font_size = 18;
            }

             if ( abubwpos_get_option( 'abubwpos_website_font_size' ) ) {
                $abubwpos_website_font_size = abubwpos_get_option( 'abubwpos_website_font_size' );
            } else {
                $abubwpos_website_font_size = 14;
            }

             if ( abubwpos_get_option( 'abubwpos_description_font_size' ) ) {
                $abubwpos_description_font_size = abubwpos_get_option( 'abubwpos_description_font_size' );
            } else {
                $abubwpos_description_font_size = 14;
            }


             if ( abubwpos_get_option( 'abubwpos_icon_size' ) ) {
                $abubwpos_icon_size = abubwpos_get_option( 'abubwpos_icon_size' );
            } else {
                $abubwpos_icon_size = 14;
            }

            $style = '<style type="text/css">';
             $style .= ' .abubwpos-wrp{margin-top :'.$abubwpos_box_margin_top.'px;}';
             $style .= ' .abubwpos-wrp{margin-bottom :'.$abubwpos_box_margin_bottom.'px;}';
            // Author name font family / font size
            if ( abubwpos_get_option( 'abubwpos_avatar_hover' )) {               
                $style .= '.abubwpos-wrp .abubwpos-avatar img{transition: all 0.5s ease 0s;}';
                $style .= '.abubwpos-wrp .abubwpos-avatar img:hover{transform: rotate(45deg);}';
            }
  
            // Author name font family / font size
            if ( abubwpos_get_option( 'abubwpos_name_font' ) != 'None' ) {
                $abubwpos_name_font = abubwpos_get_option( 'abubwpos_name_font' );
                $style .= ' .abubwpos-wrp .abubwpos-authorname {font-family:"'. esc_html( $abubwpos_name_font ) .'";}';
            }
            $style .= ' .abubwpos-wrp .abubwpos-authorname {font-size:'.$abubwpos_name_font_size.'px;}';
            
            // Author name font color
            if ( !empty(abubwpos_get_option( 'abubwpos_authore_name_color' )) ) {
                $abubwpos_authore_name_color = abubwpos_get_option( 'abubwpos_authore_name_color' );
                $style .= ' .abubwpos-wrp .abubwpos-authorname a {color:'.$abubwpos_authore_name_color.'}';
            }

            // Author web font family / font size
            if ( abubwpos_get_option( 'abubwpos_website_font' ) != 'None' ) {
                $abubwpos_website_font = abubwpos_get_option( 'abubwpos_website_font' );
                $style .= ' .abubwpos-wrp .abubwpos-website {font-family:"'. esc_html( $abubwpos_website_font ) .'";}';
            }
            $style .= ' .abubwpos-wrp .abubwpos-website {font-size:'.$abubwpos_website_font_size.'px;}';
            // Author web font color
            if ( !empty(abubwpos_get_option( 'abubwpos_authore_website_link_color' )) ) {
                $abubwpos_authore_website_link_color = abubwpos_get_option( 'abubwpos_authore_website_link_color' );
                $style .= ' .abubwpos-wrp .abubwpos-website a {color:'.$abubwpos_authore_website_link_color.'}';
            }

            // Author description font family / font size
            if ( abubwpos_get_option( 'abubwpos_description_font' ) != 'None' ) {
                $abubwpos_description_font = abubwpos_get_option( 'abubwpos_description_font' );
                $style .= ' .abubwpos-wrp .abubwpos-desc {font-family:"'. esc_html( $abubwpos_description_font ) .'";}';
            }
            $style .= ' .abubwpos-wrp .abubwpos-desc {font-size:'.$abubwpos_description_font_size.'px;}';

            // Author description style
            if ( abubwpos_get_option( 'abubwpos_description_font_style' ) == 'italic' ) {
                $style .= ' .abubwpos-wrp .abubwpos-desc {font-style:italic}';
            }

            // Author box boder color
            if ( !empty(abubwpos_get_option( 'abubwpos_authore_border_color' ))) {
                $abubwpos_authore_border_color = abubwpos_get_option( 'abubwpos_authore_border_color' );
                $style .= ' .abubwpos-wrp {border-color:'.$abubwpos_authore_border_color.'}';
            }

            //Socialbar background color
            if ( !empty(abubwpos_get_option( 'abubwpos_authore_bg_iconbar_color' ))) {
                $abubwpos_authore_bg_iconbar_color = abubwpos_get_option( 'abubwpos_authore_bg_iconbar_color' );
                $style .= ' .abubwpos-socials {background:'.$abubwpos_authore_bg_iconbar_color.'}';
            }

            //Socialbar icon color
            if ( !empty(abubwpos_get_option( 'abubwpos_authore_social_icon_color' ))) {
                $abubwpos_authore_social_icon_color = abubwpos_get_option( 'abubwpos_authore_social_icon_color' );
                $style .= ' .abubwpos-socials a.abubwpos-social-link {color:'.$abubwpos_authore_social_icon_color.'}';
            }

            //Socialbar icon size
           
            $style .= ' .abubwpos-socials a.abubwpos-social-link {font-size:'.$abubwpos_icon_size.'px}';
            

           $style .= '</style>';
            echo $style;
    }
}

$abubwpos_script = new Abubwpos_Script();
<?php

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

add_action( 'widgets_init', 'abubwpos_authorbox_widget' );

/**
* Register Author box widget
*
* @package Author Box Ultimate by WPOS
* @since 1.0.0
*/
function abubwpos_authorbox_widget() {
	register_widget( 'Abubwpos_Authorbox_Widget' );
}

/**
* Author Box Widget Class
*
* @package Author Box Ultimate by WPOS
* @since 1.0.0
*/
class Abubwpos_Authorbox_Widget extends WP_Widget {

	var $defaults;

	function __construct() {
		
		$widget_ops = array('classname' => 'abubwpos_authorbox_widget', 'description' => __( 'Display authors.', 'author-box-ultimate-by-wpos' ) );
        parent::__construct( 'abubwpos-authorbox-widget', __( 'WPOS - Author Box', 'author-box-ultimate-by-wpos' ), $widget_ops  );

        $this->defaults = array( 
			'title' 				=> '',
			'authors'				=> array(),
			'show_avatar'			=> 'true',
			'show_display_name'		=> 'true',
			'show_birth_date'		=> 'true',
			'show_site_link'		=> 'true',
			'show_bio'				=> 'true',
			'show_social_link'		=> 'true',
			);
	}

	/**
	* Updates the widget control options
	*
	* @package Author Box Ultimate by WPOS
	* @since 1.0.0
	*/
	function update( $new_instance, $old_instance ) {

		$instance = $old_instance;

		// Input fields
		$instance['title'] 						= strip_tags( $new_instance['title'] );
		$instance['authors']					= ( empty($new_instance['authors']) ) ? array() : $new_instance['authors'];
		$instance['show_avatar']				= ( isset($new_instance['show_avatar']) ) 	? 'true' : 'false';
		$instance['show_display_name']			= ( isset($new_instance['show_display_name']) ) 	? 'true' : 'false';
		$instance['show_birth_date']			= ( isset($new_instance['show_birth_date']) ) 	? 'true' : 'false';
		$instance['show_site_link']				= ( isset($new_instance['show_site_link']) ) 	? 'true' : 'false';
		$instance['show_bio']					= ( isset($new_instance['show_bio']) ) 	? 'true' : 'false';
		$instance['show_social_link']			= ( isset($new_instance['show_social_link']) ) 	? 'true' : 'false';
		return $instance;
	}

	/**
	 * Displays the widget form in widget area
	 *
	 * @package Author Box Ultimate by WPOS
	 * @since 1.0.0
	 */
	function form( $instance ) {

		$instance = wp_parse_args( (array) $instance, $this->defaults );
		$user_lists = abubwpos_get_users_list();

	?>

		<!-- Title Field -->
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', 'author-box-ultimate-by-wpos'); ?></label> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $instance['title']; ?>" />
		</p>

		<!-- Userlist Field -->
		<p>
			<label for="<?php echo $this->get_field_id( 'authors' ); ?>"><?php _e( 'Users:', 'author-box-ultimate-by-wpos'); ?></label>
			<?php if( !empty($user_lists) ) { ?>
				<select class="widefat" id="<?php echo $this->get_field_id('authors'); ?>" name="<?php echo $this->get_field_name('authors[]'); ?>" multiple="multiple">
	                <option value="post_author" <?php selected(in_array('post_author', $instance['authors']),true);?>><?php _e('Post Author','author-box-ultimate-by-wpos');?></option>
	                <?php foreach ($user_lists as $user_key => $users_data) {
	                	echo '<option value="'.$users_data['id'].'" '.selected(in_array($users_data['id'], $instance['authors']),true).'>'.$users_data['display_name'].'</option>';
	                    
					} ?>
	            </select>
            <span class="description"><em><?php _e('Select users.', 'author-box-ultimate-by-wpos'); ?></em></span>
            <?php } ?>
		</p>

		<!-- Show avatar Field -->
		<p>
			<input type="checkbox" value="1" id="<?php echo $this->get_field_id( 'show_avatar' ); ?>" name="<?php echo $this->get_field_name( 'show_avatar' ); ?>" <?php checked( $instance['show_avatar'], 'true' ); ?>>
			<label for="<?php echo $this->get_field_id( 'show_avatar' ); ?>"><?php _e( 'Show Avatar', 'author-box-ultimate-by-wpos'); ?></label>
		</p>

		<!-- Show Author Field -->
		<p>
			<input type="checkbox" value="1" id="<?php echo $this->get_field_id( 'show_display_name' ); ?>" name="<?php echo $this->get_field_name( 'show_display_name' ); ?>" <?php checked( $instance['show_display_name'], 'true' ); ?>>
			<label for="<?php echo $this->get_field_id( 'show_display_name' ); ?>"><?php _e( 'Show Display Name', 'author-box-ultimate-by-wpos'); ?></label>
		</p>

		<!-- Show Birth Date Field -->
		<p>
			<input type="checkbox" value="1" id="<?php echo $this->get_field_id( 'show_birth_date' ); ?>" name="<?php echo $this->get_field_name( 'show_birth_date' ); ?>" <?php checked( $instance['show_birth_date'], 'true' ); ?>>
			<label for="<?php echo $this->get_field_id( 'show_birth_date' ); ?>"><?php _e( 'Show Birth Date', 'author-box-ultimate-by-wpos'); ?></label>
		</p>

		<!-- Show Site Link Field -->
		<p>
			<input type="checkbox" value="1" id="<?php echo $this->get_field_id( 'show_site_link' ); ?>" name="<?php echo $this->get_field_name( 'show_site_link' ); ?>" <?php checked( $instance['show_site_link'], 'true' ); ?>>
			<label for="<?php echo $this->get_field_id( 'show_site_link' ); ?>"><?php _e( 'Show Site Link', 'author-box-ultimate-by-wpos'); ?></label>
		</p>

		<!-- Show Bio Field -->
		<p>
			<input type="checkbox" value="1" id="<?php echo $this->get_field_id( 'show_bio' ); ?>" name="<?php echo $this->get_field_name( 'show_bio' ); ?>" <?php checked( $instance['show_bio'], 'true' ); ?>>
			<label for="<?php echo $this->get_field_id( 'show_bio' ); ?>"><?php _e( 'Show Users Bio', 'author-box-ultimate-by-wpos'); ?></label>
		</p>

		<!-- Show Social Links Field -->
		<p>
			<input type="checkbox" value="1" id="<?php echo $this->get_field_id( 'show_social_link' ); ?>" name="<?php echo $this->get_field_name( 'show_social_link' ); ?>" <?php checked( $instance['show_social_link'], 'true' ); ?>>
			<label for="<?php echo $this->get_field_id( 'show_social_link' ); ?>"><?php _e( 'Show Social Links', 'author-box-ultimate-by-wpos'); ?></label>
			
		</p>

		<?php
	}

	/**
	* Outputs the content of the widget
	*
	* @package Author Box Ultimate by WPOS
	* @since 1.0.0
	*/
	function widget( $args, $instance ) {

		extract( $args );

		$title 					= $instance['title'];
		$authors 				= $instance['authors'];
		$show_avatar 			= ($instance['show_avatar'] == 'true')? true : false;
		$show_display_name 		= ($instance['show_display_name'] == 'true')? true : false;
		$show_birth_date		= ($instance['show_birth_date'] == 'true')? true : false;
		$show_site_link			= ($instance['show_site_link'] == 'true')? true : false;
		$show_bio 				= ($instance['show_bio'] == 'true')? true : false;
		$show_social_link 		= ($instance['show_social_link'] == 'true')? true : false;
		
		
		//append post author
		if(!empty($authors) && in_array('post_author',$authors)){
			unset($authors[0]);
			$current_authorid = abubwpos_get_post_authorid();
			if($current_authorid){
				$authors[0] = $current_authorid; 
			}
		}
		// If no  authors are there then return
		if( empty($authors) ) {
			return;
		}
		
		$authors = array_unique($authors);
		echo $before_widget;
		
		if ( $title ) {
            echo $before_title . $title . $after_title;
        }
        ?>
        <div class="widgets-abubwpos-authors-box">
        <ul class="widgets-abubwpos-authorlist">
        <?php
		foreach ($authors as $author_key => $author_data) {
		?>
		<li class="abubwpos-authors-box-content">
			<?php if($show_avatar){?>
				<div class="abubwpos-avatar">
	        	<?php echo get_avatar( get_the_author_meta( 'user_email', $author_data ), '100' );?>
	    		</div>
    		<?php } ?>
    		<?php if($show_display_name){?>
    		<div class="abubwpos-authorname">
        		<a href="<?php echo get_author_posts_url( $author_data );?>"><?php echo get_the_author_meta( 'display_name', $author_data);?></a>
    		</div>
    		<?php }?>
    		<?php if($show_bio){?>
    		<div class="abubwpos-desc"> 
        		<?php echo get_the_author_meta( 'description', $author_data);?>
    		</div>
    		<?php }?>
    		<?php if($show_birth_date){
    			$author_date_of_birth = '';
    			if(!empty(get_the_author_meta( 'abubwpos_data_of_birth',$author_data ))){
					$author_date_of_birth = get_the_author_meta( 'abubwpos_data_of_birth', $author_data);
					$author_date_of_birth = date( get_option('date_format'), strtotime(get_the_author_meta( 'abubwpos_data_of_birth', $author_data)));
				}
				if(!empty($author_date_of_birth)){
    		?>
		    		<div class="abubwpos-bdate"> 
		        		<?php echo $author_date_of_birth;?>  
		    		</div>
    		<?php }
    		}?>
    		<?php if($show_site_link){?>
    		<div class="abubwpos-web-link"> 
        		<a href="<?php echo get_the_author_meta( 'url', $author_data);?>"> <?php echo get_the_author_meta( 'url', $author_data);?></a>
    		</div>
    		<?php }?>
    		
    		<?php if($show_social_link){
    				$users_social_links 	= get_the_author_meta( 'abubwpos_social', $author_data );
    		  		if(!empty( $users_social_links)){ ?>
    				<div class="abubwpos-socials">
        				<?php echo abubwpos_social_links($users_social_links);?>
    				</div>
   			 		<?php }?>
    		<?php }?>
		</li>
		<?php
		}
		?>
		</ul>
		</div>
		<?php
		echo $after_widget;
	}
}
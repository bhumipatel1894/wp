=== Author Box Ultimate by WPOS ===
Contributors: wponlinesupport, anoopranawat 
Requires at least: 3.1
Tested up to: 4.7.2
Author URI: http://wponlinesupport.com
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Adds a cool responsive author box with social icons on your posts.

== Description ==

**Simple Author Box** adds a responsive author box at the end of your posts, showing the author name, author gravatar and author description. It also adds over 30 social profile fields on WordPress user profile screen, allowing to display the author social icons.

= Main Features =

* Shows author gravatar, name, website, description and social icons
* Fully customizable to match your theme design (style, color, size and text options)
* Nice looking on desktop, laptop, tablet or mobile phones
* Automatically insert the author box at the end of your post
* Option to manually insert the author box on your template file (single.php or author.php)
* Simple Author Box has RTL support

Check out our [Premium Themes](https://themeforest.net/user/tiguan/portfolio?ref=tiguan) that use Simple Author Box plugin.

== Installation ==

1. Download the plugin (.zip file) on your hard drive.
2. Unzip the zip file contents.
3. Upload the `simple-author-box` folder to the `/wp-content/plugins/` directory.
4. Activate the plugin through the 'Plugins' menu in WordPress.
5. A new sub menu item `Simple Author Box` will appear in your main Settings menu.

If you need more info, please read the plugin [documentation](http://tiguandesign.com/docs/simple-author-box/).



== Changelog ==


= 1.0 =
* Initial release
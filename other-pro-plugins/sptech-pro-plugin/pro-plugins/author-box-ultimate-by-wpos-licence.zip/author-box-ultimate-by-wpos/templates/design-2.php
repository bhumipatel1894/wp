<div class="abubwpos-wrp">
     
    <?php if(!empty( $users_social_links)){ ?>
    <div class="abubwpos-socials">
        <?php echo abubwpos_social_links($users_social_links);?>
    </div>
    <?php }?>
    <div class="abubwpos-clearfix"></div>
    <div class="abubwpos-avatar <?php echo $avatar_style;?>">
        <?php echo get_avatar( get_the_author_meta( 'user_email', $author_id ), '100' );?>
    </div>
    <?php if(!empty($author_name)){?>
    <div class="abubwpos-authorname">
        <a href="<?php echo get_author_posts_url( $author_id );?>"><?php echo $author_name;?></a>
    </div>
    <?php }?>
    <?php if(!empty($author_description)){?>
     <div class="abubwpos-desc">         
        <?php echo $author_description;?>   
    </div>
    <?php }?>
    <?php if(!empty($author_website)){?>
    <div class="abubwpos-website">
        <a href="<?php echo $author_website;?>" target="<?php echo $author_weblink_target;?>"><?php echo $author_website;?></a>
    </div>
    <?php }?>
    <?php if(!empty($author_date_of_birth)){?>
    <div class="abubwpos-bdate">
        <?php echo date( get_option('date_format'), strtotime($author_date_of_birth));?>   
    </div>
    <?php }?>
   
</div>
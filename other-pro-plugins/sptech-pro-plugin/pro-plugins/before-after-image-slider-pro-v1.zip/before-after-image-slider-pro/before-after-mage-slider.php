<?php
/*
 * Plugin Name: Before and After Image Slider Pro
 * Plugin URL: https://www.wponlinesupport.com
 * Text Domain: before-after-image-slider
 * Description: The Before & After Image Slider for Wordpress allows you to easily show and compare two images using multiple modes. 
 * Domain Path: /languages/
 * Version: 1.0
 * Author: WP Online Support
 * Author URI: https://www.wponlinesupport.com
 * Contributors: WP Online Support
*/

if( !defined( 'BAFIS_VERSION' ) ) {
	define( 'BAFIS_VERSION', '1.0' ); // Version of plugin
}

if( !defined( 'BAFIS_DIR' ) ) {
    define( 'BAFIS_DIR', dirname( __FILE__ ) ); // Plugin dir
}

if( !defined( 'BAFIS_URL' ) ) {
    define( 'BAFIS_URL', plugin_dir_url( __FILE__ ) ); // Plugin url
}
if( !defined( 'BAFIS_PLUGIN_BASENAME' ) ) {
    define( 'BAFIS_PLUGIN_BASENAME', plugin_basename( __FILE__ ) ); // Plugin base name
}

add_action('plugins_loaded', 'bafis_load_textdomain');
function bafis_load_textdomain() {
	load_plugin_textdomain( 'before-after-image-slider', false, dirname( plugin_basename(__FILE__) ) . '/languages/' );
}

/***** Updater Code Starts *****/
define( 'EDD_BAFIS_STORE_URL', 'https://www.wponlinesupport.com' );
define( 'EDD_BAFIS_ITEM_NAME', 'Before and After Image Slider Pro' );

// Plugin Updator Class 
if( !class_exists( 'EDD_SL_Plugin_Updater' ) ) {	
	include( dirname( __FILE__ ) . '/EDD_Plugin_Updater.php' );
}

/**
 * Updater Function
 * 
 * @package Before & After Image Slider
 * @since 1.0.0
 */
function edd_sl_bafis_plugin_updater() {
	
	$license_key = trim( get_option( 'edd_bafis_license_key' ) );

    $edd_updater = new EDD_SL_Plugin_Updater( EDD_BAFIS_STORE_URL, __FILE__, array(
                'version' 	=> BAFIS_VERSION,           // current version number
                'license' 	=> $license_key, 		     // license key (used get_option above to retrieve from DB)
                'item_name' => EDD_BAFIS_ITEM_NAME,    // name of this plugin
                'author' 	=> 'WP Online Support'       // author of this plugin
            )
    );

}
add_action( 'admin_init', 'edd_sl_bafis_plugin_updater', 0 );
include( dirname( __FILE__ ) . '/edd-plugin.php' );
/***** Updater Code Ends *****/



add_action( 'wp_enqueue_scripts','bafis_script' );
function bafis_script() {    
	wp_register_style( 'bafis-css', BAFIS_URL.'assets/css/bafis-css.css', null, BAFIS_VERSION );
	wp_enqueue_style( 'bafis-css' );
	
	wp_register_script( 'bafis-event-move-js', BAFIS_URL.'assets/js/jquery.event.move.js', array('jquery'), BAFIS_VERSION, true );	
	wp_register_script( 'bafis-twentytwenty-js', BAFIS_URL.'assets/js/jquery.twentytwenty.js', array('jquery'), BAFIS_VERSION, true );
   
}

/**
 * Function to unique number value
 * 
 * @Before & After Image Slider
 * @since 1.0
 */
function bafis_get_unique() {
    static $unique = 0;
    $unique++;

    return $unique;
}

/*
 * Add shortcode
 *
 */
function bafis_shortcode( $atts, $content = null ) {
	extract(shortcode_atts(array(
		"before_img"   => '',
		"before_label" => '',
		"after_img"    => '',
		"after_label"  => '',
		"orientation"  => '',
		"offset"       => '',
		"width"        => '',	
		
	), $atts));
	// Define link
	
	$before_img_1 = !empty($before_img) ? $before_img : BAFIS_URL.'/assets/images/before.jpg' ;
	$after_img_2 = !empty($after_img) ? $after_img : BAFIS_URL.'/assets/images/after.jpg' ;
	

	if( $before_label ) { 
		$before_label_1 = $before_label; 
	} else {
		$before_label_1 = 'Before';
	}
	
	
	if( $after_label ) { 
		$after_label_2 = $after_label; 
	} else {
		$after_label_2 = 'After';
	}
	
	// Define name
	if( $orientation ) { 
		$image_orientation = $orientation; 
	} else {
		$image_orientation = 'vertical';
	}
	
	// Define type
	if( $offset ) { 
		$image_offset = $offset; 
	} else {
		$image_offset = '0.5';
	}
	
	// Define type
	if( $width ) { 
		$image_width = $width; 
	} else {
		$image_width = '100%';
	}
	
	
	wp_enqueue_script('bafis-event-move-js');
	wp_enqueue_script('bafis-twentytwenty-js');
	$unique = bafis_get_unique();
	ob_start(); ?>
	<div class="main-container-wrap bafis-clearfix" style="max-width:<?php echo $image_width; ?>">	
		  <div id="bafis-<?php echo $unique;?>" class="twentytwenty-container">
			  <img src="<?php echo $before_img_1; ?>" />
				<img src="<?php echo $after_img_2; ?>" />
			</div>
		</div>	
		 <script>
			jQuery(window).load(function(){			 
			 jQuery("#bafis-"+<?php echo $unique;?>).twentytwenty(
				{
					default_offset_pct: <?php echo $image_offset; ?>, 
					orientation: '<?php echo $image_orientation; ?>',
					before_label: '<?php echo $before_label_1; ?>',
					after_label: '<?php echo $after_label_2; ?>'
				});
			});
			</script>
	<?php return ob_get_clean();
}
add_shortcode("bafis_image", "bafis_shortcode");


// How it work file, Load admin files
if ( is_admin() || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
    require_once( BAFIS_DIR . '/admin/bafis-how-it-work.php' );
}
=== Before and After Image Slider Pro ===
Tags:  after, before, before after, compare, comparison, difference, effects, gallery, image, images, responsive, slider, touch, viewer
Contributors: wponlinesupport, anoopranawat 
Requires at least: 3.1
Tested up to: 4.7.2
Author URI: http://wponlinesupport.com
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The Before & After Image Slider for Wordpress allows you to easily show and compare two images using multiple modes.

== Description ==
The Before & After Image Slider for Wordpress allows you to easily show and compare two images using multiple modes.

Before After WordPress plugin, that makes it easy to highlight the visual differences between two images. Perfect to showcase your work, where it’s essential to visualize the changes you’ve made.

= Features =
* Side by side - Using multiple comparisons at once.
* Vertical Orientation - Demonstrates sliding up and down.


= Here is the example =
<code>[bafis_image before_img="http://www.domainname.com/image-1.jpg" after_img="http://www.domainname.com/image-2.jpg" orientation="horizontal" offset="0.5" before_label="Before" after_label="After"]</code>


== Installation ==

1. Upload the 'before-after-image-slider' folder to the '/wp-content/plugins/' directory.
2. Activate the "before-after-image-slider" list plugin through the 'Plugins' menu in WordPress.
3. Add this short code where you want to display button
<code>[bafis_image]</code>


== Changelog ==

= 1.0 =
* Initial release.

== Upgrade Notice ==

= 1.0 =
* Initial release.
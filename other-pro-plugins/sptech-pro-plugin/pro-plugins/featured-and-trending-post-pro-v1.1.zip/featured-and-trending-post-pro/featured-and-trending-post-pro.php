<?php
/*
 * Plugin Name: Featured and Trending Post Pro
 * Plugin URI: https://www.wponlinesupport.com/
 * Description: Display your favourite, featured and trending post with various design.
 * Author: WP Online Support
 * Text Domain: featured-and-trending-post
 * Domain Path: /languages/
 * Version: 1.1
 * Author URI: https://www.wponlinesupport.com/
 *
 * @package WordPress
 * @author WP Online Support
 */

if( !defined( 'FTPP_VERSION' ) ) {
    define( 'FTPP_VERSION', '1.1' ); // Version of plugin
}
if( !defined( 'FTPP_DIR' ) ) {
    define( 'FTPP_DIR', dirname( __FILE__ ) ); // Plugin dir
}
if( !defined( 'FTPP_URL' ) ) {
    define( 'FTPP_URL', plugin_dir_url( __FILE__ ) ); // Plugin url
}
if( !defined( 'FTPP_PLUGIN_BASENAME' ) ) {
    define( 'FTPP_PLUGIN_BASENAME', plugin_basename( __FILE__ ) ); // Plugin base name
}
if( !defined( 'FTPP_POST_TYPE' ) ) {
    define( 'FTPP_POST_TYPE', 'post' ); // Plugin post type
}
if( !defined( 'FTPP_CAT' ) ) {
    define( 'FTPP_CAT', 'category' ); // Plugin category name
}
if( !defined( 'FTPP_FC_META_PREFIX' ) ) {
    define( 'FTPP_FC_META_PREFIX', '_wpfp_' ); // Featured plugin metabox prefix
}
if( !defined( 'FTPP_TP_META_PREFIX' ) ) {
    define( 'FTPP_TP_META_PREFIX', '_wtpsw_' ); // Trending plugin meta prefix
}

/**
 * Load Text Domain
 * This gets the plugin ready for translation
 * 
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */
function ftpp_load_textdomain() {

    global $wp_version;

    // Set filter for plugin's languages directory
    $ftpp_lang_dir = dirname( plugin_basename( __FILE__ ) ) . '/languages/';
    $ftpp_lang_dir = apply_filters( 'ftpp_languages_directory', $ftpp_lang_dir );

    // Traditional WordPress plugin locale filter.
    $get_locale = get_locale();

    if ( $wp_version >= 4.7 ) {
        $get_locale = get_user_locale();
    }

    // Traditional WordPress plugin locale filter
    $locale = apply_filters( 'plugin_locale',  $get_locale, 'featured-and-trending-post' );
    $mofile = sprintf( '%1$s-%2$s.mo', 'featured-and-trending-post', $locale );

    // Setup paths to current locale file
    $mofile_global  = WP_LANG_DIR . '/plugins/' . basename( FTPP_DIR ) . '/' . $mofile;

    if ( file_exists( $mofile_global ) ) { // Look in global /wp-content/languages/plugin-name folder
        load_textdomain( 'featured-and-trending-post', $mofile_global );
    } else { // Load the default language files
        load_plugin_textdomain( 'featured-and-trending-post', false, $ftpp_lang_dir );
    }
}
add_action('plugins_loaded', 'ftpp_load_textdomain');

/**
 * Activation Hook
 * 
 * Register plugin activation hook.
 * 
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */
register_activation_hook( __FILE__, 'ftpp_install' );

/**
 * Deactivation Hook
 * 
 * Register plugin deactivation hook.
 * 
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */
register_deactivation_hook( __FILE__, 'ftpp_uninstall');

/**
 * Plugin Setup (On Activation)
 * 
 * Does the initial setup,
 * stest default values for the plugin options.
 * 
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */
function ftpp_install() {

    // Get settings for the plugin
    $ftpp_options = get_option( 'ftpp_options' );
    
    if( empty( $ftpp_options ) ) { // Check plugin version option
        
        // Set default settings
        ftpp_default_settings();
        
        // Update plugin version to option
        update_option( 'ftpp_plugin_version', '1.0' );
    }
}

/**
 * Plugin Setup (On Deactivation)
 * 
 * Delete  plugin options.
 * 
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */
function ftpp_uninstall() {
    // Uninstall functionality
}

/***** Updater Code Starts *****/
define( 'EDD_FTPP_STORE_URL', 'https://www.wponlinesupport.com' );
define( 'EDD_FTPP_ITEM_NAME', 'Featured and Trending Post Pro' );

// Plugin Updator Class 
if( !class_exists( 'EDD_SL_Plugin_Updater' ) ) {    
    include( dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php' );
}

/**
 * Updater Function
 * 
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */
function ftpp_plugin_updater() {
    
    $license_key = trim( get_option( 'ftpp_plugin_license_key' ) );

    $edd_updater = new EDD_SL_Plugin_Updater( EDD_FTPP_STORE_URL, __FILE__, array(
                'version'   => FTPP_VERSION,            // current version number
                'license'   => $license_key,            // license key (used get_option above to retrieve from DB)
                'item_name' => EDD_FTPP_ITEM_NAME,      // name of this plugin
                'author'    => 'WP Online Support'      // author of this plugin
            )
    );
}
add_action( 'admin_init', 'ftpp_plugin_updater', 0 );

include( dirname( __FILE__ ) . '/ftpp-plugin-updater.php' );
/***** Updater Code Ends *****/

// Taking some globals
global $ftpp_options, $ftpp_model, $ftpp_view_by;

// Functions file
require_once( FTPP_DIR . '/includes/ftpp-functions.php' );
$ftpp_options = ftpp_get_settings();

// Script Class
require_once( FTPP_DIR . '/includes/class-ftpp-script.php' );

// Model File
require_once( FTPP_DIR . '/includes/class-ftpp-model.php' );

// Admin Class
require_once( FTPP_DIR . '/includes/admin/class-ftpp-admin.php' );

// Public Class
require_once( FTPP_DIR . '/includes/class-ftpp-public.php' );

// Featured - Shortcode 
require_once( FTPP_DIR . '/includes/shortcode/featured/ftpp-recent-post.php' );
require_once( FTPP_DIR . '/includes/shortcode/featured/ftpp-recent-post-grid.php' );
require_once( FTPP_DIR . '/includes/shortcode/featured/ftpp-recent-post-slider.php' );
require_once( FTPP_DIR . '/includes/shortcode/featured/ftpp-recent-post-carousel.php' );


// Trending - Shortcode 
require_once( FTPP_DIR . '/includes/shortcode/trending/ftpp-popular-post-slider.php' );
require_once( FTPP_DIR . '/includes/shortcode/trending/ftpp-popular-post-carousel.php' );
require_once( FTPP_DIR . '/includes/shortcode/trending/ftpp-popular-post-grid.php' );
require_once( FTPP_DIR . '/includes/shortcode/trending/ftpp-popular-post-block.php' );

// Featured Widget Class
require_once( FTPP_DIR . '/includes/widgets/featured/class-ftpp-featured-widget-list.php' );
require_once( FTPP_DIR . '/includes/widgets/featured/class-ftpp-featured-widget-slider.php' );
require_once( FTPP_DIR . '/includes/widgets/featured/class-ftpp-featured-vscrolling-widget.php' );

// Trending Widget Class
require_once( FTPP_DIR . '/includes/widgets/trending/class-ftpp-post-list-widget.php' );
require_once( FTPP_DIR . '/includes/widgets/trending/class-ftpp-trending-post-widget-slider.php' );
require_once( FTPP_DIR . '/includes/widgets/trending/class-ftpp-trending-post-vscrolling-widget.php' );

// Load admin files
if ( is_admin() || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
    require_once( FTPP_DIR . '/includes/admin/ftpp-how-it-works.php' );
}
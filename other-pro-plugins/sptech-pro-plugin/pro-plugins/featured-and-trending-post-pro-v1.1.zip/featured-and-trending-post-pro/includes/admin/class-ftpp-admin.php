<?php
/**
 * Admin Class
 *
 * Handles the Admin side functionality of plugin
 *
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Wpfp_Admin {
	
	function __construct() {
		
		// Action to add metabox
		add_action( 'add_meta_boxes', array($this, 'ftpp_add_featured_metabox') );

		// Action to save metabox
		add_action( 'save_post', array($this,'ftpp_save_metabox_value') );

		// Action to register admin menu
		add_action( 'admin_menu', array($this, 'ftpp_register_menu'), 9 );

		// Action to register plugin settings
		add_action ( 'admin_init', array($this, 'ftpp_register_settings') );

		// Filter for post category columns
		add_filter( 'manage_edit-'.FTPP_CAT.'_columns', array($this, 'ftpp_manage_category_columns') );
		add_filter( 'manage_'.FTPP_CAT.'_custom_column', array($this, 'ftpp_category_data'), 10, 3 );

		// Action to add custom column to post listing
		add_filter( 'manage_'.FTPP_POST_TYPE.'_posts_columns', array($this, 'ftpp_posts_columns') );

		// Action to add custom column data to post listing
		add_action('manage_'.FTPP_POST_TYPE.'_posts_custom_column', array($this, 'ftpp_post_columns_data'), 10, 2);

		// Ajax call to update featured post
		add_action( 'wp_ajax_ftpp_update_featured_post', array($this, 'ftpp_update_featured_post'));
		add_action( 'wp_ajax_nopriv_ftpp_update_featured_post',array( $this, 'ftpp_update_featured_post'));

		// Filter to add plugin links
		add_filter( 'plugin_row_meta', array( $this, 'wpfp_plugin_row_meta' ), 10, 2 );		
	}

	/**
	 * Featured Post Settings Metabox
	 * 
	 * @package Featured and Trending Post Pro
	 * @since 1.0.0
	 */
	function ftpp_add_featured_metabox() {
		add_meta_box( 'ftpp-post-sett', __( 'Featured Post Settings', 'featured-and-trending-post' ), array($this, 'ftpp_fc_mb_content'), FTPP_POST_TYPE, 'side', 'default' );
	}

	/**
	 * Featured Post Settings Metabox HTML
	 * 
	 * @package Featured and Trending Post Pro
	 * @since 1.0.0
	 */
	function ftpp_fc_mb_content() {
		include_once( FTPP_DIR .'/includes/admin/metabox/ftpp-post-sett-metabox.php');
	}

	/**
	 * Function to save metabox values
	 * 
	 * @package Featured and Trending Post Pro
	 * @since 1.0.0
	 */
	function ftpp_save_metabox_value( $post_id ) {

		global $post_type;
		
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )                	// Check Autosave
		|| ( ! isset( $_POST['post_ID'] ) || $post_id != $_POST['post_ID'] )  	// Check Revision
		|| ( $post_type !=  FTPP_POST_TYPE ) )              				// Check if current post type is supported.
		{
		  return $post_id;
		}

		$prefix = FTPP_FC_META_PREFIX; // Taking metabox prefix

		// Taking variables
		$featured_box = !empty($_POST[$prefix.'featured_post']) ? 1	: 0;

		update_post_meta($post_id, $prefix.'featured_post', $featured_box);
	}

	/**
	 * Function to register admin menus
	 * 
	 * @package Featured and Trending Post Pro
	 * @since 1.0.0
	 */
	function ftpp_register_menu() {
		add_menu_page( __('Settings', 'featured-and-trending-post'), __('Featured -- Trending Post Pro', 'featured-and-trending-post'), 'manage_options', 'wpfp-settings', array($this, 'ftpp_settings_page'), 'dashicons-format-aside' );
	}
	
	/**
	 * Function register setings
	 * 
	 * @package Featured and Trending Post Pro
	 * @since 1.0.0
	 */
	function ftpp_register_settings() {
		register_setting( 'wtpsw_plugin_options', 'wtpsw_options', array($this, 'ftpp_validate_options') );
	}

	/**
	 * Validate Settings Options
	 * 
	 * @package Featured and Trending Post Pro
	 * @since 1.0.0
	 */
	function ftpp_validate_options( $input ) {
		
		$input['default_img'] = isset($input['default_img']) 	? ftpp_slashes_deep(trim($input['default_img'])) 	: '';
		$input['custom_css'] = isset($input['custom_css']) 		? ftpp_slashes_deep($input['custom_css'], true) 	: '';
		$input['post_types']	= isset($input['post_types'])	? $input['post_types'] 								: array();

		return $input;
	}

	/**
	 * Function to handle the setting page html
	 * 
	 * @package Featured and Trending Post Pro
	 * @since 1.0.0
	 */
	function ftpp_settings_page() {
		include_once( FTPP_DIR . '/includes/admin/settings/ftpp-settings.php' );
	}

	/**
	 * Add extra column to post category
	 * 
	 * @package Featured and Trending Post Pro
	 * @since 1.0.0
	 */
	function ftpp_manage_category_columns( $columns ) {

	    $new_columns['featured_post'] = __( 'Featured Category Shortcode', 'featured-and-trending-post' );

		$columns = ftpp_add_array( $columns, $new_columns, 2 );

		return $columns;
	}

	/**
	 * Add data to extra column to post category
	 * 
	 * @package Featured and Trending Post Pro
	 * @since 1.0.0
	 */
	function ftpp_category_data($ouput, $column_name, $tax_id) {

	    if( $column_name == 'featured_post' ){
			$ouput .= '[featured_post category="' . $tax_id. '"]<br />';
	    }

	    return $ouput;
	}

	/**
	 * Add custom column to Post listing page for Featured Post  
	 * 
	 * @package Featured and Trending Post Pro
	 * @since 1.0.0
	 */
	function ftpp_posts_columns( $columns ){

	    $new_columns['ftpp_featured'] = __('Featured Post', 'featured-and-trending-post');

	    $columns = ftpp_add_array( $columns, $new_columns, 4 );

	    return $columns;
	}

	/**
	 * Add custom column data to post listing page for Featured Post
	 * 
	 * @package Featured and Trending Post Pro
	 * @since 1.0.0
	 */
	function ftpp_post_columns_data( $column, $post_id ) {

	    if( $column == 'ftpp_featured' ){

	        $prefix 		= FTPP_FC_META_PREFIX; // Metabox prefix
	        $featured_box 	= get_post_meta( $post_id, $prefix.'featured_post', true );       
	        $featured_box 	= (!empty($featured_box)) ? 'dashicons-star-filled' : 'dashicons-star-empty' ;
	        
	       	echo "<div class='ftpp-select-featured dashicons {$featured_box}' data-post-id='{$post_id}' style='cursor: pointer;'></div>";
	    }
	}

	/**
	 * Update Featured post
	 * 
	 * @package Featured and Trending Post Pro
	 * @since 1.0.0
	 */
	function ftpp_update_featured_post() {

		$prefix = FTPP_FC_META_PREFIX; // Taking metabox prefix

		$result 			= array();
		$result['success'] 	= 0;

		if( !empty($_POST['feat_id']) ) {

			update_post_meta($_POST['feat_id'], $prefix.'featured_post', $_POST['is_feat']);

			$result['success'] 	= 1;
		}

		echo json_encode($result);
		exit;
	}
	
	/**
	 * Function to unique number value
	 * 
	 * @package Featured and Trending Post Pro
	 * @since 1.0.0
	 */
	function wpfp_plugin_row_meta( $links, $file ) {
		
		if ( $file == FTPP_PLUGIN_BASENAME ) {
			
			$row_meta = array(
				'docs'    => '<a href="' . esc_url('https://www.wponlinesupport.com/pro-plugin-document/document-featured-trending-post-pro/') . '" title="' . esc_attr( __( 'View Documentation', 'featured-and-trending-post' ) ) . '" target="_blank">' . __( 'Docs', 'featured-and-trending-post' ) . '</a>',
				'support' => '<a href="' . esc_url('http://forum.wponlinesupport.com') . '" title="' . esc_attr( __( 'Visit Customer Support Forum', 'featured-and-trending-post' ) ) . '" target="_blank">' . __( 'Support', 'featured-and-trending-post' ) . '</a>',
			);
			return array_merge( $links, $row_meta );
		}
		return (array) $links;
	}
}

$wpbaw_pro_admin = new Wpfp_Admin();
<?php
/**
 * Settings Page
 *
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

$wtspw_dates 		= array( 'F j, Y', 'M j, Y', 'Y-m-d', 'm/d/Y', 'd/m/Y' ); // Dates array
$post_range 		= ftpp_get_option('post_range');
$date_format 		= ftpp_get_option('date_format');
$reg_post_types 	= ftpp_get_post_types();
$support_post_types = ftpp_get_option('post_types', array());
?>

<div class="wrap ftpp-settings">

<h2><?php _e( 'Featured and Trending Post Pro - Settings', 'featured-and-trending-post' ); ?></h2><br />

<?php

// Success message
if( isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true' ) {
	echo '<div id="message" class="updated notice notice-success is-dismissible">
			<p>'.__("Your changes saved successfully.", "featured-and-trending-post").'</p>
		  </div>';
}
?>

<form action="options.php" method="POST" id="ftpp-settings-form" class="ftpp-settings-form">
	
	<?php
	    settings_fields( 'wtpsw_plugin_options' );
	?>
	
	<div id="wtpsw-general-settings" class="post-box-container wtpsw-general-settings">
		<div class="metabox-holder">
			<div class="meta-box-sortables ui-sortable">
				<div id="general" class="postbox">

					<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'Trending Post - General Settings', 'featured-and-trending-post' ); ?></span>
						</h3>
						
						<div class="inside">
						
						<table class="form-table wtpsw-general-settings-tbl">
							<tbody>
								
								<tr>
									<th scope="row">
										<label for="wtpsw-post-within"><?php _e('Post Within', 'featured-and-trending-post'); ?></label>
									</th>
									<td>
										<select id="wtpsw-post-within" class="wtpsw-post-within" name="wtpsw_options[post_range]">
											<option value=""><?php _e('All Time', 'featured-and-trending-post'); ?></option>
											<option value="daily" <?php selected( $post_range, 'daily' ); ?>><?php _e('Today', 'featured-and-trending-post'); ?></option>
											<option value="last_day" <?php selected( $post_range, 'last_day' ); ?>><?php _e('Last Day', 'featured-and-trending-post'); ?></option>
											<option value="last_week" <?php selected( $post_range, 'last_week' ); ?>><?php _e('Last 7 Days', 'featured-and-trending-post'); ?></option>
											<option value="last_month" <?php selected( $post_range, 'last_month' ); ?>><?php _e('Last Month', 'featured-and-trending-post'); ?></option>
										</select><br/>
										<span class="description"><?php _e('Select time range for post visibility.', 'featured-and-trending-post'); ?></span>
									</td>
								</tr>
								
								<tr>
									<th scope="row">
										<label><?php _e('Date Format', 'featured-and-trending-post'); ?></label>
									</th>
									<td>
										<?php foreach ($wtspw_dates as $date_key => $date_val) { ?>
											<label title="<?php echo $date_val; ?>"><input type="radio" name="wtpsw_options[date_format]" value="<?php echo $date_val; ?>" class="wtpsw-post-date-format" <?php checked( $date_format, $date_val ); ?> /><?php echo date( $date_val, current_time('timestamp') ); ?></label><br/>
										<?php } ?>
										<span class="description"><?php _e('Select date format.', 'featured-and-trending-post'); ?></span>
									</td>
								</tr>

								<tr>
									<th scope="row">
										<label for="select-post-type"><?php _e('Select Post Types', 'wp-responsive-recent-post-slider'); ?></label>
									</th>
									<td>
										<?php if( !empty($reg_post_types) ) {
											foreach ($reg_post_types as $post_key => $post_label) { ?>
												<div class="wtpsw-post-type-wrap">
													<input type="checkbox" id="wtpsw-post-<?php echo $post_key; ?>" value="<?php echo $post_key; ?>" name="wtpsw_options[post_types][]" <?php checked( in_array($post_key, $support_post_types), true ); ?> />
													<label for="wtpsw-post-<?php echo $post_key; ?>"><?php echo $post_label; ?> (Post Type : <?php echo $post_key; ?>)</label>
												</div>
										<?php } 											
										} ?>
										<span class="description"><?php _e('Select post type box for trending post. You can enter post type name in shortcode parameter.', 'wp-responsive-recent-post-slider'); ?></span> <br/>
									</td>
								</tr>

								<tr>
									<td colspan="2" valign="top" scope="row">
										<input type="submit" id="wtpsw-settings-submit" name="wtpsw-settings-submit" class="button button-primary right" value="<?php _e('Save Changes','featured-and-trending-post');?>" />
									</td>
								</tr>
							</tbody>
						 </table>

					</div><!-- .inside -->
				</div><!-- #general -->
			</div><!-- .meta-box-sortables ui-sortable -->
		</div><!-- .metabox-holder -->
	</div><!-- #wtpsw-general-settings -->
		
	<!-- Custom CSS Settings Starts -->
	<div id="ftpp-custom-css-sett" class="post-box-container ftpp-custom-css-sett">
		<div class="metabox-holder">
			<div class="meta-box-sortables ui-sortable">
				<div id="custom-css" class="postbox">

					<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'Custom CSS Settings', 'featured-and-trending-post' ); ?></span>
						</h3>
						
						<div class="inside">
						
						<table class="form-table ftpp-custom-css-sett-tbl">
							<tbody>
								<tr>
									<th scope="row">
										<label for="ftpp-custom-css"><?php _e('Custom CSS', 'featured-and-trending-post'); ?></label>
									</th>
									<td>
										<textarea name="wtpsw_options[custom_css]" class="large-text ftpp-custom-css" id="ftpp-custom-css" rows="15"><?php echo ftpp_esc_attr(ftpp_get_option('custom_css')); ?></textarea><br/>
										<span class="description"><?php _e('Enter custom CSS to override plugin CSS.', 'featured-and-trending-post'); ?></span>
									</td>
								</tr>
								<tr>
									<td colspan="2" valign="top" scope="row">
										<input type="submit" id="ftpp-settings-submit" name="ftpp-settings-submit" class="button button-primary right" value="<?php _e('Save Changes','featured-and-trending-post'); ?>" />
									</td>
								</tr>
							</tbody>
						 </table>

					</div><!-- .inside -->
				</div><!-- #custom-css -->
			</div><!-- .meta-box-sortables ui-sortable -->
		</div><!-- .metabox-holder -->
	</div><!-- #ftpp-custom-css-sett -->
	<!-- Custom CSS Settings Ends -->

</form><!-- end .ftpp-settings-form -->

</div><!-- end .ftpp-settings -->
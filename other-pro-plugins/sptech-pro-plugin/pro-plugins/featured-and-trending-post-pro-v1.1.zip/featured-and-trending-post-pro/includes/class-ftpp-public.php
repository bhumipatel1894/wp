<?php
/**
 * Public Class
 *
 * Handles the public side functionality of plugin
 *
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Ftpp_Public {
	
	function __construct() {

		// Ajax call to update post count
		add_action( 'wp_ajax_ftpp_post_view_count', array($this, 'ftpp_post_view_count') );
		add_action( 'wp_ajax_nopriv_ftpp_post_view_count',array( $this, 'ftpp_post_view_count') );
	}

	/**
	 * Function to update views of post
	 * 
	 * @package WP Clean Responsive
	 * @since 1.0.0
	 */
	function ftpp_post_view_count() {
		
		$prefix		= FTPP_TP_META_PREFIX;
		$post_id 	= isset($_POST['post_id']) ? $_POST['post_id'] : '';
		
		if( !empty($post_id) ) {
			
			// Getting existing views
			$views = get_post_meta( $post_id, $prefix.'views', true );
			$views = !empty($views) ? $views : 0;
			
			// Update new views
			update_post_meta( $post_id, $prefix.'views', ($views+1) );
			
			echo 'Success';
		} else {
			echo 'Error - Reference Id not found.';
		}
		die();
	}
}

$ftpp_public = new Ftpp_Public();
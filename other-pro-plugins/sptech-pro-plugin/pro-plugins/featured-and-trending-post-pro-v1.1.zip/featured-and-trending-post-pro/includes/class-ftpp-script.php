<?php
/**
 * Script Class
 *
 * Handles the script and style functionality of plugin
 *
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Ftpp_Script {
	
	function __construct() {
		
		// Action to add style at front side
		add_action( 'wp_enqueue_scripts', array($this, 'ftpp_front_style') );

		// Action to add script at front side
		add_action( 'wp_enqueue_scripts', array($this, 'ftpp_front_script') );

		// Action to add script at admin side
		add_action( 'admin_enqueue_scripts', array($this, 'ftpp_admin_script') );

		// Action to add custom css in head
		add_action( 'wp_head', array($this, 'ftpp_custom_css'), 20 );
	}
	
	/**
	 * Function to add style at front side
	 * 
	 * @package Featured and Trending Post Pro
	 * @since 1.0.0
	 */
	function ftpp_front_style() {

		// Registring and enqueing font awesome css
		if( !wp_style_is( 'wpos-font-awesome', 'registered' ) ) {
			wp_register_style( 'wpos-font-awesome', FTPP_URL.'assets/css/font-awesome.min.css', null, FTPP_VERSION );
			wp_enqueue_style( 'wpos-font-awesome' );
		}
		
		// Registring and enqueing slick css
		if( !wp_style_is( 'wpos-slick-style', 'registered' ) ) {
			wp_register_style( 'wpos-slick-style', FTPP_URL.'assets/css/slick.css', array(), FTPP_VERSION );
			wp_enqueue_style( 'wpos-slick-style');
		}

		// Registring post vertical ticker script
		if( !wp_script_is( 'wpos-vticker-jquery', 'registered' ) ) {
			wp_register_script( 'wpos-vticker-jquery', FTPP_URL. 'assets/js/post-ticker.js', array('jquery'), FTPP_VERSION, true);
		}

		// Registring and enqueing featured public css
		wp_register_style( 'ftpp-fc-public-style', FTPP_URL.'assets/css/ftpp-fc-public.css', array(), FTPP_VERSION );
		wp_enqueue_style( 'ftpp-fc-public-style' );

		// Registring and enqueing trending public css
		wp_register_style( 'ftpp-tp-public-style', FTPP_URL.'assets/css/ftpp-tp-public.css', array(), FTPP_VERSION );
		wp_enqueue_style( 'ftpp-tp-public-style' );
	}

	/**
	 * Function to add script at front side
	 * 
	 * @package Featured and Trending Post Pro
	 * @since 1.0.0
	 */
	function ftpp_front_script() {

		global $post;
		
		// Taking post id to update post view count
		$post_id 			= isset($post->ID) ? $post->ID : '';
		$post_view_count	= 0;

		$supported_posts = ftpp_get_option('post_types',array()); // suppoterd post type

		if( !empty($post_id) && !empty($supported_posts) && is_singular($supported_posts) && !is_preview() && !is_front_page() && !is_home() && !is_feed() && !is_robots() ) {
			$post_view_count = $post_id;
		}

		// Registring slick slider script
		if( !wp_script_is( 'wpos-slick-jquery', 'registered' ) ) {
			wp_register_script( 'wpos-slick-jquery', FTPP_URL.'assets/js/slick.min.js', array('jquery'), FTPP_VERSION, true );
		}

		// Registering Public Script (Slider Script)
		wp_register_script( 'ftpp-public-script', FTPP_URL.'assets/js/ftpp-public.js', array('jquery'), FTPP_VERSION, true );
		wp_localize_script( 'ftpp-public-script', 'ftpp', array(
																	'ajaxurl'			=> admin_url( 'admin-ajax.php', ( is_ssl() ? 'https' : 'http' ) ),
																	'is_mobile' 		=> (wp_is_mobile()) ? 1 : 0,
																	'is_rtl' 			=> (is_rtl()) 		? 1 : 0,
																	'post_view_count'	=> $post_view_count,
																));
		wp_enqueue_script( 'ftpp-public-script' );
	}

	/**
	 * Function to add script at admin side
	 * 
	 * @package Featured and Trending Post Pro
	 * @since 1.0.0
	 */
	function ftpp_admin_script( $hook ) {
		
		global $wp_version, $post_type, $current_screen;

		$screen_id 	= isset($current_screen->id) ? $current_screen->id : '';
		$new_ui 	= $wp_version >= '3.5' ? '1' : '0'; // Check wordpress version for older scripts

		// Pages array
		$screen_pages = array('edit-post');
		
		// If page is plugin setting page then enqueue script
		if( in_array($screen_id, $screen_pages) ) {

			// Registring admin script
			wp_register_script( 'ftpp-admin-js', FTPP_URL.'assets/js/ftpp-admin.js', array('jquery'), FTPP_VERSION, true );
			wp_enqueue_script( 'ftpp-admin-js' );
		}
	}

	/**
	 * Add custom css to head
	 * 
	 * @package Featured and Trending Post Pro
	 * @since 1.0.0
	 */
	function ftpp_custom_css() {
		
		$custom_css = ftpp_get_option('custom_css');
		
		if( !empty($custom_css) ) {
			$css  = '<style type="text/css">' . "\n";
			$css .= $custom_css;
			$css .= "\n" . '</style>' . "\n";

			echo $css;
		}
	}
}

$ftpp_script = new Ftpp_Script();
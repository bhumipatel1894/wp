<?php
/**
 * Plugin generic functions file
 *
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Update default settings
 * 
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */
function ftpp_default_settings() {
	
	global $ftpp_options;
	
	$ftpp_options = array(
						'post_range' 	=>	'',
						'date_format'	=> 'F j, Y',
						'custom_css' 	=> '',
						'post_types'  	=> array(),
					);

	$default_options = apply_filters('ftpp_options_default_values', $ftpp_options );
	
	// Update default options
	update_option( 'wtpsw_options', $default_options );

	// Overwrite global variable when option is update
	$ftpp_options = ftpp_get_settings();
}

/**
 * Get Settings From Option Page
 * 
 * Handles to return all settings value
 * 
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */
function ftpp_get_settings() {
	
	$options = get_option('wtpsw_options');
	
	$settings = is_array($options) 	? $options : array();
	
	return $settings;
}

/**
 * Get an option
 * Looks to see if the specified setting exists, returns default if not
 * 
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */
function ftpp_get_option( $key = '', $default = false ) {
	global $ftpp_options;

	$value = ! empty( $ftpp_options[ $key ] ) ? $ftpp_options[ $key ] : $default;
	$value = apply_filters( 'ftpp_get_option', $value, $key, $default );
	return apply_filters( 'ftpp_get_option_' . $key, $value, $key, $default );
}

/**
 * Escape Tags & Slashes
 *
 * Handles escapping the slashes and tags
 *
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */
function ftpp_esc_attr($data) {
	return esc_attr( stripslashes($data) );
}

/**
 * Strip Slashes From Array
 *
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */
function ftpp_slashes_deep($data = array(), $flag = false) {
	
	if($flag != true) {
		$data = ftpp_nohtml_kses($data);
	}
	$data = stripslashes_deep($data);
	return $data;
}

/**
 * Strip Html Tags 
 * 
 * It will sanitize text input (strip html tags, and escape characters)
 * 
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */
function ftpp_nohtml_kses($data = array()) {
	
	if ( is_array($data) ) {
		
		$data = array_map('ftpp_nohtml_kses', $data);
		
	} elseif ( is_string( $data ) ) {
		$data = trim( $data );
		$data = wp_filter_nohtml_kses($data);
	}
	
	return $data;
}

/**
 * Function to unique number value
 * 
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */
function ftpp_get_unique() {
	static $unique = 0;
	$unique++;

	return $unique;
}

/**
 * Function to add array after specific key
 * 
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */
function ftpp_add_array(&$array, $value, $index) {
	
	if( is_array($array) && is_array($value) ){
		$split_arr 	= array_splice($array, max(0, $index));
		$array 		= array_merge( $array, $value, $split_arr);
	}

	return $array;
}

/**
 * Function to get post featured image
 * 
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */
function ftpp_get_post_featured_image( $post_id = '', $size = 'full', $default_img = false ) {

	$size 	= !empty($size) ? $size : 'full';
	$image 	= wp_get_attachment_image_src( get_post_thumbnail_id( $post_id ), $size );
	
	if( !empty($image) ) {
		$image = isset($image[0]) ? $image[0] : '';
	}

	// Getting default image
	if( $default_img && empty($image) ) {
		$image = ftpp_get_option( 'default_img' );
	}

	return $image;
}

/**
 * Function to get post excerpt
 * 
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */
function ftpp_get_post_excerpt( $post_id = null, $content = '', $word_length = '55', $more = '...' ) {

	$word_length = !empty($word_length) ? $word_length : '55';

	// If post id is passed
	if( !empty($post_id) ) {
		if (has_excerpt($post_id)) {
			$content = get_the_excerpt();
		} else {
			$content = !empty($content) ? $content : get_the_content();
		}
	}

	if( !empty($content) ) {
		$content = strip_shortcodes( $content ); // Strip shortcodes
		$content = wp_trim_words( $content, $word_length, $more );
	}

	return $content;
}

/**
 * Function to get registered post types
 * 
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */
function ftpp_get_post_types( $args = array() ) {

	// Taking defaults
	$all_post_types = array();

	$args = array(
					'public' => !empty($args['public']) ? $args['public'] : 'true'
				);

	$all_post_types = get_post_types( $args, 'object' );
	$exclude_post 	= array('attachment');

	foreach ($all_post_types as $post_type_key => $post_data) {
        if( !in_array( $post_type_key, $exclude_post) ) {
            $post_types[$post_type_key] = !empty($post_data->label) ? $post_data->label : $post_type_key;
        }
    }

	return apply_filters('ftpp_get_post_types', $post_types );  
}

/**
 * Function to exclude post type
 * 
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */
function ftpp_exclude_post_types(  ) {

	$excluded_post = array('attachment');

	return apply_filters('ftpp_exclude_post_types',$excluded_post);
}

/**
 * Function to get comment count text
 * 
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */
function ftpp_get_comments_number( $post_id = '', $hide_empty = false ) {

	$comment_text = '';

	if( !empty($post_id) ) {

		$comment_number = get_comments_number( $post_id );

		if ( $comment_number == 0 && empty($hide_empty) ) {
			$comment_text = __('0 Comments', 'featured-and-trending-post');
		} elseif ( $comment_number > 1 ) {
			$comment_text = $comment_number . __(' Comments', 'featured-and-trending-post');
		} elseif ( $comment_number == 1 ) {
			$comment_text = __('1 Comment', 'featured-and-trending-post');
		}
	}

	return $comment_text;
}
// Featured and Trending Post Shortcode Designs
/**
 * Function to get Featured post shortcode designs
 * 
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */
function ftpp_featured_post_designs() {
	$design_arr = array(
		'design-1'	=> __('Design 1', 'featured-and-trending-post'),
		'design-2'	=> __('Design 2', 'featured-and-trending-post'),
		'design-3'	=> __('Design 3', 'featured-and-trending-post'),
		'design-4'	=> __('Design 4', 'featured-and-trending-post'),
		'design-5'	=> __('Design 5', 'featured-and-trending-post'),
		'design-6'	=> __('Design 6', 'featured-and-trending-post'),
		'design-7'	=> __('Design 7', 'featured-and-trending-post'),
		'design-8'	=> __('Design 8', 'featured-and-trending-post'),
		'design-9'	=> __('Design 9', 'featured-and-trending-post'),
		'design-10'	=> __('Design 10', 'featured-and-trending-post'),
		'design-11'	=> __('Design 11', 'featured-and-trending-post'),
		'design-12'	=> __('Design 12', 'featured-and-trending-post'),
		'design-13'	=> __('Design 13', 'featured-and-trending-post'),
		'design-14'	=> __('Design 14', 'featured-and-trending-post'),
		'design-15'	=> __('Design 15', 'featured-and-trending-post'),
		'design-16'	=> __('Design 16', 'featured-and-trending-post'),
		'design-17'	=> __('Design 17', 'featured-and-trending-post'),
		'design-18'	=> __('Design 18', 'featured-and-trending-post'),
		'design-19'	=> __('Design 19', 'featured-and-trending-post'),
		'design-20'	=> __('Design 20', 'featured-and-trending-post'),
	);
	return apply_filters('ftpp_featured_post_designs', $design_arr );
}

// Trending Post Shortcode Designs
/**
 * Function to get 'wtpsw_block' shortcode designs
 * 
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */
function ftpp_trending_post_designs() {
	$design_arr = array(
		'design-1'	=> __('Design 1', 'featured-and-trending-post'),
		'design-2'	=> __('Design 2', 'featured-and-trending-post'),
		'design-3'	=> __('Design 3', 'featured-and-trending-post'),
		'design-4'	=> __('Design 4', 'featured-and-trending-post'),
		'design-5'	=> __('Design 5', 'featured-and-trending-post'),
		'design-6'	=> __('Design 6', 'featured-and-trending-post'),
		'design-7'	=> __('Design 7', 'featured-and-trending-post'),
		'design-8'	=> __('Design 8', 'featured-and-trending-post'),
		'design-9'	=> __('Design 9', 'featured-and-trending-post'),
		'design-10'	=> __('Design 10', 'featured-and-trending-post'),
		'design-11'	=> __('Design 11', 'featured-and-trending-post'),
		'design-12'	=> __('Design 12', 'featured-and-trending-post'),
		'design-13'	=> __('Design 13', 'featured-and-trending-post'),
		'design-14'	=> __('Design 14', 'featured-and-trending-post'),
		'design-15'	=> __('Design 15', 'featured-and-trending-post'),
		'design-16'	=> __('Design 16', 'featured-and-trending-post'),
		'design-17'	=> __('Design 17', 'featured-and-trending-post'),
		'design-18'	=> __('Design 18', 'featured-and-trending-post'),
		'design-19'	=> __('Design 19', 'featured-and-trending-post'),
		'design-20'	=> __('Design 20', 'featured-and-trending-post'),
	);
	return apply_filters('ftpp_trending_post_designs', $design_arr );
}

/**
 * Function to get grid column based on grid
 * 
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */
function ftpp_pro_grid_column( $grid = '' ) {

	if($grid == '2') {
		$grid_clmn = '6';
	} else if($grid == '3') {
		$grid_clmn = '4';
	}  else if($grid == '4') {
		$grid_clmn = '3';
	} else if ($grid == '1') {
		$grid_clmn = '12';
	} else {
		$grid_clmn = '12';
	}
	
	return $grid_clmn;
}

/**
 * Function to get plugin link
 * 
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */
function ftpp_pro_plugin_link($type = "") {
	$link = add_query_arg( array('page' => 'wpfp-settings'), admin_url('admin.php') );
	return $link;
}
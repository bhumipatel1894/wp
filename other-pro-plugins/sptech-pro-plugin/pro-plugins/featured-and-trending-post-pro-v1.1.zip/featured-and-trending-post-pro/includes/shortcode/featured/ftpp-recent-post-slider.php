<?php
/**
 * 'fpc_post_slider' Shortcode
 * 
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

function ftpp_featured_post_slider( $atts, $content = null ) {
	
    // Shortcode Parameter
	extract(shortcode_atts(array(
		'limit' 				=> '20',
		'category' 				=> '',
		'include_cat_child'		=> 'true',
		'design' 				=> 'design-1',
		'show_date' 			=> 'true',
		'show_category_name' 	=> 'true',
		'show_author' 			=> 'true',
		'dots'     				=> 'true',
		'arrows'     			=> 'true',				
		'autoplay'     			=> 'true',		
		'autoplay_interval' 	=> '3000',				
		'speed'             	=> '600',
		'loop'					=> 'true',
		'rtl'					=> '',
		'order'					=> 'DESC',
		'orderby'				=> 'date',
		'exclude_cat'			=> array(),
		'hide_post'        		=> array(),
		'posts'					=> array(),
		'slider_height'			=> '',
		), $atts, 'fpc_post_slider'));

	$shortcode_designs 		= ftpp_featured_post_designs();
	$posts_per_page 		= !empty($limit) 			? $limit 					: '20';
	$cat 					= (!empty($category))		? explode(',',$category) 	: '';
	$include_cat_child		= ( $include_cat_child == 'false' ) ? false : true;
	$design 				= ($design && (array_key_exists(trim($design), $shortcode_designs))) ? trim($design) : 'design-1';
	$show_date 				= ( $show_date == 'false' ) 			? 'false'	: 'true';
	$show_category 			= ( $show_category_name == 'false' )	? 'false' 	: 'true';
	$show_author 			= ( $show_author == 'false')			? 'false'	: 'true';
	$dots 					= ( $dots == 'false' ) 		? 'false' : 'true';
	$arrows 				= ( $arrows == 'false' ) 	? 'false' : 'true';
	$autoplay 				= ( $autoplay == 'false' ) 	? 'false' : 'true';
	$autoplay_interval 		= !empty($autoplay_interval) ? $autoplay_interval : '3000';
	$speed 					= !empty($speed) 					? $speed 	: '600';
	$infinite 				= ( $loop == 'true' ) 				? 'true' 	: 'false';
	$order					= ( strtolower($order) == 'asc' ) 	? 'ASC' 	: 'DESC';
	$orderby				= !empty($orderby) 			? $orderby : 'date';
	$exclude_cat			= !empty($exclude_cat)		? explode(',', $exclude_cat) 	: array();
	$hide_post				= !empty($hide_post)		? explode(',', $hide_post) 		: array();
	$posts					= !empty($posts)			? explode(',', $posts) 			: array();
	$slider_height 			= (!empty($slider_height)) 	? $slider_height 	: '';
	$image_height_css 		= (!empty($slider_height))	? "style='height:{$slider_height}px;'" : "style='height:300px;'";
	
	// For RTL
	if( empty($rtl) && is_rtl() ) {
		$rtl = 'true';
	} elseif ( $rtl == 'true' ) {
		$rtl = 'true';
	} else {
		$rtl = 'false';
	}
	
	// Shortcode file
	$wpfp_design_file_path 	= FTPP_DIR . '/templates/featured/' . $design . '.php';
	$design_file 			= (file_exists($wpfp_design_file_path)) ? $wpfp_design_file_path : '';

	// Enqueus required script
	wp_enqueue_script( 'wpos-slick-jquery' );
	wp_enqueue_script( 'ftpp-public-script' );
	
	// Taking some globals
	global $post;
	
	// Taking some variables
	$prefix 			= FTPP_FC_META_PREFIX; // Metabox prefix
	$unique				= ftpp_get_unique();
	$main_cls 			= '';

	// Slider configuration
	$slider_conf = compact('dots', 'arrows', 'autoplay', 'autoplay_interval', 'speed', 'design', 'rtl', 'infinite');

	// Query Parameter
	$args = array ( 
					'post_type'      		=> FTPP_POST_TYPE,
					'post_status'			=> array( 'publish' ),
					'order'          		=> $order,
					'orderby'        		=> $orderby,
					'posts_per_page' 		=> $posts_per_page,
					'ignore_sticky_posts'	=> true,
					'post__not_in'	 		=> $hide_post,
					'post__in'		 		=> $posts					
				);
	
	// Meta Query
	$args['meta_query'] = array(
								array(
										'key'     => $prefix.'featured_post',
										'value'   => 1,
										'compare' => '=',
								));

	// Category Parameter
	if($cat != "") {
		
		$args['tax_query'] = array(
									array(
											'taxonomy' 			=> FTPP_CAT,
											'field' 			=> 'term_id',
											'terms' 			=> $cat,
											'include_children'	=> $include_cat_child,
									));

	} else if( !empty($exclude_cat) ) {
		
		$args['tax_query'] = array(
									array(
										'taxonomy' 			=> FTPP_CAT,
										'field' 			=> 'term_id',
										'terms' 			=> $exclude_cat,
										'operator'			=> 'NOT IN',
										'include_children'	=> $include_cat_child,
										));
	}


	// WP Query
	$query = new WP_Query($args);

	ob_start();

	// If post is there
	if ( $query->have_posts() ) { ?>

		<div class="wpfp-pro-slider-wrp">
			<div id="wpfp-featured-post-slider-<?php echo $unique; ?>" class="wpfp-featured-post-slider <?php echo $design; ?> wpfp-clearfix">

				<?php while ( $query->have_posts() ) : $query->the_post();

					$terms 		= get_the_terms( $post->ID, FTPP_CAT );
					$feat_image = ftpp_get_post_featured_image( $post->ID );
					$wpfp_link 	= array();
					
					if($terms) {
						foreach ( $terms as $term ) {
							$term_link = get_term_link( $term );
							$wpfp_link[] = '<a href="' . esc_url( $term_link ) . '">'.$term->name.'</a>';
						}
					}
					$cate_name = join( " ", $wpfp_link );

	    			// Include shortcode html file
	    			if( $design_file ) {
						include( $design_file );
					}
				endwhile; ?>

			</div>
			<div class="wpfp-slider-conf" data-conf="<?php echo htmlspecialchars(json_encode($slider_conf)); ?>"></div>
		</div>
		
	<?php } // End of if have posts
		
	wp_reset_query(); // Reset WP Query
	
	$content .= ob_get_clean();
	return $content;
}

// Featured Post Slider shortcode
add_shortcode('fpc_post_slider', 'ftpp_featured_post_slider');
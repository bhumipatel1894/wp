<?php

/**
 * 'fpc_post_block' Shortcode
 * 
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

function ftpp_featured_post( $atts, $content = null ) {

	// Shortcode Parameter
	extract(shortcode_atts(array(
		'limit' 				=> '5',
		'category' 				=> '',
		'include_cat_child'		=> 'true',
		'design' 				=> 'design-1',
		'show_author' 			=> 'true',
		'show_date' 			=> 'true',
		'show_category_name' 	=> 'true',
		'order'					=> 'DESC',
		'orderby'				=> 'date',
		'exclude_cat'			=> array(),
		'hide_post'        		=> array(),
		'posts'					=> array(),
		'image_height'			=> '400',
	), $atts, 'fpc_post_block'));

	$shortcode_designs 	= ftpp_featured_post_designs();
	$posts_per_page 	= !empty($limit) 	? $limit 	: '5';
	$cat 				= (!empty($category))				? explode(',',$category) 	: '';
	$include_cat_child	= ( $include_cat_child == 'false' ) ? false : true;
	$postdesign 		= ($design && (array_key_exists(trim($design), $shortcode_designs))) ? trim($design) 	: 'design-1';
	$show_date 			= ( $show_date == 'false' ) 			? 'false' 	: 'true';
	$show_category 		= ( $show_category_name == 'false' ) 	? 'false' 	: 'true';
	$show_author 		= ( $show_author == 'true' ) 			? 'true' 	: 'false';
	$order 				= ( strtolower($order) == 'asc' ) 		? 'ASC' 	: 'DESC';
	$orderby 			= !empty($orderby) 						? $orderby 	: 'date';
	$exclude_cat		= !empty($exclude_cat)		? explode(',', $exclude_cat) 	: array();
	$hide_post			= !empty($hide_post)		? explode(',', $hide_post) 		: array();
	$posts				= !empty($posts)			? explode(',', $posts) 			: array();
	$image_height 		= (!empty($image_height)) ? $image_height: "400px";

	// Shortcode file
	$wpfp_design_file_path 	= FTPP_DIR . '/templates/featured/' . $postdesign . '.php';
	$design_file 			= (file_exists($wpfp_design_file_path)) ? $wpfp_design_file_path : '';

	// Taking some globals
	global $post;

	// Taking some variables
	$i 				= 1;
	$grid_count 	= 1;
	$prefix 		= FTPP_FC_META_PREFIX; // Metabox prefix

	// Query Parameter
	$args = array ( 
					'post_type'      		=> FTPP_POST_TYPE,
					'post_status'			=> array( 'publish' ),
					'orderby'        		=> $orderby,
					'order'          		=> $order,
					'posts_per_page' 		=> $posts_per_page,
					'ignore_sticky_posts'	=> true,
					'post__not_in'	 		=> $hide_post,
					'post__in'		 		=> $posts,	
				);

	// Meta Query
	$args['meta_query'] = array(
								array(
										'key'     => $prefix.'featured_post',
										'value'   => 1,
										'compare' => '=',
								));

	// Category Parameter
	if($cat != "") {
		$args['tax_query'] = array(
									array(
											'taxonomy' 			=> FTPP_CAT,
											'field' 			=> 'term_id',
											'terms' 			=> $cat,
											'include_children'	=> $include_cat_child,
									));

	}  else if( !empty($exclude_cat) ) {
		
		$args['tax_query'] = array(
									array(
										'taxonomy' 			=> FTPP_CAT,
										'field' 			=> 'term_id',
										'terms' 			=> $exclude_cat,
										'operator'			=> 'NOT IN',
										'include_children'	=> $include_cat_child,
										));
	}

	// WP Query
	$query = new WP_Query($args);

	ob_start();

	// If post is there
	if ( $query->have_posts() ) { ?>

		<div class="wpfp-featured-post <?php echo $postdesign; ?> wpfp-clearfix">

			<?php while ( $query->have_posts() ) : $query->the_post();

				$terms 		= get_the_terms( $post->ID, FTPP_CAT );
				$feat_image = ftpp_get_post_featured_image( $post->ID );
				$wpfp_link 	= array();

				$dynamic_height 	= ($grid_count == 1 ) ? $image_height : ($image_height/2);
				$image_height_css 	= ($dynamic_height) ? "style='height:{$dynamic_height}px;'" : "style='height:300px;'";
				$container_cls 		= ($i == 1) ? 'wpfp-medium-6 wpfp-medium-left' : "wpfp-medium-3 wpfp-medium-right";
				$main_cls 			= $container_cls.' '.'wpfpcolumns';

				if($terms) {
					foreach ( $terms as $term ) {
						$term_link 		= get_term_link( $term );
						$wpfp_link[] 	= '<a href="' . esc_url( $term_link ) . '">'.$term->name.'</a>';
					}
				}
				$cate_name = join( " ", $wpfp_link );

    			// Include shortcode html file
    			if( $design_file ) {
					include( $design_file );
				}

				$grid_count++;
				$i++;
			endwhile; ?>

		</div><!-- end .wpfp-featured-post -->

	<?php } // End of if have posts
		
	wp_reset_query(); // Reset WP Query
	
	$content .= ob_get_clean();
	return $content;
}

// Featured Post shortcode
add_shortcode('fpc_post_block', 'ftpp_featured_post');
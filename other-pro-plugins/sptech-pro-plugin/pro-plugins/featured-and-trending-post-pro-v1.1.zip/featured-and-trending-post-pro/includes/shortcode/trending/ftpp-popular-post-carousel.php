<?php

/**
 * 'wtpsw_carousel' Shortcode
 * 
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Handles Popuplar Post carousel shortcode
 * 
 * @package Featured and Trending Post Pro
 * @since 1.0.0
 */
function ftpp_tp_popular_post_carousel( $atts, $content ){

	global $ftpp_view_by, $ftpp_model;

	// Shortcode attributes
	extract( shortcode_atts( array(	
		'slides_to_show'  			=> '3',
		'slides_to_scroll'  		=> '1',
		'view_by'					=> 'views',
		'order'						=> 'DESC',
		'orderby'					=> 'meta_value_num',
		'show_comment_count'		=> 'true',
		'hide_empty_comment_count'	=> 'false',
		'limit' 					=> '20',
		'post_type'       			=> 'post',
		'design' 					=> 'design-1',
		'show_date' 				=> 'true',
		'show_author' 				=> 'true',
		'dots'     					=> 'true',
		'arrows'     				=> 'true',				
		'autoplay'     				=> 'true',		
		'autoplay_interval' 		=> '3000',				
		'speed'             		=> '600',
		'loop'						=> 'true',
		'rtl'						=> 'false',
		'hide_post'        			=> array(),
		'posts'						=> array(),
		'slider_height'				=> '',
	), $atts, 'wtpsw_carousel' ));

	$shortcode_designs 			= ftpp_trending_post_designs();
	$postdesign 				= ($design && (array_key_exists(trim($design), $shortcode_designs))) ? trim($design) 	: 'design-1';
	$slides_to_show				= (!empty($slides_to_show))		? $slides_to_show		: '3';
	$slides_to_scroll			= (!empty($slides_to_scroll))		? $slides_to_scroll		: '1';
	$view_by					= !empty($view_by)		? $view_by 		: 'views';
	$post_type					= !empty($post_type)	? $post_type 	: 'post';
	$order 						= ($order == 'DESC')	? 'DESC'		: 'ASC';
	$orderby 					= (!empty($orderby))	? $orderby		: 'date';
	$limit 						= !empty($limit) 			? $limit 				: '20';
	$showDate 					= ( $show_date == 'false' ) 			? 'false'	: 'true';
	$showauthor 				= ( $show_author == 'false')			? 'false'	: 'true';
	$dots 						= ( $dots == 'false' ) 		? 'false' : 'true';
	$arrows 					= ( $arrows == 'false' ) 	? 'false' : 'true';
	$autoplay 					= ( $autoplay == 'false' ) 	? 'false' : 'true';
	$autoplay_interval 			= !empty($autoplay_interval) ? $autoplay_interval : '3000';
	$speed 						= !empty($speed) 					? $speed 	: '600';
	$infinite 					= ( $loop == 'false' ) 				? 'false' 	: 'true';
	$hide_post					= !empty($hide_post)		? explode(',', $hide_post) 		: array();
	$posts						= !empty($posts)			? explode(',', $posts) 			: array();
	$slider_height 				= (!empty($slider_height)) 	? $slider_height 	: '';
	$image_height_css 			= (!empty($slider_height))	? "style='height:{$slider_height}px;'" : "style='height:300px;'";
	$hide_empty_comment_count 	= ($hide_empty_comment_count == 'true') ? true : false;
	$support_post_types 		= ftpp_get_option('post_types', array());

	// For RTL
	if( empty($rtl) && is_rtl() ) {
		$rtl = 'true';
	} elseif ( $rtl == 'true' ) {
		$rtl = 'true';
	} else {
		$rtl = 'false';
	}

	// Shortcode file
	$wtpsw_design_file_path = FTPP_DIR . '/templates/trending/' . $postdesign . '.php';
	$design_file 			= (file_exists($wtpsw_design_file_path)) ? $wtpsw_design_file_path : '';

	// Enqueue required script
	wp_enqueue_script('wpos-slick-jquery');
	wp_enqueue_script( 'ftpp-public-script' );

	// Taking some globals
	global $post;

	// Taking some variables
	$prefix 			= FTPP_TP_META_PREFIX; // Metabox prefix
	$unique				= ftpp_get_unique();
	$main_cls 			= 'wtpsw-post-carousel-slide';
	$query_post_type	= array();

	// Slider configuration
	$slider_conf = compact('dots', 'arrows', 'autoplay', 'autoplay_interval', 'speed', 'design', 'rtl', 'infinite','slides_to_show','slides_to_scroll');

	// For multiple post types
	if( !empty($post_type) ) {
		$post_type_arr = explode(',', $post_type);

		foreach ($post_type_arr as $post_type_key => $post_type_val) {
			$post_type_val = trim($post_type_val);

			if( !empty($post_type_val) && in_array($post_type_val, $support_post_types) ) {
				$query_post_type[] = $post_type_val;
			}
		}
	}

	// Order By
	if( $view_by == 'comment' ) {
		$orderby = 'comment_count';
	} elseif ( $view_by == 'views' ) {
		$orderby = 'meta_value_num';
	}
	
	$ftpp_view_by = $orderby; // Assign to global variable for query filter
	
	$post_args = array(
						'post_type'				=> $query_post_type,
						'post_status'			=> array( 'publish' ),
						'posts_per_page'		=> $limit,
						'order'					=> $order,
						'orderby'				=> $orderby,
						'ignore_sticky_posts'	=> true,
						'post__not_in'	 		=> $hide_post,
						'post__in'		 		=> $posts
					);

	if( $view_by == 'views' ){
		$post_args['meta_key'] = $prefix.'views';
	}
	
	// Filter to change query where condition
	add_filter( 'posts_where', array($ftpp_model, 'ftpp_query_where') );
	
	// Query to get post
	$ftpp_posts = $ftpp_model->ftpp_get_posts( $post_args );
	
	// Remove Filter for change query where condition
	remove_filter( 'posts_where', array($ftpp_model, 'ftpp_query_where') );

	ob_start();
	
	// If post is there
	if( $ftpp_posts->have_posts() ) { ?>
		<div class="wtpsw-carousel-wrp">
			<div id="wtpsw-post-carousel-<?php echo $unique; ?>" class="wtpsw-post-carousel <?php echo $design; ?> wtpsw-clearfix">
				<?php while ($ftpp_posts->have_posts()) : $ftpp_posts->the_post();
					
					$wtpsw_post_stats 	= array();
					$post_id 			= isset($post->ID) ? $post->ID : '';
					$comment_text 		= ftpp_get_comments_number( $post->ID, $hide_empty_comment_count );
					$feat_image 		= ftpp_get_post_featured_image( $post->ID );
					
					// Include shortcode html file
					if( $design_file ) {
						include( $design_file );
					}
					endwhile;
				?>
			</div>
			<div class="wtpsw-carousel-conf" data-conf="<?php echo htmlspecialchars(json_encode($slider_conf)); ?>"></div>
		</div>
<?php
	} // End of have_posts()
	
	wp_reset_query(); // Reset WP Query

	$content .= ob_get_clean();
	return $content;
}

// Trending popular post carousel shortcode
add_shortcode( 'wtpsw_carousel', 'ftpp_tp_popular_post_carousel' );
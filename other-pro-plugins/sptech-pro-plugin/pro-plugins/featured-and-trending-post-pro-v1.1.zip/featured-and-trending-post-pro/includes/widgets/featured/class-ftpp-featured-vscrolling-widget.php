<?php
/**
 * Widget API: Featured Post Vertical Scrolling Widget
 *
 * @package WP Featured Post
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

add_action( 'widgets_init', 'wpfp_post_scrolling_widget' );

/**
* Register trending post vertical slider widget
*
* @package Featured and Trending Post Pro
* @since 1.0.0
*/
function wpfp_post_scrolling_widget() {
	register_widget( 'Wpfp_Post_Scrolling_Widget' );
}

/**
* Vertical Scrolling Post Widget Class
*
* @package Featured and Trending Post Pro
* @since 1.0.0
*/
class Wpfp_Post_Scrolling_Widget extends WP_Widget {

	var $model,$defaults;

	function __construct() {

		// Widget settings
		$widget_ops = array( 'classname' => 'wpfp_post_scrolling_widget', 'description' => __( 'Display all your featured post in vertical scrolling layout.', 'featured-and-trending-post' ) );

		// Create the widget
		WP_Widget::__construct( 'wpfp-post-scrolling-widget', __( 'WPOS - Featured Post Scrolling', 'featured-and-trending-post' ), $widget_ops );

		$this->defaults = array( 
			'num_items'         => 5,
			'title'             => '',
			'date'              => 1, 
			'show_category'     => 1,
			'category'          => 0,
			'show_content'		=> 1,
			'content_length'	=> 20,
			'pause'             => 3000,
			'speed'             => 1000,
			'height'            => 500,
			);
	}

	/**
	* Updates the widget control options
	*
	* @package Featured and Trending Post Pro
	* @since 1.0.0
	*/
	function update( $new_instance, $old_instance ) {

		$instance = $old_instance;

		// Input fields
		$instance['title']              = sanitize_text_field($new_instance['title']);
		$instance['num_items']          = !empty($new_instance['num_items'])          ? $new_instance['num_items'] : 5;
		$instance['date']               = !empty($new_instance['date'])               ? 1 : 0;
		$instance['show_category']      = !empty($new_instance['show_category'])      ? 1 : 0;
		$instance['category']           = intval( $new_instance['category'] );
		$instance['show_content']		= !empty($new_instance['show_content'])		  ? 1 : 0;
		$instance['content_length']		= ( !empty($new_instance['content_length']) ) ? $new_instance['content_length'] : 20;
		$instance['pause']          	= !empty($new_instance['pause'])			  ? $new_instance['pause'] : 3000;
		$instance['speed']          	= !empty($new_instance['speed'])			  ? $new_instance['speed'] : 1000;
		$instance['height']          	= !empty($new_instance['height'])        	  ? $new_instance['height'] : 500;

		return $instance;
	}

	/**
	 * Displays the widget form in widget area
	 *
	 * @package Featured and Trending Post Pro
	 * @since 1.0.0
	 */
	function form( $instance ) {

		
		$instance = wp_parse_args( (array) $instance, $this->defaults );
		?>

		<!-- Title -->
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e( 'Title:', 'featured-and-trending-post' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($instance['title']); ?>" />
		</p>

		<!-- Number of Items -->
		<p>
			<label for="<?php echo $this->get_field_id('num_items'); ?>"><?php _e( 'Number of Items:', 'featured-and-trending-post' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('num_items'); ?>" name="<?php echo $this->get_field_name('num_items'); ?>" type="number" min="-1" value="<?php echo esc_attr($instance['num_items']); ?>" />
		</p>

		<!-- Category -->
		<p>
			<label for="<?php echo $this->get_field_id( 'category' ); ?>"><?php _e( 'Category:', 'featured-and-trending-post' ); ?></label>
			<?php
			$dropdown_args = array( 
				'taxonomy'          => FTPP_CAT,
				'class'             => 'widefat',
				'show_option_all'   => __( 'All', 'featured-and-trending-post' ),
				'id'                => $this->get_field_id( 'category' ),
				'name'              => $this->get_field_name( 'category' ),
				'selected'          => $instance['category']
				);
			wp_dropdown_categories( $dropdown_args );
			?>
		</p>

		<!--  Display Date -->
		<p>
			<input id="<?php echo $this->get_field_id( 'date' ); ?>" name="<?php echo $this->get_field_name( 'date' ); ?>" type="checkbox" value="1" <?php checked( $instance['date'], 1 ); ?> />
			<label for="<?php echo $this->get_field_id( 'date' ); ?>"><?php _e( 'Display Date', 'featured-and-trending-post' ); ?></label>
		</p>

		<!-- Display Category -->
		<p>
			<input id="<?php echo $this->get_field_id( 'show_category' ); ?>" name="<?php echo $this->get_field_name( 'show_category' ); ?>" type="checkbox" value="1" <?php checked( $instance['show_category'], 1 ); ?> />
			<label for="<?php echo $this->get_field_id( 'show_category' ); ?>"><?php _e( 'Display Category', 'featured-and-trending-post' ); ?></label>
		</p>

		<!--  Display Date -->
		<p>
			<input id="<?php echo $this->get_field_id( 'show_content' ); ?>" name="<?php echo $this->get_field_name( 'show_content' ); ?>" type="checkbox" value="1" <?php checked( $instance['show_content'], 1 ); ?> />
			<label for="<?php echo $this->get_field_id( 'show_content' ); ?>"><?php _e( 'Show Content', 'featured-and-trending-post' ); ?></label>
		</p>

		<!-- Show Post Content Word Limit -->
		<p>
			<label for="<?php echo $this->get_field_id( 'content_length' ); ?>"><?php _e( 'Post Content Length', 'featured-and-trending-post'); ?>:</label> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'content_length' ); ?>" name="<?php echo $this->get_field_name( 'content_length' ); ?>" type="number" min="1" value="<?php echo $instance['content_length']; ?>" />
			<span class="description"><em><?php _e('Enter number of words to display in post content.', 'featured-and-trending-post'); ?></em></span>
		</p>

		<!-- Pause -->
		<p>
			<label for="<?php echo $this->get_field_id( 'pause' ); ?>"><?php _e( 'Pause:', 'blog-designer-for-post-and-widget' ); ?></label>
			<input type="number" name="<?php echo $this->get_field_name( 'pause' ); ?>"  value="<?php echo $instance['pause']; ?>" class="widefat" id="<?php echo $this->get_field_id( 'pause' ); ?>" min="3000" step="100" />
		</p>

		<!-- Speed -->
		<p>
			<label for="<?php echo $this->get_field_id( 'speed' ); ?>"><?php _e( 'Speed:', 'blog-designer-for-post-and-widget' ); ?></label>
			<input type="number" name="<?php echo $this->get_field_name( 'speed' ); ?>"  value="<?php echo $instance['speed']; ?>" class="widefat" id="<?php echo $this->get_field_id( 'speed' ); ?>" min="1000" step="100" />
		</p>

		<!-- Vertical Scrolling Height -->
		<p>
			<label for="<?php echo $this->get_field_id('height'); ?>"><?php _e( 'Height:', 'featured-and-trending-post' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('height'); ?>" name="<?php echo $this->get_field_name('height'); ?>" type="number" value="<?php echo esc_attr($instance['height']); ?>" min="500" step="100"/>
		</p>

		<?php
	}

	/**
	* Outputs the content of the widget
	*
	* @package Featured and Trending Post Pro
	* @since 1.0.0
	*/
	function widget( $args, $instance ) {

		extract( $args );

		$title          = apply_filters( 'widget_title', isset( $instance['title'] ) ? $instance['title'] : __( 'Featured Post List', 'featured-and-trending-post' ), $instance, $this->id_base );
		$num_items      = $instance['num_items'];
		$date           = ( isset($instance['date']) && ($instance['date'] == 1) ) ? "true" : "false";
		$show_category	= ( isset($instance['show_category']) && ($instance['show_category'] == 1) ) ? "true" : "false";
		$category       = $instance['category'];
		$show_content   = ( isset($instance['show_content']) && ($instance['show_content'] == 1) ) ? "true" : "false";
		$content_length = $instance['content_length'];
		$pause          = $instance['pause'];
		$speed          = $instance['speed'];
		$height         = $instance['height'];

        // Slider configuration
		$slider_conf = compact( 'pause', 'speed', 'height' );

		// Enqueue required script
        wp_enqueue_script( 'wpos-vticker-jquery' );
        wp_enqueue_script( 'ftpp-public-script' );

		// Taking some globals
        global $post;

		// Taking Some Variables
        $unique = ftpp_get_unique();
        $prefix = FTPP_FC_META_PREFIX; // Metabox Prefix

        $featured_args = array(
        	'post_type'             => FTPP_POST_TYPE,
        	'post_status'           => array( 'publish' ),
        	'order'                 => 'DESC',
        	'posts_per_page'        => $num_items,
        	'ignore_sticky_posts'   => true,
        	);
		// Meta Query
        $featured_args['meta_query'] = array(
        	array(
        		'key'     => $prefix.'featured_post',
        		'value'   => 1,
        		'compare' => '=',
        		));

        // Category Parameter
        if( !empty($category) ) {
        	$featured_args['tax_query'] = array(
        		array(
        			'taxonomy'  => FTPP_CAT,
        			'field'     => 'term_id',
        			'terms'     => $category
        			));
        }

        // WP Query
        $cust_loop = new WP_Query($featured_args);

        echo $before_widget;

        if ( $title ) {
        	echo $before_title . $title . $after_title;
        }

        if( $cust_loop->have_posts() ) { ?>

        <div class="wpfp-featured-post-widget-wrp wpfp-clearfix">
        	<div class="wpfp-vscrolling-post">
        		<div class="wpfp-verical-scrolling-widget" id="wpfp-verical-scrolling-widget-<?php echo $unique; ?>">
        			<ul>

        				<?php while ($cust_loop->have_posts()) : $cust_loop->the_post();
        				$feat_image     = ftpp_get_post_featured_image( $post->ID );
        				$terms          = get_the_terms( $post->ID, 'category' );
        				$featured_links = array();

        				if($terms) {
        					foreach ( $terms as $term ) {
        						$term_link = get_term_link( $term );
        						$featured_links[] = '<a href="' . esc_url( $term_link ) . '">'.$term->name.'</a>';
        					}
        				}
        				$category = join( " ", $featured_links );
        				?>

        				<li class="wpfp-post-li">

        					<?php
							// Post Thumbnail
        					if (!empty($feat_image)) { ?>
        					<div class="wpfp-post-thumb-left">
        						<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
        							<img src="<?php echo $feat_image; ?>" alt="<?php _e( 'Post Image', 'featured-and-trending-post') ?>"/>
        						</a>	
        					</div>
        					<?php
        				}
        				?>

        				<div class="wpfp-post-thumb-right">

        					<div class="wpfp-post-title"><a class="wpfp-post-title" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></div>

        					<?php if( $date == "true" ) { ?>
        					<div class="wpfp-date-post">
        						<span>
        							<i class='icon-clock'></i>
        							<?php echo ($date == "true") ? get_the_date( ftpp_get_option('date_format') ) : '' ; ?>
        						</span>
        					</div>
        					<?php } ?>

        					<?php if($show_category == 'true' && $category !='') { ?>
        					<div class="wpfp-categories">       
        						<?php echo $category; ?>       
        					</div>
        					<?php } ?>

        					<?php if($show_content == 'true' && $show_content != '') { ?>
        					<div class="wpfp-post-cnt">
        						<?php echo ftpp_get_post_excerpt( $post->ID, null, $content_length );  ?>
        					</div>
        					<?php } ?>
        				</div>
        			</li>

        		<?php endwhile; ?>

        	</ul>
        	<div class="wpfp-vscrolling-conf" data-conf="<?php echo htmlspecialchars(json_encode($slider_conf)); ?>"></div>
        </div>
    </div>
</div>

	<?php } // End of have_posts()

		wp_reset_query(); // Reset WP Query

		echo $after_widget;
	}
}
<?php
/**
 * Widget API: Featured Post Slider
 *
 * @package WP Featured Post
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

function ftpp_featured_post_slider_widget() {
    register_widget( 'Ftpp_fpsw_Widget' );
}

// Action to register widget
add_action( 'widgets_init', 'ftpp_featured_post_slider_widget' );

class Ftpp_fpsw_Widget extends WP_Widget {

    /**
     * Sets up a new widget instance.
     *
     * @package WP Featured Post
     * @since 1.0.0
     */
    function __construct() {
        $widget_ops = array('classname' => 'wpfp-featured-fpsw', 'description' => __('Display Featured Post Items in Slider view.', 'featured-and-trending-post') );
        parent::__construct( 'ftpp_fpsw_widget', __('WPOS - Featured Post Slider', 'featured-and-trending-post'), $widget_ops );
    }

    /**
     * Handles updating settings for the current widget instance.
     *
     * @package WP Featured Post
     * @since 1.0.0
     */
    function update($new_instance, $old_instance) {

        $instance = $old_instance;

        $instance['title']              = sanitize_text_field($new_instance['title']);
        $instance['num_items']          = !empty($new_instance['num_items'])        ? $new_instance['num_items'] : 5;
        $instance['date']               = !empty($new_instance['date'])             ? 1 : 0;
        $instance['show_category']      = !empty($new_instance['show_category'])    ? 1 : 0;
        $instance['category']           = intval( $new_instance['category'] );
        $instance['arrows']             = ($new_instance['arrows'] == 'false') ? 'false' : 'true';
        $instance['autoplay']           = ($new_instance['autoplay'] == 'false') ? 'false' : 'true';
        $instance['autoplayInterval']   = intval( $new_instance['autoplayInterval'] );
        $instance['speed']              = intval( $new_instance['speed'] );
        
        return $instance;
    }

    /**
     * Outputs the settings form for the widget.
     *
     * @package WP Featured Post
     * @since 1.0.0
     */
     function form($instance) {

        $defaults = array(
            'num_items'         => 5,
            'title'             => '',
            "date"              => 1, 
            'show_category'     => 1,
            'category'          => 0,
            'arrows'            => "true",
            'autoplay'          => "true",      
            'autoplayInterval'  => 3000,                
            'speed'             => 300,
        );
        
        $instance = wp_parse_args( (array) $instance, $defaults );
    ?>

        <!-- Title -->
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e( 'Title:', 'featured-and-trending-post' ); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($instance['title']); ?>" />
        </p>
        
        <!-- Number of Items -->
        <p>
            <label for="<?php echo $this->get_field_id('num_items'); ?>"><?php _e( 'Number of Items:', 'featured-and-trending-post' ); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('num_items'); ?>" name="<?php echo $this->get_field_name('num_items'); ?>" type="number" min="-1" value="<?php echo esc_attr($instance['num_items']); ?>" />
        </p>
        
        <!-- Category -->
        <p>
            <label for="<?php echo $this->get_field_id( 'category' ); ?>"><?php _e( 'Category:', 'featured-and-trending-post' ); ?></label>
            <?php
            $dropdown_args = array( 
                'taxonomy'          => FTPP_CAT,
                'class'             => 'widefat',
                'show_option_all'   => __( 'All', 'featured-and-trending-post' ),
                'id'                => $this->get_field_id( 'category' ),
                'name'              => $this->get_field_name( 'category' ),
                'selected'          => $instance['category']
                );
            wp_dropdown_categories( $dropdown_args );
            ?>
        </p>

        <!--  Display Date -->
        <p>
            <input id="<?php echo $this->get_field_id( 'date' ); ?>" name="<?php echo $this->get_field_name( 'date' ); ?>" type="checkbox" value="1" <?php checked( $instance['date'], 1 ); ?> />
            <label for="<?php echo $this->get_field_id( 'date' ); ?>"><?php _e( 'Display Date', 'featured-and-trending-post' ); ?></label>
        </p>

        <!-- Display Category -->
        <p>
            <input id="<?php echo $this->get_field_id( 'show_category' ); ?>" name="<?php echo $this->get_field_name( 'show_category' ); ?>" type="checkbox" value="1" <?php checked( $instance['show_category'], 1 ); ?> />
            <label for="<?php echo $this->get_field_id( 'show_category' ); ?>"><?php _e( 'Display Category', 'featured-and-trending-post' ); ?></label>
        </p>

        <!-- Slider Arrows -->
        <p>
            <label for="<?php echo $this->get_field_id( 'arrows' ); ?>"><?php _e( 'Arrows:', 'featured-and-trending-post' ); ?></label>
            <select name="<?php echo $this->get_field_name( 'arrows' ); ?>" class="widefat" id="<?php echo $this->get_field_id( 'arrows' ); ?>">
                <option value="true" <?php selected( $instance['arrows'], 'true' ); ?>><?php _e( 'True', 'featured-and-trending-post' ); ?></option>
                <option value="false" <?php selected( $instance['arrows'], 'false' ); ?>><?php _e( 'False', 'featured-and-trending-post' ); ?></option>
            </select>
        </p>

        <!-- Slider Auto play -->
        <p>
            <label for="<?php echo $this->get_field_id( 'autoplay' ); ?>"><?php _e( 'Auto Play:', 'featured-and-trending-post' ); ?></label>
            <select name="<?php echo $this->get_field_name( 'autoplay' ); ?>" class="widefat" id="<?php echo $this->get_field_id( 'autoplay' ); ?>">
                <option value="true" <?php selected( $instance['autoplay'], 'true' ); ?>><?php _e( 'True', 'featured-and-trending-post' ); ?></option>
                <option value="false" <?php selected( $instance['autoplay'], 'false' ); ?>><?php _e( 'False', 'featured-and-trending-post' ); ?></option>
            </select>
        </p>

        <!-- Slider  AutoplayInterval -->
        <p>
            <label for="<?php echo $this->get_field_id( 'autoplayInterval' ); ?>"><?php _e( 'Autoplay Interval:', 'featured-and-trending-post' ); ?></label>
            <input type="text" name="<?php echo $this->get_field_name( 'autoplayInterval' ); ?>"  value="<?php echo $instance['autoplayInterval']; ?>" class="widefat" id="<?php echo $this->get_field_id( 'autoplayInterval' ); ?>" />
        </p>

        <!-- Slider Speed -->
        <p>
            <label for="<?php echo $this->get_field_id( 'speed' ); ?>"><?php _e( 'Speed:', 'featured-and-trending-post' ); ?></label>
            <input type="text" name="<?php echo $this->get_field_name( 'speed' ); ?>"  value="<?php echo $instance['speed']; ?>" class="widefat" id="<?php echo $this->get_field_id( 'speed' ); ?>" />
        </p>
        <?php
    }

    /**
     * Outputs the content for the current widget instance.
     *
     * @package WP Featured Post
     * @since 1.0.0
     */
    function widget( $featured_args, $instance ) {

        extract($featured_args, EXTR_SKIP);
        
        $title                      = apply_filters( 'widget_title', isset( $instance['title'] ) ? $instance['title'] : __( 'Featured Post List', 'featured-and-trending-post' ), $instance, $this->id_base );
        $num_items                  = $instance['num_items'];
        $date                       = ( isset($instance['date']) && ($instance['date'] == 1) ) ? "true" : "false";
        $show_category              = ( isset($instance['show_category']) && ($instance['show_category'] == 1) ) ? "true" : "false";
        $category                   = $instance['category'];
        $arrows                     = $instance['arrows'];
        $autoplay                   = $instance['autoplay'];
        $autoplay_interval          = $instance['autoplayInterval'];
        $speed                      = $instance['speed'];

        // Slider configuration
        $slider_conf = compact( 'speed', 'autoplay_interval', 'autoplay', 'arrows' );

        // Taking some globals
        global $post;

        // Enqueue required script
        wp_enqueue_script('wpos-slick-jquery');
        wp_enqueue_script( 'ftpp-public-script' );

        // Taking some variables
        $unique = ftpp_get_unique();
        $prefix = FTPP_FC_META_PREFIX; // Metabox Prefix

        // WP Query Parameter
        $featured_args = array(
            'post_type'             => FTPP_POST_TYPE,
            'post_status'           => array( 'publish' ),
            'order'                 => 'DESC',
            'posts_per_page'        => $num_items,
            'ignore_sticky_posts'   => true,
        );

        // Meta Query
        $featured_args['meta_query'] = array(
                                            array(
                                                'key'     => $prefix.'featured_post',
                                                'value'   => 1,
                                                'compare' => '=',
                                        ));

        // Category Parameter
        if( !empty($category) ) {
            $featured_args['tax_query'] = array(
                                            array(
                                                'taxonomy'  => FTPP_CAT,
                                                'field'     => 'term_id',
                                                'terms'     => $category
                                            ));
        }
        
        // WP Query
        $cust_loop = new WP_Query($featured_args);

        echo $before_widget;

        if ( $title ) {
            echo $before_title . $title . $after_title;
        }

        if ($cust_loop->have_posts()) { ?>

            <div class="wpfp-featured-post-widget-wrp wpfp-clearfix">
                <div id="wpfp-featured-post-widget-slider-<?php echo $unique; ?>" class="wpfp-widget wpfp-featured-post-widget-slider">

                    <?php while ($cust_loop->have_posts()) : $cust_loop->the_post();
                        
                        $feat_image     = ftpp_get_post_featured_image( $post->ID );
                        $terms          = get_the_terms( $post->ID, 'category' );
                        $featured_links = array();

                        if($terms) {
                            foreach ( $terms as $term ) {
                                $term_link = get_term_link( $term );
                                $featured_links[] = '<a href="' . esc_url( $term_link ) . '">'.$term->name.'</a>';
                            }
                        }
                        $cate_name = join( " ", $featured_links );
                    ?>

                    <div class="featured-slider">
                        <div class="featured-image-bg">
                            <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
                                <?php if( !empty($feat_image) ) { ?>
                                <img src="<?php echo $feat_image; ?>" alt="<?php _e( 'Post Image', 'featured-and-trending-post') ?>" />
                                <?php } ?>
                            </a>

                            <?php if($show_category == 'true' && $cate_name !='') { ?>
                            <div class="featured-categories">       
                                <?php echo $cate_name; ?>       
                            </div>
                            <?php } ?>
                        </div>

                        <div class="featured-slider-content">
                            <div class="featured-content">
                                <div class="featured-title">
                                    <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
                                </div>

                                <?php if($date == "true") { ?>
                                    <div class="featured-date">
                                        <span>
                                            <i class='icon-clock'></i>   
                                            <?php echo get_the_date(); ?>
                                        </span>
                                    </div>
                                    <?php } ?>
                            </div>
                        </div>
                    </div>

                    <?php endwhile; ?>

                </div>
                <div class="wpfp-widget-slider-conf" data-conf="<?php echo htmlspecialchars(json_encode($slider_conf)); ?>"></div>
            </div>

        <?php
        } // End of have_posts()
        
        wp_reset_query(); // Reset WP Query
        
        echo $after_widget;
    }
}
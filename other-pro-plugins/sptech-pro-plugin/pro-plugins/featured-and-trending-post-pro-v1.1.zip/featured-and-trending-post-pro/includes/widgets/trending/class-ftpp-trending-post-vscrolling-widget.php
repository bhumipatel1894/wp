<?php
/**
 * Vertical Scrolling Widget Class
 *
 * @package Featured and Trending Post Pro
 * @since 1.0.0
*/

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

add_action( 'widgets_init', 'wtpsw_post_scrolling_widget' );

/**
 * Register trending post scrolling widget
 *
 * @package Featured and Trending Post Pro
 * @since 1.0.0
*/
function wtpsw_post_scrolling_widget() {
	register_widget( 'Wtpsw_Post_vscrolling_Widget' );
}

class Wtpsw_Post_vscrolling_Widget extends WP_Widget {

	var $model,$defaults;

	function __construct() {

		global $wtpsw_model;
		$ftpp_model = $wtpsw_model;

		// Widget settings
		$widget_ops = array( 'classname' => 'wtpsw_post_scrolling_widget', 'description' => __( 'Display most popular trending post on your page with Vertical Scrolling.', 'featured-and-trending-post' ) );

		// Create the widget
		parent::__construct( 'wtpsw-post-scrolling-widget', __( 'WPOS - Trending Post Scrolling', 'featured-and-trending-post' ), $widget_ops );
	
		$this->defaults = array( 
			'title' 				   => '',
			'limit'					   => 5,
			'post_type'				   => '',
			'show_content'			   => 'false',
			'show_thumb'			   => 'true',
			'show_author'			   => 'true',
			'show_date'				   => 'true',
			'order'					   => 'DESC',
			'view_by'				   => 'views',
			'content_length'		   => 20,
			'show_comment_count'	   => 'true',
			'hide_empty_comment_count' => 'false',
			'arrows'            	   => "true",
			'autoplay'          	   => "true",      
			'pause'  	  			   => 3000,                
			'speed'             	   => 1000,
			'height'				   => 500,
			);
	}

	/**
	 * Updates the widget control options
	 *
	 * @package Featured and Trending Post Pro
	 * @since 1.0.0
	*/
	function update( $new_instance, $old_instance ) {

		$instance = $old_instance;

		// Input fields
		$instance['title'] 					  = strip_tags( $new_instance['title'] );
		$instance['limit']					  = ( empty($new_instance['limit']) || ($new_instance['limit'] < -1) ) ? 5 : $new_instance['limit'];
		$instance['post_type']				  = $new_instance['post_type'];
		$instance['view_by']				  = $new_instance['view_by'];
		$instance['order']					  = (isset($new_instance['order']) && $new_instance['order'] == 'ASC') ? 'ASC' : 'DESC';
		$instance['show_author']			  = ( isset($new_instance['show_author']) ) 	? 'true' : 'false';
		$instance['show_comment_count']		  = ( isset($new_instance['show_comment_count']) ) 	? 'true' : 'false';
		$instance['show_content']			  = ( isset($new_instance['show_content']) ) 	? 'true' : 'false';
		$instance['show_thumb']				  = ( isset($new_instance['show_thumb']) ) 	? 'true' : 'false';
		$instance['show_date']				  = ( isset($new_instance['show_date']) ) 	? 'true' : 'false';
		$instance['content_length']			  = ( !empty($new_instance['content_length']) ) ? $new_instance['content_length'] : 20;
		$instance['hide_empty_comment_count'] = ( isset($new_instance['hide_empty_comment_count']) ) ? 'true' : 'false';
		$instance['pause']   	  			  = ( !empty( $new_instance['pause'] )) ? $new_instance['pause'] : 3000;
		$instance['speed']              	  = ( !empty( $new_instance['speed'] )) ? $new_instance['speed'] : 1000 ;
		$instance['height']          	      = !empty($new_instance['height'])     ? $new_instance['height'] : 500;

		return $instance;
	}

	/**
	 * Displays the widget form in widget area
	 *
	 * @package Featured and Trending Post Pro
	 * @since 1.0.0
 	 */
	function form( $instance ) {

		$instance = wp_parse_args( (array) $instance, $this->defaults );
		if(!is_array($instance['post_type'])){
			$instance['post_type'] = explode(',',$instance['post_type']);
		}
		
		if(!is_array($instance['post_type'])) {
			$instance['post_type'] = explode(',', $instance['post_type']);
		}

		$reg_post_types_arr 	= ftpp_get_post_types();
		$reg_post_types 	= array_keys($reg_post_types_arr);
		$support_post_types = ftpp_get_option('post_types',array());
		$sel_post_type      = (!empty($instance['post_type']) && in_array($instance['post_type'], $support_post_types)) ? $instance['post_type']    : 'post';
		
		?>

		<!-- Title Field -->
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', 'featured-and-trending-post'); ?></label> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $instance['title']; ?>" />
		</p>

		<!-- Post Type Field -->
		<p>
			<label for="<?php echo $this->get_field_id( 'post_type' ); ?>"><?php _e( 'Post Types:', 'featured-and-trending-post'); ?></label>
			<?php if( !empty($support_post_types) ) { ?>
			<select class="widefat ftpp-reg-post-types" id="<?php echo $this->get_field_id('post_type'); ?>" name="<?php echo $this->get_field_name('post_type[]'); ?>" multiple="multiple">
                <?php foreach ($support_post_types as $post_key => $post_value) {
                    if(in_array($post_value, $reg_post_types)) {
                        echo '<option value="'.$post_value.'" '.selected(in_array($post_value, $instance['post_type']),true).'>'.$reg_post_types_arr[$post_value].'</option>';
                    }
				} ?>
            </select>
            <span class="description"><em><?php _e('Select post types which you want to display.', 'featured-and-trending-post'); ?></em></span>
            <?php } else { ?>
            	<span style="display:block; color:#a94442;"><?php _e('Sorry, No Post Type is enabled for trending post. Please enable from plugin', 'featured-and-trending-post'); ?> <a target="_blank" href="<?php echo ftpp_pro_plugin_link(); ?>">settings</a>.</span>
            <?php } ?>
		</p>

		<!-- View By Field -->
		<p>
			<label for="<?php echo $this->get_field_id( 'view_by' ); ?>"><?php _e( 'Post List By:', 'featured-and-trending-post'); ?></label>
			<select class="widefat" id="<?php echo $this->get_field_id( 'view_by' ); ?>" name="<?php echo $this->get_field_name( 'view_by' ); ?>">
				<option value="views" <?php selected( $instance['view_by'], 'views' ); ?> ><?php _e('Total Views', 'featured-and-trending-post') ?></option>
				<option value="comment" <?php selected( $instance['view_by'], 'comment' ); ?>><?php _e('Comments Count', 'featured-and-trending-post'); ?></option>
			</select>
		</p>

		<!-- Number of Items Field -->
		<p>
			<label for="<?php echo $this->get_field_id( 'limit' ); ?>"><?php _e( 'Number of Items:', 'featured-and-trending-post'); ?></label> 
			<input class="widefat" min="-1" id="<?php echo $this->get_field_id( 'limit' ); ?>" name="<?php echo $this->get_field_name( 'limit' ); ?>" type="number" value="<?php echo $instance['limit']; ?>" />
		</p>

		<!-- Order Field -->
		<p>
			<label for="<?php echo $this->get_field_id( 'order' ); ?>"><?php _e( 'Order:', 'featured-and-trending-post'); ?></label>
			<select class="widefat" id="<?php echo $this->get_field_id( 'order' ); ?>" name="<?php echo $this->get_field_name( 'order' ); ?>">
				<option value="ASC" <?php selected( $instance['order'], 'ASC' ); ?> ><?php _e('ASC', 'featured-and-trending-post') ?></option>
				<option value="DESC" <?php selected( $instance['order'], 'DESC' ); ?>><?php _e('DESC', 'featured-and-trending-post'); ?></option>
			</select>
		</p>

		<!-- Show Content Field -->
		<p>
			<input type="checkbox" value="1" id="<?php echo $this->get_field_id( 'show_content' ); ?>" name="<?php echo $this->get_field_name( 'show_content' ); ?>" <?php checked( $instance['show_content'], 'true' ); ?>>
			<label for="<?php echo $this->get_field_id( 'show_content' ); ?>"><?php _e( 'Show Post Content', 'featured-and-trending-post'); ?></label><br/>
			<span class="description"><em><?php _e('If your post has excerpt then it will take it else post content will be taken.', 'featured-and-trending-post'); ?></em></span>
		</p>

		<!-- Show Post Content Word Limit -->
		<p>
			<label for="<?php echo $this->get_field_id( 'content_length' ); ?>"><?php _e( 'Post Content Length', 'featured-and-trending-post'); ?>:</label> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'content_length' ); ?>" name="<?php echo $this->get_field_name( 'content_length' ); ?>" type="number" min="1" value="<?php echo $instance['content_length']; ?>" />
			<span class="description"><em><?php _e('Enter number of words to display in post content.', 'featured-and-trending-post'); ?></em></span>
		</p>

		<!-- Show Thumbnail Field -->
		<p>
			<input type="checkbox" value="1" id="<?php echo $this->get_field_id( 'show_thumb' ); ?>" name="<?php echo $this->get_field_name( 'show_thumb' ); ?>" <?php checked( $instance['show_thumb'], 'true' ); ?>>
			<label for="<?php echo $this->get_field_id( 'show_thumb' ); ?>"><?php _e( 'Show Thumbnail', 'featured-and-trending-post'); ?></label>
		</p>

		<!-- Show Author Field -->
		<p>
			<input type="checkbox" value="1" id="<?php echo $this->get_field_id( 'show_author' ); ?>" name="<?php echo $this->get_field_name( 'show_author' ); ?>" <?php checked( $instance['show_author'], 'true' ); ?>>
			<label for="<?php echo $this->get_field_id( 'show_author' ); ?>"><?php _e( 'Show Author', 'featured-and-trending-post'); ?></label>
		</p>

		<!-- Show Date Field -->
		<p>
			<input type="checkbox" value="1" id="<?php echo $this->get_field_id( 'show_date' ); ?>" name="<?php echo $this->get_field_name( 'show_date' ); ?>" <?php checked( $instance['show_date'], 'true' ); ?>>
			<label for="<?php echo $this->get_field_id( 'show_date' ); ?>"><?php _e( 'Show Date', 'featured-and-trending-post'); ?></label>
		</p>

		<!-- Show Comment Field -->
		<p>
			<input type="checkbox" value="1" id="<?php echo $this->get_field_id( 'show_comment_count' ); ?>" name="<?php echo $this->get_field_name( 'show_comment_count' ); ?>" <?php checked( $instance['show_comment_count'], 'true' ); ?>>
			<label for="<?php echo $this->get_field_id( 'show_comment_count' ); ?>"><?php _e( 'Show Comment Count', 'featured-and-trending-post'); ?></label>
		</p>

		<!-- Show Empty Comment Field -->
		<p>
			<input type="checkbox" value="1" id="<?php echo $this->get_field_id( 'hide_empty_comment_count' ); ?>" name="<?php echo $this->get_field_name( 'hide_empty_comment_count' ); ?>" <?php checked( $instance['hide_empty_comment_count'], 'true' ); ?>>
			<label for="<?php echo $this->get_field_id( 'hide_empty_comment_count' ); ?>"><?php _e( 'Hide Empty Comment Count', 'featured-and-trending-post'); ?></label><br/>
			<span class="description"><em><?php _e('Hide comment count if it is empty.', 'featured-and-trending-post'); ?></em></span>
		</p>

		<!-- Scrolling  pause -->
		<p>
			<label for="<?php echo $this->get_field_id( 'pause' ); ?>"><?php _e( 'Pause:', 'featured-and-trending-post' ); ?></label>
			<input type="number" name="<?php echo $this->get_field_name( 'pause' ); ?>"  value="<?php echo $instance['pause']; ?>" class="widefat" id="<?php echo $this->get_field_id( 'pause' ); ?>" min="3000" step="100"/>
		</p>

		<!-- Scrolling Speed -->
		<p>
			<label for="<?php echo $this->get_field_id( 'speed' ); ?>"><?php _e( 'Speed:', 'featured-and-trending-post' ); ?></label>
			<input type="number" name="<?php echo $this->get_field_name( 'speed' ); ?>"  value="<?php echo $instance['speed']; ?>" class="widefat" id="<?php echo $this->get_field_id( 'speed' ); ?>" min="1000" step="100" />
		</p>

		<!-- Vertical Scrolling Height-->
		<p>
			<label for="<?php echo $this->get_field_id( 'height' ); ?>"><?php _e( 'Height:', 'featured-and-trending-post'); ?></label> 
			<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'height' ); ?>" name="<?php echo $this->get_field_name( 'height' ); ?>" value="<?php echo $instance['height']; ?>" min="500" step="100" />
		</p>

		<?php
	}

	/**
	 * Outputs the content of the widget
	 *
	 * @package Featured and Trending Post Pro
	 * @since 1.0.0
	 */
	function widget( $args, $instance ) {

		global $ftpp_view_by, $ftpp_model;

		extract( $args );

		$prefix						= FTPP_TP_META_PREFIX;
		$query_post_type			= array();
		$title 						= $instance['title'];
		$limit 						= $instance['limit'];
		$show_date 					= $instance['show_date'];
		$show_author 				= $instance['show_author'];
		$show_comment_count			= $instance['show_comment_count'];
		$show_thumb 				= $instance['show_thumb'];
		$show_content 				= $instance['show_content'];
		$view_by 					= $instance['view_by'];
		$order 						= $instance['order'];
		$post_type 					= $instance['post_type'];
		$content_length 			= $instance['content_length'];
		$hide_empty_comment_count 	= ($instance['hide_empty_comment_count'] == 'true') ? true : false;
		$pause          			= $instance['pause'];
		$speed                      = $instance['speed'];
		$height                     = $instance['height'];
		$support_post_types 		= ftpp_get_option('post_types',array());
		// scrolling configuration
		$slider_conf = compact( 'speed', 'pause', 'height' );

		// Taking some globals
		global $post;

		// Taking some variables
		$unique = ftpp_get_unique();

		if( !empty($post_type) ) {
			foreach ($post_type as $post_key => $post_val) {
				if( in_array($post_val, $support_post_types) ) {
					$query_post_type[] = $post_val;
				}
			}
		}

		// If no post type is there then return
		if( empty($query_post_type) ) {
			return;
		}

		// Enqueue required script
		wp_enqueue_script( 'wpos-vticker-jquery' );
		wp_enqueue_script( 'ftpp-public-script' );
		
		// Order By
		if( $view_by == 'comment' ) {
			$orderby = 'comment_count';
		} elseif ( $view_by == 'views' ) {
			$orderby = 'meta_value_num';
		}

		$ftpp_view_by = $orderby; // Assign to global variable for query filter

		// WP Query Parameters
		$post_args = array(
			'post_type'				=> $query_post_type,
			'post_status'			=> array( 'publish' ),
			'posts_per_page'		=> $limit,
			'order'					=> $order,
			'orderby'				=> $orderby,
			'ignore_sticky_posts'	=> true,     
			'pause'  				=> $pause,                
			'speed'             	=> $speed,
			);
		
		
		if( $view_by == 'views' ){
			$post_args['meta_key'] = $prefix.'views';
		}

		// Filter to change query where condition
		add_filter( 'posts_where', array($ftpp_model, 'ftpp_query_where') );

		// Query to get post
		$ftpp_posts = $ftpp_model->ftpp_get_posts( $post_args );

		// Remove Filter for change query where condition
		remove_filter( 'posts_where', array($ftpp_model, 'ftpp_query_where') );

		echo $before_widget;

		if ( $title ) {
			echo $before_title . $title . $after_title;
		}

		// If post is there
		if( $ftpp_posts->have_posts() ) { ?>

		<div class="wtpsw-post-scrolling-widget-wrp wtpsw-clearfix">
			<div class="wtpsw-scrolling-post">
				<div id="wtpsw-widget-vscrolling-<?php echo $unique; ?>" class="wtpsw-widget-vscrolling">
					<ul>
						<?php while ($ftpp_posts->have_posts()) : $ftpp_posts->the_post();

				$wtpsw_stats    = array(); // Need to flush
				$comment_text   = ftpp_get_comments_number( $post->ID, $hide_empty_comment_count );
				$feat_image     = ftpp_get_post_featured_image( $post->ID );
				?>
				<li class="wtpsw-post-li">
					<?php if( $show_thumb == 'true' ) { ?>
					<div class="wtpsw-post-thumb-left">
						<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
							<img src="<?php echo $feat_image; ?>" alt="<?php _e( 'Post Image', 'featured-and-trending-post') ?>"/>
						</a>
					</div>
					<?php } ?>

					<div class="wtpsw-post-thumb-right">

						<h6><a class="wtpsw-post-title" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h6>

						<?php if( $show_date == "true" ) { ?>
						<div class="wtpsw-date-post">
							<span>
								<i class='icon-clock'></i>
								<?php echo ($show_date == "true") ? get_the_date( ftpp_get_option('date_format') ) : '' ; ?>
							</span>
						</div>
						<?php } ?>

						<div class="wtpsw-post-stats">
							<?php if( $show_author == 'true' ) {
								$wtpsw_stats[] = "<span class='wtpsw-post-author'><i class='icon-user'></i>".__('By ', 'featured-and-trending-post')."<a href='".get_author_posts_url( $post->author )."'>".get_the_author()."</a></span>";
							} ?>

							<?php if( $show_comment_count == 'true' && $comment_text ) {
								$wtpsw_stats[] = "<span class='wtpsw-post-comment'>".$comment_text."</span>";
							} ?>

							<?php echo join( ' | ', $wtpsw_stats ); ?>
						</div>
						<?php if($show_content == 'true') { ?>
						<div class="wtpsw-post-cnt" style="width: 100%;float:left;">
							<?php echo ftpp_get_post_excerpt( $post->ID, null, $content_length );  ?>
						</div>
						<?php } ?>
					</div>
				</li>
			<?php endwhile; ?>
			</ul>
		</div>
	</div>
	<div class="wtpsw-vscrolling-conf" data-conf="<?php echo htmlspecialchars(json_encode($slider_conf)); ?>"></div>
</div>

	<?php } // End of have_posts()

		wp_reset_query(); // Reset WP Query

		echo $after_widget;
	}
}
﻿=== Featured And Trending Post Pro ===
Contributors: wponlinesupport
Tags: featured post, featured post grid, featured post widget, responsive featured post grid, responsive featured post, brick layout, featured post brick layout, featured posts, add featured posts, display featured posts, Trending Post, Trending post grid, Trending post wdget, Responsive trending post grid, responsive trending post, Trending post brick layout, display trending post
Requires at least: 3.1
Tested up to: 4.7.5

Display Featured post on your website with 4 shortcode and 2 widget.
Display Trending post on your website with 4 shortcode and 2 widget.

== Description ==

Featured and Trending Posts allows you to add featured posts and trending posts to your blog website via shortcode in pages and/or posts. Display your popular posts from any post type on your blog website via shortcode in pages and/or posts.
This plugin makes it easier to mark posts as featured posts from post list OR from post inner section.

View [DEMO](https://www.wponlinesupport.com/wp-plugin/featured-and-trending-posts/) for more informations.

= Shortcode and widget =
= Featured and Trending Posts has 8 shortoctcodes and 2 widget =
* Featured GridBox : <code>[fpc_post_block]</code>
* Featured Grid : <code>[fpc_post_grid]</code>
* Featured Slider : <code>[fpc_post_slider]</code>
* Featured Carousel : <code>[fpc_post_carousel]</code>
* Trending GridBox : <code>[wtpsw_gridbox]</code>
* Trending Grid : <code>[wtpsw_grid]</code>
* Trending Slider : <code>[wtpsw_popular_post]</code>
* Trending Carousel : <code>[wtpsw_carousel]</code>
* List and Slider Widget for Featured Post
* List and Slider Widget for Trending Post

= Features =
* Mark any post as a Featured Post from post list OR from post inner section and display them in 4 layout and 20 designs.
* Display popular posts from any post type in 4 layout and 20 designs.
* Adjust Featured Posts display to any theme.
* 8 Shortcode and 4 widget.
* You can set how many posts you wish to display.
* You can select any category.

= Shortcodes =
* <code>[fpc_post_block limit="10"]</code>
* <code>[fpc_post_grid]</code>
* <code>[fpc_post_slider]</code>
* <code>[fpc_post_carousel]</code>
* <code>[wtpsw_gridbox]</code>
* <code>[wtpsw_grid]</code>
* <code>[wtpsw_popular_post]</code>
* <code>[wtpsw_carousel]</code>

= Templete code =
* <code><?php echo do_shortcode('[fpc_post_block limit="10"]'); ?></code>
* <code><?php echo do_shortcode('[fpc_post_grid limit="10"]'); ?></code>
* <code><?php echo do_shortcode('[fpc_post_slider limit="10"]'); ?></code>
* <code><?php echo do_shortcode('[fpc_post_carousel limit="10"]'); ?></code>
* <code><?php echo do_shortcode('[wtpsw_gridbox limit="10"]'); ?></code>
* <code><?php echo do_shortcode('[wtpsw_grid limit="10"]'); ?></code>
* <code><?php echo do_shortcode('[wtpsw_popular_post limit="10"]'); ?></code>
* <code><?php echo do_shortcode('[wtpsw_carousel grid="3" limit="10"]'); ?></code>

= Following are Featured post Parameters: =

<code>[fpc_post_block]</code>
* **Limit :** [fpc_post_block limit="10"] (Display latest 10 featured post).
* **Category :** [fpc_post_block category="category_id"] (Display featured post categories wise.)
* **Include Category Child :** [fpc_post_block include_cat_child="true"] (If you are displaying parent category wise then wheather to display child category post or not.)
* **Design :** [fpc_post_block design="design-1"] (Display featured post in defferent 20 design.)
* **Show Author :** [fpc_post_block show_author="true"] (Display featured post author OR not. By default value is “true”. Values are “true” OR “false” ).
* **Show Date :** [fpc_post_block show_date="false"] (Display featured post date OR not. By default value is “true”. Options are “true OR false”).
* **Show Category Name :** [fpc_post_block show_category_name="true" ] (Display featured post category name OR not. By default value is “true”. Options are “true OR false”).
* **Order :** [fpc_post_block order="DESC"] (Controls featured post order. Values are "ASC" OR "DESC".)
* **Orderby :** [fpc_post_block orderby="post_date"] (Display featured post in your order. Values are "post_date", "modified", "title", "name" (Post Slug), "ID", "rand", "menu_order", "comment_count")
* **Exclude Category :** [fpc_post_block exclude_cat="1,5,6"] (Exclude some post category which you do not want to display.)
* **Display Specific Posts :** [fpc_post_block posts="1,5,6"] (Display only specific posts.)
* **Exclude Post :** [fpc_post_block hide_post="1,5,6"] (Exclude some post which you do not want to display.)
* **Image Height :** [fpc_post_block image_height="500"] (Control featured post image height.)

<code>[fpc_post_grid]</code>
* **Limit :** [fpc_post_grid limit="10"] (Display latest 10 featured post).
* **Grid:**  [fpc_post_grid grid="3"] (Display post in grid3. You can use grid:1,2,3,4).
* **Design :** [fpc_post_grid design="design-1"] (Display featured post in defferent 20 design).
* **Show Author :** [fpc_post_grid show_author="true"] (Display featured post author OR not. By default value is “true”. Values are “true” OR “false” ).
* **Category :** [fpc_post_grid category="category_id"] (Display featured post categories wise.)
* **Include Category Child :** [fpc_post_grid include_cat_child="true"] (If you are displaying parent category wise then wheather to display child category post or not.)
* **Show Category Name :** [fpc_post_grid show_category_name="true" ] (Display featured post category name OR not. By default value is “true”. Options are “true OR false”).
* **Show Date :** [fpc_post_grid show_date="false"] (Display featured post date OR not. By default value is “true”. Options are “true OR false”).
* **Order :** [fpc_post_grid order="DESC"] (Controls featured post order. Values are "ASC" OR "DESC".)
* **Orderby :** [fpc_post_grid orderby="post_date"] (Display featured post in your order. Values are "post_date", "modified", "title", "name" (Post Slug), "ID", "rand", "menu_order", "comment_count")
* **Exclude Category :** [fpc_post_grid exclude_cat="1,5,6"] (Exclude some post category which you do not want to display.)
* **Display Specific Posts :** [fpc_post_grid posts="1,5,6"] (Display only specific posts.)
* **Exclude Post :** [fpc_post_grid hide_post="1,5,6"] (Exclude some post which you do not want to display.)
* **Image Height :** [fpc_post_grid image_height="500"] (Control featured post image height.)

<code>[fpc_post_slider]</code>
* **Limit :** [fpc_post_slider limit="10"] (Display latest 10 featured post).
* **Category :** [fpc_post_slider category="category_id"] (Display featured post categories wise.)
* **Include Category Child :** [fpc_post_slider include_cat_child="true"] (If you are displaying parent category wise then wheather to display child category post or not.)
* **Design :** [fpc_post_slider design="design-1"] (Display featured post in defferent 20 design.)
* **Show Author :** [fpc_post_slider show_author="true"] (Display featured post author OR not. By default value is “true”. Values are “true” OR “false” ).
* **Show Date :** [fpc_post_slider show_date="false"] (Display featured post date OR not. By default value is “true”. Options are “true OR false”).
* **Show Category Name :** [fpc_post_slider show_category_name="true" ] (Display featured post category name OR not. By default value is “true”. Options are “true OR false”).
* **Order :** [fpc_post_slider order="DESC"] (Controls featured post order. Values are "ASC" OR "DESC".)
* **Orderby :** [fpc_post_slider orderby="post_date"] (Display featured post in your order. Values are "post_date", "modified", "title", "name" (Post Slug), "ID", "rand", "menu_order", "comment_count")
* **Exclude Category :** [fpc_post_slider exclude_cat="1,5,6"] (Exclude some post category which you do not want to display.)
* **Display Specific Posts :** [fpc_post_slider posts="1,5,6"] (Display only specific posts.)
* **Exclude Post :** [fpc_post_slider hide_post="1,5,6"] (Exclude some post which you do not want to display.)
* **Slider Height :** [fpc_post_slider slider_height="500"] (Control featured post image height.)
* **Dots :** [fpc_post_slider dots="true"] (Dots parameter will control visibility of slider dots).
* **Arrow :** [fpc_post_slider arrows="true"] (Arrow parameter will control visibility of slider next previous arrow buttons).
* **Autoplay :** [fpc_post_slider autoplay="true"] (Autoplay slides).
* **Autoplay Interval:** [fpc_post_slider autoplay_interval="true"] (Autoplay Interval will set time between slides change).
* **Speed:** [fpc_post_slider speed="true"] (Speed of slider will be controled with this parameter).
* **Loop:** [fpc_post_slider loop="true"] (Continus slider will set with this parameter).

<code>[fpc_post_carousel]</code>
* **Limit :** [fpc_post_carousel limit="10"] (Display latest 10 featured post).
* **Category :** [fpc_post_carousel category="category_id"] (Display featured post categories wise.)
* **Include Category Child :** [fpc_post_carousel include_cat_child="true"] (If you are displaying parent category wise then wheather to display child category post or not.)
* **Design :** [fpc_post_carousel design="design-1"] (Display featured post in defferent 20 design.)
* **Show Author :** [fpc_post_carousel show_author="true"] (Display featured post author OR not. By default value is “true”. Values are “true” OR “false” ).
* **Show Date :** [fpc_post_carousel show_date="false"] (Display featured post date OR not. By default value is “true”. Options are “true OR false”).
* **Show Category Name :** [fpc_post_carousel show_category_name="true" ] (Display featured post category name OR not. By default value is “true”. Options are “true OR false”).
* **Order :** [fpc_post_carousel order="DESC"] (Controls featured post order. Values are "ASC" OR "DESC".)
* **Orderby :** [fpc_post_carousel orderby="post_date"] (Display featured post in your order. Values are "post_date", "modified", "title", "name" (Post Slug), "ID", "rand", "menu_order", "comment_count")
* **Exclude Category :** [fpc_post_carousel exclude_cat="1,5,6"] (Exclude some post category which you do not want to display.)
* **Display Specific Posts :** [fpc_post_carousel posts="1,5,6"] (Display only specific posts.)
* **Exclude Post :** [fpc_post_carousel hide_post="1,5,6"] (Exclude some post which you do not want to display.)
* **Slider Height :** [fpc_post_carousel slider_height="500"] (Control featured post image height.)
* **Dots :** [fpc_post_carousel dots="true"] (Dots parameter will control visibility of slider dots).
* **Arrow :** [fpc_post_carousel arrows="true"] (Arrow parameter will control visibility of slider next previous arrow buttons).
* **Autoplay :** [fpc_post_carousel autoplay="true"] (Autoplay slides).
* **Autoplay Interval:** [fpc_post_carousel autoplay_interval="true"] (Autoplay Interval will set time between slides change).
* **Speed:** [fpc_post_carousel speed="true"] (Speed of slider will be controled with this parameter).
* **Loop:** [fpc_post_carousel loop="true"] (Continus slider will set with this parameter).
* **Slides To Scroll:** [fpc_post_carousel slides_to_scroll="2"] (Set number of slides to scroll at a time).
* **Slides To Show:** [fpc_post_carousel slides_to_show="2"] (Set number of slides for show).

= Following are Trending post Parameters: =

<code>[wtpsw_gridbox]</code>
* **Limit :** [wtpsw_gridbox limit="10"] (Display latest 10 Trending post).
* **Post Type :** [wtpsw_gridbox post_type="post"] (Display Trending post from different post types).
* **Design :** [wtpsw_gridbox design="design-1"] (Display Trending post in defferent 20 design.)
* **Show Author :** [wtpsw_gridbox show_author="true"] (Display Trending post author OR not. By default value is “true”. Values are “true” OR “false” ).
* **Show Date :** [wtpsw_gridbox show_date="false"] (Display Trending post date OR not. By default value is “true”. Options are “true OR false”).
* **Order :** [wtpsw_gridbox order="DESC"] (Controls Trending post order. Values are "ASC" OR "DESC".)
* **Orderby :** [wtpsw_gridbox orderby="post_date"] (Display Trending post in your order. Values are "post_date", "modified", "title", "name" (Post Slug), "ID", "rand", "menu_order", "comment_count")
* **Image Height :** [wtpsw_gridbox image_height="500"] (Control Trending post image height.)
* **View By :** [wtpsw_gridbox view_by="views"] (Display Trending post accoring to their views, comments.)
* **Show Comment Count :** [wtpsw_gridbox show_comment_count="true"] (Display number of comments on post.)
* **Hide Empty Comment Count :** [wtpsw_gridbox hide_empty_comment_count="false"] (Display 0 comment count or not.)
* **Display Specific Posts :** [wtpsw_gridbox posts="1,5,6"] (Display only specific posts.)
* **Exclude Post :** [wtpsw_gridbox hide_post="1,5,6"] (Exclude some post which you do not want to display.)

<code>[wtpsw_grid]</code>
* **Limit :** [wtpsw_grid limit="10"] (Display latest 10 Trending post).
* **Post Type :** [wtpsw_grid post_type="post"] (Display Trending post from different post types).
* **Grid :** [wtpsw_grid grid="post"] (Display Trending post in various grid).
* **Design :** [wtpsw_grid design="design-1"] (Display Trending post in defferent 20 design.)
* **Show Author :** [wtpsw_grid show_author="true"] (Display Trending post author OR not. By default value is “true”. Values are “true” OR “false” ).
* **Show Date :** [wtpsw_grid show_date="false"] (Display Trending post date OR not. By default value is “true”. Options are “true OR false”).
* **Order :** [wtpsw_grid order="DESC"] (Controls Trending post order. Values are "ASC" OR "DESC".)
* **Orderby :** [wtpsw_grid orderby="post_date"] (Display Trending post in your order. Values are "post_date", "modified", "title", "name" (Post Slug), "ID", "rand", "menu_order", "comment_count")
* **Image Height :** [wtpsw_grid image_height="500"] (Control Trending post image height.)
* **View By :** [wtpsw_grid view_by="views"] (Display Trending post accoring to their views, comments.)
* **Show Comment Count :** [wtpsw_grid show_comment_count="true"] (Display number of comments on post.)
* **Hide Empty Comment Count :** [wtpsw_grid hide_empty_comment_count="false"] (Display 0 comment count or not.)
* **Display Specific Posts :** [wtpsw_grid posts="1,5,6"] (Display only specific posts.)
* **Exclude Post :** [wtpsw_grid hide_post="1,5,6"] (Exclude some post which you do not want to display.)

<code>[wtpsw_popular_post]</code>
* **Limit :** [wtpsw_popular_post limit="10"] (Display latest 10 Trending post).
* **Post Type :** [wtpsw_popular_post post_type="post"] (Display Trending post from different post types).
* **Design :** [wtpsw_popular_post design="design-1"] (Display Trending post in defferent 20 design.)
* **Show Author :** [wtpsw_popular_post show_author="true"] (Display Trending post author OR not. By default value is “true”. Values are “true” OR “false” ).
* **Show Date :** [wtpsw_popular_post show_date="false"] (Display Trending post date OR not. By default value is “true”. Options are “true OR false”).
* **Order :** [wtpsw_popular_post order="DESC"] (Controls Trending post order. Values are "ASC" OR "DESC".)
* **Orderby :** [wtpsw_popular_post orderby="post_date"] (Display Trending post in your order. Values are "post_date", "modified", "title", "name" (Post Slug), "ID", "rand", "menu_order", "comment_count")
* **Slider Height :** [wtpsw_popular_post slider_height="500"] (Control Trending post image height.)
* **Dots :** [wtpsw_popular_post dots="true"] (Dots parameter will control visibility of slider dots).
* **Arrow :** [wtpsw_popular_post arrows="true"] (Arrow parameter will control visibility of slider next previous arrow buttons).
* **Autoplay :** [wtpsw_popular_post autoplay="true"] (Autoplay slides).
* **Autoplay Interval :** [wtpsw_popular_post autoplay_interval="true"] (Autoplay Interval will set time between slides change).
* **Speed :** [wtpsw_popular_post speed="true"] (Speed of slider will be controled with this parameter).
* **Loop :** [wtpsw_popular_post loop="true"] (Continus slider will set with this parameter).
* **View By :** [wtpsw_popular_post view_by="views"] (Display Trending post accoring to their views, comments.)
* **Show Comment Count :** [wtpsw_popular_post show_comment_count="true"] (Display number of comments on post.)
* **Hide Empty Comment Count :** [wtpsw_popular_post hide_empty_comment_count="false"] (Display 0 comment count or not.)
* **Display Specific Posts :** [wtpsw_popular_post posts="1,5,6"] (Display only specific posts.)
* **Exclude Post :** [wtpsw_popular_post hide_post="1,5,6"] (Exclude some post which you do not want to display.)

<code>[wtpsw_carousel]</code>
* **Limit :** [wtpsw_carousel limit="10"] (Display latest 10 Trending post).
* **Post Type :** [wtpsw_carousel post_type="post"] (Display Trending post from different post types).
* **Design :** [wtpsw_carousel design="design-1"] (Display Trending post in defferent 20 design.)
* **Show Author :** [wtpsw_carousel show_author="true"] (Display Trending post author OR not. By default value is “true”. Values are “true” OR “false” ).
* **Show Date :** [wtpsw_carousel show_date="false"] (Display Trending post date OR not. By default value is “true”. Options are “true OR false”).
* **Order :** [wtpsw_carousel order="DESC"] (Controls Trending post order. Values are "ASC" OR "DESC".)
* **Orderby :** [wtpsw_carousel orderby="post_date"] (Display Trending post in your order. Values are "post_date", "modified", "title", "name" (Post Slug), "ID", "rand", "menu_order", "comment_count")
* **Slider Height :** [wtpsw_carousel slider_height="500"] (Control Trending post image height.)
* **Dots :** [wtpsw_carousel dots="true"] (Dots parameter will control visibility of slider dots).
* **Arrow :** [wtpsw_carousel arrows="true"] (Arrow parameter will control visibility of slider next previous arrow buttons).
* **Autoplay :** [wtpsw_carousel autoplay="true"] (Autoplay slides).
* **Autoplay Interval:** [wtpsw_carousel autoplay_interval="true"] (Autoplay Interval will set time between slides change).
* **Speed:** [wtpsw_carousel speed="true"] (Speed of slider will be controled with this parameter).
* **Loop:** [wtpsw_carousel loop="true"] (Continus slider will set with this parameter).
* **Slides To Scroll:** [wtpsw_carousel slides_to_scroll="2"] (Set number of slides to scroll at a time).
* **Slides To Show:** [wtpsw_carousel slides_to_show="2"] (Set number of slides for show).
* **View By :** [wtpsw_carousel view_by="views"] (Display Trending post accoring to their views, comments.)
* **Show Comment Count :** [wtpsw_carousel show_comment_count="true"] (Display number of comments on post.)
* **Hide Empty Comment Count :** [wtpsw_carousel hide_empty_comment_count="false"] (Display 0 comment count or not.)
* **Display Specific Posts :** [wtpsw_carousel posts="1,5,6"] (Display only specific posts.)
* **Exclude Post :** [wtpsw_carousel hide_post="1,5,6"] (Exclude some post which you do not want to display.)

== Installation ==
1. Upload the 'featured-and-trending-post' folder to the '/wp-content/plugins/' directory.
2. Activate the 'featured-and-trending-post' list plugin through the 'Plugins' menu in WordPress.
3. Go to Post--> All Post and click the STAR to make post as a featured post. 
4. Use the following shortcode.

= Shortcodes =
* <code>[fpc_post_block limit="10"]</code>
* <code>[fpc_post_grid]</code>
* <code>[fpc_post_slider]</code>
* <code>[fpc_post_carousel]</code>
* <code>[wtpsw_gridbox]</code>
* <code>[wtpsw_grid]</code>
* <code>[wtpsw_popular_post]</code>
* <code>[wtpsw_carousel]</code>

= Templete code =
* <code><?php echo do_shortcode('[fpc_post_block limit="10"]'); ?></code>
* <code><?php echo do_shortcode('[fpc_post_grid limit="10"]'); ?></code>
* <code><?php echo do_shortcode('[fpc_post_slider limit="10"]'); ?></code>
* <code><?php echo do_shortcode('[fpc_post_carousel limit="10"]'); ?></code>
* <code><?php echo do_shortcode('[wtpsw_gridbox limit="10"]'); ?></code>
* <code><?php echo do_shortcode('[wtpsw_grid limit="10"]'); ?></code>
* <code><?php echo do_shortcode('[wtpsw_popular_post limit="10"]'); ?></code>
* <code><?php echo do_shortcode('[wtpsw_carousel grid="3" limit="10"]'); ?></code>
 
== Screenshots ==

1. Grid Block
2. Grid
3. Slider
4. Carousel
5. Featured Post Star
6. Feature List widget
7. Feature Slider Widget
8. Trending List Widget
9. Trending Slider Widget


== Changelog ==

= 1.1 (May 29, 2017) =
* [*] Note : Please update widget and save plugin settings for Trending Post and Widget functionality once you update plugin.
* [+] Added 'Post Type' support settings for trending post.
* [+] Added 'posts', 'hide_post', 'exclude_cat' parameter for featured post shortcodes.
* [+] Added 'posts', 'hide_post' parameter for trending post shortcodes.
* [*] Updated plugin translation code. Now user can put plugin languages file in WordPress 'language' folder so plugin language file will not be loss while plugin update.
* [*] Updated 'How it Work' page for better user interface.
* [*] Issue fixed in some shortcode parameter.

= 1.0 (Dec 06, 2016) =
* Initial release.

== Upgrade Notice ==

= 1.1 (May 29, 2017) =
* [+] Note : Please update widget and save plugin settings for Trending Post and Widget functionality once you update plugin.
* [+] Added 'Post Type' support settings for trending post.
* [+] Added 'posts', 'hide_post', 'exclude_cat' parameter for featured post shortcodes.
* [+] Added 'posts', 'hide_post' parameter for trending post shortcodes.
* [*] Updated plugin translation code. Now user can put plugin languages file in WordPress 'language' folder so plugin language file will not be loss while plugin update.
* [*] Updated 'How it Work' page for better user interface.
* [*] Issue fixed in some shortcode parameter.

= 1.0 (Dec 06, 2016) =
* Initial release.
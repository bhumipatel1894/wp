<div class="<?php echo $main_cls; ?>" <?php echo $image_height_css; ?>>
	<a class="wpfp-link-overlay" href="<?php the_permalink(); ?>"></a>
	<div class="wpfp-featured-content">
		<div class="wpfp-overlay">
			<div class="wpfp-image-bg">
				<?php if( !empty($feat_image) ) { ?>
				<img src="<?php echo $feat_image; ?>" alt="<?php the_title(); ?>" />
				<?php } ?>
			</div>
			<?php if($show_category == "true" && $cate_name !='') { ?>
			<div class="wpfp-categories">
				<?php echo $cate_name; ?>
			</div>
			<?php } ?>
			<div class="wpfp-bottom-content">
				<div class="wpfp-title">
					<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
				</div>
				<?php if($show_date == "true" || $show_author == 'true') { ?>
				<div class="wpfp-date">		
					<?php if($show_author == 'true') { ?>
					<span><i class="icon-user"></i><?php  esc_html_e( 'By', 'featured-post' ); ?> <?php the_author(); ?></span>
					<?php } ?>
					<?php echo ($show_author == 'true' && $show_date == 'true') ? '&nbsp;/&nbsp;': '' ?>
					<?php if($show_date == "true") { ?>
					<span><i class="icon-clock"></i>
						<?php echo get_the_date(); } ?></span>
					</div>
					<?php } ?>
				</div>
			</div>
		</div>
	</div>
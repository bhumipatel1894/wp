<div class="<?php echo $main_cls; ?>" <?php echo $image_height_css; ?>>
	<a class="wtpsw-link-overlay" href="<?php the_permalink(); ?>"></a>
	<div class="wtpsw-trending-content">
		<div class="wtpsw-overlay">

			<div class="wtpsw-image-bg">
				<?php if( !empty($feat_image) ) { ?>
				<img src="<?php echo $feat_image; ?>" alt="<?php the_title(); ?>" />
				<?php } ?>
			</div>
			<div class="wtpsw-bottom-content">
				<div class="wtpsw-title">
					<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
				</div>

				<?php if($showDate == "true" || $showauthor == 'true' || $show_comment_count == 'true') { ?>
				<div class="wtpsw-date">
					<?php if($showauthor == 'true') {
						$wtpsw_post_stats[] = "<span><i class='icon-user'></i>".__( 'By', 'featured-and-trending-post' )." <a href='".get_author_posts_url( $post->author )."'>".get_the_author()."</a></span>";
					} ?>

					<?php if($showDate == "true") {
						$wtpsw_post_stats[] = "<span><i class='icon-clock'></i>".get_the_date( ftpp_get_option('date_format') )."</span>";
					} ?>

					<?php if( $show_comment_count == "true" && $comment_text ) {
						$wtpsw_post_stats[] = "<span class='wtpsw-post-comment'>".$comment_text."</span>";
					} ?>

					<?php echo join(' / ', $wtpsw_post_stats); ?>

				</div>
				<?php } ?>
			</div>
		</div>
	</div>
</div>
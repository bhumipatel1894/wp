jQuery(document).ready(function($){

	// Initialize Slider
	$( '.fgsp-slider' ).each(function( index ) {
		
		var slider_id   	= $(this).attr('id');
		var nav_id 			= null;
		var slider_conf 	= $.parseJSON( $(this).parent('.fgsp-slider-wrap').find('.fgsp-slider-conf').text());
		var slider_nav_id 	= $(this).attr('data-slider-nav-for');

		// For Navigation
		if( typeof(slider_nav_id) != 'undefined' && slider_nav_id != '' ) {
			nav_id = '.'+slider_nav_id;
		}
		
		jQuery('#'+slider_id+' .fgsp-gallery-slider').slick({
			dots			: (slider_conf.dots) == "true" ? true : false,
			infinite		: (slider_conf.loop) == "true" ? true : false,
			arrows			: (slider_conf.arrows) == "true" ? true : false,
			speed			: parseInt(slider_conf.speed),
			autoplay		: (slider_conf.autoplay) == "true" ? true : false,
			autoplaySpeed	: parseInt(slider_conf.autoplay_speed),			
			rtl             : (slider_conf.rtl) == "true" ? true : false,
			mobileFirst    	: (WpFgsp.is_mobile == 1) ? true : false,
			asNavFor		: nav_id,
		});

		// For Navigation
		if( typeof(slider_nav_id) != 'undefined' ) {
			jQuery('.'+slider_nav_id).slick({
				slidesToShow 	: parseInt(slider_conf.nav_slide_column),
				slidesToScroll 	: 1,
				asNavFor 		: '#'+slider_id+' .fgsp-gallery-slider',
				dots 			: false,
				arrows 			: true,
				centerMode 		: true,
				rtl 			: (slider_conf.rtl) == "true" ? true : false,
				mobileFirst    	: (WpFgsp.is_mobile == 1) ? true : false,
				infinite 		: true,
				focusOnSelect 	: true,
				responsive 		: [
				{
					breakpoint 	: 767,
					settings 	: {
						slidesToShow 	: (parseInt(slider_conf.nav_slide_column) > 5) ? 5 : parseInt(slider_conf.nav_slide_column),
					}
				},
				{
					breakpoint 	: 640,
					settings   	: {
						slidesToShow 	: (parseInt(slider_conf.nav_slide_column) > 3) ? 3 : parseInt(slider_conf.nav_slide_column),
					}
				},
				{
					breakpoint	: 479,
					settings	: {
						slidesToShow 	: (parseInt(slider_conf.nav_slide_column) > 3) ? 3 : parseInt(slider_conf.nav_slide_column),
					}
				},
				{
					breakpoint: 319,
					settings: {
						slidesToShow: (parseInt(slider_conf.nav_slide_column) > 2) ? 2 : parseInt(slider_conf.nav_slide_column),
						centerMode :false,
					}
				}]
			});
		}
	});
	
	// Initialize Carousel
	$( '.fgsp-carousel' ).each(function( index ) {
		
		var slider_id   = $(this).attr('id');
		var slider_conf = $.parseJSON( $(this).parent('.fgsp-carousel-wrap').find('.fgsp-carousel-conf').text());
		jQuery('#'+slider_id+' .fgsp-gallery-carousel').slick({
			dots			: (slider_conf.dots) == "true" ? true : false,
			infinite		: (slider_conf.loop) == "true" ? true : false,
			arrows			: (slider_conf.arrows) == "true" ? true : false,
			speed			: parseInt(slider_conf.speed),
			autoplay		: (slider_conf.autoplay) == "false" ? false : true,
			autoplaySpeed	: parseInt(slider_conf.autoplay_speed),
			slidesToShow	: parseInt(slider_conf.slide_to_show),
			slidesToScroll	: parseInt(slider_conf.slide_to_scroll),
			centerMode 		: (slider_conf.centermode) == "true" ? true : false,
			rtl             : (slider_conf.rtl) == "true" ? true : false,
			mobileFirst    	: (WpFgsp.is_mobile == 1) ? true : false,
			responsive: [{
				breakpoint: 1023,
				settings: {
					slidesToShow: (parseInt(slider_conf.slide_to_show) > 3) ? 3 : parseInt(slider_conf.slide_to_show),
					slidesToScroll: 1,
				}
			},{
				breakpoint: 767,	  			
				settings: {
					slidesToShow: (parseInt(slider_conf.slide_to_show) > 2) ? 2 : parseInt(slider_conf.slide_to_show),
					slidesToScroll: 1
				}
			},
			{
				breakpoint: 479,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
					dots: false
				}
			},
			{
				breakpoint: 319,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
					dots: false
				}	    		
			}]
		});		
	});

	// For Variable width
	$( '.fgsp-variable' ).each(function( index ) {
		
		var slider_id   	= $(this).attr('id');
		var nav_id 			= null;
		var slider_nav_id 	= $(this).attr('data-slider-nav-for');
		var slider_conf 	= $.parseJSON( $(this).closest('.fgsp-variable-wrap').find('.fgsp-variable-conf').text());

		// For Navigation
		if( typeof(slider_nav_id) != 'undefined' && slider_nav_id != '' ) {
			nav_id = '.'+slider_nav_id;
		}
		
		jQuery('#'+slider_id+' .fgsp-gallery-variable').slick({
			dots			: (slider_conf.dots) == "true" ? true : false,
			infinite		: (slider_conf.loop) == "true" ? true : false,
			arrows			: (slider_conf.arrows) == "true" ? true : false,
			speed			: parseInt(slider_conf.speed),
			autoplay		: (slider_conf.autoplay) == "true" ? true : false,
			autoplaySpeed	: parseInt(slider_conf.autoplay_speed),
			slidesToShow	: 1,
			slidesToScroll	: 1,
			centerMode 		: true,
			rtl             : (slider_conf.rtl) == "true" ? true : false,
			mobileFirst    	: (WpFgsp.is_mobile == 1) ? true : false,
			variableWidth 	: false,
			asNavFor		: nav_id,
			responsive 		: [{
				breakpoint 	: 1023,
				settings 	: {
					infinite 		: (slider_conf.loop) == "true" ? true : false,
					dots 			: (slider_conf.dots) == "true" ? true : false,
				}
			},{
				breakpoint 	: 767,	  			
				settings	: {
					infinite 		: (slider_conf.loop) == "true" ? true : false,
					dots 			: (slider_conf.dots) == "true" ? true : false,
				}
			},
			{
				breakpoint 	: 479,
				settings 	: {
					dots 			: false,
					centerMode 		: false,
					infinite 		: (slider_conf.loop) == "true" ? true : false,
				}
			},
			{
				breakpoint	: 319,
				settings	: {
					dots			: false,
					centerMode 		: false,
					infinite 		: (slider_conf.loop) == "true" ? true : false,
				}
			}]
		});

		// For Navigation
		if( typeof(slider_nav_id) != 'undefined' ) {
			jQuery('.'+slider_nav_id).slick({
				slidesToShow 	: parseInt(slider_conf.nav_slide_column),
				slidesToScroll 	: 1,
				asNavFor 		: '#'+slider_id+' .fgsp-gallery-variable',
				dots 			: false,
				arrows 			: true,
				centerMode 		: true,
				focusOnSelect 	: true,
				rtl 			: (slider_conf.rtl) == "true" ? true : false,
				mobileFirst    	: (WpFgsp.is_mobile == 1) ? true : false,
				infinite 		: (slider_conf.loop) == "true" ? true : false,
				responsive 		: [
				{
					breakpoint 	: 767,
					settings 	: {
						slidesToShow 	: (parseInt(slider_conf.nav_slide_column) > 5) ? 5 : parseInt(slider_conf.nav_slide_column),
						centerMode 		: true,
					}
				},
				{
					breakpoint 	: 640,
					settings   	: {
						slidesToShow 	: (parseInt(slider_conf.nav_slide_column) > 3) ? 3 : parseInt(slider_conf.nav_slide_column),
						centerMode 		: true,
					}
				},
				{
					breakpoint	: 479,
					settings	: {
						slidesToShow 	: (parseInt(slider_conf.nav_slide_column) > 3) ? 3 : parseInt(slider_conf.nav_slide_column),
						centerMode 		: true,
					}
				},
				{
					breakpoint: 319,
					settings: {
						slidesToShow: (parseInt(slider_conf.nav_slide_column) > 2) ? 2 : parseInt(slider_conf.nav_slide_column),
						centerMode 	:false,
					}
				}]
			});
		}
	});

	// Magnific Popup
	$( '.fgsp-slider-popup' ).each(function( index ) {

		var popup_id = $(this).attr('id');

		if( typeof('popup_id') !== 'undefined' && popup_id != '' ) {

			var total_item	= $('#'+popup_id+' .fgsp-slide:not(.slick-cloned) a').length;

			$('#'+popup_id).magnificPopup({
				delegate: '.slick-slide a',
				type: 'image',
				tLoading: 'Loading image #%curr%...',
				mainClass: 'fgsp-mfp-popup mfp-with-zoom mfp-img-mobile',
				gallery: {
					enabled: true,
					navigateByImgClick: true,
					preload: [0,1] // Will preload 0 - before current, and 1 after the current image
				},
				image: {
					tError: '<a href="%url%">The image #%curr%</a> could not be loaded.',
					titleSrc: function(item) {
						return item.el.closest('.fgsp-img-wrap').find('.fgsp-img').attr('title');
					}
				},
				zoom: {
					enabled: false,
					duration: 300, // don't foget to change the duration also in CSS
					opener: function(element) {
						return element.closest('.fgsp-img-wrap').find('.fgsp-img');
					}
				},
				callbacks: {
					markupParse: function(template, values, item) {
						var current_indx 	= item.el.closest('.fgsp-slide').attr('data-item-index');
						values.counter 		= current_indx+' of '+total_item;
					}
				},
			});
		}
	});
});
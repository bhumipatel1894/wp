<?php
/**
 * Plugin Name: Advanced Custom Fields - Frontend Gallery Slider Pro
 * Plugin URI: https://www.wponlinesupport.com/
 * Description: Display Advanced Custom Field Gallery on frontend of your website with shorcode.
 * Author: WP Online Support 
 * Text Domain: frontend-gallery-slider-for-advanced-custom-field
 * Domain Path: /languages/
 * Version: 1.0.1
 * Author URI: https://www.wponlinesupport.com/
 *
 * @package Frontend Gallery Slider For Advanced Custom Field Pro
 * @author WP Online Support
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

if( !defined( 'FGSP_PRO_VERSION' ) ) {
	define( 'FGSP_PRO_VERSION', '1.0.1' ); // Version of plugin
}
if( !defined( 'FGSP_PRO_VERSION_DIR' ) ) {
    define( 'FGSP_PRO_VERSION_DIR', dirname( __FILE__ ) ); // Plugin dir
}
if( !defined( 'FGSP_PRO_VERSION_URL' ) ) {
    define( 'FGSP_PRO_VERSION_URL', plugin_dir_url( __FILE__ ) ); // Plugin url
}
if( !defined( 'FGSP_PRO_PLUGIN_BASENAME' ) ) {
    define( 'FGSP_PRO_PLUGIN_BASENAME', plugin_basename( __FILE__ ) ); // plugin base name
}
if( !defined( 'FGSP_PRO_POST_TYPE' ) ) {
    define( 'FGSP_PRO_POST_TYPE', (class_exists('acf_pro') ? 'acf-field-group' : 'acf') ); // plugin post type
}

// Taking some globals
global $wp_fgsp_pro_options;

// Functions File
require_once( FGSP_PRO_VERSION_DIR . '/includes/fgsp-pro-functions.php' );
$wp_fgsp_pro_options = wp_fgsp_pro_get_settings();

/**
 * Activation Hook
 * 
 * Register plugin activation hook.
 * 
 * @package Frontend Gallery Slider For Advanced Custom Field Pro
 * @since 1.0.0
 */
register_activation_hook( __FILE__, 'fgsp_pro_install' );

/**
 * Plugin Setup (On Activation)
 * 
 * Does the initial setup,
 * set default values for the plugin options.
 * 
 * @package Frontend Gallery Slider For Advanced Custom Field Pro
 * @since 1.0.0
 */
function fgsp_pro_install() {
    
    // Get settings for the plugin
    $wp_fgsp_pro_options = get_option( 'wp_fgsp_pro_options' );
    
    if( empty( $wp_fgsp_pro_options ) ) { // Check plugin version option
        
        // Set default settings
        wp_fgsp_pro_default_settings();
        
        // Update plugin version to option
        update_option( 'wp_fgsp_pro_plugin_version', '1.0' );
    }

    if( is_plugin_active('frontend-gallery-slider-for-advanced-custom-field/frontend-gallery-slider.php') ) {
        add_action('update_option_active_plugins', 'fgsp_pro_deactivate_free_version');
    }
}

/**
 * Deactivate free plugin
 * 
 * @package Frontend Gallery Slider For Advanced Custom Field Pro
 * @since 1.0.0
 */
function fgsp_pro_deactivate_free_version() {
    deactivate_plugins('frontend-gallery-slider-for-advanced-custom-field/frontend-gallery-slider.php', true);
}

/**
 * Check ACF plugin is active
 *
 * @package Frontend Gallery Slider For Advanced Custom Field Pro
 * @since 1.0.0
 */
function fgsp_pro_check_activation() {

    if ( !class_exists('acf') ) {
        // is this plugin active?
        if ( is_plugin_active( plugin_basename( __FILE__ ) ) ) {
            // deactivate the plugin
            deactivate_plugins( plugin_basename( __FILE__ ) );
            // unset activation notice
            unset( $_GET[ 'activate' ] );
            // display notice
            add_action( 'admin_notices', 'fgsp_pro_admin_notices' );
        }
    }
}

// Check required plugin is activated or not
add_action( 'admin_init', 'fgsp_pro_check_activation' );

/**
 * Admin notices
 * 
 * @package Frontend Gallery Slider For Advanced Custom Field Pro
 * @since 1.0.0
 */
function fgsp_pro_admin_notices() {

    if ( !class_exists('acf') ) {
        echo '<div class="error notice is-dismissible">';
        echo sprintf( __('<p><strong>%s</strong> recommends the following plugin to use.</p>', 'frontend-gallery-slider-for-advanced-custom-field'), 'Frontend Gallery Slider For Advanced Custom Field Pro' );
        echo sprintf( __('<p><strong><a href="%s" target="_blank">%s</a>, %s</strong></p>', 'frontend-gallery-slider-for-advanced-custom-field'), 'https://wordpress.org/plugins/advanced-custom-fields', 'Advanced Custom Fields', 'Advanced Custom Fields: Gallery Field' );
        echo '</div>';
    }
}

/**
 * Function to display admin notice of activated plugin.
 * 
 * @package Frontend Gallery Slider For Advanced Custom Field Pro
 * @since 1.0.0
 */
function front_gallery_admin_notice() {

    $dir = WP_PLUGIN_DIR . '/frontend-gallery-slider-for-advanced-custom-field/frontend-gallery-slider.php';
    
    // If free plugin exist
    if( file_exists($dir) ) {
        
        global $pagenow;
        
        if ( $pagenow == 'plugins.php' && current_user_can( 'install_plugins' ) ) {
            echo '<div id="message" class="updated notice is-dismissible"><p><strong>Thank you for activating Frontend Gallery Slider For Advanced Custom Field Pro</strong>.<br /> It looks like you had FREE version <strong>(<em>Frontend Gallery Slider For Advanced Custom Field</em>)</strong> of this plugin activated. To avoid conflicts the extra version has been deactivated and we recommend you delete it. </p></div>';
        }
    }
}

// Action to display notice
add_action( 'admin_notices', 'front_gallery_admin_notice');


/***** Updater Code Starts *****/
define( 'EDD_FGSP_PRO_STORE_URL', 'https://www.wponlinesupport.com' );
define( 'EDD_FGSP_PRO_ITEM_NAME', 'Frontend Gallery Slider For Advanced Custom Field Pro' );

// Plugin Updator Class 
if( !class_exists( 'EDD_SL_Plugin_Updater' ) ) {    
    include( dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php' );
}

/**
 * Updater Function
 * 
 * @package Frontend Gallery Slider For Advanced Custom Field Pro
 * @since 1.0.0
 */
function fgsp_pro_plugin_updater() {
    
    $license_key = trim( get_option( 'fgsp_pro_plugin_license_key' ) );

    $edd_updater = new EDD_SL_Plugin_Updater( EDD_FGSP_PRO_STORE_URL, __FILE__, array(
                'version'   => FGSP_PRO_VERSION,        // current version number
                'license'   => $license_key,            // license key (used get_option above to retrieve from DB)
                'item_name' => EDD_FGSP_PRO_ITEM_NAME,  // name of this plugin
                'author'    => 'WP Online Support'      // author of this plugin
            )
    );
}
add_action( 'admin_init', 'fgsp_pro_plugin_updater', 0 );
include( dirname( __FILE__ ) . '/fgsp-plugin-updater.php');
/***** Updater Code Ends *****/

/**
 * Load the plugin after the main plugin is loaded.
 * 
 * @package Frontend Gallery Slider For Advanced Custom Field Pro
 * @since 1.0.0
 */
function fgsp_pro_load_plugin() {

    // Check main plugin is active or not
    if( class_exists('acf') ) {
        
        /**
         * Load Text Domain
         * This gets the plugin ready for translation
         * 
         * @package Frontend Gallery Slider For Advanced Custom Field Pro
         * @since 1.0.0
         */
        global $wp_version;

        // Set filter for plugin's languages directory
        $fgsp_pro_lang_dir = dirname( plugin_basename( __FILE__ ) ) . '/languages/';
        $fgsp_pro_lang_dir = apply_filters( 'fgsp_pro_languages_directory', $fgsp_pro_lang_dir );

        // Traditional WordPress plugin locale filter.
        $get_locale = get_locale();

        if ( $wp_version >= 4.7 ) {
            $get_locale = get_user_locale();
        }

        // Traditional WordPress plugin locale filter
        $locale = apply_filters( 'plugin_locale',  $get_locale, 'frontend-gallery-slider-for-advanced-custom-field' );
        $mofile = sprintf( '%1$s-%2$s.mo', 'frontend-gallery-slider-for-advanced-custom-field', $locale );

        // Setup paths to current locale file
        $mofile_global  = WP_LANG_DIR . '/plugins/' . basename( FGSP_PRO_VERSION_DIR ) . '/' . $mofile;

        if ( file_exists( $mofile_global ) ) { // Look in global /wp-content/languages/plugin-name folder
            load_textdomain( 'frontend-gallery-slider-for-advanced-custom-field', $mofile_global );
        } else { // Load the default language files
            load_plugin_textdomain( 'frontend-gallery-slider-for-advanced-custom-field', false, $fgsp_pro_lang_dir );
        }

        /**
         * Deactivation Hook
         * 
         * Register plugin deactivation hook.
         * 
         * @package Frontend Gallery Slider For Advanced Custom Field Pro
         * @since 1.0.0
         */
        register_deactivation_hook( __FILE__, 'fgsp_pro_uninstall');

        /**
         * Plugin Setup (On Deactivation)
         * 
         * Delete  plugin options.
         * 
         * @package Frontend Gallery Slider For Advanced Custom Field Pro
         * @since 1.0.0
         */
        function fgsp_pro_uninstall() {
            // Uninstall functionality
        }

        // Script File
        require_once( FGSP_PRO_VERSION_DIR . '/includes/class-fgsp-pro-script.php' );

        // Admin Class File
        require_once( FGSP_PRO_VERSION_DIR . '/includes/admin/class-wp-fgsp-pro-admin.php' );

        // Shortcode File
        require_once( FGSP_PRO_VERSION_DIR . '/includes/shortcode/fgsp-pro-frontend-gallery-slider.php' );
        require_once( FGSP_PRO_VERSION_DIR . '/includes/shortcode/fgsp-pro-frontend-gallery-carousel.php' );
        require_once( FGSP_PRO_VERSION_DIR . '/includes/shortcode/fgsp-pro-frontend-gallery-variable.php' );
    }
}

// Action to load plugin after the main plugin is loaded
add_action('plugins_loaded', 'fgsp_pro_load_plugin', 15);
<?php
/**
 * Admin Class
 *
 * Handles the Admin side functionality of plugin
 *
 * @package Frontend Gallery Slider For Advanced Custom Field Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Wp_Fgsp_Pro_Admin {

	function __construct() {

		// Action to register plugin settings
		add_action ( 'admin_init', array($this, 'wp_fgsp_pro_register_settings') );

		// Action to register admin menu
		add_action( 'admin_menu', array($this, 'wp_fgsp_pro_register_menu'), 105 );

		// Filter to add plugin links
		add_filter( 'plugin_row_meta', array( $this, 'wp_fgsp_pro_plugin_row_meta' ), 10, 2);
	}

	/**
	 * Function register settings
	 * 
	 * @package Frontend Gallery Slider For Advanced Custom Field Pro
	 * @since 1.0.0
	 */

	function wp_fgsp_pro_register_settings() {
		register_setting( 'wp_fgsp_pro_plugin_options', 'wp_fgsp_pro_options', array($this, 'wp_fgsp_pro_validate_options') );
	}
	
	/**
	 * Validate Settings Options
	 * 
	 * @package Frontend Gallery Slider For Advanced Custom Field Pro
	 * @since 1.0.0
	 */

	function wp_fgsp_pro_validate_options( $input ) {

		$input['custom_css'] = isset($input['custom_css']) 	? wp_fgsp_pro_slashes_deep($input['custom_css'], true) 	: '';

		return $input;
	}

	/**
	 * Function to register admin menus
	 * 
	 * @package Frontend Gallery Slider For Advanced Custom Field Pro
	 * @since 1.0.0
	 */
 
	function wp_fgsp_pro_register_menu() {
 		add_submenu_page( 'edit.php?post_type='.FGSP_PRO_POST_TYPE, __('Custom CSS for Frontend Gallery Pro', 'frontend-gallery-slider-for-advanced-custom-field'),__('Custom CSS - Frontend Gallery Pro','frontend-gallery-slider-for-advanced-custom-field'), 'manage_options','wp-fgsp-pro-settings',array($this, 'wp_fgsp_pro_settings_page' ));
 	}

	/**
	 * Function to handle the setting page html
	 * 
	 * @package Frontend Gallery Slider For Advanced Custom Field Pro
	 * @since 1.0.0
	 */
	function wp_fgsp_pro_settings_page() {
		include_once( FGSP_PRO_VERSION_DIR . '/includes/admin/settings/wp-fgsp-settings.php' );
	}

	/**
	 * Function to unique number value
	 * 
	 * @package Frontend Gallery Slider For Advanced Custom Field Pro
	 * @since 1.0.0
	 */
	function wp_fgsp_pro_plugin_row_meta( $links, $file ) {
		
		if ( $file == FGSP_PRO_PLUGIN_BASENAME ) {
			
			$row_meta = array(
				'docs'    => '<a href="' . esc_url('https://www.wponlinesupport.com/pro-plugin-document/document-frontend-gallery-slider-advanced-custom-field-pro/') . '" title="' . esc_attr( __( 'View Documentation', 'frontend-gallery-slider-for-advanced-custom-field' ) ) . '" target="_blank">' . __( 'Docs', 'frontend-gallery-slider-for-advanced-custom-field' ) . '</a>',
				'support' => '<a href="' . esc_url('https://www.wponlinesupport.com/welcome-wp-online-support-forum/') . '" title="' . esc_attr( __( 'Visit Customer Support Forum', 'frontend-gallery-slider-for-advanced-custom-field' ) ) . '" target="_blank">' . __( 'Support', 'frontend-gallery-slider-for-advanced-custom-field' ) . '</a>',
			);
			return array_merge( $links, $row_meta );
		}
		return (array) $links;
	}
}

$wp_fgsp_pro_admin = new Wp_Fgsp_Pro_Admin();
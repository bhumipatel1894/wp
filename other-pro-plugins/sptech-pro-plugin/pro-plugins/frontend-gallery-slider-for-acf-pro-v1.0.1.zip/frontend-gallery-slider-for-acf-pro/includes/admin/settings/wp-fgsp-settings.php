<?php
/**
 * Settings Page
 *
 * @package Frontend Gallery Slider For Advanced Custom Field Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;
?>

<div class="wrap wp-fgsp-settings">
	
	<h2><?php _e( 'Frontend Gallery Slider For ACF Pro', 'frontend-gallery-slider-for-advanced-custom-field' ); ?></h2><br/>
	
	<?php
	// Success message
	if( isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true' ) {
		echo '<div id="message" class="updated notice notice-success is-dismissible">
				<p><strong>'.__("Your changes saved successfully.", "frontend-gallery-slider-for-advanced-custom-field").'</strong></p>
			  </div>';
	}
	?>
	
	<form action="options.php" method="POST" id="wp-fgsp-settings-form" class="wp-fgsp-settings-form">

		<?php  	
			settings_fields( 'wp_fgsp_pro_plugin_options' );
	    	global $wp_fgsp_pro_options;
		?>

		<!-- Custom CSS Settings Starts -->
		<div id="wp-fgsp-custom-css-sett" class="post-box-container wp-fgsp-custom-css-sett">
			<div class="metabox-holder">
				<div class="meta-box-sortables ui-sortable">
					<div id="wp-fgsp-custom-css-postbox" class="postbox">

						<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

							<!-- Settings box title -->
							<h3 class="hndle">
								<span><?php _e( 'Custom CSS Settings', 'frontend-gallery-slider-for-advanced-custom-field' ); ?></span>
							</h3>
							
							<div class="inside">
								<table class="form-table wp-fgsp-custom-css-tbl">
									<tbody>
										<tr>
											<th scope="row">
												<label for="wp-fgsp-custom-css"><?php _e('Custom CSS', 'frontend-gallery-slider-for-advanced-custom-field'); ?>:</label>
											</th>
											<td>
												<textarea name="wp_fgsp_pro_options[custom_css]" class="large-text wp-fgsp-custom-css" id="wp-fgsp-custom-css" rows="15"><?php echo wp_fgsp_pro_esc_attr(wp_fgsp_pro_get_option('custom_css')); ?></textarea><br/>
												<span class="description"><?php _e('Enter custom CSS to override plugin CSS.', 'frontend-gallery-slider-for-advanced-custom-field'); ?></span>
											</td>
										</tr>
										<tr>
											<td colspan="2" valign="top" scope="row">
												<input type="submit" id="wp-fgsp-settings-submit" name="wp-fgsp-settings-submit" class="button button-primary right" value="<?php _e('Save Changes','frontend-gallery-slider-for-advanced-custom-field'); ?>" />
											</td>
										</tr>
									</tbody>
								</table>
							</div><!-- .inside -->
					</div><!-- #wp-fgsp-custom-css-postbox -->
				</div><!-- .meta-box-sortables ui-sortable -->
			</div><!-- .metabox-holder -->
		</div><!-- #wp-fgsp-custom-css-sett -->
		<!-- Custom CSS Settings Ends -->
		
	</form><!-- end .wp-fgsp-settings-form -->
	
</div><!-- end .wp-fgsp-settings -->
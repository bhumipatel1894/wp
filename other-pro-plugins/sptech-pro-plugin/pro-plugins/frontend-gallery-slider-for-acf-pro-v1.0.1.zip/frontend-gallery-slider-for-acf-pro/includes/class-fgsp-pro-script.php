<?php
/**
 * Script Class
 *
 * Handles the script and style functionality of plugin
 *
 * @package Frontend Gallery Slider For Advanced Custom Field Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class WP_Fgsp_pro_Script {
	
	function __construct() {

		// Action to add style at front side
		add_action( 'wp_enqueue_scripts', array($this, 'wp_fgsp_pro_front_style') );
		
		// Action to add script at front side
		add_action( 'wp_enqueue_scripts', array($this, 'wp_fgsp_pro_front_script') );

		// Action to add custom css in head
		add_action( 'wp_head', array($this, 'front_gallery_custom_css'), 20 );
	}

	/**
	 * Function to add style at front side
	 * 
	 * @package Frontend Gallery Slider For Advanced Custom Field Pro
	 * @since 1.0.0
	 */
	function wp_fgsp_pro_front_style() {

		// Registring and enqueing magnific css
		if( !wp_style_is( 'wpos-magnific-style', 'registered' ) ) {
			wp_register_style( 'wpos-magnific-style', FGSP_PRO_VERSION_URL.'assets/css/magnific-popup.css', array(), FGSP_PRO_VERSION );
			wp_enqueue_style( 'wpos-magnific-style');
		}

		// Registring and enqueing slick css
		if( !wp_style_is( 'wpos-slick-style', 'registered' ) ) {
			wp_register_style( 'wpos-slick-style', FGSP_PRO_VERSION_URL.'assets/css/slick.css', array(), FGSP_PRO_VERSION );
			wp_enqueue_style( 'wpos-slick-style');
		}
		
		// Registring and enqueing public css
		wp_register_style( 'wp-fgsp-public-css', FGSP_PRO_VERSION_URL.'assets/css/wp-fgsp-pro-public.css', null, FGSP_PRO_VERSION );
		wp_enqueue_style( 'wp-fgsp-public-css' );
	}
	
	/**
	 * Function to add script at front side
	 * 
	 * @package Frontend Gallery Slider For Advanced Custom Field Pro
	 * @since 1.0.0
	 */
	function wp_fgsp_pro_front_script() {

		// Registring magnific popup script
		if( !wp_script_is( 'wpos-magnific-script', 'registered' ) ) {
			wp_register_script( 'wpos-magnific-script', FGSP_PRO_VERSION_URL.'assets/js/jquery.magnific-popup.min.js', array('jquery'), FGSP_PRO_VERSION, true );
		}
		
		// Registring slick slider script
		if( !wp_script_is( 'wpos-slick-jquery', 'registered' ) ) {
			wp_register_script( 'wpos-slick-jquery', FGSP_PRO_VERSION_URL.'assets/js/slick.min.js', array('jquery'), FGSP_PRO_VERSION, true );
		}

		// Registring public script
		wp_register_script( 'wp-fgsp-public-js', FGSP_PRO_VERSION_URL.'assets/js/wp-fgsp-pro-public.js', array('jquery'), FGSP_PRO_VERSION, true );
		wp_localize_script( 'wp-fgsp-public-js', 'WpFgsp', array(
															'is_mobile' 		=>	(wp_is_mobile()) 	? 1 : 0,
															'is_rtl' 			=>	(is_rtl()) 			? 1 : 0,
														));
	}

	/**
	 * Add custom css to head
	 * 
	 * @package Frontend Gallery Slider For Advanced Custom Field Pro
	 * @since 1.0.0
	 */
	function front_gallery_custom_css() {

		$custom_css = wp_fgsp_pro_get_option('custom_css');

		if( !empty($custom_css) ) {
			$css  = '<style type="text/css">' . "\n";
			$css .= $custom_css;
			$css .= "\n" . '</style>' . "\n";

			echo $css;
		}
	}
}

$wp_fgsp_pro_script = new WP_Fgsp_pro_Script();
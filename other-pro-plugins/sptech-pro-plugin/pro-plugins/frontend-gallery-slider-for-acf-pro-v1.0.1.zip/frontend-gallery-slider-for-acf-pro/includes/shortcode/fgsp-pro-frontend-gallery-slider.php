<?php
/**
 * 'acf_gallery_slider' Shortcode
 * 
 * @package Frontend Gallery Slider For Advanced Custom Field Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

function fgsp_gallery_slider($atts, $content) {

	extract(shortcode_atts(array(
		'acf_field' 		=> '',
		'slide_to_show' 	=> '1',
		'slide_to_scroll' 	=> '1',
		'design'			=> 'design-1',
		'autoplay' 			=> 'true',
		'autoplay_speed' 	=> '3000',
		'speed' 			=> '300',
		'arrows' 			=> 'true',
		'dots' 				=> 'true',
		'show_caption' 		=> 'true',
		'show_title' 		=> 'true',
		'show_description' 	=> 'true',
		'slider_height'		=> '',
		'loop'				=> 'true',
		'navigation'		=> 'false',
		'nav_slide_column'	=> 5,
		'rtl'				=> false,
	), $atts));

	// Taking some globals
	global $post;

	$shortcode_designs 		= wp_fgsp_pro_slider_designs();
	$acf_field 				= !empty($acf_field) 				? trim($acf_field) 	: '';
	$show_title 			= ($show_title == 'false') 			? 'false' 			: 'true';	
	$show_description		= ($show_description == 'false') 	? 'false' 			: 'true';	
	$autoplay 				= ($autoplay == 'false') 			? 'false' 			: 'true';
	$autoplay_speed 		= !empty($autoplay_speed) 			? $autoplay_speed 	: 3000;
	$speed 					= !empty($speed) 					? $speed 			: 300;	
	$arrows 				= ($arrows == 'false') 				? 'false' 			: 'true';
	$dots 					= ($dots == 'false') 				? 'false' 			: 'true';
	$show_caption 			= ($show_caption == 'false') 		? 'false' 			: 'true';
	$loop 					= ($loop == 'false') 				? 'false' 			: 'true';
	$navigation 			= ($navigation == 'true') 			? 'true' 			: 'false';
	$nav_slide_column 		= !empty($nav_slide_column) 		? $nav_slide_column : 5;
	$slider_height_css 		= (!empty($slider_height))			? "style='height:{$slider_height}px;'" : '';
	$design 				= ($design && (array_key_exists(trim($design), $shortcode_designs))) ? trim($design) 	: 'design-1';

	// If field is not passed then return simply
	if( $acf_field == '' ) {
		return $content;
	}

	// Shortcode file
	$gallery_path 	= FGSP_PRO_VERSION_DIR . '/templates/' . $design . '.php';
	$design_file 	= (file_exists($gallery_path)) ? $gallery_path : '';

	// For RTL
	if( empty($rtl) && is_rtl() ) {
		$rtl = 'true';
	} elseif ( $rtl == 'true' ) {
		$rtl = 'true';
	} else {
		$rtl = 'false';
	}

	// Enqueue required script
	wp_enqueue_script( 'wpos-magnific-script' );
	wp_enqueue_script( 'wpos-slick-jquery' );
	wp_enqueue_script( 'wp-fgsp-public-js' );
	
	// Slider configuration
	$slider_conf = compact('slide_to_show', 'slide_to_scroll', 'autoplay', 'autoplay_speed', 'speed', 'arrows', 'dots', 'loop', 'nav_slide_column', 'rtl');

	// Taking some variables
	$count				= 1;
	$slider_as_nav_for 	= '';
	$unique 			= wp_fgsp_pro_get_unique();
	$slider_as_nav_for  = ($navigation == 'true') ? "data-slider-nav-for='fgsp-slider-nav-{$unique}'" : '';
	
	// Getting gallery images
	$images = get_field($acf_field);

	ob_start();

	if( $images ): ?>

		<div class="fgsp-slider-wrap fgsp-row-clearfix">		
			<div id="fgsp-slider-<?php echo $unique; ?>" class="fgsp-slider fgsp-slider-popup <?php echo 'fgsp-'.$design; ?>" <?php echo $slider_as_nav_for; ?>>		
				<div class="fgsp-gallery-slider fgsp-common-slider">

					<?php
					// If desing file is there
					if($design_file) {
						foreach( $images as $image ) {
							
							$gallery_img_src		= $image['url'];
							$gallery_title			= $image['title'];
							$gallery_description	= $image['description'];
							$gallery_alt			= $image['alt'];
							$gallery_caption		= $image['caption'];

							// Design file
							include($design_file);

							$count++;
						}
					} ?>
				</div>
				<div class="fgsp-slider-conf"><?php echo htmlspecialchars(json_encode($slider_conf)); ?></div>
			</div>

			<?php
			// For Navigation design 
			if( $navigation == 'true' ) { ?>
			
				<div class="fgsp-slider-nav-<?php echo $unique; ?> fgsp-slider-nav <?php echo $design; ?>"><?php
					
					foreach( $images as $image ): 
						$slider_nav_img = $image['url'];
			?>

					<div class="slick-image-nav"><?php
						if( $slider_nav_img ) { ?>
							<img class="fgsp-slider-nav-img" src="<?php echo $slider_nav_img; ?>" alt="<?php _e('Slider Nav Image', 'frontend-gallery-slider-for-advanced-custom-field'); ?>" /><?php
						} ?>
					</div><?php

					endforeach; ?>
				</div>
			<?php } ?>
		</div>
<?php
	endif;

	$content .= ob_get_clean();
	return $content;
}

// 'acf_gallery_slider' Shortcode
add_shortcode( 'acf_gallery_slider', 'fgsp_gallery_slider' );
=== Frontend Gallery Slider For ACF PRO ===
Contributors: wponlinesupport, anoopranawat
Tags: wponlinesupport, frontend gallery slider, frontend gallery Carousel,  slider, acf frontend gallery slider, acf frontend gallery Carousel, acf gallery, acf
Requires at least: 3.1
Tested up to: 4.7.2
Author URI: http://wponlinesupport.com
Stable tag: trunk

Display Advanced Custom Field Gallery in slider, carousel, variable width on frontend of your website with shorcode.

== Description ==
A very simple plugin to display Advanced Custom Field Gallery on frontend of your website in a slider, carousel and variable width view with the help of shorcode. The gallery field provides a simple and intuitive interface for managing a collection of images.


= This plugin contain Three shortcode: =
1) Slider View
<code>[acf_gallery_slider]</code>

2) Carousel View
<code>[acf_gallery_carousel]</code>

3) Variable Width View
<code>[acf_gallery_variable]</code>


= Following are ACF Gallery Slider Parameters: =
<code>[acf_gallery_slider]</code>
* **ACF Field Name :** [acf_gallery_slider acf_field="gallery"] (Paste the ACF Gallery field name.)
* **Slides Column :** [acf_gallery_slider slide_to_show="2"] (number of slider show at a time.)
* **No of Slide to scroll :** [acf_gallery_slider slide_to_scroll="1"] (number of slide scroll at a time.)
* **Design :** [acf_gallery_slider design="design-10"] (Select the designs for ACF Gallery Slider.) 
* **Autoplay :** [acf_gallery_slider autoplay="true"] (Autoplay the slider. By Default value is "true". Options are "true" OR "false" ).
* **Autoplay Speed : ** [acf_gallery_slider autoplay_speed="3000"] (Slider autoplay speed. Default value is "3000".)
* **Speed : ** [acf_gallery_slider speed="300"] (particular slider speed.)
* **Arrows : ** [acf_gallery_slider arrows="true"] (Display the arrows of the slider. By Default Value is "true". Options are "true" OR "false").
* **Display Caption :** [acf_gallery_slider show_caption="true" ] (Display ACF Gallery Slider Caption OR not. By default value is "True". Options are "ture OR false").
* **Display Title :** [acf_gallery_slider show_title="true" ] (Display ACF Gallery Slider Title name OR not. By default value is "True". Options are "ture OR false").
* **Display Description :** [acf_gallery_slider show_description="false"] (Show ACF Gallery Slider image Description. By default value is "false". Values are "true" and "false").
* **Slider Height :** [acf_gallery_slider slider_height="500"] (Control ACF Gallery Slider image height).
* **Loop :** [acf_gallery_slider loop="true"] (Slider in continues loop. By Default Value is True. Options are 'true' OR 'false').


<code>[acf_gallery_carousel]</code>
* **ACF Field Name :** [acf_gallery_carousel acf_field="gallery"] (Paste the ACF Gallery Field Name).
* **Slides Column :** [acf_gallery_carousel slide_to_show="2"] (number of slider show at a time).
* **No of Slide to scroll :** [acf_gallery_carousel slide_to_scroll="1"] (number of slider scroll at a time).
* **Design :** [acf_gallery_carousel design="design-10"] (Select the designs for ACF Gallery Slider.) 
* **Autoplay :** [acf_gallery_carousel autoplay="true"] (Autoplay the slider. By Default value is "true". Options are "true" OR "false" ).
* **Autoplay Speed : ** [acf_gallery_carousel autoplay_speed="3000"] (Slider autoplay speed. Default value is "3000".)
* **Speed : ** [acf_gallery_carousel speed="300"] (particular slider speed.)
* **Arrows : ** [acf_gallery_carousel arrows="true"] (Display the arrows of the slider. By Default Value is "true". Options are "true" OR "false").
* **Display Caption :** [acf_gallery_carousel show_caption="true" ] (Display ACF Gallery Slider Caption OR not. By default value is "True". Options are "ture OR false").
* **Display Title :** [acf_gallery_carousel show_title="true" ] (Display ACF Gallery Slider Title name OR not. By default value is "True". Options are "ture OR false").
* **Display Description :** [acf_gallery_carousel show_description="false"] (Show ACF Gallery Slider image Description. By default value is "false". Values are "true" and "false").
* **Slider Height :** [acf_gallery_carousel slider_height="500"] (Control ACF Gallery Slider image height).
* **Center Mode Effect :** [acf_gallery_carousel centermode="false"] ()
* **Loop :** [acf_gallery_carousel loop="true"] (Slider in continues loop. By Default Value is True. Options are 'true' OR 'false').


<code>[acf_gallery_variable]</code>
* **ACF Field Name :** [acf_gallery_variable acf_field="gallery"] (Paste the ACF Gallery Field Name).
* **Slides Column :** [acf_gallery_variable slide_to_show="2"] (number of slider show at a time).
* **No of Slide to scroll :** [acf_gallery_variable slide_to_scroll="1"] (number of slider scroll at a time).
* **Design :** [acf_gallery_variable design="design-10"] (Select the designs for ACF Gallery Slider.) 
* **Autoplay :** [acf_gallery_variable autoplay="true"] (Autoplay the slider. By Default value is "true". Options are "true" OR "false" ).
* **Autoplay Speed : ** [acf_gallery_variable autoplay_speed="3000"] (Slider autoplay speed. Default value is "3000".)
* **Speed : ** [acf_gallery_variable speed="300"] (Control slider speed.)
* **Arrows : ** [acf_gallery_variable arrows="true"] (Display the arrows of the slider. By Default Value is "true". Options are "true" OR "false").
* **Display Caption :** [acf_gallery_variable show_caption="true" ] (Display ACF Gallery Slider Caption OR not. By default value is "True". Options are "ture OR false").
* **Display Title :** [acf_gallery_variable show_title="true" ] (Display ACF Gallery Slider Title name OR not. By default value is "True". Options are "ture OR false").
* **Display Description :** [acf_gallery_variable show_description="false"] (Show ACF Gallery Slider image Description. By default value is "false". Values are "true" and "false").
* **Slider Height :** [acf_gallery_variable slider_height="500"] (Control ACF Gallery Slider image height).
* **Loop :** [acf_gallery_variable loop="true"] (Slider in continues loop. By Default Value is True. Options are 'true' OR 'false').


== Installation ==

1. Upload the 'frontend-gallery-slider-for-advanced-custom-field-pro' folder to the '/wp-content/plugins/' directory.
2. Activate the Frontend Gallery Slider For Advanced Custom Field Pro plugin through the 'Plugins' menu in WordPress.
3. Add multiple images to your page and display them as gallery.
4. Create a page with the any name and paste this short code  <code> [acf_gallery_slider], [acf_gallery_carousel] and [acf_gallery_variable] </code>.

== Changelog ==

= 1.0.1 (08, Feb 2016) =
* [*] Updated plugin translation code. Now user can put plugin languages file in WordPress 'language' folder so plugin language file will not be loss while plugin update.
* [*] Resolved magnific popup total image count issue.
* [*] Updated magnific popup CSS.
* [*] Resolved invalid license page issue with ACF Pro.
* [*] Taken better care when 'acf_field' shortcode parameter is not passed.
* [*] Taken better care of escaping in image title and alt tag.
* [*] Taken better care of 'Center Mode' in 'acf_gallery_carousel' shortcode. Now design will not be disturbed with even number of slide.
* [*] Code optimization.

= 1.0 (08, Nov 2016) =
* Initial release.

== Upgrade Notice ==

= 1.0.1 (08, Feb 2016) =
* [*] Updated plugin translation code. Now user can put plugin languages file in WordPress 'language' folder so plugin language file will not be loss while plugin update.
* [*] Resolved magnific popup total image count issue.
* [*] Updated magnific popup CSS.
* [*] Resolved invalid license page issue with ACF Pro.
* [*] Taken better care when 'acf_field' shortcode parameter is not passed.
* [*] Taken better care of escaping in image title and alt tag.
* [*] Taken better care of 'Center Mode' in 'acf_gallery_carousel' shortcode. Now design will not be disturbed with even number of slide.
* [*] Code optimization.

= 1.0 (08, Nov 2016) =
* Initial release.
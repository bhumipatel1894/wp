<div class="fgsp-slide" data-item-index="<?php echo $count; ?>">
	<div class="fgsp-img-wrap" <?php echo $slider_height_css; ?>>
		<a class="fgsp-img-link" href="<?php echo $gallery_img_src; ?>"></a>
		<img class="fgsp-img" src="<?php echo $gallery_img_src ?>" title="<?php echo wp_fgsp_pro_esc_attr($gallery_title); ?>" alt="<?php echo wp_fgsp_pro_esc_attr($gallery_alt); ?>" />
	</div>

	<?php if($show_title == 'true' || $show_caption == 'true') { ?>
		<div class="fgsp-gallery-container">
			<div class="fgsp-gallery-container-wrap">
			<?php if($show_title == 'true') { ?>
				<div class="fgsp-image-title"><?php echo $gallery_title; ?></div>
			<?php }
	
		 	if($show_caption == 'true' && $gallery_caption != '') { ?>
				<div class="fgsp-image-caption"><?php echo $gallery_caption; ?></div>
		 	<?php }
	
		 	if($show_description == 'true' && $gallery_description != '') { ?>
	
				<div class="fgsp-image-desc">
					<?php 
						echo $gallery_description;
					?>
				</div>
		 	<?php } ?>
		 	</div>
		</div>
	<?php } ?>
</div>
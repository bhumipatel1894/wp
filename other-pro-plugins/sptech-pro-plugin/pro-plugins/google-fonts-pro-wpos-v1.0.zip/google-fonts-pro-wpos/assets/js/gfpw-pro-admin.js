jQuery( document ).ready(function( $ ) {

	$('.gfpw-gf-font').select2();

	// Add another font
	$(document).on('click', '.gfpw-add-gf-font', function(){
		
		$(this).closest('.gfpw-gf-font-row').find('.gfpw-gf-font').select2('destroy');
		
		var cls_ele = $(this).closest('.gfpw-gf-font-wrp');
		var cln_ele	= $(this).closest('.gfpw-gf-font-row').clone();
		
		cln_ele.find('.gfpw-gf-font').val('');
		cln_ele.find('.gfpw-gf-font-family i').text('N/A');
		
		cls_ele.append(cln_ele);
		
		cls_ele.find('.gfpw-gf-font').select2();
	});

	// Remove font
	$(document).on('click', '.gfpw-remove-gf-font', function(){
		var cls_ele 	= $(this).closest('.gfpw-gf-font-row');
		var total_ele 	= $('.gfpw-gf-font-wrp .gfpw-gf-font-row').length;

		if( total_ele > 1 ) {
			cls_ele.remove();
		} else {
			alert( GfpwAdmin.no_remove_msg );
		}

		gfpw_update_site_gf_font();
	});

	// On Change of fonts
	$(document).on('change', '.gfpw-gf-font', function() {
		
		var font_family = $(this).find('option:selected').closest('optgroup').attr('label');
		font_family 	= font_family ? font_family : 'N/A';

		$(this).closest('.gfpw-gf-font-row').find('.gfpw-gf-font-family i').text(font_family);

		gfpw_update_site_gf_font();
	});

	// Reset settings
    $( document ).on( 'click', '.gfpw-reset-sett', function() {
		
		var ans;
		ans = confirm(GfpwAdmin.reset_msg);

		if(ans) {
			return true;
		} else {
			return false;
		}
	});
});

function gfpw_update_site_gf_font() {

	var font_opts	= '';
	font_opts 		+= '<option value="">'+GfpwAdmin.select_opt+'</option>';

	// Taking site font
	jQuery('.gfpw-gf-font-wrp .gfpw-gf-font').each(function(index ) {
		var font_val	= jQuery(this).val();
		var font_name	= jQuery(this).find('option:selected').html();

		if( font_val && (font_opts.indexOf('option value="'+font_val+'"') < 0) ) {
			font_opts += '<option value="'+font_val+'">'+font_name+'</option>';
		}
	});

	// Updating site element font
	jQuery('.gfpw-font-ele-row .gfpw-site-ele-font').each(function(index) {
		var font_val = jQuery.trim( jQuery(this).val() );

		jQuery(this).html(font_opts); // Updating options

		// Remain selected value as it is
		if( font_val != '' && jQuery(this).find("option[value='"+font_val+"']").length > 0 ) {
			jQuery(this).val(font_val);
		} else {
			jQuery(this).val('');
		}
	});
}
<?php
/**
 * Plugin Name: Google Fonts Pro - WPOS
 * Plugin URI: https://www.wponlinesupport.com
 * Description: Easy to add google fonts to your site.
 * Author: WP Online Support
 * Text Domain: google-fonts-wpos
 * Domain Path: /languages/
 * Version: 1.0
 * Author URI: https://www.wponlinesupport.com
 * 
 * @package WordPress
 * @author WP Online Support
 */

/**
 * Basic plugin definitions
 * 
 * @package Google Fonts Pro - WPOS
 * @since 1.0.0
 */
if( !defined( 'GFPW_VERSION' ) ) {
    define( 'GFPW_VERSION', '1.0' ); // Version of plugin
}
if( !defined( 'GFPW_DIR' ) ) {
    define( 'GFPW_DIR', dirname( __FILE__ ) ); // Plugin dir
}
if( !defined( 'GFPW_URL' ) ) {
    define( 'GFPW_URL', plugin_dir_url( __FILE__ ) ); // Plugin url
}
if( !defined( 'GFPW_PLUGIN_BASENAME' ) ) {
    define( 'GFPW_PLUGIN_BASENAME', plugin_basename( __FILE__ ) ); // plugin base name
}

/**
 * Load Text Domain
 * This gets the plugin ready for translation
 * 
 * @package Google Fonts Pro - WPOS
 * @since 1.0.0
 */
function gfpw_load_textdomain() {
	load_plugin_textdomain( 'google-fonts-wpos', false, dirname( plugin_basename(__FILE__) ) . '/languages/' );
}
add_action('plugins_loaded', 'gfpw_load_textdomain');

/**
 * Activation Hook
 * 
 * Register plugin activation hook.
 * 
 * @package Google Fonts Pro - WPOS
 * @since 1.0.0
 */
register_activation_hook( __FILE__, 'gfpw_install' );

/**
 * Deactivation Hook
 * 
 * Register plugin deactivation hook.
 * 
 * @package Google Fonts Pro - WPOS
 * @since 1.0.0
 */
register_deactivation_hook( __FILE__, 'gfpw_uninstall');

/**
 * Plugin Setup (On Activation)
 * 
 * Does the initial setup,
 * stest default values for the plugin options.
 * 
 * @package Google Fonts Pro - WPOS
 * @since 1.0.0
 */
function gfpw_install() {

	// Get settings for the plugin
    $gfpw_pro_options = get_option( 'gfpw_pro_options' );
    
    if( empty( $gfpw_pro_options ) ) { // Check plugin version option
        
        // Set default settings
        gfpw_default_settings();
        
        // Update plugin version to option
        update_option( 'gfpw_plugin_version', '1.0' );
    }
}

/**
 * Plugin Setup (On Deactivation)
 * 
 * Delete  plugin options.
 * 
 * @package Google Fonts Pro - WPOS
 * @since 1.0.0
 */
function gfpw_uninstall() {
}

/***** Updater Code Starts *****/
define( 'EDD_GFPW_PRO_STORE_URL', 'https://www.wponlinesupport.com' );
define( 'EDD_GFPW_PRO_ITEM_NAME', 'Google Fonts Pro' );

// Plugin Updator Class 
if( !class_exists( 'EDD_SL_Plugin_Updater' ) ) {    
    include( dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php' );
}

/**
 * Updater Function
 * 
 * @package Countdown Timer Ultimate Pro
 * @since 1.0.0
 */
function gfpw_plugin_updater() {
    
    $license_key = trim( get_option( 'gfpw_plugin_license_key' ) );

    $edd_updater = new EDD_SL_Plugin_Updater( EDD_GFPW_PRO_STORE_URL, __FILE__, array(
                'version'   => GFPW_VERSION,       		// current version number
                'license'   => $license_key,            // license key (used get_option above to retrieve from DB)
                'item_name' => EDD_GFPW_PRO_ITEM_NAME,  // name of this plugin
                'author'    => 'WP Online Support'      // author of this plugin
            )
    );
}
add_action( 'admin_init', 'gfpw_plugin_updater', 0 );

include( dirname( __FILE__ ) . '/gfpw-plugin-updater.php' );
/***** Updater Code Ends *****/

// Taking some globals
global $gfpw_pro_options;

// Functions file
require_once( GFPW_DIR . '/includes/gfpw-functions.php' );
$gfpw_pro_options = gfpw_get_settings();

// Google fonts file
require_once( GFPW_DIR . '/includes/gfpw-google-fonts.php' );

// Script Class
require_once( GFPW_DIR . '/includes/class-gfpw-script.php' );

// Admin Class
require_once( GFPW_DIR . '/includes/admin/class-gfpw-admin.php' );

// Public Class
require_once( GFPW_DIR . '/includes/class-gfpw-public.php' );
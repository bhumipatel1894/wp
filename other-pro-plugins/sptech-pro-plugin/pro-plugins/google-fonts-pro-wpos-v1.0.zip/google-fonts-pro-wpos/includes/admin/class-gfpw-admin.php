<?php
/**
 * Admin Class
 *
 * Handles the Admin side functionality of plugin
 *
 * @package Google Fonts Pro - WPOS
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Gfpw_Admin {

	function __construct() {
		
		// Action to register admin menu
		add_action( 'admin_menu', array($this, 'gfpw_register_menu') );

		// Action to register plugin settings
		add_action ( 'admin_init', array($this, 'gfpw_register_settings') );

		// Filter to add plugin links
		add_filter( 'plugin_row_meta', array( $this, 'gfpw_plugin_row_meta' ), 10, 2 );
		add_filter( 'plugin_action_links_' . GFPW_PLUGIN_BASENAME, array( $this, 'gfpw_plugin_action_links' ) );
	}

	/**
	 * Function to register admin menus
	 * 
	 * @package Google Fonts Pro - WPOS
	 * @since 1.0.0
	 */
	function gfpw_register_menu() {
		add_menu_page( __('Settings', 'google-fonts-wpos'), __('Google Fonts Pro - WPOS', 'google-fonts-wpos'), 'manage_options', 'gfpw-settings', array($this, 'gfpw_settings_page'), 'dashicons-editor-spellcheck' );
	}

	/**
	 * Function to handle the setting page html
	 * 
	 * @package Google Fonts Pro - WPOS
	 * @since 1.0.0
	 */
	function gfpw_settings_page() {
		include_once( GFPW_DIR . '/includes/admin/settings/gfpw-settings.php' );
	}

	/**
	 * Function register setings
	 * 
	 * @package Google Fonts Pro - WPOS
	 * @since 1.0.0
	 */
	function gfpw_register_settings() {
		register_setting( 'gfpw_pro_plugin_options', 'gfpw_pro_options', array($this, 'gfpw_validate_options') );
	}
	
	/**
	 * Validate Settings Options
	 * 
	 * @package Google Fonts Pro - WPOS
	 * @since 1.0.0
	 */
	function gfpw_validate_options( $input ) {

		$input['gf_font'] 		= isset($input['gf_font']) 		? array_unique(gfpw_slashes_deep($input['gf_font'], true)) 	: '';
		$input['custom_css'] 	= isset($input['custom_css']) 	? gfpw_slashes_deep($input['custom_css'], true) 			: '';

		return $input;
	}

	/**
	 * Function to unique number value
	 * 
	 * @package Google Fonts Pro - WPOS
	 * @since 1.0.0
	 */
	function gfpw_plugin_row_meta( $links, $file ) {
		
		if ( $file == GFPW_PLUGIN_BASENAME ) {
			
			$row_meta = array(
				'docs'    => '<a href="' . esc_url('https://www.wponlinesupport.com/pro-plugin-document/document-google-fonts-pro/') . '" title="' . esc_attr( __( 'View Documentation', 'google-fonts-wpos' ) ) . '" target="_blank">' . __( 'Docs', 'google-fonts-wpos' ) . '</a>',
				'support' => '<a href="' . esc_url('https://www.wponlinesupport.com/welcome-wp-online-support-forum/') . '" title="' . esc_attr( __( 'Visit Customer Support Forum', 'google-fonts-wpos' ) ) . '" target="_blank">' . __( 'Support', 'google-fonts-wpos' ) . '</a>',
			);
			return array_merge( $links, $row_meta );
		}
		return (array) $links;
	}
	
	/**
	 * Function to add extra plugins link
	 * 
	 * @package Google Fonts Pro - WPOS
	 * @since 1.0.0
	 */
	function gfpw_plugin_action_links( $links ) {
		
		$license_url = add_query_arg( array( 'page' => 'gfpw-pro-license'), admin_url('admin.php') );
		
		$links['license'] = '<a href="' . esc_url($license_url) . '" title="' . esc_attr( __( 'Activate Plugin License', 'google-fonts-wpos' ) ) . '">' . __( 'License', 'google-fonts-wpos' ) . '</a>';
		
		return $links;
	}
}

$gfpw_admin = new Gfpw_Admin();
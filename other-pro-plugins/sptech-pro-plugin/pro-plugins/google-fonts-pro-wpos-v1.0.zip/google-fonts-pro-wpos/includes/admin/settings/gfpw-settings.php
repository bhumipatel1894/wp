<?php
/**
 * Settings Page
 *
 * @package Google Fonts Pro - WPOS
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;
?>
<div class="wrap gfpw-settings">
	
	<h2><?php _e( 'Google Fonts Pro Settings', 'google-fonts-wpos' ); ?></h2><br/>
	
	<?php
	// Success message
	if(isset($_POST['gfpw_reset_setts']) && !empty($_POST['gfpw_reset_setts'])) {
			
			gfpw_default_settings(); // Set default settings
			
			// Resett message
			echo '<div id="message" class="updated fade"><p><strong>' . __( 'All settings reset successfully.', 'google-fonts-wpos') . '</strong></p></div>';
			
	} elseif( isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true' ) {
		echo '<div id="message" class="updated notice notice-success is-dismissible">
				<p><strong>'.__("Your changes saved successfully.", "google-fonts-wpos").'</strong></p>
			  </div>';
	}
	?>
	
	<form action="" method="post">
		<div class="textright">
			<input type="submit" name="gfpw_reset_setts" value="<?php _e('Reset All Settings', 'google-fonts-wpos'); ?>" class="button button-primary gfpw-reset-sett" />
		</div>
	</form><!-- Reset settings form -->

	<form action="options.php" method="POST" id="gfpw-settings-form" class="gfpw-settings-form">
		
		<?php
		    settings_fields( 'gfpw_pro_plugin_options' );

		    global $gfpw_pro_options;
		    
			// Taking some variables
			$gfpf_google_fonts 	= gfpw_google_fonts('simplified');
			$font_elements		= gfpw_fonts_elements();
			$gf_site_fonts 		= gfpw_get_option( 'gf_font', array('0' => '') );
			$site_font_elements	= gfpw_get_option('font_element');
		?>
		
		<!-- General Settings Starts -->
		<div id="gfpw-general-sett" class="post-box-container gfpw-general-sett">
			<div class="metabox-holder">
				<div class="meta-box-sortables ui-sortable">
					<div id="general" class="postbox">

						<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

							<!-- Settings box title -->
							<h3 class="hndle">
								<span><?php _e( 'General Settings', 'google-fonts-wpos' ); ?></span>
							</h3>
							
							<div class="inside">
							
							<table class="form-table gfpw-general-sett-tbl">
								<tbody>
									<tr>
										<th scope="row">
											<label for="gfpw-gf-font"><?php _e('Google Fonts', 'google-fonts-wpos'); ?></label>
										</th>
										<td>
											<div class="gfpw-gf-font-wrp">
											<?php
											// Loop of selected stored fonts
											if( !empty($gf_site_fonts) ) {
												foreach ($gf_site_fonts as $gf_site_font_key => $gf_site_font_val) {

													$font_data 		= gfpw_get_font_data($gf_site_font_val);
													$font_family 	= !empty($font_data['font_family']) ? $font_data['font_family'] : __('N/A', 'google-fonts-wpos');
											?>

												<div class="gfpw-gf-font-row">
													
													<span class="gfpw-gf-font-family"><?php _e('Font Family', 'google-fonts-wpos') ?> - <i><?php echo $font_family; ?></i></span>

													<select name="gfpw_pro_options[gf_font][]" class="gfpw-select-box gfpw-gf-font">
														<option value=""><?php _e('-- Select Font --', 'google-fonts-wpos'); ?></option>
														<?php
														// Loop of google fonts
														if( !empty($gfpf_google_fonts) ) {
															foreach ($gfpf_google_fonts as $gf_key => $gf_val) {
														?>
														
														<optgroup label="<?php echo $gf_key; ?>">
															
															<?php 
															// Loop of fonts variants
															if( !empty($gf_val) ) {
																foreach ($gf_val as $variant_key => $variant_val) {					
															?>

															<option value="<?php echo $variant_key; ?>" <?php selected( $variant_key, $gf_site_font_val ); ?>><?php echo $gf_key.' - '.$variant_val; ?></option>

															<?php
																}
															} ?>

														</optgroup>

														<?php }
														}
														?>
													</select>
													<span class="gfpw-icon gfpw-add-gf-font-icon gfpw-add-gf-font" title="<?php _e('Add Font', 'google-fonts-wpos'); ?>"><i class="dashicons dashicons-plus-alt"></i></span>
													<span class="gfpw-icon gfpw-remove-gf-font-icon gfpw-remove-gf-font" title="<?php _e('Remove Font', 'google-fonts-wpos'); ?>"><i class="dashicons dashicons-dismiss"></i></span>
												</div><!-- end .gfpw-gf-font-row -->

											<?php
												}
											}
											?>
											</div><!-- end .gfpw-gf-font-wrp -->
											<span class="description"><?php _e('Select google fonts which you want to load on site.', 'google-fonts-wpos'); ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label for="gfpw-gf-font"><?php _e('Apply Google Fonts to Element', 'google-fonts-wpos'); ?></label>
										</th>
										<td>
										<?php
											if( !empty($font_elements) ){
												foreach ($font_elements as $ele_key => $ele_value) {
										?>
												<div class="gfpw-font-ele-row">
													<label for="gfpw-ele-<?php echo $ele_key; ?>" class="gfpw-ele"><?php echo $ele_value; ?></label>
													<select name="gfpw_pro_options[font_element][<?php echo $ele_key; ?>]" id="gfpw-ele-<?php echo $ele_key; ?>" class="gfpw-select-box gfpw-site-ele-font">
														<option value=""><?php _e('-- Select Font --', 'google-fonts-wpos'); ?></option>

														<?php
														// Loop of selected stored fonts
														if( !empty($gf_site_fonts) ) {
															foreach ($gf_site_fonts as $gf_site_font_key => $gf_site_font_val) {

																// If empty then return
																if( empty($gf_site_font_val) ) {
																	continue;
																}

																$font_data 		= gfpw_get_font_data($gf_site_font_val);
																$font_family 	= $font_data['font_family'];
																$font_name		= (!empty($font_family) && !empty($gfpf_google_fonts[$font_family][$gf_site_font_val])) ? $font_family.' - '.$gfpf_google_fonts[$font_family][$gf_site_font_val] : __('N/A', 'google-fonts-wpos');
																$ele_font		= isset($site_font_elements[$ele_key]) ? $site_font_elements[$ele_key] : '';
													?>
														
														<option value="<?php echo $gf_site_font_val; ?>" <?php selected( $ele_font, $gf_site_font_val ); ?>><?php echo $font_name; ?></option>

													<?php	} // End of foreach
														} // End of if
														?>
													</select>
												</div><!-- end .gfpw-font-ele-row -->
										<?php	}
											}
											?>
											<br/>
											<span class="description"><?php _e('Select google font for site element.', 'google-fonts-wpos'); ?></span>
										</td>
									</tr>
									<tr>
										<td colspan="2" valign="top" scope="row">
											<input type="submit" id="gfpw-settings-submit" name="gfpw-settings-submit" class="button button-primary right" value="<?php _e('Save Changes','google-fonts-wpos'); ?>" />
										</td>
									</tr>
								</tbody>
							 </table>

						</div><!-- .inside -->
					</div><!-- #general -->
				</div><!-- .meta-box-sortables ui-sortable -->
			</div><!-- .metabox-holder -->
		</div><!-- #gfpw-general-sett -->
		<!-- General Settings Ends -->

		
		<!-- Custom CSS Settings Starts -->
		<div id="gfpw-custom-css-sett" class="post-box-container gfpw-custom-css-sett">
			<div class="metabox-holder">
				<div class="meta-box-sortables ui-sortable">
					<div class="postbox">

						<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

							<!-- Settings box title -->
							<h3 class="hndle">
								<span><?php _e( 'Custom CSS Settings', 'google-fonts-wpos' ); ?></span>
							</h3>
							
							<div class="inside">
							
							<table class="form-table gfpw-custom-css-tbl">
								<tbody>
									<tr>
										<th scope="row">
											<label for="gfpw-custom-css"><?php _e('Custom CSS', 'google-fonts-wpos'); ?></label>
										</th>
										<td>
											<textarea name="gfpw_pro_options[custom_css]" class="large-text gfpw-custom-css" id="gfpw-custom-css" rows="15"><?php echo gfpw_esc_attr(gfpw_get_option('custom_css')); ?></textarea><br/>
											<span class="description"><?php _e('Enter custom CSS to override plugin CSS.', 'google-fonts-wpos'); ?></span>
										</td>
									</tr>
									<tr>
										<td colspan="2" valign="top" scope="row">
											<input type="submit" id="gfpw-settings-submit" name="gfpw-settings-submit" class="button button-primary right" value="<?php _e('Save Changes','google-fonts-wpos');?>" />
										</td>
									</tr>
								</tbody>
							 </table>

						</div><!-- .inside -->
					</div><!-- #gfpw-custom-css -->
				</div><!-- .meta-box-sortables ui-sortable -->
			</div><!-- .metabox-holder -->
		</div><!-- #gfpw-custom-css-sett -->
		<!-- Custom CSS Settings Ends -->
		
	</form><!-- end .gfpw-settings-form -->
	
</div><!-- end .gfpw-settings -->
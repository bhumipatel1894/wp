<?php
/**
 * Public Class
 *
 * Handles the Public side functionality of plugin
 *
 * @package Google Fonts Pro - WPOS
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Gfpw_Public {

	function __construct() {
		
		// Action to register admin menu
		add_filter( 'body_class', array($this, 'gfpw_add_body_class') );
	}

	/**
	 * Function to register admin menus
	 * 
	 * @package Google Fonts Pro - WPOS
	 * @since 1.0.0
	 */
	function gfpw_add_body_class( $classes ) {
		
		$classes[] = 'gfpw-fonts';
		
		return $classes;
	}
}

$gfpw_public = new Gfpw_Public();
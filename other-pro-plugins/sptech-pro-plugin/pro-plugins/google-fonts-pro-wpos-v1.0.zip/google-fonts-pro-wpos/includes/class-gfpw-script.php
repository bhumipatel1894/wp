<?php
/**
 * Script Class
 *
 * Handles the script and style functionality of plugin
 *
 * @package Google Fonts Pro - WPOS
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Gfpw_Script {
	
	function __construct() {

		// Action to add style in backend
		add_action( 'admin_enqueue_scripts', array($this, 'gfpw_admin_style') );
		
		// Action to add script at admin side
		add_action( 'admin_enqueue_scripts', array($this, 'gfpw_admin_script') );

		// Action to add script at admin side
		add_action( 'wp_enqueue_scripts', array($this, 'gfpw_front_style') );

		// Action to add custom CSS
		add_action( 'wp_head', array($this, 'gfpw_front_custom_style') );
	}

	/**
	 * Enqueue admin styles
	 * 
	 * @package Google Fonts Pro - WPOS
	 * @since 1.0.0
	 */
	function gfpw_admin_style( $hook ) {

		$pages_arr = array( 'toplevel_page_gfpw-settings' );
		
		// If page is plugin setting page then enqueue script
		if( in_array($hook, $pages_arr) ) {

			// Registring select 2 style
			wp_register_style( 'wpos-select2-style', GFPW_URL.'assets/css/select2.min.css', null, GFPW_VERSION );
			wp_enqueue_style( 'wpos-select2-style' );

			// Registring admin style
			wp_register_style( 'gfpw-pro-admin-style', GFPW_URL.'assets/css/gfpw-pro-admin.css', null, GFPW_VERSION );
			wp_enqueue_style( 'gfpw-pro-admin-style' );
		}
	}

	/**
	 * Enqueue admin styles
	 * 
	 * @package Google Fonts Pro - WPOS
	 * @since 1.0.0
	 */
	function gfpw_admin_script( $hook ) {

		$pages_arr = array( 'toplevel_page_gfpw-settings' );
		
		// If page is plugin setting page then enqueue script
		if( in_array($hook, $pages_arr) ) {
			
			// Registring select 2 script
			wp_register_script( 'wpos-select2-script', GFPW_URL.'assets/js/select2.min.js', array('jquery'), GFPW_VERSION, true );
			wp_enqueue_script( 'wpos-select2-script' );
			
			// Registring admin script
			wp_register_script( 'gfpw-pro-admin-script', GFPW_URL.'assets/js/gfpw-pro-admin.js', array('jquery'), GFPW_VERSION, true );
			wp_localize_script( 'gfpw-pro-admin-script', 'GfpwAdmin', array(
																	'no_remove_msg' => __('Sorry, You can not delete this', 'google-fonts-wpos'),
																	'select_opt' 	=> __('-- Select Font --', 'google-fonts-wpos'),
																	'reset_msg'		=> __('Click OK to reset all options. All settings will be lost!', 'google-fonts-wpos'),
																));
			wp_enqueue_script( 'gfpw-pro-admin-script' );
		}
	}

	/**
	 * Enqueue front scripts
	 * 
	 * @package Google Fonts Pro - WPOS
	 * @since 1.0.0
	 */
	function gfpw_front_style() {

		$gf_site_fonts = gfpw_get_option( 'gf_font' );

		if( !empty($gf_site_fonts) ) {
			
			$gf_fonts = implode('|', $gf_site_fonts);
			
			if( !empty($gf_fonts) ) {
				$gf_font_url 	= add_query_arg( array('family' => $gf_fonts), 'https://fonts.googleapis.com/css' );

				// Google Fonts URL
				wp_register_style( 'gfpw-pro-font-style', $gf_font_url, null, GFPW_VERSION );
				wp_enqueue_style( 'gfpw-pro-font-style' );
			}
		}
	}

	/**
	 * Enqueue front scripts
	 * 
	 * @package Google Fonts Pro - WPOS
	 * @since 1.0.0
	 */
	function gfpw_front_custom_style() {

		// Taking some variables
		$site_font_elements	= gfpw_get_option('font_element');

		if( !empty($site_font_elements) ) {

			$css = '<style type="text/css">' . "\n";

			foreach ($site_font_elements as $font_ele => $font_val) {
				if( !empty($font_ele) && !empty($font_val) ) {

					$font_data = gfpw_get_font_data($font_val);

					// For opening element (In some cses we need different)
					switch ($font_ele) {
						case 'body':
							$css_target = "body, body.gfpw-fonts{";
							break;

						case 'button':
							$css_target = "button,.gfpw-fonts button,input[type='button'],.gfpw-fonts input[type='button'],input[type='submit'],.gfpw-fonts input[type='submit']{";
							break;

						case 'input':
							$css_target = "input:not([type]), input[type='text'], input[type='date'], input[type='datetime'], input[type='datetime-local'], input[type='month'], input[type='week'], input[type='email'], input[type='number'], input[type='search'], input[type='tel'], input[type='time'], input[type='url'], input[type='color'], textarea{";
							break;
						
						default:
							$css_target = "{$font_ele},.gfpw-fonts {$font_ele}{";
							break;
					}
					$css .= apply_filters( 'gfpw_font_ele_css_target', $css_target, $font_ele );

					if( !empty($font_data['font_family']) ) {
						$css .= 'font-family:'.$font_data['font_family'].';';
					}
					if( !empty($font_data['font_weight']) ) {
						$css .= 'font-weight:'.$font_data['font_weight'].';';
					}
					$css .= apply_filters( 'gfpw_font_ele_css', '', $font_ele );
					$css .= '}';
				}
			}

			$css .= "\n" . '</style>' . "\n";
			echo $css;
		}

		// Custom CSS
		$custom_css = gfpw_get_option('custom_css');
		if( !empty($custom_css) ) {
			$css  = '<style type="text/css">' . "\n";
			$css .= $custom_css;
			$css .= "\n" . '</style>' . "\n";

			echo $css;
		}
	}
}

$Gfpw_Script = new Gfpw_Script();
<?php
/**
 * Plugin generic functions file
 *
 * @package Google Fonts Pro - WPOS
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Update default settings
 * 
 * @package Google Fonts Pro - WPOS
 * @since 1.0.0
 */
function gfpw_default_settings() {
    
    global $gfpw_pro_options;
    
    $gfpw_pro_options = array(
        'gf_font'       => array(),
        'font_element'  => array(),
        'custom_css'    => '',
    );
    
    $default_options = apply_filters('gfpw_options_default_values', $gfpw_pro_options );
    
    // Update default options
    update_option( 'gfpw_pro_options', $default_options );
    
    // Overwrite global variable when option is update
    $gfpw_pro_options = gfpw_get_settings();
}

/**
 * Get Settings From Option Page
 * 
 * Handles to return all settings value
 * 
 * @package Google Fonts Pro - WPOS
 * @since 1.0.0
 */
function gfpw_get_settings() {
  	
    $options    = get_option('gfpw_pro_options');
    $settings   = is_array($options)  ? $options : array();
    
    return $settings;
}

/**
 * Get an option
 * Looks to see if the specified setting exists, returns default if not
 * 
 * @package Google Fonts Pro - WPOS
 * @since 1.0.0
 */
function gfpw_get_option( $key = '', $default = false ) {
    global $gfpw_pro_options;

    $value = ! empty( $gfpw_pro_options[ $key ] ) ? $gfpw_pro_options[ $key ] : $default;
    $value = apply_filters( 'gfpw_get_option', $value, $key, $default );

    return apply_filters( 'gfpw_get_option_' . $key, $value, $key, $default );
}

/**
 * Escape Tags & Slashes
 *
 * Handles escapping the slashes and tags
 *
 * @package Google Fonts Pro - WPOS
 * @since 1.0.0
 */
function gfpw_esc_attr($data) {
	return esc_attr( stripslashes($data) );
}

/**
 * Strip Slashes From Array
 *
 * @package Google Fonts Pro - WPOS
 * @since 1.0.0
 */
function gfpw_slashes_deep($data = array(), $flag = false) {
  	
    if($flag != true) {
        $data = gfpw_nohtml_kses($data);
    }
    $data = stripslashes_deep($data);
    return $data;
}

/**
 * Strip Html Tags 
 * 
 * It will sanitize text input (strip html tags, and escape characters)
 * 
 * @package Google Fonts Pro - WPOS
 * @since 1.0.0
 */
function gfpw_nohtml_kses($data = array()) {
  	
	if ( is_array($data) ) {

	$data = array_map('gfpw_nohtml_kses', $data);

	} elseif ( is_string( $data ) ) {
		$data = trim( $data );
		$data = wp_filter_nohtml_kses($data);
	}

	return $data;
}

/**
 * Google Fonts Elements
 * 
 * @package Google Fonts Pro - WPOS
 * @since 1.0.0
 */
function gfpw_fonts_elements($data = array()) {
    $elements = array(
                            'body'          => __('Body Font', 'google-fonts-wpos'),
                            'h1'            => __('H1 Font', 'google-fonts-wpos'),
                            'h2'            => __('H2 Font', 'google-fonts-wpos'),
                            'h3'            => __('H3 Font', 'google-fonts-wpos'),
                            'h4'            => __('H4 Font', 'google-fonts-wpos'),
                            'h5'            => __('H5 Font', 'google-fonts-wpos'),
                            'h6'            => __('H6 Font', 'google-fonts-wpos'),
                            'p'             => __('P Font', 'google-fonts-wpos'),
                            'a'             => __('Hyperlink Font', 'google-fonts-wpos'),
                            'blockquote'    => __('Blockquote Font', 'google-fonts-wpos'),
                            'pre'           => __('Pre Font', 'google-fonts-wpos'),
                            'code'          => __('Code Font', 'google-fonts-wpos'),
                            'button'        => __('Button Font', 'google-fonts-wpos'),
                            'input'         => __('Input Types Font', 'google-fonts-wpos'),
                            'ol'            => __('Ordered List Font', 'google-fonts-wpos'),
                            'ul'            => __('Unordered List Font', 'google-fonts-wpos'),
                            'label'         => __('Label Font', 'google-fonts-wpos'),
                        );

    return apply_filters( 'gfpw_fonts_elements', $elements);
}

/**
 * Get Google Fonts Data
 * 
 * @package Google Fonts Pro - WPOS
 * @since 1.0.0
 */
function gfpw_get_font_data($font = '') {

    $font_data = array();

    $font_data_arr = explode(':', $font);
    preg_match("|\d+|", $font, $font_weight_arr); // Getting numeric value from string

    $font_weight    = isset($font_weight_arr[0])    ? $font_weight_arr[0] : '';
    $font_style     = isset($font_data_arr[1])      ? str_replace($font_weight, '', $font_data_arr[1]) : '';

    // Font Data
    $font_data['font_family']   = isset($font_data_arr[0]) ? $font_data_arr[0] : '';
    $font_data['font_style']    = $font_style;
    $font_data['font_weight']   = $font_weight;

    return $font_data;
}
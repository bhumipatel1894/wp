=== Google Fonts Pro ===
Contributors: wponlinesupport, anoopranawat 
Tags: google fonts
Requires at least: 3.1
Tested up to: 4.7

Adds google fonts to any theme without coding and integrates with the WordPress theme.

== Description ==
Adds google fonts to any theme without coding and integrates with the WordPress theme. It allows you to asign fonts for body, heading, em, a tag etc. This plugin allows you to take full control of your theme's typography in any WordPress theme.

= Available Features : =
* Selection of multiple google fonts
* 650+ Google fonts
* Easy to apply on various common elements
* Custom CSS
* 100% Multilanguage

== Installation ==

1. Upload the 'google-fonts-pro-wpos' folder to the '/wp-content/plugins/' directory.
2. Activate the "Google Fonts Pro" list plugin through the 'Plugins' menu in WordPress.
3. Choose your desired font and apply on your desired element.


== Changelog ==

= 1.0 =
* Initial release.

== Upgrade Notice ==

= 1.0 =
* Initial release.
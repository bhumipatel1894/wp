=== Instagram Slider and Carousel Plus Widget Pro ===
Contributors: wponlinesupport 
Tags: Custom Instagram Feed, feed, hashtag, instagram, Instagram feed, instagram gallery, Instagram images, Instagram photos, Instagram posts, Instagram wall, lightbox, photos, instagram social feed, show instagram post, responsive instgram, beautiful instagram, instagram widget,prepossessing instgram, arresting instgram, instgram plugin, artistic instagram, instagram wordpress, smashing instgram
Requires at least: 3.1
Tested up to: 4.7.3


== Description ==
A very simple plugin to display your instagram pictures in Grid, Slider and Widget. 

WPOS - Instagram is the free and most modern mobile touch slider view with hardware accelerated transitions and amazing native behavior. It is intended to be used in Destktop and mobile websites.


= This plugin contain 2 shortcode: =
1) Instagram Pictures **Instagram Pictures in Slider / carousel** view
<code>[iscwp-slider]</code>

2) Instagram Pictures **Instagram Pictures in Grid view**
<code>[iscwp-grid]</code>

3) Instagram Pictures **Instagram Pictures in Grid Block view**
<code>[iscwp-grid-block]</code>


= You can use Following parameters with shortcode =

<code>[iscwp-slider]</code>
* **Username** username="instagram" (Instagram username of which you want to show pictures.)
* **User Avatar** popup_user_avatar="true" (show user's profile pic in popup.values are "true" or "false". By Default is true.)
* **Instagram Link** popup_insta_link="ture" (show the instagram user link.values are "true" or "false". By Default is true.)
* **Instagram Link Text** instagram_link_text="View on Instagram" (vlaue is any string.)
* **Design** design="design-1" (your desired desing between "design-1" to "design-10". By Default is design-1.)
* **Limit** limit="20" (number of pictures you want to show. By Default is 20.)
* **Space Between Pics** offset="10" (gap betwenn two pitctures. values is any number. By default is 10.)
* **Link Target** link_target="self" (open the link in same window or in new window. values are "self" OR "blank". By Default is self.)
* **Popup Gallery** popup_gallery="true" (open the instagram pictures as gallery or not. values are "true" OR "false".By Default is true.)
* **Picture Height** gallery_height="300" (pictures hieght. any numeric value accepted.By Default valuse is 300.)
* **Image Caption** show_caption="true" (show the picture's caption.values are "true" or "false". By Default is true.)
* **Popup** popup="true" (show the popup for the picture detail.values are "true" or "false". By Default is true.)
* **Likes Count** show_likes_count="true" (show the likes count of picture.values are "true" or "false". By Default is true.)
* **Comments Count** show_comments_count="true" (show the commnets count of picture.values are "true" or "false". By Default is true.)
* **Comments** show_comments="true" (show the commnets of picture when popup.values are "true" or "false". By Default is true.)
* **masonry** masonry="false" (enable varient height for pictures.values are "true" or "false". By Default is false.)
* **User Details** show_user_info="false" (show the information of instagram user.values are "true" or "false". By Default is false.)
* **Slide To Show** slidestoshow="3" (number of slide you want to show in slider. By default is 3.)
* **Slide To Scroll** slidestoscroll="1" (number of picture you want to scroll at a time. By Default is number 1.)
* **Loop** loop="ture" (show continuous slider.values are "true" or "false". By Default is true.)
* **Dots** dots="true" (show slider dots.values are "true" or "false". By Default is true.)
* **Arrows** arrows="true" (show slider arrows.values are "true" or "false". By Default is true.)
* **Autoplay** autoplay="true" (Autoplay slider.values are "true" or "false". By Default is true.)
* **Autoplay Interval** autoplay_interval="3000" (time duration to scroll slide.value is any integer number. By Default is 3000.)
* **Slide Speed** speed="300" (speed of slide when scrolling.value is any integer number. By Default is 300.)
* **CenterMode** centermode="false" (enable centermode in slider.values are "true" or "false". By Default is false.)
* **Image fit** image_fit="false" (fit the image in container values are "true" or "false")

<code>[iscwp-grid]</code>
* **Username** username="instagram" (Instagram username of which you want to show pictures.)
* **Grid** grid="4" (Number of columns that you wanna to show. valuie is any numeric value between 1 to 12. By Default value is 2.)
* **User Avatar** popup_user_avatar="true" (show user's profile pic in popup.values are "true" or "false". By Default is true.)
* **Instagram Link*** popup_insta_link="ture" (show the instagram user link.values are "true" or "false". By Default is true.)
* **Instagram Link Text** instagram_link_text="View on Instagram" (vlaue is any string.)
* **Design** design="design-1" (your desired desing between "design-1" to "design-10". By Default is design-1.)
* **Limit** limit="20" (number of pictures you want to show. By Default is 20.)
* **Space Between Pics** offset="10" (gap betwenn two pitctures. values is any number. By default is 10.)
* **Link Target** link_target="self" (open the link in same window or in new window. values are "self" OR "blank". By Default is self.)
* **Popup Gallery** popup_gallery="true" (open the instagram pictures as gallery or not. values are "true" OR "false".By Default is true.)
* **Picture Height** gallery_height="300" (pictures hieght. any numeric value accepted.By Default valuse is 300.)
* **Image Caption** show_caption="true" (show the picture's caption.values are "true" or "false". By Default is true.)
* **Popup** popup="true" (show the popup for the picture detail.values are "true" or "false". By Default is true.)
* **Likes Count** show_likes_count="true" (show the likes count of picture.values are "true" or "false". By Default is true.)
* **Comments Count** show_comments_count="true" (show the commnets count of picture.values are "true" or "false". By Default is true.)
* **Comments** show_comments="true" (show the commnets of picture when popup.values are "true" or "false". By Default is true.)
* **Masonry** masonry="false" (enable varient height for pictures.values are "true" or "false". By Default is false.)
* **User Details** show_user_info="false" (show the information of instagram user.values are "true" or "false". By Default is false.)
* **Image fit** image_fit="false" (fit the image in container values are "true" or "false")

<code>[iscwp-grid-block]</code>
* **Username** username="instagram" (Instagram username of which you want to show pictures.)
* **User Avatar** popup_user_avatar="true" (show user's profile pic in popup.values are "true" or "false". By Default is true.)
* **Instagram Link** popup_insta_link="ture" (show the instagram user link.values are "true" or "false". By Default is true.)
* **Instagram Link Text** instagram_link_text="View on Instagram" (vlaue is any string.)
* **Design** design="design-1" (your desired desing between "design-1" to "design-3". By Default is design-1.)
* **Limit** limit="20" (number of pictures you want to show. By Default is 20.)
* **Link Target** link_target="self" (open the link in same window or in new window. values are "self" OR "blank". By Default is self.)
* **Popup Gallery** popup_gallery="true" (open the instagram pictures as gallery or not. values are "true" OR "false".By Default is true.)
* **Image Caption** show_caption="true" (show the picture's caption.values are "true" or "false". By Default is true.)
* **Popup** popup="true" (show the popup for the picture detail.values are "true" or "false". By Default is true.)
* **Likes Count** show_likes_count="true" (show the likes count of picture.values are "true" or "false". By Default is true.)
* **Comments Count** show_comments_count="true" (show the commnets count of picture.values are "true" or "false". By Default is true.)
* **Comments** show_comments="true" (show the commnets of picture when popup.values are "true" or "false". By Default is true.)
* **User Details** show_user_info="false" (show the information of instagram user.values are "true" or "false". By Default is false.)
* **Image fit** image_fit="false" (fit the image in container values are "true" or "false")


= Features include =

* 10+ Designs
* Touch-enabled Navigation.
* Fully responsive. Scales with its container.
* Fully accessible with arrow key navigation.
* Responsive
* Given shortcode and template code.
* Grid View.
* Slider View.
* Grid Block View.
* 2 Widgets Ready.
* Cache Time can be adjusted.
* Clear all Caches @ Single click.
* Custom CSS.
* Center Mode With Slider.
* Attractive Popup design for detail view of picture.

== Installation ==

1. Upload the 'instagram-slider-and-carousel-plus-widget-pro' folder to the '/wp-content/plugins/' directory.
2. Activate the "Instagram Slider and Carousel Plus Widget Pro" list plugin through the 'Plugins' menu in WordPress.
3. Do plugin settings and done.


== Changelog ==

= 1.0 =
* Initial release.

== Upgrade Notice ==

= 1.0 =
* Initial release.
<?php
/**
 * Admin Class
 *
 * Handles the Admin side functionality of plugin
 *
 * @package Maintenance Mode By WPOS
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Mtm_Pro_Admin {

	function __construct() {

		// Action to register admin menu
		add_action( 'admin_menu', array($this, 'mtm_pro_register_menu') );

		// Action to register plugin settings
		add_action ( 'admin_init', array($this, 'mtm_pro_register_settings') );

		// Action to Maintenance Mode
		add_action( 'wp_loaded', array($this,'mtm_pro_maintenance_mode'), 5);

		// Filter to add plugin links
		add_filter( 'plugin_row_meta', array( $this, 'mtm_pro_plugin_row_meta' ), 10, 2 );
		add_filter( 'plugin_action_links_' . MTM_PRO_PLUGIN_BASENAME, array( $this, 'mtm_pro_plugin_action_links' ) );
	}

	/**
	 * Function to register admin menus
	 * 
	 * @package Maintenance Mode By WPOS
	 * @since 1.0.0
	 */
	function mtm_pro_register_menu() {
		add_menu_page(__('Maintenance Mode - WPOS', 'maintenance-mode-pro-by-wpos'), __('Maintenance Mode - WPOS', 'maintenance-mode-pro-by-wpos'), 'manage_options', 'mtm-pro-settings', array($this, 'mtm_pro_main_page') );
	}

	/**
	 * Function to handle the setting page html
	 * 
	 * @package Maintenance Mode By WPOS
	 * @since 1.0.0
	 */
	function mtm_pro_main_page() {
		include_once( MTM_PRO_DIR . '/includes/admin/settings/mtm-pro-settings.php' );
	}

	/**
	 * Function register setings
	 * 
	 * @package Maintenance Mode By WPOS
	 * @since 1.0.0
	 */
	function mtm_pro_register_settings() {
		register_setting( 'mtm_pro_plugin_options', 'mtm_pro_options', array($this, 'mtm_pro_validate_options') );
	}

	/**
	 * Validate Settings Options
	 * 
	 * @package Maintenance Mode By WPOS
	 * @since 1.0.0
	 */
	function mtm_pro_validate_options( $input ) {

		//general options
		$input['maintenance_mode_page_title']		= isset($input['maintenance_mode_page_title']) 			? mtm_pro_slashes_deep($input['maintenance_mode_page_title']) 			: '';
		$input['maintenance_mode_google_analytics']	= isset($input['maintenance_mode_google_analytics']) 	? $input['maintenance_mode_google_analytics'] 							: '';
		$input['maintenance_mode_company_logo']		= isset($input['maintenance_mode_company_logo']) 		? mtm_pro_slashes_deep($input['maintenance_mode_company_logo']) 		: '';
		$input['maintenance_mode_company_logo_width'] = isset($input['maintenance_mode_company_logo_width']) 		? mtm_pro_slashes_deep($input['maintenance_mode_company_logo_width']) 		: '';
		$input['is_maintenance_mode']   			= !empty($input['is_maintenance_mode']) 				? 1 																	: 0;
		$input['maintenance_mode_title'] 			= isset($input['maintenance_mode_title']) 				? mtm_pro_slashes_deep($input['maintenance_mode_title']) 				: '';
		$input['maintenance_mode_text'] 			= isset($input['maintenance_mode_text']) 				? $input['maintenance_mode_text'] 										: '';
		$input['maintenance_mode_bgcolor'] 			= isset($input['maintenance_mode_bgcolor']) 			? mtm_pro_slashes_deep($input['maintenance_mode_bgcolor']) 				: '';
		$input['maintenance_mode_bgimage'] 			= isset($input['maintenance_mode_bgimage']) 			? mtm_pro_slashes_deep($input['maintenance_mode_bgimage']) 				: '';
		$input['maintenance_mode_copyright'] 		= isset($input['maintenance_mode_copyright']) 			? mtm_pro_slashes_deep($input['maintenance_mode_copyright']) 			: '';
		
		// timer options
		$input['maintenance_mode_clock_style'] 		= isset($input['maintenance_mode_clock_style']) 		? mtm_pro_slashes_deep($input['maintenance_mode_clock_style']) 			: '';
		$input['maintenance_mode_is_days']   		= !empty($input['maintenance_mode_is_days']) 			? 1 																	: 0;
		$input['maintenance_mode_days_text'] 		= isset($input['maintenance_mode_days_text']) 			? mtm_pro_slashes_deep($input['maintenance_mode_days_text']) 			: '';
		$input['maintenance_mode_is_hours']   		= !empty($input['maintenance_mode_is_hours']) 			? 1 																	: 0;
		$input['maintenance_mode_hours_text'] 		= isset($input['maintenance_mode_hours_text']) 			? mtm_pro_slashes_deep($input['maintenance_mode_hours_text']) 			: '';
		$input['maintenance_mode_is_minutes']   	= !empty($input['maintenance_mode_is_minutes']) 		? 1 																	: 0;
		$input['maintenance_mode_minutes_text'] 	= isset($input['maintenance_mode_minutes_text']) 		? mtm_pro_slashes_deep($input['maintenance_mode_minutes_text']) 		: '';
		$input['maintenance_mode_is_seconds']   	= !empty($input['maintenance_mode_is_seconds']) 		? 1 																	: 0;
		$input['maintenance_mode_seconds_text'] 	= isset($input['maintenance_mode_seconds_text']) 		? mtm_pro_slashes_deep($input['maintenance_mode_seconds_text']) 		: '';
		$input['maintenance_mode_expire_time'] 		= isset($input['maintenance_mode_expire_time']) 		? mtm_pro_slashes_deep($input['maintenance_mode_expire_time']) 			: '';
		$input['maintenance_mode_clock_label_color']= isset($input['maintenance_mode_clock_label_color']) 	? mtm_pro_slashes_deep($input['maintenance_mode_clock_label_color']) 	: '';
		$input['maintenance_mode_clock_digit_color']= isset($input['maintenance_mode_clock_digit_color']) 	? mtm_pro_slashes_deep($input['maintenance_mode_clock_digit_color']) 	: '';
		
		// subscription options
		$input['maintenance_mode_is_subscription']  = !empty($input['maintenance_mode_is_subscription']) 	? 1 																	: 0;
		$input['maintenance_mode_subscription_text']= isset($input['maintenance_mode_subscription_text']) 	? mtm_pro_slashes_deep($input['maintenance_mode_subscription_text'])	: '';
		$input['maintenance_mode_sub_form']			= isset($input['maintenance_mode_sub_form']) 			? $input['maintenance_mode_sub_form']									: '';
		$input['mtm_custom_css'] 					= isset($input['mtm_custom_css']) 						? mtm_pro_slashes_deep($input['mtm_custom_css']) 						: '';
		
		//social options
		$input['mtm_facebook'] 						= isset($input['mtm_facebook']) 						? mtm_pro_slashes_deep($input['mtm_facebook']) 							: '';
		$input['mtm_twitter'] 						= isset($input['mtm_twitter']) 							? mtm_pro_slashes_deep($input['mtm_twitter']) 							: '';
		$input['mtm_linkedin'] 						= isset($input['mtm_linkedin']) 						? mtm_pro_slashes_deep($input['mtm_linkedin']) 							: '';
		$input['mtm_github'] 						= isset($input['mtm_github']) 							? mtm_pro_slashes_deep($input['mtm_github']) 							: '';
		$input['mtm_youtube'] 						= isset($input['mtm_youtube']) 							? mtm_pro_slashes_deep($input['mtm_youtube']) 							: '';
		$input['mtm_pinterest'] 					= isset($input['mtm_pinterest']) 						? mtm_pro_slashes_deep($input['mtm_pinterest']) 						: '';
		$input['mtm_instagram'] 					= isset($input['mtm_instagram']) 						? mtm_pro_slashes_deep($input['mtm_instagram']) 						: '';
		$input['mtm_email'] 						= isset($input['mtm_email']) 							? mtm_pro_slashes_deep($input['mtm_email']) 							: '';
		$input['mtm_google_plus']					= isset($input['mtm_google_plus']) 						? mtm_pro_slashes_deep($input['mtm_google_plus']) 						: '';
		$input['mtm_tumblr'] 						= isset($input['mtm_tumblr']) 							? mtm_pro_slashes_deep($input['mtm_tumblr']) 							: '';

		//clock options
		$input['timercircle_animation'] 			= isset($input['timercircle_animation']) 				? mtm_pro_slashes_deep($input['timercircle_animation']) 				: '';
		$input['timercircle_width'] 				= isset($input['timercircle_width']) 					? mtm_pro_slashes_deep($input['timercircle_width']) 					: '';
		$input['timerbackground_width'] 			= isset($input['timerbackground_width']) 				? mtm_pro_slashes_deep($input['timerbackground_width']) 				: '';
		$input['timer_width'] 						= isset($input['timer_width']) 							? mtm_pro_slashes_deep($input['timer_width']) 							: '';
		$input['timerbackground_color'] 			= isset($input['timerbackground_color']) 				? mtm_pro_slashes_deep($input['timerbackground_color']) 				: '';
		$input['timerdaysbackground_color'] 		= isset($input['timerdaysbackground_color']) 			? mtm_pro_slashes_deep($input['timerdaysbackground_color']) 			: '';
		$input['timerhoursbackground_color'] 		= isset($input['timerhoursbackground_color']) 			? mtm_pro_slashes_deep($input['timerhoursbackground_color']) 			: '';
		$input['timerminutesbackground_color'] 		= isset($input['timerminutesbackground_color']) 		? mtm_pro_slashes_deep($input['timerminutesbackground_color']) 			: '';
		$input['timersecondsbackground_color'] 		= isset($input['timersecondsbackground_color']) 		? mtm_pro_slashes_deep($input['timersecondsbackground_color']) 			: '';

		//time circle 2 options
		$input['timercircle2_width'] 				= isset($input['timercircle2_width']) 					? mtm_pro_slashes_deep($input['timercircle2_width']) 					: '';
		$input['timer2background_color'] 			= isset($input['timer2background_color']) 				? mtm_pro_slashes_deep($input['timer2background_color']) 				: '';
		$input['timer2daysbackground_color'] 		= isset($input['timer2daysbackground_color']) 			? mtm_pro_slashes_deep($input['timer2daysbackground_color']) 			: '';
		$input['timer2hoursbackground_color'] 		= isset($input['timer2hoursbackground_color']) 			? mtm_pro_slashes_deep($input['timer2hoursbackground_color']) 			: '';
		$input['timer2minutesbackground_color'] 	= isset($input['timer2minutesbackground_color']) 		? mtm_pro_slashes_deep($input['timer2minutesbackground_color']) 		: '';
		$input['timer2secondsbackground_color'] 	= isset($input['timer2secondsbackground_color']) 		? mtm_pro_slashes_deep($input['timer2secondsbackground_color']) 		: '';

		//vertical clock
		$input['verticalbackground_color'] 			= isset($input['verticalbackground_color']) 			? mtm_pro_slashes_deep($input['verticalbackground_color']) 				: '';		

		//horizontal clock
		$input['horizontalbackground_color'] 		= isset($input['horizontalbackground_color']) 			? mtm_pro_slashes_deep($input['horizontalbackground_color']) 			: '';		

		//rounded clock
		$input['round_circle_color'] 				= isset($input['round_circle_color']) 					? mtm_pro_slashes_deep($input['round_circle_color']) 					: '';		

		//bar clock
		$input['bar_background_color'] 				= isset($input['bar_background_color']) 				? mtm_pro_slashes_deep($input['bar_background_color']) 					: '';		
		$input['bar_fill_color'] 					= isset($input['bar_fill_color']) 						? mtm_pro_slashes_deep($input['bar_fill_color']) 						: '';		

		//night clock
		$input['night_separator_color'] 			= isset($input['night_separator_color']) 				? mtm_pro_slashes_deep($input['night_separator_color']) 				: '';				

		//modern clock
		$input['modern_separator_color'] 			= isset($input['modern_separator_color']) 				? mtm_pro_slashes_deep($input['modern_separator_color']) 				: '';				

		//shadow clock
		$input['shadow2_color'] 					= isset($input['shadow2_color']) 						? mtm_pro_slashes_deep($input['shadow2_color']) 						: '';				
		$input['shadow1_color'] 					= isset($input['shadow1_color']) 						? mtm_pro_slashes_deep($input['shadow1_color']) 						: '';				
		
		return $input;
	}

	/**
	* Function to add maintenance file
	* 
	* @package Maintenance Mode By WPOS
	* @since 1.0.0
	*/
	function mtm_pro_maintenance_mode() {

	    global $pagenow, $mtm_pro_options;
	    
	    $maintenance 			= mtm_pro_get_option('is_maintenance_mode');
	    $maintenance_template 	= mtm_pro_get_option('is_maintenance_mode_template');

	    $clock_designs 			= mtm_pro_designs();
		$mtm_date 				= mtm_pro_esc_attr( mtm_pro_get_option('maintenance_mode_expire_time') );

		// Creating compitible date according to UTF GMT time zone formate for older browwser
		$unique 				= mtm_pro_get_unique();
		$mtm_date 				= date('F d, Y H:i:s', strtotime($mtm_date));

		$mtm_company_logo 		= mtm_pro_get_option('maintenance_mode_company_logo');
		$mtm_company_logo_width = mtm_pro_get_option('maintenance_mode_company_logo_width');
		$mtm_company_logo_width = (!empty($mtm_company_logo_width)) ? "style='width:".$mtm_company_logo_width."px'" : 'style="width:250px;"' ;
		$mtm_title 				= mtm_pro_esc_attr( mtm_pro_get_option('maintenance_mode_title') );
		$mtm_content 			= mtm_pro_get_option('maintenance_mode_text');
		$mtm_bgcolor 			= mtm_pro_get_option('maintenance_mode_bgcolor');
		$mtm_bgimage 			= mtm_pro_get_option('maintenance_mode_bgimage');
		$mtm_copyright 			= mtm_pro_get_option('maintenance_mode_copyright');

		$mtm_bgtimer 			= mtm_pro_get_option('maintenance_mode_expire_time');
		$mtm_bgtimer_style 		= mtm_pro_get_option('maintenance_mode_clock_style');
		$design 				= ($mtm_bgtimer_style && (array_key_exists(trim($mtm_bgtimer_style), $clock_designs))) ? trim($mtm_bgtimer_style) : 'design-1';
		$is_days 				= mtm_pro_get_option('maintenance_mode_is_days');
		$days_text 				= mtm_pro_get_option('maintenance_mode_days_text');
		$is_hours 				= mtm_pro_get_option('maintenance_mode_is_hours');
		$hours_text 			= mtm_pro_get_option('maintenance_mode_hours_text');
		$is_minutes 			= mtm_pro_get_option('maintenance_mode_is_minutes');
		$minutes_text 			= mtm_pro_get_option('maintenance_mode_minutes_text');
		$is_seconds 			= mtm_pro_get_option('maintenance_mode_is_seconds');
		$seconds_text 			= mtm_pro_get_option('maintenance_mode_seconds_text');
		$textcolor 				= mtm_pro_get_option('maintenance_mode_clock_label_color');
		$digitcolor 			= mtm_pro_get_option('maintenance_mode_clock_digit_color');

		$mtm_is_subscription 	= mtm_pro_get_option('maintenance_mode_is_subscription');
		$mtm_is_subscription_text = mtm_pro_get_option('maintenance_mode_subscription_text');
		$mtm_subscription_form 	= mtm_pro_get_option('maintenance_mode_sub_form');

		$mtm_facebook 			= esc_url(mtm_pro_get_option('mtm_facebook'));
		$mtm_twitter 			= esc_url(mtm_pro_get_option('mtm_twitter'));
		$mtm_linkedin 			= esc_url(mtm_pro_get_option('mtm_linkedin'));
		$mtm_github 			= esc_url(mtm_pro_get_option('mtm_github'));
		$mtm_youtube 			= esc_url(mtm_pro_get_option('mtm_youtube'));
		$mtm_pinterest 			= esc_url(mtm_pro_get_option('mtm_pinterest'));
		$mtm_instagram 			= esc_url(mtm_pro_get_option('mtm_instagram'));
		$mtm_email 				= mtm_pro_get_option('mtm_email');
		$mtm_google_plus 		= esc_url(mtm_pro_get_option('mtm_google_plus'));
		$mtm_tumblr				= esc_url(mtm_pro_get_option('mtm_tumblr'));

		// Shortcode file
		$design_file_path 		= MTM_PRO_DIR . '/templates/' . $design . '.php';
		$design_file 			= (file_exists($design_file_path)) ? $design_file_path : '';

		// Getting Circle 1 Variables
		$animation				= mtm_pro_get_option('timercircle_animation');
		$circlewidth			= mtm_pro_get_option('timercircle_width');
		$backgroundwidth		= mtm_pro_get_option('timerbackground_width');
		$backgroundcolor		= mtm_pro_get_option('timerbackground_color');
		$daysbackgroundcolor	= mtm_pro_get_option('timerdaysbackground_color');
		$hoursbackgroundcolor	= mtm_pro_get_option('timerhoursbackground_color');
		$minutesbackgroundcolor	= mtm_pro_get_option('timerminutesbackground_color');
		$secondsbackgroundcolor	= mtm_pro_get_option('timersecondsbackground_color');
		$width 					= mtm_pro_get_option('timer_width');

		// Circle 2 options
		$circle2width 					= mtm_pro_get_option('timercircle2_width');
		$circle2backgroundcolor 		= mtm_pro_get_option('timer2background_color');
		$circle2daysbackgroundcolor		= mtm_pro_get_option('timer2daysbackground_color');
		$cieclr2hoursbackgroundcolor	= mtm_pro_get_option('timer2hoursbackground_color');
		$circle2minutesbackgroundcolor	= mtm_pro_get_option('timer2minutesbackground_color');
		$circle2secondsbackgroundcolor	= mtm_pro_get_option('timer2secondsbackground_color');

		// Vertical options
		$verticalbackgroundcolor 		= mtm_pro_get_option('verticalbackground_color');

		// Horizontal options
		$horizontalbackgroundcolor 		= mtm_pro_get_option('horizontalbackground_color');

		// Rounded Clock options
		$roundedcirclecolor 			= mtm_pro_get_option('round_circle_color');

		// Bar Clock options
		$barbackgroundcolor 			= mtm_pro_get_option('bar_background_color');
		$barfillcolor 					= mtm_pro_get_option('bar_fill_color');

		// Night Clock options
		$nightseparatorcolor 			= mtm_pro_get_option('night_separator_color');

		// Modern Clock options
		$modernseparatorcolor 			= mtm_pro_get_option('modern_separator_color');

		// Shadow Shadow options
		$shadow1color 					= mtm_pro_get_option('shadow1_color');
		$shadow2color 					= mtm_pro_get_option('shadow2_color');

		// Compacting Variables
		$date_conf 	= compact('mtm_date', 'is_days','is_hours','is_minutes','is_seconds', 'days_text','hours_text','minutes_text','seconds_text','animation','circlewidth','backgroundwidth','backgroundcolor','daysbackgroundcolor','hoursbackgroundcolor','minutesbackgroundcolor','secondsbackgroundcolor','circle2width','circle2backgroundcolor','circle2daysbackgroundcolor','cieclr2hoursbackgroundcolor','circle2minutesbackgroundcolor','circle2secondsbackgroundcolor');
		$mmt_style = (!empty($mtm_bgimage)) ? "style='background:".$mtm_bgcolor." url(".$mtm_bgimage.") no-repeat top center fixed;background-size: cover;'" : 'style="background:'.$mtm_bgcolor.';"' ;
		
	    if( !empty($maintenance) && $pagenow !== 'wp-login.php' && !is_user_logged_in() ) {
	        require_once( MTM_PRO_DIR . '/templates/'.$maintenance_template.'.php' );
	        die();
	    }
	}

	/**
	 * Function to unique number value
	 * 
	 * @package Maintenance Mode By WPOS
	 * @since 1.0.0
	 */
	function mtm_pro_plugin_row_meta( $links, $file ) {
		
		if ( $file == MTM_PRO_PLUGIN_BASENAME ) {
			
			$row_meta = array(
				'docs'    => '<a href="' . esc_url('https://www.wponlinesupport.com/pro-plugin-document/maintenance-mode-pro-wpos/') . '" title="' . esc_attr( __( 'View Documentation', 'maintenance-mode-pro-by-wpos' ) ) . '" target="_blank">' . __( 'Docs', 'maintenance-mode-pro-by-wpos' ) . '</a>',
				'support' => '<a href="' . esc_url('https://www.wponlinesupport.com/welcome-wp-online-support-forum/') . '" title="' . esc_attr( __( 'Visit Customer Support Forum', 'maintenance-mode-pro-by-wpos' ) ) . '" target="_blank">' . __( 'Support', 'maintenance-mode-pro-by-wpos' ) . '</a>',
			);
			return array_merge( $links, $row_meta );
		}
		return (array) $links;
	}

	/**
	 * Function to add extra plugins link
	 * 
	 * @package Maintenance Mode By WPOS
	 * @since 1.0.0
	 */
	function mtm_pro_plugin_action_links( $links ) {
		
		$license_url = add_query_arg( array('page' => 'mtm-license'), admin_url('admin.php') );
		
		$links['license'] = '<a href="' . esc_url($license_url) . '" title="' . esc_attr( __( 'Activate Plugin License', 'maintenance-mode-pro-by-wpos' ) ) . '">' . __( 'License', 'maintenance-mode-pro-by-wpos' ) . '</a>';
		
		return $links;
	}
}

$mtm_pro_admin = new Mtm_Pro_Admin();
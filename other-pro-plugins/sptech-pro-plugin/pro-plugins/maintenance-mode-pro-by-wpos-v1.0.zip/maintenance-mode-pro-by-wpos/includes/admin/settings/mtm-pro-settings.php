<?php
/**
 * Settings Page
 *
 * @package Maintenance Mode By WPOS
 * @since 1.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// Taking some variables
$mtm_pro_designs = mtm_pro_designs();
?>

<div class="wrap mtm-settings">

	<h2><?php _e( 'Maintenanace Mode Settings', 'maintenance-mode-pro-by-wpos' ); ?></h2><br />

	<?php
	// Success message
	if( isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true' ) {
		echo '<div id="message" class="updated notice notice-success is-dismissible">
		<p>'.__("Your changes saved successfully.", "maintenance-mode-pro-by-wpos").'</p>
			  </div>';
	}
	?>

	<form action="options.php" method="POST" id="mtm-settings-form" class="mtm-settings-form">
		
		<?php
		    settings_fields( 'mtm_pro_plugin_options' );
		?>

		<!-- General Settings Starts -->
		<div id="mtm-general-sett" class="post-box-container mtm-general-sett">
			<div class="metabox-holder">
				<div class="meta-box-sortables ui-sortable">
					<div id="general" class="postbox">

						<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'General Settings', 'maintenance-mode-pro-by-wpos' ); ?></span>
						</h3>
						
						<div class="inside" id="123">
						
							<table class="form-table mtm-general-sett-tbl">
								<tbody>
									<tr>
										<th scope="row">
											<label for="mtm-enable-maintenance"><?php _e('Enable Maintenance Mode', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input id="mtm-enable-maintenance" type="checkbox" name="mtm_pro_options[is_maintenance_mode]" value="1" <?php checked(mtm_pro_get_option('is_maintenance_mode'),1); ?>/><br/>
											<span class="description"><?php _e('Check this box to enable maintenance mode.','maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label for="mtm-page-title"><?php _e('Page Title', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input id="mtm-page-title" type="text" name="mtm_pro_options[maintenance_mode_page_title]" value="<?php echo mtm_pro_esc_attr( mtm_pro_get_option('maintenance_mode_page_title') ); ?>" class="large-text" /><br/>
											<span class="description"><?php _e('Enter page title.','maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label for="mtm-web-logo"><?php _e('Website Logo', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input id="mtm-web-logo" type="text" name="mtm_pro_options[maintenance_mode_company_logo]" value="<?php echo mtm_pro_esc_attr( mtm_pro_get_option('maintenance_mode_company_logo') ); ?>" id="maintenance-mode-company-logo" class="regular-text mtm-default-img mtm-img-upload-input" />
											<input type="button" name="mtm_default_img" class="button-secondary mtm-img-uploader" value="<?php _e( 'Upload Image', 'maintenance-mode-pro-by-wpos'); ?>" />
											<input type="button" name="mtm_default_img_clear" id="mtm-default-img-clear" class="button button-secondary mtm-image-clear" value="<?php _e( 'Clear', 'maintenance-mode-pro-by-wpos'); ?>" /> <br />
											<span class="description"><?php _e( 'Upload website logo.', 'maintenance-mode-pro-by-wpos' ); ?></span>
											<?php
												$maintenance_mode_company_logo = '';
												if( mtm_pro_get_option('maintenance_mode_company_logo') ) { 
													$maintenance_mode_company_logo = '<img src="'.mtm_pro_get_option('maintenance_mode_company_logo').'" alt="" />';
												}
											?>
											<div class="mtm-imgs-preview"><?php echo $maintenance_mode_company_logo; ?></div>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label for="mtm-logo-width"><?php _e('Website Logo Width', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input id="mtm-logo-width" type="number" step="10" name="mtm_pro_options[maintenance_mode_company_logo_width]" value="<?php echo mtm_pro_esc_attr( mtm_pro_get_option('maintenance_mode_company_logo_width') ); ?>"/> <?php _e('Px', 'maintenance-mode-pro-by-wpos'); ?><br/>
											<span class="description"><?php _e('Enter website logo width.','maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label for="mtm-title"><?php _e('Maintenance Mode Title', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input id="mtm-title" type="text" name="mtm_pro_options[maintenance_mode_title]" value="<?php echo mtm_pro_esc_attr( mtm_pro_get_option('maintenance_mode_title') ); ?>" class="large-text" /><br/>
											<span class="description"><?php _e('Enter maintenance mode title.','maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label for="maintenance-mode-text"><?php _e('Enter Maintenance Mode Message', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<?php 
											$content 	= mtm_pro_get_option('maintenance_mode_text');
											$editor_id 	= 'maintenance-mode-text';
											$settings 	= array(
																'media_buttons'	=> true,
																'textarea_rows'	=> 8,
																'textarea_name'	=> 'mtm_pro_options[maintenance_mode_text]',
															);
											wp_editor($content, $editor_id, $settings); ?>
											<span class="description"><?php _e('Enter maintenance mode message.','maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label for="mtm-pro-copyright"><?php _e('Copyright Text', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<textarea id="mtm-pro-copyright" name="mtm_pro_options[maintenance_mode_copyright]" class="large-text"><?php echo mtm_pro_esc_attr( mtm_pro_get_option('maintenance_mode_copyright') ); ?></textarea>
											<span class="description"><?php _e('Enter Copyright text.','maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label for="mtm-countdown-timer-bg"><?php _e('Background', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input id="mtm-countdown-timer-bg" type="text" class="mtm-color-box" name="mtm_pro_options[maintenance_mode_bgcolor]" value="<?php echo mtm_pro_esc_attr( mtm_pro_get_option('maintenance_mode_bgcolor') ); ?>">
											<br/>
										<span class="description"><?php _e('Select Background Color.','maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label for="mtm-bg-img"><?php _e('Background Image', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input id="mtm-bg-img" type="text" name="mtm_pro_options[maintenance_mode_bgimage]" value="<?php echo mtm_pro_esc_attr( mtm_pro_get_option('maintenance_mode_bgimage') ); ?>" id="maintenance-mode-bgimage" class="regular-text mtm-default-img mtm-img-upload-input" />
											<input type="button" name="mtm_default_img" class="button-secondary mtm-img-uploader" value="<?php _e( 'Upload Image', 'maintenance-mode-pro-by-wpos'); ?>" />
											<input type="button" name="mtm_default_img_clear" id="mtm-default-img-clear" class="button button-secondary mtm-image-clear" value="<?php _e( 'Clear', 'maintenance-mode-pro-by-wpos'); ?>" /> <br />
											<span class="description"><?php _e( 'Upload background image.', 'maintenance-mode-pro-by-wpos' ); ?></span>
											<?php
												$maintenance_mode_bgimage = '';
												if( mtm_pro_get_option('maintenance_mode_bgimage') ) { 
													$maintenance_mode_bgimage = '<img src="'.mtm_pro_get_option('maintenance_mode_bgimage').'" alt="" />';
												}
											?>
											<div class="mtm-imgs-preview"><?php echo $maintenance_mode_bgimage; ?></div>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label for="mtm-pro-google-ana"><?php _e('Google Analytics Code', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<textarea id="mtm-pro-google-ana" name="mtm_pro_options[mtm_google_analytics]" class="large-text mtm-custom-css" id="mtm-custom-css" rows="5"><?php echo mtm_pro_get_option('mtm_google_analytics'); ?></textarea><br/>
											<span class="description"><?php _e('Enter Google Analytics code.','maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>

									<tr valign="top">
										<th scope="row">
											<label for="mtm-design"><?php _e('Maintenance Mode Template', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<select name="mtm_pro_options[is_maintenance_mode_template]" class="mtm-design" id="mtm-design">
												<?php
												$mtm_pro_template	= mtm_pro_maintenance_template();
												if( !empty($mtm_pro_template) ) {
													foreach ($mtm_pro_template as $template_design_key => $template_design_val) {
												?>
														<option value="<?php echo $template_design_key; ?>" <?php selected( mtm_pro_get_option('is_maintenance_mode_template'), $template_design_key); ?>><?php echo $template_design_val; ?></option>
												<?php
													}
												}
												?>
											</select><br/>
											<span class="description"><?php _e('Select maintenance mode template.', 'maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>

									<tr>
										<td colspan="2" valign="top" scope="row">
											<input type="submit" id="mtm-settings-submit" name="mtm-settings-submit" class="button button-primary right" value="<?php _e('Save Changes','maintenance-mode-pro-by-wpos'); ?>" />
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Timer Settings Starts -->
		<div id="mtm-general-sett" class="post-box-container mtm-general-sett">
			<div class="metabox-holder">
				<div class="meta-box-sortables ui-sortable">
					<div id="general" class="postbox">

						<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'Timer Settings', 'maintenance-mode-pro-by-wpos' ); ?></span>
						</h3>
						
						<div class="inside">
							
							<table class="form-table mtm-general-sett-tbl">
								<tbody>
									<tr valign="top">
										<th scope="row">
											<label for="mtm-countdown-time-date"><?php _e('Expiry Date & Time', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<?php 	$date  = mtm_pro_get_option('maintenance_mode_expire_time');
													$date  = ($date != '') ? $date : current_time('Y-m-d H:m:s'); ?>
											<input type="text" name="mtm_pro_options[maintenance_mode_expire_time]" value="<?php echo mtm_pro_esc_attr($date); ?>" class="regular-text mtm-countdown-time-date mtm-countdown-datepicker" id="mtm-countdown-time-date" /><br/>
											<span class="description"><?php _e('Select timer expiry Date and Time.', 'maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label><?php _e('Timer Label Text Color', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input type="text" class="mtm-color-box" name="mtm_pro_options[maintenance_mode_clock_label_color]" value="<?php echo mtm_pro_esc_attr( mtm_pro_get_option('maintenance_mode_clock_label_color') ); ?>"><br/>
											<span class="description"><?php _e('Select timer label color like Hours, Minutes and etc.', 'maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label for="mtm-countdown-timer"><?php _e('Timer Digit Text Color', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input type="text" class="mtm-color-box" name="mtm_pro_options[maintenance_mode_clock_digit_color]" value="<?php echo mtm_pro_esc_attr( mtm_pro_get_option('maintenance_mode_clock_digit_color') ); ?>"><br/>
											<span class="description"><?php _e('Select timer clock digit color.', 'maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>
									<tr>
										<th scope="row">
											<label><?php _e('Timer Clock Options', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<table>
												<tr>
													<td>
														<input type="checkbox" name="mtm_pro_options[maintenance_mode_is_days]" value="1" class="mtm-check-box mtm-timer-days" id="mtm-timer-days" <?php checked(mtm_pro_get_option('maintenance_mode_is_days'),1); ?>/>
														<label for="mtm-timer-days"><?php _e('Days', 'maintenance-mode-pro-by-wpos'); ?></label><br/>
														<input type="text" name="mtm_pro_options[maintenance_mode_days_text]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('maintenance_mode_days_text')); ?>" class="regular-text mtm-countdown-day-text" id="mtm-countdown-day-text"><br/>
														<span class="description"><?php _e('Check this box to enable Days in timer and add your desired text.', 'maintenance-mode-pro-by-wpos'); ?></span>
													</td>
													<td>
														<input type="checkbox" name="mtm_pro_options[maintenance_mode_is_hours]" value="1" class="mtm-check-box mtm-timer-hours" id="mtm-timer-hours" <?php checked(mtm_pro_get_option('maintenance_mode_is_hours'), 1); ?> />
														<label for="mtm-countdown-timer"><?php _e('Hours', 'maintenance-mode-pro-by-wpos'); ?></label><br/>
														<input type="text" id="mtm-countdown-hour-text" class="regular-text mtm-countdown-hour-text" name="mtm_pro_options[maintenance_mode_hours_text]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('maintenance_mode_hours_text')); ?>" /><br/>
														<span class="description"><?php _e('Check this box to enable Hours in timer and add your desired text.') ?></span>
													</td>
												</tr>
												<tr>
													<td>
														<input type="checkbox" name="mtm_pro_options[maintenance_mode_is_minutes]" value="1" class="mtm-check-box mtm-timer-minutes" id="mtm-timer-minutes" <?php checked(mtm_pro_get_option('maintenance_mode_is_minutes'), 1); ?> />
														<label for="mtm-timer-minutes"><?php _e('Minutes', 'maintenance-mode-pro-by-wpos'); ?></label><br/>
														<input type="text" name="mtm_pro_options[maintenance_mode_minutes_text]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('maintenance_mode_minutes_text')); ?>" id="mtm-countdown-minutes-text" class="regular-text mtm-countdown-minutes-text" /><br/>
														<span class="description"><?php _e('Check this box to enable Minutes in timer and add your desired text.', 'maintenance-mode-pro-by-wpos'); ?></span>
													</td>
													<td>
														<input type="checkbox" name="mtm_pro_options[maintenance_mode_is_seconds]" value="1" class="mtm-check-box mtm-timer-second" id="mtm-timer-second" <?php checked(mtm_pro_get_option('maintenance_mode_is_seconds'), 1); ?> />
														<label for="mtm-timer-second"><?php _e('Seconds', 'maintenance-mode-pro-by-wpos'); ?></label><br/>
														<input type="text" id="mtm-countdown-seconds-text" class="regular-text mtm-countdown-seconds-text" name="mtm_pro_options[maintenance_mode_seconds_text]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('maintenance_mode_seconds_text')); ?>" /><br/>
														<span class="description"><?php _e('Check this box to enable Seconds in timer and add your desired text.', 'maintenance-mode-pro-by-wpos'); ?></span>
													</td>
												</tr>
											</table>
										</td>
									</tr>
									<tr valign="top">
										<th scope="row">
											<label for="mtm-clock"><?php _e('Choose Style', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<select name="mtm_pro_options[maintenance_mode_clock_style]" class="mtm-design" id="mtm-clock">
												<?php
												if( !empty($mtm_pro_designs) ) {
													foreach ($mtm_pro_designs as $clock_design_key => $clock_design_val) {
												?>
														<option value="<?php echo $clock_design_key; ?>" <?php selected( mtm_pro_get_option('maintenance_mode_clock_style'), $clock_design_key); ?>><?php echo $clock_design_val; ?></option>
												<?php
													}
												}
												?>
											</select><br/>
											<span class="description"><?php _e('Select countdown timer style.', 'maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>
									<tr>
										<td colspan="2" valign="top" scope="row">
											<input type="submit" id="mtm-settings-submit" name="mtm-settings-submit" class="button button-primary right" value="<?php _e('Save Changes','maintenance-mode-pro-by-wpos'); ?>" />
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Timer Settings Ends -->
		
		<!-- Circle clock options starts -->
		<div id="mtm-general-sett" class="post-box-container mtm-general-sett mtm-post-hide mtm-post-common mtm-post-circle" style="<?php if(mtm_pro_get_option('maintenance_mode_clock_style') == 'circle' || mtm_pro_get_option('maintenance_mode_clock_style') == '' ){ echo 'display:block';  }else{ echo 'display:none'; } ?>">
			<div class="metabox-holder">
				<div class="meta-box-sortables ui-sortable">
					<div id="general" class="postbox">

						<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'Circle Clock Settings', 'maintenance-mode-pro-by-wpos' ); ?></span>
						</h3>
						
						<div class="inside">

							<table class="form-table mtm-post-sett-table">
								<tbody>
									<tr valign="top">
										<th scope="row">
											<label><?php _e('Choose Animation', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<select name="mtm_pro_options[timercircle_animation]" class="mtm-select-box mtm-timer-animation" id="mtm-timer-animation">
												<option value="smooth" <?php selected( mtm_pro_get_option('timercircle_animation'), 'smooth'); ?>><?php _e('Smooth', 'maintenance-mode-pro-by-wpos'); ?></option>
												<option value="ticks" <?php selected( mtm_pro_get_option('timercircle_animation'), 'ticks'); ?>><?php _e('Ticks', 'maintenance-mode-pro-by-wpos'); ?></option>
											</select><br/>
											<span class="description"><?php _e('Select circle animation style.', 'maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>

									<tr valign="top">
										
										<th scope="row">
											<label><?php _e('Circle Width (Foreground)', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input type="hidden" class="mtm-number" min="0.0033333333333333335" max="0.13333333333333333" step="0.003333333" name="mtm_pro_options[timercircle_width]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('timercircle_width')); ?>">
											<div class="mtm-slider"></div>
											<span class="description"><?php _e('Adjust circle width.', 'maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>

									<tr valign="top">
										<th scope="row">
											<label for="mtm-countdown-timer"><?php _e('Background Width', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input type="hidden" class="mtm-number" min="0.1" max="3" step="0.1" name="mtm_pro_options[timerbackground_width]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('timerbackground_width')); ?>">
											<div class="mtm-background-slider"></div>
											<span class="description"><?php _e('Adjust circle background width.', 'maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>

									<tr valign="top">
										<th scope="row">
											<label for="mtm-timer-width"><?php _e('Countdown Timer Width', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input type="number" min="1" name="mtm_pro_options[timer_width]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('timer_width')); ?>" class="small-text mtm-timer-width" id="mtm-timer-width" /> <?php _e('Px', 'maintenance-mode-pro-by-wpos'); ?><br/>
											<span class="description"><?php _e('Enter countdown timer width.', 'maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label for="mtm-countdown-timer"><?php _e('Background Color', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input type="text" class="mtm-color-box" name="mtm_pro_options[timerbackground_color]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('timerbackground_color')); ?>"><br/>
											<span class="description"><?php _e('Please select background color.', 'maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>
									<tr>
										<th scope="row">
											<label for="mtm-countdown-timer"><?php _e('Foreground Colors', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<table>
												<tr>
													<td>
														<label for="mtm-countdown-timer"><?php _e('Days', 'maintenance-mode-pro-by-wpos'); ?></label><br/>
														<input type="text" class="mtm-color-box" name="mtm_pro_options[timerdaysbackground_color]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('timerdaysbackground_color')); ?>"><br/>
														<span class="description"><?php _e('Select Day circle color.', 'maintenance-mode-pro-by-wpos'); ?></span>
													</td>
													<td>
														<label for="mtm-countdown-timer"><?php _e('Hours', 'maintenance-mode-pro-by-wpos'); ?></label><br/>
														<input type="text" class="mtm-color-box" name="mtm_pro_options[timerhoursbackground_color]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('timerhoursbackground_color')); ?>"><br/>
														<span class="description"><?php _e('Select Hours circle color.', 'maintenance-mode-pro-by-wpos'); ?></span>
													</td>
												</tr>

												<tr>
													<td>
														<label for="mtm-countdown-timer"><?php _e('Minutes', 'maintenance-mode-pro-by-wpos'); ?></label><br/>
														<input type="text" class="mtm-color-box" name="mtm_pro_options[timerminutesbackground_color]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('timerminutesbackground_color')); ?>"><br/>
														<span class="description"><?php _e('Select Minute circle color.', 'maintenance-mode-pro-by-wpos'); ?></span>
													</td>
													<td>
														<label for="mtm-countdown-timer"><?php _e('Seconds', 'maintenance-mode-pro-by-wpos'); ?></label><br/>
														<input type="text" class="mtm-color-box" name="mtm_pro_options[timersecondsbackground_color]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('timersecondsbackground_color')); ?>"><br/>
														<span class="description"><?php _e('Select Second circle color.', 'maintenance-mode-pro-by-wpos'); ?></span>
													</td>
												</tr>
											</table><!-- End of inner table -->
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Circle clock options ends -->

		<!-- Circle 2 options -->
		<div id="mtm-general-sett" class="post-box-container mtm-general-sett mtm-post-hide mtm-post-common mtm-post-design-3" style="<?php if(mtm_pro_get_option('maintenance_mode_clock_style') == 'design-3'){ echo 'display:block';  }else{ echo 'display:none'; } ?>">
			<div class="metabox-holder">
				<div class="meta-box-sortables ui-sortable">
					<div id="general" class="postbox">

						<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'Circle Style 2 Clock Settings', 'maintenance-mode-pro-by-wpos' ); ?></span>
						</h3>
						
						<div class="inside">

							<table class="form-table mtm-post-sett-table">
								<tbody>

									<tr valign="top">
										<th scope="row">
											<label><?php _e('Circle Width', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input type="hidden" class="mtm-number" min="1" max="25" step="1" name="mtm_pro_options[timercircle2_width]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('timercircle2_width')); ?>">
											<div class="mtm-circle-2-slider"></div>
											<span class="description"><?php _e('Adjust circle width.', 'maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label><?php _e('Background Color', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input type="text" class="mtm-color-box" name="mtm_pro_options[timer2background_color]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('timer2background_color')); ?>"><br/>
											<span class="description"><?php _e('Select background color.', 'maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>
									<tr>
										<th scope="row">
											<label><?php _e('Foreground Colors', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										
										<td>
											<table>	
												<tr>
													<td>
														<label><?php _e('Days', 'maintenance-mode-pro-by-wpos'); ?></label><br/>
														<input type="text" class="mtm-color-box" name="mtm_pro_options[timer2daysbackground_color]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('timer2daysbackground_color')); ?>"><br/>
														<span class="description"><?php _e('Select Day circle color.', 'maintenance-mode-pro-by-wpos'); ?></span>
													</td>
													
													<td>
														<label><?php _e('Hours', 'maintenance-mode-pro-by-wpos'); ?></label><br/>
														<input type="text" class="mtm-color-box" name="mtm_pro_options[timer2hoursbackground_color]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('timer2hoursbackground_color')); ?>"><br/>
														<span class="description"><?php _e('Select Hours color.', 'maintenance-mode-pro-by-wpos'); ?></span>
													</td>
												</tr>

												<tr>
													<td>
														<label><?php _e('Minutes', 'maintenance-mode-pro-by-wpos'); ?></label><br/>
														<input type="text" class="mtm-color-box" name="mtm_pro_options[timer2minutesbackground_color]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('timer2minutesbackground_color')); ?>"><br/>
														<span class="description"><?php _e('Select Minute circle color.', 'maintenance-mode-pro-by-wpos'); ?></span>
													</td>
													<td>
														<label><?php _e('Seconds', 'maintenance-mode-pro-by-wpos'); ?></label><br/>
														<input type="text" class="mtm-color-box" name="mtm_pro_options[timer2secondsbackground_color]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('timer2secondsbackground_color')); ?>"><br/>
														<span class="description"><?php _e('Please select second circle color.', 'maintenance-mode-pro-by-wpos'); ?></span>
													</td>
												</tr>
											</table><!-- End of inner table -->
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Circle 2 options end -->

		<!-- Vertical clock options starts -->
		<div id="mtm-general-sett" class="post-box-container mtm-general-sett mtm-post-hide mtm-post-common mtm-post-design-2" style="<?php if(mtm_pro_get_option('maintenance_mode_clock_style') == 'design-2'){ echo 'display:block';  }else{ echo 'display:none'; } ?>">
			<div class="metabox-holder">
				<div class="meta-box-sortables ui-sortable">
					<div id="general" class="postbox">

						<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'Vertical Clock Settings', 'maintenance-mode-pro-by-wpos' ); ?></span>
						</h3>
						
						<div class="inside">
							<table class="form-table mtm-post-sett-table">
								<tbody>
									<tr>
										<th scope="row">
											<label for="mtm-countdown-timer"><?php _e('Flip Background Color', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input type="text" class="mtm-color-box" name="mtm_pro_options[verticalbackground_color]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('verticalbackground_color')); ?>"><br/>
											<span class="description"><?php _e('Select flip background color.', 'maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Vertical clock options starts -->

		<!-- Horizontal Clock options starts -->
		<div id="mtm-general-sett" class="post-box-container mtm-general-sett mtm-post-hide mtm-post-common mtm-post-design-8" style="<?php if(mtm_pro_get_option('maintenance_mode_clock_style') == 'design-8'){ echo 'display:block';  }else{ echo 'display:none'; } ?>">
			<div class="metabox-holder">
				<div class="meta-box-sortables ui-sortable">
					<div id="general" class="postbox">

						<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'Horizontal Clock Settings', 'maintenance-mode-pro-by-wpos' ); ?></span>
						</h3>
						
						<div class="inside">

							<table class="form-table mtm-post-sett-table">
								<tbody>

									<tr>
										<th scope="row">
											<label><?php _e('Flip Background Color', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input type="text" class="mtm-color-box" name="mtm_pro_options[horizontalbackground_color]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('horizontalbackground_color')); ?>"><br/>
											<span class="description"><?php _e('Select flip background color.', 'maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Horizontal Clock options ends -->

		<!-- Rounded Clock options -->
		<div id="mtm-general-sett" class="post-box-container mtm-general-sett mtm-post-hide mtm-post-common mtm-post-design-1" style="<?php if(mtm_pro_get_option('maintenance_mode_clock_style') == 'design-1'){ echo 'display:block';  }else{ echo 'display:none'; } ?>">
			<div class="metabox-holder">
				<div class="meta-box-sortables ui-sortable">
					<div id="general" class="postbox">

						<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'Rounded Clock Settings', 'maintenance-mode-pro-by-wpos' ); ?></span>
						</h3>
						
						<div class="inside">

							<table class="form-table mtm-post-sett-table">
								<tbody>
									<tr>
										<th scope="row">
											<label for="mtm-countdown-timer"><?php _e('Circle Border Color', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input type="text" class="mtm-color-box" name="mtm_pro_options[round_circle_color]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('round_circle_color')); ?>"><br/>
											<span class="description"><?php _e('Select circle border color.', 'maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Rounded Clock options end -->

		<!-- Bars clock options starts -->
		<div id="mtm-general-sett" class="post-box-container mtm-general-sett mtm-post-hide mtm-post-common mtm-post-design-4" style="<?php if(mtm_pro_get_option('maintenance_mode_clock_style') == 'design-4'){ echo 'display:block';  }else{ echo 'display:none'; } ?>">
			<div class="metabox-holder">
				<div class="meta-box-sortables ui-sortable">
					<div id="general" class="postbox">

						<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'Bars Clock Settings', 'maintenance-mode-pro-by-wpos' ); ?></span>
						</h3>
						
						<div class="inside">
							<table class="form-table mtm-post-sett-table">
								<tbody>
									<tr>
										<th scope="row">
											<label for="mtm-countdown-timer"><?php _e('Bar Background Color', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input type="text" class="mtm-color-box" name="mtm_pro_options[bar_background_color]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('bar_background_color')); ?>"><br/>
											<span class="description"><?php _e('Select bar background color.', 'maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>
									<tr>
										<th scope="row">
											<label for="mtm-countdown-timer"><?php _e('Bar Fill Color', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input type="text" class="mtm-color-box" name="mtm_pro_options[bar_fill_color]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('bar_fill_color')); ?>"><br/>
											<span class="description"><?php _e('Select bar fill color.', 'maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Bars clock options ends -->

		<!-- Night clock options starts -->
		<div id="mtm-general-sett" class="post-box-container mtm-general-sett mtm-post-hide mtm-post-common mtm-post-design-5" style="<?php if(mtm_pro_get_option('maintenance_mode_clock_style') == 'design-5'){ echo 'display:block';  }else{ echo 'display:none'; } ?>">
			
			<div class="metabox-holder">
				<div class="meta-box-sortables ui-sortable">
					<div id="general" class="postbox">

						<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'Night Clock Settings', 'maintenance-mode-pro-by-wpos' ); ?></span>
						</h3>
						
						<div class="inside">

							<table class="form-table mtm-post-sett-table">
								<tbody>

									<tr>
										<th scope="row">
											<label for="mtm-countdown-timer"><?php _e('Clock Separator Color', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input type="text" class="mtm-color-box" name="mtm_pro_options[night_separator_color]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('night_separator_color')); ?>"><br/>
											<span class="description"><?php _e('Select clock separator color.', 'maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Night clock options ends -->

		<!-- Modern Clock options starts -->
		<div id="mtm-general-sett" class="post-box-container mtm-general-sett mtm-post-hide mtm-post-common mtm-post-design-9" style="<?php if(mtm_pro_get_option('maintenance_mode_clock_style') == 'design-9'){ echo 'display:block';  }else{ echo 'display:none'; } ?>">
			
			<div class="metabox-holder">
				<div class="meta-box-sortables ui-sortable">
					<div id="general" class="postbox">

						<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'Modern Clock Settings', 'maintenance-mode-pro-by-wpos' ); ?></span>
						</h3>
						
						<div class="inside">
							<table class="form-table mtm-post-sett-table">
								<tbody>
									<tr>
										<th scope="row">
											<label><?php _e('Separator Color', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input type="text" class="mtm-color-box" name="mtm_pro_options[modern_separator_color]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('modern_separator_color')); ?>"><br/>
											<span class="description"><?php _e('Select clock separator color.', 'maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Modern Clock options ends -->

		<!-- Shadow Clock options starts -->
		<div id="mtm-general-sett" class="post-box-container mtm-general-sett mtm-post-hide mtm-post-common mtm-post-design-11" style="<?php if(mtm_pro_get_option('maintenance_mode_clock_style') == 'design-11'){ echo 'display:block';  }else{ echo 'display:none'; } ?>">
			
			<div class="metabox-holder">
				<div class="meta-box-sortables ui-sortable">
					<div id="general" class="postbox">

						<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'Shadow Clock Settings', 'maintenance-mode-pro-by-wpos' ); ?></span>
						</h3>
						
						<div class="inside">
							<table class="form-table mtm-post-sett-table">
								<tbody>
									<tr>
										<th scope="row">
											<label for="mtm-countdown-timer"><?php _e('Shadow 1 Color', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input type="text" class="mtm-color-box" name="mtm_pro_options[shadow2_color]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('shadow2_color')); ?>"><br/>
											<span class="description"><?php _e('Select clock shadow 1 color.', 'maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>
									<tr>
										<th scope="row">
											<label for="mtm-countdown-timer"><?php _e('Shadow 2 Color', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input type="text" class="mtm-color-box" name="mtm_pro_options[shadow1_color]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('shadow1_color')); ?>"><br/>
											<span class="description"><?php _e('Select clock shadow 2 color.', 'maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Shadow Clock options end -->

		<!-- Subscription Settings Starts -->
		<div id="mtm-general-sett" class="post-box-container mtm-general-sett">
			<div class="metabox-holder">
				<div class="meta-box-sortables ui-sortable">
					<div id="general" class="postbox">

						<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'Subscription and Custom CSS Settings', 'maintenance-mode-pro-by-wpos' ); ?></span>
						</h3>
						
						<div class="inside">
						
							<table class="form-table mtm-general-sett-tbl">
								<tbody>
									<tr>
										<th scope="row">
											<label for="mtm-pro-sub-enable"><?php _e('Enable Subscription', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input id="mtm-pro-sub-enable" type="checkbox" name="mtm_pro_options[maintenance_mode_is_subscription]" value="1" <?php checked(mtm_pro_get_option('maintenance_mode_is_subscription'),1); ?>/><br/>
											<span class="description"><?php _e('Mark this box to enable subscription.','maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label for="mtm-sub-title"><?php _e('Subscription Title', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input id="mtm-sub-title" type="text" name="mtm_pro_options[maintenance_mode_subscription_text]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('maintenance_mode_subscription_text')); ?>" class="large-text"><br/>
											<span class="description"><?php _e('Enter subscription title.', 'maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label for="mtm-sub-form"><?php _e('Subscription Form Code', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<textarea id="mtm-sub-form" name="mtm_pro_options[maintenance_mode_sub_form]" class="large-text mtm-custom-css" id="mtm-custom-css" rows="15"><?php echo mtm_pro_esc_attr(mtm_pro_get_option('maintenance_mode_sub_form')); ?></textarea><br/>
											<span class="description"><?php _e('Enter Subscription Form Code.','maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label for="mtm-pro-custom-css"><?php _e('Custom CSS', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<textarea id="mtm-pro-custom-css" name="mtm_pro_options[mtm_custom_css]" class="large-text mtm-custom-css" id="mtm-custom-css" rows="15"><?php echo mtm_pro_esc_attr(mtm_pro_get_option('mtm_custom_css')); ?></textarea><br/>
											<span class="description"><?php _e('Enter custom CSS to override with existing CSS.','maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>
									<tr>
										<td colspan="2" valign="top" scope="row">
											<input type="submit" id="mtm-settings-submit" name="mtm-settings-submit" class="button button-primary right" value="<?php _e('Save Changes','maintenance-mode-pro-by-wpos'); ?>" />
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Subscription Settings Ends -->

		<!-- Socials Settings Starts -->
		<div id="mtm-general-sett" class="post-box-container mtm-general-sett">
			<div class="metabox-holder">
				<div class="meta-box-sortables ui-sortable">
					<div id="general" class="postbox">

						<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'Socials Settings', 'maintenance-mode-pro-by-wpos' ); ?></span>
						</h3>
						
						<div class="inside">
						
							<table class="form-table mtm-general-sett-tbl">
								<tbody>
									<tr>
										<th scope="row">
											<label for="mtm-pro-fb"><?php _e('Facebook', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input id="mtm-pro-fb" type="url" name="mtm_pro_options[mtm_facebook]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('mtm_facebook')); ?>" class="regular-text" /><br/>
											<span class="description"><?php _e('Enter facebook URl.','maintenance-mode-pro-by-wpos'); ?></span>
										</td>
										
										<th scope="row">
											<label for="mtm-pro-twitter"><?php _e('Twitter', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input id="mtm-pro-twitter" type="url" name="mtm_pro_options[mtm_twitter]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('mtm_twitter')); ?>" class="regular-text" /><br/>
											<span class="description"><?php _e('Enter twitter URl.','maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label for="mtm-pro-linkedin"><?php _e('Linkedin', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input id="mtm-pro-linkedin" type="url" name="mtm_pro_options[mtm_linkedin]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('mtm_linkedin')); ?>" class="regular-text" /><br/>
											<span class="description"><?php _e('Enter linkedin URl.','maintenance-mode-pro-by-wpos'); ?></span>
										</td>
								
										<th scope="row">
											<label for="mtm-pro-github"><?php _e('Github', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input id="mtm-pro-github" type="url" name="mtm_pro_options[mtm_github]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('mtm_github')); ?>" class="regular-text" /><br/>
											<span class="description"><?php _e('Enter github URl.','maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label for="mtm-pro-yoututbe"><?php _e('Youtube', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input id="mtm-pro-yoututbe" type="url" name="mtm_pro_options[mtm_youtube]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('mtm_youtube')); ?>" class="regular-text" /><br/>
											<span class="description"><?php _e('Enter github URl.','maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									
										<th scope="row">
											<label for="mtm-pro-pinterest"><?php _e('Pinterest', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input id="mtm-pro-pinterest" type="url" name="mtm_pro_options[mtm_pinterest]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('mtm_pinterest')); ?>" class="regular-text" /><br/>
											<span class="description"><?php _e('Enter pinterest URl.','maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label for="mtm-pro-insta"><?php _e('Instagram', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input id="mtm-pro-insta" type="url" name="mtm_pro_options[mtm_instagram]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('mtm_instagram')); ?>" class="regular-text" /><br/>
											<span class="description"><?php _e('Enter instagram URl.','maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									
										<th scope="row">
											<label for="mtm-pro-email"><?php _e('Email', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input id="mtm-pro-email" type="email" name="mtm_pro_options[mtm_email]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('mtm_email')); ?>" class="regular-text" /><br/>
											<span class="description"><?php _e('Enter Your Email Address.','maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label for="mtm-pro-gplus"><?php _e('Google+', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input id="mtm-pro-gplus" type="url" name="mtm_pro_options[mtm_google_plus]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('mtm_google_plus')); ?>" class="regular-text" /><br/>
											<span class="description"><?php _e('Enter google plus URl.','maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									
										<th scope="row">
											<label for="mtm-pro-tubmlr"><?php _e('Tumblr', 'maintenance-mode-pro-by-wpos'); ?></label>
										</th>
										<td>
											<input id="mtm-pro-tubmlr" type="url" name="mtm_pro_options[mtm_tumblr]" value="<?php echo mtm_pro_esc_attr(mtm_pro_get_option('mtm_tumblr')); ?>" class="regular-text" /><br/>
											<span class="description"><?php _e('Enter tumblr URL.','maintenance-mode-pro-by-wpos'); ?></span>
										</td>
									</tr>
									<tr>
										<td colspan="4" valign="top" scope="row">
											<input type="submit" id="mtm-settings-submit" name="mtm-settings-submit" class="button button-primary right" value="<?php _e('Save Changes','maintenance-mode-pro-by-wpos'); ?>" />
										</td>
									</tr>
								</tbody>
						 	</table>
						</div><!-- .inside -->
					</div><!-- #general -->
				</div><!-- .meta-box-sortables ui-sortable -->
			</div><!-- .metabox-holder -->
		</div><!-- #mtm-general-sett -->
		<!-- Socials Settings Ends -->
		
	</form><!-- end .mtm-settings-form -->
</div><!-- end .mtm-settings -->
<?php
/**
 * Plugin generic functions file
 *
 * @package Maintenance Mode By WPOS
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Update default settings
 * 
 * @package Maintenance Mode By WPOS
 * @since 1.0.0
 */
function mtm_pro_default_settings() {
    
    global $mtm_pro_options;
    
    $mtm_pro_options = array(

        // Genaral
        'is_maintenance_mode'                   => 0,
        'is_maintenance_mode_template'          => 'maintenance-template-5',
        'maintenance_mode_page_title'           => 'Website is under construction',
        'maintenance_mode_google_analytics'     => '',
        'maintenance_mode_company_logo'         => MTM_PRO_URL.'assets/images/sample-logo.png',
        'maintenance_mode_company_logo_width'   => 250,
        'maintenance_mode_title'                => 'This Site is under construction',
        'maintenance_mode_text'                 => 'Thank you for visiting! We are currently performing scheduled maintenance and updates on the website.We will be back online to serve you in short. Thank you for your patience.',
        'maintenance_mode_bgcolor'              => '#c3c3c3',
        'maintenance_mode_bgimage'              => MTM_PRO_URL.'assets/images/sample-background.jpg',
        'maintenance_mode_copyright'            => 'WP Online Support &copy; 2016',
        
        // Timer
        'maintenance_mode_expire_time'          => date( 'Y-m-d H:i:s', strtotime('+30 day', current_time('timestamp')) ),
        'maintenance_mode_clock_style'          => 'design-5',
        'maintenance_mode_is_days'              => 1,
        'maintenance_mode_days_text'            => 'Days',
        'maintenance_mode_is_hours'             => 1,
        'maintenance_mode_hours_text'           => 'Hours',
        'maintenance_mode_is_minutes'           => 1,
        'maintenance_mode_minutes_text'         => 'Minutes',
        'maintenance_mode_is_seconds'           => 1,
        'maintenance_mode_seconds_text'         => 'Seconds',
        'maintenance_mode_clock_label_color'    => '#fff',
        'maintenance_mode_clock_digit_color'    => '#fff',
        
        // Subscription
        'maintenance_mode_is_subscription'      => 0,
        'maintenance_mode_subscription_text'    => 'Subscribe to our mailing list',
        'maintenance_mode_sub_form'             => '',
        'mtm_custom_css'                        => '',
        
        // Socials
        'mtm_facebook'                          => '',
        'mtm_twitter'                           => '',
        'mtm_linkedin'                          => '',
        'mtm_github'                            => '',
        'mtm_youtube'                           => '',
        'mtm_pinterest'                         => '',
        'mtm_instagram'                         => '',
        'mtm_email'                             => '',
        'mtm_google_plus'                       => '',
        'mtm_tumblr'                            => '',

        // Time circle 1 options
        'timercircle_animation' =>'',
        'timercircle_width'=>0.1,
        'timerbackground_width'=>1.2,
        'timer_width'=>'',
        'timerbackground_color'=>'#313332',
        'timerdaysbackground_color'=>'#e3be32',
        'timerhoursbackground_color'=>'#36b0e3',
        'timerminutesbackground_color'=>'#75bf44',
        'timersecondsbackground_color'=>'#66c5af',

        // Time circle 2 options
        'timercircle2_width'=>5,
        'timer2background_color'=>'#ff9900',
        'timer2daysbackground_color'=>'#fff',
        'timer2hoursbackground_color'=>'#fff',
        'timer2minutesbackground_color'=>'#fff',
        'timer2secondsbackground_color'=>'#fff',

        // Vertical clock
        'verticalbackground_color' =>'#dd3333',

        // Horizontal clock
        'horizontalbackground_color'=>'#dd3333',

        // Rounded clock
        'round_circle_color'=>'#dd3333',

        // Bar clock
        'bar_background_color'=>'#ffffff',
        'bar_fill_color'=>'#ff9900',

        // Night clock
        'night_separator_color'=>'#fff',

        // Modern clock
        'modern_separator_color'=>'#dd3333',

        // Shadow clock
        'shadow2_color'=>'#969696',
        'shadow1_color'=>'#a19513',
    );
    
    $default_options = apply_filters('mtm_options_default_values', $mtm_pro_options );
    
    // Update default options
    update_option( 'mtm_pro_options', $default_options );

    // Overwrite global variable when option is update
    $mtm_pro_options = mtm_pro_get_settings();
}

/**
 * Escape Tags & Slashes
 *
 * Handles escapping the slashes and tags
 *
 * @package Maintenance Mode By WPOS
 * @since 1.0.0
 */
function mtm_pro_esc_attr($data) {
    return esc_attr( stripslashes($data) );
}

/**
 * Get an option
 * Looks to see if the specified setting exists, returns default if not
 * 
 * @package Maintenance Mode By WPOS
 * @since 1.0.0
 */
function mtm_pro_get_option( $key = '', $default = false ) {
    global $mtm_pro_options;

    $value = ! empty( $mtm_pro_options[ $key ] ) ? $mtm_pro_options[ $key ] : $default;
    $value = apply_filters( 'mtm_get_option', $value, $key, $default );
    
    return apply_filters( 'mtm_get_option_' . $key, $value, $key, $default );
}

/**
 * Get Settings From Option Page
 * 
 * Handles to return all settings value
 * 
 * @package Maintenance Mode By WPOS
 * @since 1.0.0
 */
function mtm_pro_get_settings() {
  
    $options    = get_option('mtm_pro_options');
    $settings   = is_array($options)  ? $options : array();
    
    return $settings;
}

/**
 * Strip Slashes From Array
 *
 * @package Maintenance Mode By WPOS
 * @since 1.0.0
 */
function mtm_pro_slashes_deep($data = array(), $flag = false) {
  
    if($flag != true) {
        $data = mtm_pro_nohtml_kses($data);
    }
    $data = stripslashes_deep($data);
    return $data;
}

/**
 * Strip Html Tags 
 * 
 * It will sanitize text input (strip html tags, and escape characters)
 * 
 * @package Maintenance Mode By WPOS
 * @since 1.0.0
 */

function mtm_pro_nohtml_kses($data = array()) {
  
  if ( is_array($data) ) {
    
    $data = array_map('mtm_pro_nohtml_kses', $data);
    
  } elseif ( is_string( $data ) ) {
    $data = trim( $data );
    $data = wp_filter_nohtml_kses($data);
  }
  
  return $data;
}

/**
* Function to add array after specific key
* 
* @package Maintenance Mode By WPOS
* @since 1.0.0
*/
function mtm_pro_designs() {
    $design_arr = array(
            'circle'    => __('Circle Clock', 'maintenance-mode-pro-by-wpos'),
            'design-3'  => __('Circle Style 2', 'maintenance-mode-pro-by-wpos'),
            'design-1'  => __('Rounded Clock', 'maintenance-mode-pro-by-wpos'),
            'design-8'  => __('Horizontal Flip', 'maintenance-mode-pro-by-wpos'),
            'design-2'  => __('Vertical Flip', 'maintenance-mode-pro-by-wpos'),
            'design-6'  => __('Simple Clock', 'maintenance-mode-pro-by-wpos'),
            'design-7'  => __('Simple Clock 2', 'maintenance-mode-pro-by-wpos'),
            'design-10' => __('Simple Clock 3', 'maintenance-mode-pro-by-wpos'),
            'design-12' => __('Simple Clock 4', 'maintenance-mode-pro-by-wpos'),
            'design-9'  => __('Modern Clock', 'maintenance-mode-pro-by-wpos'),
            'design-11' => __('Shadow Clock', 'maintenance-mode-pro-by-wpos'),
            'design-4'  => __('Bars Clock', 'maintenance-mode-pro-by-wpos'),
            'design-5'  => __('Night Clock', 'maintenance-mode-pro-by-wpos'),
        );
    return apply_filters('mtm_pro_designs', $design_arr );
}

/**
* Function to add array after specific key
* 
* @package Maintenance Mode By WPOS
* @since 1.0.0
*/
function mtm_pro_maintenance_template() {
    $design_arr = array(
            'maintenance-template-1'  => __('Maintenance Mode Template 1', 'maintenance-mode-pro-by-wpos'),
            'maintenance-template-2'  => __('Maintenance Mode Template 2', 'maintenance-mode-pro-by-wpos'),
            'maintenance-template-3'  => __('Maintenance Mode Template 3', 'maintenance-mode-pro-by-wpos'),
            'maintenance-template-4'  => __('Maintenance Mode Template 4', 'maintenance-mode-pro-by-wpos'),
            'maintenance-template-5'  => __('Maintenance Mode Template 5', 'maintenance-mode-pro-by-wpos'),
        );
    return apply_filters('mtm_pro_maintenance_template', $design_arr );
}

/**
 * Function to unique number value
 * 
 * @package Maintenance Mode By WPOS
 * @since 1.0.0
 */
function mtm_pro_get_unique() {
    static $unique = 0;
    $unique++;

    return $unique;
}
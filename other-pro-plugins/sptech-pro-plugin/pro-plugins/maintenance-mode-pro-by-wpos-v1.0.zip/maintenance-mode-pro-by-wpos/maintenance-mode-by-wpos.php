<?php
/**
 * Plugin Name: Maintenance Mode Pro - WPOS
 * Plugin URI: https://www.wponlinesupport.com/
 * Description: Easy to add maintenance mode in your website.
 * Author: WP Online Support
 * Text Domain: maintenance-mode-pro-by-wpos
 * Domain Path: /languages/
 * Version: 1.0
 * Author URI: https://www.wponlinesupport.com/
 *
 * @package WordPress
 * @author WP Online Support
 */

/**
 * Basic plugin definitions
 * 
 * @package Maintenance Mode By WPOS
 * @since 1.0.0
 */
if( !defined( 'MTM_PRO_VERSION' ) ) {
	define( 'MTM_PRO_VERSION', '1.0' ); // Version of plugin
}
if( !defined( 'MTM_PRO_DIR' ) ) {
    define( 'MTM_PRO_DIR', dirname( __FILE__ ) ); // Plugin dir
}
if( !defined( 'MTM_PRO_URL' ) ) {
    define( 'MTM_PRO_URL', plugin_dir_url( __FILE__ ) ); // Plugin url
}
if( !defined( 'MTM_PRO_PLUGIN_BASENAME' ) ) {
	define( 'MTM_PRO_PLUGIN_BASENAME', plugin_basename( __FILE__ ) ); // plugin base name
}

/**
 * Load Text Domain
 * This gets the plugin ready for translation
 * 
 * @package Maintenance Mode By WPOS
 * @since 1.0.0
 */
function mtm_pro_load_textdomain() {
	load_plugin_textdomain( 'maintenance-mode-pro-by-wpos', false, dirname( plugin_basename(__FILE__) ) . '/languages/' );
}
add_action('plugins_loaded', 'mtm_pro_load_textdomain');

/**
 * Activation Hook
 * 
 * Register plugin activation hook.
 * 
 * @package Maintenance Mode By WPOS
 * @since 1.0.0
 */
register_activation_hook( __FILE__, 'mtm_pro_install' );

/**
 * Deactivation Hook
 * 
 * Register plugin deactivation hook.
 * 
 * @package Maintenance Mode By WPOS
 * @since 1.0.0
 */
register_deactivation_hook( __FILE__, 'mtm_pro_uninstall');

/**
 * Plugin Setup (On Activation)
 * 
 * Does the initial setup,
 * stest default values for the plugin options.
 * 
 * @package Maintenance Mode By WPOS
 * @since 1.0.0
 */
function mtm_pro_install() {

    // Get settings for the plugin
    $mtm_pro_options = get_option( 'mtm_pro_options' );
    
    if( empty( $mtm_pro_options ) ) { // Check plugin version option
        
        // Set default settings
        mtm_pro_default_settings();
        
        // Update plugin version to option
        update_option( 'mtm_pro_plugin_version', '1.0' );
    }
}

/**
 * Plugin Setup (On Deactivation)
 * 
 * Delete  plugin options.
 * 
 * @package Maintenance Mode By WPOS
 * @since 1.0.0
 */
function mtm_pro_uninstall() {
    // Uninstall functionality
}

/***** Updater Code Starts *****/
define( 'EDD_MTM_PRO_STORE_URL', 'https://www.wponlinesupport.com' );
define( 'EDD_MTM_PRO_ITEM_NAME', 'Maintenance Mode Pro' );

// Plugin Updator Class 
if( !class_exists( 'EDD_SL_Plugin_Updater' ) ) {    
    include( dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php' );
}

/**
 * Updater Function
 * 
 * @package Maintenance Mode By WPOS
 * @since 1.0.0
 */
function mtm_pro_plugin_updater() {
    
    $license_key = trim( get_option( 'mtm_pro_plugin_license_key' ) );

    $edd_updater = new EDD_SL_Plugin_Updater( EDD_MTM_PRO_STORE_URL, __FILE__, array(
                'version'   => MTM_PRO_VERSION,         // current version number
                'license'   => $license_key,            // license key (used get_option above to retrieve from DB)
                'item_name' => EDD_MTM_PRO_ITEM_NAME,   // name of this plugin
                'author'    => 'WP Online Support'      // author of this plugin
            )
    );
}
add_action( 'admin_init', 'mtm_pro_plugin_updater', 0 );
include( dirname( __FILE__ ) . '/mtm-plugin-updater.php' );
/***** Updater Code Ends *****/

// Taking some globals
global $mtm_pro_options;

// Functions file
require_once( MTM_PRO_DIR . '/includes/mtm-functions.php' );
$mtm_pro_options = mtm_pro_get_settings();

// Script Class File
require_once( MTM_PRO_DIR . '/includes/class-mtm-script.php' );

// Admin Class File
require_once( MTM_PRO_DIR . '/includes/admin/class-mtm-admin.php' );
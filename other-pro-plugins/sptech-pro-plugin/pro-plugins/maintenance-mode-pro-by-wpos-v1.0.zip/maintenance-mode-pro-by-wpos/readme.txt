=== Maintenance Mode Pro - WPOS ===
Contributors: wponlinesupport, anoopranawat 
Tags: maintenance mode, coming soon
Requires at least: 3.5
Tested up to: 4.6.1
Stable tag: trunk

A quick, easy way to add and display maintenance mode on your website.

== Description ==
A very simple plugin to your website on maintenance mode. Maintenance Mode allow you to create nice and functional maintenance mode template with different timers in a few minutes. 
This is the best way to create beautiful maintenance mode template for your website visitors. You can use our Countdown timer in your website.

You can enable maintenance mode in your website with single click. The easiest way to put your website on maintenance mode.

= Features of WordPress Maintenance Mode Pro =
* Fully Responsive WordPress Maintenancemode.
* 5 attractive maintenance mode templates.
* 12+ timer design to integrate with any maintenance mode template.
* fully customized clock.
* Ability to chnage background color and width of timer.
* Ability to change rotating circle background color and width.
* Option to show/hide Days, hours, minutes and seconds.
* Option to set difftent background colors for Days, hours, minutes and seconds.
* subscription form integration.

== Installation ==

1. Upload the 'Maintenance Mode Pro by Wpos' folder to the '/wp-content/plugins/' directory.
2. Activate the "Maintenance Mode Pro by Wpos" list plugin through the 'Plugins' menu in WordPress.
3. Enable the maintenance mode.

== Changelog ==

= 1.0 =
* Initial release.

== Upgrade Notice ==

= 1.0 =
* Initial release.
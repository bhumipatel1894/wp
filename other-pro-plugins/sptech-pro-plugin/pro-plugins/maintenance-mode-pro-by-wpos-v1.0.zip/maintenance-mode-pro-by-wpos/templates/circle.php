<style type="text/css">
	#mtm-datecount-<?php echo $unique; ?>  .time_circles > div > h4{color:<?php echo $textcolor; ?> !important;}
	#mtm-datecount-<?php echo $unique; ?>  .time_circles > div > span{color:<?php echo $digitcolor; ?> !important;}
</style>
<div class="mtm-clock mtm-clock-circle" data-date="<?php echo $mtm_date; ?>" style="max-width:<?php echo $width; ?>px;"></div>
<style type="text/css">
#mtm-datecount-<?php echo $unique; ?> .mtm-clock .ce-col{color: <?php echo $textcolor; ?>;}
#mtm-datecount-<?php echo $unique; ?> .mtm-clock .ce-col .mtm-color{color: <?php echo $digitcolor; ?>;}
#mtm-datecount-<?php echo $unique; ?> .mtm-clock p, .mtm-countdown-timer-design-11 .mtm-clock span {text-shadow: -.02em .05em 0 <?php echo $shadow2color; ?>, .08em .08em 0 <?php echo $shadow1color; ?>;}
</style>
	
<div class="mtm-clock">
	<div class="ce-duration">
		<?php if($is_days == 1) { ?>
			<div class="ce-col"><span class="ce-days mtm-color"></span> <span class="ce-days-label"></span></div>
		<?php } ?>
		
		<?php if($is_hours == 1) { ?>
			<div class="ce-col"><span class="ce-hours mtm-color"></span> <span class="ce-hours-label"></span></div>
		<?php } ?>
		
		<?php if($is_minutes == 1){ ?>
			<div class="ce-col"><span class="ce-minutes mtm-color"></span> <span class="ce-minutes-label"></span></div>
		<?php } ?>

		<?php if($is_seconds == 1){ ?>
			<div class="ce-col"><span class="ce-seconds mtm-color"></span> <span class="ce-seconds-label"></span></div>
		<?php } ?>
	</div>
</div>
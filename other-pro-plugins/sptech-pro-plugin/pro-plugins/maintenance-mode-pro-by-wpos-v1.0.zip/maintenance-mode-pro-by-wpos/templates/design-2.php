<style type="text/css">
#mtm-datecount-<?php echo $unique; ?> .mtm-clock .ce-unit-wrap > span,
#mtm-datecount-<?php echo $unique; ?> .mtm-clock div.digits div.digits-inner div.flip-wrap div div.inn {color: <?php echo $textcolor; ?>;}
#mtm-datecount-<?php echo $unique; ?> .mtm-clock div.digits div.digits-inner div.flip-wrap div div.inn {color: <?php echo $digitcolor; ?>;}
#mtm-datecount-<?php echo $unique; ?> .mtm-clock div.digits div.digits-inner div.flip-wrap div div.inn, 
#mtm-datecount-<?php echo $unique; ?> .mtm-clock div.digits div.digits-inner div.flip-wrap div.up div.inn{background: <?php echo $verticalbackgroundcolor; ?>;}
</style>

<div class="mtm-clock">
	<?php if($is_days == 1){ ?>
		<div class="ce-unit-wrap">
			<div class="days"></div>
			<span class="ce-days-label"></span>
		</div>
	<?php } ?>
	
	<?php if($is_hours == 1){ ?>
		<div class="ce-unit-wrap">
			<div class="hours"></div>
			<span class="ce-hours-label"></span>
		</div>
	<?php } ?>
	
	<?php if($is_minutes == 1){ ?>
		<div class="ce-unit-wrap">
			<div class="minutes"></div>
			<span class="ce-minutes-label"></span>
		</div>
	<?php } ?>
	
	<?php if($is_seconds == 1){ ?>
		<div class="ce-unit-wrap">
			<div class="seconds"></div>
			<span class="ce-seconds-label"></span>
		</div>
	<?php } ?>
</div>
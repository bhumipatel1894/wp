<style type="text/css">
#mtm-datecount-<?php echo $unique; ?> .mtm-clock span{color: <?php echo $textcolor; ?>;}
#mtm-datecount-<?php echo $unique; ?> .mtm-clock span.mtm-color span{color: <?php echo $digitcolor; ?>;}
#mtm-datecount-<?php echo $unique; ?> .mtm-clock .ce-bar{background: <?php echo $barbackgroundcolor; ?>;}
#mtm-datecount-<?php echo $unique; ?> .mtm-clock .ce-fill{background: <?php echo $barfillcolor; ?>;}
</style>
	
<div class="ce-clearfix mtm-clock">
	<div class="ce-info ce-clearfix">
		<?php if($is_days == 1){ ?>
			<div class="ce-bar ce-bar-days"><div class="ce-fill"></div></div> 
			<span class="ce-days mtm-color"></span> <span class="ce-days-label"></span>
		<?php } ?>

		<?php if($is_hours == 1){ ?>
			<div class="ce-bar ce-bar-hours"><div class="ce-fill"></div></div> 
			<span class="ce-hours mtm-color"></span> <span class="ce-hours-label"></span>
		<?php } ?>
		
		<?php if($is_minutes == 1){ ?>
			<div class="ce-bar ce-bar-minutes"><div class="ce-fill"></div></div> 
			<span class="ce-minutes mtm-color"></span> <span class="ce-minutes-label"></span>
		<?php } ?>
		
		<?php if($is_seconds == 1){ ?>
			<div class="ce-bar ce-bar-seconds"><div class="ce-fill"></div></div> 
			<span class="ce-seconds mtm-color"></span> <span class="ce-seconds-label"></span>
		<?php } ?>
	</div>
</div>
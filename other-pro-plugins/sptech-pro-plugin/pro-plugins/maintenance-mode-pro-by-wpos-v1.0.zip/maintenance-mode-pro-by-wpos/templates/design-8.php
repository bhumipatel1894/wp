<style type="text/css">	
#mtm-datecount-<?php echo $unique; ?> .mtm-clock .ce-days, 
#mtm-datecount-<?php echo $unique; ?> .mtm-clock .ce-hours, 
#mtm-datecount-<?php echo $unique; ?> .mtm-clock .ce-minutes, 
#mtm-datecount-<?php echo $unique; ?> .mtm-clock .ce-seconds{color: <?php echo $digitcolor; ?>;}
#mtm-datecount-<?php echo $unique; ?> .mtm-clock{color: <?php echo $textcolor; ?>;}
#mtm-datecount-<?php echo $unique; ?> .mtm-clock .ce-flip-wrap .ce-flip-front,
#mtm-datecount-<?php echo $unique; ?> .mtm-clock .ce-flip-wrap .ce-flip-back{background: <?php echo $horizontalbackgroundcolor; ?>;}
</style>

<div class="mtm-clock">
	<?php if($is_days == 1){ ?>
		<div class="ce-col">
			<div class="ce-days">
				<div class="ce-flip-wrap">
					<div class="ce-flip-front"></div>
					<div class="ce-flip-back"></div>
				</div>
			</div>
			<span class="ce-days-label"></span>
		</div>
	<?php } ?>
	
	<?php if($is_hours == 1){ ?>
		<div class="ce-col">
			<div class="ce-hours">
				<div class="ce-flip-wrap">
					<div class="ce-flip-front"></div>
					<div class="ce-flip-back"></div>
				</div>
			</div>
			<span class="ce-hours-label"></span>
		</div>
	<?php } ?>
	
	<?php if($is_minutes == 1){ ?>
		<div class="ce-col">
			<div class="ce-minutes">
				<div class="ce-flip-wrap">
					<div class="ce-flip-front"></div>
					<div class="ce-flip-back"></div>
				</div>
			</div>
			<span class="ce-minutes-label"></span>
		</div>
	<?php } ?>
	
	<?php if($is_seconds == 1){ ?>
		<div class="ce-col">
			<div class="ce-seconds">
				<div class="ce-flip-wrap">
					<div class="ce-flip-front"></div>
					<div class="ce-flip-back"></div>
				</div>
			</div>
			<span class="ce-seconds-label"></span>
		</div>
	<?php } ?>
</div>
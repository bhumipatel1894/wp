<?php 
$mtm_page_title 		= mtm_pro_esc_attr( mtm_pro_get_option('maintenance_mode_page_title') );
$mtm_google_analytics 	= mtm_pro_get_option('mtm_google_analytics'); 
$mtm_custom_css 		= mtm_pro_esc_attr( mtm_pro_get_option('mtm_custom_css') ); ?>
<!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) & !(IE 8)]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width" />
	<title><?php echo $mtm_page_title; ?></title>
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />

	<link href="https://fonts.googleapis.com/css?family=Lato:400,400i,700,700i,900" rel="stylesheet">
	<link href="<?php echo MTM_PRO_URL; ?>assets/css/fontello.css" rel="stylesheet">
	<link href="<?php echo MTM_PRO_URL; ?>assets/css/mtm-pro-public.css" rel="stylesheet">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
	
	<?php if( $mtm_custom_css != ''){ ?>
		<style type="text/css">
			<?php echo $mtm_custom_css; ?>
		</style>
	<?php } ?>
	
	<?php if($mtm_google_analytics != '') {
		echo $mtm_google_analytics;
	} ?>
</head>
<body>
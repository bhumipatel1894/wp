jQuery( document ).ready(function( $ ) {

    $(".abubwpos-settings .abubwpos-options-check").click( function(){
       
        var cls_ele     = $(this).closest('.form-table');
        var ele_name    = $(this).attr('name');
        var ele_module  = $(this).attr('data-dependant');
        
        if( $(this).is(':checked') ) {
            cls_ele.find('tr.'+ele_module).show(500);
        } else {
            cls_ele.find('tr.'+ele_module).hide(500);
        }
    });
    
    $(".abubwpos-settings #abubwpos-social-icon-style").change( function(){
       var ico_style    = $(this).val();
        var cls_ele     = $(this).closest('.form-table');
        var ele_name    = $(this).attr('name');
        var ele_module  = $(this).attr('data-dependant');
        
        if(ico_style == 'circle') {
            cls_ele.find('tr.'+ele_module).show(500);
        } else {
            cls_ele.find('tr.'+ele_module).hide(500);
        }
    });
    /* Colorpicker */
    $('.abubwpos-color-box').wpColorPicker();

    /*Date Picker*/
    $(".abubwpos-datepicker").datepicker();
    /* sortable */
    $( 'table.abubwpos-users-social-info tbody' ).sortable({
        cursor              : 'move',
        axis                : 'y',
        handle              : '.handle',
        containment         : '.abubwpos-users-social-info',
        scrollSensitivity   : 40,
        placeholder         : "abubwpos-state-highlight",
        helper              : function( event, ui ) {
                                return ui;
                              },
        start               : function( event, ui ) {
                              },
        stop                : function( event, ui ) {
                              },
        update              : function( event, ui ) {
                              }
    });

    /* Reset Settings Button */
    $( document ).on( 'click', '.abubwpos-reset-sett', function() {
        var ans;
        ans = confirm(Abubwpos_Admin.reset_msg);

        if(ans) {
            return true;
        } else {
            return false;
        }
    });
    
});
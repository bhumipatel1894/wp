<?php
/**
 * Admin Class
 *
 * Handles the Admin side functionality of plugin
 *
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Abubwpos_Admin {
	
	function __construct() {

		// Action to register admin menu
		add_action( 'admin_menu', array($this, 'abubwpos_register_menu') );

		// Action to register plugin settings
		add_action ( 'admin_init', array($this, 'abubwpos_register_settings') );

		// Action to add social field in user profile page		
		add_action( 'show_user_profile', array($this,'abubwpos_social_field') );

		// Action to save social field	
		add_action( 'edit_user_profile', array($this,'abubwpos_social_field') );

		// Action to save authorbox data
		add_action( 'personal_options_update', array($this,'abubwpos_save_social_field') );
		add_action( 'edit_user_profile_update', array($this,'abubwpos_save_social_field') );

	}

	/**
	 * Function to register admin menus
	 * 
	 * @package Author Box Ultimate by WPOS
	 * @since 1.0.0
	 */
	function abubwpos_register_menu() {
		add_menu_page ( __('WPOS Author Box', 'author-box-ultimate-by-wpos'), __('WPOS Author Box', 'author-box-ultimate-by-wpos'), 'manage_options', 'abubwpos-settings', array($this, 'abubwpos_settings_page'), 'dashicons-feedback' );
	}

	/**
	 * Function to handle the setting page html
	 * 
	 * @package Author Box Ultimate by WPOS
	 * @since 1.0.0
	 */
	function abubwpos_settings_page() {
		include_once( ABUBWPOS_DIR . '/includes/admin/settings/settings.php' );
	}

	/**
	 * Function register setings
	 * 
	 * @package Author Box Ultimate by WPOS
	 * @since 1.0.0
	 */
	function abubwpos_register_settings()
	{
		register_setting( 'abubwpos_plugin_options', 'abubwpos_options', array($this, 'abubwpos_validate_options') );
	}

	/**
	 * Validate Settings Options
	 * 
	 * @package Author Box Ultimate by WPOS
	 * @since 1.0.0
	 */
	function abubwpos_validate_options( $input ) {
		return $input;
	}
	
	/**
	 * Function to add extra field in user profile page
	 * 
	 * @package Author Box Ultimate by WPOS
	 * @since 1.0.0
	 */
	function abubwpos_social_field($user){
		include_once( ABUBWPOS_DIR . '/includes/admin/profile-fields/profile-fields.php' );
	}

	function abubwpos_save_social_field($user_id){
		if ( !current_user_can( 'edit_user', $user_id ) )
		return FALSE;
		if(isset($_POST['abubwpos_data_of_birth']) && !empty($_POST['abubwpos_data_of_birth'])){
			update_user_meta( $user_id, 'abubwpos_data_of_birth', $_POST['abubwpos_data_of_birth'] );
		}
		else{
			update_user_meta( $user_id, 'abubwpos_data_of_birth', '' );
		}

		update_user_meta( $user_id, 'abubwpos_social', $_POST['abubwpos_social'] );
	}
}

$abubwpos_admin = new Abubwpos_Admin();
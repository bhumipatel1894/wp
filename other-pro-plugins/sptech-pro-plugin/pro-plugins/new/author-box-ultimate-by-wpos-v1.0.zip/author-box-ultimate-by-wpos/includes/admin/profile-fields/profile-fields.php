<?php
/**
 * Profile Fields
 *
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;
$abubwpos_social_links 	= abubwpos_social_icons();
$users_social_links 	= get_the_author_meta( 'abubwpos_social', $user->ID );
$author_date_of_birth	= '';
if(!empty($abubwpos_social_links)){
	$abubwpos_social_links['abubwpos_social'] = abubwpos_social_link_merge($users_social_links,$abubwpos_social_links['abubwpos_social']);
}

if(!empty(get_the_author_meta( 'abubwpos_data_of_birth',$user->ID  ))){
	$author_date_of_birth = get_the_author_meta( 'abubwpos_data_of_birth', $user->ID );
	$author_date_of_birth = date( get_option('date_format'), strtotime(get_the_author_meta( 'abubwpos_data_of_birth', $user->ID )));
}

?>
<h2><?php _e('Authore Box Information','author-box-ultimate-by-wpos');?></h2>
<table class="form-table abubwpos-users-social-info">
	<tbody>
		<tr>
			<td><label for="abubwpos-birth-of-date"><?php _e('Date Of Birth','author-box-ultimate-by-wpos');?> </label></td>
			<td>
			<input type="text" name="abubwpos_data_of_birth" id="abubwpos-birth-of-date" value="<?php echo $author_date_of_birth; ?>" class="regular-text abubwpos-datepicker" />
			</td>
		</tr>
		
		<?php 
		if(!empty($abubwpos_social_links['abubwpos_social'])){
			foreach ($abubwpos_social_links['abubwpos_social'] as $social_key => $social_data) {
				
				$users_social_link = isset($users_social_links[$social_key]) ? $users_social_links[$social_key] : '';
				?>
				<tr>
					<td>
						<span class="handle"><i class="dashicons dashicons-move"></i></span>
						<label for="abubwpos-<?php echo $social_key?>"><?php echo $social_data['label'];?> </label>
					</td>
					<td>
						<input id="abubwpos-<?php echo $social_key?>" type="text" name="abubwpos_social[<?php echo $social_key;?>]" id="abubwpos-birth-of-date" value="<?php echo $users_social_link;?>" class="regular-text" />
					</td>
				</tr>
				<?php
			}
		}
		?>
	</tbody>
</table>
<?php
/**
 * Settings Page
 *
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

global $wp_version;


?>

<div class="wrap abubwpos-settings">

<h2><?php _e( 'Author Box Ultimate By WPOS Settings', 'author-box-ultimate-by-wpos' ); ?></h2><br />

<?php
if( isset($_POST['abubwpos_reset_settings']) && !empty($_POST['abubwpos_reset_settings']) ) {
	
	abubwpos_default_settings(); // set default settings
	
	// Reset message
	echo '<div id="message" class="updated notice notice-success is-dismissible">
			<p><strong>' . __( 'All settings reset successfully.', 'author-box-ultimate-by-wpos') . '</strong></p>
		 </div>';
}
if( isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true' ) {
	
	
	echo '<div id="message" class="updated notice notice-success is-dismissible">
			<p>'.__("Your changes saved successfully.", "author-box-ultimate-by-wpos").'</p>
		  </div>';
}
?>
<!--  reset settings form -->
<form action="" method="post" id="abubwpos-reset-sett-form">
	<div class="abubwpos-reset-sett-form-wrp abubwpos-clearfix">
		<input type="submit" class="button button-primary right abubwpos-reset-sett" name="abubwpos_reset_settings" id="abubwpos-reset-sett" value="<?php _e( 'Reset All Settings', 'author-box-ultimate-by-wpos' ); ?>" />
	</div>
</form>

<form action="options.php" method="POST" id="abubwpos-settings-form" class="abubwpos-settings-form">
	
	<?php
	    settings_fields( 'abubwpos_plugin_options' );
	    global $abubwpos_options;
	   
	    $avatar_styles 					= abubwpos_avatar_styles();
	    $abubwposbox_icon_type			= abubwpos_icon_type();
	   	$abubwposbox_icon_style			= abubwpos_icon_style();
	    $abubwposbox_google_subset 		= abubwpos_google_subset();
	    $abubwposbox_google_fonts 		= abubwpos_google_fonts();
	    $abubwposbox_desc_style 		= abubwpos_description_style();
	   	$abubwposbox_abubwpos_web_cls 	= abubwpos_get_option('abubwpos_web') ? '' : 'abubwpos-hide';
	   	$abubwposbox_icon_style_cls 	= (abubwpos_get_option('abubwpos_social_icon_style')  == 'circle')? '' : 'abubwpos-hide';
	   	$abubwposbox_designs 			= abubwpos_designs();
	?>
	
	<div id="abubwpos-design-settings" class="post-box-container abubwpos-design-settings">
		<div class="metabox-holder">
			<div class="meta-box-sortables ui-sortable">
				<div id="general" class="postbox">

					<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'Authobox Design Options', 'author-box-ultimate-by-wpos' ); ?></span>
						</h3>
						
						<div class="inside">
						
						<table class="form-table abubwpos-design-settings-tbl">
							<tbody>

								<tr>
									<th scope="row">
										<label for="abubwpos-enable-author"><?php _e('Enable Authobox', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<label class="abubwpos-enable-author abubwpos-check-switch abubwpos-options-check-switch"><input type="checkbox" name="abubwpos_options[abubwpos_enable]" value="1" class="abubwpos-options-check abubwpos-enable-author" <?php checked(abubwpos_get_option('abubwpos_enable'), 1 ); ?>/><div class="abubwpos-check-slider abubwpos-check-switch-round"></div></label>
									</td>
								</tr>

								<tr>
									<th scope="row">
										<label for="abubwpos-design"><?php _e('Choose Author Box Design', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<select id="abubwpos-design" name="abubwpos_options[abubwpos_design]" class="abubwpos-select-box abubwpos-design">
											<?php 
											if(!empty($abubwposbox_designs)){
												foreach ($abubwposbox_designs as $design_key => $design_name) {
												?>
													<option value="<?php echo $design_key;?>" <?php selected(abubwpos_get_option('abubwpos_design'),$design_key);?>><?php echo $design_name;?></option>
												<?php
												}
											}
											?>
										</select>										
									</td>
								</tr>							

								<tr>
									<td colspan="2" valign="top" scope="row">
										<input type="submit" id="abubwpos-settings-submit" name="abubwpos-settings-submit" class="button button-primary right" value="<?php _e('Save Changes','author-box-ultimate-by-wpos');?>" />
									</td>
								</tr>
							</tbody>
						 </table>

					</div><!-- .inside -->
				</div><!-- #general -->
			</div><!-- .meta-box-sortables ui-sortable -->
		</div><!-- .metabox-holder -->
	</div><!-- #abubwpos-design-settings -->

	<div id="abubwpos-general-settings" class="post-box-container abubwpos-general-settings">
		<div class="metabox-holder">
			<div class="meta-box-sortables ui-sortable">
				<div id="general" class="postbox">

					<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'General Options', 'author-box-ultimate-by-wpos' ); ?></span>
						</h3>
						
						<div class="inside">
						
						<table class="form-table abubwpos-general-settings-tbl">
							<tbody>								

								<tr>
									<th scope="row">
										<label for="abubwpos-box-margin-top"><?php _e('Top margin of author box', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<input id="abubwpos-box-margin-top" type="number" name="abubwpos_options[abubwpos_box_margin_top]" value="<?php echo abubwpos_get_option('abubwpos_box_margin_top');?>" class="abubwpos-box-margin-top"  /> PX
									</td>
								</tr>

								<tr>
									<th scope="row">
										<label for="abubwpos-box-margin-bottom"><?php _e('Bottom margin of author box', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<input type="number" name="abubwpos_options[abubwpos_box_margin_bottom]" value="<?php echo abubwpos_get_option('abubwpos_box_margin_bottom');?>" class="abubwpos-box-margin-bottom" id="abubwpos-box-margin-bottom" /> PX
									</td>
								</tr>

								<tr>
									<th scope="row">
										<label for="abubwpos-no-description"><?php _e('Hide the author box if author description is empty', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<label class="abubwpos-check-switch abubwpos-options-check-switch"><input type="checkbox" name="abubwpos_options[abubwpos_no_description]" value="1" class="abubwpos-options-check" <?php checked(abubwpos_get_option('abubwpos_no_description'), 1 ); ?>/><div class="abubwpos-check-slider abubwpos-check-switch-round"></div></label>
									</td>
								</tr>							
								
								<tr>
									<th scope="row">
										<label for="abubwpos-avatar-style"><?php _e('Author avatar image style', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<select name="abubwpos_options[abubwpos_avatar_style]" class="abubwpos-select-box abubwpos-avatar-style" id="abubwpos-avatar-style">
											<?php 
											if(!empty($avatar_styles)){
												foreach ($avatar_styles as $avatar_key => $abubwpos_avatar_style) {
												?>
													<option value="<?php echo $avatar_key;?>" <?php selected(abubwpos_get_option('abubwpos_avatar_style'),$avatar_key);?>><?php echo $abubwpos_avatar_style;?></option>
												<?php
												}
											}
											?>
										</select>										
									</td>
								</tr>

								<tr>
									<th scope="row">
										<label for="abubwpos-web"><?php _e('Show author website', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<label class="abubwpos-check-switch abubwpos-options-check-switch"><input type="checkbox" name="abubwpos_options[abubwpos_web]" value="1" class="abubwpos-options-check" <?php checked(abubwpos_get_option('abubwpos_web'), 1 ); ?> data-dependant="abubwpos-website"/><div class="abubwpos-check-slider abubwpos-check-switch-round"></div></label>
									</td>
								</tr>															

								<tr class="abubwpos-website <?php echo  $abubwposbox_abubwpos_web_cls;?>">
									<th scope="row">
										<label for="abubwpos-web-target"><?php _e('Open author website link in a new tab', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<label class="abubwpos-check-switch abubwpos-options-check-switch"><input type="checkbox" name="abubwpos_options[abubwpos_web_target]" value="1" class="abubwpos-options-check" <?php checked(abubwpos_get_option('abubwpos_web_target'), 1 ); ?>/><div class="abubwpos-check-slider abubwpos-check-switch-round"></div></label>
									</td>
								</tr>

								<tr>
									<th scope="row">
										<label for="abubwpos-birth-date"><?php _e('Show author Birth Date', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<label class="abubwpos-check-switch abubwpos-options-check-switch"><input type="checkbox" name="abubwpos_options[abubwpos_birth_date]" value="1" class="abubwpos-options-check" <?php checked(abubwpos_get_option('abubwpos_birth_date'), 1 ); ?> data-dependant="abubwpos-website"/><div class="abubwpos-check-slider abubwpos-check-switch-round"></div></label>
									</td>
								</tr>

								<tr>
									<th scope="row">
										<label for="abubwpos-email"><?php _e('Show author email', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<label class="abubwpos-check-switch abubwpos-options-check-switch"><input type="checkbox" name="abubwpos_options[abubwpos_email]" value="1" class="abubwpos-options-check" <?php checked(abubwpos_get_option('abubwpos_email'), 1 ); ?>/><div class="abubwpos-check-slider abubwpos-check-switch-round"></div></label>
									</td>
								</tr>

								<tr>
									<th scope="row">
										<label for="abubwpos-role"><?php _e('Show author role', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<label class="abubwpos-check-switch abubwpos-options-check-switch"><input type="checkbox" name="abubwpos_options[abubwpos_role]" value="1" class="abubwpos-role abubwpos-options-check" <?php checked(abubwpos_get_option('abubwpos_role'), 1 ); ?>/><div class="abubwpos-check-slider abubwpos-check-switch-round"></div></label>
									</td>
								</tr>
									
								<tr>
									<th colspan="4">
										<div class="abubwpos-sett-title"><?php _e('Social Icon Settings','author-box-ultimate-by-wpos');?></div>
									</th>
								</tr>

								<tr>
									<th scope="row">
										<label for="abubwpos-social-icon-style"><?php _e('Social icons style (Colored)', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<label class="abubwpos-social-icon-style abubwpos-check-switch abubwpos-options-check-switch"><input type="checkbox" name="abubwpos_options[abubwpos_social_style]" value="1" class="abubwpos-options-check" <?php checked(abubwpos_get_option('abubwpos_social_style'), 1 ); ?>/><div class="abubwpos-social-icon-style abubwpos-check-slider abubwpos-check-switch-round"></div></label>
									</td>
								</tr>
								
								<tr>
									<th scope="row">
										<label for="abubwpos-social-icon-border"><?php _e('Social Icons Border', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<label class="abubwpos-social-icon-border abubwpos-check-switch abubwpos-options-check-switch"><input type="checkbox" name="abubwpos_options[abubwpos_social_icon_border]" value="1" class="abubwpos-options-check" <?php checked(abubwpos_get_option('abubwpos_social_icon_border'), 1 ); ?>/><div class="abubwpos-social-icon-border abubwpos-check-slider abubwpos-check-switch-round"></div></label>
									</td>
								</tr>

								<tr>
									<th scope="row">
										<label for="abubwpos-social-link-target"><?php _e('Open social icon links in a new tab', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<label class="abubwpos-check-switch abubwpos-options-check-switch"><input type="checkbox" name="abubwpos_options[abubwpos_social_link_target]" value="1" class="abubwpos-options-check" <?php checked(abubwpos_get_option('abubwpos_social_link_target'), 1 ); ?>/><div class="abubwpos-check-slider abubwpos-check-switch-round"></div></label>
									</td>
								</tr>
								
								<tr>
									<th scope="row">
										<label for="abubwpos-enable-popup"><?php _e('Hide the social icons on author box', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<label class="abubwpos-check-switch abubwpos-options-check-switch"><input type="checkbox" name="abubwpos_options[abubwpos_hide_social_icon]" value="1" class="abubwpos-options-check" <?php checked(abubwpos_get_option('abubwpos_hide_social_icon'), 1 ); ?>/><div class="abubwpos-check-slider abubwpos-check-switch-round"></div></label>
									</td>
								</tr>
								<tr>
									<td colspan="2" valign="top" scope="row">
										<input type="submit" id="abubwpos-settings-submit" name="abubwpos-settings-submit" class="button button-primary right" value="<?php _e('Save Changes','author-box-ultimate-by-wpos');?>" />
									</td>
								</tr>
							</tbody>
						 </table>

					</div><!-- .inside -->
				</div><!-- #general -->
			</div><!-- .meta-box-sortables ui-sortable -->
		</div><!-- .metabox-holder -->
	</div><!-- #abubwpos-general-settings -->

	<div id="abubwpos-color-settings" class="post-box-container abubwpos-general-settings">
		<div class="metabox-holder">
			<div class="meta-box-sortables ui-sortable">
				<div id="general" class="postbox">

					<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'Color Options', 'author-box-ultimate-by-wpos' ); ?></span>
						</h3>
						
						<div class="inside">
						
						<table class="form-table abubwpos-general-settings-tbl">
							<tbody>

								<tr>
									<th scope="row">
										<label for="abubwpos-authore-name-color"><?php _e('Author name color', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<input type="text" id="abubwpos-authore-name-color" value="<?php echo abubwpos_get_option('abubwpos_authore_name_color'); ?>" name="abubwpos_options[abubwpos_authore_name_color]" class="abubwpos-color-box" /><br/>
									</td>
								</tr>

								<tr>
									<th scope="row">
										<label for="abubwpos-authore-website-link-color"><?php _e('Author website link color', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<input type="text" id="abubwpos-authore-website-link-color" value="<?php echo abubwpos_get_option('abubwpos_authore_website_link_color'); ?>" name="abubwpos_options[abubwpos_authore_website_link_color]" class="abubwpos-color-box" /><br/>
									</td>
								</tr>

								<tr>
									<th scope="row">
										<label for="abubwpos-authore-border-color"><?php _e('Border color of Author Box', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<input type="text" id="abubwpos-authore-border-color" value="<?php echo abubwpos_get_option('abubwpos_authore_border_color'); ?>" name="abubwpos_options[abubwpos_authore_border_color]" class="abubwpos-color-box" /><br/>
									</td>
								</tr>

								<tr>
									<th scope="row">
										<label for="bubwpos-authore-bg-iconbar-color"><?php _e('Background color of social icons bar', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<input type="text" id="abubwpos-authore-bg-iconbar-color" value="<?php echo abubwpos_get_option('abubwpos_authore_bg_iconbar_color'); ?>" name="abubwpos_options[abubwpos_authore_bg_iconbar_color]" class="abubwpos-color-box" /><br/>
									</td>
								</tr>

								<tr>
									<th scope="row">
										<label for="abubwpos-authore-social-icon-color"><?php _e('Social icons color (for symbols only)', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<input type="text" id="abubwpos-authore-social-icon-color" value="<?php echo abubwpos_get_option('abubwpos_authore_social_icon_color'); ?>" name="abubwpos_options[abubwpos_authore_social_icon_color]" class="abubwpos-color-box" /><br/>
									</td>
								</tr>

								<tr>
									<th scope="row">
										<label for="abubwpos-authore-social-icon-color"><?php _e('Social icons border', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<input type="text" id="abubwpos-authore-social-icon-color" value="<?php echo abubwpos_get_option('abubwpos_authore_social_icon_border_color'); ?>" name="abubwpos_options[abubwpos_authore_social_icon_border_color]" class="abubwpos-color-box" /><br/>
									</td>
								</tr>
								
								<tr>
									<td colspan="2" valign="top" scope="row">
										<input type="submit" id="abubwpos-settings-submit" name="abubwpos-settings-submit" class="button button-primary right" value="<?php _e('Save Changes','author-box-ultimate-by-wpos');?>" />
									</td>
								</tr>
							</tbody>
						 </table>

					</div><!-- .inside -->
				</div><!-- #general -->
			</div><!-- .meta-box-sortables ui-sortable -->
		</div><!-- .metabox-holder -->
	</div><!-- #abubwpos-colored-settings -->

	<div id="abubwpos-typography-settings" class="post-box-container abubwpos-typography-settings">
		<div class="metabox-holder">
			<div class="meta-box-sortables ui-sortable">
				<div id="general" class="postbox">

					<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'Typography Options', 'author-box-ultimate-by-wpos' ); ?></span>
						</h3>
						
						<div class="inside">
						
						<table class="form-table abubwpos-general-settings-tbl">
							<tbody>

								<tr>
									<th colspan="4">
										<div class="abubwpos-sett-title"><?php _e('Authorbox Font Settings','author-box-ultimate-by-wpos');?></div>
									</th>
								</tr>

								<tr>
									<th scope="row">
										<label for="abubwpos-font-subset"><?php _e('Google font characters subset', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<select name="abubwpos_options[abubwpos_font_subset]" class="abubwpos-select-box abubwpos-font-subset" id="abubwpos-font-subset">
											<?php 
											if(!empty($abubwposbox_google_subset)){
												foreach ($abubwposbox_google_subset as $abubwposbox_subset_key => $abubwposbox_subset_name) {
												?>
													<option value="<?php echo $abubwposbox_subset_name;?>" <?php selected(abubwpos_get_option('abubwpos_font_subset'),$abubwposbox_subset_name);?>><?php echo $abubwposbox_subset_name;?></option>
												<?php
												}
											}
											?>											
										</select>
									</td>
								</tr>

								<tr>
									<th scope="row">
										<label for="abubwpos-name-font"><?php _e('Author name font family', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<select name="abubwpos_options[abubwpos_name_font]" class="abubwpos-select-box abubwpos-name-font" id="abubwpos-name-font">
											<?php 
											if(!empty($abubwposbox_google_fonts)){
												foreach ($abubwposbox_google_fonts as $google_font_key => $google_font_name) {
												?>
													<option value="<?php echo $google_font_name;?>" <?php selected(abubwpos_get_option('abubwpos_name_font'),$google_font_name);?>><?php echo $google_font_name;?></option>
												<?php
												}
											}
											?>
										</select>
									</td>
								</tr>

								<tr>
									<th scope="row">
										<label for="abubwpos-website-font"><?php _e('Author website font family', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<select name="abubwpos_options[abubwpos_website_font]" class="abubwpos-select-box abubwpos-website-font" id="abubwpos-website-font">
											<?php 
											if(!empty($abubwposbox_google_fonts)){
												foreach ($abubwposbox_google_fonts as $google_font_key => $google_font_name) {
												?>
													<option value="<?php echo $google_font_name;?>" <?php selected(abubwpos_get_option('abubwpos_website_font'),$google_font_name);?>><?php echo $google_font_name;?></option>
												<?php
												}
											}
											?>
										</select>
									</td>
								</tr>	

								<tr>
									<th scope="row">
										<label for="abubwpos-description-font"><?php _e('Author description font family', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<select name="abubwpos_options[abubwpos_description_font]" class="abubwpos-select-box abubwpos-description-font" id="abubwpos-description-font">
											<?php 
											if(!empty($abubwposbox_google_fonts)){
												foreach ($abubwposbox_google_fonts as $google_font_key => $google_font_name) {
												?>
													<option value="<?php echo $google_font_name;?>" <?php selected(abubwpos_get_option('abubwpos_description_font'),$google_font_name);?>><?php echo $google_font_name;?></option>
												<?php
												}
											}
											?>
										</select>
									</td>
								</tr>
								
								<tr>
									<th colspan="4">
										<div class="abubwpos-sett-title"><?php _e('Authorbox Font Size Settings','author-box-ultimate-by-wpos');?></div>
									</th>
								</tr>

								<tr>
									<th scope="row">
										<label for="abubwpos-name-font-size"><?php _e('Author name font size', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<input type="number" name="abubwpos_options[abubwpos_name_font_size]" value="<?php echo abubwpos_get_option('abubwpos_name_font_size');?>" class="abubwpos-name-font-size" id="abubwpos-name-font-size" /> PX
									</td>
								</tr>

								<tr>
									<th scope="row">
										<label for="abubwpos-website-font-size"><?php _e('Author website font size', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<input type="number" name="abubwpos_options[abubwpos_website_font_size]" value="<?php echo abubwpos_get_option('abubwpos_website_font_size');?>" class="abubwpos-website-font-size" id="abubwpos-website-font-size" /> PX
									</td>
								</tr>

								<tr>
									<th scope="row">
										<label for="abubwpos-description-font-size"><?php _e('Author description font size', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<input type="number" name="abubwpos_options[abubwpos_description_font_size]" value="<?php echo abubwpos_get_option('abubwpos_description_font_size');?>" class="abubwpos-description-font-size" id="abubwpos-description-font-size" /> PX
									</td>
								</tr>

								<tr>
									<th scope="row">
										<label for="abubwpos-icon-size"><?php _e('Size of social icons', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<input type="number" name="abubwpos_options[abubwpos_icon_size]" value="<?php echo abubwpos_get_option('abubwpos_icon_size');?>" class="abubwpos-icon-size" id="abubwpos-icon-size" /> PX
									</td>
								</tr>								
								
								<tr>
									<th scope="row">
										<label for="abubwpos-description-font-style"><?php _e('Author description font style', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<select name="abubwpos_options[abubwpos_description_font_style]" class="abubwpos-select-box abubwpos-description-font-style" id="abubwpos-description-font-style">
											<?php 
											if(!empty($abubwposbox_desc_style)){
												foreach ($abubwposbox_desc_style as $style_key => $desc_style) {
												?>
													<option value="<?php echo $style_key;?>" <?php selected(abubwpos_get_option('abubwpos_description_font_style'),$style_key);?>><?php echo $desc_style;?></option>
												<?php
												}
											}
											?>
										</select>
									</td>
								</tr>

								<tr>
									<td colspan="2" valign="top" scope="row">
										<input type="submit" id="abubwpos-settings-submit" name="abubwpos-settings-submit" class="button button-primary right" value="<?php _e('Save Changes','author-box-ultimate-by-wpos');?>" />
									</td>
								</tr>
							</tbody>
						 </table>

					</div><!-- .inside -->
				</div><!-- #general -->
			</div><!-- .meta-box-sortables ui-sortable -->
		</div><!-- .metabox-holder -->
	</div><!-- #abubwpos-general-settings -->

	<div id="abubwpos-typography-settings" class="post-box-container abubwpos-typography-settings">
		<div class="metabox-holder">
			<div class="meta-box-sortables ui-sortable">
				<div id="general" class="postbox">

					<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'Miscellaneous options', 'author-box-ultimate-by-wpos' ); ?></span>
						</h3>
						
						<div class="inside">
						
						<table class="form-table abubwpos-general-settings-tbl">
							<tbody>
								<tr>
									<th scope="row">
										<label for="abubwpos-enable-popup"><?php _e('Disable Font Awesome stylesheet', 'author-box-ultimate-by-wpos'); ?>:</label>
									</th>
									<td>
										<label class="abubwpos-check-switch abubwpos-options-check-switch"><input type="checkbox" name="abubwpos_options[abubwpos_load_fa]" value="1" class="abubwpos-options-check" <?php checked(abubwpos_get_option('abubwpos_load_fa'), 1 ); ?>/><div class="abubwpos-check-slider abubwpos-check-switch-round"></div></label>
									</td>
								</tr>								
								<tr>
									<td colspan="2" valign="top" scope="row">
										<input type="submit" id="abubwpos-settings-submit" name="abubwpos-settings-submit" class="button button-primary right" value="<?php _e('Save Changes','author-box-ultimate-by-wpos');?>" />
									</td>
								</tr>
							</tbody>
						 </table>

					</div><!-- .inside -->
				</div><!-- #general -->
			</div><!-- .meta-box-sortables ui-sortable -->
		</div><!-- .metabox-holder -->
	</div><!-- #abubwpos-general-settings -->


</form><!-- end .abubwpos-settings-form -->

</div><!-- end .abubwpos-settings -->
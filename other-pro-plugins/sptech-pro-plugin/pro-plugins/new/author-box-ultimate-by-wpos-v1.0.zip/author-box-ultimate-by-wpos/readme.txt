=== Author Box Ultimate by WPOS ===
Contributors: wponlinesupport, anoopranawat 
Requires at least: 3.1
Tested up to: 4.8
Author URI: http://wponlinesupport.com
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Author Box Ultimate adds a responsive author box at the end of your posts, showing the author name, author gravatar and author description.

== Description ==

Author Box Ultimate adds a responsive author box at the end of your posts, showing the author name, author gravatar and author description.

It also adds over 20+ social profile fields on WordPress user profile screen, allowing to display the author social icons.

= Main Features =

* Shows author gravatar, name, website, description and social icons
* Fully customizable to match your theme design (style, color, size and text options)
* Nice looking on desktop, laptop, tablet or mobile phones
* Automatically insert the author box at the end of your post

== Installation ==

1. Download the plugin (.zip file) on your hard drive.
2. Unzip the author-box-ultimate-by-wpos.zip file contents.
3. Upload the "author-box-ultimate-by-wpos" folder to the '/wp-content/plugins/' directory.
4. Activate the plugin through the 'Plugins' menu in WordPress.
5. A new sub menu item 'WPOS Author Box' will appear in your main menu.

== Changelog ==

= 1.0 =
* Initial release

== Upgrade Notice ==

= 1.0 =
* Initial release
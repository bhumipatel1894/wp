<div class="abubwpos-wrp abubwpos-clearfix abubwpos-design-2">
	<div class="abubwpos-medium-12 abubwpos-columns">
		<div class="abubwpos-avatar <?php echo $avatar_style;?>">
			<?php echo get_avatar( get_the_author_meta( 'user_email', $author_id ), '100' );?>
		</div>
	</div>
	<div class="abubwpos-medium-12 abubwpos-columns">
		<?php if(!empty($author_name)){?>
			<h4 class="abubwpos-authorname">
				<a href="<?php echo get_author_posts_url( $author_id );?>"><?php echo $author_name;?></a>
			</h4>
		<?php }	
		 if(!empty($author_description)){?>
			 <div class="abubwpos-desc">   
				<?php echo $author_description;?>   
			</div>
		<?php }
		if(!empty($author_website)){?>
			<div class="abubwpos-website">
				<i class="fa fa-external-link" aria-hidden="true"></i> &nbsp;&nbsp;<a href="<?php echo $author_website;?>" target="<?php echo $author_weblink_target;?>"><?php echo $author_website;?></a>
			</div>
		<?php }		
		if(!empty($abubwpos_email)){			
			?>
			<div class="abubwpos-email">
				<i class="fa fa-envelope-o" aria-hidden="true"></i> &nbsp;&nbsp;<?php echo $abubwpos_email;?>   
			</div>
		<?php }
		if(!empty($abubwpos_role)){?>
			<div class="abubwpos-role">
				<i class="fa fa-user-o" aria-hidden="true"></i> &nbsp;&nbsp;<?php echo $abubwpos_role;?>   
			</div>
		<?php }
		if(!empty($author_date_of_birth)){?>
			<div class="abubwpos-bdate">
				<i class="fa fa-calendar" aria-hidden="true"></i> &nbsp;&nbsp;<?php echo date( get_option('date_format'), strtotime($author_date_of_birth));?>   
			</div>
		<?php }?>
	</div>		
    <div class="abubwpos-clearfix"></div>
   <?php if(!empty( $users_social_links) && array_filter($users_social_links) && ($is_hide_social_icon != '1')){ ?>
    <div class="abubwpos-socials">
        <?php echo abubwpos_social_links($users_social_links);?>
    </div>
    <?php }?>
</div>
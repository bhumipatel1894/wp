<div class="abubwpos-wrp abubwpos-clearfix abubwpos-design-6">
	<div class="abubwpos-medium-3 abubwpos-columns">
		<div class="abubwpos-avatar <?php echo $avatar_style;?>">
			<?php echo get_avatar( get_the_author_meta( 'user_email', $author_id ), '100' );?>
		</div>
	</div>
	<div class="abubwpos-medium-9 abubwpos-columns">	
		<?php if(!empty($author_name)){?>
			<h4 class="abubwpos-authorname">
				<?php echo $author_name;?>
			</h4>
		<?php }
		if(!empty($author_description)){?>
			 <div class="abubwpos-desc">   
				<?php echo $author_description;?>   
			</div>
		<?php } ?>
		<ul class="abubwpos-list-inline">
			<li><a href="<?php echo get_author_posts_url( $author_id );?>"><?php  _e('All Posts','author-box-ultimate-by-wpos'); ?></a></li>
			<?php if(!empty($author_website)){ ?>			
				<li><a href="<?php echo $author_website;?>" target="<?php echo $author_weblink_target;?>"><?php  _e('Website','author-box-ultimate-by-wpos'); ?></a></li>	
			<?php }
			if(!empty($abubwpos_email)){ ?>			
				<li><a href="mailto:<?php echo $abubwpos_email;?>?Subject=Hello%20again" target="<?php echo $author_weblink_target;?>"><?php  _e('Email','author-box-ultimate-by-wpos'); ?></a></li>	
			<?php } 
			if(!empty($abubwpos_role)){?>
			<li><?php echo $abubwpos_role;?></li>	
			<?php } ?>					
		</ul>		
		
	</div>		
    <div class="abubwpos-clearfix"></div>
   <?php if(!empty( $users_social_links) && array_filter($users_social_links) && ($is_hide_social_icon != '1')){ ?>
    <div class="abubwpos-socials">
        <?php echo abubwpos_social_links($users_social_links);?>
    </div>
    <?php }?>
</div>
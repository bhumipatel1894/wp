<?php
/**
 * Visual Composer Class
 *
 * Handles the visual composer shortcode functionality of plugin
 *
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Wpspw_Vc {
	
	function __construct() {
		
		// Action to add 'wpspw_post' shortcode in vc
		add_action( 'vc_before_init', array($this, 'wpspw_pro_integrate_grid_vc') );

		// Action to add 'wpspw_recent_post' shortcode in vc
		add_action( 'vc_before_init', array($this, 'wpspw_pro_integrate_recent_grid_vc') );
	
		// Action to add 'wpspw_post_gridbox' shortcode in vc
		add_action( 'vc_before_init', array($this, 'wpspw_pro_integrate_gridbox_vc') );	

		// Action to add 'wpspw_post_list' shortcode in vc
		add_action( 'vc_before_init', array($this, 'wpspw_pro_integrate_list_vc') );	
	
		// Action to add 'wpspw_recent_post_slider' shortcode in vc
		add_action( 'vc_before_init', array($this, 'wpspw_pro_integrate_gridbox_slider_vc') );

		// Action to add 'wpspw_gridbox_slider' shortcode in vc
		add_action( 'vc_before_init', array($this, 'wpspw_pro_integrate_slider_vc') );

		// Action to add 'wpspw_masonry' shortcode in vc
		add_action( 'vc_before_init', array($this, 'wpspw_pro_integrate_masonry_vc') );

				// Action to add 'wpspw_ticker' shortcode in vc
		add_action( 'vc_before_init', array($this, 'wpspw_pro_integrate_ticker_vc') );
	}

	/**
	 * Function to add 'wpspw_post' shortcode in vc
	 * 
	 * @package Blog Designer - Post and Widget Pro
	 * @since 1.0.0
	 */
	function wpspw_pro_integrate_grid_vc() {
		vc_map( 
			array(
				'name' 			=> __( 'WPOS - Blog Grid', 'blog-designer-for-post-and-widget' ),
				'base' 			=> 'wpspw_post',
				'icon' 			=> 'icon-wpb-wp',
				'class' 		=> '',
				'category' 		=> __( 'Content', 'blog-designer-for-post-and-widget'),
				'description' 	=> __( 'Display post grid.', 'blog-designer-for-post-and-widget' ),
				'params' 		=> array(
					// General settings
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Design', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'design',
						'value' 		=> array(
							__( 'Grid Design 1', 'blog-designer-for-post-and-widget' ) 	=> 'design-1',
							__( 'Grid Design 2', 'blog-designer-for-post-and-widget' ) 	=> 'design-2',
							__( 'Grid Design 3', 'blog-designer-for-post-and-widget' ) 	=> 'design-3',
							__( 'Grid Design 4', 'blog-designer-for-post-and-widget' ) 	=> 'design-4',
							__( 'Grid Design 5', 'blog-designer-for-post-and-widget' ) 	=> 'design-5',
							__( 'Grid Design 6', 'blog-designer-for-post-and-widget' ) 	=> 'design-6',
							__( 'Grid Design 7', 'blog-designer-for-post-and-widget' ) 	=> 'design-7',
							__( 'Grid Design 8', 'blog-designer-for-post-and-widget' ) 	=> 'design-8',
							__( 'Grid Design 9', 'blog-designer-for-post-and-widget' ) 	=> 'design-9',
							__( 'Grid Design 10', 'blog-designer-for-post-and-widget' ) 	=> 'design-10',
							__( 'Grid Design 11', 'blog-designer-for-post-and-widget' ) 	=> 'design-11',
							__( 'Grid Design 12', 'blog-designer-for-post-and-widget' ) 	=> 'design-12',
							__( 'Grid Design 13', 'blog-designer-for-post-and-widget' ) 	=> 'design-13',
							__( 'Grid Design 14', 'blog-designer-for-post-and-widget' ) 	=> 'design-14',
							__( 'Grid Design 15', 'blog-designer-for-post-and-widget' ) 	=> 'design-15',
							__( 'Grid Design 16', 'blog-designer-for-post-and-widget' ) 	=> 'design-16',
							__( 'Grid Design 17', 'blog-designer-for-post-and-widget' ) 	=> 'design-17',
							__( 'Grid Design 18', 'blog-designer-for-post-and-widget' ) 	=> 'design-18',
							__( 'Grid Design 19', 'blog-designer-for-post-and-widget' ) 	=> 'design-19',
							__( 'Grid Design 20', 'blog-designer-for-post-and-widget' ) 	=> 'design-20',
							__( 'Grid Design 21', 'blog-designer-for-post-and-widget' ) 	=> 'design-21',
							__( 'Grid Design 22', 'blog-designer-for-post-and-widget' ) 	=> 'design-22',
							__( 'Grid Design 23', 'blog-designer-for-post-and-widget' ) 	=> 'design-23',
							__( 'Grid Design 24', 'blog-designer-for-post-and-widget' ) 	=> 'design-24',
							__( 'Grid Design 25', 'blog-designer-for-post-and-widget' ) 	=> 'design-25',
							__( 'Grid Design 26', 'blog-designer-for-post-and-widget' ) 	=> 'design-26',
							__( 'Grid Design 27', 'blog-designer-for-post-and-widget' ) 	=> 'design-27',
							__( 'Grid Design 28', 'blog-designer-for-post-and-widget' ) 	=> 'design-28',
							__( 'Grid Design 29', 'blog-designer-for-post-and-widget' ) 	=> 'design-29',
							__( 'Grid Design 30', 'blog-designer-for-post-and-widget' ) 	=> 'design-30',
							__( 'Grid Design 31', 'blog-designer-for-post-and-widget' ) 	=> 'design-31',
							__( 'Grid Design 32', 'blog-designer-for-post-and-widget' ) 	=> 'design-32',
							__( 'Grid Design 33', 'blog-designer-for-post-and-widget' ) 	=> 'design-33',
							__( 'Grid Design 34', 'blog-designer-for-post-and-widget' ) 	=> 'design-34',
							__( 'Grid Design 35', 'blog-designer-for-post-and-widget' ) 	=> 'design-35',
							__( 'Grid Design 36', 'blog-designer-for-post-and-widget' ) 	=> 'design-36',
							__( 'Grid Design 37', 'blog-designer-for-post-and-widget' ) 	=> 'design-37',
							__( 'Grid Design 38', 'blog-designer-for-post-and-widget' ) 	=> 'design-38',
							__( 'Grid Design 39', 'blog-designer-for-post-and-widget' ) 	=> 'design-39',
							__( 'Grid Design 40', 'blog-designer-for-post-and-widget' ) 	=> 'design-40',
							__( 'Grid Design 41', 'blog-designer-for-post-and-widget' ) 	=> 'design-41',
							__( 'Grid Design 42', 'blog-designer-for-post-and-widget' ) 	=> 'design-42',
							__( 'Grid Design 43', 'blog-designer-for-post-and-widget' ) 	=> 'design-43',
							__( 'Grid Design 44', 'blog-designer-for-post-and-widget' ) 	=> 'design-44',
							__( 'Grid Design 45', 'blog-designer-for-post-and-widget' ) 	=> 'design-45',
							__( 'Grid Design 46', 'blog-designer-for-post-and-widget' ) 	=> 'design-46',
							__( 'Grid Design 47', 'blog-designer-for-post-and-widget' ) 	=> 'design-47',
							__( 'Grid Design 48', 'blog-designer-for-post-and-widget' ) 	=> 'design-48',
							__( 'Grid Design 49', 'blog-designer-for-post-and-widget' ) 	=> 'design-49',
							__( 'Grid Design 50', 'blog-designer-for-post-and-widget' ) 	=> 'design-50',
							),
						'description' 	=> __( 'Choose grid design.', 'blog-designer-for-post-and-widget' ),
						'admin_label' 	=> true,
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Author', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_author',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Author.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Date', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_date',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Date.', 'blog-designer-for-post-and-widget' ),
						),

					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Content', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_content',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Content.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Full Content', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_full_content',
						'value' 		=> array(
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							),
						'description' 	=> __( 'Show Full Content.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Content Word Limit', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'content_words_limit',
						'value' 		=> '20',
						'description' 	=> __( 'Enter Content Word Limit', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Read More', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_read_more',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Read More.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Pagination', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'pagination',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Pagination.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Pagination Type', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'pagination_type',
						'value' 		=> array(
							__( 'Numeric', 'blog-designer-for-post-and-widget' ) 		=> 'numeric',
							__( 'Next-Prev', 'blog-designer-for-post-and-widget' ) 	=> 'prev-next',
							),
						'description' 	=> __( 'Pagination Type', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Image Size', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'media_size',
						'value' 		=> array(
							__( 'Large', 'blog-designer-for-post-and-widget' ) 		=> 'large',
							__( 'Full', 'blog-designer-for-post-and-widget' ) 	=> 'full',
							__( 'Medium', 'blog-designer-for-post-and-widget' ) 	=> 'medium',
							__( 'Thumbnail', 'blog-designer-for-post-and-widget' ) 	=> 'thumbnail',
							),
						'description' 	=> __( 'Set Image Size', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Image Fit', 'blog-designer-for-post-and-widget'),
						'param_name' 	=> 'image_fit',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Set Image Fit.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Tags', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_tags',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Tags.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Comments', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_comments',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Comments.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Link Behavior', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'link_target',
						'value' 		=> array(
							__( 'Self', 'blog-designer-for-post-and-widget' ) 		=> 'self',
							__( 'blank', 'blog-designer-for-post-and-widget' ) 	=> '_blank',
							),
						'description' 	=> __( 'Link Target.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Content Tail', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'content_tail',
						'value' 		=> '...',
						'description' 	=> __( 'Enter Content Tail to display', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Image Height', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'image_height',
						'value' 		=> '',
						'description' 	=> __( 'Enter Image Height', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Read More Text', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'read_more_text',
						'value' 		=> '',
						'description' 	=> __( 'Enter Read More Text', 'blog-designer-for-post-and-widget' ),
						),

				// Data Settings
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Total Items Limit', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'limit',
						'value' 		=> 20,
						'description' 	=> __( 'Enter number to be displayed. Enter -1 to display all.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Grid', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'grid',
						'value' 		=> 1,
						'description' 	=> __( 'Enter number to be displayed post per row.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Post Order By', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'orderby',
						'value' 		=> array(
											__( 'Post Date', 'blog-designer-for-post-and-widget' ) 			=> 'date',
											__( 'Post ID', 'blog-designer-for-post-and-widget' ) 				=> 'ID',
											__( 'Post Author', 'blog-designer-for-post-and-widget' ) 			=> 'author',
											__( 'Post Title', 'blog-designer-for-post-and-widget' ) 			=> 'title',
											__( 'Post Modified Date', 'blog-designer-for-post-and-widget' ) 	=> 'modified',
											__( 'Random', 'blog-designer-for-post-and-widget' ) 				=> 'rand',
											__( 'Menu Order', 'blog-designer-for-post-and-widget' ) 			=> 'menu_order',
											),
						'description' 	=> __( 'Select order type.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' )
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Order', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'order',
						'value' 		=> array(
												__( 'Descending', 'blog-designer-for-post-and-widget' ) 	=> 'desc',
												__( 'Ascending', 'blog-designer-for-post-and-widget' ) 	=> 'asc',
											),
						'description' 	=> __( 'Post Order.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' )
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Category', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'category',
						'value' 		=> '',
						'description' 	=> __( 'Enter category id to display Posts categories wise comma separated.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type'			=> 'dropdown',
						'class'			=> '',
						'heading'		=> __( 'Disply Child Category','blog-designer-for-post-and-widget'),
						'param_name'	=> 'include_cat_child',
						'value'			=> array(
							__('True', 'blog-designer-for-post-and-widget')		=> 'true',
							__('False', 'blog-designer-for-post-and-widget')	=> 'false',
							),
						'description'	=> __( 'Display Child Category.','blog-designer-for-post-and-widget'),
						'group'		=> __( 'Data Settings','blog-designer-for-post-and-widget'),

						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Show Category Name', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_category_name',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Category Name.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Category Name', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'category_name',
						'value' 		=> '',
						'description' 	=> __( 'Category Name.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Exclude Category', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'exclude_cat',
						'value' 		=> '',
						'description' 	=> __( 'Exclude post category. Works only if `Category` field is empty. you can exclude with comma separated.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Display Specific Posts', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'posts',
						'value' 		=> '',
						'description' 	=> __( 'Enter post id which you only want to display with comma separated.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Exclude Post', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'exclude_post',
						'value' 		=> '',
						'description' 	=> __( 'Enter post id which you do not want to display with comma separated.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
				),
			)
		);
	}

/******************************************************/
	/**
	 * Function to add 'wpspw_recent_post' shortcode in vc
	 * 
	 * @package Blog Designer - Post and Widget Pro
	 * @since 1.0.0
	 */
	function wpspw_pro_integrate_recent_grid_vc() {
		vc_map( 
			array(
				'name' 			=> __( 'WPOS - Recent Blog Grid', 'blog-designer-for-post-and-widget' ),
				'base' 			=> 'wpspw_recent_post',
				'icon' 			=> 'icon-wpb-wp',
				'class' 		=> '',
				'category' 		=> __( 'Content', 'blog-designer-for-post-and-widget'),
				'description' 	=> __( 'Display recent post grid.', 'blog-designer-for-post-and-widget' ),
				'params' 		=> array(

				// General settings
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Design', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'design',
						'value' 		=> array(
							__( 'Recent Design 1', 'blog-designer-for-post-and-widget' ) 	=> 'design-1',
							__( 'Recent Design 2', 'blog-designer-for-post-and-widget' ) 	=> 'design-2',
							__( 'Recent Design 3', 'blog-designer-for-post-and-widget' ) 	=> 'design-3',
							__( 'Recent Design 4', 'blog-designer-for-post-and-widget' ) 	=> 'design-4',
							__( 'Recent Design 5', 'blog-designer-for-post-and-widget' ) 	=> 'design-5',
							__( 'Recent Design 6', 'blog-designer-for-post-and-widget' ) 	=> 'design-6',
							__( 'Recent Design 7', 'blog-designer-for-post-and-widget' ) 	=> 'design-7',
							__( 'Recent Design 8', 'blog-designer-for-post-and-widget' ) 	=> 'design-8',
							__( 'Recent Design 9', 'blog-designer-for-post-and-widget' ) 	=> 'design-9',
							__( 'Recent Design 10', 'blog-designer-for-post-and-widget' ) 	=> 'design-10',
							__( 'Recent Design 11', 'blog-designer-for-post-and-widget' ) 	=> 'design-11',
							__( 'Recent Design 12', 'blog-designer-for-post-and-widget' ) 	=> 'design-12',
							__( 'Recent Design 13', 'blog-designer-for-post-and-widget' ) 	=> 'design-13',
							__( 'Recent Design 14', 'blog-designer-for-post-and-widget' ) 	=> 'design-14',
							__( 'Recent Design 15', 'blog-designer-for-post-and-widget' ) 	=> 'design-15',
							__( 'Recent Design 16', 'blog-designer-for-post-and-widget' ) 	=> 'design-16',
							__( 'Recent Design 17', 'blog-designer-for-post-and-widget' ) 	=> 'design-17',
							__( 'Recent Design 18', 'blog-designer-for-post-and-widget' ) 	=> 'design-18',
							__( 'Recent Design 19', 'blog-designer-for-post-and-widget' ) 	=> 'design-19',
							__( 'Recent Design 20', 'blog-designer-for-post-and-widget' ) 	=> 'design-20',
							__( 'Recent Design 21', 'blog-designer-for-post-and-widget' ) 	=> 'design-21',
							__( 'Recent Design 22', 'blog-designer-for-post-and-widget' ) 	=> 'design-22',
							__( 'Recent Design 23', 'blog-designer-for-post-and-widget' ) 	=> 'design-23',
							__( 'Recent Design 24', 'blog-designer-for-post-and-widget' ) 	=> 'design-24',
							__( 'Recent Design 25', 'blog-designer-for-post-and-widget' ) 	=> 'design-25',
							__( 'Recent Design 26', 'blog-designer-for-post-and-widget' ) 	=> 'design-26',
							__( 'Recent Design 27', 'blog-designer-for-post-and-widget' ) 	=> 'design-27',
							__( 'Recent Design 28', 'blog-designer-for-post-and-widget' ) 	=> 'design-28',
							__( 'Recent Design 29', 'blog-designer-for-post-and-widget' ) 	=> 'design-29',
							__( 'Recent Design 30', 'blog-designer-for-post-and-widget' ) 	=> 'design-30',
							__( 'Recent Design 31', 'blog-designer-for-post-and-widget' ) 	=> 'design-31',
							__( 'Recent Design 32', 'blog-designer-for-post-and-widget' ) 	=> 'design-32',
							__( 'Recent Design 33', 'blog-designer-for-post-and-widget' ) 	=> 'design-33',
							__( 'Recent Design 34', 'blog-designer-for-post-and-widget' ) 	=> 'design-34',
							__( 'Recent Design 35', 'blog-designer-for-post-and-widget' ) 	=> 'design-35',
							__( 'Recent Design 36', 'blog-designer-for-post-and-widget' ) 	=> 'design-36',
							__( 'Recent Design 37', 'blog-designer-for-post-and-widget' ) 	=> 'design-37',
							__( 'Recent Design 38', 'blog-designer-for-post-and-widget' ) 	=> 'design-38',
							__( 'Recent Design 39', 'blog-designer-for-post-and-widget' ) 	=> 'design-39',
							__( 'Recent Design 40', 'blog-designer-for-post-and-widget' ) 	=> 'design-40',
							__( 'Recent Design 41', 'blog-designer-for-post-and-widget' ) 	=> 'design-41',
							__( 'Recent Design 42', 'blog-designer-for-post-and-widget' ) 	=> 'design-42',
							__( 'Recent Design 43', 'blog-designer-for-post-and-widget' ) 	=> 'design-43',
							__( 'Recent Design 44', 'blog-designer-for-post-and-widget' ) 	=> 'design-44',
							__( 'Recent Design 45', 'blog-designer-for-post-and-widget' ) 	=> 'design-45',
							__( 'Recent Design 46', 'blog-designer-for-post-and-widget' ) 	=> 'design-46',
							__( 'Recent Design 47', 'blog-designer-for-post-and-widget' ) 	=> 'design-47',
							__( 'Recent Design 48', 'blog-designer-for-post-and-widget' ) 	=> 'design-48',
							__( 'Recent Design 49', 'blog-designer-for-post-and-widget' ) 	=> 'design-49',
							__( 'Recent Design 50', 'blog-designer-for-post-and-widget' ) 	=> 'design-50',
							),
						'description' 	=> __( 'Choose recent grid design.', 'blog-designer-for-post-and-widget' ),
						'admin_label' 	=> true,
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Author', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_author',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Author.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Date', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_date',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Date.', 'blog-designer-for-post-and-widget' ),
						),

					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Content', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_content',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Content.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Full Content', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_full_content',
						'value' 		=> array(
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							),
						'description' 	=> __( 'Show Full Content.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Read More', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_read_more',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Read More.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Content Word Limit', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'content_words_limit',
						'value' 		=> '20',
						'description' 	=> __( 'Enter Content Word Limit', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Content Tail', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'content_tail',
						'value' 		=> '...',
						'description' 	=> __( 'Enter Content Tail to display', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Tags', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_tags',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Tags.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Comments', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_comments',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Comments.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Link Behavior', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'link_target',
						'value' 		=> array(
							__( 'Self', 'blog-designer-for-post-and-widget' ) 		=> 'self',
							__( 'blank', 'blog-designer-for-post-and-widget' ) 	=> '_blank',
							),
						'description' 	=> __( 'Link Target.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Image Height', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'image_height',
						'value' 		=> '',
						'description' 	=> __( 'Enter Image Height', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Read More Text', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'read_more_text',
						'value' 		=> '',
						'description' 	=> __( 'Enter Read More Text', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Set Image Size', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'media_size',
						'value' 		=> array(
							__( 'Large', 'blog-designer-for-post-and-widget' ) 		=> 'large',
							__( 'Full', 'blog-designer-for-post-and-widget' ) 	=> 'full',
							__( 'Medium', 'blog-designer-for-post-and-widget' ) 	=> 'medium',
							__( 'Thumbnail', 'blog-designer-for-post-and-widget' ) 	=> 'thumbnail',
							),
						'description' 	=> __( 'Set Image Size by values', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Image Fit', 'blog-designer-for-post-and-widget'),
						'param_name' 	=> 'image_fit',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Set Image Fit.', 'blog-designer-for-post-and-widget' ),
						),
			// Data Settings
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Total Items Limit', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'limit',
						'value' 		=> 20,
						'description' 	=> __( 'Enter number to be displayed. Enter -1 to display all.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Grid', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'grid',
						'value' 		=> 1,
						'description' 	=> __( 'Enter number to be displayed post per row.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Post Order By', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'orderby',
						'value' 		=> array(
												__( 'Post Date', 'blog-designer-for-post-and-widget' ) 			=> 'date',
												__( 'Post ID', 'blog-designer-for-post-and-widget' ) 				=> 'ID',
												__( 'Post Author', 'blog-designer-for-post-and-widget' ) 			=> 'author',
												__( 'Post Title', 'blog-designer-for-post-and-widget' ) 			=> 'title',
												__( 'Post Modified Date', 'blog-designer-for-post-and-widget' ) 	=> 'modified',
												__( 'Random', 'blog-designer-for-post-and-widget' ) 				=> 'rand',
												__( 'Menu Order', 'blog-designer-for-post-and-widget' ) 			=> 'menu_order',
												),
						'description' 	=> __( 'Select order type.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' )
						),									
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Order', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'order',
						'value' 		=> array(
												__( 'Descending', 'blog-designer-for-post-and-widget' ) 	=> 'desc',
												__( 'Ascending', 'blog-designer-for-post-and-widget' ) 	=> 'asc',
											),
						'description' 	=> __( 'Post Order.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' )
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Category', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'category',
						'value' 		=> '',
						'description' 	=> __( 'Enter category id to display Posts categories wise with comma separated.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Display Child Category', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'include_cat_child',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Display child category of Parent Category.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Show Category Name', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_category_name',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Category Name.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Category Name', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'category_name',
						'value' 		=> '',
						'description' 	=> __( 'Category Name.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Exclude Category', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'exclude_cat',
						'value' 		=> '',
						'description' 	=> __( 'Exclude Post category. Works only if `Category` field is empty. you can exclude with comma separated.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Display Specific Posts', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'posts',
						'value' 		=> '',
						'description' 	=> __( 'Enter post id which you only want to display with comma separated.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Exclude Post', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'exclude_post',
						'value' 		=> '',
						'description' 	=> __( 'Enter post id which you do not want to display with comma separated.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Query Offset', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'query_offset',
						'value' 		=> null,
						'description' 	=> __( 'Enter number of post that you want to skip', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
				),
			)
		);
	}

/*********************************************************************************/

	/**
	 * Function to add 'wpspw_post_gridbox' shortcode in vc
	 * 
	 * @package Blog Designer - Post and Widget Pro
	 * @since 1.0.0
	 */
	function wpspw_pro_integrate_gridbox_vc() {
		vc_map( 
			array(
				'name' 			=> __( 'WPOS - Blog Grid Box', 'blog-designer-for-post-and-widget' ),
				'base' 			=> 'wpspw_post_gridbox',
				'icon' 			=> 'icon-wpb-wp',
				'class' 		=> '',
				'category' 		=> __( 'Content', 'blog-designer-for-post-and-widget'),
				'description' 	=> __( 'Display Blog gridbox.', 'blog-designer-for-post-and-widget' ),
				'params' 		=> array(

				// General settings
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Design', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'design',
						'value' 		=> array(
							__( 'Gridbox Design 1', 'blog-designer-for-post-and-widget' ) 	=> 'design-1',
							__( 'Gridbox Design 2', 'blog-designer-for-post-and-widget' ) 	=> 'design-2',
							__( 'Gridbox Design 3', 'blog-designer-for-post-and-widget' ) 	=> 'design-3',
							__( 'Gridbox Design 4', 'blog-designer-for-post-and-widget' ) 	=> 'design-4',
							__( 'Gridbox Design 5', 'blog-designer-for-post-and-widget' ) 	=> 'design-5',
							__( 'Gridbox Design 6', 'blog-designer-for-post-and-widget' ) 	=> 'design-6',
							__( 'Gridbox Design 7', 'blog-designer-for-post-and-widget' ) 	=> 'design-7',
							__( 'Gridbox Design 8', 'blog-designer-for-post-and-widget' ) 	=> 'design-8',
							__( 'Gridbox Design 9', 'blog-designer-for-post-and-widget' ) 	=> 'design-9',
							__( 'Gridbox Design 10', 'blog-designer-for-post-and-widget' ) 	=> 'design-10',
							__( 'Gridbox Design 11', 'blog-designer-for-post-and-widget' ) 	=> 'design-11',
							__( 'Gridbox Design 12', 'blog-designer-for-post-and-widget' ) 	=> 'design-12',
							__( 'Gridbox Design 13', 'blog-designer-for-post-and-widget' ) 	=> 'design-13',
							),
						'description' 	=> __( 'Choose Blog gridbox design.', 'blog-designer-for-post-and-widget' ),
						'admin_label' 	=> true,
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Author', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_author',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Author.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Date', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_date',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Date.', 'blog-designer-for-post-and-widget' ),
						),

					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Content', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_content',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Content.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Full Content', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_full_content',
						'value' 		=> array(
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							),
						'description' 	=> __( 'Show Full Content.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Read More', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_read_more',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Read More.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Content Word Limit', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'content_words_limit',
						'value' 		=> '20',
						'description' 	=> __( 'Enter Content Word Limit', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Content Tail', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'content_tail',
						'value' 		=> '...',
						'description' 	=> __( 'Enter Content Tail to display', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Tags', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_tags',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Tags.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Comments', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_comments',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Comments.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Link Behavior', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'link_target',
						'value' 		=> array(
							__( 'Self', 'blog-designer-for-post-and-widget' ) 		=> 'self',
							__( 'blank', 'blog-designer-for-post-and-widget' ) 	=> '_blank',
							),
						'description' 	=> __( 'Link Target.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Image Height', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'image_height',
						'value' 		=> '',
						'description' 	=> __( 'Enter Image Height', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Read More Text', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'read_more_text',
						'value' 		=> '',
						'description' 	=> __( 'Enter Read More Text', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Image Fit', 'blog-designer-for-post-and-widget'),
						'param_name' 	=> 'image_fit',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Set Image Fit.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Pagination', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'pagination',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Pagination.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Pagination Type', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'pagination_type',
						'value' 		=> array(
							__( 'Numeric', 'blog-designer-for-post-and-widget' ) 		=> 'numeric',
							__( 'Next-Prev', 'blog-designer-for-post-and-widget' ) 	=> 'prev-next',
							),
						'description' 	=> __( 'Pagination Type', 'blog-designer-for-post-and-widget' ),
						),
					// Data Settings
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Total Items Limit', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'limit',
						'value' 		=> 20,
						'description' 	=> __( 'Enter number to be displayed. Enter -1 to display all.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Post Order By', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'orderby',
						'value' 		=> array(
												__( 'Post Date', 'blog-designer-for-post-and-widget' ) 			=> 'date',
												__( 'Post ID', 'blog-designer-for-post-and-widget' ) 				=> 'ID',
												__( 'Post Author', 'blog-designer-for-post-and-widget' ) 			=> 'author',
												__( 'Post Title', 'blog-designer-for-post-and-widget' ) 			=> 'title',
												__( 'Post Modified Date', 'blog-designer-for-post-and-widget' ) 	=> 'modified',
												__( 'Random', 'blog-designer-for-post-and-widget' ) 				=> 'rand',
												__( 'Menu Order', 'blog-designer-for-post-and-widget' ) 			=> 'menu_order',
												),
						'description' 	=> __( 'Select order type.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' )
						),									
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Order', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'order',
						'value' 		=> array(
												__( 'Descending', 'blog-designer-for-post-and-widget' ) 	=> 'desc',
												__( 'Ascending', 'blog-designer-for-post-and-widget' ) 	=> 'asc',
											),
						'description' 	=> __( 'Post Order.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' )
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Category', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'category',
						'value' 		=> '',
						'description' 	=> __( 'Enter category id to display Posts categories wise with comma separated.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Display Child Category', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'include_cat_child',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Display child category or not.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Show Category Name', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_category_name',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Category Name.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Category Name', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'category_name',
						'value' 		=> '',
						'description' 	=> __( 'Category Name.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Exclude Category', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'exclude_cat',
						'value' 		=> '',
						'description' 	=> __( 'Exclude Post category. Works only if `Category` field is empty.you can exclude with comma separated', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Display Specific Posts', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'posts',
						'value' 		=> '',
						'description' 	=> __( 'Enter post id which you only want to display with comma separated.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Exclude Post', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'exclude_post',
						'value' 		=> '',
						'description' 	=> __( 'Enter post id which you do not want to display with comma separated.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
				),
			)
		);
	}

/***************************************************************/

	/**
	 * Function to add 'wpspw_post_list' shortcode in vc
	 * 
	 * @package Blog Designer - Post and Widget Pro
	 * @since 1.0.0
	 */
	function wpspw_pro_integrate_list_vc() {
		vc_map( 
			array(
				'name' 			=> __( 'WPOS-Blog List View', 'blog-designer-for-post-and-widget' ),
				'base' 			=> 'wpspw_post_list',
				'icon' 			=> 'icon-wpb-wp',
				'class' 		=> '',
				'category' 		=> __( 'Content', 'blog-designer-for-post-and-widget'),
				'description' 	=> __( 'Display Blog List View.', 'blog-designer-for-post-and-widget' ),
				'params' 		=> array(
					// General settings
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Design', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'design',
						'value' 		=> array(
							__( 'List Design 1', 'blog-designer-for-post-and-widget' ) 	=> 'design-1',
							__( 'List Design 2', 'blog-designer-for-post-and-widget' ) 	=> 'design-2',
							__( 'List Design 3', 'blog-designer-for-post-and-widget' ) 	=> 'design-3',
							__( 'List Design 4', 'blog-designer-for-post-and-widget' ) 	=> 'design-4',
							__( 'List Design 5', 'blog-designer-for-post-and-widget' ) 	=> 'design-5',
							__( 'List Design 6', 'blog-designer-for-post-and-widget' ) 	=> 'design-6',
							__( 'List Design 7', 'blog-designer-for-post-and-widget' ) 	=> 'design-7',
							__( 'List Design 8', 'blog-designer-for-post-and-widget' ) 	=> 'design-8',
							),
						'description' 	=> __( 'Choose List design.', 'blog-designer-for-post-and-widget' ),
						'admin_label' 	=> true,
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Author', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_author',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 	=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Author.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Date', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_date',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Date.', 'blog-designer-for-post-and-widget' ),
						),

					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Content', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_content',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Content.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Full Content', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_full_content',
						'value' 		=> array(
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							),
						'description' 	=> __( 'Show Full Content.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Content Word Limit', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'content_words_limit',
						'value' 		=> '20',
						'description' 	=> __( 'Enter Content Word Limit', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Read More', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_read_more',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Read More.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Pagination', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'pagination',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Pagination.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Pagination Type', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'pagination_type',
						'value' 		=> array(
							__( 'Numeric', 'blog-designer-for-post-and-widget' ) 		=> 'numeric',
							__( 'Next-Prev', 'blog-designer-for-post-and-widget' ) 	=> 'prev-next',
							),
						'description' 	=> __( 'Pagination Type', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Image Size', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'media_size',
						'value' 		=> array(
							__( 'Large', 'blog-designer-for-post-and-widget' ) 		=> 'large',
							__( 'Full', 'blog-designer-for-post-and-widget' ) 	=> 'full',
							__( 'Medium', 'blog-designer-for-post-and-widget' ) 	=> 'medium',
							__( 'Thumbnail', 'blog-designer-for-post-and-widget' ) 	=> 'thumbnail',
							),
						'description' 	=> __( 'Set Image Size', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Image Fit', 'blog-designer-for-post-and-widget'),
						'param_name' 	=> 'image_fit',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Set Image Fit.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Tags', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_tags',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Tags.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Comments', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_comments',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Comments.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Link Behavior', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'link_target',
						'value' 		=> array(
							__( 'Self', 'blog-designer-for-post-and-widget' ) 		=> 'self',
							__( 'blank', 'blog-designer-for-post-and-widget' ) 	=> '_blank',
							),
						'description' 	=> __( 'Link Target.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Content Tail', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'content_tail',
						'value' 		=> '...',
						'description' 	=> __( 'Enter Content Tail to display', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Image Height', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'image_height',
						'value' 		=> '',
						'description' 	=> __( 'Enter Image Height', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Read More Text', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'read_more_text',
						'value' 		=> '',
						'description' 	=> __( 'Enter Read More Text', 'blog-designer-for-post-and-widget' ),
						),

				// Data Settings
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Total Items Limit', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'limit',
						'value' 		=> 20,
						'description' 	=> __( 'Enter number to be displayed. Enter -1 to display all.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Post Order By', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'orderby',
						'value' 		=> array(
											__( 'Post Date', 'blog-designer-for-post-and-widget' ) 			=> 'date',
											__( 'Post ID', 'blog-designer-for-post-and-widget' ) 				=> 'ID',
											__( 'Post Author', 'blog-designer-for-post-and-widget' ) 			=> 'author',
											__( 'Post Title', 'blog-designer-for-post-and-widget' ) 			=> 'title',
											__( 'Post Modified Date', 'blog-designer-for-post-and-widget' ) 	=> 'modified',
											__( 'Random', 'blog-designer-for-post-and-widget' ) 				=> 'rand',
											__( 'Menu Order', 'blog-designer-for-post-and-widget' ) 			=> 'menu_order',
											),
						'description' 	=> __( 'Select order type.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' )
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Order', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'order',
						'value' 		=> array(
												__( 'Descending', 'blog-designer-for-post-and-widget' ) 	=> 'desc',
												__( 'Ascending', 'blog-designer-for-post-and-widget' ) 	=> 'asc',
											),
						'description' 	=> __( 'Post Order.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' )
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Category', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'category',
						'value' 		=> '',
						'description' 	=> __( 'Enter category id to display Posts categories wise with comma separated.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type'			=> 'dropdown',
						'class'			=> '',
						'heading'		=> __( 'Disply Child Category','blog-designer-for-post-and-widget'),
						'param_name'	=> 'include_cat_child',
						'value'			=> array(
							__('True', 'blog-designer-for-post-and-widget')		=> 'true',
							__('False', 'blog-designer-for-post-and-widget')	=> 'false',
							),
						'description'	=> __( 'Display Child Category.','blog-designer-for-post-and-widget'),
						'group'		=> __( 'Data Settings','blog-designer-for-post-and-widget'),

						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Show Category Name', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_category_name',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Category Name.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Category Name', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'category_name',
						'value' 		=> '',
						'description' 	=> __( 'Category Name.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Exclude Category', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'exclude_cat',
						'value' 		=> '',
						'description' 	=> __( 'Exclude post category. Works only if `Category` field is empty.you can exculde with comma separated', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Display Specific Posts', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'posts',
						'value' 		=> '',
						'description' 	=> __( 'Enter post id which you only want to display with comma separated.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Exclude Post', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'exclude_post',
						'value' 		=> '',
						'description' 	=> __( 'Enter post id which you do not want to display with comma separated.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
				),
			)
		);
	}

/***************************************************************************/

	/**
	 * Function to add 'wpspw_gridbox_slider' shortcode in vc
	 * 
	 * @package Blog Designer - Post and Widget Pro
	 * @since 1.0.0
	 */

	function wpspw_pro_integrate_gridbox_slider_vc() {
		vc_map( 
			array(
				'name' 			=> __( 'Blog Gridbox Slider', 'blog-designer-for-post-and-widget' ),
				'base' 			=> 'wpspw_gridbox_slider',
				'icon' 			=> 'icon-wpb-wp',
				'class' 		=> '',
				'category' 		=> __( 'Content', 'blog-designer-for-post-and-widget'),
				'description' 	=> __( 'Display Blog Gridbox slider.', 'blog-designer-for-post-and-widget' ),
				'params' 	=> array(
			// General settings
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Design', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'design',
						'value' 		=> array(
							__( 'Gridbox Slider Design 1', 'blog-designer-for-post-and-widget' ) 	=> 'design-1',
							__( 'Gridbox Slider Design 2', 'blog-designer-for-post-and-widget' ) 	=> 'design-2',
							__( 'Gridbox Slider Design 3', 'blog-designer-for-post-and-widget' ) 	=> 'design-3',
							__( 'Gridbox Slider Design 4', 'blog-designer-for-post-and-widget' ) 	=> 'design-4',
							__( 'Gridbox Slider Design 5', 'blog-designer-for-post-and-widget' ) 	=> 'design-5',
							__( 'Gridbox Slider Design 6', 'blog-designer-for-post-and-widget' ) 	=> 'design-6',
							__( 'Gridbox Slider Design 7', 'blog-designer-for-post-and-widget' ) 	=> 'design-7',
							__( 'Gridbox Slider Design 8', 'blog-designer-for-post-and-widget' ) 	=> 'design-8',
							),
						'description' 	=> __( 'Choose Slider design.', 'blog-designer-for-post-and-widget' ),
						'admin_label' 	=> true,
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Author', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_author',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Author.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Date', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_date',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Date.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Content', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_content',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Content.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Read More', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_read_more',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Read More.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Content Word Limit', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'content_words_limit',
						'value' 		=> '20',
						'description' 	=> __( 'Enter Content Word Limit', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Content Tail', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'content_tail',
						'value' 		=> '...',
						'description' 	=> __( 'Enter Content Tail to display', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Tags', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_tags',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Tags.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Comments', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_comments',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Comments.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Link Behavior', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'link_target',
						'value' 		=> array(
							__( 'Self', 'blog-designer-for-post-and-widget' ) 		=> 'self',
							__( 'blank', 'blog-designer-for-post-and-widget' ) 	=> '_blank',
							),
						'description' 	=> __( 'Link Target.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Image Fit', 'blog-designer-for-post-and-widget'),
						'param_name' 	=> 'image_fit',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Set Image Fit.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Image Height', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'image_height',
						'value' 		=> '',
						'description' 	=> __( 'Enter Image Height', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Read More Text', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'read_more_text',
						'value' 		=> '',
						'description' 	=> __( 'Enter Read More Text', 'blog-designer-for-post-and-widget' ),
					),
				// Date Setting
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Total items Limit', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'limit',
						'value' 		=> 20,
						'description' 	=> __( 'Enter number to be displayed. Enter -1 to display all.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Post Order By', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'orderby',
						'value' 		=> array(
												__( 'Post Date', 'blog-designer-for-post-and-widget' ) 			=> 'date',
												__( 'Post ID', 'blog-designer-for-post-and-widget' ) 				=> 'ID',
												__( 'Post Author', 'blog-designer-for-post-and-widget' ) 			=> 'author',
												__( 'Post Title', 'blog-designer-for-post-and-widget' ) 			=> 'title',
												__( 'Post Modified Date', 'blog-designer-for-post-and-widget' ) 	=> 'modified',
												__( 'Random', 'blog-designer-for-post-and-widget' ) 				=> 'rand',
												__( 'Menu Order', 'blog-designer-for-post-and-widget' ) 			=> 'menu_order',
												),
						'description' 	=> __( 'Select order type.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' )
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Order', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'order',
						'value' 		=> array(
												__( 'Descending', 'blog-designer-for-post-and-widget' ) 	=> 'desc',
												__( 'Ascending', 'blog-designer-for-post-and-widget' ) 	=> 'asc',
											),
						'description' 	=> __( 'Post Order.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' )
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Category', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'category',
						'value' 		=> '',
						'description' 	=> __( 'Enter category id to display Posts categories wise with comma separated.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Category Name', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_category_name',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Category Name or Not', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Category Name', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'category_name',
						'value' 		=> '',
						'description' 	=> __( 'Category Name.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Exclude Category', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'exclude_cat',
						'value' 		=> '',
						'description' 	=> __( 'Exclude slides category. Works only if `Category` field is empty. you can exclude with comma separated', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Display Specific Post', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'posts',
						'value' 		=> '',
						'description' 	=> __( 'Enter post id which you only want to display with comma separated.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Exclude Post', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'exclude_post',
						'value' 		=> '',
						'description' 	=> __( 'Enter post id which you do not want to display with comma separated.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),

					//Slider Setting
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Dots', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'dots',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 	=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) => 'false',
							),
						'description' 	=> __( 'Show pagination dots.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Slider Settings', 'blog-designer-for-post-and-widget' )
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Arrows', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'arrows',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 	=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) => 'false',
							),
						'description' 	=> __( 'Show Prev - Next arrows.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Slider Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Autoplay', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'autoplay',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 	=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) => 'false',
							),
						'description' 	=> __( 'Enable autoplay.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Slider Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Loop', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'loop',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 	=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) => 'false',
							),
						'description' 	=> __( 'Enable loop.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Slider Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Autoplay Interval', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'autoplay_interval',
						'value' 		=> '2000',
						'description' 	=> __( 'Enter autoplay speed.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Slider Settings', 'blog-designer-for-post-and-widget' ),
						'dependency' 	=> array(
							'element' 	=> 'autoplay',
							'value' 	=> array( 'true' ),
							),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Speed', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'speed',
						'value' 		=> '300',
						'description' 	=> __( 'Enter slide speed.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Slider Settings', 'blog-designer-for-post-and-widget' ),
					),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'RTL', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'rtl',
						'value' 		=> array(
							__( 'False', 'blog-designer-for-post-and-widget' ) => 'false',
							__( 'True', 'blog-designer-for-post-and-widget' ) 	=> 'true',
							),
						'description' 	=> __( 'RTL', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Slider Settings', 'blog-designer-for-post-and-widget' ),
					),	
				),
			)
		);
	}
/***************************************************/
	/**
	 * Function to add 'wpspw_masonry' shortcode in vc
	 * 
	 * @package Blog Designer - Post and Widget Pro
	 * @since 1.0.0
	 */
	function wpspw_pro_integrate_masonry_vc() {
		vc_map( 
			array(
				'name' 			=> __( 'WPOS-Blog Masonry View', 'blog-designer-for-post-and-widget' ),
				'base' 			=> 'wpspw_masonry',
				'icon' 			=> 'icon-wpb-wp',
				'class' 		=> '',
				'category' 		=> __( 'Content', 'blog-designer-for-post-and-widget'),
				'description' 	=> __( 'Display Blog Masonry View.', 'blog-designer-for-post-and-widget' ),
				'params' 		=> array(
					// General settings
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Design', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'design',
						'value' 		=> array(
							__( 'Masonry Design 1', 'blog-designer-for-post-and-widget' ) 	=> 'design-1',
							__( 'Masonry Design 2', 'blog-designer-for-post-and-widget' ) 	=> 'design-2',
							__( 'Masonry Design 3', 'blog-designer-for-post-and-widget' ) 	=> 'design-3',
							__( 'Masonry Design 4', 'blog-designer-for-post-and-widget' ) 	=> 'design-4',
							__( 'Masonry Design 5', 'blog-designer-for-post-and-widget' ) 	=> 'design-5',
							__( 'Masonry Design 6', 'blog-designer-for-post-and-widget' ) 	=> 'design-6',
							__( 'Masonry Design 7', 'blog-designer-for-post-and-widget' ) 	=> 'design-7',
							__( 'Masonry Design 8', 'blog-designer-for-post-and-widget' ) 	=> 'design-8',
							__( 'Masonry Design 9', 'blog-designer-for-post-and-widget' ) 	=> 'design-9',
							__( 'Masonry Design 10', 'blog-designer-for-post-and-widget' ) 	=> 'design-10',
							__( 'Masonry Design 11', 'blog-designer-for-post-and-widget' ) 	=> 'design-11',
							__( 'Masonry Design 12', 'blog-designer-for-post-and-widget' ) 	=> 'design-12',
							__( 'Masonry Design 13', 'blog-designer-for-post-and-widget' ) 	=> 'design-13',
							__( 'Masonry Design 14', 'blog-designer-for-post-and-widget' ) 	=> 'design-14',
							__( 'Masonry Design 15', 'blog-designer-for-post-and-widget' ) 	=> 'design-15',
							__( 'Masonry Design 16', 'blog-designer-for-post-and-widget' ) 	=> 'design-16',
							__( 'Masonry Design 17', 'blog-designer-for-post-and-widget' ) 	=> 'design-17',
							__( 'Masonry Design 18', 'blog-designer-for-post-and-widget' ) 	=> 'design-18',
							__( 'Masonry Design 19', 'blog-designer-for-post-and-widget' ) 	=> 'design-19',
							__( 'Masonry Design 20', 'blog-designer-for-post-and-widget' ) 	=> 'design-20',
							__( 'Masonry Design 21', 'blog-designer-for-post-and-widget' ) 	=> 'design-21',
							__( 'Masonry Design 22', 'blog-designer-for-post-and-widget' ) 	=> 'design-22',
							__( 'Masonry Design 23', 'blog-designer-for-post-and-widget' ) 	=> 'design-23',
							__( 'Masonry Design 24', 'blog-designer-for-post-and-widget' ) 	=> 'design-24',
							__( 'Masonry Design 47', 'blog-designer-for-post-and-widget' ) 	=> 'design-47',
							__( 'Masonry Design 48', 'blog-designer-for-post-and-widget' ) 	=> 'design-48',
							__( 'Masonry Design 49', 'blog-designer-for-post-and-widget' ) 	=> 'design-49',
							__( 'Masonry Design 50', 'blog-designer-for-post-and-widget' ) 	=> 'design-50',
							),
						'description' 	=> __( 'Choose Masonry design.', 'blog-designer-for-post-and-widget' ),
						'admin_label' 	=> true,
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Author', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_author',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 	=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Author.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Date', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_date',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Date.', 'blog-designer-for-post-and-widget' ),
						),

					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Content', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_content',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Content.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Content Word Limit', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'content_words_limit',
						'value' 		=> '20',
						'description' 	=> __( 'Enter Content Word Limit', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Read More', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_read_more',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Read More.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Pagination', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'pagination',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Pagination.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Image Size', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'media_size',
						'value' 		=> array(
							__( 'Large', 'blog-designer-for-post-and-widget' ) 		=> 'large',
							__( 'Full', 'blog-designer-for-post-and-widget' ) 	=> 'full',
							__( 'Medium', 'blog-designer-for-post-and-widget' ) 	=> 'medium',
							__( 'Thumbnail', 'blog-designer-for-post-and-widget' ) 	=> 'thumbnail',
							),
						'description' 	=> __( 'Set Image Size', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Tags', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_tags',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Tags.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Comments', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_comments',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Comments.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Link Behavior', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'link_target',
						'value' 		=> array(
							__( 'Self', 'blog-designer-for-post-and-widget' ) 		=> 'self',
							__( 'blank', 'blog-designer-for-post-and-widget' ) 	=> '_blank',
							),
						'description' 	=> __( 'Open a link New tab or not', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Masonry Effect', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'effect',
						'value' 		=> array(
							__( '2', 'blog-designer-for-post-and-widget' ) 	=> '2',
							__( '3', 'blog-designer-for-post-and-widget' ) 	=> '3',
							__( '4', 'blog-designer-for-post-and-widget' ) 	=> '4',
							__( '5', 'blog-designer-for-post-and-widget' ) 	=> '5',
							__( '6', 'blog-designer-for-post-and-widget' ) 	=> '6',
							__( '7', 'blog-designer-for-post-and-widget' ) 	=> '7',
							),
						'description' 	=> __( 'Link Target.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Content Tail', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'content_tail',
						'value' 		=> '...',
						'description' 	=> __( 'Enter Content Tail to display', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Read More Text', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'read_more_text',
						'value' 		=> '',
						'description' 	=> __( 'Enter Read More Text', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Load More Text', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'load_more_text',
						'value' 		=> '',
						'description' 	=> __( 'Enter Load More Text', 'blog-designer-for-post-and-widget' ),
						),

				// Data Settings
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Total Items Limit', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'limit',
						'value' 		=> 20,
						'description' 	=> __( 'Enter number to be displayed. Enter -1 to display all.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Grid', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'grid',
						'value' 		=> 2,
						'description' 	=> __( 'Enter number to be displayed post per row.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Post Order By', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'orderby',
						'value' 		=> array(
											__( 'Post Date', 'blog-designer-for-post-and-widget' ) 			=> 'date',
											__( 'Post ID', 'blog-designer-for-post-and-widget' ) 				=> 'ID',
											__( 'Post Author', 'blog-designer-for-post-and-widget' ) 			=> 'author',
											__( 'Post Title', 'blog-designer-for-post-and-widget' ) 			=> 'title',
											__( 'Post Modified Date', 'blog-designer-for-post-and-widget' ) 	=> 'modified',
											__( 'Random', 'blog-designer-for-post-and-widget' ) 				=> 'rand',
											__( 'Menu Order', 'blog-designer-for-post-and-widget' ) 			=> 'menu_order',
											),
						'description' 	=> __( 'Select order type.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' )
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Order', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'order',
						'value' 		=> array(
												__( 'Descending', 'blog-designer-for-post-and-widget' ) 	=> 'desc',
												__( 'Ascending', 'blog-designer-for-post-and-widget' ) 	=> 'asc',
											),
						'description' 	=> __( 'Post Order.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' )
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Category', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'category',
						'value' 		=> '',
						'description' 	=> __( 'Enter category id to display Posts categories wise with comma separated.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Show Category Name', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_category_name',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Category Name.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Category Name', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'category_name',
						'value' 		=> '',
						'description' 	=> __( 'Category Name.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Display Specific Posts', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'posts',
						'value' 		=> '',
						'description' 	=> __( 'Enter post id which you only want to display with comma separated.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Exclude Post', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'exclude_post',
						'value' 		=> '',
						'description' 	=> __( 'Enter post id which you do not want to display with comma separated.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
				),
			)
		);
	}

/***************************************************/
	/**
	 * Function to add 'wpspw_ticker' shortcode in vc
	 * 
	 * @package Blog Designer - Post and Widget Pro
	 * @since 1.0.0
	 */
	function wpspw_pro_integrate_ticker_vc() {
		vc_map( 
			array(
				'name' 			=> __( 'WPOS-Blog Ticker', 'blog-designer-for-post-and-widget' ),
				'base' 			=> 'wpspw_ticker',
				'icon' 			=> 'icon-wpb-wp',
				'class' 		=> '',
				'category' 		=> __( 'Content', 'blog-designer-for-post-and-widget'),
				'description' 	=> __( 'Display Blog Ticker.', 'blog-designer-for-post-and-widget' ),
				'params' 		=> array(
					// General settings
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Ticker Title', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'ticker_title',
						'value' 		=> 'Latest News',
						'description' 	=> __( 'Title for the Ticker.', 'blog-designer-for-post-and-widget' ),
						'admin_label' 	=> true,
						),
					array(
						'type' 			=> 'colorpicker',
						'class' 		=> '',
						'heading' 		=> __( 'Theme Color', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'theme_color',
						'value' 		=> '#2096cd',
						'description' 	=> __( 'Set Ticker theme color.', 'blog-designer-for-post-and-widget' )
						),
					array(
						'type' 			=> 'colorpicker',
						'class' 		=> '',
						'heading' 		=> __( 'Ticker Heading Color', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'heading_font_color',
						'value' 		=> '#fff',
						'description' 	=> __( 'Set Ticker Heading Font Color.', 'blog-designer-for-post-and-widget' )
						),
					array(
						'type' 			=> 'colorpicker',
						'class' 		=> '',
						'heading' 		=> __( 'Font Color', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'font_color',
						'value' 		=> '#2096cd',
						'description' 	=> __( 'Set Ticker Text Font Color.', 'blog-designer-for-post-and-widget' ),

						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Font Style', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'font_style',
						'value' 		=> array(
										__( 'Normal', 'blog-designer-for-post-and-widget' ) 		=> 'normal',
										__( 'Bold', 'blog-designer-for-post-and-widget' ) 			=> 'bold',
										__( 'Italic', 'blog-designer-for-post-and-widget' ) 		=> 'italic',
										__( 'Bold Italic', 'blog-designer-for-post-and-widget' ) 	=> 'bold-italic',
											),
						'description' 	=> __( 'Set Font Style of the Post.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Link Behavior', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'link_target',
						'value' 		=> array(
							__( 'Self', 'blog-designer-for-post-and-widget' ) 		=> 'self',
							__( 'blank', 'blog-designer-for-post-and-widget' ) 	=> '_blank',
							),
						'description' 	=> __( 'Open a link New tab or not', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Ticker Effect', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'ticker_effect',
						'value' 		=> array(
										__( 'Verticle Ticker Effect','blog-designer-for-post-and-widget' ) 	=> 'slide-v',
										__( 'Horizontal Ticker Effect', 'blog-designer-for-post-and-widget' ) 	=> 'slide-h',
										__( 'Fade Ticker Effect', 'blog-designer-for-post-and-widget' )   => 'fade',
										),
						'description' 	=> __( 'Set the ticker effect. e.g. Vertical, Horizontal, Fade', 'blog-designer-for-post-and-widget' ),
						'admin_label' 	=> true,
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Autoplay', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'autoplay',
						'value' 		=> array(
										__( 'True', 'blog-designer-for-post-and-widget' ) 	=> 'true',
										__( 'False', 'blog-designer-for-post-and-widget' ) => 'false',
										),
						'description' 	=> __( 'Autoplay Ticker.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Speed', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'speed',
						'value' 		=> '3000',
						'description' 	=> __( 'Speed of the ticker.', 'blog-designer-for-post-and-widget' ),
						'dependency' 	=> array(
						'element' 	=> 'autoplay',
						'value' 	=> array( 'true' ),
										),
						),
				// Data Settings
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Total Ticker Items Limit', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'limit',
						'value' 		=> 20,
						'description' 	=> __( 'Enter number to be displayed. Enter -1 to display all.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Order By', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'orderby',
						'value' 		=> array(
											__( 'Post Date', 'blog-designer-for-post-and-widget' ) 			=> 'date',
											__( 'Post ID', 'blog-designer-for-post-and-widget' ) 				=> 'ID',
											__( 'Post Author', 'blog-designer-for-post-and-widget' ) 			=> 'author',
											__( 'Post Title', 'blog-designer-for-post-and-widget' ) 			=> 'title',
											__( 'Post Modified Date', 'blog-designer-for-post-and-widget' ) 	=> 'modified',
											__( 'Random', 'blog-designer-for-post-and-widget' ) 				=> 'rand',
											__( 'Menu Order', 'blog-designer-for-post-and-widget' ) 			=> 'menu_order',
											),
						'description' 	=> __( 'Select order type.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' )
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Order', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'order',
						'value' 		=> array(
												__( 'Descending', 'blog-designer-for-post-and-widget' ) 	=> 'desc',
												__( 'Ascending', 'blog-designer-for-post-and-widget' ) 	=> 'asc',
											),
						'description' 	=> __( 'Post Order.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' )
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Category', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'category',
						'value' 		=> '',
						'description' 	=> __( 'Enter category id to display Posts categories wise with comma separated.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type'			=> 'dropdown',
						'class'			=> '',
						'heading'		=> __( 'Disply Child Category','blog-designer-for-post-and-widget'),
						'param_name'	=> 'include_cat_child',
						'value'			=> array(
							__('True', 'blog-designer-for-post-and-widget')		=> 'true',
							__('False', 'blog-designer-for-post-and-widget')	=> 'false',
							),
						'description'	=> __( 'Display Child Category.','blog-designer-for-post-and-widget'),
						'group'		=> __( 'Data Settings','blog-designer-for-post-and-widget'),

						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Exclude Category', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'exclude_cat',
						'value' 		=> '',
						'description' 	=> __( 'Exclude post category. Works only if `Category` field is empty.you can exculde with comma separated', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Display Specific Posts', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'posts',
						'value' 		=> '',
						'description' 	=> __( 'Enter post id which you only want to display with comma separated.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Exclude Post', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'exclude_post',
						'value' 		=> '',
						'description' 	=> __( 'Enter post id which you do not want to display with comma separated.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Query Offset', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'query_offset',
						'value' 		=> null,
						'description' 	=> __( 'Enter number of post that you want to skip', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
				),
			)
		);
	}

/***************************************************/

	/**
	 * Function to add 'wpspw_recent_post_slider' shortcode in vc
	 * 
	 * @package Blog Designer - Post and Widget Pro
	 * @since 1.0.0
	 */

	function wpspw_pro_integrate_slider_vc() {
		vc_map( 
			array(
				'name' 			=> __( 'WPOS - Post Slider', 'blog-designer-for-post-and-widget' ),
				'base' 			=> 'wpspw_recent_post_slider',
				'icon' 			=> 'icon-wpb-wp',
				'class' 		=> '',
				'category' 		=> __( 'Content', 'blog-designer-for-post-and-widget'),
				'description' 	=> __( 'Display Post slider.', 'blog-designer-for-post-and-widget' ),
				'params' 	=> array(
			// General settings
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Design', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'design',
						'value' 		=> array(
							__( 'Slider Design 1', 'blog-designer-for-post-and-widget' ) 	=> 'design-1',
							__( 'Slider Design 2', 'blog-designer-for-post-and-widget' ) 	=> 'design-2',
							__( 'Slider Design 3', 'blog-designer-for-post-and-widget' ) 	=> 'design-3',
							__( 'Slider Design 4', 'blog-designer-for-post-and-widget' ) 	=> 'design-4',
							__( 'Slider Design 5', 'blog-designer-for-post-and-widget' ) 	=> 'design-5',
							__( 'Slider Design 6', 'blog-designer-for-post-and-widget' ) 	=> 'design-6',
							__( 'Slider Design 7', 'blog-designer-for-post-and-widget' ) 	=> 'design-7',
							__( 'Slider Design 8', 'blog-designer-for-post-and-widget' ) 	=> 'design-8',
							__( 'Slider Design 9', 'blog-designer-for-post-and-widget' ) 	=> 'design-9',
							__( 'Slider Design 10', 'blog-designer-for-post-and-widget' ) 	=> 'design-10',
							__( 'Slider Design 11', 'blog-designer-for-post-and-widget' ) 	=> 'design-11',
							__( 'Slider Design 12', 'blog-designer-for-post-and-widget' ) 	=> 'design-12',
							__( 'Slider Design 13', 'blog-designer-for-post-and-widget' ) 	=> 'design-13',
							__( 'Slider Design 14', 'blog-designer-for-post-and-widget' ) 	=> 'design-14',
							__( 'Slider Design 15', 'blog-designer-for-post-and-widget' ) 	=> 'design-15',
							__( 'Slider Design 16', 'blog-designer-for-post-and-widget' ) 	=> 'design-16',
							__( 'Slider Design 17', 'blog-designer-for-post-and-widget' ) 	=> 'design-17',
							__( 'Slider Design 18', 'blog-designer-for-post-and-widget' ) 	=> 'design-18',
							__( 'Slider Design 19', 'blog-designer-for-post-and-widget' ) 	=> 'design-19',
							__( 'Slider Design 20', 'blog-designer-for-post-and-widget' ) 	=> 'design-20',
							__( 'Slider Design 21', 'blog-designer-for-post-and-widget' ) 	=> 'design-21',
							__( 'Slider Design 22', 'blog-designer-for-post-and-widget' ) 	=> 'design-22',
							__( 'Slider Design 23', 'blog-designer-for-post-and-widget' ) 	=> 'design-23',
							__( 'Slider Design 24', 'blog-designer-for-post-and-widget' ) 	=> 'design-24',
							__( 'Slider Design 25', 'blog-designer-for-post-and-widget' ) 	=> 'design-25',
							__( 'Slider Design 26', 'blog-designer-for-post-and-widget' ) 	=> 'design-26',
							__( 'Slider Design 27', 'blog-designer-for-post-and-widget' ) 	=> 'design-27',
							__( 'Slider Design 28', 'blog-designer-for-post-and-widget' ) 	=> 'design-28',
							__( 'Slider Design 29', 'blog-designer-for-post-and-widget' ) 	=> 'design-29',
							__( 'Slider Design 30', 'blog-designer-for-post-and-widget' ) 	=> 'design-30',
							__( 'Slider Design 31', 'blog-designer-for-post-and-widget' ) 	=> 'design-31',
							__( 'Slider Design 32', 'blog-designer-for-post-and-widget' ) 	=> 'design-32',
							__( 'Slider Design 33', 'blog-designer-for-post-and-widget' ) 	=> 'design-33',
							__( 'Slider Design 34', 'blog-designer-for-post-and-widget' ) 	=> 'design-34',
							__( 'Slider Design 35', 'blog-designer-for-post-and-widget' ) 	=> 'design-35',
							__( 'Slider Design 36', 'blog-designer-for-post-and-widget' ) 	=> 'design-36',
							__( 'Slider Design 37', 'blog-designer-for-post-and-widget' ) 	=> 'design-37',
							__( 'Slider Design 38', 'blog-designer-for-post-and-widget' ) 	=> 'design-38',
							__( 'Slider Design 39', 'blog-designer-for-post-and-widget' )	=> 'design-39',
							__( 'Slider Design 40', 'blog-designer-for-post-and-widget' )	=> 'design-40',
							__( 'Slider Design 41', 'blog-designer-for-post-and-widget' )	=> 'design-41',
							__( 'Slider Design 42', 'blog-designer-for-post-and-widget' )	=> 'design-42',
							__( 'Slider Design 43', 'blog-designer-for-post-and-widget' )	=> 'design-43',
							__( 'Slider Design 44', 'blog-designer-for-post-and-widget' )	=> 'design-44',
							__( 'Slider Design 45', 'blog-designer-for-post-and-widget' )	=> 'design-45',
							),
						'description' 	=> __( 'Choose Slider design.', 'blog-designer-for-post-and-widget' ),
						'admin_label' 	=> true,
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Author', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_author',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Author.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Date', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_date',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Date.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Content', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_content',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Content.', 'blog-designer-for-post-and-widget' ),
						),
					/*array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Full Content', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_full_content',
						'value' 		=> array(
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							),
						'description' 	=> __( 'Show Full Content.', 'blog-designer-for-post-and-widget' ),
						),*/
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Read More', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_read_more',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Read More.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Content Word Limit', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'content_words_limit',
						'value' 		=> '20',
						'description' 	=> __( 'Enter Content Word Limit', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Content Tail', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'content_tail',
						'value' 		=> '...',
						'description' 	=> __( 'Enter Content Tail to display', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Tags', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_tags',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Tags.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Comments', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_comments',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Comments.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Link Behavior', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'link_target',
						'value' 		=> array(
							__( 'Self', 'blog-designer-for-post-and-widget' ) 		=> 'self',
							__( 'blank', 'blog-designer-for-post-and-widget' ) 	=> '_blank',
							),
						'description' 	=> __( 'Link Target.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Set Image Size', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'media_size',
						'value' 		=> array(
							__( 'Large', 'blog-designer-for-post-and-widget' ) 		=> 'large',
							__( 'Full', 'blog-designer-for-post-and-widget' ) 	=> 'full',
							__( 'Medium', 'blog-designer-for-post-and-widget' ) 	=> 'medium',
							__( 'Thumbnail', 'blog-designer-for-post-and-widget' ) 	=> 'thumbnail',
							),
						'description' 	=> __( 'Set Image Size by values', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Image Fit', 'blog-designer-for-post-and-widget'),
						'param_name' 	=> 'image_fit',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Set Image Fit.', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Image Height', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'image_height',
						'value' 		=> '',
						'description' 	=> __( 'Enter Image Height', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Read More Text', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'read_more_text',
						'value' 		=> '',
						'description' 	=> __( 'Enter Read More Text', 'blog-designer-for-post-and-widget' ),
					),
				// Date Setting
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Total items Limit', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'limit',
						'value' 		=> 20,
						'description' 	=> __( 'Enter number to be displayed. Enter -1 to display all.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Post Order By', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'orderby',
						'value' 		=> array(
												__( 'Post Date', 'blog-designer-for-post-and-widget' ) 			=> 'date',
												__( 'Post ID', 'blog-designer-for-post-and-widget' ) 				=> 'ID',
												__( 'Post Author', 'blog-designer-for-post-and-widget' ) 			=> 'author',
												__( 'Post Title', 'blog-designer-for-post-and-widget' ) 			=> 'title',
												__( 'Post Modified Date', 'blog-designer-for-post-and-widget' ) 	=> 'modified',
												__( 'Random', 'blog-designer-for-post-and-widget' ) 				=> 'rand',
												__( 'Menu Order', 'blog-designer-for-post-and-widget' ) 			=> 'menu_order',
												),
						'description' 	=> __( 'Select order type.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' )
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Order', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'order',
						'value' 		=> array(
												__( 'Descending', 'blog-designer-for-post-and-widget' ) 	=> 'desc',
												__( 'Ascending', 'blog-designer-for-post-and-widget' ) 	=> 'asc',
											),
						'description' 	=> __( 'Post Order.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' )
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Category', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'category',
						'value' 		=> '',
						'description' 	=> __( 'Enter category id to display Posts categories wise with comma separated.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Category Name', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'show_category_name',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 		=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Category Name or Not', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Category Name', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'category_name',
						'value' 		=> '',
						'description' 	=> __( 'Category Name.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Exclude Category', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'exclude_cat',
						'value' 		=> '',
						'description' 	=> __( 'Exclude slides category. Works only if `Category` field is empty.you can exclude with comma separated', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Display Specific Post', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'posts',
						'value' 		=> '',
						'description' 	=> __( 'Enter post id which you only want to display with comma separated.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Exclude Post', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'exclude_post',
						'value' 		=> '',
						'description' 	=> __( 'Enter post id which you do not want to display with comma separated.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Data Settings', 'blog-designer-for-post-and-widget' ),
						),

					//Slider Setting
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Dots', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'dots',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 	=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) => 'false',
							),
						'description' 	=> __( 'Show pagination dots.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Slider Settings', 'blog-designer-for-post-and-widget' )
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Arrows', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'arrows',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 	=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) => 'false',
							),
						'description' 	=> __( 'Show Prev - Next arrows.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Slider Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Slide To Show', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'slides_column',
						'value' 		=> '3',
						'description' 	=> __( 'Enter Slide to show.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Slider Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Slide To Scroll', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'slides_scroll',
						'value' 		=> '1',
						'description' 	=> __( 'Enter slide to scroll.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Slider Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Autoplay', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'autoplay',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 	=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) => 'false',
							),
						'description' 	=> __( 'Enable autoplay.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Slider Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Loop', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'loop',
						'value' 		=> array(
							__( 'True', 'blog-designer-for-post-and-widget' ) 	=> 'true',
							__( 'False', 'blog-designer-for-post-and-widget' ) => 'false',
							),
						'description' 	=> __( 'Enable loop.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Slider Settings', 'blog-designer-for-post-and-widget' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Autoplay Interval', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'autoplay_interval',
						'value' 		=> '2000',
						'description' 	=> __( 'Enter autoplay speed.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Slider Settings', 'blog-designer-for-post-and-widget' ),
						'dependency' 	=> array(
							'element' 	=> 'autoplay',
							'value' 	=> array( 'true' ),
							),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Speed', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'speed',
						'value' 		=> '300',
						'description' 	=> __( 'Enter slide speed.', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Slider Settings', 'blog-designer-for-post-and-widget' ),
					),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'RTL', 'blog-designer-for-post-and-widget' ),
						'param_name' 	=> 'rtl',
						'value' 		=> array(
							__( 'False', 'blog-designer-for-post-and-widget' ) => 'false',
							__( 'True', 'blog-designer-for-post-and-widget' ) 	=> 'true',
							),
						'description' 	=> __( 'RTL', 'blog-designer-for-post-and-widget' ),
						'group' 		=> __( 'Slider Settings', 'blog-designer-for-post-and-widget' ),
					),	
				),
			)
		);
	}
}


$wpspw_vc = new Wpspw_Vc();
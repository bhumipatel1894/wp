<?php
/**
 * Shortcodes Class
 *
 * Handles shortcodes functionality of plugin
 *
 * @package WP Blog and Widget - Masonry Layout
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

function wpspw_post_masonry( $atts, $content = null ) {
		
		// Shortcode Parameters
		extract(shortcode_atts(array(
			"limit" 				=> '4',
			"category" 				=> '',
			"category_name" 		=> '',
			"design"	 			=> 'design-1',
			"grid" 					=> '2',
			"pagination" 			=> 'false',
			"show_date" 			=> 'true',
			"show_category_name"	=> 'true',
			"show_content" 			=> 'true',
			"show_read_more" 		=> 'true',
			"content_words_limit" 	=> '20',
			'content_tail'			=> '...',
			'order'					=> 'DESC',
			'orderby'				=> 'post_date',
			'link_target'			=> 'self',
			'exclude_post'			=> array(),
			'posts'					=> array(),
			'effect'				=> 'effect-2',
			'load_more_text'		=> '',
			'show_author' 			=> 'true',
			'media_size' 			=> 'large',			
			'read_more_text'		=> __('Read More', 'blog-designer-for-post-and-widget'),
			'show_tags'				=> 'true',
			'show_comments'			=> 'true',	
		), $atts));

		$shortcode_designs 	= wpspw_post_masonry_designs();
		$msonry_effects 	= wpspw_post_masonry_effects();
	    $content_tail 		= html_entity_decode($content_tail);
	    $posts_per_page		= (!empty($limit)) 		? $limit 			: '4';
	    $cat 				= (!empty($category))	? explode(',',$category) : '';
		$blogcategory_name 	= ($category_name) 		? $category_name 	: '';
		$newdesign 			= ($design && (array_key_exists(trim($design), $shortcode_designs))) ? trim($design) 	: 'design-1';
		$blogpagination 	= ($pagination == 'true')			? 'true'		: 'false';
		$gridcol 			= (!empty($grid))					? $grid 		: '2';
		$showDate 			= ( $show_date == 'true' ) 			? 'true' 		: 'false';
		$showCategory 		= ( $show_category_name == 'true')	? 'true' 		: 'false';
		$showContent 		= ( $show_content == 'true' ) 		? 'true' 		: 'false';
	    $words_limit 		= !empty($content_words_limit) 		? $content_words_limit : '20';
		$showreadmore 		= ( $show_read_more == 'true' ) 	? 'true' 		: 'false';
		$order 				= ( strtolower($order) == 'asc' ) 	? 'ASC' 		: 'DESC';
		$orderby 			= (!empty($orderby))				? $orderby		: 'post_date';
		$link_target 		= ($link_target == 'blank') 		? '_blank' : '_self';
		$exclude_post 		= !empty($exclude_post)				? explode(',', $exclude_post) 	: array();
		$posts 				= !empty($posts)					? explode(',', $posts) 			: array();
		$load_more_text 	= !empty($load_more_text) 			? $load_more_text : __('Load More Posts', 'wp-blog-and-widgets');
		$effect 			= (!empty($effect) && array_key_exists(trim($effect), $msonry_effects))	? trim($effect) : 'effect-1';		
		$showAuthor 		= ($show_author == 'false')			? 'false'			: 'true';
		$media_size 		= (!empty($media_size))				? $media_size 	: 'large'; //thumbnail, medium, large, full
		$read_more_text 	= !empty($read_more_text) 			? $read_more_text 				: __('Read More', 'blog-designer-for-post-and-widget');
		$show_tags 			= ( $show_tags == 'false' ) 			? 'false'						: 'true';
		$show_comments 		= ( $show_comments == 'false' ) 		? 'false'						: 'true';	
		$unique 			= wpspw_pro_get_unique();		
		
		// Shortcode file
		$design_file_path 	= WPSPW_PRO_DIR . '/templates/masonry/' . $newdesign . '.php';
		$design_file 		= (file_exists($design_file_path)) ? $design_file_path : '';
		
		// Shortcode Parameters
		$shortcode_atts = compact('content_tail', 'posts_per_page', 'cat', 'blogcategory_name', 'newdesign', 'blogpagination', 'gridcol', 'showDate', 'showCategory', 'showContent', 'words_limit', 'showreadmore', 'order', 'orderby', 'link_target', 'exclude_post', 'posts','showAuthor','read_more_text', 'media_size', 'show_tags','show_comments');
		
		global $paged, $post, $wpbawm_in_shrtcode;
		
		if(is_home() || is_front_page()) {
			  $paged = get_query_var('page');
		} else {
			 $paged = get_query_var('paged');
		}

		// WP Query Parameters
	$args = array ( 
		'post_type'      		=> WPSPW_POST_TYPE,
		'post_status' 			=> array('publish'),
		'order'          		=> $order,
		'orderby'        		=> $orderby, 
		'posts_per_page' 		=> $posts_per_page, 
		'paged'          		=> $paged,
		'post__in'				=> $posts,
		'post__not_in'			=> $exclude_post,
		'ignore_sticky_posts'	=> true,
	);

    // Category Parameter
	if($cat != "") {
		
		$args['tax_query'] = array(
								array( 
									'taxonomy' 			=> WPSPW_CAT,
									'field' 			=> 'term_id',
									'terms' 			=> $cat,
									'include_children'	=> $include_cat_child,
								));

	} else if( !empty($exclude_cat) ) {
		
		$args['tax_query'] = array(
								array(
									'taxonomy' 			=> WPSPW_CAT,
									'field' 			=> 'term_id',
									'terms' 			=> $exclude_cat,
									'operator'			=> 'NOT IN',
									'include_children'	=> $include_cat_child,
								));
	}

		// WP Query
		$query 			= new WP_Query($args);
		$post_count 	= $query->post_count;
		$total_post 	= $query->found_posts;
		$count 			= 0;
		$grid_count		= 1;

		ob_start();

		// If Blog post is there
		if ( $query->have_posts() ) :

			// Enqueue required script
			wp_enqueue_script('masonry', 'jquery');
			wp_enqueue_script('wpspw-masonry-public-script');			
		
		if ($category_name != '') { ?>
			<h1 class="category-title-main">		   
				<?php echo $category_name; ?>
			</h1>
		<?php } ?>

		<div class="wpspw-post-masonry-wrp wpspw-clearfix" id="wpspw-post-masonry-wrp-<?php echo $unique; ?>">

			<?php if ( $blogcategory_name != '' ) { ?>
				<h1 class="category-title-main">
					<?php echo $blogcategory_name; ?>
				</h1>
			<?php } ?>

			<div class="wpspw-post-masonry wpspw-<?php echo $effect; ?> wpspw-<?php echo $newdesign; ?> wpspw-grid-<?php echo $gridcol; ?>" id="wpspw-post-masonry-<?php echo $unique; ?>">

	            <?php while ( $query->have_posts() ) : $query->the_post();
	            		
	            	$count++;
	            	$cat_links 			= array();
	               	$terms 					= get_the_terms( $post->ID, WPSPW_CAT );
					$post_link 				= wpspw_pro_get_post_link( $post->ID );					
					$post_featured_image 	= wpspw_pro_get_post_featured_image( $post->ID, $media_size, true );	                
					$tags 			        = get_the_tag_list(' ',', ');
					$comments 		        = get_comments_number( $post->ID );
					$reply			        = ($comments <= 1)  ? 'Reply' : 'Replies';

					if($terms) {
						foreach ( $terms as $term ) {
							$term_link = get_term_link( $term );
							$cat_links[] = '<a href="' . esc_url( $term_link ) . '">'.$term->name.'</a>';
						}
	                }
	                $cate_name = join( " ", $cat_links );
	              	
	              	if( $design_file ) {
	              		include( $design_file );
	              	}
					
					$grid_count++;
	            	endwhile;
					
	           	?>
			</div><!-- end .wpspw-blog-masonry -->
			
			<?php if( ($posts_per_page != -1) && ($posts_per_page < $total_post) && ($blogpagination != 'true') ) { ?>
			<div class="wpspw-ajax-btn-wrap">
				<button class="wpspw-load-more-btn more" data-ajax="1" data-paged="1" data-count="<?php echo $count; ?>">
					<i class="wpspw-ajax-loader"><img src="<?php echo WPSPW_PRO_URL . 'assets/images/ajax-loader.gif'; ?>" alt="<?php _e('Loading', 'blog-designer-for-post-and-widget'); ?>" /></i> 
					<?php echo $load_more_text; ?>
				</button>
				<div class="wpspw-hide wpspw-shortcode-param"><?php echo wpspw_esc_attr( json_encode($shortcode_atts)); ?></div>
			</div><!-- end .wpspw-ajax-btn-wrap -->
			<?php } ?>

			<?php if($blogpagination == "true") { ?>
				<div class="blog_pagination wpblog-clearfix wpspw-<?php echo $newdesign;?>">
					<div class="button-blog-p"><?php next_posts_link( ' Next >>', $query->max_num_pages ); ?></div>
					<div class="button-blog-n"><?php previous_posts_link( '<< Previous' ); ?> </div>
				</div>
			<?php } ?>

		</div><!-- end .wpspw-blog-masonry -->

	<?php
			
		endif;
		wp_reset_query(); // Reset wp query
		$content .= ob_get_clean();
		return $content;
	}
add_shortcode( 'wpspw_masonry', 'wpspw_post_masonry');
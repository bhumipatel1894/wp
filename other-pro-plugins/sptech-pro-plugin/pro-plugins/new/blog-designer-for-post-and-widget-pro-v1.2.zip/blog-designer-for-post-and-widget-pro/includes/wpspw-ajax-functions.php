<?php
/**
 * Public Class * 
 * Handles shortcodes functionality of plugin * 
 * @package WP Blog and Widget - Masonry Layout
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Wpspw_Public {
	function __construct() {
		// Ajax call to update option
		add_action( 'wp_ajax_wpspw_get_more_post', array($this, 'wpspw_get_more_post'));
		add_action( 'wp_ajax_nopriv_wpspw_get_more_post',array( $this, 'wpspw_get_more_post'));		
	}
	/**
	 * Get more Blog post througn ajax
	 *
	 * @package WP Blog and Widget - Masonry Layout
	 * @since 1.0.0
	 */
	function wpspw_get_more_post() {
		
		// Taking some defaults
		$result = array();
		
		if( !empty($_POST['shrt_param']) ) {
			
			global $post, $wpspw_in_shrtcode;
			
			extract( $_POST['shrt_param'] );
			
			$design_file_path 	= WPSPW_PRO_DIR . '/templates/masonry/' . $newdesign . '.php';
			$design_file 		= (file_exists($design_file_path)) 	? $design_file_path 	: '';			
			$count 				= (isset($_POST['count'])) 			? (int)$_POST['count'] 	: 0;			
			$shortcode_atts 	= $_POST['shrt_param']; // Assigning it to variable
			
			$args = array (
					'post_type'      	=> WPSPW_POST_TYPE, 
					'orderby'        	=> !empty($orderby) 	? $orderby : 'post_date',
					'order'          	=> !empty($order) 		? $order 	: 'DESC',
					'posts_per_page' 	=> !empty($posts_per_page) 		? $posts_per_page 	: '10',
					'paged'          	=> !empty($_POST['paged']) 		? $_POST['paged'] 	: '1',
					'post_not_in'		=> !empty($exclude_post) ? $exclude_post : array(),
					'post_in'			=> !empty($posts) ? $posts : array(),
				);

			if($cat != "") {
				$args['tax_query'] = array( array( 'taxonomy' => WPSPW_CAT, 'field' => 'id', 'terms' => $cat) );
			}

			$blog_posts = new WP_Query($args);

			ob_start();

			if ( $blog_posts->have_posts() ) {				

				while ( $blog_posts->have_posts() ) : $blog_posts->the_post();
					
					$count++;
					$blog_links 			= array();
					$terms 					= get_the_terms( $post->ID, WPSPW_CAT );
		            $post_link 				= wpspw_pro_get_post_link( $post->ID );
					$wpspw_author 			= get_the_author();
					$post_featured_image 	= wpspw_pro_get_post_featured_image( $post->ID, $media_size, true );						
					$terms 					= get_the_terms( $post->ID, WPSPW_CAT );
					$tags 			        = get_the_tag_list(' ',', ');
					$comments 		        = get_comments_number( $post->ID );
					$reply			        = ($comments <= 1)  ? 'Reply' : 'Replies';
					
					if($terms) {
						foreach ( $terms as $term ) {
							$term_link = get_term_link( $term );
							$blog_links[] = '<a href="' . esc_url( $term_link ) . '">'.$term->name.'</a>';
						}
	                }
	                $cate_name = join( " ", $blog_links );	                
				if( $design_file ) {
              		include( $design_file );
              	}
				endwhile; // End while loop
			}			
				$data = ob_get_clean();				
						
				$result['success'] 		= 1;
				$result['data'] 		= $data;
				$result['count']		= $count;				
				
		} else {
			$result['success'] 	= 0;
		}
		echo json_encode($result);
		die();
	}
}

$wpspw_public = new Wpspw_Public();
﻿=== Blog Designer - Post and Widget Pro  ===
Contributors: wponlinesupport, anoopranawat 
Tags: wordpress blog , wordpress blog widget, Free wordpress blog, blog custom post type, blog tab, blog menu, blog page with custom post type, blog, latest blog, custom post type, cpt, widget
Requires at least: 3.1
Tested up to: 4.8
Author URI: http://wponlinesupport.com
Stable tag: trunk

A quick, easy way to add WP Stylist Post designs to your WordPress website.

== Description ==

Blog Designer - Post and Widget Pro display WordPress posts with multiple designs . You can display latest post on your homepage/frontpage as well as in inner pages with around 36 designs.

= This wordpress plugin contains 8 shorcode =

* <code>[wpspw_post]</code> : Display blog post in grid view.
* <code>[wpspw_recent_post]</code> : Display recent blog post in grid view(Without paginations).
* <code>[wpspw_post_list]</code> : Display blog post in list view.
* <code>[wpspw_masonry]</code> : Display blog post in masonry layouts.
* <code>[wpspw_recent_post_slider]</code> : Display recent blog post in slider view.
* <code>[wpspw_post_gridbox]</code> : Display blog post in grid box layout.
* <code>[wpspw_gridbox_slider]</code> : Display blog post in grid box  slider layout.
* <code>[wpspw_ticker]</code> : Display blog post in ticker.

== Changelog ==

= 1.2 (27, June 2017) =
* [+] Added new 20+ news designs in existing recent blog post grid shortcode <code>[wpspw_recent_post]</code>
* [+] Added new 20+ news designs in existing  blog post grid shortcode <code>[wpspw_post]</code>
* [+] Added new 20+ news designs in existing recent blog post grid shortcode <code>[wpspw_recent_post_slider]</code>
* [+] Added new shortcode [wpspw_post_list] for list blog layouts with 8 designs.
* [+] Added new shortcode [wpspw_gridbox_slider] for list blog layouts with 8 designs.
* [+] Added new shortcode <code>[wpspw_post_gridbox]</code> for GridBox Post slider layouts with latest 13 designs.
* [+] Added new shortcode <code>[wpspw_masonry]</code> for Masonary Post layouts with latest 24 designs.
* [+] Added new shortcode parameters ie image_fit(true OR false) and media_size(thumbnail, medium, large, full)
* [+] Added new shortcode parameters ie show_tags(true OR false) and show_comments(true OR false)
* [-] Designs #26, #27 and #36 are depricated from shortcode <code>[wpspw_recent_post]</code> and <code>[wpspw_post]</code> and added in new shortcode <code>[wpspw_post_list]</code> as a design #5, #6 and #7 respectively.
* [-] Designs #28, #29, #31, #45, #46 and #47 are depricated from shortcode <code>[wpspw_recent_post]</code> and added in new shortcode <code>[wpspw_post_gridbox]</code> as a design #1, #2, #3, #6, #7 and #8 respectively.
* [-] Designs #40, #41 and #42 are depricated from shortcode <code>[wpspw_recent_post_slider]</code> and   and added in new shortcode <code>[wpspw_gridbox_slider]</code> as a #1, #2 and #3 respectively.
* [*] Fixed some css issue for widgets.
* [*] Fixed some css issue for Grid Block view.
* [+] Added prefix for the classes to avoide the conflict with other plugins/themes

= 1.1 (Dec 02, 2016) =
* [+] Added 'News Ticker' for Post.
* [+] Added 'How It Work' page for better user interface.
* [+] Added 'Pagination' for post to 'wpspw_post' shortcode.
* [+] Added plugin settings to customize post title, color and etc.

= 1.0 =
* Initial release.


== Upgrade Notice ==

= 1.2 (27, June 2017) =
* [+] Added new 20+ news designs in existing recent blog post grid shortcode <code>[wpspw_recent_post]</code>
* [+] Added new 20+ news designs in existing  blog post grid shortcode <code>[wpspw_post]</code>
* [+] Added new 20+ news designs in existing recent blog post grid shortcode <code>[wpspw_recent_post_slider]</code>
* [+] Added new shortcode [wpspw_post_list] for list blog layouts with 8 designs.
* [+] Added new shortcode [wpspw_gridbox_slider] for list blog layouts with 8 designs.
* [+] Added new shortcode <code>[wpspw_post_gridbox]</code> for GridBox Post slider layouts with latest 13 designs.
* [+] Added new shortcode <code>[wpspw_masonry]</code> for Masonary Post layouts with latest 24 designs.
* [+] Added new shortcode parameters ie image_fit(true OR false) and media_size(thumbnail, medium, large, full)
* [+] Added new shortcode parameters ie show_tags(true OR false) and show_comments(true OR false)
* [-] Designs #26, #27 and #36 are depricated from shortcode <code>[wpspw_recent_post]</code> and <code>[wpspw_post]</code> and added in new shortcode <code>[wpspw_post_list]</code> as a design #5, #6 and #7 respectively.
* [-] Designs #28, #29, #31, #45, #46 and #47 are depricated from shortcode <code>[wpspw_recent_post]</code> and added in new shortcode <code>[wpspw_post_gridbox]</code> as a design #1, #2, #3, #6, #7 and #8 respectively.
* [-] Designs #40, #41 and #42 are depricated from shortcode <code>[wpspw_recent_post_slider]</code> and   and added in new shortcode <code>[wpspw_gridbox_slider]</code> as a #1, #2 and #3 respectively.
* [*] Fixed some css issue for widgets.
* [*] Fixed some css issue for Grid Block view.
* [+] Added prefix for the classes to avoide the conflict with other plugins/themes

= 1.1 (Dec 02, 2016) =
* [+] Added 'News Ticker' for Post.
* [+] Added 'How It Work' page for better user interface.
* [+] Added 'Pagination' for post to 'wpspw_post' shortcode.
* [+] Added plugin settings to customize post title, color and etc.

= 1.0 =
* Initial release.
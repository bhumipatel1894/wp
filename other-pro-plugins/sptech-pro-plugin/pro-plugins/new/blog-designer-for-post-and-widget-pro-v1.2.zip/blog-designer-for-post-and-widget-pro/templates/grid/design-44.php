<?php if($gridcol == '2') {
	$newsprogrid = "6";
} else if($gridcol == '3') {
	$newsprogrid = "4";
}  else if($gridcol == '4') {
	$newsprogrid = "3";
}  else if($gridcol == '5') {
	$newsprogrid = "c5";	
} else if ($gridcol == '1') {
	$newsprogrid = "12";
} else {
	$newsprogrid = "12";
}
?>
<div class="wpspw-post-grid wpspw-clr-<?php echo $grid_count; ?> wpspw-medium-<?php echo $newsprogrid; ?> wpspw-columns <?php echo $css_class; ?>">	
	<div class="wpspw-post-overlay"> 
	<a class="wpspw-link-overlay" href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>"></a>	
  		<div class="wpspw-post-image-bg" style="<?php echo $height_css; ?>">
			<?php if( !empty($post_featured_image) ) { ?>
			<img src="<?php echo $post_featured_image; ?>" alt="<?php the_title(); ?>" />
			<?php } ?>
		</div>
		<div class="wpspw-post-grid-content">
			<?php if($showCategory == "true" && $cate_name !='') { ?>
				<div class="wpspw-post-categories">	
				<?php echo $cate_name; ?>
				</div>
				<?php } ?>
			<div class="wpspw-post-content">
				<h2 class="wpspw-post-title">
					<a href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>"><?php the_title(); ?></a>
				</h2>
				<?php if($showDate == "true" || $showAuthor == 'true' || $show_comments =="true") { ?>
							<div class="wpspw-post-date">
								<?php if($showAuthor == 'true') { ?>
									<span class="wpspw-user-img"><img src="<?php echo WPSPW_PRO_URL; ?>assets/images/user-white.svg" alt=""> <?php the_author(); ?></span>
								<?php } ?>
								<?php echo ($showAuthor == 'true' && $showDate == 'true') ? '&nbsp;' : '' ?>
								<?php if($showDate == "true") { ?>
									<span class="wpspw-time"> <img src="<?php echo WPSPW_PRO_URL; ?>assets/images/calendar-white.svg" alt=""> <?php echo get_the_date(); ?> </span>
								<?php } ?>
								<?php echo ($showAuthor == 'true' && $showDate == 'true' && $show_comments == 'true') ? '&nbsp;' : '' ?>
								<?php if(!empty($comments) && $show_comments == 'true') { ?>
									<span class="wpspw-post-comments">
										<img src="<?php echo WPSPW_PRO_URL; ?>assets/images/comment-bubble-white.svg" alt="" />
										<a href="<?php the_permalink(); ?>#comments"><?php echo $comments.' '.$reply;  ?></a>
									</span>
								<?php } ?>	
							</div><!-- end .wpspw-post-date -->
						<?php }  ?>
			</div>
		</div>
	</div>
		<?php if($showContent == "true") { ?>
					<div class="wpspw-post-content">
						<?php if($showFullContent == "false" ) { ?>
							<div class="wpspw-post-short-content"><?php echo wpspw_pro_get_post_excerpt( $post->ID, get_the_content(), $words_limit, $content_tail ); ?></div>

							<?php if($showreadmore == 'true') { ?>
								<a href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>" class="readmorebtn"><?php echo esc_html($read_more_text); ?></a>
							<?php } ?>
						<?php } else { 
								the_content();
							}	?>
					</div>
				<?php } 
				if(!empty($tags) && $show_tags == 'true') { ?>
				<div class="wpspw-post-tags">
					<img src="<?php echo WPSPW_PRO_URL; ?>assets/images/price-tag.svg" alt="" />
					<?php echo $tags;  ?>
				</div><!-- end .wpswp-post-tags -->
			<?php } ?>	
</div>
<?php
	if( $grid_count == 5 || ( $post_count == $count ) ) {
		$grid_count = 0;
?>
<?php } ?>
<?php if($gridcol == '2') {
	$newsprogrid = "6";
} else if($gridcol == '3') {
	$newsprogrid = "4";
}  else if($gridcol == '4') {
	$newsprogrid = "3";
}  else if($gridcol == '5') {
	$newsprogrid = "c5";	
} else if ($gridcol == '1') {
	$newsprogrid = "12";
} else {
	$newsprogrid = "12";
}
?>
<div class="wpspw-post-grid  wpspw-medium-<?php echo $newsprogrid; ?> wpspw-columns <?php echo $css_class; ?>">		
	<div class="wpspw-post-grid-content <?php if ( !has_post_thumbnail() ) { echo 'no-thumb-image'; } ?>">
		<?php		
		if ( has_post_thumbnail() ) { ?>
		<div class="wpspw-post-image-bg" style="<?php echo $height_css; ?>">
			<a href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>">
				<img src="<?php echo $post_featured_image; ?>" alt="<?php _e('Post Image', 'sp-news-and-widget'); ?>" />
			</a>
		</div>
		<?php } ?>	
		<div class="wpspw-content-above-image">	
			<h2 class="wpspw-post-title">
				<a href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>"><?php the_title(); ?></a>
			</h2>
			<?php if($showCategory == "true" && $cate_name !='') { ?>
			<div class="wpspw-post-categories">
				<?php echo $cate_name; ?>
			</div>
			<?php }
			 if($showDate == "true" || $showAuthor == 'true' || $show_comments =="true") { ?>
							<div class="wpspw-post-date">
								<?php if($showAuthor == 'true') { ?>
									<span class="wpspw-user-img"><img src="<?php echo WPSPW_PRO_URL; ?>assets/images/user.svg" alt=""> <?php the_author(); ?></span>
								<?php } ?>
								<?php echo ($showAuthor == 'true' && $showDate == 'true') ? '&nbsp;' : '' ?>
								<?php if($showDate == "true") { ?>
									<span class="wpspw-time"> <img src="<?php echo WPSPW_PRO_URL; ?>assets/images/calendar.svg" alt=""> <?php echo get_the_date(); ?> </span>
								<?php } ?>
								<?php echo ($showAuthor == 'true' && $showDate == 'true' && $show_comments == 'true') ? '&nbsp;' : '' ?>
								<?php if(!empty($comments) && $show_comments == 'true') { ?>
									<span class="wpspw-post-comments">
										<img src="<?php echo WPSPW_PRO_URL; ?>assets/images/comment-bubble.svg" alt="" />
										<a href="<?php the_permalink(); ?>#comments"><?php echo $comments.' '.$reply;  ?></a>
									</span>
								<?php } ?>	
							</div><!-- end .wpspw-post-date -->
						<?php } 
			if($showContent == "true") { ?>
				<div class="wpspw-post-content">
					<?php if($showFullContent == "false" ) { ?>

						<div class="wpspw-post-short-content"><?php echo wpspw_pro_get_post_excerpt( $post->ID, get_the_content(), $words_limit, $content_tail ); ?></div>

						<?php if($showreadmore == 'true') { ?>
							<a href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>" class="readmorebtn"><?php echo esc_html($read_more_text); ?></a>
						<?php } ?>

					<?php } else { 
							the_content();
						}
					?>
				</div>
			<?php }
			if(!empty($tags) && $show_tags == 'true') { ?>
				<div class="wpspw-post-tags">
					<img src="<?php echo WPSPW_PRO_URL; ?>assets/images/price-tag.svg" alt="" />
					<?php echo $tags;  ?>
				</div><!-- end .wpswp-post-tags -->
			<?php } ?>	
		</div>
	</div>
</div>
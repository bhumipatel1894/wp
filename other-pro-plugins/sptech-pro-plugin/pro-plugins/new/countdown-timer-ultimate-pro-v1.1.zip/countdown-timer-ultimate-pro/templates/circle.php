<style type="text/css">
	#wpcdt-datecount-<?php echo $unique; ?> .time_circles > div > h4{color:<?php echo $textcolor; ?> !important;}
	#wpcdt-datecount-<?php echo $unique; ?> .time_circles > div > span{color:<?php echo $digitcolor; ?> !important;}
</style>
<div class="wpcdt-clock wpcdt-clock-circle" data-timer="<?php echo $totalseconds; ?>" style="max-width:<?php echo $width; ?>px;"></div>
jQuery( document ).ready(function($) {

    // Initialize color box
	$('.fmgc-color-box').wpColorPicker();
});
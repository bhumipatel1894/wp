<?php
/*
 * Plugin Name: Hero Banner Ultimate Pro
 * Plugin URI: https://www.wponlinesupport.com/plugins
 * Text Domain: hero-banner-ultimate-pro
 * Description: Display Hero Banner with background image OR video 
 * Domain Path: /languages/
 * Version: 1.1.2
 * Author: WP Online Support
 * Author URI: https://www.wponlinesupport.com
 * Contributors: WP Online Support
*/

if( !defined( 'HBUPRO_VERSION' ) ) {
	define( 'HBUPRO_VERSION', '1.1.2' ); // Version of plugin
}
if( !defined( 'HBUPRO_DIR' ) ) {
    define( 'HBUPRO_DIR', dirname( __FILE__ ) ); // Plugin dir
}
if( !defined( 'HBUPRO_URL' ) ) {
    define( 'HBUPRO_URL', plugin_dir_url( __FILE__ )); // Plugin url
}
if( !defined( 'HBUPRO_PLUGIN_BASENAME' ) ) {
	define( 'HBUPRO_PLUGIN_BASENAME', plugin_basename( __FILE__ ) ); // plugin base name
}
if(!defined( 'HBUPRO_POST_TYPE' ) ) {
	define('HBUPRO_POST_TYPE', 'hbupro_banner'); // Plugin post type
}
if(!defined( 'HBUPRO_META_PREFIX' ) ) {
	define('HBUPRO_META_PREFIX','_hbu_'); // Plugin metabox prefix
}

/**
 * Activation Hook
 * 
 * Register plugin activation hook.
 * 
 * @package Hero Banner Ultimate Pro
 * @since 1.0.0
 */
register_activation_hook( __FILE__, 'hbupro_install' );

/**
 * Deactivation Hook
 * 
 * Register plugin deactivation hook.
 * 
 * @package Hero Banner Ultimate Pro
 * @since 1.0.0
 */
register_deactivation_hook( __FILE__, 'hbupro_uninstall');

/**
 * Plugin Activation Function
 * Does the initial setup, sets the default values for the plugin options
 * 
 * @package Hero Banner Ultimate Pro
 * @since 1.0.0
 */
function hbupro_install() {        
   
}

/**
 * Plugin Functinality (On Deactivation)
 * 
 * Delete  plugin options.
 * 
 * @package Hero Banner Ultimate Pro
 * @since 1.0.0
 */
function hbupro_uninstall() {

}

/**
 * Load Text Domain
 * This gets the plugin ready for translation
 * 
 * @package Hero Banner Ultimate Pro
 * @since 1.0.0
 */
function hbupro_pro_load_textdomain() {

    global $wp_version;

    // Set filter for plugin's languages directory
    $hbupro_lang_dir = dirname( plugin_basename( __FILE__ ) ) . '/languages/';
    $hbupro_lang_dir = apply_filters( 'hbupro_languages_directory', $hbupro_lang_dir );

    // Traditional WordPress plugin locale filter.
    $get_locale = get_locale();

    if ( $wp_version >= 4.7 ) {
        $get_locale = get_user_locale();
    }

    // Traditional WordPress plugin locale filter
    $locale = apply_filters( 'plugin_locale',  $get_locale, 'hero-banner-ultimate-pro' );
    $mofile = sprintf( '%1$s-%2$s.mo', 'hero-banner-ultimate-pro', $locale );

    // Setup paths to current locale file
    $mofile_global  = WP_LANG_DIR . '/plugins/' . basename( HBUPRO_DIR ) . '/' . $mofile;

    if ( file_exists( $mofile_global ) ) { // Look in global /wp-content/languages/plugin-name folder
        load_textdomain( 'hero-banner-ultimate-pro', $mofile_global );
    } else { // Load the default language files
        load_plugin_textdomain( 'hero-banner-ultimate-pro', false, $hbupro_lang_dir );
    }
}
add_action('plugins_loaded', 'hbupro_pro_load_textdomain');


/***** Updater Code Starts *****/
define( 'EDD_HBUPRO_STORE_URL', 'https://www.wponlinesupport.com' );
define( 'EDD_HBUPRO_ITEM_NAME', 'Hero Banner Ultimate Pro' );

// Plugin Updator Class
if( !class_exists( 'EDD_SL_Plugin_Updater' ) ) {	
	include( dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php' );
}

/**
 * Updater Function
 * 
 * @package Hero Banner Ultimate Pro
 * @since 1.0.0
 */
function edd_sl_hbupro_plugin_updater() {
	
	$license_key = trim( get_option( 'edd_hbupro_license_key' ) );

	$edd_updater = new EDD_SL_Plugin_Updater( EDD_HBUPRO_STORE_URL, __FILE__, array(
            'version' 	=> HBUPRO_VERSION,      // current version number
            'license' 	=> $license_key,          // license key (used get_option above to retrieve from DB)
            'item_name' => EDD_HBUPRO_ITEM_NAME,    // name of this plugin
            'author' 	=> 'WP Online Support'    // author of this plugin
		)
	);

}
add_action( 'admin_init', 'edd_sl_hbupro_plugin_updater', 0 );
include( dirname( __FILE__ ) . '/edd-hbupro-plugin.php' );
/***** Updater Code Ends *****/

// Funcions File
require_once( HBUPRO_DIR .'/includes/hbupro-functions.php' );

// Post Type File
require_once( HBUPRO_DIR . '/includes/hbupro-post-types.php' );

// Script Class File
require_once( HBUPRO_DIR . '/includes/class-hbupro-script.php' );

// Admin Class File
require_once( HBUPRO_DIR . '/includes/admin/class-hbupro-admin.php' );

// Shortcode file
require_once( HBUPRO_DIR . '/includes/shortcode/hbupro-popup-shortcode.php' );

// How it work file, Load admin files
if ( is_admin() || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
    require_once( HBUPRO_DIR . '/includes/admin/hbupro-how-it-work.php' );
}

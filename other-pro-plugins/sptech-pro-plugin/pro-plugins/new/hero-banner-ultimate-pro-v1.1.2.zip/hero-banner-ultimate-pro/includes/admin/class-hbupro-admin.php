<?php
/**
 * Admin Class
 *
 * Handles the Admin side functionality of plugin
 *
 * @package Hero Banner Ultimate Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Hbupro_Admin {

	function __construct() {
		
		// Action to add metabox
		add_action( 'add_meta_boxes', array($this, 'hbupro_post_sett_metabox') );

		// Action to save metabox
		add_action( 'save_post', array($this, 'hbupro_save_metabox_value') );		

		// Action to add custom column to Slider listing
		add_filter( 'manage_'.HBUPRO_POST_TYPE.'_posts_columns', array($this, 'hbupro_manage_posts_columns') );

		// Action to add custom column data to Slider listing
		add_action('manage_'.HBUPRO_POST_TYPE.'_posts_custom_column', array($this, 'hbupro_post_columns_data'), 10, 2);

		// Filter to add row data
		add_filter( 'post_row_actions', array($this, 'hbupro_add_post_row_action'), 10, 2 );

		
	}

	/**
	 * Post Settings Metabox
	 * 
	 * @package Hero Banner Ultimate Pro
	 * @since 1.0.0
	 */
	function hbupro_post_sett_metabox() {
		add_meta_box( 'hbupro-post-sett', __( 'Hero Banner - Settings', 'banner-anything-on-click' ), array($this, 'hbupro_post_sett_mb_content'), HBUPRO_POST_TYPE, 'normal', 'high' );
	}

	/**
	 * Post Settings Metabox HTML
	 * 
	 * @package Hero Banner Ultimate Pro
	 * @since 1.0.0
	 */
	function hbupro_post_sett_mb_content() {
		include_once( HBUPRO_DIR .'/includes/admin/metabox/hbupro-post-sett-metabox.php');
	}

	/**
	 * Function to save metabox values
	 * 
	 * @package Hero Banner Ultimate Pro
	 * @since 1.0.0
	 */
	function hbupro_save_metabox_value( $post_id ) {

		global $post_type;
		
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )                	// Check Autosave
		|| ( ! isset( $_POST['post_ID'] ) || $post_id != $_POST['post_ID'] )  	// Check Revision
		|| ( $post_type !=  HBUPRO_POST_TYPE ) )              				// Check if current post type is supported.
		{
		  return $post_id;
		}

		$prefix = HBUPRO_META_PREFIX; // Taking metabox prefix

		// Taking variables
		$banner_type 			= isset($_POST[$prefix.'banner_type']) 				? $_POST[$prefix.'banner_type'] 			: '';
		$color_type 			= isset($_POST[$prefix.'color_type']) 				? $_POST[$prefix.'color_type'] 				: '';
		$banner_layout 			= isset($_POST[$prefix.'banner_layout']) 			? $_POST[$prefix.'banner_layout'] 			: '';
		$banner_bg_color 		= isset($_POST[$prefix.'banner_bg_color']) 			? $_POST[$prefix.'banner_bg_color'] 		: '';
		$banner_gradient_color 	= isset($_POST[$prefix.'banner_gradient_color']) 	? $_POST[$prefix.'banner_gradient_color'] 	: '';
		$banner_gradient_position = isset($_POST[$prefix.'banner_gradient_position']) 	? $_POST[$prefix.'banner_gradient_position'] 	: '';
		$banner_image_url 		= isset($_POST[$prefix.'banner_image_url']) 		? $_POST[$prefix.'banner_image_url'] 		: '';
		$banner_video_url 		= isset($_POST[$prefix.'banner_video_url']) 		? $_POST[$prefix.'banner_video_url'] 		: '';
		$banner_vmvideo_url 	= isset($_POST[$prefix.'banner_vmvideo_url']) 		? $_POST[$prefix.'banner_vmvideo_url'] 		: '';				
		$banner_poster_url 		= isset($_POST[$prefix.'banner_poster_url']) 		? $_POST[$prefix.'banner_poster_url'] 		: '';
		$banner_ovelay_color 	= isset($_POST[$prefix.'banner_ovelay_color']) 		? $_POST[$prefix.'banner_ovelay_color']		: '';
		$banner_ovelay_opacity	= isset($_POST[$prefix.'banner_ovelay_opacity']) 	? $_POST[$prefix.'banner_ovelay_opacity']	: '';
		$banner_title_color 	= isset($_POST[$prefix.'banner_title_color']) 		? $_POST[$prefix.'banner_title_color'] 		: '';	
		$banner_content_color 	= isset($_POST[$prefix.'banner_content_color']) 	? $_POST[$prefix.'banner_content_color'] 	: '';	
		$banner_title_fontsize 	= isset($_POST[$prefix.'banner_title_fontsize']) 	? $_POST[$prefix.'banner_title_fontsize'] 	: '';
		$banner_subtitle_fontsize= isset($_POST[$prefix.'banner_subtitle_fontsize'])? $_POST[$prefix.'banner_subtitle_fontsize']: '';
		$banner_title_upper 	= isset($_POST[$prefix.'banner_title_upper']) 	? $_POST[$prefix.'banner_title_upper'] 	: '';
		$banner_subtitle_uppercase= isset($_POST[$prefix.'banner_subtitle_uppercase'])? $_POST[$prefix.'banner_subtitle_uppercase']: '';
		$banner_button_one_name	= isset($_POST[$prefix.'banner_button_one_name']) 	? $_POST[$prefix.'banner_button_one_name']	: '';
		$banner_button_one_link = isset($_POST[$prefix.'banner_button_one_link']) 	? $_POST[$prefix.'banner_button_one_link'] 	: '';	
		$banner_button_two_name = isset($_POST[$prefix.'banner_button_two_name']) 	? $_POST[$prefix.'banner_button_two_name'] 	: '';	
		$banner_button_two_link = isset($_POST[$prefix.'banner_button_two_link']) 	? $_POST[$prefix.'banner_button_two_link'] 	: '';		
		$banner_bg_size 		= isset($_POST[$prefix.'banner_bg_size']) 			? $_POST[$prefix.'banner_bg_size'] 			: '';
		$banner_bg_attachemnt 	= isset($_POST[$prefix.'banner_bg_attachemnt'])		? $_POST[$prefix.'banner_bg_attachemnt'] 	: '';
		$banner_bg_position 	= isset($_POST[$prefix.'banner_bg_position']) 		? $_POST[$prefix.'banner_bg_position'] 		: '';
		$banner_padding_top 	= isset($_POST[$prefix.'banner_padding_top']) 		? $_POST[$prefix.'banner_padding_top'] 		: '';
		$banner_padding_right 	= isset($_POST[$prefix.'banner_padding_right']) 	? $_POST[$prefix.'banner_padding_right'] 	: '';		
		$banner_padding_bottom 	= isset($_POST[$prefix.'banner_padding_bottom']) 	? $_POST[$prefix.'banner_padding_bottom'] 	: '';	
		$banner_padding_left 	= isset($_POST[$prefix.'banner_padding_left']) 		? $_POST[$prefix.'banner_padding_left'] 	: '';
		$banner_wrap_width 		= isset($_POST[$prefix.'banner_wrap_width']) 		? $_POST[$prefix.'banner_wrap_width'] 		: '';	
		$banner_button_one_class = isset($_POST[$prefix.'banner_button_one_class']) ? $_POST[$prefix.'banner_button_one_class'] : '';
		$banner_button_two_class = isset($_POST[$prefix.'banner_button_two_class']) ? $_POST[$prefix.'banner_button_two_class'] : '';

		/* Mobile Data */
		$banner_button_hide_img = isset($_POST[$prefix.'banner_button_hide_img']) ? $_POST[$prefix.'banner_button_hide_img'] : '';
		$banner_mobile_title_fontsize = isset($_POST[$prefix.'banner_mobile_title_fontsize']) ? $_POST[$prefix.'banner_mobile_title_fontsize'] : '';
		$banner_mobile_subtitle_fontsize = isset($_POST[$prefix.'banner_mobile_subtitle_fontsize']) ? $_POST[$prefix.'banner_mobile_subtitle_fontsize'] : '';
		$banner_mobile_bg_size 	= isset($_POST[$prefix.'banner_mobile_bg_size']) 	? $_POST[$prefix.'banner_mobile_bg_size'] 	: '';

		update_post_meta($post_id, $prefix.'banner_type', $banner_type);
		update_post_meta($post_id, $prefix.'color_type', $color_type);
		update_post_meta($post_id, $prefix.'banner_bg_color', $banner_bg_color);
		update_post_meta($post_id, $prefix.'banner_gradient_color', $banner_gradient_color);
		update_post_meta($post_id, $prefix.'banner_gradient_position', $banner_gradient_position);
		update_post_meta($post_id, $prefix.'banner_layout', $banner_layout);
		update_post_meta($post_id, $prefix.'banner_video_url', $banner_video_url);
		update_post_meta($post_id, $prefix.'banner_vmvideo_url', $banner_vmvideo_url);	
		update_post_meta($post_id, $prefix.'banner_poster_url', $banner_poster_url);	
		update_post_meta($post_id, $prefix.'banner_image_url', $banner_image_url);	
		update_post_meta($post_id, $prefix.'banner_ovelay_color', $banner_ovelay_color);
		update_post_meta($post_id, $prefix.'banner_ovelay_opacity', $banner_ovelay_opacity);
		update_post_meta($post_id, $prefix.'banner_title_color', $banner_title_color);
		update_post_meta($post_id, $prefix.'banner_content_color', $banner_content_color);		
		update_post_meta($post_id, $prefix.'banner_title_fontsize', $banner_title_fontsize);
		update_post_meta($post_id, $prefix.'banner_subtitle_fontsize', $banner_subtitle_fontsize);
		update_post_meta($post_id, $prefix.'banner_title_upper', $banner_title_upper);
		update_post_meta($post_id, $prefix.'banner_subtitle_uppercase', $banner_subtitle_uppercase);
		update_post_meta($post_id, $prefix.'banner_button_one_name', $banner_button_one_name);
		update_post_meta($post_id, $prefix.'banner_button_one_link', $banner_button_one_link);
		update_post_meta($post_id, $prefix.'banner_button_two_name', $banner_button_two_name);		
		update_post_meta($post_id, $prefix.'banner_button_two_link', $banner_button_two_link);
		update_post_meta($post_id, $prefix.'banner_bg_size', $banner_bg_size);		
		update_post_meta($post_id, $prefix.'banner_bg_attachemnt', $banner_bg_attachemnt);
		update_post_meta($post_id, $prefix.'banner_bg_position', $banner_bg_position);
		update_post_meta($post_id, $prefix.'banner_padding_top', $banner_padding_top);
		update_post_meta($post_id, $prefix.'banner_padding_right', $banner_padding_right);
		update_post_meta($post_id, $prefix.'banner_padding_bottom', $banner_padding_bottom);		
		update_post_meta($post_id, $prefix.'banner_padding_left', $banner_padding_left);
		update_post_meta($post_id, $prefix.'banner_wrap_width', $banner_wrap_width);
		update_post_meta($post_id, $prefix.'banner_button_one_class', $banner_button_one_class);
		update_post_meta($post_id, $prefix.'banner_button_two_class', $banner_button_two_class);	
		
		/* Mobile Setting Update data */
		update_post_meta($post_id, $prefix.'banner_button_hide_img', $banner_button_hide_img);
		update_post_meta($post_id, $prefix.'banner_mobile_title_fontsize', $banner_mobile_title_fontsize);
		update_post_meta($post_id, $prefix.'banner_mobile_subtitle_fontsize', $banner_mobile_subtitle_fontsize);
		update_post_meta($post_id, $prefix.'banner_mobile_bg_size', $banner_mobile_bg_size);			
		
	}
	
	
	/**
	 * Add custom column to Post listing page
	 * 
	 * @package Hero Banner Ultimate Pro
	 * @since 1.0.0
	 */
	function hbupro_manage_posts_columns( $columns ) {
		
		$new_columns['hbupro_shortcode'] 	= __( 'Shortcode', 'banner-anything-on-click' );	   

	    $columns = hbupro_add_array( $columns, $new_columns, 1, true );

	    return $columns;
	}

	/**
	 * Add custom column data to Post listing page
	 * 
	 * @package Hero Banner Ultimate Pro
	 * @since 1.0.0
	 */
	function hbupro_post_columns_data( $column, $post_id ) {

		$prefix = HBUPRO_META_PREFIX; // Taking metabox prefix

	    switch ($column) {
			case 'hbupro_shortcode':			
				$shortcode_string = '';
				$shortcode_string .= '[hbupro_banner id="'.$post_id.'"] ';				
				echo $shortcode_string;
				break;
			
		}
	}

	/**
	 * Function to add custom quick links at post listing page
	 * 
	 * @package Hero Banner Ultimate Pro
	 * @since 1.0.0
	 */
	function hbupro_add_post_row_action($actions, $post ) {
		if( $post->post_type == HBUPRO_POST_TYPE ) {
			return array_merge( array( 'hbupro_id' => 'ID: ' . $post->ID ), $actions );
		}
		return $actions;
	}
	
	
}

$hbupro_admin = new Hbupro_Admin();

<?php
/**
 * Script Class
 * Handles the script and style functionality of plugin
 *
 * @package Hero Banner Ultimate Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Hbupro_Script {

	function __construct() {

		// Action to add script at front side
		add_action( 'wp_enqueue_scripts', array($this, 'hbupro_front_style') );
		
		// Action to add script at front side
		add_action( 'wp_enqueue_scripts', array($this, 'hbupro_front_script') );

		// Action to add style in backend
		add_action( 'admin_enqueue_scripts', array($this, 'hbupro_admin_style') );		
		
		// Action to add script in backend
		add_action( 'admin_enqueue_scripts', array($this, 'hbupro_admin_script') );		
		
	}
	
	/**
	 * Function to add style at front side
	 * 
	 * @package Hero Banner Ultimate Pro
	 * @since 1.0.0
	 */
	function hbupro_front_style() {		

		// Registring and enqueing button with style pro css
		wp_register_style( 'hbupro-public-style', HBUPRO_URL.'assets/css/hbupro-public-style.css', array(), HBUPRO_VERSION );
		wp_enqueue_style( 'hbupro-public-style' );

	}	
	
	/**
	 * Function to add style at front side
	 * 
	 * @package Hero Banner Ultimate Pro
	 * @since 1.0.0
	 */
	function hbupro_front_script() {		

		wp_register_script( 'hbupro-video-script', HBUPRO_URL.'assets/js/hbupro-ultimate-bg.js', array('jquery'), HBUPRO_VERSION, true );		

	}	

	/**
	 * Enqueue admin styles
	 * 
	 * @package Hero Banner Ultimate Pro
	 * @since 1.0.0
	 */
	function hbupro_admin_style( $hook ) {

		global $typenow;

		// Taking pages array
		$pages_arr = array( HBUPRO_POST_TYPE );

		if( in_array($typenow, $pages_arr) ) {
			wp_register_style( 'hbupro-admin-style', HBUPRO_URL.'assets/css/hbupro-admin-style.css', array(), HBUPRO_VERSION );
			wp_enqueue_style( 'hbupro-admin-style' );
			
		// Enqueu built in style for color picker
			if( wp_style_is( 'wp-color-picker', 'registered' ) ) { // Since WordPress 3.5
				wp_enqueue_style( 'wp-color-picker' );
			}	
		}		
		
	}

	/**
	 * Enqueue admin script
	 * 
	 * @package Hero Banner Ultimate Pro
	 * @since 1.0.0
	 */
	function hbupro_admin_script( $hook ) {

		global $typenow, $wp_version;
		$new_ui = $wp_version >= '3.5' ? '1' : '0'; // Check wordpress version for older scripts
		// Taking pages array
		$pages_arr = array( HBUPRO_POST_TYPE );

		if( in_array($typenow, $pages_arr) ) {
			
			// Enqueu built-in script for color picker
			if( wp_script_is( 'wp-color-picker', 'registered' ) ) { // Since WordPress 3.5
				wp_enqueue_script( 'wp-color-picker' );
			}
			
			// Registring admin script
			wp_register_script( 'hbupro-admin-script', HBUPRO_URL.'assets/js/hbupro-admin-script.js', array('jquery'), HBUPRO_VERSION, true );
			wp_enqueue_script( 'hbupro-admin-script' );
			wp_localize_script( 'hbupro-admin-script', 'HbuproAdmin', array(
																		'new_ui' 	=>	$new_ui,
																		'sry_msg' => __('Sorry, One entry should be there.', 'hero-banner-ultimate-pro'),			
			
			));			
		}
		
	}

}

$hbupro_script = new Hbupro_Script();
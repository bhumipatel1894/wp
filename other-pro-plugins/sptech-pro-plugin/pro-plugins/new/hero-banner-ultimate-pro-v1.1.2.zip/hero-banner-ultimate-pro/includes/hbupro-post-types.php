<?php
/**
 * Register Post type functionality 
 * @package hero-banner-ultimate-pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Function to register post type
 * 
 * @package hero-banner-ultimate-pro
 * @since 1.0.0
 */
function hbupro_register_post_type() {

	$hbupro_post_lbls = apply_filters( 'hbupro_post_labels', array(
								'name'                 	=> __('Hero Banner', 'hero-banner-ultimate-pro'),
								'singular_name'        	=> __('Hero Banner', 'hero-banner-ultimate-pro'),
								'add_new'              	=> __('Add Hero Banner', 'hero-banner-ultimate-pro'),
								'add_new_item'         	=> __('Add New Hero Banner', 'hero-banner-ultimate-pro'),
								'edit_item'            	=> __('Edit Hero Banner', 'hero-banner-ultimate-pro'),
								'new_item'             	=> __('New Hero Banner', 'hero-banner-ultimate-pro'),
								'view_item'            	=> __('View Hero Banner', 'hero-banner-ultimate-pro'),
								'search_items'         	=> __('Search Hero Banner', 'hero-banner-ultimate-pro'),
								'not_found'            	=> __('No Hero Banner found', 'hero-banner-ultimate-pro'),
								'not_found_in_trash'   	=> __('No Hero Banner found in trash', 'hero-banner-ultimate-pro'),
								'parent_item_colon'    	=> '',
								'menu_name'            	=> __('Hero Banner Pro', 'hero-banner-ultimate-pro')
							));

	$hbupro_args = array(
		'labels'				=> $hbupro_post_lbls,
		'public'              	=> false,
		'show_ui'             	=> true,
		'query_var'           	=> false,
		'rewrite'             	=> false,
		'capability_type'     	=> 'post',
		'hierarchical'        	=> false,
		'menu_icon'				=> 'dashicons-welcome-view-site',
		'supports'            	=> apply_filters('hbupro_post_supports', array('title','editor')),
	);

	// Register slick slider post type
	register_post_type( HBUPRO_POST_TYPE, apply_filters( 'hbupro_registered_post_type_args', $hbupro_args ) );
}

// Action to register plugin post type
add_action('init', 'hbupro_register_post_type');

/**
 * Function to update post message for popup
 * 
 * @package Popup anything on click
 * @since 1.0.0
 */
function hbupro_post_updated_messages( $messages ) {

	global $post, $post_ID;

	$messages[HBUPRO_POST_TYPE] = array(
		0 => '', // Unused. Messages start at index 1.
		1 => sprintf( __( 'Popup updated.', 'hero-banner-ultimate-pro' ) ),
		2 => __( 'Custom field updated.', 'hero-banner-ultimate-pro' ),
		3 => __( 'Custom field deleted.', 'hero-banner-ultimate-pro' ),
		4 => __( 'Popup updated.', 'hero-banner-ultimate-pro' ),
		5 => isset( $_GET['revision'] ) ? sprintf( __( 'Popup restored to revision from %s', 'hero-banner-ultimate-pro' ), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
		6 => sprintf( __( 'Popup published.', 'hero-banner-ultimate-pro' ) ),
		7 => __( 'Popup saved.', 'hero-banner-ultimate-pro' ),
		8 => sprintf( __( 'Popup submitted.', 'hero-banner-ultimate-pro' ) ),
		9 => sprintf( __( 'Popup scheduled for: <strong>%1$s</strong>.', 'hero-banner-ultimate-pro' ),
		  date_i18n( 'M j, Y @ G:i', strtotime( $post->post_date ) ) ),
		10 => sprintf( __( 'Popup draft updated.', 'hero-banner-ultimate-pro' ) ),
	);	
	return $messages;
}
// Filter to update slider post message
add_filter( 'post_updated_messages', 'hbupro_post_updated_messages' );
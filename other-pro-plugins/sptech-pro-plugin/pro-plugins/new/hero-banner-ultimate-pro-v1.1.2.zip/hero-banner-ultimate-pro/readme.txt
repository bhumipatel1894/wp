=== Hero Banner Ultimate Pro ===
Tags: hero image, hero banner, hero header, hero video, video background, hero video, youtube video background, vimeo video background
Contributors: wponlinesupport, anoopranawat 
Requires at least: 3.1
Tested up to: 4.8.1
Stable tag: trunk
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Add hero banner with the help of background image OR background color OR background video. 

== Description ==

Add hero banner with the help of background image OR background color OR background video. Hero Banner Ultimate comes with 4 types of layouts where you can manage you hero banner design.

View [FREE DEMO](http://demo.wponlinesupport.com/hero-banner-ultimate-demo/) for more details.

In web design, a hero banner is a large web banner image, prominently placed on a web page, generally in the front and center. The hero banner is often the first visual a visitor encounters on the site; it presents an overview of the site's most important content. A hero image often consists of background image OR background color OR background video and text.

Large fullscreen backgrounds and hero banners can be used in single page designs with ease.

= Hero Banner Ultimate Features =
* Background image
* Background color
* Background video
* Title and sub title font size
* Title and sub title font color
* Banner inner padding
* Banner overlay setting
* Call to Action Setting

== Installation ==

1. Upload the 'hero-banner-ultimate-pro' folder to the '/wp-content/plugins/' directory.
2. Activate the "hero-banner-ultimate-pro" list plugin through the 'Plugins' menu in WordPress.

== Changelog ==

= 1.1.2 =
* [*] Fixed responsive issue on mobile
* [*] Fixed mobile setting added from admin side

= 1.1.1 =
* [*] Fixed some layout issues

= 1.1 =
* [+] Added some new options and Layouts

= 1.0 =
* Initial release.

== Upgrade Notice ==

= 1.1.2 =
* [*] Fixed responsive issue on mobile
* [*] Fixed mobile setting added from admin side

= 1.1.1 =
* [*] Fixed some layout issues

= 1.1 =
* [+] Added some new options and Layouts

= 1.0 =
* Initial release.
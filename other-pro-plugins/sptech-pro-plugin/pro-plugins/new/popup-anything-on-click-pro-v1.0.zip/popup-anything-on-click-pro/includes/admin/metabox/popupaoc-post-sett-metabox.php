<?php
/**
 * Handles Post Setting metabox HTML
 *
 * @package Buttons With Style Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

global $post, $wp_version;

// Taking some variables
$prefix 				= POPUPAOCPRO_META_PREFIX; // Metabox prefix
$popup_type_list 		= popupaocpro_popup_type();
$popup_effect_list 		= popupaocpro_effect();
$popup_positionx_list	= popupaocpro_positionx();
$popup_positiony_list 	= popupaocpro_positiony();
$popup_fullscreen_list 	= popupaocpro_popupfullscreen();
$popup_overlay_list     = popupaocpro_popupoverlay();
$popup_lodaer_list 	    = popupaocpro_lodaer();


// Getting saved values
$popup_type 			= get_post_meta( $post->ID, $prefix.'popup_type', true );
$popup_link_txt 		= get_post_meta( $post->ID, $prefix.'popup_link_txt', true );
$popup_button_txt 		= get_post_meta( $post->ID, $prefix.'popup_button_txt', true );
$popup_image_url 		= get_post_meta( $post->ID, $prefix.'popup_image_url', true );
$full_screen 			= get_post_meta( $post->ID, $prefix.'full_screen', true );
$popup_effect 			= get_post_meta( $post->ID, $prefix.'popup_effect', true );
$popup_positionx 		= get_post_meta( $post->ID, $prefix.'popup_positionx', true );
$popup_positiony 		= get_post_meta( $post->ID, $prefix.'popup_positiony', true );
$speedin 				= get_post_meta( $post->ID, $prefix.'speedin', true );
$speedout 				= get_post_meta( $post->ID, $prefix.'speedout', true );
$delay 					= get_post_meta( $post->ID, $prefix.'delay', true );
$enable_loader 			= get_post_meta( $post->ID, $prefix.'enable_loader', true );
$enable_ovelay 			= get_post_meta( $post->ID, $prefix.'enable_ovelay', true );
$popup_ovelay_color 	= get_post_meta( $post->ID, $prefix.'popup_ovelay_color', true );
$popup_ovelay_opacity 	= get_post_meta( $post->ID, $prefix.'popup_ovelay_opacity', true );
$loader_color 			= get_post_meta( $post->ID, $prefix.'loader_color', true );
$loader_speed 			= get_post_meta( $post->ID, $prefix.'loader_speed', true );
$popup_width            = get_post_meta( $post->ID, $prefix.'popup_width', true );
$button_class           = get_post_meta( $post->ID, $prefix.'button_class', true );

if($popup_type == 'simple_link' || $popup_type == '') {
	$popup_simple_style = 'style = "display:table"';
	$popup_img_style = 'style = "display:none"';
	$popup_img_btn = 'style = "display:none"';
} elseif($popup_type == 'image') {
	$popup_img_style = 'style = "display:table"';
	$popup_simple_style = 'style = "display:none"';
	$popup_img_btn = 'style = "display:none"';
}
else{
	$popup_img_btn = 'style = "display:table"';
	$popup_simple_style = 'style = "display:none"';
	$popup_img_style = 'style = "display:none"';
}
?>



<table class="form-table popupaoc-post-sett-tbl">
	<tbody>
		<!-- popup button text -->
		<tr valign="top">
			<th scope="row">
				<label for="popup-btn-type"><?php _e('Link type', 'popup-anything-on-click'); ?></label>
			</th>
			<td class="row-meta">
				<select name="<?php echo $prefix;?>popup_type" class="popupaoc-select-box popup-btn-type" id="popup-btn-type">
					<?php
					if( !empty($popup_type_list) ) {
						foreach ($popup_type_list as $key => $value) {
							echo '<option value="'.$key.'" '.selected($popup_type,$key).'>'.$value.'</option>';
						}
					}
					?>
				</select>
				<br/>
				<span class="description"><?php _e('Select on click type ie where user going to click.', 'popup-anything-on-click'); ?></span>
			</td>			
		</tr>
		<!-- Simple button settings -->
		<tr valign="top">
			<td colspan="2" class="popupaoc-no-padding">
				<table class="form-table popupaoc-simple-link" <?php echo $popup_simple_style;?>>
								
					<tr>
						<th><label for="popupaoc-simple-btn-name"><?php echo __('Link Text','popup-anything-on-click');?></label></th>
						<td class="row-meta">
							<input type="text" name="<?php echo $prefix;?>popup_link_txt" value="<?php echo $popup_link_txt; ?>" class="large-text" placeholder="<?php _e('Link Text', 'popup-anything-on-click'); ?>" /><br/>
							<br/>
							<span class="description"><?php _e('Enter text.', 'popup-anything-on-click'); ?></span>
						</td>
					</tr>						
					
				</table>
				<table class="form-table popupaoc-simple-button" <?php echo $popup_img_btn;?>>
					
					<tr>
						<th>
							<?php _e('Button Text','');?>
						</th>
						<td class="row-meta">
							<input type="text" name="<?php echo $prefix;?>popup_button_txt" value="<?php echo $popup_button_txt; ?>" class="large-text" placeholder="<?php _e('Button Text', 'popup-anything-on-click'); ?>" /><br/>							
							<span class="description"><?php _e('Enter Popup button text.', 'popup-anything-on-click'); ?></span>
						</td>
					</tr>
					<tr>
						<th>
							<?php _e('Button Custom Class','');?>
						</th>
						<td class="row-meta">
							<input type="text" name="<?php echo $prefix;?>button_class" value="<?php echo $button_class; ?>" class="large-text" placeholder="<?php _e('popupaoc-button', 'popup-anything-on-click'); ?>" /><br/>							
							<span class="description"><?php _e('You can use our some predefinded classes : popupaoc-black, popupaoc-white, popupaoc-grey, popupaoc-azure, popupaoc-moderate-green, popupaoc-soft-red, popupaoc-red, popupaoc-green, popupaoc-bright-yellow, popupaoc-cyan, popupaoc-orange, popupaoc-moderate-violet, popupaoc-dark-magenta, popupaoc-moderate-blue, popupaoc-blue, .popupaoc-magenta, .popupaoc-lime, popupaoc-pink, popupaoc-vivid-yellow, popupaoc-lime-green, popupaoc-yellow', 'popup-anything-on-click'); ?></span>
						</td>
					</tr>
					
					
				</table><!-- end .popupaoc-group-button-sett -->
				<table class="form-table popupaoc-simple-image" <?php echo $popup_img_style;?>>
					
					<tr>
						<th>
							<?php _e('Upload Image','');?>
						</th>
						<td>
							<input type="text" name="<?php echo $prefix.'popup_image_url';?>" value="<?php echo $popup_image_url;?>" id="popup-anything-default-img" class="regular-text popup-antything-default-img popup-antything-img-upload-input" />
							<input type="button" name="popup_default_img" class="button-secondary popup-anything-img-uploader" value="<?php _e( 'Upload Image', 'popup-anything-on-click'); ?>" />
							<input type="button" name="popu_default_img_clear" id="popup-anything-default-img-clear" class="button button-secondary popup-anything-image-clear" value="<?php _e( 'Clear', 'popup-anything-on-click'); ?>" /> <br />
							<span class="description"><?php _e( 'Upload popup button image.','popup-anything-on-click' ); ?></span>
							<?php
								$default_img = '';
								if( !empty($popup_image_url)) { 
									$default_img = '<img src="'.$popup_image_url.'" alt="" />';
								}
							?>
							<div class="popup-anything-imgs-preview"><?php echo $default_img; ?></div>
						</td>
					</tr>
					
				</table><!-- end .popupaoc-group-button-sett -->
			</td>
		</tr>
		<tr valign="top" style="border-bottom:1px solid #ddd;">
			<th scope="row" colspan="2"><h3 style="padding-bottom:0px;margin-bottom:0px;"><?php _e('Popup Screen and Effects', 'popup-anything-on-click'); ?></h3></th>
		</tr>
		<!-- popup screen -->
		<tr valign="top">
			<th scope="row">
				<label for="popupaoc-full-screen"><?php _e('Full Screen', 'popup-anything-on-click'); ?></label>
			</th>			
			<td class="row-meta">			
				<select name="<?php echo $prefix;?>full_screen" class="popupaoc-select-box popupaoc-btn-clr-class" id="popupaoc-full-screen">
					<?php
					if( !empty($popup_fullscreen_list) ) {
						foreach ($popup_fullscreen_list as $key => $value) {
							echo '<option value="'.$key.'" '.selected($full_screen,$key).'>'.$value.'</option>';
						}
					}
					?>
				</select><br/>
				<span class="description"><?php _e('Enable popup full screen.', 'popup-anything-on-click'); ?></span>
			</td>			
		</tr>	
		<tr valign="top">
			<th scope="row">
				<label for="popupaoc-popup-width"><?php _e('Popup Width', 'popup-anything-on-click'); ?></label>
			</th>
			<td class="row-meta">			
				<input type="text" name="<?php echo $prefix;?>popup_width" id="popupaoc-popup-width" value="<?php echo $popup_width; ?>" class="regular-text" placeholder="<?php _e('70%', 'popup-anything-on-click'); ?>" /><br/>
				<span class="description"><?php _e('Set a total width in %..', 'popup-anything-on-click'); ?></span>
			</td>			
		</tr>	
		<!-- popup effect -->
		<tr valign="top">
			<th scope="row">
				<label for="popupaoc-effect"><?php _e('Effect', 'popup-anything-on-click'); ?></label>
			</th>
			<td class="row-meta">			
				<select name="<?php echo $prefix;?>popup_effect" class="popupaoc-select-box popupaoc-btn-clr-class" id="popupaoc-effect">
					<?php
					if( !empty($popup_effect_list) ) {
						foreach ($popup_effect_list as $key => $value) {
							echo '<option value="'.$key.'" '.selected($popup_effect,$key).'>'.$value.'</option>';
						}
					}
					?>
				</select><br/>
				<span class="description"><?php _e('Select effect.', 'popup-anything-on-click'); ?></span>
			</td>			
		</tr>
		
		<!-- popup speedin -->
		<tr valign="top">
			<th scope="row">
				<label for="popupaoc-speedin"><?php _e('SpeedIn', 'popup-anything-on-click'); ?></label>
			</th>
			<td class="row-meta">			
				<input type="number" id="popupaoc-speedin" name="<?php echo $prefix;?>speedin" value="<?php echo $speedin; ?>" class="regular-text" placeholder="<?php _e('300', 'popup-anything-on-click'); ?>" /><br/>
				<span class="description"><?php _e('Enter the speed start of the animation in milliseconds.', 'popup-anything-on-click'); ?></span>
			</td>			
		</tr>
		<!-- popup speedout -->
		<tr valign="top">
			<th scope="row">
				<label for="popupaoc-speedout"><?php _e('SpeedOut', 'popup-anything-on-click'); ?></label>
			</th>
			<td class="row-meta">			
				<input type="number" id="popupaoc-speedout" name="<?php echo $prefix;?>speedout" value="<?php echo $speedout; ?>" class="regular-text" placeholder="<?php _e('300', 'popup-anything-on-click'); ?>" /><br/>
				<span class="description"><?php _e('Enter the speed end of the animation in milliseconds.', 'popup-anything-on-click'); ?></span>
			</td>			
		</tr>
		<!-- popup delay -->
		<tr valign="top">
			<th scope="row">
				<label for="popupaoc-delay"><?php _e('Delay', 'popup-anything-on-click'); ?></label>
			</th>
			<td class="row-meta">			
				<input type="number" id="popupaoc-delay" name="<?php echo $prefix;?>delay" value="<?php echo $delay; ?>" class="regular-text" placeholder="<?php _e('150', 'popup-anything-on-click'); ?>" /><br/>
				<span class="description"><?php _e('Enter the wait before the transition effect start.', 'popup-anything-on-click'); ?></span>
			</td>			
		</tr>
		<tr valign="top" style="border-bottom:1px solid #ddd;">
			<th scope="row" colspan="2"><h3 style="padding-bottom:0px;margin-bottom:0px;"><?php _e('Popup Position', 'popup-anything-on-click'); ?></h3></th>
		</tr>
		<!-- popup positionx -->
		<tr valign="top">
			<th scope="row">
				<label for="popupaoc-positionx"><?php _e('PositionX', 'popup-anything-on-click'); ?></label>
			</th>
			<td class="row-meta">			
				<select name="<?php echo $prefix;?>popup_positionx" class="popupaoc-select-box popupaoc-btn-clr-class" id="popupaoc-positionx">
					<?php
					if( !empty($popup_positionx_list) ) {
						foreach ($popup_positionx_list as $key => $value) {
							echo '<option value="'.$key.'" '.selected($popup_positionx,$key).'>'.$value.'</option>';
						}
					}
					?>
				</select><br/>
				<span class="description"><?php _e('Select position X (Horizontal).', 'popup-anything-on-click'); ?></span>
			</td>			
		</tr>
		<!-- popup positiony -->
		<tr valign="top">
			<th scope="row">
				<label for="popupaoc-positiony"><?php _e('PositionY', 'popup-anything-on-click'); ?></label>
			</th>
			<td class="row-meta">			
				<select name="<?php echo $prefix;?>popup_positiony" class="popupaoc-select-box popupaoc-btn-clr-class" id="popupaoc-positiony">
					<?php
					if( !empty($popup_positiony_list) ) {
						foreach ($popup_positiony_list as $key => $value) {
							echo '<option value="'.$key.'" '.selected($popup_positiony,$key).'>'.$value.'</option>';
						}
					}
					?>
				</select><br/>
				<span class="description"><?php _e('Select position Y (Vertical).', 'popup-anything-on-click'); ?></span>
			</td>			
		</tr>		
		
		<tr valign="top" style="border-bottom:1px solid #ddd;">
			<th scope="row" colspan="2"><h3 style="padding-bottom:0px;margin-bottom:0px;"><?php _e('Popup Loader Setting', 'popup-anything-on-click'); ?></h3></th>
		</tr>
		<!-- popup loader -->
		<tr valign="top">
			<th scope="row">
				<label for="popupaoc-loader"><?php _e('Enable Loader', 'popup-anything-on-click'); ?></label>
			</th>
			<td class="row-meta">			
				<select name="<?php echo $prefix;?>enable_loader" class="popupaoc-select-box popupaoc-btn-clr-class" id="popupaoc-loader">
					<?php
					if( !empty($popup_lodaer_list) ) {
						foreach ($popup_lodaer_list as $key => $value) {
							echo '<option value="'.$key.'" '.selected($enable_loader,$key).'>'.$value.'</option>';
						}
					}
					?>
				</select><br/>
				<span class="description"><?php _e('Enable loader.', 'popup-anything-on-click'); ?></span>
			</td>				
		</tr>
		<tr>
			<th scope="row">
					<label for="popupaoc-loader-color"><?php _e('Loader Color', 'popup-anything-on-click'); ?>:</label>
			</th>
			<td>				
				<input type="text" value="<?php echo $loader_color; ?>" id="popupaoc-loader-color" name="<?php echo $prefix;?>loader_color" class="popupaoc-color-box" /><br/>						
				<span class="description"><?php _e('Select Loader Color.', 'popup-anything-on-click'); ?></span>
			</td>
		</tr>
		<tr valign="top">
			<th scope="row">
				<label for="popupaoc-loader-speed"><?php _e('Loader Speed', 'popup-anything-on-click'); ?></label>
			</th>
			<td class="row-meta">			
				<input type="number" name="<?php echo $prefix;?>loader_speed" id="popupaoc-loader-speed" value="<?php echo $loader_speed; ?>" class="regular-text" placeholder="<?php _e(' 1500', 'popup-anything-on-click'); ?>" /><br/>
				<span class="description"><?php _e('Set the speed in milliseconds of the loader.', 'popup-anything-on-click'); ?></span>
			</td>			
		</tr>
		<!-- popup overlay -->
		<tr valign="top" style="border-bottom:1px solid #ddd;">
			<th scope="row" colspan="2"><h3 style="padding-bottom:0px;margin-bottom:0px;"><?php _e('Popup Overlay Setting', 'popup-anything-on-click'); ?></h3></th>
		</tr>
		<tr valign="top">
			<th scope="row">
				<label for="popupaoc-overlay"><?php _e('Enable Overlay', 'popup-anything-on-click'); ?></label>
			</th>
			<td class="row-meta">			
				<select name="<?php echo $prefix;?>enable_ovelay" class="popupaoc-select-box popupaoc-btn-clr-class" id="popupaoc-overlay">
					<?php
					if( !empty($popup_overlay_list) ) {
						foreach ($popup_overlay_list as $key => $value) {
							echo '<option value="'.$key.'" '.selected($enable_ovelay,$key).'>'.$value.'</option>';
						}
					}
					?>
				</select><br/>
				<span class="description"><?php _e('Enable Overlay', 'popup-anything-on-click'); ?></span>
			</td>				
		</tr>
		<tr>
			<th scope="row">
					<label for="popupaoc-overlay-bgcolor"><?php _e('Popup Overlay Color', 'popup-anything-on-click'); ?>:</label>
			</th>
			<td>				
				<input type="text" value="<?php echo $popup_ovelay_color; ?>" id="popupaoc-overlay-bgcolor" name="<?php echo $prefix;?>popup_ovelay_color" class="popupaoc-color-box" /><br/>						
				<span class="description"><?php _e('Select Popup overlay background color.', 'popup-anything-on-click'); ?></span>
			</td>
		</tr>
		<tr valign="top">
			<th scope="row">
				<label for="popup-ovelay-opacity"><?php _e('Popup Overlay Opacity', 'popup-anything-on-click'); ?></label>
			</th>
			<td class="row-meta">			
				<input type="number" id="popup-ovelay-opacity" name="<?php echo $prefix;?>popup_ovelay_opacity" value="<?php echo $popup_ovelay_opacity; ?>" min="0" max="1" step="0.1" class="regular-text" placeholder="<?php _e(' Range: 0 to 1', 'popup-anything-on-click'); ?>" /><br/>
				<span class="description"><?php _e('Set the overlay opacity level. Range: 0 to 1.', 'popup-anything-on-click'); ?></span>
			</td>			
		</tr>	

	</tbody>
</table><!-- end .popupaoc-post-sett-tbl -->
<?php
/**
 * Script Class
 * Handles the script and style functionality of plugin
 *
 * @package Popup anything on click
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Popupaocpro_Script {

	function __construct() {

		// Action to add script at front side
		add_action( 'wp_enqueue_scripts', array($this, 'popupaocpro_front_style') );

		// Action to add style in backend
		add_action( 'admin_enqueue_scripts', array($this, 'popupaocpro_admin_style') );
		
		// Action to add script at front side
		add_action( 'wp_enqueue_scripts', array($this, 'popupaocpro_plugin_script') );		
		
		// Action to add script in backend
		add_action( 'admin_enqueue_scripts', array($this, 'popupaocpro_admin_script') );		
		
	}
	
	/**
	 * Function to add style at front side
	 * 
	 * @package Popup anything on click
	 * @since 1.0.0
	 */
	function popupaocpro_front_style() {		

		// Registring and enqueing button with style pro css
		wp_register_style( 'popupaoc-public-style', POPUPAOCPRO_URL.'assets/css/popupaoc-public-style.css', array(), POPUPAOCPRO_VERSION );
		wp_enqueue_style( 'popupaoc-public-style' );

	}
	
	/**
	 * Function to add script at front side
	 * 
	 * @package Popup anything on click
	 * @since 1.0.0
	 */
	function popupaocpro_plugin_script() {			
		// Registring frontend js
		if( !wp_script_is( 'popupaoc-legacy-js', 'registered' ) ) {	
			wp_register_script( 'popupaoc-legacy-js', POPUPAOCPRO_URL.'assets/js/custombox.legacy.min.js', array('jquery'), POPUPAOCPRO_VERSION, true );
		}
		if( !wp_script_is( 'popupaoc-popup-js', 'registered' ) ) {		
			wp_register_script( 'popupaoc-popup-js', POPUPAOCPRO_URL.'assets/js/popupaoc-popup.min.js', array('jquery'), POPUPAOCPRO_VERSION, true );	
		}	
		
	}	

	/**
	 * Enqueue admin styles
	 * 
	 * @package Popup anything on click
	 * @since 1.0.0
	 */
	function popupaocpro_admin_style( $hook ) {

		global $typenow;

		// Taking pages array
		$pages_arr = array( POPUPAOCPRO_POST_TYPE );

		if( in_array($typenow, $pages_arr) ) {
			wp_register_style( 'popupaoc-admin-style', POPUPAOCPRO_URL.'assets/css/popupaoc-admin-style.css', array(), POPUPAOCPRO_VERSION );
			wp_enqueue_style( 'popupaoc-admin-style' );
			
		// Enqueu built in style for color picker
			if( wp_style_is( 'wp-color-picker', 'registered' ) ) { // Since WordPress 3.5
				wp_enqueue_style( 'wp-color-picker' );
			}	
		}		
		
	}

	/**
	 * Enqueue admin script
	 * 
	 * @package Popup anything on click
	 * @since 1.0.0
	 */
	function popupaocpro_admin_script( $hook ) {

		global $typenow, $wp_version;
		$new_ui = $wp_version >= '3.5' ? '1' : '0'; // Check wordpress version for older scripts
		// Taking pages array
		$pages_arr = array( POPUPAOCPRO_POST_TYPE );

		if( in_array($typenow, $pages_arr) ) {
			
			// Enqueu built-in script for color picker
			if( wp_script_is( 'wp-color-picker', 'registered' ) ) { // Since WordPress 3.5
				wp_enqueue_script( 'wp-color-picker' );
			}
			
			// Registring admin script
			wp_register_script( 'popupaoc-admin-script', POPUPAOCPRO_URL.'assets/js/popupaoc-admin-script.js', array('jquery'), POPUPAOCPRO_VERSION, true );
			wp_enqueue_script( 'popupaoc-admin-script' );
			wp_localize_script( 'popupaoc-admin-script', 'PopupaocAdmin', array(
																		'new_ui' 	=>	$new_ui,
																		'sry_msg' => __('Sorry, One entry should be there.', 'buttons-with-style'),			
			
			));			
		}
		
	}

}

$popupaocpro_script = new Popupaocpro_Script();
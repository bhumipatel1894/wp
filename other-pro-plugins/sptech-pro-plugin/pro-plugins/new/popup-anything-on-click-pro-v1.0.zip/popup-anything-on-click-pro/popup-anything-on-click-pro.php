<?php
/*
 * Plugin Name: Popup anything on click Pro
 * Plugin URI: https://www.wponlinesupport.com/plugins
 * Text Domain: popup-anything-on-click
 * Description: Display a modal popup by clicking on a link, image or button 
 * Domain Path: /languages/
 * Version: 1.0
 * Author: WP Online Support
 * Author URI: https://www.wponlinesupport.com
 * Contributors: WP Online Support
*/

if( !defined( 'POPUPAOCPRO_VERSION' ) ) {
	define( 'POPUPAOCPRO_VERSION', '1.0' ); // Version of plugin
}
if( !defined( 'POPUPAOCPRO_DIR' ) ) {
    define( 'POPUPAOCPRO_DIR', dirname( __FILE__ ) ); // Plugin dir
}
if( !defined( 'POPUPAOCPRO_URL' ) ) {
    define( 'POPUPAOCPRO_URL', plugin_dir_url( __FILE__ )); // Plugin url
}
if( !defined( 'POPUPAOCPRO_PLUGIN_BASENAME' ) ) {
	define( 'POPUPAOCPRO_PLUGIN_BASENAME', plugin_basename( __FILE__ ) ); // plugin base name
}
if(!defined( 'POPUPAOCPRO_POST_TYPE' ) ) {
	define('POPUPAOCPRO_POST_TYPE', 'aoc_popup'); // Plugin post type
}
if(!defined( 'POPUPAOCPRO_META_PREFIX' ) ) {
	define('POPUPAOCPRO_META_PREFIX','_aoc_'); // Plugin metabox prefix
}

/**
 * Activation Hook
 * 
 * Register plugin activation hook.
 * 
 * @package Popup anything on click Pro
 * @since 1.0.0
 */
register_activation_hook( __FILE__, 'popupaoc_install' );

/**
 * Deactivation Hook
 * 
 * Register plugin deactivation hook.
 * 
 * @package Popup anything on click Pro
 * @since 1.0.0
 */
register_deactivation_hook( __FILE__, 'popupaoc_uninstall');

/**
 * Plugin Activation Function
 * Does the initial setup, sets the default values for the plugin options
 * 
 * @package Popup anything on click Pro
 * @since 1.0.0
 */
function popupaoc_install() {
        
    // Update plugin version to option
    update_option( 'popupaoc_plugin_version', '1.0' );
    
    if( is_plugin_active('popup-anything-on-click/popup-anything-on-click.php') ){
        add_action('update_option_active_plugins', 'popupaoc_deactivate_free_version');
    }
}

/**
 * Plugin Functinality (On Deactivation)
 * 
 * Delete  plugin options.
 * 
 * @package Popup anything on click Pro
 * @since 1.0.0
 */
function popupaoc_uninstall() {

}

/**
 * Deactivate free plugin
 * 
 * @package Popup anything on click Pro
 * @since 1.0.0
 */
function popupaoc_deactivate_free_version() {
    deactivate_plugins('popup-anything-on-click/popup-anything-on-click.php', true);
}

/**
 * Function to display admin notice of activated plugin.
 * 
 * @package Popup anything on click Pro
 * @since 1.0.0
 */
function popupaoc_pro_admin_notice() {

    $dir = ABSPATH . 'wp-content/plugins/popup-anything-on-click/popup-anything-on-click.php';

    // If PRO plugin is active and free plugin exist
    if( is_plugin_active( 'popup-anything-on-click-pro/popup-anything-on-click-pro.php' ) && file_exists($dir) ) {

        global $pagenow;

        if( $pagenow == 'plugins.php' ) {

            if ( current_user_can( 'install_plugins' ) ) {
                echo '<div id="message" class="updated notice is-dismissible"><p><strong>Thank you for activating Popup anything on click Pro</strong>.<br /> It looks like you had FREE version <strong>(<em>Popup anything on click</em>)</strong> of this plugin activated. To avoid conflicts the extra version has been deactivated and we recommend you delete it. </p></div>';
            }
        }
    }
}

// Action to display notice
add_action( 'admin_notices', 'popupaoc_pro_admin_notice');

/**
 * Load Text Domain
 * This gets the plugin ready for translation
 * 
 * @package Popup anything on click Pro
 * @since 1.0.0
 */
function popupaoc_pro_load_textdomain() {

    global $wp_version;

    // Set filter for plugin's languages directory
    $popupaoc_lang_dir = dirname( plugin_basename( __FILE__ ) ) . '/languages/';
    $popupaoc_lang_dir = apply_filters( 'popupaoc_languages_directory', $popupaoc_lang_dir );

    // Traditional WordPress plugin locale filter.
    $get_locale = get_locale();

    if ( $wp_version >= 4.7 ) {
        $get_locale = get_user_locale();
    }

    // Traditional WordPress plugin locale filter
    $locale = apply_filters( 'plugin_locale',  $get_locale, 'popup-anything-on-click' );
    $mofile = sprintf( '%1$s-%2$s.mo', 'popup-anything-on-click', $locale );

    // Setup paths to current locale file
    $mofile_global  = WP_LANG_DIR . '/plugins/' . basename( POPUPAOCPRO_DIR ) . '/' . $mofile;

    if ( file_exists( $mofile_global ) ) { // Look in global /wp-content/languages/plugin-name folder
        load_textdomain( 'popup-anything-on-click', $mofile_global );
    } else { // Load the default language files
        load_plugin_textdomain( 'popup-anything-on-click', false, $popupaoc_lang_dir );
    }
}
add_action('plugins_loaded', 'popupaoc_pro_load_textdomain');


/***** Updater Code Starts *****/
define( 'EDD_POPUPAOC_STORE_URL', 'https://www.wponlinesupport.com' );
define( 'EDD_POPUPAOC_ITEM_NAME', 'Popup anything on click Pro' );

// Plugin Updator Class
if( !class_exists( 'EDD_SL_Plugin_Updater' ) ) {	
	include( dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php' );
}

/**
 * Updater Function
 * 
 * @package Popup anything on click Pro
 * @since 1.0.0
 */
function edd_sl_popupaoc_plugin_updater() {
	
	$license_key = trim( get_option( 'edd_popupaoc_license_key' ) );

	$edd_updater = new EDD_SL_Plugin_Updater( EDD_POPUPAOC_STORE_URL, __FILE__, array(
            'version' 	=> POPUPAOCPRO_VERSION,      // current version number
            'license' 	=> $license_key,          // license key (used get_option above to retrieve from DB)
            'item_name' => EDD_POPUPAOC_ITEM_NAME,    // name of this plugin
            'author' 	=> 'WP Online Support'    // author of this plugin
		)
	);

}
add_action( 'admin_init', 'edd_sl_popupaoc_plugin_updater', 0 );
include( dirname( __FILE__ ) . '/edd-popupaoc-plugin.php' );
/***** Updater Code Ends *****/

// Funcions File
require_once( POPUPAOCPRO_DIR .'/includes/popupaoc-functions.php' );

// Post Type File
require_once( POPUPAOCPRO_DIR . '/includes/popupaoc-post-types.php' );

// Script Class File
require_once( POPUPAOCPRO_DIR . '/includes/class-popupaoc-script.php' );

// Admin Class File
require_once( POPUPAOCPRO_DIR . '/includes/admin/class-popupaoc-admin.php' );

// Shortcode file
require_once( POPUPAOCPRO_DIR . '/includes/shortcode/popupaoc-popup-shortcode.php' );

// How it work file, Load admin files
if ( is_admin() || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
    require_once( POPUPAOCPRO_DIR . '/includes/admin/popupaoc-how-it-work.php' );
}
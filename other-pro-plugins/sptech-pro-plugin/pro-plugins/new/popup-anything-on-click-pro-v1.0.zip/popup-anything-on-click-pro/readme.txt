=== Popup anything on click Pro ===
Tags: modal popup, popup, modal, full screen popup, html popup, popup on click, modal popup on click, full screen popup on click
Contributors: wponlinesupport, anoopranawat 
Requires at least: 3.1
Tested up to: 4.8
Stable tag: trunk
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Display a modal popup by clicking on a link, image or button

== Description ==
Popup anything by clicking on a link, image or button and manage powerful modal popups for your WordPress blog or website. You can add unlimited popups with your own configurations.

Popup Builder is a modal popup plugin for WordPress website that allows you to add highly customizable popup windows.

This plugin enable awesome popup in your WordPress website using short codes. With popup builder plugin you can insert any type of content into your Popup (HTML, Image, Shortcodes etc). Insert your popup shortcode into any page or a post, easily and fast.

= Features =
* Create and manage as many popups as you want
* Customize the look and feel of the popup
* Set custom animation effects (Fadein, Slide, Fall, Flip, Blur, Rotate etc)
* Customize popup animation effect
* Set popup location on the screen
* Full screen popup
* Responsive popup
* On click popup
* Html popup
* Image popup

== Installation ==

1. Upload the 'popup-anything-on-click-pro' folder to the '/wp-content/plugins/' directory.
2. Activate the "popup-anything-on-click-pro" list plugin through the 'Plugins' menu in WordPress.

== Changelog ==

= 1.0 =
* Initial release.

== Upgrade Notice ==

= 1.0 =
* Initial release.
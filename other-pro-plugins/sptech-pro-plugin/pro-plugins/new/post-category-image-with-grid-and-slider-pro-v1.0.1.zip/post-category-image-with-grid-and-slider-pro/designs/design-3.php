<div class="<?php echo $wrapper_cls; ?>">
	<div class="pciwgas-post-cat-inner pciwgas-clearfix">
		<div class="pciwgas-img-wrapper" <?php echo $height_css; ?>>
			<a class="pciwgas-hover" href="<?php echo $term_link; ?>" target="<?php echo $link_target; ?>">
				<?php if(!empty($category_image)) {  ?>							
								<img src="<?php echo $category_image; ?>"  class="pciwgas-cat-img" alt="" />
							<?php }  ?>
			</a>
			<?php if( $show_count ) { ?>
				<span class="pciwgas-cat-count"><?php echo $category->count; ?></span>
			<?php } ?>
		</div>
		<div class="pciwgas-bottom-wrapper">
			<?php if( $show_title ) { ?>
				<div class="pciwgas-title">
					<a href="<?php echo $term_link; ?>" target="<?php echo $link_target; ?>"><?php echo $category->name; ?></a>
				</div>
			<?php } ?>
			<span class="pciwgas-line"></span>
			<?php if( $show_desc && $category->description ) { ?>
			<div class="pciwgas-description"><?php echo $category->description; ?></div>
			<?php } ?>
		</div>
	</div>
</div>


<div class="<?php echo $wrapper_cls; ?>">
		<div class="pciwgas-post-cat-inner pciwgas-clearfix">
		<div class="pciwgas-img-wrapper" <?php echo $height_css; ?>>
			<?php if(!empty($category_image)) {  ?>							
								<img src="<?php echo $category_image; ?>"  class="pciwgas-cat-img" alt="" />
			<?php }  ?>
		</div>
		<div class="pciwgas-bottom-content">
			<?php if( $show_count ) { ?>
				<span class="pciwgas-cat-count"><?php echo $category->count; ?></span>
			<?php } 
				if( $show_title ) { ?>
			<div class="pciwgas-title"><?php echo $category->name; ?></div>
			<?php } 
			if( $show_desc && $category->description ) { ?>
				<div class="pciwgas-bottom-wrapper">
					<div class="pciwgas-description"><?php echo $category->description; ?></div>
				</div>
			<?php } ?>
		</div>
		<a class="pciwgas-hover" href="<?php echo $term_link; ?>" target="<?php echo $link_target; ?>"></a>
	</div>
</div>


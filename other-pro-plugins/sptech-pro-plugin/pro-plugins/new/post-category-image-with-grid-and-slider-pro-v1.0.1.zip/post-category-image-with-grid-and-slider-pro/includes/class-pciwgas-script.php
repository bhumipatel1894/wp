<?php
/**
 * Script Class
 *
 * Handles the script and style functionality of plugin
 *
 * @package Post Category Image With Grid and Slider
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Pciwgaspro_Script {
	
	function __construct() {
		
		// Action to add style at front side
		add_action( 'wp_enqueue_scripts', array($this, 'pciwgaspro_front_style') );
		
		// Action to add script at front side
		add_action( 'wp_enqueue_scripts', array($this, 'pciwgaspro_front_script') );
		
		// Action to add style in backend
		add_action( 'admin_enqueue_scripts', array($this, 'pciwgaspro_admin_style') );
		
		// Action to add script at admin side
		add_action( 'admin_enqueue_scripts', array($this, 'pciwgaspro_admin_script') );
		
		
	}

	/**
	 * Function to add style at front side
	 * 
	 * @package Post Category Image With Grid and Slider
	 * @since 1.0.0
	 */
	function pciwgaspro_front_style() {		
		wp_register_style( 'pciwgas-publlic-style', PCIWGASPRO_URL.'assets/css/categoryimage-public.css', null, PCIWGASPRO_VERSION );
			wp_enqueue_style( 'pciwgas-publlic-style' );
		
	}
	
	/**
	 * Function to add script at front side
	 * 
	 * @package Post Category Image With Grid and Slider
	 * @since 1.0.0
	 */
	function pciwgaspro_front_script() {

		// Registring slick slider script
		if( !wp_script_is( 'wpos-slick-jquery', 'registered' ) ) {
			wp_register_script( 'wpos-slick-jquery', PCIWGASPRO_URL.'assets/js/slick.min.js', array('jquery'), PCIWGASPRO_VERSION, true );
		}
		
		// Registring and enqueing public script
		wp_register_script( 'pciwgas-public-script', PCIWGASPRO_URL.'assets/js/pciwgas-public.js', array('jquery'), PCIWGASPRO_VERSION, true );
		wp_localize_script( 'pciwgas-public-script', 'Pciwgas', array(
																	'is_mobile' => (wp_is_mobile()) ? 1 : 0,
																	'is_rtl' 	=> (is_rtl()) 		? 1 : 0
																	));
			
	}

	/**
	 * Enqueue admin styles
	 * 
	 * @package Post Category Image With Grid and Slider
	 * @since 1.0
	 */
	function pciwgaspro_admin_style( $hook ) {

		 $pages_array = array( 'toplevel_page_pciwgaspro-settings');		
		
		// If page is plugin setting page then enqueue script
		 if( in_array($hook, $pages_array) ) {
			
			// Registring admin script
			wp_register_style( 'pciwgas-admin-style', PCIWGASPRO_URL.'assets/css/categoryimage-admin.css', null, PCIWGASPRO_VERSION );
			wp_enqueue_style( 'pciwgas-admin-style' );
		}
	}

	/**
	 * Function to add script at admin side
	 * 
	 * @package Post Category Image With Grid and Slider
	 * @since 1.0
	 */
	function pciwgaspro_admin_script( $hook ) {
		
		 if ($hook != 'edit-tags.php' && $hook != 'term.php') {
            return;
        }

        wp_enqueue_media();       
		wp_enqueue_script( 'category-image-admin-js', PCIWGASPRO_URL.'assets/js/categoryimage.js', array('jquery'), PCIWGASPRO_VERSION, true );	
        wp_localize_script('category-image-admin-js', 'CategoryImage', array(
            'wp_version' => PCIWGASPRO_WP_VERSION,
                'label'      => array(
                    'title'  => __('Choose Category Image', 'post-category-image-with-grid-and-slider'),
                    'button' => __('Choose Image', 'post-category-image-with-grid-and-slider')
                )
            )
        );
	}	
}

$pciwgaspro_script = new Pciwgaspro_Script();
<?php
/**
 * Function 
 * Handles the script and style functionality of plugin
 * @package Post Category Image With Grid and Slider
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;
/**
 * Function to get featured content column
 * 
 * @package Post Category Image With Grid and Slider
 * @since 1.0.0
 */
function pciwgaspro_column( $row = '' ) {
	if($row == 2) {
		$per_row = 6;
	} else if($row == 3) {
		$per_row = 4;	
	} else if($row == 4) {
		$per_row = 3;
	} else if($row == 1) {
		$per_row = 12;
	} else{
        $per_row = 12;
    }

    return $per_row;
}
/**
 * Function to unique number value
 * 
 * @package Post Category Image With Grid and Slider
 * @since 1.0.0
 */
function pciwgaspro_get_unique() {
    static $unique = 0;
    $unique++;

    return $unique;
}

/**
 * Update default settings
 * 
 * @package Post Category Image With Grid and Slider
 * @since 1.0.0
 */
function pciwgaspro_default_settings(){
    
    global $pciwgaspro_options;
    
    $pciwgaspro_options = array(
                                'pciwgaspro_enable'                           => '1',
                               
                            );
    
    $default_options = apply_filters('pciwgaspro_options_default_values', $pciwgaspro_options );
    
    // Update default options
    update_option( 'pciwgaspro_options', $default_options );
    
    // Overwrite global variable when option is update
    $pciwgaspro_options = pciwgaspro_get_settings();
}

/**
 * Get Settings From Option Page
 * 
 * Handles to return all settings value
 * 
 * @package Post Category Image With Grid and Slider
 * @since 1.0.0
 */
function pciwgaspro_get_settings() {
    
    $options = get_option('pciwgaspro_options');

    $settings = is_array($options)  ? $options : array();
    
    return $settings;
}

/**
 * Get an option
 * Looks to see if the specified setting exists, returns default if not
 * 
 * @package Post Category Image With Grid and Slider
 * @since 1.0.0
*/
function pciwgaspro_get_option( $key = '', $default = false ) {
    global $pciwgaspro_options;
    
    $value = ! empty( $pciwgaspro_options[ $key ] ) ? $pciwgaspro_options[ $key ] : $default;
    $value = apply_filters( 'pciwgaspro_get_option', $value, $key, $default );
    return apply_filters( 'pciwgaspro_get_option_' . $key, $value, $key, $default );
}

/**
 * Escape Tags & Slashes
 *
 * Handles escapping the slashes and tags
 *
 * @package  Post Category Image With Grid and Slider
 * @since 1.0.0
 */
function pciwgaspro_escape_attr($data) {
    return esc_attr( stripslashes($data) );
}

/**
 * Strip Slashes From Array
 *
 * @package Post Category Image With Grid and Slider
 * @since 1.0.0
 */
function pciwgaspro_slashes_deep($data = array(), $flag = false) {
    
    if($flag != true) {
        $data = pciwgaspro_nohtml_kses($data);
    }
    $data = stripslashes_deep($data);
    return $data;
}

/**
 * Strip Html Tags 
 * 
 * It will sanitize text input (strip html tags, and escape characters)
 * 
 * @package Post Category Image With Grid and Slider
 * @since 1.0.0
 */
function pciwgaspro_nohtml_kses($data = array()) {
    
    if ( is_array($data) ) {
        
        $data = array_map('pciwgaspro_nohtml_kses', $data);
        
    } elseif ( is_string( $data ) ) {
        
        $data = wp_filter_nohtml_kses($data);
    }
    
    return $data;
}

/**
 * Function to get category shortcode designs
 * 
 * @package Post Category Image With Grid and Slider
 * @since 1.0
 */
function pciwgaspro_cat_designs() {
    $design_arr = array(               
                'design-1'  => __('Design 1', 'post-category-image-with-grid-and-slider'),
                'design-2'  => __('Design 2', 'post-category-image-with-grid-and-slider'),
                'design-3'  => __('Design 3', 'post-category-image-with-grid-and-slider'),
                'design-4'  => __('Design 4', 'post-category-image-with-grid-and-slider'),
                'design-5'  => __('Design 5', 'post-category-image-with-grid-and-slider'),
                'design-6'  => __('Design 6', 'post-category-image-with-grid-and-slider'),
                'design-7'  => __('Design 7', 'post-category-image-with-grid-and-slider'),
                'design-8'  => __('Design 8', 'post-category-image-with-grid-and-slider'),
                'design-9'  => __('Design 9', 'post-category-image-with-grid-and-slider'),
                'design-10' => __('Design 10', 'post-category-image-with-grid-and-slider'),
            );
    return apply_filters('pciwgaspro_cat_designs', $design_arr );
}
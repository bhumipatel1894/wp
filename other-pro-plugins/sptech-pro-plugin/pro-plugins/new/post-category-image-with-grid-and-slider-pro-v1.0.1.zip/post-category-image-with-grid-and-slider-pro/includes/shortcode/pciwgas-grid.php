<?php
/**
 * 'pci-cat-grid' Shortcode
 * 
 * @package Post Category Image With Grid and Slider
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

function pciwgaspro_grid_shortcode($atts, $content) { 
	// Shortcode Parameter
	$atts = extract(shortcode_atts(array(
				'limit'     		=> '',
                'size'    			=> 'full',
				'taxonomy'          => 'category',
                'term_id' 			=> null,               
				'design'     		=> 'design-1',
				'orderby'    		=> 'name',
				'order'      		=> 'ASC',				
				'columns'    		=> '3',
				'show_title' 		=> 'true',
				'show_count'		=> 'true',
				'show_desc'  		=> 'true',
				'hide_empty' 		=> 'true',
				'link_target'		=> 'self',
				'img_wrap_height'   => '',
				
        ), $atts,'pci-cat-grid'));
	
	$cat_designs = pciwgaspro_cat_designs();
	$limit				 = !empty($limit) 			    		? $limit 					: '';
	$size 			 	 = !empty($size) 						? $size 					: 'full';
	$taxonomy 	 		 = !empty($taxonomy) 			        ? $taxonomy 			    : 'category';
	$term_id 	 		 = (!empty($term_id)) 					? explode(',', $term_id) 	: '';	
	$design 	 		 = ($design && (array_key_exists(trim($design), $cat_designs))) ? trim($design) : 'design-1';
	$show_title	 		 = ($show_title == 'true') 				? true 						: false;
	$show_count	 		 = ($show_count == 'true') 				? true 						: false;
	$show_desc	 		 = ($show_desc == 'true') 				? true 						: false;
	$hide_empty  		 = ( $hide_empty == 'false') 			? false 					: true;
	$link_target 		 = ($link_target == 'blank') 			? '_blank' 					: '_self';
	$columns 	 		 = (!empty($columns) && $columns <= 4)  ? $columns 			: 3;
	$height 	 		 = (!empty($height)) 					? $height 					: '';
	$height_css  		 = (!empty($height))					? "style='height:{$height}px;'" : '';
	$column_grid 		 = pciwgaspro_column($columns);	
	$count 				 = 0;	
	
	// Shortcode file
	$cat_design_file_path 	= PCIWGASPRO_DIR . '/designs/' . $design . '.php';
	$design_file 			= (file_exists($cat_design_file_path)) ? $cat_design_file_path : '';
	
	// get terms and workaround WP bug with parents/pad counts
	$args = array(
			'number'	 => $limit,	
			'orderby'    => $orderby,
			'order'      => $order,
			'include'    => $term_id,
			'hide_empty' => $hide_empty,	
			
		);

	$post_categories = get_terms( $taxonomy, $args );
	
	ob_start();
	
	if ( $post_categories ) { ?>
		<div class="pciwgas-cat-wrap pciwgas-clearfix pciwgas-<?php echo $design; ?>">			
				<?php foreach ( $post_categories as $category ) {					
					$img_arra = array('size'=>$size,'term_id'=>$category->term_id);					
					$category_image = CategoryimageLoadFunction::pciwgaspro_get_category_image($img_arra);										
					$term_link = get_term_link( $category, $taxonomy );	

					$wrapper_cls = "pciwgas-post-cat-grid pciwgas-medium-{$column_grid} pciwgas-columns";
					$wrapper_cls .= ($count%$columns == 0) ? ' pciwgas-first' : '';	
					
					if( $design_file ) {
						include( $cat_design_file_path );
					}
					
					$count++; } ?>		
		</div>	
		<?php	
	}
	$content .= ob_get_clean();
	return $content;
}

add_shortcode('pci-cat-grid', 'pciwgaspro_grid_shortcode');
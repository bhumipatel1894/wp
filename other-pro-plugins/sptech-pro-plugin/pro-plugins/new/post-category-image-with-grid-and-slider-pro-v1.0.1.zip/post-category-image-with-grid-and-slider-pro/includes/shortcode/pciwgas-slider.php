<?php
/**
 * 'pci-cat-slider' Shortcode
 * 
 * @package Post Category Image With Grid and Slider
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

function pciwgaspro_slider_shortcode($atts, $content) { 
	// Shortcode Parameter
	$atts = extract(shortcode_atts(array(
				'limit'     		=> '',
				'taxonomy'          => 'category',
                'size'    			=> 'full',
                'term_id' 			=> null,               
				'design'     		=> 'design-1',
				'orderby'    		=> 'name',
				'order'      		=> 'ASC',				
				'show_title' 		=> 'true',
				'show_count'		=> 'true',
				'show_desc'  		=> 'true',
				'hide_empty' 		=> 'true',
				'slidestoshow' 		=> '3',
				'slidestoscroll' 	=> '1',
				'loop' 				=> 'true',
				'dots'     			=> 'true',
				'arrows'     		=> 'true',
				'autoplay'     		=> 'false',
				'autoplay_interval' => '3000',
				'speed'             => '300',
				'rtl'				=> '',
				'link_target'		=> 'self',
				'img_wrap_height'   => '',
				
        ), $atts,'pci-cat-slider'));
		
	$unique				 = pciwgaspro_get_unique();
	$cat_designs 		 = pciwgaspro_cat_designs();
	$limit		 		 = !empty($limit) 			    ? $limit 					: '';
	$taxonomy 	 		 = !empty($taxonomy) 			        ? $taxonomy 			    : 'category';
	$size 				 = !empty($size) 				? $size 					: 'full';
	$term_id 	 		 = (!empty($term_id)) 			? explode(',', $term_id) 	: '';	
	$design 	 		 = ($design && (array_key_exists(trim($design), $cat_designs))) ? trim($design) : 'design-1';
	$show_title	 		 = ($show_title == 'true') 		? true 						: false;
	$show_count	 		 = ($show_count == 'true') 		? true 						: false;
	$show_desc			 = ($show_desc == 'true') 		? true 						: false;
	$hide_empty  		 = ( $hide_empty == 'false') 	? false 					: true;
	$slidestoshow 		 = !empty($slidestoshow) 			? $slidestoshow 						: 3;
	$slidestoscroll 	 = !empty($slidestoscroll) 			? $slidestoscroll 						: 1;
	$loop 				 = ( $loop == 'false' ) 				? 'false' 								: 'true';
	$dots 				 = ( $dots == 'false' ) 				? 'false' 								: 'true';
	$arrows 			 = ( $arrows == 'false' ) 			? 'false' 								: 'true';
	$autoplay 			 = ( $autoplay == 'false' ) 			? 'false' 								: 'true';
	$autoplay_interval   = (!empty($autoplay_interval)) 		? $autoplay_interval 					: 3000;
	$speed 				 = (!empty($speed)) 					? $speed 								: 300;	
	$link_target = ($link_target == 'blank') 	? '_blank' 					: '_self';
	$height 	 = (!empty($height)) 			? $height 					: '';
	$height_css  = (!empty($height))			? "style='height:{$height}px;'" : '';
	
	// For RTL
	if( empty($rtl) && is_rtl() ) {
		$rtl = 'true';
	} elseif ( $rtl == 'true' ) {
		$rtl = 'true';
	} else {
		$rtl = 'false';
	}
	
	// Shortcode file
	$cat_design_file_path 	= PCIWGASPRO_DIR . '/designs/' . $design . '.php';
	$design_file 			= (file_exists($cat_design_file_path)) ? $cat_design_file_path : '';
	
	// Enqueue required script
	wp_enqueue_script( 'wpos-slick-jquery' );
	wp_enqueue_script( 'pciwgas-public-script' );
	
	// get terms and workaround WP bug with parents/pad counts
	$args = array(
			'number'	 => $limit,
			'orderby'    => $orderby,
			'order'      => $order,
			'include'    => $term_id,
			'hide_empty' => $hide_empty,	
			
		);

	$post_categories = get_terms( $taxonomy, $args );
	// Slider configuration
	$slider_conf = compact('slidestoshow', 'slidestoscroll', 'loop', 'dots', 'arrows', 'autoplay', 'autoplay_interval', 'speed', 'rtl');
	
	ob_start();
	
	if ( $post_categories ) { ?>
		<div class="pciwgas-cat-wrap pciwgas-cat-wrap-slider pciwgas-clearfix pciwgas-<?php echo $design; ?>">
			<div id="pciwgas-<?php echo $unique; ?>" class="pciwgas-cat-slider-main" >
				<?php foreach ( $post_categories as $category ) {					
					$img_arra = array('size'=>$size,'term_id'=>$category->term_id);					
					$category_image = CategoryimageLoadFunction::pciwgaspro_get_category_image($img_arra);										
					$term_link = get_term_link( $category, $taxonomy );				
					
					$wrapper_cls = "pciwgas-post-cat-grid";					
					
					if( $design_file ) {
						include( $cat_design_file_path );
					}	
					
					} ?>				
			</div>
			<div class="pciwgas-slider-conf" data-conf="<?php echo htmlspecialchars(json_encode($slider_conf)); ?>"></div>	
		</div>	
		<?php	
	}
	$content .= ob_get_clean();
	return $content;
}

add_shortcode('pci-cat-slider', 'pciwgaspro_slider_shortcode');
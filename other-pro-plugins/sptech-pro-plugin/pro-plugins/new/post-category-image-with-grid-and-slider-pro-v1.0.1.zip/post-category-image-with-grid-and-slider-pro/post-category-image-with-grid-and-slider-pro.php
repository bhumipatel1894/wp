<?php
/**
 * Plugin Name: Post Category Image With Grid and Slider Pro
 * Plugin URI: https://www.wponlinesupport.com/plugins
 * Description: Post Category Image With Grid and Slider plugin allow users to upload  category (taxonomy) image and display in grid and slider.
 * Author: WP Online Support
 * Author URI: https://www.wponlinesupport.com
 * Text Domain: post-category-image-with-grid-and-slider
 * Domain Path: languages
 * Version: 1.0.1
 * 
 * @package WordPress
 * @author WP Online Support
 */

 /**
 * Basic plugin definitions
 * 
 * @package Post Category Image With Grid and Slider
 * @since 1.0.0
 */
if( !defined( 'PCIWGASPRO_WP_VERSION' ) ) {
	define( 'PCIWGASPRO_WP_VERSION', get_bloginfo('version') ); 
} 
if( !defined( 'PCIWGASPRO_VERSION' ) ) {
	define( 'PCIWGASPRO_VERSION', '1.0.1' ); // Version of plugin
}
if( !defined( 'PCIWGASPRO_URL' ) ) {
    define( 'PCIWGASPRO_URL', plugin_dir_url( __FILE__ ) ); // Plugin url
}
if( !defined( 'PCIWGASPRO_DIR' ) ) {
    define( 'PCIWGASPRO_DIR', dirname( __FILE__ ) ); // Plugin dir
}
if( !defined( 'PCIWGASPRO_PLUGIN_BASE' ) ) {
	define( 'PCIWGASPRO_PLUGIN_BASE',  plugin_dir_path(__FILE__)); // plugin base
}
if( !defined( 'PCIWGASPRO_PATH_TEMPLATES' ) ) {
    define( 'PCIWGASPRO_PATH_TEMPLATES', PCIWGASPRO_PLUGIN_BASE . 'templates/');
}
if( !defined( 'PCIWGASPRO_PLUGIN_BASENAME' ) ) {
    define( 'PCIWGASPRO_PLUGIN_BASENAME', plugin_basename( __FILE__ ) ); // Plugin base name
}			


/**
 * Activation Hook
 * 
 * Register plugin activation hook.
 * 
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */

register_activation_hook( __FILE__, 'pciwgaspro_install' );

/**
 * Plugin Setup (On Activation)
 * 
 * Does the initial setup,
 * stest default values for the plugin options.
 * 
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */
function pciwgaspro_install(){

	// Get settings for the plugin
    $pciwgaspro_options = get_option( 'pciwgaspro_options' );
    
    if( empty( $pciwgaspro_options ) ) { // Check plugin version option
        
        // Set default settings
        pciwgaspro_default_settings();
        
        // Update plugin version to option
        update_option( 'pciwgaspro_plugin_version', '1.0' );
    }
}

/**
 * Deactivation Hook
 * 
 * Register plugin deactivation hook.
 * 
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */
register_deactivation_hook( __FILE__, 'pciwgaspro_uninstall');

/**
 * Plugin Setup (On Deactivation)
 * 
 * Delete  plugin options.
 * 
 * @package WP Responsive Recent Post Slider Pro
 * @since 1.0.0
 */
function pciwgaspro_uninstall() {
    // Uninstall functionality
}


/**
 * Load Text Domain
 * This gets the plugin ready for translation
 * 
 * @package Post Category Image With Grid and Slider
 * @since 1.0.0
 */
function pciwgaspro_load_textdomain() {

    global $wp_version;

    // Set filter for plugin's languages directory
    $pciwgaspro_lang_dir = dirname( plugin_basename( __FILE__ ) ) . '/languages/';
    $pciwgaspro_lang_dir = apply_filters( 'pciwgaspro_languages_directory', $pciwgaspro_lang_dir );
    
    // Traditional WordPress plugin locale filter.
    $get_locale = get_locale();

    if ( $wp_version >= 4.7 ) {
        $get_locale = get_user_locale();
    }

    // Traditional WordPress plugin locale filter
    $locale = apply_filters( 'plugin_locale',  $get_locale, 'post-category-image-with-grid-and-slider' );
    $mofile = sprintf( '%1$s-%2$s.mo', 'post-category-image-with-grid-and-slider', $locale );

    // Setup paths to current locale file
    $mofile_global  = WP_LANG_DIR . '/plugins/' . basename( PCIWGASPRO_DIR ) . '/' . $mofile;

    if ( file_exists( $mofile_global ) ) { // Look in global /wp-content/languages/plugin-name folder
        load_textdomain( 'post-category-image-with-grid-and-slider', $mofile_global );
    } else { // Load the default language files
        load_plugin_textdomain( 'post-category-image-with-grid-and-slider', false, $pciwgaspro_lang_dir );
    }
}
add_action('plugins_loaded', 'pciwgaspro_load_textdomain');


/***** Updater Code Starts *****/
define( 'EDD_PCIWGASPRO_STORE_URL', 'https://www.wponlinesupport.com' );
define( 'EDD_PCIWGASPRO_ITEM_NAME', 'Post Category Image With Grid and Slider Pro' );

// Plugin Updator Class 
if( !class_exists( 'EDD_SL_Plugin_Updater' ) ) {    
    include( dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php' );
}

/**
 * Updater Function
 * 
 * @package Author Box Ultimate by WPOS
 * @since 1.0.0
 */
function pciwgaspro_plugin_updater() {
    
    $license_key = trim( get_option( 'edd_pciwgaspro_license_key' ) );

    $edd_updater = new EDD_SL_Plugin_Updater( EDD_PCIWGASPRO_STORE_URL, __FILE__, array(
                'version'   => PCIWGASPRO_VERSION,          // current version number
                'license'   => $license_key,            // license key (used get_option above to retrieve from DB)
                'item_name' => EDD_PCIWGASPRO_ITEM_NAME,     // name of this plugin
                'author'    => 'WP Online Support'      // author of this plugin
            )
    );
}
add_action( 'admin_init', 'pciwgaspro_plugin_updater', 0 );
include( dirname( __FILE__ ) . '/pciwgas-plugin-updater.php' );
/***** Updater Code Ends *****/



/** Admin files */
require_once( PCIWGASPRO_DIR . '/includes/admin/pciwgas-admin-function.php' );
require_once( PCIWGASPRO_DIR . '/includes/admin/CategoryimageLoadFunction.php' );
add_action('init', array('CategoryimageLoadFunction', 'pciwgaspro_initialize'));

require_once( PCIWGASPRO_DIR . '/includes/admin/class-pciwgas-admin.php' );

global $pciwgaspro_options;
/** function file */
require_once( PCIWGASPRO_DIR . '/includes/pciwgas-function.php' );
$pciwgaspro_options = pciwgaspro_get_settings();
/** Load js and css files */
require_once( PCIWGASPRO_DIR . '/includes/class-pciwgas-script.php' );

/** Shortcode files */
require_once( PCIWGASPRO_DIR . '/includes/shortcode/pciwgas-grid.php' );
require_once( PCIWGASPRO_DIR . '/includes/shortcode/pciwgas-slider.php' );

// Load how it work files
	if ( is_admin() || ( defined( 'WP_CLI' ) && WP_CLI ) ) {	
		    include_once( PCIWGASPRO_DIR . '/includes/admin/pciwgas-how-it-work.php' );
		}

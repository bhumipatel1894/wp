<?php _e('Sorry, WPCustom Category Image works only under Wordpress 3.5 or higher', 'post-category-image-with-grid-and-slider'); ?>
    <br>
    <?php echo __('And... PHP ', 'post-category-image-with-grid-and-slider') . $min_php_version; ?>

<?php
/**
 * Visual Composer Class
 *
 * Handles the visual composer shortcode functionality of plugin
 *
 * @package Post grid and filter with popup Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Pgafupro_Vc {
	
	function __construct() {
		
		// Action to add 'pgaf_post_grid' shortcode in vc
		add_action( 'vc_before_init', array($this, 'pgafupro_pro_integrate_grid_vc') );

		// Action to add 'pgaf_post_filter' shortcode in vc
		add_action( 'vc_before_init', array($this, 'pgafupro_pro_integrate_post_filter_vc') );	
	}

	/**
	 * Function to add 'pgaf_post_grid' shortcode in vc
	 * 
	 * @package Post grid and filter with popup Pro
	 * @since 1.0.0
	 */
	function pgafupro_pro_integrate_grid_vc() {
		vc_map( 
			array(
				'name' 			=> __( 'WPOS - Post Grid', 'post-grid-and-filter-ultimate' ),
				'base' 			=> 'pgaf_post_grid',
				'icon' 			=> 'icon-wpb-wp',
				'class' 		=> '',
				'category' 		=> __( 'Content', 'post-grid-and-filter-ultimate'),
				'description' 	=> __( 'Display post grid.', 'post-grid-and-filter-ultimate' ),
				'params' 		=> array(
					// General settings
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Design', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'design',
						'value' 		=> array(
							__( 'Grid Design 1', 'post-grid-and-filter-ultimate' ) 	=> 'design-1',
							__( 'Grid Design 2', 'post-grid-and-filter-ultimate' ) 	=> 'design-2',
							__( 'Grid Design 3', 'post-grid-and-filter-ultimate' ) 	=> 'design-3',
							__( 'Grid Design 4', 'post-grid-and-filter-ultimate' ) 	=> 'design-4',
							__( 'Grid Design 5', 'post-grid-and-filter-ultimate' ) 	=> 'design-5',
							__( 'Grid Design 6', 'post-grid-and-filter-ultimate' ) 	=> 'design-6',
							__( 'Grid Design 7', 'post-grid-and-filter-ultimate' ) 	=> 'design-7',
							__( 'Grid Design 8', 'post-grid-and-filter-ultimate' ) 	=> 'design-8',
							__( 'Grid Design 9', 'post-grid-and-filter-ultimate' ) 	=> 'design-9',
							__( 'Grid Design 10', 'post-grid-and-filter-ultimate' ) => 'design-10',
							
							),
						'description' 	=> __( 'Choose grid design.', 'post-grid-and-filter-ultimate' ),
						'admin_label' 	=> true,
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Total Items Limit', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'limit',
						'value' 		=> 20,
						'description' 	=> __( 'Enter number to be displayed. Enter -1 to display all.', 'post-grid-and-filter-ultimate' ),
						'group' 		=> __( 'Data Settings', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Grid', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'grid',
						'value' 		=> 3,
						'description' 	=> __( 'Enter number to be displayed post per row.', 'post-grid-and-filter-ultimate' ),
						'group' 		=> __( 'Data Settings', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Post Order By', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'orderby',
						'value' 		=> array(
											__( 'Post Date', 'post-grid-and-filter-ultimate' ) 			=> 'date',
											__( 'Post ID', 'post-grid-and-filter-ultimate' ) 				=> 'ID',
											__( 'Post Author', 'post-grid-and-filter-ultimate' ) 			=> 'author',
											__( 'Post Title', 'post-grid-and-filter-ultimate' ) 			=> 'title',
											__( 'Post Modified Date', 'post-grid-and-filter-ultimate' ) 	=> 'modified',
											__( 'Random', 'post-grid-and-filter-ultimate' ) 				=> 'rand',
											__( 'Menu Order', 'post-grid-and-filter-ultimate' ) 			=> 'menu_order',
											),
						'description' 	=> __( 'Select order type.', 'post-grid-and-filter-ultimate' ),
						'group' 		=> __( 'Data Settings', 'post-grid-and-filter-ultimate' )
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Order', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'order',
						'value' 		=> array(
												__( 'Descending', 'post-grid-and-filter-ultimate' ) 	=> 'desc',
												__( 'Ascending', 'post-grid-and-filter-ultimate' ) 	=> 'asc',
											),
						'description' 	=> __( 'Post Order.', 'post-grid-and-filter-ultimate' ),
						'group' 		=> __( 'Data Settings', 'post-grid-and-filter-ultimate' )
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Category', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'cat_id',
						'value' 		=> '',
						'description' 	=> __( 'Enter category id to display Posts categories wise comma separated.', 'post-grid-and-filter-ultimate' ),
						'group' 		=> __( 'Data Settings', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type'			=> 'dropdown',
						'class'			=> '',
						'heading'		=> __( 'Disply Child Category','post-grid-and-filter-ultimate'),
						'param_name'	=> 'include_cat_child',
						'value'			=> array(
							__('True', 'post-grid-and-filter-ultimate')		=> 'true',
							__('False', 'post-grid-and-filter-ultimate')	=> 'false',
							),
						'description'	=> __( 'Display Child Category.','post-grid-and-filter-ultimate'),
						'group'		=> __( 'Data Settings','post-grid-and-filter-ultimate'),

						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Show Category Name', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'show_category_name',
						'value' 		=> array(
							__( 'True', 'post-grid-and-filter-ultimate' ) 		=> 'true',
							__( 'False', 'post-grid-and-filter-ultimate' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Category Name.', 'post-grid-and-filter-ultimate' ),
						'group' 		=> __( 'Data Settings', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Exclude Category', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'exclude_cat',
						'value' 		=> '',
						'description' 	=> __( 'Exclude post category. Works only if `Category` field is empty. you can exclude with comma separated.', 'post-grid-and-filter-ultimate' ),
						'group' 		=> __( 'Data Settings', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Display Specific Posts', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'posts',
						'value' 		=> '',
						'description' 	=> __( 'Enter post id which you only want to display with comma separated.', 'post-grid-and-filter-ultimate' ),
						'group' 		=> __( 'Data Settings', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Exclude Post', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'exclude_post',
						'value' 		=> '',
						'description' 	=> __( 'Enter post id which you do not want to display with comma separated.', 'post-grid-and-filter-ultimate' ),
						'group' 		=> __( 'Data Settings', 'post-grid-and-filter-ultimate' ),
						),	
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Author', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'show_author',
						'value' 		=> array(
							__( 'True', 'post-grid-and-filter-ultimate' ) 	=> 'true',
							__( 'False', 'post-grid-and-filter-ultimate' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Author.', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Date', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'show_date',
						'value' 		=> array(
							__( 'True', 'post-grid-and-filter-ultimate' ) 	=> 'true',
							__( 'False', 'post-grid-and-filter-ultimate' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Date.', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Comments', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'show_comments',
						'value' 		=> array(
							__( 'True', 'post-grid-and-filter-ultimate' ) 		=> 'true',
							__( 'False', 'post-grid-and-filter-ultimate' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Comments.', 'post-grid-and-filter-ultimate' ),
						),	

					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Content', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'show_content',
						'value' 		=> array(
							__( 'True', 'post-grid-and-filter-ultimate' ) 	=> 'true',
							__( 'False', 'post-grid-and-filter-ultimate' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Content.', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Content Word Limit', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'content_words_limit',
						'value' 		=> '20',
						'description' 	=> __( 'Enter Content Word Limit', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Read More', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'show_read_more',
						'value' 		=> array(
							__( 'True', 'post-grid-and-filter-ultimate' ) 		=> 'true',
							__( 'False', 'post-grid-and-filter-ultimate' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Read More.', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Pagination', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'pagination',
						'value' 		=> array(
							__( 'True', 'post-grid-and-filter-ultimate' ) 		=> 'true',
							__( 'False', 'post-grid-and-filter-ultimate' ) 	=> 'false',
							),
						'description' 	=> __( 'Pagination.', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Pagination Type', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'pagination_type',
						'value' 		=> array(
							__( 'Numeric', 'post-grid-and-filter-ultimate' ) 		=> 'numeric',
							__( 'Next-Prev', 'post-grid-and-filter-ultimate' ) 	=> 'prev-next',
							),
						'description' 	=> __( 'Pagination Type', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Image Size', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'media_size',
						'value' 		=> array(
							__( 'Large', 'post-grid-and-filter-ultimate' ) 		=> 'large',
							__( 'Full', 'post-grid-and-filter-ultimate' ) 		=> 'full',
							__( 'Medium', 'post-grid-and-filter-ultimate' ) 	=> 'medium',
							__( 'Thumbnail', 'post-grid-and-filter-ultimate' ) 	=> 'thumbnail',
							),
						'description' 	=> __( 'Set Image Size', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Image Fit', 'post-grid-and-filter-ultimate'),
						'param_name' 	=> 'image_fit',
						'value' 		=> array(
							__( 'True', 'post-grid-and-filter-ultimate' ) 	=> 'true',
							__( 'False', 'post-grid-and-filter-ultimate' ) 	=> 'false',
							),
						'description' 	=> __( 'Set Image Fit.', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Content Tail', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'content_tail',
						'value' 		=> '...',
						'description' 	=> __( 'Enter Content Tail to display', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Image Height', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'image_height',
						'value' 		=> '',
						'description' 	=> __( 'Enter Image Height', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Read More Text', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'read_more_text',
						'value' 		=> '',
						'description' 	=> __( 'Enter Read More Text', 'post-grid-and-filter-ultimate' ),
						),
					
					// Popup Settings
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Single Post Popup', 'post-grid-and-filter-ultimate'),
						'param_name' 	=> 'single_post_popup',
						'value' 		=> array(
							__( 'False', 'post-grid-and-filter-ultimate' ) 	=> 'false',
							__( 'True', 'post-grid-and-filter-ultimate' ) 	=> 'true',							
							),
						'description' 	=> __( 'Enable post detail view in a popup.', 'post-grid-and-filter-ultimate' ),
						),
					// Popup Settings
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Popup Effect', 'post-grid-and-filter-ultimate'),
						'param_name' 	=> 'popup_effect',
						'value' 		=> array(
							__( 'Fadein', 'post-grid-and-filter-ultimate' ) 		=> 'fadein',
							__( 'Slide', 'post-grid-and-filter-ultimate' ) 			=> 'slide',
							__( 'Fall', 'post-grid-and-filter-ultimate' ) 			=> 'fall',
							__( 'Flip', 'post-grid-and-filter-ultimate' ) 			=> 'flip',
							__( 'Blur', 'post-grid-and-filter-ultimate' ) 			=> 'blur',
							__( 'Rotate', 'post-grid-and-filter-ultimate' ) 		=> 'rotate',
							__( 'Sign', 'post-grid-and-filter-ultimate' ) 			=> 'sign',
							__( 'Super scaled', 'post-grid-and-filter-ultimate' ) 	=> 'superscaled',
							__( 'Slit', 'post-grid-and-filter-ultimate' ) 			=> 'slit',
							__( 'Corner', 'post-grid-and-filter-ultimate' ) 		=> 'corner',
							__( 'Makeway', 'post-grid-and-filter-ultimate' ) 		=> 'makeway',
							__( 'Door', 'post-grid-and-filter-ultimate' ) 			=> 'door',
							__( 'Push', 'post-grid-and-filter-ultimate' ) 			=> 'push',
							__( 'Scale', 'post-grid-and-filter-ultimate' ) 			=> 'scale',
							__( 'Slide Together', 'post-grid-and-filter-ultimate' ) => 'slidetogether',
							),
						'description' 	=> __( 'Select Popup Effect.', 'post-grid-and-filter-ultimate' ),
						),					
					
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Full Screen', 'post-grid-and-filter-ultimate'),
						'param_name' 	=> 'full_screen',
						'value' 		=> array(
							__( 'False', 'post-grid-and-filter-ultimate' ) 	=> 'false',
							__( 'True', 'post-grid-and-filter-ultimate' ) 	=> 'true',							
							),
						'description' 	=> __( 'Popup in Full screen.', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Popup Position X', 'post-grid-and-filter-ultimate'),
						'param_name' 	=> 'popup_positionx',
						'value' 		=> array(
							__( 'Center', 'post-grid-and-filter-ultimate' ) 	=> 'Center',
							__( 'Left', 'post-grid-and-filter-ultimate' ) 		=> 'Left',
							__( 'Right', 'post-grid-and-filter-ultimate' ) 		=> 'Right',
							),
						'description' 	=> __( 'Popup Position X.', 'post-grid-and-filter-ultimate' ),
						),	
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Popup Position Y', 'post-grid-and-filter-ultimate'),
						'param_name' 	=> 'popup_positiony',
						'value' 		=> array(
							__( 'Center', 'post-grid-and-filter-ultimate' ) 	=> 'Center',
							__( 'Top', 'post-grid-and-filter-ultimate' ) 		=> 'Top',
							__( 'Bottom', 'post-grid-and-filter-ultimate' ) 	=> 'Bottom',
							),
						'description' 	=> __( 'Popup Position Y.', 'post-grid-and-filter-ultimate' ),
						),			
						
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Speed In', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'speed_in',
						'value' 		=> '',
						'description' 	=> __( 'Enter Value ', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Speed Out', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'speed_out',
						'value' 		=> '',
						'description' 	=> __( 'Enter Value ', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Delay', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'delay',
						'value' 		=> '',
						'description' 	=> __( 'Enter Value ', 'post-grid-and-filter-ultimate' ),
						),	
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Enable loader', 'post-grid-and-filter-ultimate'),
						'param_name' 	=> 'enable_loader',
						'value' 		=> array(
							__( 'True', 'post-grid-and-filter-ultimate' ) 	=> 'true',
							__( 'False', 'post-grid-and-filter-ultimate' ) 	=> 'false',
							),
						'description' 	=> __( 'Enable Popup loader .', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Enable overlay', 'post-grid-and-filter-ultimate'),
						'param_name' 	=> 'enable_overlay',
						'value' 		=> array(
							__( 'True', 'post-grid-and-filter-ultimate' ) 	=> 'true',
							__( 'False', 'post-grid-and-filter-ultimate' ) 	=> 'false',
							),
						'description' 	=> __( 'Enable Popup overlay.', 'post-grid-and-filter-ultimate' ),
						),	
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Overlay color', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'overlay_color',
						'value' 		=> '',
						'description' 	=> __( 'Enter Color Value ie #000000 ', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Overlay opacity', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'overlay_opacity',
						'value' 		=> '',
						'description' 	=> __( 'Enter opacity value. Rage is 0 to 1 ', 'post-grid-and-filter-ultimate' ),
						),					
					
				),
			)
		);
	}

/******************************************************/
	/**
	 * Function to add 'pgaf_post_filter' shortcode in vc
	 * 
	 * @package Blog Designer - Post and Widget Pro
	 * @since 1.0.0
	 */
	function pgafupro_pro_integrate_post_filter_vc() {
		vc_map( 
			array(
				'name' 			=> __( 'WPOS - Post Grid Filter', 'post-grid-and-filter-ultimate' ),
				'base' 			=> 'pgaf_post_filter',
				'icon' 			=> 'icon-wpb-wp',
				'class' 		=> '',
				'category' 		=> __( 'Content', 'post-grid-and-filter-ultimate'),
				'description' 	=> __( 'Display recent post grid filter.', 'post-grid-and-filter-ultimate' ),
				'params' 		=> array(
					// General settings
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Design', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'design',
						'value' 		=> array(
							__( 'Filter Design 1', 'post-grid-and-filter-ultimate' ) 	=> 'design-1',
							__( 'Filter Design 2', 'post-grid-and-filter-ultimate' ) 	=> 'design-2',
							__( 'Filter Design 3', 'post-grid-and-filter-ultimate' ) 	=> 'design-3',
							__( 'Filter Design 4', 'post-grid-and-filter-ultimate' ) 	=> 'design-4',
							__( 'Filter Design 5', 'post-grid-and-filter-ultimate' ) 	=> 'design-5',
							__( 'Filter Design 6', 'post-grid-and-filter-ultimate' ) 	=> 'design-6',
							__( 'Filter Design 7', 'post-grid-and-filter-ultimate' ) 	=> 'design-7',
							__( 'Filter Design 8', 'post-grid-and-filter-ultimate' ) 	=> 'design-8',
							__( 'Filter Design 9', 'post-grid-and-filter-ultimate' ) 	=> 'design-9',
							__( 'Filter Design 10', 'post-grid-and-filter-ultimate' ) => 'design-10',
							
							),
						'description' 	=> __( 'Choose grid design.', 'post-grid-and-filter-ultimate' ),
						'admin_label' 	=> true,
						),
					
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Grid', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'grid',
						'value' 		=> 3,
						'description' 	=> __( 'Enter number to be displayed post per row.', 'post-grid-and-filter-ultimate' ),
						'group' 		=> __( 'Data Settings', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Post Order By', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'orderby',
						'value' 		=> array(
											__( 'Post Date', 'post-grid-and-filter-ultimate' ) 			=> 'date',
											__( 'Post ID', 'post-grid-and-filter-ultimate' ) 				=> 'ID',
											__( 'Post Author', 'post-grid-and-filter-ultimate' ) 			=> 'author',
											__( 'Post Title', 'post-grid-and-filter-ultimate' ) 			=> 'title',
											__( 'Post Modified Date', 'post-grid-and-filter-ultimate' ) 	=> 'modified',
											__( 'Random', 'post-grid-and-filter-ultimate' ) 				=> 'rand',
											__( 'Menu Order', 'post-grid-and-filter-ultimate' ) 			=> 'menu_order',
											),
						'description' 	=> __( 'Select order type.', 'post-grid-and-filter-ultimate' ),
						'group' 		=> __( 'Data Settings', 'post-grid-and-filter-ultimate' )
						),					
						
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Order', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'order',
						'value' 		=> array(
												__( 'Descending', 'post-grid-and-filter-ultimate' ) 	=> 'desc',
												__( 'Ascending', 'post-grid-and-filter-ultimate' ) 	=> 'asc',
											),
						'description' 	=> __( 'Post Order.', 'post-grid-and-filter-ultimate' ),
						'group' 		=> __( 'Data Settings', 'post-grid-and-filter-ultimate' )
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Category', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'cat_id',
						'value' 		=> '',
						'description' 	=> __( 'Enter category id to display Posts categories wise comma separated.', 'post-grid-and-filter-ultimate' ),
						'group' 		=> __( 'Data Settings', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type'			=> 'dropdown',
						'class'			=> '',
						'heading'		=> __( 'Disply Child Category','post-grid-and-filter-ultimate'),
						'param_name'	=> 'include_cat_child',
						'value'			=> array(
							__('True', 'post-grid-and-filter-ultimate')		=> 'true',
							__('False', 'post-grid-and-filter-ultimate')	=> 'false',
							),
						'description'	=> __( 'Display Child Category.','post-grid-and-filter-ultimate'),
						'group'		=> __( 'Data Settings','post-grid-and-filter-ultimate'),

						),
						
					//Filter category settings
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Total Category Limit', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'cat_limit',
						'value' 		=> 0,
						'description' 	=> __( 'Display total number of categories.', 'post-grid-and-filter-ultimate' ),
						'group' 		=> __( 'Data Settings', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Category Order', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'cat_order',
						'value' 		=> array(
												__( 'Descending', 'post-grid-and-filter-ultimate' ) 	=> 'desc',
												__( 'Ascending', 'post-grid-and-filter-ultimate' ) 	=> 'asc',
											),
						'description' 	=> __( 'Category Order.', 'post-grid-and-filter-ultimate' ),
						'group' 		=> __( 'Data Settings', 'post-grid-and-filter-ultimate' )
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Category Order By', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'cat_orderby',
						'value' 		=> array(
											__( 'Name', 'post-grid-and-filter-ultimate' ) 			=> 'name',
											__( 'Term ID', 'post-grid-and-filter-ultimate' ) 		=> 'term_id',
											__( 'Count', 'post-grid-and-filter-ultimate' ) 			=> 'count',											
											),
						'description' 	=> __( 'Select category order by.', 'post-grid-and-filter-ultimate' ),
						'group' 		=> __( 'Data Settings', 'post-grid-and-filter-ultimate' )
						),		
						
						
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Show Category Name', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'show_category_name',
						'value' 		=> array(
							__( 'True', 'post-grid-and-filter-ultimate' ) 		=> 'true',
							__( 'False', 'post-grid-and-filter-ultimate' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Category Name.', 'post-grid-and-filter-ultimate' ),
						'group' 		=> __( 'Data Settings', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Exclude Category', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'exclude_cat',
						'value' 		=> '',
						'description' 	=> __( 'Exclude post category. Works only if `Category` field is empty. you can exclude with comma separated.', 'post-grid-and-filter-ultimate' ),
						'group' 		=> __( 'Data Settings', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Display Specific Posts', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'posts',
						'value' 		=> '',
						'description' 	=> __( 'Enter post id which you only want to display with comma separated.', 'post-grid-and-filter-ultimate' ),
						'group' 		=> __( 'Data Settings', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Exclude Post', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'exclude_post',
						'value' 		=> '',
						'description' 	=> __( 'Enter post id which you do not want to display with comma separated.', 'post-grid-and-filter-ultimate' ),
						'group' 		=> __( 'Data Settings', 'post-grid-and-filter-ultimate' ),
						),	
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Author', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'show_author',
						'value' 		=> array(
							__( 'True', 'post-grid-and-filter-ultimate' ) 	=> 'true',
							__( 'False', 'post-grid-and-filter-ultimate' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Author.', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Date', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'show_date',
						'value' 		=> array(
							__( 'True', 'post-grid-and-filter-ultimate' ) 	=> 'true',
							__( 'False', 'post-grid-and-filter-ultimate' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Date.', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Comments', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'show_comments',
						'value' 		=> array(
							__( 'True', 'post-grid-and-filter-ultimate' ) 		=> 'true',
							__( 'False', 'post-grid-and-filter-ultimate' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Comments.', 'post-grid-and-filter-ultimate' ),
						),	

					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Content', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'show_content',
						'value' 		=> array(
							__( 'True', 'post-grid-and-filter-ultimate' ) 	=> 'true',
							__( 'False', 'post-grid-and-filter-ultimate' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Content.', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Content Word Limit', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'content_words_limit',
						'value' 		=> '20',
						'description' 	=> __( 'Enter Content Word Limit', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Read More', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'show_read_more',
						'value' 		=> array(
							__( 'True', 'post-grid-and-filter-ultimate' ) 		=> 'true',
							__( 'False', 'post-grid-and-filter-ultimate' ) 	=> 'false',
							),
						'description' 	=> __( 'Show Read More.', 'post-grid-and-filter-ultimate' ),
						),
					
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Image Size', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'media_size',
						'value' 		=> array(
							__( 'Large', 'post-grid-and-filter-ultimate' ) 		=> 'large',
							__( 'Full', 'post-grid-and-filter-ultimate' ) 		=> 'full',
							__( 'Medium', 'post-grid-and-filter-ultimate' ) 	=> 'medium',
							__( 'Thumbnail', 'post-grid-and-filter-ultimate' ) 	=> 'thumbnail',
							),
						'description' 	=> __( 'Set Image Size', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Image Fit', 'post-grid-and-filter-ultimate'),
						'param_name' 	=> 'image_fit',
						'value' 		=> array(
							__( 'True', 'post-grid-and-filter-ultimate' ) 	=> 'true',
							__( 'False', 'post-grid-and-filter-ultimate' ) 	=> 'false',
							),
						'description' 	=> __( 'Set Image Fit.', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Content Tail', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'content_tail',
						'value' 		=> '...',
						'description' 	=> __( 'Enter Content Tail to display', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Image Height', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'image_height',
						'value' 		=> '',
						'description' 	=> __( 'Enter Image Height', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Read More Text', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'read_more_text',
						'value' 		=> '',
						'description' 	=> __( 'Enter Read More Text', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'All filter text', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'all_filter_text',
						'value' 		=> '',
						'description' 	=> __( 'Change filter text (All)', 'post-grid-and-filter-ultimate' ),
						),	
					
					// Popup Settings
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Single Post Popup', 'post-grid-and-filter-ultimate'),
						'param_name' 	=> 'single_post_popup',
						'value' 		=> array(
							__( 'False', 'post-grid-and-filter-ultimate' ) 	=> 'false',
							__( 'True', 'post-grid-and-filter-ultimate' ) 	=> 'true',							
							),
						'description' 	=> __( 'Enable post detail view in a popup.', 'post-grid-and-filter-ultimate' ),
						),
					// Popup Settings
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Popup Effect', 'post-grid-and-filter-ultimate'),
						'param_name' 	=> 'popup_effect',
						'value' 		=> array(
							__( 'Fadein', 'post-grid-and-filter-ultimate' ) 		=> 'fadein',
							__( 'Slide', 'post-grid-and-filter-ultimate' ) 			=> 'slide',
							__( 'Fall', 'post-grid-and-filter-ultimate' ) 			=> 'fall',
							__( 'Flip', 'post-grid-and-filter-ultimate' ) 			=> 'flip',
							__( 'Blur', 'post-grid-and-filter-ultimate' ) 			=> 'blur',
							__( 'Rotate', 'post-grid-and-filter-ultimate' ) 		=> 'rotate',
							__( 'Sign', 'post-grid-and-filter-ultimate' ) 			=> 'sign',
							__( 'Super scaled', 'post-grid-and-filter-ultimate' ) 	=> 'superscaled',
							__( 'Slit', 'post-grid-and-filter-ultimate' ) 			=> 'slit',
							__( 'Corner', 'post-grid-and-filter-ultimate' ) 		=> 'corner',
							__( 'Makeway', 'post-grid-and-filter-ultimate' ) 		=> 'makeway',
							__( 'Door', 'post-grid-and-filter-ultimate' ) 			=> 'door',
							__( 'Push', 'post-grid-and-filter-ultimate' ) 			=> 'push',
							__( 'Scale', 'post-grid-and-filter-ultimate' ) 			=> 'scale',
							__( 'Slide Together', 'post-grid-and-filter-ultimate' ) => 'slidetogether',
							),
						'description' 	=> __( 'Select Popup Effect.', 'post-grid-and-filter-ultimate' ),
						),					
					
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Full Screen', 'post-grid-and-filter-ultimate'),
						'param_name' 	=> 'full_screen',
						'value' 		=> array(
							__( 'False', 'post-grid-and-filter-ultimate' ) 	=> 'false',
							__( 'True', 'post-grid-and-filter-ultimate' ) 	=> 'true',							
							),
						'description' 	=> __( 'Popup in Full screen.', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Popup Position X', 'post-grid-and-filter-ultimate'),
						'param_name' 	=> 'popup_positionx',
						'value' 		=> array(
							__( 'Center', 'post-grid-and-filter-ultimate' ) 	=> 'Center',
							__( 'Left', 'post-grid-and-filter-ultimate' ) 		=> 'Left',
							__( 'Right', 'post-grid-and-filter-ultimate' ) 		=> 'Right',
							),
						'description' 	=> __( 'Popup Position X.', 'post-grid-and-filter-ultimate' ),
						),	
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Popup Position Y', 'post-grid-and-filter-ultimate'),
						'param_name' 	=> 'popup_positiony',
						'value' 		=> array(
							__( 'Center', 'post-grid-and-filter-ultimate' ) 	=> 'Center',
							__( 'Top', 'post-grid-and-filter-ultimate' ) 		=> 'Top',
							__( 'Bottom', 'post-grid-and-filter-ultimate' ) 	=> 'Bottom',
							),
						'description' 	=> __( 'Popup Position Y.', 'post-grid-and-filter-ultimate' ),
						),			
						
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Speed In', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'speed_in',
						'value' 		=> '',
						'description' 	=> __( 'Enter Value ', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Speed Out', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'speed_out',
						'value' 		=> '',
						'description' 	=> __( 'Enter Value ', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Delay', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'delay',
						'value' 		=> '',
						'description' 	=> __( 'Enter Value ', 'post-grid-and-filter-ultimate' ),
						),	
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Enable loader', 'post-grid-and-filter-ultimate'),
						'param_name' 	=> 'enable_loader',
						'value' 		=> array(
							__( 'True', 'post-grid-and-filter-ultimate' ) 	=> 'true',
							__( 'False', 'post-grid-and-filter-ultimate' ) 	=> 'false',
							),
						'description' 	=> __( 'Enable Popup loader .', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'dropdown',
						'class' 		=> '',
						'heading' 		=> __( 'Enable overlay', 'post-grid-and-filter-ultimate'),
						'param_name' 	=> 'enable_overlay',
						'value' 		=> array(
							__( 'True', 'post-grid-and-filter-ultimate' ) 	=> 'true',
							__( 'False', 'post-grid-and-filter-ultimate' ) 	=> 'false',
							),
						'description' 	=> __( 'Enable Popup overlay.', 'post-grid-and-filter-ultimate' ),
						),	
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Overlay color', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'overlay_color',
						'value' 		=> '',
						'description' 	=> __( 'Enter Color Value ie #000000 ', 'post-grid-and-filter-ultimate' ),
						),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> __( 'Overlay opacity', 'post-grid-and-filter-ultimate' ),
						'param_name' 	=> 'overlay_opacity',
						'value' 		=> '',
						'description' 	=> __( 'Enter opacity value. Rage is 0 to 1 ', 'post-grid-and-filter-ultimate' ),
						),					
					
				),
			)
		);
	}
}


$pgafupro_vc = new Pgafupro_Vc();
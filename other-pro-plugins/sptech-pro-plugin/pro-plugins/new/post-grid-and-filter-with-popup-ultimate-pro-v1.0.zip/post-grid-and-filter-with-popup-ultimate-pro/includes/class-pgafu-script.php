<?php
/**
 * Script Class
 *
 * Handles the script and style functionality of plugin
 *
 * @package Post grid and filter ultimate
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Pgafupro_Script {
	
	function __construct() {
		
		// Action to add style at front side
		add_action( 'wp_enqueue_scripts', array($this, 'pgafupro_plugin_style') );

		// Action to add script at front side
		add_action( 'wp_enqueue_scripts', array($this, 'pgafupro_plugin_script') );		
		
	}

	/**
	 * Function to add script at front side
	 * 
	 * @package Post grid and filter ultimate
	 * @since 1.0.0
	 */
	function pgafupro_plugin_style(){		
		
		// Registring and enqueing public css
		wp_register_style( 'pgafupro-public-style', PGAFUPRO_URL.'assets/css/pgafu-public.css', array(), PGAFUPRO_VERSION );
		wp_enqueue_style( 'pgafupro-public-style');		
		
	}

	/**
	 * Function to add script at front side
	 * 
	 * @package Post grid and filter ultimate
	 * @since 1.0.0
	 */
	function pgafupro_plugin_script() {		
		
		// Registring tooltip js
		if( !wp_script_is( 'wpos-filterizr-js', 'registered' ) ) {
			wp_register_script( 'wpos-filterizr-js', PGAFUPRO_URL.'assets/js/filterizr.js', array('jquery'), PGAFUPRO_VERSION, true );
		}
		// Registring animate js
		if( !wp_script_is( 'popupaoc-legacy-js', 'registered' ) ) {	
			wp_register_script( 'popupaoc-legacy-js', PGAFUPRO_URL.'assets/js/custombox.legacy.min.js', array('jquery'), PGAFUPRO_VERSION, true );
		}
		// Registring animate js
		if( !wp_script_is( 'popupaoc-popup-js', 'registered' ) ) {	
			wp_register_script( 'popupaoc-popup-js', PGAFUPRO_URL.'assets/js/pgafu-popup.min.js', array('jquery'), PGAFUPRO_VERSION, true );	
		}
		
		// Registring public js
		wp_register_script( 'pgafupro-public-js', PGAFUPRO_URL.'assets/js/pgafu-public.js', array('jquery'), PGAFUPRO_VERSION, true );
		
		
	}	
}

$pgafupro_script = new Pgafupro_Script();
<?php
/**
 * 'pgaf_post_grid' Shortcode
 * 
 * @package Post grid and filter ultimate
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Function to handle the 'pgaf_post_grid' shortcode
 * 
 * @package Post grid and filter ultimate
 * @since 1.0.0
 */
function pgafupro_post_grid_shortcode( $atts, $content ) {
	
	// Shortcode Parameters
	extract(shortcode_atts(array(
		'limit' 				=> '15',
		'cat_id' 				=> '',
		'include_cat_child'		=> 'true',		
		'order'					=> 'DESC',
		'orderby'				=> 'date',
		'grid' 					=> '3',		
		'image_fit' 			=> 'true',		
		'media_size' 			=> 'large',
		'show_date' 			=> 'true',
		'show_category_name' 	=> 'true',
		'show_author' 			=> 'true',
		'image_height' 			=> '',
		'design'				=> 'design-1',		
		'content_words_limit' 	=> '20',
		'show_read_more'        => 'true',
		'content_tail'			=> '...',
		'pagination' 			=> 'true',
		'pagination_type'		=> 'numeric',
		'show_comments'			=> 'true',
		'show_content' 			=> 'true',
		'single_post_popup'     => 'false',			
		'read_more_text'		=> __('Read More', 'post-grid-and-filter-ultimate'),
		'exclude_cat'			=> array(),
		'exclude_post'			=> array(),
		'posts'					=> array(),			
		'popup_effect'          => 'fadein',
		'popup_positionx'       => 'center',
		'popup_positiony'    	=> 'center',
		'full_screen'           => 'false',
		'speed_in'              => '300',
		'speed_out'             => '300',
		'delay'                 => '150',
		'enable_loader'         => 'true',
		'enable_overlay'        => 'true',
		'overlay_color'         => '#000',
		'overlay_opacity'       => '0.5',		
		), $atts, 'pgaf_post_grid'));
	
	$shortcode_designs	= pgafupro_post_grid_designs();	
	$unique 			= pgafupro_get_unique();
	$limit				= !empty($limit) 					? $limit 						: '15';
	$order 				= ( strtolower($order) == 'asc' ) 	? 'ASC' 						: 'DESC';
	$orderby			= !empty($orderby) 					? $orderby 						: 'date';
	$gridcol			= !empty($grid) 					? $grid 						: '1';
	$design 			= array_key_exists( trim($design)  , $shortcode_designs ) ? $design : 'design-1';	
	$cat_id				= (!empty($cat_id))					? explode(',',$cat_id) 			: '';
	$include_cat_child	= ( $include_cat_child == 'false' ) ? false 						: true;	
	$words_limit 		= !empty( $content_words_limit ) 	? $content_words_limit          : 20;
	$content_tail 		= html_entity_decode($content_tail);
	$show_read_more  	= ($show_read_more == 'false' )     ? false 						: true;	
	$showAuthor 		= ($show_author == 'false')			? false						    : true;
	$media_size 		= (!empty($media_size))				? $media_size 	                : 'large'; //thumbnail, medium, large, full	
	$showDate 			= ($show_date == 'false' ) 			? false							: true;
	$showCategory 		= ($show_category_name == 'false' ) ? false 						: true;
	$image_height 		= (!empty($image_height))           ? $image_height                 : '';
	$height_css 		= ($image_height)                   ? 'height:'.$image_height.'px;' : '';
	$pagination 		= ($pagination == 'false')			? false						    : true;
	$pagination_type 	= ($pagination_type == 'prev-next')	? 'prev-next' 					: 'numeric';
	$image_fit			= ($image_fit == 'false')			? 0                             : 1;
	$show_comments 		= ($show_comments == 'false' ) 		? false							: true;
	$showContent 		= ($show_content == 'false' ) 		? false 						: true;
	$single_post_popup 	= ($single_post_popup == 'false' )  ? false 						: true;
	$read_more_text 	= !empty($read_more_text) 			? $read_more_text 				: __('Read More', 'post-grid-and-filter-ultimate');
	$exclude_cat 		= !empty($exclude_cat)				? explode(',', $exclude_cat) 	: array();
	$exclude_post 		= !empty($exclude_post)				? explode(',', $exclude_post) 	: array();
	$posts 				= !empty($posts)					? explode(',', $posts) 			: array();
	
	$popup_effect 		= (!empty($popup_effect))			? $popup_effect 	            : 'fadein'; //fadein, slide, fall, flip, blur, rotate		
	$popup_positionx 	= (!empty($popup_positionx))		? $popup_positionx 	    		: 'center';  //Set horizontal position of modal (left, center or right).	
	$popup_positiony 	= (!empty($popup_positiony))		? $popup_positiony 	    		: 'center';  //Set vertical position of modal (top, center or bottom).
	$full_screen		= ( $full_screen == 'false' ) 		? 'false' 						: 'true';		
	$speed_in			= !empty($speed_in) 				? $speed_in 					: '300';
	$speed_out			= !empty($speed_out) 				? $speed_out 					: '300';
	$delay				= !empty($delay) 					? $delay 						: '150';
	$enable_loader 		= ( $enable_loader == 'false' ) 	? 'false'						: 'true';
	$enable_overlay 	= ( $enable_overlay == 'false' )	? 'false' 						: 'true';
	$overlay_color		= !empty($overlay_color) 			? $overlay_color 				: '#000';
	$overlay_opacity	= !empty($overlay_opacity) 			? $overlay_opacity 				: '0.5';
	
	
	// Shortcode file
	$post_design_file_path 	= PGAFUPRO_DIR . '/templates/grid/' . $design . '.php';
	$design_file 			= (file_exists($post_design_file_path)) ? $post_design_file_path : '';
	
	wp_enqueue_script( 'popupaoc-legacy-js' );
	wp_enqueue_script( 'popupaoc-popup-js' );	
	
	// Taking some globals
	global $post, $paged;
	$grid_count     = 1;
	$count 			= 0;
	$i              = 0;
	$j              = 0;	
	$image_fit_class	= ($image_fit) 	? 'pgafu-image-fit' : '';
	
	// Pagination parameter
	if(is_home() || is_front_page()) {
		$paged = get_query_var('page');
	} else {
		$paged = get_query_var('paged');
	}
	
	// WP Query Parameters
	$query_args = array(
			'post_type' 			=> PGAFUPRO_POST_TYPE,
			'post_status' 			=> array( 'publish' ),
			'posts_per_page'		=> $limit,
			'order'          		=> $order,
			'orderby'        		=> $orderby,
			'post__in'				=> $posts,
			'post__not_in'			=> $exclude_post,	
			'ignore_sticky_posts'	=> true,
			'paged'         		=> $paged,
		);

	// Category Parameter
	if( !empty($cat_id) ) {
		$query_args['tax_query'] = array( 
										array(
											'taxonomy' 			=> PGAFUPRO_CAT, 
											'field' 			=> 'term_id',
											'terms' 			=> $cat_id,
											'include_children'	=> $include_cat_child,
										));

	} else if( !empty($exclude_cat) ) {
		
		$query_args['tax_query'] = array(
								array(
									'taxonomy' 			=> PGAFUPRO_CAT,
									'field' 			=> 'term_id',
									'terms' 			=> $exclude_cat,
									'operator'			=> 'NOT IN',
									'include_children'	=> $include_cat_child,
								));
	} 

	// WP Query
	$post_query = new WP_Query($query_args);
	$post_count = $post_query->post_count;
	
	ob_start();
	
	// If post is there
	if ( $post_query->have_posts() ) {
?>
		<div class="pgafu-post-grid-wrp pgafu-clearfix">
			<div id="pgafu-post-grid-<?php echo $unique; ?>" class="pgafu-post-grid-main <?php echo 'pgafu-'.$design.' '.$image_fit_class; ?> pgafu-grid-<?php echo $gridcol; ?>">			
				<?php
				while ( $post_query->have_posts() ) : $post_query->the_post();				
					$count++;
					$i++;
					$cat_links 				= array();
					$css_class 				= '';
					$post_featured_image 	= pgafupro_get_post_featured_image( $post->ID, $media_size, true );	
					$post_link 		        = pgafupro_get_post_link( $post->ID );		
					$terms 					= get_the_terms( $post->ID, PGAFUPRO_CAT );				
					$comments 				= get_comments_number( $post->ID );
					$reply					= ($comments <= 1)  ? 'Reply' : 'Replies';
					
					$data_popuppgafu_str = '{"content":';
					$data_popuppgafu_str .= '{"effect": "'.$popup_effect.'", "positionX": "'.$popup_positionx.'", "positionY": "'.$popup_positiony.'", "fullscreen": '.$full_screen.', "speedIn": '.$speed_in.', "speedOut": '.$speed_out.', "delay": '.$delay.'},';	
					$data_popuppgafu_str .= '"loader":';	
					$data_popuppgafu_str .= '{"active": '.$enable_loader.'},';
					$data_popuppgafu_str .= '"overlay":';	
					$data_popuppgafu_str .= '{"active": '.$enable_overlay.', "color": "'.$overlay_color.'", "opacity": '.$overlay_opacity.'}';	
					$data_popuppgafu_str .= '}';
					
					if(!$single_post_popup) {
						$post_link_print  = 'href="'.$post_link.'"';		
					} else {
						$post_link_print  = "href='javascript:void(0);' data-popuppgafu-{$unique}{$i}='{$data_popuppgafu_str}'";
					}
					
					if($terms) {
						foreach ( $terms as $term ) {
							$term_link = get_term_link( $term );
							$cat_links[] = '<a href="' . esc_url( $term_link ) . '">'.$term->name.'</a>';
						}
					}
					$cate_name = join( " ", $cat_links );
					
					if ( ( is_numeric( $grid ) && ( $grid > 0 ) && ( 0 == ($count - 1) % $grid ) ) || 1 == $count ) { $css_class .= ' pgafu-first'; }
					if ( ( is_numeric( $grid ) && ( $grid > 0 ) && ( 0 == $count % $grid ) ) || $post_count == $count ) { $css_class .= ' pgafu-last'; }				
					
					
					// Include shortcode html file
					if( $design_file ) {
						include( $design_file );
					}			
				$grid_count++;
				endwhile; ?>
			</div>		
		<?php if($pagination == "true") { ?>
			<div class="pgafu-post-pagination pgafu-clearfix">
				<?php if($pagination_type == "numeric") {				
					echo pgafupro_pagination( array( 'paged' => $paged , 'total' => $post_query->max_num_pages ) );
				} else { ?>
					<div class="button-post-p"><?php next_posts_link( ' Next >>', $post_query->max_num_pages ); ?></div>
					<div class="button-post-n"><?php previous_posts_link( '<< Previous' ); ?></div>
				<?php } ?>
			</div>
		<?php }
		if($single_post_popup) {
			while ( $post_query->have_posts() ) : $post_query->the_post();
					$j++;				
					$cat_links 				= array();
					$post_featured_image 	= pgafupro_get_post_featured_image( $post->ID, $media_size, true );
					$terms 					= get_the_terms( $post->ID, PGAFUPRO_CAT );				
					$comments 				= get_comments_number( $post->ID );
					$reply					= ($comments <= 1)  ? 'Reply' : 'Replies';				
					
					
					if($terms) {
						foreach ( $terms as $term ) {
							$term_link = get_term_link( $term );
							$cat_links[] = '<a href="' . esc_url( $term_link ) . '">'.$term->name.'</a>';
						}
					}	
					$cate_name = join( " ", $cat_links );
					
				?>		
			<div id="popuppgafu-modal-<?php echo $unique.''.$j;?>" class="popuppgafu-modal <?php echo $image_fit_class; ?>">
				<a href="javascript:void(0);" onclick="Custombox.modal.close();" class="popuppgafu-close"></a>	               
				<div class="pgafu-modal-content">
				<?php if ( has_post_thumbnail() ) { ?>
					<div class="pgafu-post-single-image-bg">					
							<img src="<?php echo $post_featured_image; ?>" alt="<?php the_title(); ?>" />
						
					</div>
					<?php } if($showCategory && $cate_name !='') { ?>
						<div class="pgafu-post-categories">
							<?php echo $cate_name; ?>
						</div>
						<?php }  ?>
					<h2 class="pgafu-post-title"><?php the_title(); ?></a></h2>
					 <?php if($showDate || $showAuthor || $show_comments) { ?>
						<div class="pgafu-post-date">
							<?php if($showAuthor) { ?>
								<span class="pgafu-user-img"><img src="<?php echo PGAFUPRO_URL; ?>assets/images/user.svg" alt=""> <?php the_author(); ?></span>
							<?php } ?>
							<?php echo ($showAuthor && $showDate) ? '&nbsp;' : '' ?>
							<?php if($showDate) { ?>
								<span class="pgafu-time"> <img src="<?php echo PGAFUPRO_URL; ?>assets/images/calendar.svg" alt=""> <?php echo get_the_date(); ?> </span>
							<?php } ?>
							<?php echo ($showAuthor && $showDate && $show_comments) ? '&nbsp;' : '' ?>
							<?php if(!empty($comments) && $show_comments) { ?>
								<span class="pgafu-post-comments">
									<img src="<?php echo PGAFUPRO_URL; ?>assets/images/comment-bubble.svg" alt="" />
									<a href="<?php the_permalink(); ?>#comments"><?php echo $comments.' '.$reply;  ?></a>
								</span>
							<?php } ?>	
						</div><!-- end .pgafu-post-date -->
					<?php } ?>
					<div class="pgafu-post-single-content">
						<?php the_content(); ?>
					</div>
				</div>
			</div>		
				<script>
					jQuery(function() {
					 jQuery(document).on('click', '[data-popuppgafu-<?php echo $unique.''.$j;?>]', function() {
						var options = jQuery(this).data('popuppgafu-<?php echo $unique.''.$j;?>');
						if (!options.content.target) {
						  options.content.target = '#popuppgafu-modal-<?php echo $unique.''.$j?>';
						}

						new Custombox.modal(options).open();
					  });

					 }); 
			</script>		
		<?php endwhile; 
			}
		}	// end of checkpopup true	
	?>	
	</div>		
	<?php
	wp_reset_query(); // Reset WP Query

    $content .= ob_get_clean();
    return $content;
}
add_shortcode('pgaf_post_grid', 'pgafupro_post_grid_shortcode');
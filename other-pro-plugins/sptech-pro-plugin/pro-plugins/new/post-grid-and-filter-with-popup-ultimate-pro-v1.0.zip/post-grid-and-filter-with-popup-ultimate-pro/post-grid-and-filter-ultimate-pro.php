<?php
/**
 * Plugin Name: Post grid and filter with popup Pro
 * Plugin URI: https://www.wponlinesupport.com
 * Description: Display post grid on your website with or without categoryies filter. Option to display detail view of  post a in popup OR in sngle.php file.
 * Author: WP Online Support
 * Author URI: https://www.wponlinesupport.com
 * Text Domain: post-grid-and-filter-ultimate
 * Domain Path: /languages/
 * Version: 1.0
 *
 * @package WordPress
 * @author WP Online Support
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Basic plugin definitions
 * 
 * @package Post grid and filter ultimate
 * @since 1.0.0
 */
if( !defined( 'PGAFUPRO_VERSION' ) ) {
	define( 'PGAFUPRO_VERSION', '1.0' ); // Version of plugin
}
if( !defined( 'PGAFUPRO_DIR' ) ) {
	define( 'PGAFUPRO_DIR', dirname( __FILE__ ) ); // Plugin dir
}
if( !defined( 'PGAFUPRO_URL' ) ) {
	define( 'PGAFUPRO_URL', plugin_dir_url( __FILE__ ) ); // Plugin url
}
if( !defined( 'PGAFUPRO_PLUGIN_BASENAME' ) ) {
    define( 'PGAFUPRO_PLUGIN_BASENAME', plugin_basename( __FILE__ ) ); // Plugin base name
}
if( !defined( 'PGAFUPRO_POST_TYPE' ) ) {
	define( 'PGAFUPRO_POST_TYPE', 'post' ); // Plugin post type name
}
if( !defined( 'PGAFUPRO_CAT' ) ) {
	define( 'PGAFUPRO_CAT', 'category' ); // Plugin taxonomy name
}

/**
 * Load Text Domain
 * This gets the plugin ready for translation
 * 
 * @package Post grid and filter ultimate
 * @since 1.0.0
 */
function pgafupro_load_textdomain() {

    global $wp_version;

    // Set filter for plugin's languages directory
    $pgafupro_lang_dir = dirname( plugin_basename( __FILE__ ) ) . '/languages/';
    $pgafupro_lang_dir = apply_filters( 'pgafupro_languages_directory', $pgafupro_lang_dir );

    // Traditional WordPress plugin locale filter.
    $get_locale = get_locale();

    if ( $wp_version >= 4.7 ) {
        $get_locale = get_user_locale();
    }

    // Traditional WordPress plugin locale filter
    $locale = apply_filters( 'plugin_locale',  $get_locale, 'post-grid-and-filter-ultimate' );
    $mofile = sprintf( '%1$s-%2$s.mo', 'post-grid-and-filter-ultimate', $locale );

    // Setup paths to current locale file
    $mofile_global  = WP_LANG_DIR . '/plugins/' . basename( PGAFUPRO_DIR ) . '/' . $mofile;

    if ( file_exists( $mofile_global ) ) { // Look in global /wp-content/languages/plugin-name folder
        load_textdomain( 'post-grid-and-filter-ultimate', $mofile_global );
    } else { // Load the default language files
        load_plugin_textdomain( 'post-grid-and-filter-ultimate', false, $pgafupro_lang_dir );
    }
}
add_action('plugins_loaded', 'pgafupro_load_textdomain');


/***** Updater Code Starts *****/
define( 'EDD_PGAFUPRO_STORE_URL', 'https://www.wponlinesupport.com' );
define( 'EDD_PGAFUPRO_ITEM_NAME', 'Post grid and filter with popup Pro' );

// Plugin Updator Class 
if( !class_exists( 'EDD_SL_Plugin_Updater' ) ) {	
	include( dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php' );
}

/**
 * Updater Function
 * 
 * @package Post grid and filter ultimate
 * @since 1.0.0
 */
function pgafu_plugin_updater() {
	
	$license_key = trim( get_option( 'edd_pgafupost_license_key' ) );

	$edd_updater = new EDD_SL_Plugin_Updater( EDD_PGAFUPRO_STORE_URL, __FILE__, array(
			'version' 	=> PGAFUPRO_VERSION, 	// current version number
			'license' 	=> $license_key, 		// license key (used get_option above to retrieve from DB)
			'item_name' => EDD_PGAFUPRO_ITEM_NAME, // name of this plugin
			'author' 	=> 'WP Online Support'  // author of this plugin
		)
	);
}
add_action( 'admin_init', 'pgafu_plugin_updater', 0 );

include( dirname( __FILE__ ) . '/edd-pgafu-plugin.php' );
/***** Updater Code Ends *****/

// Functions file
require_once( PGAFUPRO_DIR . '/includes/pgafu-functions.php' );

// Script Class
require_once( PGAFUPRO_DIR . '/includes/class-pgafu-script.php' );

// Shortcode File
require_once( PGAFUPRO_DIR . '/includes/shortcode/pgafu-post-grid.php' );
require_once( PGAFUPRO_DIR . '/includes/shortcode/pgafu-postgrid-filter.php' );

// VC Shortcode File
require_once( PGAFUPRO_DIR . '/includes/admin/class-pgafu-vc.php' );

// How it work file, Load admin files
if ( is_admin() || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
    require_once( PGAFUPRO_DIR . '/includes/admin/pgafu-how-it-work.php' );
}
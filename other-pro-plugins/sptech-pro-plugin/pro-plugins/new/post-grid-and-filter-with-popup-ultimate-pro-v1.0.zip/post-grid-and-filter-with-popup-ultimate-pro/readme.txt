===  Post grid and filter with popup Pro ===
Tags: post grid, post, post filter, post category filter, custom post grid, grid display, grid, content grid, filter, post designs, grid designs
Contributors: wponlinesupport, anoopranawat 
Requires at least: 3.1
Tested up to: 4.8
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Display post grid on your website with or without categoryies filter. Option to display detail view of  post a in popup OR in sngle.php file.

== Description ==
Easy way to display WordPress post in grid view and post grid with filter. Display anywhere via shortcode. lots more shortcode parameters give you extend as your needs.

Post grid and filter ultimate helps you to display any WordPress posts on any page, in responsive grid and list easily, without coding.

= Features include: =
* Post grid with 2 designs.
* Post grid filter with 2 designs.
* Display recent posts in a second.
* Display posts on page, sidebar widgets, theme file.
* Sort posts by title, date, ID
* Display featured image in any size (thumbnail, medium, large, full)
* Limit number of posts to display
* Enable/Disable pagination (2 type of paginations)
* Lost of shortcode parameters.
* Fully Responsive.
* 100% Multilanguage.

= Plugin contains 2 shortcodes =
<code>[pgaf_post_grid]</code> - Post Grid Shortcode
<code>[pgaf_post_filter]</code> - Post Filter Shortcode

= Template code is =
<code><?php echo do_shortcode('[pgaf_post_grid]'); ?></code>
<code><?php echo do_shortcode('[pgaf_post_filter]'); ?></code>

== Installation ==

1. Upload the 'Post grid and filter with popup Pro' folder to the '/wp-content/plugins/' directory.
2. Activate the "Post grid and filter with popup Pro " list plugin through the 'Plugins' menu in WordPress.
3. Add a new page and add shortcode.


== Changelog ==

= 1.0 =
* Initial release.


== Upgrade Notice ==

= 1.0 =
* Initial release.
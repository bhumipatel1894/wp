<div class="pgafu-post-grid">			
	<div class="pgafu-post-grid-content <?php if ( !has_post_thumbnail() ) { echo 'no-thumb-image'; } ?>">
		<?php		
		if ( has_post_thumbnail() ) { ?>
		<div class="pgafu-post-image-bg" style="<?php echo $height_css; ?>">
			<a <?php echo $post_link_print; ?>>
				<img src="<?php echo $post_featured_image; ?>" alt="<?php the_title(); ?>" />
			</a>
		</div>
		<?php }  ?>	
		<div class="pgafu-post-content-bacground">	
				<h2 class="pgafu-post-title">
					<a <?php echo $post_link_print; ?>><?php the_title(); ?></a>
				</h2>

				<?php  if($showCategory && $cate_name !='') { ?>
					<div class="pgafu-post-categories">
						<?php echo $cate_name; ?>
					</div>
				<?php }  		
					 if($showDate || $showAuthor || $show_comments) { ?>
						<div class="pgafu-post-date">
							<?php if($showAuthor) { ?>
								<span class="pgafu-user-img"><img src="<?php echo PGAFUPRO_URL; ?>assets/images/user.svg" alt=""> <?php the_author(); ?></span>
							<?php } ?>
							<?php echo ($showAuthor && $showDate) ? '&nbsp;' : '' ?>
							<?php if($showDate == "true") { ?>
								<span class="pgafu-time"> <img src="<?php echo PGAFUPRO_URL; ?>assets/images/calendar.svg" alt=""> <?php echo get_the_date(); ?> </span>
							<?php } ?>
							<?php echo ($showAuthor && $showDate && $show_comments) ? '&nbsp;' : '' ?>
							<?php if(!empty($comments) && $show_comments) { ?>
								<span class="pgafu-post-comments">
									<img src="<?php echo PGAFUPRO_URL; ?>assets/images/comment-bubble.svg" alt="" />
									<a href="<?php the_permalink(); ?>#comments"><?php echo $comments.' '.$reply;  ?></a>
								</span>
							<?php } ?>	
						</div><!-- end .pgafu-post-date -->
					<?php }  
				if($showContent) { ?>
						<div class="pgafu-post-content">				
								<div class="pgafu-post-short-content"><?php echo pgafupro_get_post_excerpt( $post->ID, get_the_content(), $words_limit, $content_tail ); ?></div>
								<?php if($show_read_more) { ?>
									<a <?php echo $post_link_print; ?>  class="readmorebtn"><?php echo esc_html($read_more_text); ?></a>
								<?php } ?>				
						</div>
					<?php } ?>				
		</div>	
	</div>
</div>
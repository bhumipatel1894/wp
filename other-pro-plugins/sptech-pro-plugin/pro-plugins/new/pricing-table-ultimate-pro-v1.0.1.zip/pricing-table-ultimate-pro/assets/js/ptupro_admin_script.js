jQuery(document).ready(function (){  
    jQuery('.ptu_font_sett').hide();    
    jQuery("#ptu_font_sett_button").click(function(){
        jQuery('.ptu_font_sett').slideToggle();
    });     
    
});
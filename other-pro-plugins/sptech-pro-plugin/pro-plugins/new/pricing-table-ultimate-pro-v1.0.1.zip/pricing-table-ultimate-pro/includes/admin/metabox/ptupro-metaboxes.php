<?php
/**
 * Register metaboxes for Pricing Tables.
 */
function ptupro_register_group_metabox() {

    /* Custom sanitization call-back to allow HTML in most fields */
    function ptu_html_allowed_sani_cb($content) {
        return wp_kses_post( $content );
    }

    /* Custom sanitization call-back for custom button field */
    function ptu_custom_button_sani_cb($content) {
        return balanceTags( $content, true );
    }

    $prefix = PTUPRO_META_PREFIX;
	
	 // Settings
    $design_group = new_cmb2_box( array(
        'id' => $prefix . 'design_metabox',
        'title' => '<span style="font-weight:bold;">'.__( 'Select Design', 'pricing-table-ultimate-pro' ).'</span>',
        'object_types' => array( PTUPRO_POST_TYPE ),
        
    ));

        $design_group->add_field( array(
			'name'             => 'Select Designs',
			'desc'             => 'Select design for pricing table',
			'id' 				=> $prefix . 'plan_design',
			'type'             => 'select',			
			'default'          => 'ptu-design-1',
			'options'          => array(
				'design-1' 			=> __( 'Design-1', 'pricing-table-ultimate-pro' ),
				'design-2'  		=> __( 'Design-2', 'pricing-table-ultimate-pro' ),
				'design-3'     		=> __( 'Design-3', 'pricing-table-ultimate-pro' ),
				'design-4'  		=> __( 'Design-4', 'pricing-table-ultimate-pro' ),
				'design-5'     		=> __( 'Design-5', 'pricing-table-ultimate-pro' ),
				'design-6'     		=> __( 'Design-6', 'pricing-table-ultimate-pro' ),
				'design-7'  		=> __( 'Design-7', 'pricing-table-ultimate-pro' ),
				'design-8'     		=> __( 'Design-8', 'pricing-table-ultimate-pro' ),
				'design-9'  		=> __( 'Design-9', 'pricing-table-ultimate-pro' ),
				'design-10'     	=> __( 'Design-10', 'pricing-table-ultimate-pro' ),
			),
			
		) );
		
		 $design_group->add_field( array(
                'name' => __( 'Customize this design', 'pricing-table-ultimate-pro' ),
                'desc' => __( 'By selecting this option, above selected design will override by colors(Prcing Table Colors Setting) and font size(Adjust font sizes) selected by you.', 'pricing-table-ultimate-pro' ),
				'id'   => $prefix . 'cust_design',
				'type' => 'checkbox',				
				'default' => false,
            ));
	
    // Tables group
    $main_group = new_cmb2_box( array(
        'id' => $prefix . 'plan_metabox',
        'title' => '<span style="font-weight:bold;">'.__( 'Manage Pricing Table Plans', 'pricing-table-ultimate-pro' ).'</span>',
        'object_types' => array( PTUPRO_POST_TYPE ),
    ));

        $ptupro_pricing_plan_group = $main_group->add_field( array(
            'id' => $prefix . 'plan_group',
            'type' => 'group',
            'options' => array(
                'group_title' => __('Pricing Plan {#}', 'pricing-table-ultimate-pro' ),
                'add_button' => __('Add another pricing plan', 'pricing-table-ultimate-pro' ),
                'remove_button' => __('Remove pricing plan', 'pricing-table-ultimate-pro' ),
                'sortable' => true,
                'single' => false,
            ),
        ));

            $main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Pricing Table Plan header', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'head_header',
                'type' => 'title',
                'row_classes' => 'ptupro-medium-12 ptupro-columns ptupro-heading',
            ));

            $main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Title', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'title',
                'type' => 'text',
                'row_classes' => 'ptupro-medium-6 ptupro-columns ptupro-text ptupro-input',
                'sanitization_cb' => 'ptu_html_allowed_sani_cb',
				
            ));

            $main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Subtitle', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'subtitle',
                'type' => 'text',
                'row_classes' => 'ptupro-medium-6 ptupro-columns ptupro-text ptupro-input',
                'sanitization_cb' => 'ptu_html_allowed_sani_cb',
            ));

            $main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Recurrence', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'recurrence',
				'desc'    => 'eg. Per Month/Year',
                'type' => 'text',
                'row_classes' => 'ptupro-medium-3 ptupro-columns ptupro-text ptupro-input',
                'sanitization_cb' => 'ptu_html_allowed_sani_cb',
            ));

             $main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Price', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'price',
                'type' => 'text',
				'desc'    => 'eg. 50 OR FREE',
                'row_classes' => 'ptupro-medium-3 ptupro-columns ptupro-text ptupro-input',
                'sanitization_cb' => 'ptu_html_allowed_sani_cb',
            ));

             $main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Description', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'description',
                'type' => 'text',
				'desc'    => 'Short text that will appear below the subtitle',
                'row_classes' => 'ptupro-medium-6 ptupro-columns ptupro-text ptupro-input',
                'sanitization_cb' => 'ptu_html_allowed_sani_cb',
            ));

            $main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Small icon image....', 'pricing-table-ultimate-pro' ),
                'id'   => $prefix . 'icon',
                'type' => 'file',
				'desc'    => 'Upload image icon',
                'options' => array('add_upload_file_text' => __( 'Upload', 'pricing-table-ultimate-pro' )),
                'row_classes' => 'ptupro-medium-6 ptupro-columns ptupro-upload ptupro-input',
            ));
			 $main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( '.....OR Font Awesome Icon', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'fa_icon',
                'type' => 'text',
                'row_classes' => 'ptupro-medium-6 ptupro-columns ptupro-text ptupro-input',
				'desc'    => 'Add Font Awesome Icon eg fa-diamond',
                'sanitization_cb' => 'ptu_html_allowed_sani_cb',
				
            ));

            $main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Recommended plan', 'pricing-table-ultimate-pro' ),
                'desc' => __( 'Mark as recommended : Check this to highlight pricing table plan', 'pricing-table-ultimate-pro' ),
				'id'   => $prefix . 'recommended',
				'type' => 'checkbox',				
				'row_classes' => 'ptupro-medium-6 ptupro-columns ptupro-checkbox_side ptupro-clear',
				'default' => false,
            ));
			$main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Recommended TEXT', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'recommended_text',
                'type' => 'text',
                'row_classes' => 'ptupro-medium-6 ptupro-columns ptupro-text ptupro-input',
				'desc'    => 'Add recommended TEXT eg POPULER',
                'sanitization_cb' => 'ptu_html_allowed_sani_cb',
				
            ));

            $main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Remove currency sign', 'pricing-table-ultimate-pro' ),
                'desc' => __( 'Remove currency sign : Highlight FREE plan', 'pricing-table-ultimate-pro' ),
		      'id'   => $prefix . 'free',
		      'type' => 'checkbox',			  
              'row_classes' => 'ptupro-medium-12 ptupro-columns ptupro-checkbox_side',
              'default' => false,
            ));

            $main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Plan features', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'features_header',
                'type' => 'title',
                'row_classes' => 'ptupro-medium-12 ptupro-columns ptupro-heading',
            ));

            $main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Feature list', 'pricing-table-ultimate-pro' ),
				        'id' => $prefix . 'features',
				        'type' => 'textarea',
						'attributes'  => array('rows' => 9),
						'row_classes' => 'ptupro-medium-6 ptupro-columns ptupro-textarea ptupro-input',
						'sanitization_cb' => 'ptu_html_allowed_sani_cb',
						'attributes'  => array(
						'placeholder' => __('One feature per line', 'pricing-table-ultimate-pro' ),
                ),
            ));

            $main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Tips & Tricks', 'pricing-table-ultimate-pro' ),
                'desc' => '<span class="dashicons dashicons-yes"></span> '.__( 'Add images (not recommended)', 'pricing-table-ultimate-pro' ).'<br/><span style="color:#bbb;">&lt;img src="http://yoursite.com/yourimage.png"/&gt;</span><br/><br/><span class="dashicons dashicons-yes"></span> '.__( 'Add links', 'pricing-table-ultimate-pro' ).'<br/><span style="color:#bbb;">&lt;a href="http://yoursite.com"&gt;Go to yoursite.com&lt;/a&gt;</span><br/><br/><span class="dashicons dashicons-yes"></span> '.__( 'Add bold text', 'pricing-table-ultimate-pro' ).'<br/><span style="color:#bbb;">&lt;strong&gt;Something <strong>important</strong>&lt;/strong&gt;</span><br/><br/><span class="dashicons dashicons-yes"></span> '.__( 'Show feature as unavailable with', 'pricing-table-ultimate-pro' ).' "-n"<br/><span style="color:#bbb;">-nMy feature</span>',
                'id'   => $prefix . 'features_desc',
                'type' => 'title',
                'row_classes' => 'ptupro-medium-6 ptupro-columns ptupro-info',
            ));

            $main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Plan button...', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'button_header',
                'type' => 'title',
                'row_classes' => 'ptupro-medium-12 ptupro-columns ptupro-heading',
            ));

             $main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Button text', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'btn_text',
                'type' => 'text',
				'desc'    => 'eg. Sign up OR Buy',
                'row_classes' => 'ptupro-medium-4 ptupro-columns ptupro-text ptupro-input',
                'sanitization_cb' => 'ptu_html_allowed_sani_cb',
            ));

             $main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Button link', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'btn_link',
                'type' => 'text',
				'desc'    => 'eg. https://wponlinesupport.com',
                'row_classes' => 'ptupro-medium-4 ptupro-columns ptupro-text ptupro-input',
                'sanitization_cb' => 'ptu_html_allowed_sani_cb',
            ));
			
			$main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Select Button Color Class', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'btn_class',
                'type' => 'select',
				'default'  => 'ptufront-black',
				'options'  => array(
						'ptufront-black'					=> __('Black','pricing-table-ultimate-pro'),
						'ptufront-white'					=> __('White','pricing-table-ultimate-pro'),
						'ptufront-grey'					=> __('Gray','pricing-table-ultimate-pro'),
						'ptufront-azure'					=> __('Azure','pricing-table-ultimate-pro'),
						'ptufront-moderate-green'			=> __('Moderate Green','pricing-table-ultimate-pro'),	
						'ptufront-soft-red'				=> __('Soft Red','pricing-table-ultimate-pro'),
						'ptufront-red'					=> __('Moderate Red','pricing-table-ultimate-pro'),
						'ptufront-green'					=> __('Green','pricing-table-ultimate-pro'),
						'ptufront-bright-yellow'			=> __('Bright Yellow','pricing-table-ultimate-pro'),
						'ptufront-orange'					=> __('Cyan','pricing-table-ultimate-pro'),
						'ptufront-orange'					=> __('Orange','pricing-table-ultimate-pro'),
						'ptufront-moderate-violet'		=> __('Moderate Violet','pricing-table-ultimate-pro'),
						'ptufront-dark-magenta'			=> __('Dark Magenta','pricing-table-ultimate-pro'),
						'ptufront-moderate-blue'			=> __('Moderate Blue','pricing-table-ultimate-pro'),
						'ptufront-blue'					=> __('Blue','pricing-table-ultimate-pro'),						
						'ptufront-magenta'				=> __('Magenta','pricing-table-ultimate-pro'),
						'ptufront-lime'					=> __('Lime','pricing-table-ultimate-pro'),
						'ptufront-pink'					=> __('Pink','pricing-table-ultimate-pro'),
						'ptufront-vivid-yellow'			=> __('Vivid Yellow','pricing-table-ultimate-pro'),
						'ptufront-lime-green'				=> __('Lime Green','pricing-table-ultimate-pro'),
						'ptufront-yellow'					=> __('Yellow','pricing-table-ultimate-pro'),
				),
                'row_classes' => 'ptupro-medium-4 ptupro-columns ptupro-text ptupro-input',
                
            ));

            $main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( '...or a custom button instead', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'cust_button_header',
                'type' => 'title',
                'row_classes' => 'ptupro-medium-12 ptupro-columns ptupro-heading',
            ));

            $main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Custom button code OR Button shortcode', 'pricing-table-ultimate-pro' ),
				'id' => $prefix . 'btn_custom_btn',
				'type' => 'textarea',
                'attributes'  => array('rows' => 9),
                'row_classes' => 'ptupro-medium-6 ptupro-columns ptupro-textarea ptupro-input',
                'sanitization_cb' => 'ptu_custom_button_sani_cb',
                'attributes'  => array(
                 'placeholder' => __('Paste any button code here (Stripe, Paypal...)', 'pricing-table-ultimate-pro' ),
                ),
            ));

            $main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'What is a custom button OR Button shortcode?', 'pricing-table-ultimate-pro' ),
                'desc' => '<span class="dashicons dashicons-editor-code"></span> '.__( 'Button shortcode is code created with some plugin ie  WooCommerce, Easy Digital Downloads as well as many other plugin will generate buying buttons for you.', 'pricing-table-ultimate-pro' ).' <br/><br/><span class="dashicons dashicons-editor-help"></span> '.__( 'Custom buttons are provided by third-party payment plateforms to allow direct redirection to the payment page. Paypal, Stripe as well as many other companies will generate buying buttons for you.', 'pricing-table-ultimate-pro' ).' <br/><br/><span class="dashicons dashicons-admin-generic"></span> '.__( 'If you want your Pricing plan\'s footer to be replaced by a custom button, copy-paste the button code in this box. This will override the default button settings.', 'pricing-table-ultimate-pro' ),
                'id'   => $prefix . 'custom_button_desc',
                'type' => 'title',				
                'row_classes' => 'ptupro-medium-6 ptupro-columns ptupro-info',
            ));
			
			$main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Prcing Table Colors Setting', 'pricing-table-ultimate-pro' ),
                'id'   => $prefix . 'color_setting',
                'type' => 'title',
                'row_classes' => 'ptupro-medium-12 ptupro-columns ptupro-heading',
            ));		
			
			
			$main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Title background color', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'plan_header_color',
                'type' => 'colorpicker',
	            'default'  => '#f1f1f1',
                'row_classes' => 'ptupro-medium-6 ptupro-columns ptupro-color ptupro-input',
				'desc' =>'Select title background color',
            ));
			$main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Subtitle and Description background color', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'plan_subtitle_bgcolor',
                'type' => 'colorpicker',
	            'default'  => '#f1f1f1',
                'row_classes' => 'ptupro-medium-6 ptupro-columns ptupro-color ptupro-input',
				'desc' =>'Select subtitle and description background color',
            ));
			$main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Price background color', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'plan_price_bgcolor',
                'type' => 'colorpicker',
	            'default'  => '#f1f1f1',
                'row_classes' => 'ptupro-medium-6 ptupro-columns ptupro-color ptupro-input',
				'desc' =>'Select price background color',
            ));
			$main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Body background color', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'plan_body_color',
                'type' => 'colorpicker',
	            'default'  => '#f1f1f1',
                'row_classes' => 'ptupro-medium-6 ptupro-columns ptupro-color ptupro-input',
				'desc' =>'Body consist Plan features',
            ));
			$main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Footer background color', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'plan_footer_color',
                'type' => 'colorpicker',
	            'default'  => '#f1f1f1',
                'row_classes' => 'ptupro-medium-6 ptupro-columns ptupro-color ptupro-input',
				'desc' =>'Footer consist Plan Buttons',
            ));
			$main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Pricing table border color (If Needed)', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'plan_border_color',
                'type' => 'colorpicker',
	            'default'  => '',
                'row_classes' => 'ptupro-medium-6 ptupro-columns ptupro-color ptupro-input',
				'desc' =>'Select pricing table border color (If Needed) ',
            ));
			$main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Icon section background color', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'plan_icon_bgcolor',
                'type' => 'colorpicker',
	            'default'  => '#f1f1f1',
                'row_classes' => 'ptupro-medium-6 ptupro-columns ptupro-color ptupro-input',
				'desc' =>'Select icon section background color',
            ));
			$main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Icon color', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'plan_icon_color',
                'type' => 'colorpicker',
	            'default'  => '#555',
                'row_classes' => 'ptupro-medium-6 ptupro-columns ptupro-color ptupro-input',
				'desc' =>'Select icon color',
            ));
			$main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Title color', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'plan_title_color',
                'type' => 'colorpicker',
	            'default'  => '#000',
                'row_classes' => 'ptupro-medium-4 ptupro-columns ptupro-clear ptupro-color ptupro-input',
				'desc' =>'Select main title color',
            ));
			$main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Subtitle color', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'plan_subtitle_color',
                'type' => 'colorpicker',
	            'default'  => '#555',
                'row_classes' => 'ptupro-medium-4 ptupro-columns ptupro-color ptupro-input',
				'desc' =>'Select subtitle color',
            ));
			$main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Description color', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'plan_description_color',
                'type' => 'colorpicker',
	            'default'  => '#555',
                'row_classes' => 'ptupro-medium-4 ptupro-columns ptupro-color ptupro-input',
				'desc' =>'Select description color',
            ));
			
			
			$main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Price color', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'plan_price_color',
                'type' => 'colorpicker',
	            'default'  => '#000',
                'row_classes' => 'ptupro-medium-4 ptupro-columns ptupro-color ptupro-input',
				'desc' =>'Select price color',
            ));
			
			$main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Recurrence color', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'plan_recurrence_color',
                'type' => 'colorpicker',
	            'default'  => '#555',
                'row_classes' => 'ptupro-medium-4 ptupro-columns ptupro-color ptupro-input',
				'desc' =>'Select recurrence color',
            ));
			$main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Features color', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'plan_features_color',
                'type' => 'colorpicker',
	            'default'  => '#555',
                'row_classes' => 'ptupro-medium-4 ptupro-columns ptupro-color ptupro-input',
				'desc' =>'Select features list color',
            ));

            $main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Others', 'pricing-table-ultimate-pro' ),
                'id'   => $prefix . 'styling_desc',
                'type' => 'title',
                'row_classes' => 'ptupro-medium-12 ptupro-columns ptupro-heading',
            ));

            $main_group->add_group_field( $ptupro_pricing_plan_group, array(
                'name' => __( 'Custom CSS classes', 'pricing-table-ultimate-pro' ),
                'id' => $prefix . 'custom_classes',
                'type' => 'text',
				'desc'    => 'Add classes to this plan like my-class another-class',
                'row_classes' => 'ptupro-medium-12 ptupro-columns ptupro-text ptupro-input',
            ));

           

    // Settings
    $side_group = new_cmb2_box( array(
        'id' => $prefix . 'settings_metabox',
        'title' => '<span style="font-weight:bold;">'.__( 'Settings', 'pricing-table-ultimate-pro' ).'</span>',
        'object_types' => array( PTUPRO_POST_TYPE ),
        'context' => 'side',
        'priority' => 'high',
    ));

        $side_group->add_field( array(
            'name' => __( 'General settings', 'pricing-table-ultimate-pro' ),
            'id'   => $prefix . 'other_settings_desc',
            'type' => 'title',
            'row_classes' => 'ptupro-medium-12 ptupro-columns ptupro-heading',
        ));

        $side_group->add_field( array(
            'name'    => __( 'Change currency', 'pricing-table-ultimate-pro' ),
			'id'      => $prefix . 'currency',
			'type'    => 'text',
			'desc'    => 'Add your currency sign here',
            'row_classes' => 'ptupro-medium-12 ptupro-columns ptupro-text_side',
        ));

        $side_group->add_field( array(
            'name'    => __( 'Links behavior', 'pricing-table-ultimate-pro' ),
			'id'      => $prefix . 'open_newwindow',
			'type'    => 'select',
			'options' => array(
			    'currentwindow'   => __( 'Open in current window', 'pricing-table-ultimate-pro' ),
			    'newwindow'   => __( 'Open in new window/tab', 'pricing-table-ultimate-pro' ),

			),
			'default' => 'currentwindow',
            'row_classes' => 'ptupro-medium-12 ptupro-columns ptupro-text_side',
        ));       


        $side_group->add_field( array(
            'name' => '',
                'desc' => '<a id="ptu_font_sett_button" style="margin-top:-10px; cursor:pointer;"><span class="dashicons dashicons-admin-settings"></span> '.__( 'Adjust font sizes', 'pricing-table-ultimate-pro' ).'</a>',
                'id'   => $prefix . 'pro_desc',
                'type' => 'title',
                'row_classes' => 'ptupro-fonts-setting ptupro-info ptupro-info_side',
        ));

        $side_group->add_field( array(
            'name'    => __( 'Title', 'pricing-table-ultimate-pro' ),
			'id'      => $prefix . 'title_fontsize',
			'type'    => 'text',
			'desc'    => 'eg. 18px',               
            'sanitization_cb' => 'ptu_html_allowed_sani_cb',
            'row_classes' => 'ptupro-fonts-setting ptupro-text_side ptu_font_sett',
        ));

        $side_group->add_field( array(
            'name'    => __( 'Subtitle', 'pricing-table-ultimate-pro' ),
			'id'      => $prefix . 'subtitle_fontsize',
			'type'    => 'text',
			'desc'    => 'eg. 18px',               
            'sanitization_cb' => 'ptu_html_allowed_sani_cb',
            'row_classes' => 'ptupro-fonts-setting-sub ptupro-text_side ptu_font_sett',
        ));

        $side_group->add_field( array(
            'name'    => __( 'Description', 'pricing-table-ultimate-pro' ),
			'id'      => $prefix . 'description_fontsize',
			'type'    => 'text',
			'desc'    => 'eg. 18px',               
            'sanitization_cb' => 'ptu_html_allowed_sani_cb',
            'row_classes' => 'ptupro-fonts-setting-sub ptupro-text_side ptu_font_sett',
        ));

        $side_group->add_field( array(
            'name'    => __( 'Price', 'pricing-table-ultimate-pro' ),
			'id'      => $prefix . 'price_fontsize',
			'type'    => 'text',
			'desc'    => 'eg. 40px',               
            'sanitization_cb' => 'ptu_html_allowed_sani_cb',
            'row_classes' => 'ptupro-fonts-setting-sub ptupro-text_side ptu_font_sett',
        ));

        $side_group->add_field( array(
            'name'    => __( 'Recurrence', 'pricing-table-ultimate-pro' ),
			'id'      => $prefix . 'recurrence_fontsize',
			'type'    => 'text',
			'desc'    => 'eg. 18px',               
            'sanitization_cb' => 'ptu_html_allowed_sani_cb',
            'row_classes' => 'ptupro-fonts-setting-sub ptupro-text_side ptu_font_sett',
        ));

        $side_group->add_field( array(
            'name'    => __( 'Fa Icon Size', 'pricing-table-ultimate-pro' ),
			'id'      => $prefix . 'icon_fontsize',
			'type'    => 'text',
            'row_classes' => 'ptupro-fonts-setting-sub ptupro-text_side ptu_font_sett',
			'desc'    => 'eg. 18px',               
            'sanitization_cb' => 'ptu_html_allowed_sani_cb',
        ));

        $side_group->add_field( array(
            'name'    => __( 'Features', 'pricing-table-ultimate-pro' ),
			'id'      => $prefix . 'features_fontsize',
			'type'    => 'text',
			'desc'    => 'eg. 15px',               
            'sanitization_cb' => 'ptu_html_allowed_sani_cb',
            'row_classes' => 'ptupro-fonts-setting-sub ptupro-text_side ptu_font_sett',
        ));
}
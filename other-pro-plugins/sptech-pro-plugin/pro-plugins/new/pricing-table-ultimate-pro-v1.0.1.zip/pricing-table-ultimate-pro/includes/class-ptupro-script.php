<?php
/**
 * Script Class
 * Handles the script and style functionality of plugin
 *
 * @package Pricing Table Ultimate Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Ptupro_Script {

	function __construct() {

		// Action to add script at front side
		add_action( 'wp_enqueue_scripts', array($this, 'ptupro_front_style') );		

		// Action to add style in backend
		add_action( 'admin_enqueue_scripts', array($this, 'ptupro_admin_style') );	
	
		
	}
	
	/**
	 * Function to add style at front side
	 * 
	 * @package Pricing Table Ultimate Pro
	 * @since 1.0.0
	 */
	function ptupro_front_style() {		
		
		// Registring font awesome style
		wp_register_style( 'ptupro-font-awesome', 'https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css', null, PTUPRO_VERSION );
		wp_enqueue_style( 'ptupro-font-awesome' );
		
		// Registring and enqueing button with style pro css
		wp_register_style( 'ptupro-public-style', PTUPRO_URL.'assets/css/ptupro_public_style.css', array(), PTUPRO_VERSION );
		wp_enqueue_style( 'ptupro-public-style' );

	}	
	
	/**
	 * Function to add style at front side
	 * 
	 * @package Pricing Table Ultimate Pro
	 * @since 1.0.0
	 */
	function ptupro_admin_style() {
		global $post_type;
		if( 'ptu_pricing_table' == $post_type ) {
			wp_register_style( 'ptupro-admin-style', PTUPRO_URL.'assets/css/ptupro_admin_style.css', array(), PTUPRO_VERSION );
			wp_enqueue_style( 'ptupro-admin-style' );
			wp_register_script( 'ptupro-admin-script', PTUPRO_URL.'assets/js/ptupro_admin_script.js', array('jquery'), PTUPRO_VERSION, true );
			wp_enqueue_script('ptupro-admin-script');
		}
	}

}

$ptupro_script = new Ptupro_Script();
<?php
/**
 * Plugin generic functions file
 *
 * @package Pricing Table Ultimate Pro
 * @since 1.0.0
 */

 // Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Function to get shortcode col
 * 
 * @package Pricing Table Ultimate Pro
 * @since 1.0.0
 */
add_action( 'manage_ptu_pricing_table_posts_custom_column' , 'ptu_custom_columns', 10, 2 );
add_filter('manage_ptu_pricing_table_posts_columns' , 'add_ptu_pricing_table_columns');
function ptu_custom_columns( $column, $post_id ) {
    switch ( $column ) {
	case 'dk_shortcode' :
		global $post;
		$id = '' ;
		$id = $post->ID;
        $shortcode = '<span style="display:inline-block;border:solid 2px lightgray; background:white; padding:0 8px; font-size:13px; line-height:25px; vertical-align:middle;">[ptu_pricing_table id="'.$id.'"]</span>';
	    echo $shortcode;
	    break;
    }
}
function add_ptu_pricing_table_columns($columns) { return array_merge($columns, array('dk_shortcode' => 'Shortcode'));}


<?php
/**
 * Register Post type functionality 
 * @package Pricing Table Ultimate Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

add_action( 'init', 'ptupro_register_post_type' );
function ptupro_register_post_type() {
	$labels = array(
		'name'               => __( 'Pricing Tables', 'pricing-table-ultimate-pro' ),
		'singular_name'      => __( 'Pricing Table', 'pricing-table-ultimate-pro' ),
		'menu_name'          => __( 'Pricing Tables', 'pricing-table-ultimate-pro' ),
		'name_admin_bar'     => __( 'Pricing Table', 'pricing-table-ultimate-pro' ),
		'add_new'            => __( 'Add New', 'pricing-table-ultimate-pro' ),
		'add_new_item'       => __( 'Add New Pricing Table', 'pricing-table-ultimate-pro' ),
		'new_item'           => __( 'New Pricing Table', 'pricing-table-ultimate-pro' ),
		'edit_item'          => __( 'Edit Pricing Table', 'pricing-table-ultimate-pro' ),
		'view_item'          => __( 'View Pricing Table', 'pricing-table-ultimate-pro' ),
		'all_items'          => __( 'All Pricing Tables', 'pricing-table-ultimate-pro' ),
		'search_items'       => __( 'Search Pricing Tables', 'pricing-table-ultimate-pro' ),
		'not_found'          => __( 'No Pricing Tables found.', 'pricing-table-ultimate-pro' ),
		'not_found_in_trash' => __( 'No Pricing Tables found in Trash.', 'pricing-table-ultimate-pro' )
	);

	$args = array(
		'labels'             => $labels,
		'public'             => false,
		'publicly_queryable' => false,
		'show_ui'            => true,
        'show_in_admin_bar'  => false,
		'capability_type'    => 'post',
		'has_archive'        => false,
		'hierarchical'       => false,
		'supports'           => array( 'title' ),
        'menu_icon'          => 'dashicons-tickets'
	);
	register_post_type( PTUPRO_POST_TYPE, $args );
}


/**
 * Register Customize update messages
 * @package Pricing Table Ultimate Pro
 * @since 1.0.0
 */
 
function ptupro_updated_messages( $messages ) {

	global $post, $post_ID;

	$messages[PTUPRO_POST_TYPE] = array(
		0 => '', // Unused. Messages start at index 1.
		1 => sprintf( __( 'Pricing Table updated.', 'pricing-table-ultimate-pro' ) ),
		2 => __( 'Custom field updated.', 'pricing-table-ultimate-pro' ),
		3 => __( 'Custom field deleted.', 'pricing-table-ultimate-pro' ),
		4 => __( 'Pricing Table updated.', 'pricing-table-ultimate-pro' ),
		5 => isset( $_GET['revision'] ) ? sprintf( __( 'Pricing Table restored to revision from %s', 'pricing-table-ultimate-pro' ), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
		6 => sprintf( __( 'Pricing Table published.', 'pricing-table-ultimate-pro' ) ),
		7 => __( 'Pricing Table saved.', 'pricing-table-ultimate-pro' ),
		8 => sprintf( __( 'Pricing Table submitted.', 'pricing-table-ultimate-pro' ) ),
		9 => sprintf( __( 'Pricing Table scheduled for: <strong>%1$s</strong>.', 'pricing-table-ultimate-pro' ),
		  date_i18n( 'M j, Y @ G:i', strtotime( $post->post_date ) ) ),
		10 => sprintf( __( 'Pricing Table draft updated.', 'pricing-table-ultimate-pro' ) ),
	);	
	return $messages;
}
// Filter to update slider post message
add_filter( 'post_updated_messages', 'ptupro_updated_messages' ); 
 

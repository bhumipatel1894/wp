<?php
/**
 * Plugin Name: Pricing Table Ultimate Pro
 * Plugin URI: https://www.wponlinesupport.com/wp-plugin
 * Description: A responsive, easy and elegant way to present your offer to your visitors. Just create a new pricing table (custom type) and copy-paste the shortcode into your posts/pages.
 * Version: 1.0.1
 * Text Domain: pricing-table-ultimate-pro
 * Domain Path: /languages/
 * Author: WP Online Support
 * Author URI: https://www.wponlinesupport.com
 * Contributors: WP Online Support
 */


if( !defined( 'PTUPRO_VERSION' ) ) {
	define( 'PTUPRO_VERSION', '1.0.1' ); // Version of plugin
}
if( !defined( 'PTUPRO_DIR' ) ) {
    define( 'PTUPRO_DIR', dirname( __FILE__ ) ); // Plugin dir
}
if( !defined( 'PTUPRO_URL' ) ) {
    define( 'PTUPRO_URL', plugin_dir_url( __FILE__ )); // Plugin url
}
if( !defined( 'PTUPRO_PLUGIN_BASENAME' ) ) {
	define( 'PTUPRO_PLUGIN_BASENAME', plugin_basename( __FILE__ ) ); // plugin base name
}
if(!defined( 'PTUPRO_POST_TYPE' ) ) {
	define('PTUPRO_POST_TYPE', 'ptu_pricing_table'); // Plugin post type
}
if(!defined( 'PTUPRO_META_PREFIX' ) ) {
	define('PTUPRO_META_PREFIX','_ptu_'); // Plugin metabox prefix
} 
 

/**
 * Load Text Domain
 * This gets the plugin ready for translation
 * 
 * @package Pricing Table Ultimate Pro
 * @since 1.0.0
 */
function ptupro_pro_load_textdomain() {

    global $wp_version;

    // Set filter for plugin's languages directory
    $ptupro_lang_dir = dirname( plugin_basename( __FILE__ ) ) . '/languages/';
    $ptupro_lang_dir = apply_filters( 'ptupro_languages_directory', $ptupro_lang_dir );

    // Traditional WordPress plugin locale filter.
    $get_locale = get_locale();

    if ( $wp_version >= 4.7 ) {
        $get_locale = get_user_locale();
    }

    // Traditional WordPress plugin locale filter
    $locale = apply_filters( 'plugin_locale',  $get_locale, 'pricing-table-ultimate-pro' );
    $mofile = sprintf( '%1$s-%2$s.mo', 'pricing-table-ultimate-pro', $locale );

    // Setup paths to current locale file
    $mofile_global  = WP_LANG_DIR . '/plugins/' . basename( PTUPRO_DIR ) . '/' . $mofile;

    if ( file_exists( $mofile_global ) ) { // Look in global /wp-content/languages/plugin-name folder
        load_textdomain( 'pricing-table-ultimate-pro', $mofile_global );
    } else { // Load the default language files
        load_plugin_textdomain( 'pricing-table-ultimate-pro', false, $ptupro_lang_dir );
    }
}
add_action('plugins_loaded', 'ptupro_pro_load_textdomain');


/***** Updater Code Starts *****/
define( 'EDD_PTUPRO_STORE_URL', 'https://www.wponlinesupport.com' );
define( 'EDD_PTUPRO_ITEM_NAME', 'Pricing Table Ultimate Pro' );

// Plugin Updator Class
if( !class_exists( 'EDD_SL_Plugin_Updater' ) ) {	
	include( dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php' );
}

/**
 * Updater Function
 * 
 * @package Pricing Table Ultimate Pro
 * @since 1.0.0
 */
function edd_sl_ptupro_plugin_updater() {
	
	$license_key = trim( get_option( 'edd_ptupro_license_key' ) );

	$edd_updater = new EDD_SL_Plugin_Updater( EDD_PTUPRO_STORE_URL, __FILE__, array(
            'version' 	=> PTUPRO_VERSION,      // current version number
            'license' 	=> $license_key,          // license key (used get_option above to retrieve from DB)
            'item_name' => EDD_PTUPRO_ITEM_NAME,    // name of this plugin
            'author' 	=> 'WP Online Support'    // author of this plugin
		)
	);

}
add_action( 'admin_init', 'edd_sl_ptupro_plugin_updater', 0 );
include( dirname( __FILE__ ) . '/edd-ptupro-plugin.php' );
/***** Updater Code Ends *****/
 

// Post Type File
require_once( PTUPRO_DIR . '/includes/ptupro-post-types.php' );

// Script Class File
require_once( PTUPRO_DIR . '/includes/class-ptupro-script.php' );

// Script Class File
require_once( PTUPRO_DIR . '/includes/class-ptupro-script.php' );

// Function File
require_once( PTUPRO_DIR . '/includes/ptupro-functions.php' );

// Shortcode File
require_once( PTUPRO_DIR . '/includes/shortcode/ptupro-shortcode.php' );

// Meta Box
require_once( PTUPRO_DIR . '/includes/admin/metabox/cmb2/init.php' );

require_once( PTUPRO_DIR . '/includes/admin/metabox/ptupro-metaboxes.php' );

// Registering Pricing Table metaboxes
add_action( 'cmb2_init', 'ptupro_register_group_metabox' );
=== Pricing Table Ultimate Pro ===
Contributors: wponlinesupport, anoopranawat
Tags: pricing table, pricing tables, prices, pricing, plans, offer, shortcode, price, responsive, pricing, tables, pricing plan
Requires at least: 3.6
Tested up to: 4.8
Stable tag: trunk
License: GPL2
License URI: http://www.gnu.org/licenses/gpl.html

A responsive and elegant way to present your offer to your visitors. Create a new pricing table now and copy-paste the shortcode anywhere.

== Description ==
This plugin adds a Pricing Tables tab in the admin panel which allows you to create pricing tables for your website the easy way. You can quickly add features to your different plans, choose a color (as well as many other options) and display your price table anywhere with a simple shortcode.

= Available fields =
* Title
* Subtitle
* Description
* Price
* Recurrence ("one-time fee", "per month")
* Small icon
* Features (as many as you want)
* Button URL and text
* Custom buttons (Stripe, Paypal…)
* Custom CSS classes
* Color (per plan)

= Available settings =
* Recommended plan (highlight any plan)
* Remove currency sign (eg. for free plans)
* Change currency sign (€, £, ¥, $…)
* Links behavior (current/new window)
* Font size presets

== Installation ==

= Installation =
1. In your WordPress admin panel, go to Plugins > Add new
2. Upload "pricing-table-ultimate-pro.zip"
3. Activate the plugin

== Changelog ==

= 1.0.1 =
* [+] Added custom class option for each table


= 1.0 =
* Initial release

== Upgrade Notice ==

= 1.0.1 =
* [+] Added custom class option for each table

= 1.0 =
* Initial release

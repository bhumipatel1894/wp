<div class="ptufront-medium-<?php echo $nb_entries; ?> ptufront-table-design-<?php echo $key.' '.$custom_classes; ?> ptufront-columns">
				<div class="ptufront-table-inner" <?php if(!empty($cust_design)) { echo 'style="border:2px solid '.$plan_border_color.';"'; } ?>>
				<?php if (!empty($plans_recommended)) { ?><div class="ptu-price-badge"><?php echo $recommended_text; ?></div>	<?php } ?>		
						<?php if(!empty($plans_title)) { ?>
							<div class="ptu-title" <?php if(!empty($cust_design)) { echo 'style="color:'.$plan_title_color.';background:'.$plan_header_color.';font-size:'.$title_fontsize_set.';"';} ?>><?php echo $plans_title; ?></div>
						<?php }
						 if(!empty($plans_price)) { ?>
						<div class="ptu-price" <?php if(!empty($cust_design)) { echo 'style="color:'.$plan_price_color.';background:'.$plan_price_bgcolor.';font-size:'.$price_fontsize_set.';"'; } ?>>
								<?php if($plans_free == false) { ?>
									<span class="ptu-currency"><?php echo $currency; ?></span> 
									<?php } echo $plans_price;
										if(!empty($plans_recurrence)) { ?>
											<span class="ptu-recurrence" <?php if(!empty($cust_design)) { echo 'style="color:'.$plan_recurrence_color.';font-size:'.$recurrence_fontsize_set.';"'; } ?>> / <?php echo $plans_recurrence; ?></span>
								<?php } ?>
							</div>
								
						 <?php } if(!empty($plans_subtitle)) { ?>
							<div class="ptu-subtitle" <?php if(!empty($cust_design)) { echo 'style="color:'.$plan_subtitle_color.';background:'.$plan_subtitle_bgcolor.';font-size:'.$subtitle_fontsize_set.';"'; } ?>><?php echo $plans_subtitle; ?></div>
						<?php }	 if(!empty($plans_description)) { ?>
							<div class="ptu-description" <?php if(!empty($cust_design)) { echo 'style="color:'.$plan_description_color.';background:'.$plan_subtitle_bgcolor.';font-size:'.$description_fontsize_set.';"'; } ?>><?php echo $plans_description; ?></div>
						<?php } 
						if(!empty($fa_icon || $icon)) { ?>
							<div class="ptu-icon" <?php if(!empty($cust_design)) { echo 'style="background:'.$plan_icon_bgcolor.';"'; } ?>>								
								<?php if(!empty($fa_icon)) { ?>
									<i class="fa <?php echo $fa_icon; ?>" <?php if(!empty($cust_design)) { echo 'style="color:'.$plan_icon_color.';font-size:'.$icon_fontsize_set.';"'; } ?> aria-hidden="true"></i> 
								<?php } else { ?>
								<img src="<?php echo $icon; ?>" alt="" />
								<?php } ?>	
							</div>						
						<?php } ?>					
					
					<?php if(!empty($plans_features)) { ?>
							<div class="ptufront-table-body" <?php if(!empty($cust_design)) { echo 'style="background:'.$plan_body_color.';"'; } ?>>	
								<div class="ptu-features" <?php if(!empty($cust_design)) { echo 'style="color:'.$plan_features_color.';font-size:'.$features_fontsize_set.';"'; } ?>>					
								 <?php $features = array();

											$string = $plans_features;
											$stringAr = explode("\n", $string);
											$stringAr = array_filter($stringAr, 'trim');

											foreach ($stringAr as $feature) {
												$features[] = strip_tags($feature,'<strong></strong><br><br/></br><img><a>');
											}

											foreach ($features as $small_key => $feature){
												if (!empty($feature)){

													$check = substr($feature, 0, 2);
													if ($check == '-n') {
														$feature = substr($feature, 2);
														$check_color = '#bbbbbb';
													} elseif(!empty($cust_design))  {
														$check_color = $plan_features_color;
													} else { 
														$check_color = 'inherit';
													} ?>

													<div style="color:<?php echo $check_color;  if(!empty($cust_design))  { ?> border-bottom:1px solid <?php echo $plan_border_color; } ?>" class="ptu-features-lines ptu-features-lines-<?php echo $key; ?> ptu-features-lines-key-<?php echo $small_key; ?>">
														<?php echo $feature; ?>
													</div>
												<?php
												}
											}
								?>									
								</div>
							</div>
					<?php } 
					if(!empty($plans_btn_text) || !empty($plans_btn_custom_btn)) { ?>
						<div class="ptufront-table-footer" <?php if(!empty($cust_design)) { echo 'style="background:'.$plan_footer_color.';"'; } ?>>	
						<?php if (!empty($plans_btn_custom_btn)) { ?>
							<div class="ptu-button">	<?php echo do_shortcode($plans_btn_custom_btn); ?></div>
						<?php } else { ?>	
							<div class="ptu-button"><a class="ptufront-button <?php echo $plans_btn_class; ?>" href="<?php echo $plans_btn_link; ?>" <?php echo $link_behavior; ?>><?php echo $plans_btn_text; ?></a></div>
						<?php } ?>
						</div>
					<?php } ?>
				</div>
			</div>
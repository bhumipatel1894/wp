jQuery(document).ready(function($){

    $( '.wpssc-swiper-slider' ).each(function( index ) {

		var slider_id	  	= $(this).parent().attr('id');
		var slider_conf 	= $.parseJSON( $(this).closest('.wpssc-slider-wrap').find('.wpssc-slider-conf').text());

		if( typeof(slider_id) != 'undefined' && slider_id != '' ) {

			var swiper = new Swiper('#'+slider_id, {
		        paginationHide		: (slider_conf.pagination) == "true" 			? false 		: true,
		        paginationType 		: slider_conf.pagination_type,
		        autoplay 			: (slider_conf.autoplay) == "true" 				? parseInt(slider_conf.autoplay_speed) : '' ,
		        spaceBetween 		: parseInt(slider_conf.space_between),
		        speed 				: parseInt(slider_conf.speed),
		        loop 				: (slider_conf.loop) == "true" 					? true 			: false,
		        autoplayStopOnLast 	: (slider_conf.auto_stop) == "true" 			? true 			: false,
		        effect 				: slider_conf.animation,
		        height 				: parseInt(slider_conf.vertical_height),
		        direction 			: (slider_conf.direction) == "vertical" 		? 'vertical' 	: 'horizontal',
		        pagination 			: '.swiper-pagination',
		        paginationClickable : true,
		        nextButton			: '.swiper-button-next',
		        prevButton 			: '.swiper-button-prev',
		        autoHeight 			: (slider_conf.autoheight) == "true" 			? true 			: false,
				grabCursor 			: (slider_conf.grab_cursor) == "true" 			? true 			: false,			
				preloadImages		: (slider_conf.lazy_load_slider) == "true" 		? false 		: true,			
				lazyLoading 		: (slider_conf.lazy_load_slider) == "true" 		? true 			: false,	
				
	    	});
	    }
	});

	// For Carousel Slider
	$( '.wpssc-swiper-carousel' ).each(function( index ) {
		
		var slider_id   = $(this).parent().attr('id');
		var slider_conf = $.parseJSON( $(this).closest('.wpssc-carousel-wrap').find('.wpssc-carousel-conf').text());
		
		if( typeof(slider_id) != 'undefined' && slider_id != '' ) {
			
			var swiper = new Swiper('#'+slider_id, {
				slidesPerView 		: parseInt(slider_conf.slide_to_show),
				slidesPerGroup 		: parseInt(slider_conf.slide_to_column),
				centeredSlides		: (slider_conf.centermode) == "true" 			? true 			: false,
				paginationHide 		: (slider_conf.pagination) == "true" 			? false 		: true,
		        paginationType 		: (slider_conf.pagination_type == 'fraction') 	? 'fraction' 	: 'bullets',
		        autoplay 			: (slider_conf.autoplay) == "true" ? parseInt(slider_conf.autoplay_speed) : '' ,
		        spaceBetween 		: parseInt(slider_conf.space_between),
		        speed 				: parseInt(slider_conf.speed),
		        loop				: (slider_conf.loop) == "true" 					? true 			: false,
		        autoplayStopOnLast 	: (slider_conf.auto_stop) == "true" 			? true 			: false,
		        pagination 			: '.swiper-pagination',
		        paginationClickable : true,
		        nextButton 			: '.swiper-button-next',
		        prevButton 			: '.swiper-button-prev',
				slidesPerColumn		: parseInt(slider_conf.slide_per_column_carousel),
				grabCursor 			: (slider_conf.grab_cursor_carousel) == "true" 		? true 			: false,			
				preloadImages		: (slider_conf.lazy_load_slider) == "true" 		? false 		: true,			
				lazyLoading 		: (slider_conf.lazy_load_slider) == "true" 		? true 			: false,							
				
				breakpoints: {
				    // when window width is <= 320px
				    320: {
				      slidesPerView: 1,
				    },
				    // when window width is <= 480px
				    480: {
				      slidesPerView: 1,
				    },
				    // when window width is <= 640px
				    640: {
				      slidesPerView: 3,
				    }
				}
	    	});
		}
	});
	
	
	$( '.wpssc-gallery-top' ).each(function( index ) {
		
		var slider_id	  	= $(this).attr('id');
		var thumb_slider_id	  	= $(this).attr('data-count');		
		var slider_conf 	= $.parseJSON( $(this).closest('.wpssc-thumb-gallery-wrap').find('.wpssc-slider-conf').text());

		if( typeof(slider_id) != 'undefined' && slider_id != '' ) {

			var swiper = new Swiper('#'+slider_id, {
		        paginationHide		: (slider_conf.pagination) == "true" 			? false 		: true,
		        paginationType 		: (slider_conf.pagination_type == 'fraction') 	? 'fraction' 	: 'bullets',
		        autoplay 			: (slider_conf.autoplay) == "true" ? parseInt(slider_conf.autoplay_speed) : '' ,
		        spaceBetween 		: parseInt(slider_conf.space_between),
		        speed 				: parseInt(slider_conf.speed),		        
		        autoplayStopOnLast 	: (slider_conf.auto_stop) == "true" 			? true 			: false,
		        effect 				: slider_conf.animation,		       		       
		        pagination 			: '.swiper-pagination',
		        paginationClickable : true,
		        nextButton			: '.swiper-button-next',
		        prevButton 			: '.swiper-button-prev',
		        autoHeight 			: (slider_conf.autoheight) == "true" 			? true 			: false,
				grabCursor 			: (slider_conf.grab_cursor) == "true" 		? true 			: false,			
				preloadImages		: (slider_conf.lazy_load_slider) == "true" 		? false 		: true,			
				lazyLoading 		: (slider_conf.lazy_load_slider) == "true" 		? true 			: false,				
				
	    	});	
		 var galleryThumbs = new Swiper('#wpssc-gallery-thumbs-'+thumb_slider_id, {
				spaceBetween 		: parseInt(slider_conf.space_between),
				centeredSlides		: true,
				slidesPerView		: 'auto',
				touchRatio			: 0.2,
				autoplay 			: (slider_conf.autoplay) == "true" ? parseInt(slider_conf.autoplay_speed) : '' ,				
				autoplayStopOnLast 	: (slider_conf.auto_stop) == "true" 			? true 			: false,				
				slideToClickedSlide: true
			});
			
			swiper.params.control = galleryThumbs;
			galleryThumbs.params.control = swiper;	
			
	    }
		
		
	});
});
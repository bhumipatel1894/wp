<?php
/**
 * Handles Post Setting metabox HTML
 *
 * @package Swiper Slider and Carousel
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

global $post;

$prefix = WP_SSCPRO_META_PREFIX; // Metabox prefix

$gallery_imgs 	= get_post_meta( $post->ID, $prefix.'gallery_id', true );
$no_img_cls		= !empty($gallery_imgs) ? 'wp-sscpro-hide' : '';
?>

<table class="form-table wp-sscpro-post-sett-table">
	<tbody>
		<tr valign="top">
			<th scope="row">
				<label for="wp-sscpro-gallery-imgs"><?php _e('Choose Gallery Images', 'swiper-slider-and-carousel'); ?></label>
			</th>
			<td>
				<button type="button" class="button button-secondary wp-sscpro-img-uploader" id="wp-sscpro-gallery-imgs" data-multiple="true" data-button-text="<?php _e('Add to Gallery', 'swiper-slider-and-carousel'); ?>" data-title="<?php _e('Add Images to Gallery', 'swiper-slider-and-carousel'); ?>"><i class="dashicons dashicons-format-gallery"></i> <?php _e('Gallery Images', 'swiper-slider-and-carousel'); ?></button>
				<button type="button" class="button button-secondary wp-sscpro-del-gallery-imgs"><i class="dashicons dashicons-trash"></i> <?php _e('Remove Gallery Images', 'swiper-slider-and-carousel'); ?></button><br/>
				
				<div class="wp-sscpro-gallery-imgs-prev wp-sscpro-imgs-preview wp-sscpro-gallery-imgs-wrp">
					<?php if( !empty($gallery_imgs) ) {
						foreach ($gallery_imgs as $img_key => $img_data) {

							$attachment_url 		= wp_get_attachment_thumb_url( $img_data );
							$attachment_edit_link	= get_edit_post_link( $img_data );
					?>
							<div class="wp-sscpro-img-wrp">
								<div class="wp-sscpro-img-tools wp-sscpro-hide">
									<span class="wp-sscpro-tool-icon wp-sscpro-edit-img dashicons dashicons-edit" title="<?php _e('Edit Image in Popup', 'swiper-slider-and-carousel'); ?>"></span>
									<a href="<?php echo $attachment_edit_link; ?>" target="_blank" title="<?php _e('Edit Image', 'swiper-slider-and-carousel'); ?>"><span class="wp-sscpro-tool-icon wp-sscpro-edit-attachment dashicons dashicons-visibility"></span></a>
									<span class="wp-sscpro-tool-icon wp-sscpro-del-tool wp-sscpro-del-img dashicons dashicons-no" title="<?php _e('Remove Image', 'swiper-slider-and-carousel'); ?>"></span>
								</div>
								<img class="wp-sscpro-img" src="<?php echo $attachment_url; ?>" alt="" />
								<input type="hidden" class="wp-sscpro-attachment-no" name="wp_sscpro_img[]" value="<?php echo $img_data; ?>" />
							</div><!-- end .wp-sscpro-img-wrp -->
					<?php }
					} ?>
					
					<p class="wp-sscpro-img-placeholder <?php echo $no_img_cls; ?>"><?php _e('No Gallery Images', 'swiper-slider-and-carousel'); ?></p>

				</div><!-- end .wp-sscpro-imgs-preview -->
				<span class="description"><?php _e('Choose your desired images for gallery. Hold Ctrl key to select multiple images at a time.', 'swiper-slider-and-carousel'); ?></span>
			</td>
		</tr>
	</tbody>
</table><!-- end .wtwp-tstmnl-table -->
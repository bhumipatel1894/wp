<?php
/**
 * Handles Post Setting metabox HTML
 *
 * @package Swiper Slider and Carousel
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

global $post;

$prefix = WP_SSCPRO_META_PREFIX; // Metabox prefix

$style 						= get_post_meta( $post->ID, $prefix.'design_style', true );
$slider_design 				= get_post_meta( $post->ID, $prefix.'slider_design', true );
$show_title 				= get_post_meta( $post->ID, $prefix.'show_title', true );
$show_caption 				= get_post_meta( $post->ID, $prefix.'show_caption', true );

// Slider Variables
$arrow_slider 				= get_post_meta( $post->ID, $prefix.'arrow_slider', true );
$pagination_slider 			= get_post_meta( $post->ID, $prefix.'pagination_slider', true );
$autoplay_slider 			= get_post_meta( $post->ID, $prefix.'autoplay_slider', true );
$autoplay_speed_slider 		= get_post_meta( $post->ID, $prefix.'autoplay_speed_slider', true );
$auto_stop_slider 			= get_post_meta( $post->ID, $prefix.'auto_stop_slider', true );
$speed_slider 				= get_post_meta( $post->ID, $prefix.'speed_slider', true );
$animation_slider 			= get_post_meta( $post->ID, $prefix.'animation_slider', true );
$height_slider 				= get_post_meta( $post->ID, $prefix.'height_slider', true );
$autoheight_slider 			= get_post_meta( $post->ID, $prefix.'autoheight_slider', true );
$direction_slider 			= get_post_meta( $post->ID, $prefix.'direction_slider', true );
$pagination_type_slider 	= get_post_meta( $post->ID, $prefix.'pagination_type_slider', true );
$space_between_slider 		= get_post_meta( $post->ID, $prefix.'space_between_slider', true );
$loop_slider 				= get_post_meta( $post->ID, $prefix.'loop_slider', true );
$lazy_load_slider 			= get_post_meta( $post->ID, $prefix.'lazy_load_slider', true );
$grab_cursor 				= get_post_meta( $post->ID, $prefix.'grab_cursor', true );
$nav_type 					= get_post_meta( $post->ID, $prefix.'nav_type', true );

// Carousel Variables 
$slide_to_show_carousel 	= get_post_meta( $post->ID, $prefix.'slide_to_show_carousel', true );
$slide_to_column_carousel 	= get_post_meta( $post->ID, $prefix.'slide_to_column_carousel', true );
$slide_per_column_carousel 	= get_post_meta( $post->ID, $prefix.'slide_per_column_carousel', true );
$arrow_carousel 			= get_post_meta( $post->ID, $prefix.'arrow_carousel', true );
$pagination_carousel 		= get_post_meta( $post->ID, $prefix.'pagination_carousel', true );
$speed_carousel 			= get_post_meta( $post->ID, $prefix.'speed_carousel', true );
$autoplay_carousel 			= get_post_meta( $post->ID, $prefix.'autoplay_carousel', true );
$autoplay_speed_carousel	= get_post_meta( $post->ID, $prefix.'autoplay_speed_carousel', true );
$auto_stop_carousel 		= get_post_meta( $post->ID, $prefix.'auto_stop_carousel', true );
$pagination_type_carousel 	= get_post_meta( $post->ID, $prefix.'pagination_type_carousel', true );
$space_between_carousel 	= get_post_meta( $post->ID, $prefix.'space_between_carousel', true );
$centermode_carousel 		= get_post_meta( $post->ID, $prefix.'centermode_carousel', true );
$loop_carousel 				= get_post_meta( $post->ID, $prefix.'loop_carousel', true );
$lazy_load_carousel 		= get_post_meta( $post->ID, $prefix.'lazy_load_carousel', true );
$grab_cursor_carousel 		= get_post_meta( $post->ID, $prefix.'grab_cursor_carousel', true );
$nav_type_carousel 			= get_post_meta( $post->ID, $prefix.'nav_type_carousel', true );

// thumb Slider Variables
$arrow_thumb_slider 				= get_post_meta( $post->ID, $prefix.'arrow_thumb_slider', true );
$pagination_thumb_slider 			= get_post_meta( $post->ID, $prefix.'pagination_thumb_slider', true );
$autoplay_thumb_slider 				= get_post_meta( $post->ID, $prefix.'autoplay_thumb_slider', true );
$autoplay_thumb_speed_slider 		= get_post_meta( $post->ID, $prefix.'autoplay_thumb_speed_slider', true );
$auto_thumb_stop_slider 			= get_post_meta( $post->ID, $prefix.'auto_thumb_stop_slider', true );
$speed_thumb_slider 				= get_post_meta( $post->ID, $prefix.'speed_thumb_slider', true );
$animation_thumb_slider 			= get_post_meta( $post->ID, $prefix.'animation_thumb_slider', true );
$height_thumb_slider 				= get_post_meta( $post->ID, $prefix.'height_thumb_slider', true );
$autoheight_thumb_slider 			= get_post_meta( $post->ID, $prefix.'autoheight_thumb_slider', true );
$pagination_thumb_type_slider 		= get_post_meta( $post->ID, $prefix.'pagination_thumb_type_slider', true );
$space_thumb_between_slider 		= get_post_meta( $post->ID, $prefix.'space_thumb_between_slider', true );
$lazy_load_thumb 					= get_post_meta( $post->ID, $prefix.'lazy_load_thumb', true );
$grab_cursor_thumb 					= get_post_meta( $post->ID, $prefix.'grab_cursor_thumb', true );
$nav_type_thumb 					= get_post_meta( $post->ID, $prefix.'nav_type_thumb', true );

?>

<div class="wp-tsasp-mb-tabs-wrp">
	<table class="form-table wp-tsasp-mdetails wp-tsasp-tab-cnt">
		<tr valign="top">
			<th scope="row">
				<label><?php _e('Select Slider Type', 'swiper-slider-and-carousel'); ?></label>				
			</th>
			<td scope="row">
				<select name="<?php echo $prefix; ?>design_style" class="wpssc-choose-design">
					<option value="">Select Type</option>
					<option value="slider" <?php selected( $style, 'slider'); ?>>Slider</option>
					<option value="carousel" <?php selected( $style, 'carousel'); ?>>Carousel</option>
					<option value="thumbs_gallery" <?php selected( $style, 'thumbs_gallery'); ?>>Thumbs Gallery</option>
				</select>
			</td>
			
		</tr>
		<tr valign="top">
					<td scope="row">
						<label><?php _e('Select Design', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<select name="<?php echo $prefix; ?>slider_design">
							<option value="design-1" <?php selected( $slider_design, 'design-1'); ?>>Design-1</option>
							<option value="design-2" <?php selected( $slider_design, 'design-2'); ?>>Design-2</option>
							<option value="design-3" <?php selected( $slider_design, 'design-3'); ?>>Design-3</option>
							<option value="design-4" <?php selected( $slider_design, 'design-4'); ?>>Design-4</option>
							<option value="design-5" <?php selected( $slider_design, 'design-5'); ?>>Design-5</option>
							<option value="design-6" <?php selected( $slider_design, 'design-6'); ?>>Design-6</option>
							<option value="design-7" <?php selected( $slider_design, 'design-7'); ?>>Design-7</option>
							<option value="design-8" <?php selected( $slider_design, 'design-8'); ?>>Design-8</option>
							<option value="design-9" <?php selected( $slider_design, 'design-9'); ?>>Design-9</option>
							<option value="design-10" <?php selected( $slider_design, 'design-10'); ?>>Design-10</option>							
						</select><br/>
						<span class="description"><?php _e('Select design to display','swiper-slider-and-carousel'); ?></span>
					</td>
		</tr>
		<tr valign="top">
					<td scope="row">
						<label><?php _e('Show Title', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="radio" name="<?php echo $prefix; ?>show_title" value="true" <?php checked( 'true', $show_title ); ?>>True
						<input type="radio" name="<?php echo $prefix; ?>show_title" value="false" <?php checked( 'false', $show_title ); ?>>False<br>
						<span class="description"><?php _e('Show slider title or not. By default value is false','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
			<tr valign="top">
					<td scope="row">
						<label><?php _e('Show Caption', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="radio" name="<?php echo $prefix; ?>show_caption" value="true" <?php checked( 'true', $show_caption ); ?>>True
						<input type="radio" name="<?php echo $prefix; ?>show_caption" value="false" <?php checked( 'false', $show_caption ); ?>>False<br>
						<span class="description"><?php _e('Show caption  or not. By default value is false','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>	
	</table>
	<!-- Slider Setting -->
	<div id="wp-tsasp-mdetails" class="wp-tsasp-mdetails wpssc-slider" style="<?php if($style == 'carousel' || $style == 'thumbs_gallery' || $style == '') { echo 'display:none';  } ?>">
		<table class="form-table wp-tsasp-team-detail-tbl">
			<h3><?php _e('Slider Settings', 'swiper-slider-and-carousel') ?></h3>
			<hr>
			<tbody>
				<tr valign="top">
					<h4><?php _e('Navigation & Pagination Settings', 'swiper-slider-and-carousel') ?></h4>
					<hr>
					<td scope="row">
						<label><?php _e('Arrow', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="radio" value="true" name="<?php echo $prefix; ?>arrow_slider" <?php checked( 'true', $arrow_slider ); ?>>True
						<input type="radio" value="false" name="<?php echo $prefix; ?>arrow_slider" <?php checked( 'false', $arrow_slider ); ?>>False<br>
						<span class="description"><?php _e('Enable Arrows for slider','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				<tr valign="top">
					<td scope="row">
						<label><?php _e('Pagination', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="radio" name="<?php echo $prefix; ?>pagination_slider" value="true" <?php checked( 'true', $pagination_slider ); ?>>True
						<input type="radio" name="<?php echo $prefix; ?>pagination_slider" value="false" <?php checked( 'false', $pagination_slider ); ?>>False<br>
						<span class="description"><?php _e('String with CSS selector or HTML elspanent of the container with pagination','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				<tr valign="top">
					<td scope="row">
						<label><?php _e('Pagination Type', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<select name="<?php echo $prefix; ?>pagination_type_slider">
							<option value="bullets" <?php selected( $pagination_type_slider, 'bullets'); ?>>Bullets</option>
							<option value="fraction" <?php selected( $pagination_type_slider, 'fraction'); ?>>Fraction</option>
							<option value="progress" <?php selected( $pagination_type_slider, 'progress'); ?>>Progress</option>
						</select><br/>
						<span class="description"><?php _e('String with type of pagination. Can be "bullets", "fraction"','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				<tr valign="top">
					<td scope="row">
						<label><?php _e('Navigation Type', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<select name="<?php echo $prefix; ?>nav_type">							
							<option value="blue" <?php selected( $nav_type, 'blue'); ?>>Blue</option>
							<option value="light" <?php selected( $nav_type, 'light'); ?>>Light</option>
							<option value="black" <?php selected( $nav_type, 'black'); ?>>Black</option>	
						</select><br/>
						<span class="description"><?php _e('Select navigation thspane ie light or dark.','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
			</tbody>
		</table>
		<table class="form-table wp-tsasp-team-detail-tbl">
			<tbody>
				<tr valign="top">
					<h4><?php _e('General Settings', 'swiper-slider-and-carousel') ?></h4>
					<hr>
					<td scope="row">
						<label><?php _e('Autoplay', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="radio" name="<?php echo $prefix; ?>autoplay_slider" value="true" <?php checked( 'true', $autoplay_slider ); ?>>True
						<input type="radio" name="<?php echo $prefix; ?>autoplay_slider"  value="false" <?php checked( 'false', $autoplay_slider ); ?>>False<br/>
						<span class="description"><?php _e('Enable Autoplay for Slider','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				<tr valign="top">
					<td scope="row">
						<label><?php _e('Autoplay Speed', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="number"  name="<?php echo $prefix; ?>autoplay_speed_slider" placeholder="5000" value="<?php echo wp_sscpro_esc_attr($autoplay_speed_slider); ?>"><br/>
						<span class="description"><?php _e('Delay between transitions (in ms). If this parameter is not specified, auto play will be disabled','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				<tr valign="top">
					<td scope="row">
						<label><?php _e('Space Between Slides', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="number"  name="<?php echo $prefix; ?>space_between_slider"  placeholder="10" value="<?php echo wp_sscpro_esc_attr($space_between_slider); ?>"><br/>
						<span class="description"><?php _e('Distance between slides in px.','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				<tr valign="top">
					<td scope="row">
						<label><?php _e('Speed', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="number"  name="<?php echo $prefix; ?>speed_slider" placeholder="5000" value="<?php echo wp_sscpro_esc_attr($speed_slider); ?>"><br/>
						<span class="description"><?php _e('Duration of transition between slides (in ms)','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				<tr valign="top">
					<td scope="row">
						<label><?php _e('Loop', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="radio" name="<?php echo $prefix; ?>loop_slider" value="true" <?php checked( 'true', $loop_slider ); ?>>True
						<input type="radio" name="<?php echo $prefix; ?>loop_slider" value="false" <?php checked( 'false', $loop_slider ); ?>>False<br/>
						<span class="description"><?php _e('Set to true to enable continuous loop mode','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				<tr valign="top">
					<td scope="row">
						<label><?php _e('Autoplay Stop On Last', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="radio" name="<?php echo $prefix; ?>auto_stop_slider" value="true" <?php checked( 'true', $auto_stop_slider ); ?>>True
						<input type="radio" name="<?php echo $prefix; ?>auto_stop_slider" value="false" <?php checked( 'false', $auto_stop_slider ); ?>>False<br/>
						<span class="description"><?php _e('Enable this parameter and autoplay will be stopped when it reaches last slide','swiper-slider-and-carousel'); ?></span><br/>
						<span class="description" style="color:#ff0808;"><?php _e('This will work when loop is false.','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
			</tbody>
		</table>		
		
		<table class="form-table wp-tsasp-team-detail-tbl">
			<tbody>
				<tr valign="top">
					<h4><?php _e('lazyLoading Settings', 'swiper-slider-and-carousel') ?></h4>
					<hr>
					<td scope="row">
						<label><?php _e('lazyLoading', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
					<input type="radio" name="<?php echo $prefix; ?>lazy_load_slider" value="true" <?php checked( 'true', $lazy_load_slider ); ?>>True
						<input type="radio" name="<?php echo $prefix; ?>lazy_load_slider" value="false" <?php checked( 'false', $lazy_load_slider ); ?>>False<br/>						
						<span class="description"><?php _e('Set to "true" to enable images lazy loading. By default value is FALSE','swiper-slider-and-carousel'); ?></span><br />
						<span class="description" style="color:#ff0808;"><?php _e('lazyLoading is only work with AutoHeight="false"','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				
				
			</tbody>
		</table><!-- end .wtwp-tstmnl-table -->	
		<table class="form-table wp-tsasp-team-detail-tbl">
			<tbody>
				<tr valign="top">
					<h4><?php _e('Effect Settings', 'swiper-slider-and-carousel') ?></h4>
					<hr>
					<td scope="row">
						<label><?php _e('Effect', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<select name="<?php echo $prefix; ?>animation_slider">
							<option value="slide" <?php if($animation_slider == 'slide'){echo 'selected'; } ?>>Slide</option>
							<option value="fade" <?php if($animation_slider == 'fade'){echo 'selected'; } ?>>Fade</option>
							<option value="flip" <?php if($animation_slider == 'flip'){echo 'selected'; } ?>>flip</option>							
							<option value="cube" <?php if($animation_slider == 'cube'){echo 'selected'; } ?>>cube</option>
						</select><br/>
						<span class="description"><?php _e('Could be "slide", "fade", "flip"','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				
				
			</tbody>
		</table><!-- end .wtwp-tstmnl-table -->	
		<table class="form-table wp-tsasp-team-detail-tbl">
			<tbody>
				<tr valign="top">
					<h4><?php _e('Direction Settings', 'swiper-slider-and-carousel') ?></h4>
					<hr>
					<td scope="row">
						<label><?php _e('Direction', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="radio" name="<?php echo $prefix; ?>direction_slider" value="horizontal" <?php checked( 'horizontal', $direction_slider ); ?>>Horizontal
						<input type="radio" name="<?php echo $prefix; ?>direction_slider" value="vertical" <?php checked( 'vertical', $direction_slider ); ?>>Vertical<br/>
						<span class="description"><?php _e('Could be "horizontal" or "vertical" (for vertical slider).','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				
				
			</tbody>
		</table><!-- end .wtwp-tstmnl-table -->	
		
		<table class="form-table wp-tsasp-team-detail-tbl">
			<tbody>
				<tr valign="top">
					<h4><?php _e('Other Settings', 'swiper-slider-and-carousel') ?></h4>
					<hr>					
				</tr>
				<tr valign="top">
					<td scope="row">
						<label><?php _e('AutoHeight', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="radio" name="<?php echo $prefix; ?>autoheight_slider" value="true" <?php checked( 'true', $autoheight_slider ); ?>>True
						<input type="radio" name="<?php echo $prefix; ?>autoheight_slider" value="false" <?php checked( 'false', $autoheight_slider ); ?>>False<br/>
						<span class="description"><?php _e('Set to true and slider wrapper will adopt its height to the height of the currently active slide','swiper-slider-and-carousel'); ?></span><br/>
						<span class="description" style="color:#ff0808;"><?php _e('Set this parameter false if you want to use HEIGHT for slider.','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				
				<tr valign="top">
					<td scope="row">
						<label><?php _e('Height', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="number"  class="wp-igsp-slider" name="<?php echo $prefix; ?>height_slider" placeholder="400" value="<?php echo wp_sscpro_esc_attr($height_slider); ?>">px<br/>
						<span class="description"><?php _e('Swiper height (in px). Parameter allows to force Swiper height. Useful only if you initialize Swiper when it is hidden.','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				<tr valign="top">
					<td scope="row">
						<label><?php _e('Grab Cursor', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="radio" name="<?php echo $prefix; ?>grab_cursor" value="true" <?php checked( 'true', $grab_cursor ); ?>>True
						<input type="radio" name="<?php echo $prefix; ?>grab_cursor" value="false" <?php checked( 'false', $grab_cursor ); ?>>False<br/>
						<span class="description"><?php _e('This option may a little improve desktop usability. If true, user will see the "grab" cursor when hover on Swiper','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
			</tbody>
		</table><!-- end .wtwp-tstmnl-table -->
	</div>

	<div id="wp-tsasp-sdetails" class="wp-tsasp-sdetails wp-tsasp-tab-cnt wpssc-carousel" style="<?php if($style == 'slider' || $style == 'thumbs_gallery' || $style == '' ){ echo 'display:none';  } ?>">
		<table class="form-table wp-tsasp-sdetails-tbl">
		<h3><?php _e('Carousel Settings', 'swiper-slider-and-carousel') ?></h3>
		<hr>	
			<tbody>
				<tr valign="top">
					<h4><?php _e('Carousel Settings', 'swiper-slider-and-carousel') ?></h4>
					<hr>
					<td scope="row">
						<label><?php _e('Slide To Show', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
					<input type="number" min="1" step="1" name="<?php echo $prefix; ?>slide_to_show_carousel" placeholder="3" value="<?php echo wp_sscpro_esc_attr($slide_to_show_carousel); ?>"><br/>
					<span class="description"><?php _e('Number of slides per view (slides visible at the same time on slider container).','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>

				<tr valign="top">
					<td scope="row">
						<label><?php _e('Slide To Scroll', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="number" min="1" step="1" name="<?php echo $prefix; ?>slide_to_column_carousel" placeholder="1" value="<?php echo wp_sscpro_esc_attr($slide_to_column_carousel); ?>"><br/>
						<span class="description"><?php _e('Set numbers of slides to define and enable group sliding. Useful to use with slidesPerView > 1','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				
				<tr valign="top">
					<td scope="row">
						<label><?php _e('Slides Per Column', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="number" min="1" step="1" name="<?php echo $prefix; ?>slide_per_column_carousel" placeholder="1" value="<?php echo wp_sscpro_esc_attr($slide_per_column_carousel); ?>"><br/>
						<span class="description"><?php _e('Number of slides per column, for multirow layout','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>

				<tr valign="top">
					<td scope="row">
						<label><?php _e('Center Mode', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="radio" name="<?php echo $prefix; ?>centermode_carousel" value="true" <?php checked( 'true', $centermode_carousel ); ?>>True
						<input type="radio" name="<?php echo $prefix; ?>centermode_carousel" value="false" <?php checked( 'false', $centermode_carousel ); ?>>False<br/>
						<span class="description"><?php _e('If true, then active slide will be centered, not always on the left side.','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>

				<tr valign="top">
					<td scope="row">
						<label><?php _e('Space Between Slides', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="number" name="<?php echo $prefix; ?>space_between_carousel" placeholder="10" value="<?php echo wp_sscpro_esc_attr($space_between_carousel); ?>"><br/>
						<span class="description"><?php _e('Distance between slides in px.','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
			</tbody>
		</table>
		<table class="form-table wp-tsasp-sdetails-tbl">
			<tbody>
				<tr valign="top">
					<h4><?php _e('Navigation & Pagination Settings', 'swiper-slider-and-carousel') ?></h4>
					<hr>
					<td scope="row">
						<label><?php _e('Arrow', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="radio" name="<?php echo $prefix; ?>arrow_carousel" value="true" <?php checked( 'true', $arrow_carousel ); ?>>True
						<input type="radio" name="<?php echo $prefix; ?>arrow_carousel" value="false" <?php checked( 'false', $arrow_carousel ); ?>>False<br/>
						<span class="description"><?php _e('Enable Arrows for slider','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>

				<tr valign="top">
					<td scope="row">
						<label><?php _e('Pagination', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="radio" name="<?php echo $prefix; ?>pagination_carousel" value="true" <?php checked( 'true', $pagination_carousel ); ?>>True
						<input type="radio" name="<?php echo $prefix; ?>pagination_carousel" value="false" <?php checked( 'false', $pagination_carousel ); ?>>False<br/>
						<span class="description"><?php _e('String with CSS selector or HTML elspanent of the container with pagination','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				<tr valign="top">
					<td scope="row">
						<label><?php _e('Pagination Type', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<select name="<?php echo $prefix; ?>pagination_type_carousel">
							<option value="bullets" <?php selected( $pagination_type_carousel, 'bullets'); ?>>Bullets</option>
							<option value="fraction" <?php selected( $pagination_type_carousel, 'fraction'); ?>>Fraction</option>
							<option value="progress" <?php selected( $pagination_type_carousel, 'progress'); ?>>Progress</option>
						</select><br/>
						<span class="description"><?php _e('String with type of pagination. Can be "bullets", "fraction"','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>				
				<tr valign="top">
					<td scope="row">
						<label><?php _e('Navigation Type', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<select name="<?php echo $prefix; ?>nav_type_carousel">							
							<option value="blue" <?php selected( $nav_type_carousel, 'blue'); ?>>Blue</option>
							<option value="light" <?php selected( $nav_type_carousel, 'light'); ?>>Light</option>
							<option value="black" <?php selected( $nav_type_carousel, 'black'); ?>>Black</option>	
						</select><br/>
						<span class="description"><?php _e('Select navigation thspane ie light or dark.','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
			</tbody>
		</table>
		<table class="form-table wp-tsasp-team-detail-tbl">
			<tbody>
				<tr valign="top">
					<h4><?php _e('lazyLoading Settings', 'swiper-slider-and-carousel') ?></h4>
					<hr>
					<td scope="row">
						<label><?php _e('lazyLoading', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
					<input type="radio" name="<?php echo $prefix; ?>lazy_load_carousel" value="true" <?php checked( 'true', $lazy_load_carousel ); ?>>True
						<input type="radio" name="<?php echo $prefix; ?>lazy_load_carousel" value="false" <?php checked( 'false', $lazy_load_carousel ); ?>>False<br/>						
						<span class="description"><?php _e('Set to "true" to enable images lazy loading. By default value is FALSE','swiper-slider-and-carousel'); ?></span>
						
					</td>
				</tr>
				
				
			</tbody>
		</table><!-- end .wtwp-tstmnl-table -->	
		<table class="form-table wp-tsasp-sdetails-tbl">
			<tbody>
				<tr valign="top">
					<h4><?php _e('Genaral Settings', 'swiper-slider-and-carousel') ?></h4>
					<hr>
					<td scope="row">
						<label><?php _e('Autoplay', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="radio" name="<?php echo $prefix; ?>autoplay_carousel" value="true" <?php checked( 'true', $autoplay_carousel ); ?>>True
						<input type="radio" name="<?php echo $prefix; ?>autoplay_carousel"  value="false" <?php checked( 'false', $autoplay_carousel ); ?>>False<br/>
						<span class="description"><?php _e('Enable Autoplay for Slider','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>

				<tr valign="top">
					<td scope="row">
						<label><?php _e('Autoplay Speed', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="number"  name="<?php echo $prefix; ?>autoplay_speed_carousel"  placeholder="5000" value="<?php echo wp_sscpro_esc_attr($autoplay_speed_carousel); ?>"><br/>
						<span class="description"><?php _e('Delay between transitions (in ms). If this parameter is not specified, auto play will be disabled','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				<tr valign="top">
					<td scope="row">
						<label><?php _e('Speed', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="number"  name="<?php echo $prefix; ?>speed_carousel" placeholder="3000" value="<?php echo wp_sscpro_esc_attr($speed_carousel); ?>"><br/>
						<span class="description"><?php _e('Duration of transition between slides (in ms)','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				<tr valign="top">
					<td scope="row">
						<label><?php _e('Loop', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="radio" name="<?php echo $prefix; ?>loop_carousel" value="true" <?php checked( 'true', $loop_carousel ); ?>>True
						<input type="radio" name="<?php echo $prefix; ?>loop_carousel" value="false" <?php checked( 'false', $loop_carousel ); ?>>False<br/>
						<span class="description"><?php _e('Set to true to enable continuous loop mode','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				<tr valign="top">
					<td scope="row">
						<label><?php _e('Autoplay Stop On Last', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="radio" name="<?php echo $prefix; ?>auto_stop_carousel" value="true" <?php checked( 'true', $auto_stop_carousel ); ?>>True
						<input type="radio" name="<?php echo $prefix; ?>auto_stop_carousel" value="false" <?php checked( 'false', $auto_stop_carousel ); ?>>False<br/>
						<span class="description"><?php _e('Enable this parameter and autoplay will be stopped when it reaches last slide','swiper-slider-and-carousel'); ?></span><br/>
						<span class="description" style="color:#ff0808;"><?php _e('This will work when loop is false.','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				<tr valign="top">
					<td scope="row">
						<label><?php _e('Grab Cursor', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="radio" name="<?php echo $prefix; ?>grab_cursor_carousel" value="true" <?php checked( 'true', $grab_cursor_carousel ); ?>>True
						<input type="radio" name="<?php echo $prefix; ?>grab_cursor_carousel" value="false" <?php checked( 'false', $grab_cursor_carousel ); ?>>False<br/>
						<span class="description"><?php _e('This option may a little improve desktop usability. If true, user will see the "grab" cursor when hover on Swiper','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
			</tbody>
		</table><!-- end .wtwp-tstmnl-table -->
	</div>
	
	<div id="wp-tsasp-mdetails" class="wp-tsasp-mdetails wpssc-thumbs-gallery " style="<?php if($style == 'slider' || $style == 'carousel' || $style == '' ){ echo 'display:none';  } ?>">
		<table class="form-table wp-tsasp-team-detail-tbl">
			<h3><?php _e('Thumbs Gallery Settings', 'swiper-slider-and-carousel') ?></h3>
			<hr>
			<tbody>
				<tr valign="top">
					<h4><?php _e('Navigation & Pagination Settings', 'swiper-slider-and-carousel') ?></h4>
					<hr>
					<td scope="row">
						<label><?php _e('Arrow', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="radio" value="true" name="<?php echo $prefix; ?>arrow_thumb_slider" <?php checked( 'true', $arrow_thumb_slider ); ?>>True
						<input type="radio" value="false" name="<?php echo $prefix; ?>arrow_thumb_slider" <?php checked( 'false', $arrow_thumb_slider ); ?>>False<br>
						<span class="description"><?php _e('Enable Arrows for slider','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				<tr valign="top">
					<td scope="row">
						<label><?php _e('Pagination', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="radio" name="<?php echo $prefix; ?>pagination_thumb_slider" value="true" <?php checked( 'true', $pagination_thumb_slider ); ?>>True
						<input type="radio" name="<?php echo $prefix; ?>pagination_thumb_slider" value="false" <?php checked( 'false', $pagination_thumb_slider ); ?>>False<br>
						<span class="description"><?php _e('String with CSS selector or HTML elspanent of the container with pagination','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				<tr valign="top">
					<td scope="row">
						<label><?php _e('Pagination Type', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<select name="<?php echo $prefix; ?>pagination_thumb_type_slider">
							<option value="bullets" <?php selected( $pagination_thumb_type_slider, 'bullets'); ?>>Bullets</option>
							<option value="fraction" <?php selected( $pagination_thumb_type_slider, 'fraction'); ?>>Fraction</option>
							<option value="progress" <?php selected( $pagination_thumb_type_slider, 'progress'); ?>>Progress</option>
						</select><br/>
						<span class="description"><?php _e('String with type of pagination. Can be "bullets", "fraction"','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				<tr valign="top">
					<td scope="row">
						<label><?php _e('Navigation Type', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<select name="<?php echo $prefix; ?>nav_type_thumb">							
							<option value="blue" <?php selected( $nav_type_thumb, 'blue'); ?>>Blue</option>
							<option value="light" <?php selected( $nav_type_thumb, 'light'); ?>>Light</option>
							<option value="black" <?php selected( $nav_type_thumb, 'black'); ?>>Black</option>	
						</select><br/>
						<span class="description"><?php _e('Select navigation thspane ie light or dark.','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
			</tbody>
		</table>
		<table class="form-table wp-tsasp-team-detail-tbl">
			<tbody>
				<tr valign="top">
					<h4><?php _e('General Settings', 'swiper-slider-and-carousel') ?></h4>
					<hr>
					<td scope="row">
						<label><?php _e('Autoplay', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="radio" name="<?php echo $prefix; ?>autoplay_thumb_slider" value="true" <?php checked( 'true', $autoplay_thumb_slider ); ?>>True
						<input type="radio" name="<?php echo $prefix; ?>autoplay_thumb_slider"  value="false" <?php checked( 'false', $autoplay_thumb_slider ); ?>>False<br/>
						<span class="description"><?php _e('Enable Autoplay for Slider','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				<tr valign="top">
					<td scope="row">
						<label><?php _e('Autoplay Speed', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="number" name="<?php echo $prefix; ?>autoplay_thumb_speed_slider" placeholder="5000" value="<?php echo wp_sscpro_esc_attr($autoplay_thumb_speed_slider); ?>"><br/>
						<span class="description"><?php _e('Delay between transitions (in ms). If this parameter is not specified, auto play will be disabled','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				<tr valign="top">
					<td scope="row">
						<label><?php _e('Space Between Slides', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="number"  name="<?php echo $prefix; ?>space_thumb_between_slider"  placeholder="10" value="<?php echo wp_sscpro_esc_attr($space_thumb_between_slider); ?>"><br/>
						<span class="description"><?php _e('Distance between slides in px.','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				<tr valign="top">
					<td scope="row">
						<label><?php _e('Speed', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="number"  name="<?php echo $prefix; ?>speed_thumb_slider" placeholder="5000" value="<?php echo wp_sscpro_esc_attr($speed_thumb_slider); ?>"><br/>
						<span class="description"><?php _e('Duration of transition between slides (in ms)','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				
				<tr valign="top">
					<td scope="row">
						<label><?php _e('Autoplay Stop On Last', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="radio" name="<?php echo $prefix; ?>auto_thumb_stop_slider" value="true" <?php checked( 'true', $auto_stop_slider ); ?>>True
						<input type="radio" name="<?php echo $prefix; ?>auto_thumb_stop_slider" value="false" <?php checked( 'false', $auto_stop_slider ); ?>>False<br/>
						<span class="description"><?php _e('Enable this parameter and autoplay will be stopped when it reaches last slide','swiper-slider-and-carousel'); ?></span><br/>
						
					</td>
				</tr>
			</tbody>
		</table>
		<table class="form-table wp-tsasp-team-detail-tbl">
			<tbody>
				<tr valign="top">
					<h4><?php _e('lazyLoading Settings', 'swiper-slider-and-carousel') ?></h4>
					<hr>
					<td scope="row">
						<label><?php _e('lazyLoading', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
					<input type="radio" name="<?php echo $prefix; ?>lazy_load_thumb" value="true" <?php checked( 'true', $lazy_load_thumb ); ?>>True
						<input type="radio" name="<?php echo $prefix; ?>lazy_load_thumb" value="false" <?php checked( 'false', $lazy_load_thumb ); ?>>False<br/>						
						<span class="description"><?php _e('Set to "true" to enable images lazy loading. By default value is FALSE','swiper-slider-and-carousel'); ?></span>
						
					</td>
				</tr>
				
				
			</tbody>
		</table><!-- end .wtwp-tstmnl-table -->	
		<table class="form-table wp-tsasp-team-detail-tbl">
			<tbody>
				<tr valign="top">
					<h4><?php _e('Effect Settings', 'swiper-slider-and-carousel') ?></h4>
					<hr>
					<td scope="row">
						<label><?php _e('Effect', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<select name="<?php echo $prefix; ?>animation_thumb_slider">
							<option value="slide" <?php if($animation_thumb_slider == 'slide'){echo 'selected'; } ?>>Slide</option>
							<option value="fade" <?php if($animation_thumb_slider == 'fade'){echo 'selected'; } ?>>Fade</option>
							<option value="flip" <?php if($animation_thumb_slider == 'flip'){echo 'selected'; } ?>>flip</option>							
							<option value="cube" <?php if($animation_thumb_slider == 'cube'){echo 'selected'; } ?>>cube</option>
						</select><br/>
						<span class="description"><?php _e('Could be "slide", "fade", "flip"','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				
				
			</tbody>
		</table><!-- end .wtwp-tstmnl-table -->	
		<table class="form-table wp-tsasp-team-detail-tbl">
			<tbody>
				<tr valign="top">
					<h4><?php _e('Other Settings', 'swiper-slider-and-carousel') ?></h4>
					<hr>					
				</tr>				
				
				<tr valign="top">
					<td scope="row">
						<label><?php _e('Height', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="number"  class="wp-igsp-slider" name="<?php echo $prefix; ?>height_thumb_slider" placeholder="400" value="<?php echo wp_sscpro_esc_attr($height_thumb_slider); ?>">px<br/>
						<span class="description"><?php _e('Swiper height (in px). Parameter allows to force Swiper height. Useful only if you initialize Swiper when it is hidden.','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
				<tr valign="top">
					<td scope="row">
						<label><?php _e('Grab Cursor', 'swiper-slider-and-carousel'); ?></label>
					</td>
					<td>
						<input type="radio" name="<?php echo $prefix; ?>grab_cursor_thumb" value="true" <?php checked( 'true', $grab_cursor_thumb ); ?>>True
						<input type="radio" name="<?php echo $prefix; ?>grab_cursor_thumb" value="false" <?php checked( 'false', $grab_cursor_thumb ); ?>>False<br/>
						<span class="description"><?php _e('This option may a little improve desktop usability. If true, user will see the "grab" cursor when hover on Swiper','swiper-slider-and-carousel'); ?></span>
					</td>
				</tr>
			</tbody>
		</table><!-- end .wtwp-tstmnl-table -->
	</div>	
</div>
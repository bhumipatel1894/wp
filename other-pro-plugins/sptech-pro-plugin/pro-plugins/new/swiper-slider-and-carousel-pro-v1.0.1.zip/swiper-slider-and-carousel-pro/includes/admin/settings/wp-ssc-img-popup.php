<?php
/**
 * Image Data Popup
 *
 * @package Swiper Slider and Carousel
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;
?>

<div class="wp-sscpro-img-data-wrp wp-sscpro-hide">
	<div class="wp-sscpro-img-data-cnt">

		<div class="wp-sscpro-img-cnt-block">
			<div class="wp-sscpro-popup-close wp-sscpro-popup-close-wrp"><img src="<?php echo WP_SSCPRO_URL; ?>assets/images/close.png" alt="<?php _e('Close (Esc)', 'swiper-slider-and-carousel'); ?>" title="<?php _e('Close (Esc)', 'swiper-slider-and-carousel'); ?>" /></div>

			<div class="wp-sscpro-popup-body-wrp">
			</div><!-- end .wp-sscpro-popup-body-wrp -->
			
			<div class="wp-sscpro-img-loader"><?php _e('Please Wait', 'swiper-slider-and-carousel'); ?> <span class="spinner"></span></div>

		</div><!-- end .wp-sscpro-img-cnt-block -->

	</div><!-- end .wp-sscpro-img-data-cnt -->
</div><!-- end .wp-sscpro-img-data-wrp -->
<div class="wp-sscpro-popup-overlay"></div>
<?php
/**
 * 'meta_gallery_carousel' Shortcode
 * 
 * @package Swiper Slider and Carousel
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

function wp_sscpro_gallery_carousel( $atts, $content ) {
	
	extract(shortcode_atts(array(
		'id'				=> '',
	), $atts));
	
	// Taking some globals
	global $post;

	// Taking some variables
	$unique 		= wp_sscpro_get_unique();
	$gallery_id 	= !empty($id) ? $id	: $post->ID;

	$prefix = WP_SSCPRO_META_PREFIX; // Metabox prefix
	
	$slider_design     = get_post_meta( $gallery_id, $prefix.'slider_design', true );

	$slide_to_show		= get_post_meta( $gallery_id, $prefix.'slide_to_show_carousel', true );
	$slide_to_show 		= (!empty($slide_to_show)) ? $slide_to_show : '3';
	
	$slide_to_column	= get_post_meta( $gallery_id, $prefix.'slide_to_column_carousel', true );
	$slide_to_column	= (!empty($slide_to_column)) ? $slide_to_column : '1';
	
	$slide_per_column_carousel	= get_post_meta( $gallery_id, $prefix.'slide_per_column_carousel', true );
	$slide_per_column_carousel	= (!empty($slide_per_column_carousel)) ? $slide_per_column_carousel : '1';
	
	$arrow				= get_post_meta( $gallery_id, $prefix.'arrow_carousel', true );
	$arrow 				= ($arrow == 'false') ? 'false' : 'true';
	
	$pagination 		= get_post_meta( $gallery_id, $prefix.'pagination_carousel', true );
	$pagination 		= ($pagination == 'false') ? 'false' : 'true';

	$pagination_type 	= get_post_meta( $gallery_id, $prefix.'pagination_type_carousel', true );
	$pagination_type 	= ($pagination_type == 'fraction') ? 'fraction' : 'bullets';
	
	$speed 				= get_post_meta( $gallery_id, $prefix.'speed_carousel', true );
	$speed 				= (!empty($speed)) ? $speed : '300';

	$autoplay 			= get_post_meta( $gallery_id, $prefix.'autoplay_carousel', true );
	$autoplay 			= ($autoplay == 'false') ? 'false' : 'true';
	
	$autoplay_speed		= get_post_meta( $gallery_id, $prefix.'autoplay_speed_carousel', true );
	$autoplay_speed 	= (!empty($autoplay_speed)) ? $autoplay_speed : '3000';
	
	$auto_stop			= get_post_meta( $gallery_id, $prefix.'auto_stop_carousel', true );
	$auto_stop 			= ($auto_stop == 'true') ? 'true' : 'false';

	$loop				= get_post_meta( $gallery_id, $prefix.'loop_carousel', true );
	$loop 				= ($loop == 'true') ? 'true' : 'false';

	$centermode 		= get_post_meta( $gallery_id, $prefix.'centermode_carousel', true );
	$centermode 		= ($centermode == 'true') ? 'true' : 'false';

	$space_between   	= get_post_meta( $gallery_id, $prefix.'space_between_carousel', true );
	$space_between 		= (!empty($space_between)) ? $space_between : '0';
	
	$lazy_load_slider 	= get_post_meta( $gallery_id, $prefix.'lazy_load_carousel', true );
	$lazy_load_slider 	= ($lazy_load_slider == 'true') ? 'true' : 'false';	
	$nav_type_carousel 	= get_post_meta( $gallery_id, $prefix.'nav_type_carousel', true );
	
	$grab_cursor_carousel 		= get_post_meta( $gallery_id, $prefix.'grab_cursor_carousel', true );
	$grab_cursor_carousel 		= ($grab_cursor_carousel == 'true') ? 'true' : 'false';	

	$show_title 			= get_post_meta( $gallery_id, $prefix.'show_title', true );
	$show_caption 			= get_post_meta( $gallery_id, $prefix.'show_caption', true );
	
	// Slider configuration
	$slider_conf = compact('slide_to_show', 'slide_to_column','slide_per_column_carousel', 'pagination','pagination_type', 'speed','autoplay','autoplay_speed','auto_stop','space_between','centermode','loop','grab_cursor_carousel', 'lazy_load_slider');

	// Enqueue required script
	wp_enqueue_script( 'wpos-swiper-jquery' );
	wp_enqueue_script( 'wp-ssc-public-js' );

	// Getting gallery images
	$images = get_post_meta($gallery_id, $prefix.'gallery_id', true);

	// Shortcode file
	$gallery_path 	= WP_SSCPRO_DIR . '/templates/carousel/' . $slider_design . '.php';
	$design_file 	= (file_exists($gallery_path)) ? $gallery_path : '';
	
	ob_start();
	
	if( $images ): ?>
		
		<div class="wpssc-carousel-wrap wpssc-row-clearfix sscpro-<?php echo $slider_design; ?> <?php if ($lazy_load_slider == 'true') { echo "lazy_load_acitive"; }  ?>">		
			<div id="wpssc-carousel-<?php echo $unique; ?>" class="swiper-container wpssc-swiper-carousel-wrapper">				
				<div class="swiper-wrapper wpssc-swiper-carousel">					
					<?php foreach( $images as $image ): 						
						$post_mata_data		= get_post($image);					
						$image_lsider		= wp_get_attachment_image_src( $image, 'large' );
						$image_alt_text 	= get_post_meta($image,'_wp_attachment_image_alt',true);
						$image_link 		= get_post_meta($image, $prefix.'attachment_link',true);
						$image_caption 		= $post_mata_data->post_excerpt;
						$image_title 		= $post_mata_data->post_title;						
							
						if($design_file) {
							include($design_file);	                   	
						}	
							
						endforeach; ?>
				</div>				
				<div class="wpssc-carousel-conf"><?php echo json_encode( $slider_conf ); ?></div><!-- end of-slider-conf -->
				
				<?php if($pagination == 'true'){ ?>
					<div class="swiper-pagination <?php if ($nav_type_carousel == 'light') { echo "swiper-pagination-white"; } elseif ($nav_type_carousel == 'black') { echo "swiper-pagination-black"; } ?>"></div>
				<?php } ?>	        
		        <!-- Add Arrows -->
		        <?php if($arrow == 'true'){ ?>
			        <div class="swiper-button-next <?php if ($nav_type_carousel == 'light') { echo "swiper-button-white"; } elseif ($nav_type_carousel == 'black') { echo "swiper-button-black"; } ?>"></div>
			        <div class="swiper-button-prev <?php if ($nav_type_carousel == 'light') { echo "swiper-button-white"; } elseif ($nav_type_carousel == 'black') { echo "swiper-button-black"; } ?>"></div>
		        <?php } ?>
			</div><!-- end .msacwl-carousel -->
		</div><!-- end .msacwl-carousel-wrap -->
	<?php endif;
	
	$content .= ob_get_clean();
	return $content;
}

// 'meta_gallery_carousel' Shortcode
add_shortcode( 'swiper_carousel', 'wp_sscpro_gallery_carousel' );
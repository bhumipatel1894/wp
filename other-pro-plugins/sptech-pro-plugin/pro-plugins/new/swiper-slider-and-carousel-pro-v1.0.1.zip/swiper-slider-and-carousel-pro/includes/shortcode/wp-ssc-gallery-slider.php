<?php
/**
 * 'meta_gallery_slider' Shortcode
 * 
 * @package Swiper Slider and Carousel
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

function wp_sscpro_gallery_slider($atts, $content) {
	
	extract(shortcode_atts(array(
		'id'				=> '',
	), $atts));
	
	// Taking some globals
	global $post;

	// Taking some variables
	$unique 		= wp_sscpro_get_unique();
	$gallery_id 	= !empty($id) ? $id	: $post->ID;

	$prefix = WP_SSCPRO_META_PREFIX; // Metabox prefix
		
	$slider_design     = get_post_meta( $gallery_id, $prefix.'slider_design', true );
	
	$arrow 				= get_post_meta( $gallery_id, $prefix.'arrow_slider', true );
	$arrow 				= ($arrow == 'false') ? 'false' : 'true';	
	$pagination 		= get_post_meta( $gallery_id, $prefix.'pagination_slider', true );
	$pagination 		= ($pagination == 'false') ? 'false' : 'true';
	$pagination_type 	= get_post_meta( $gallery_id, $prefix.'pagination_type_slider', true );		
	$autoplay 			= get_post_meta( $gallery_id, $prefix.'autoplay_slider', true );
	$autoplay 			= ($autoplay == 'false') ? 'false' : 'true';	
	$autoplay_speed 	= get_post_meta( $gallery_id, $prefix.'autoplay_speed_slider', true );
	$autoplay_speed 	= (!empty($autoplay_speed)) ? $autoplay_speed : '3000';	
	$auto_stop 			= get_post_meta( $gallery_id, $prefix.'auto_stop_slider', true );
	$auto_stop 			= ($auto_stop == 'true') ? 'true' : 'false';	
	$loop 				= get_post_meta( $gallery_id, $prefix.'loop_slider', true );
	$loop 				= ($loop == 'false') ? 'false' : 'true';
	$speed 				= get_post_meta( $gallery_id, $prefix.'speed_slider', true );
	$speed 				= (!empty($speed)) ? $speed : '300';	
	$animation 			= get_post_meta( $gallery_id, $prefix.'animation_slider', true );	
	$autoheight 		= get_post_meta( $gallery_id, $prefix.'autoheight_slider', true );
	$autoheight 		= ($autoheight == 'true') ? 'true' : 'false';
	
	$height 			= get_post_meta( $gallery_id, $prefix.'height_slider', true );
	$height 			= (!empty($height)) ? $height : '400';
	
	$direction 			= get_post_meta( $gallery_id, $prefix.'direction_slider', true );
	$direction 			= ($direction == 'vertical') ? 'vertical' : 'horizontal';
	$vertical_height 	= ($direction == 'vertical' && empty($height)) ? '500' : $height ;
	$space_between   	= get_post_meta( $gallery_id, $prefix.'space_between_slider', true );
	$space_between 		= (!empty($space_between)) ? $space_between : '0';
	
	$slider_height 		= (!empty($height)) ? 'style="height:'.$height.'px;"' : '';
	$slider_wrap_height = ($direction == 'vertical' && empty($height)) ? 'style="height:500px;"' : $slider_height;	
	
	$grab_cursor 		= get_post_meta( $gallery_id, $prefix.'grab_cursor', true );
	$grab_cursor 		= ($grab_cursor == 'true') ? 'true' : 'false';	
	$lazy_load_slider 	= get_post_meta( $gallery_id, $prefix.'lazy_load_slider', true );
	$lazy_load_slider 	= ($lazy_load_slider == 'true') ? 'true' : 'false';	
	$nav_type 			= get_post_meta( $gallery_id, $prefix.'nav_type', true );
	
	$show_title 			= get_post_meta( $gallery_id, $prefix.'show_title', true );
	$show_caption 			= get_post_meta( $gallery_id, $prefix.'show_caption', true );

	// Slider configuration
	$slider_conf = compact('pagination','pagination_type', 'autoplay', 'autoplay_speed', 'direction','auto_stop','speed','animation','vertical_height','autoheight','space_between','loop', 'grab_cursor', 'lazy_load_slider');

	// Enqueue required script
	wp_enqueue_script( 'wpos-swiper-jquery' );
	wp_enqueue_script( 'wp-ssc-public-js' );
	
	// Getting gallery images
	$images = get_post_meta($gallery_id, $prefix.'gallery_id', true);
	
	// Shortcode file
	$gallery_path 	= WP_SSCPRO_DIR . '/templates/slider/' . $slider_design . '.php';
	$design_file 	= (file_exists($gallery_path)) ? $gallery_path : '';
	
	ob_start();

	if( $images ): ?>
		<div class="wpssc-slider-wrap wpssc-row-clearfix sscpro-<?php echo $slider_design; ?>">
			<div id="wpssc-slider-<?php echo $unique; ?>" class="swiper-container wpssc-swiper-slider-wrapper" <?php if($direction == 'vertical') { echo $slider_wrap_height; } ?>>				
				<div class="swiper-wrapper wpssc-swiper-slider">					
					<?php foreach( $images as $image ): 						
						$post_mata_data		= get_post($image);					
						$image_lsider		= wp_get_attachment_image_src( $image, 'full' );
						$image_alt_text 	= get_post_meta($image,'_wp_attachment_image_alt',true);
						$image_link 		= get_post_meta($image, $prefix.'attachment_link',true);
						$image_caption 		= $post_mata_data->post_excerpt;
						$image_title 		= $post_mata_data->post_title;						
							
						if($design_file) {
							include($design_file);	                   	
						}	
							
						endforeach; ?>
				</div>
				<div class="wpssc-slider-conf"><?php echo json_encode( $slider_conf ); ?></div><!-- end of-slider-conf -->				
				<?php if($pagination == 'true'){ ?>
					<div class="swiper-pagination <?php if ($nav_type == 'light') { echo "swiper-pagination-white"; } elseif ($nav_type == 'black') { echo "swiper-pagination-black"; } ?>"></div>
				<?php } ?>	        
		        <!-- Add Arrows -->
		        <?php if($arrow == 'true'){ ?>
			        <div class="swiper-button-next <?php if ($nav_type == 'light') { echo "swiper-button-white"; } elseif ($nav_type == 'black') { echo "swiper-button-black"; } ?>"></div>
			        <div class="swiper-button-prev <?php if ($nav_type == 'light') { echo "swiper-button-white"; } elseif ($nav_type == 'black') { echo "swiper-button-black"; } ?>"></div>
		        <?php } ?>
			</div><!-- end .msacwl-slider -->
		</div><!-- end .msacwl-slider-wrap -->
	<?php endif;
	$content .= ob_get_clean();
	return $content;
}
// 'meta_gallery_slider' Shortcode
add_shortcode( 'swiper_slider', 'wp_sscpro_gallery_slider' );
<?php
/**
 * Plugin Name: Swiper Slider and Carousel Pro
 * Plugin URI: http://www.wponlinesupport.com/
 * Description: Plugin create custom post type - swiper slider, add mulipule images and settings. 
 * Author: WP Online Support 
 * Text Domain: swiper-slider-and-carousel
 * Domain Path: /languages/
 * Version: 1.0.1
 * Author URI: http://www.wponlinesupport.com/
 *
 * @package WordPress
 * @author SP Technolab
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

if( !defined( 'WP_SSCPRO_VERSION' ) ) {
	define( 'WP_SSCPRO_VERSION', '1.0.1' ); // Version of plugin
}
if( !defined( 'WP_SSCPRO_DIR' ) ) {
    define( 'WP_SSCPRO_DIR', dirname( __FILE__ ) ); // Plugin dir
}
if( !defined( 'WP_SSCPRO_URL' ) ) {
    define( 'WP_SSCPRO_URL', plugin_dir_url( __FILE__ ) ); // Plugin url
}
if( !defined( 'WP_SSCPRO_POST_TYPE' ) ) {
    define( 'WP_SSCPRO_POST_TYPE', 'wp_ssc_gallery' ); // Plugin post type
}
if( !defined( 'WP_SSCPRO_META_PREFIX' ) ) {
    define( 'WP_SSCPRO_META_PREFIX', '_wp_ssc_' ); // Plugin metabox prefix
}
if( !defined( 'SSCPRO_PLUGIN_BASENAME' ) ) {
	define( 'SSCPRO_PLUGIN_BASENAME', plugin_basename( __FILE__ ) ); // plugin base name
}

/**
 * Load Text Domain
 * This gets the plugin ready for translation
 * 
 * @package Swiper Slider and Carousel
 * @since 1.0.0
 */
function wp_sscpro_load_textdomain() {
	load_plugin_textdomain( 'swiper-slider-and-carousel', false, dirname( plugin_basename(__FILE__) ) . '/languages/' );
}
add_action('plugins_loaded', 'wp_sscpro_load_textdomain');


/***** Updater Code Starts *****/
define( 'EDD_SSCPRO_STORE_URL', 'https://www.wponlinesupport.com' );
define( 'EDD_SSCPRO_ITEM_NAME', 'Swiper Slider and Carousel Pro' );

// Plugin Updator Class
if( !class_exists( 'EDD_SL_Plugin_Updater' ) ) {	
	include( dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php' );
}

/**
 * Updater Function
 * 
 * @package Swiper Slider and Carousel
 * @since 1.0.0
 */
function edd_sl_sscpro_plugin_updater() {
	
	$license_key = trim( get_option( 'edd_sscpro_license_key' ) );

	$edd_updater = new EDD_SL_Plugin_Updater( EDD_SSCPRO_STORE_URL, __FILE__, array(
            'version' 	=> WP_SSCPRO_VERSION,      // current version number
            'license' 	=> $license_key,          // license key (used get_option above to retrieve from DB)
            'item_name' => EDD_SSCPRO_ITEM_NAME,    // name of this plugin
            'author' 	=> 'WP Online Support'    // author of this plugin
		)
	);

}
add_action( 'admin_init', 'edd_sl_sscpro_plugin_updater', 0 );
include( dirname( __FILE__ ) . '/edd-sscpro-plugin.php' );
/***** Updater Code Ends *****/



/**
 * Activation Hook
 * 
 * Register plugin activation hook.
 * 
 * @package Swiper Slider and Carousel
 * @since 1.0.0
 */
register_activation_hook( __FILE__, 'wp_sscpro_install' );

/**
 * Deactivation Hook
 * 
 * Register plugin deactivation hook.
 * 
 * @package Swiper Slider and Carousel
 * @since 1.0.0
 */
register_deactivation_hook( __FILE__, 'wp_sscpro_uninstall');

/**
 * Plugin Setup (On Activation)
 * 
 * Does the initial setup,
 * set default values for the plugin options.
 * 
 * @package Swiper Slider and Carousel
 * @since 1.0.0
 */
function wp_sscpro_install() {
    
    // Register post type function
    wp_sscpro_register_post_type();

    // IMP need to flush rules for custom registered post type
    flush_rewrite_rules();

    // Deactivate free version
    if( is_plugin_active('swiper-slider-and-carousel/swiper-slider-and-carousel.php') ) {
        add_action('update_option_active_plugins', 'wp_sscpro_deactivate_free_version');
    }
}

/**
 * Plugin Setup (On Deactivation)
 * 
 * Delete  plugin options.
 * 
 * @package Swiper Slider and Carousel
 * @since 1.0.0
 */
function wp_sscpro_uninstall() {
    
    // IMP need to flush rules for custom registered post type
    flush_rewrite_rules();
}

/**
 * Deactivate free plugin
 * 
 * @package Swiper Slider and Carousel
 * @since 1.0.0
 */
function wp_sscpro_deactivate_free_version() {
    deactivate_plugins('swiper-slider-and-carousel/swiper-slider-and-carousel.php', true);
}


/**
 * Function to display admin notice of activated plugin.
 * 
 * @package Swiper Slider and Carousel
 * @since 1.0.0
 */
function wp_sscpro_admin_notice() {

    $dir = ABSPATH . 'wp-content/plugins/swiper-slider-and-carousel/swiper-slider-and-carousel.php';

    // If PRO plugin is active and free plugin exist
    if( is_plugin_active( 'swiper-slider-and-carousel-pro/swiper-slider-and-carousel-pro.php' ) && file_exists($dir) ) {

        global $pagenow;

        if( $pagenow == 'plugins.php' ) {

            if ( current_user_can( 'install_plugins' ) ) {
                echo '<div id="message" class="updated notice is-dismissible"><p><strong>Thank you for activating Swiper Slider and Carousel Pro </strong>.<br /> It looks like you had FREE version <strong>( <em>Swiper Slider and Carousel </em>)</strong> of this plugin activated. To avoid conflicts the extra version has been deactivated and we recommend you delete it. </p></div>';
            }
        }
    }
}

// Action to display notice
add_action( 'admin_notices', 'wp_sscpro_admin_notice');

// Functions File
require_once( WP_SSCPRO_DIR . '/includes/wp-ssc-functions.php' );

// Plugin Post Type File
require_once( WP_SSCPRO_DIR . '/includes/wp-ssc-post-types.php' );

// Script File
require_once( WP_SSCPRO_DIR . '/includes/class-wp-ssc-script.php' );

// Admin Class File
require_once( WP_SSCPRO_DIR . '/includes/admin/class-wp-ssc-admin.php' );

// Shortcode File
require_once( WP_SSCPRO_DIR . '/includes/shortcode/wp-ssc-gallery-slider.php' );
require_once( WP_SSCPRO_DIR . '/includes/shortcode/wp-ssc-gallery-carousel.php' );
require_once( WP_SSCPRO_DIR . '/includes/shortcode/wp-ssc-gallery-thumbs-gallery.php' );

// How it work file, Load admin files
if ( is_admin() || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
    require_once( WP_SSCPRO_DIR . '/includes/admin/ssc-how-it-work.php' );
}
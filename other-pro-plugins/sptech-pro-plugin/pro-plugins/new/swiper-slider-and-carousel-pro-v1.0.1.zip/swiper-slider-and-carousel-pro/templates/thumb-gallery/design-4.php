<?php
/**
 * Design file
 *
 * Handles the Admin side functionality of plugin
 *
 * @package Swiper Slider and Carousel
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;	
?>			
<div class="swiper-slide sscpro-slide">
<?php if(!empty($image_link)) { ?><a class="sscpro-img-overlay-link" href="<?php echo $image_link; ?>"></a><?php } ?>
	<div class="sscpro-img-wrap" <?php echo $slider_wrap_height; ?>>							
	 <?php if ($lazy_load_slider == 'true')	{ ?>
			 <img data-src="<?php echo $image_lsider[0]; ?>"  alt="<?php echo $image_alt_text; ?>" class="swiper-lazy" /></a> 
				<div class="swiper-lazy-preloader"></div>
				<?php } else { ?>
					<img src="<?php echo $image_lsider[0]; ?>" alt="<?php echo $image_alt_text; ?>" />
				<?php } ?>	
	</div>
		<?php if(($show_title == 'true' && !empty($image_title)) || ($show_caption == 'true' && !empty($image_caption))) {
					 ?>
						<div class="sscpro-gallery-container">
							<?php if($show_title == 'true') { ?>
								<div class="sscpro-image-title"><?php echo $image_title; ?></div>
							<?php } 	
							if($show_caption == 'true') { ?>	
								<div class="sscpro-image-caption"><?php echo $image_caption; ?></div>
							<?php } ?>		
						</div>
			<?php }	 ?>
</div>	
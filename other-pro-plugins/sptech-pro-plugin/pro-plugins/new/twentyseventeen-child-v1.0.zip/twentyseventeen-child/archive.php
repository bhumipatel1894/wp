<?php
/**
 * The template for displaying archive pages
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

get_header();
$categories = get_queried_object();
$cat_id = $categories->term_id;

$layouttype         = wpos_get_option('blog_layout_type_cat');
$gridcol            = wpos_get_option('blog_grid_cat');
$posts_per_page     = wpos_get_option('limit', 1);
$design             = wpos_get_option('blog_design_cat'); 
$showreadmore       = wpos_get_option('show_read_more'); 
$showDate           = wpos_get_option('enable_post_date_cat');
$showAuthor         = wpos_get_option('enable_post_author_cat');
$show_comments      = wpos_get_option('enable_post_count');
$showCategory       = wpos_get_option('enable_post_cat_cat');
$showContent        = wpos_get_option('show_content_cat');
$showFullContent    = wpos_get_option('post_full_cnt');
$read_more_text     = wpos_get_option('readmore_text_cat');
$show_tags          = wpos_get_option('enable_post_tag_cat');
$link_target        = wpos_get_option('link_behaviour_cat');
$words_limit                = wpos_get_option('excerpt_lenght');
$hide_indx_feat_img         = wpos_get_option('hide_indx_feat_img_cat', 0);
$hide_single_feat_img       = wpos_get_option('hide_single_feat_img_cat');
$enable_post_formate        = wpos_get_option('enable_post_formate_cat');

$effect ="effect-2";

$media_size = "full";
$post_design_file_path 	= get_stylesheet_directory() . '/blog-designs/'.$layouttype.'/'.$design.'.php';
$design_file 		= (file_exists($post_design_file_path)) ? $post_design_file_path : '';

$post_design_template 	= get_stylesheet_directory() . '/blog-designs/'.$layouttype.'/design-template.php';
$design_template 		= (file_exists($post_design_template)) ? $post_design_template : '';

global $paged, $post, $wpbawm_in_shrtcode;
$count 			= 0; 
$newscount 		= 0;
$grid_count		= 1; ?>

<div class="wrap">

	<?php if ( have_posts() ) : ?>
		<header class="page-header">
			<?php
				the_archive_title( '<h1 class="page-title">', '</h1>' );
				the_archive_description( '<div class="taxonomy-description">', '</div>' );
			?>
		</header><!-- .page-header -->
	<?php endif; ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

				<?php if(is_home() || is_front_page()) {
							$paged = get_query_var('page');
						} else {
							$paged = get_query_var('paged');
						}
						
						$order 			= 'ASC';
						$orderby 		='date';
						// WP Query Parameters
						$args = array ( 
							'post_type'      		=> 'post',
							'post_status' 			=> array('publish'),
							'order'          		=> $order,
							'orderby'        		=> $orderby,
							'cat'                   => $cat_id,	
							'posts_per_page' 		=> $posts_per_page, 
							'paged'          		=> $paged,		
							'ignore_sticky_posts'	=> true,
						);    

						// WP Query
						$query 		= new WP_Query($args);
						$post_count = $query->post_count;
						$total_post 	= $query->found_posts;
						
						// If post is there
						if ( $query->have_posts() ) { 
						
							 // Include shortcode html file
									if( $design_template ) {
										include( $design_template );
									}
						
						} // end of have_post()

						wp_reset_query(); // Reset WP Query

					  ?>


		</main><!-- #main -->
	</div><!-- #primary -->
	<?php get_sidebar(); ?>
</div><!-- .wrap -->

<?php get_footer();

jQuery(document).ready(function($) { 	
	// If go to top is enabled
	if( Wpos.enable_goto_top == 1 ) {
		// Go to top functionality
		jQuery(window).load(function() {
			wpos_goto_top();
		});
		jQuery(window).scroll(function() {
			wpos_goto_top();
		});
		// BacktoTop
		$('#wpos-go-to-top').click(function() {
			$('html, body').animate({
				scrollTop: 0
			}, 1000);

			return false;
		});
	}  
        
        
});
// Function to goto top
function wpos_goto_top() {
	var y = jQuery(this).scrollTop();
	 if (y > 150) {
	    jQuery('#wpos-go-to-top').fadeIn('slow')
	} else {
	    jQuery('#wpos-go-to-top').fadeOut('slow')
	}
}


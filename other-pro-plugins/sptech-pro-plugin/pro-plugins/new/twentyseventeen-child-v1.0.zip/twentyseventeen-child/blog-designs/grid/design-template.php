<div class="wpspw-post-grid-main <?php echo 'wpspw-'.$design; ?> wpspw-clearfix">			
			<?php
			while ( $query->have_posts() ) : $query->the_post();
				
				$count++;
				$cat_links 		= array();
				$css_class 		= '';
				$post_featured_image 	= wpspw_pro_get_post_featured_image( $post->ID, $media_size, true );
				$post_link 		= wpspw_pro_get_post_link( $post->ID );
				$terms 			= get_the_terms( $post->ID, 'category' );
				$tags 			= get_the_tag_list(' ',', ');
				$comments 		= get_comments_number( $post->ID );
				$reply			= ($comments <= 1)  ? 'Reply' : 'Replies';
				
				if($terms) {
					foreach ( $terms as $term ) {
						$term_link = get_term_link( $term );
						$cat_links[] = '<a href="' . esc_url( $term_link ) . '">'.$term->name.'</a>';
					}
				}
				$cate_name = join( " ", $cat_links );
				
				if ( ( is_numeric( $gridcol ) && ( $gridcol > 0 ) && ( 0 == ($count - 1) % $gridcol ) ) || 1 == $count ) { $css_class .= ' wpspw-first'; }
				if ( ( is_numeric( $gridcol ) && ( $gridcol > 0 ) && ( 0 == $count % $gridcol ) ) || $post_count == $count ) { $css_class .= ' wpspw-last'; }
	            
	            // Include shortcode html file
				if( $design_file ) {
					include( $design_file );
				}

				$newscount++;
				$grid_count++;

			endwhile; ?>
		</div>

		
		<div class="wpspw-post-pagination wpspw-clearfix">
			<?php 				
				echo wpspw_pro_pagination( array( 'paged' => $paged , 'total' => $query->max_num_pages ) );
			 ?>
		</div>
<?php 
// Shortcode Parameters
$shortcode_atts = compact('posts_per_page','hide_indx_feat_img', 'design','words_limit', 'gridcol', 'showDate', 'showCategory', 'showContent', 'showreadmore', 'order', 'orderby', 'link_target', 'showAuthor', 'show_tags','read_more_text','show_comments');

// Enqueue required script
			wp_enqueue_script('masonry', 'jquery');
			wp_enqueue_script('wpspw-masonry-public-script');		?>

		<div class="wpspw-post-masonry-wrp wpspw-clearfix" id="wpspw-post-masonry-wrp-<?php echo $unique; ?>">	
			<div class="wpspw-post-masonry wpspw-<?php echo $effect; ?> wpspw-<?php echo $design; ?> wpspw-grid-<?php echo $grid; ?>" id="wpspw-post-masonry-<?php echo $unique; ?>">
			<?php
			while ( $query->have_posts() ) : $query->the_post();
				
				$count++;
				$cat_links 		= array();
				$css_class 		= '';
				$post_featured_image 	= wpspw_pro_get_post_featured_image( $post->ID, 'full', true );
				$post_link 		= wpspw_pro_get_post_link( $post->ID );
				$terms 			= get_the_terms( $post->ID, 'category' );
				$tags 			= get_the_tag_list(' ',', ');
				$comments 		= get_comments_number( $post->ID );
				$reply			= ($comments <= 1)  ? 'Reply' : 'Replies';
				
				if($terms) {
					foreach ( $terms as $term ) {
						$term_link = get_term_link( $term );
						$cat_links[] = '<a href="' . esc_url( $term_link ) . '">'.$term->name.'</a>';
					}
				}
				$cate_name = join( " ", $cat_links );			
				
	            
	            // Include shortcode html file
				if( $design_file ) {
					include( $design_file );
				}

				$newscount++;
				$grid_count++;

			endwhile; ?>
			</div>		
		<?php if( ($posts_per_page != -1) && ($posts_per_page < $total_post) ) { ?>
			<div class="wpspw-ajax-btn-wrap">
				<button class="wpspw-load-more-btn more" data-ajax="1" data-paged="1" data-count="<?php echo $count; ?>">
					<i class="wpspw-ajax-loader"><img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/ajax-loader.gif" alt="<?php _e('Loading', 'twentyseventeen'); ?>" /></i> 
					<?php _e('Load More', 'twentyseventeen'); ?>
				</button>
				<div class="wpspw-hide wpspw-shortcode-param"><?php echo wpspw_esc_attr( json_encode($shortcode_atts)); ?></div>
			</div><!-- end .wpspw-ajax-btn-wrap -->
		
			<?php } ?>
			</div>	
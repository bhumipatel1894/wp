<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.2
 */

?>

</div><!-- #content -->
	<?php if ( is_active_sidebar( 'instgaram-sidebar' ) ) : ?>	
		<div class="wpos-instagram-feed wpspw-clearfix">
			<?php dynamic_sidebar( 'instgaram-sidebar' ); ?>
		</div>
	<?php endif; ?>
		<footer id="colophon" class="site-footer" role="contentinfo">
			<div class="wrap">
				<?php get_sidebar('footer'); ?>
			</div>	
			<div class="footer-copyright-area wpspw-clearfix">	
					<div class="wrap">	
						<div class="wpspw-medium-8 wpspw-columns wpos-footer-copyright-text">
							<?php echo wpos_footer_copyright(); ?>
						</div>
						<div class="wpspw-medium-4 wpspw-columns wpos-social-networks wpos-social-networks-footer wpos-text-right">
							<?php echo wpos_social_networks( 'footer' ); ?>
						</div>
					</div>
			</div><!-- end .footer-copyright-area -->			
		</footer><!-- #colophon -->
		<!-- Go to top -->
				<?php if(wpos_get_option('enable_goto_top')) { ?>
					<div id="wpos-go-to-top">
							<div class="wpos-go-to-top-container show-for-large-up">
								<i class="fa fa-chevron-up"></i>
							</div>
					</div>
				<?php } ?>
	</div><!-- .site-content-contain -->
</div><!-- #page -->
<?php wp_footer(); ?>

</body>
</html>

<?php

/**
 * WPOS Twenty Seventeen Child
 * @package WPOS Twenty Seventeen Child
 * @since 1.0
 */

// Defining Some Variable
if( !defined( 'WPOS_VERSION' ) ) {
	define('WPOS_VERSION', '1.0'); // Theme Version
}
if( !defined( 'WPOS_DIR' ) ) {
	define( 'WPOS_DIR', dirname( __FILE__ ) );	// Theme dir
}
if( !defined( 'WPOS_URL' ) ) {
	define( 'WPOS_URL', get_stylesheet_directory_uri() );	// Theme url
}
if( !defined( 'WPOS_DEFAULT_POST_TYPE' ) ) {
    define( 'WPOS_DEFAULT_POST_TYPE', 'post' ); // Theme default post type
}
if( !defined( 'WPOS_DEFAULT_CAT' ) ) {
    define( 'WPOS_DEFAULT_CAT', 'category' ); // Theme default category name
}
if( !defined( 'WPOS_META_PREFIX' ) ) {
	define( 'WPOS_META_PREFIX', '_wpos_' );	// Meta Prefix
}


/***** Updater Code Starts *****/
function wpos_theme_updater() {
	require( get_stylesheet_directory() . '/updater/theme-updater.php' );
}
add_action( 'after_setup_theme', 'wpos_theme_updater' );
/***** Updater Code Ends *****/

require_once( get_stylesheet_directory() . '/includes/wpspw-ajax-functions.php' );
function wpos_twentyseventeen_theme_enqueue_styles() {

    $parent_style = 'parent-style'; // This is 'twentyfifteen-style' for the Twenty Fifteen theme.

    wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css' );
   
}
add_action( 'wp_enqueue_scripts', 'wpos_twentyseventeen_theme_enqueue_styles' );

// Change number or products per row to 3
add_filter('loop_shop_columns', 'loop_columns');
if (!function_exists('loop_columns')) {
	function loop_columns() {
		return 3; // 3 products per row
	}
}
/**
 * Function to get post excerpt
 * 
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0
 */
function wpspw_pro_get_post_excerpt( $post_id = null, $content = '', $word_length = '55', $more = '...' ) {
	
	$has_excerpt 	= false;
	$word_length 	= !empty($word_length) ? $word_length : '55';
	
	// If post id is passed
	if( !empty($post_id) ) {
		if (has_excerpt($post_id)) {

			$has_excerpt 	= true;
			$content 		= get_the_excerpt();

		} else {
			$content = !empty($content) ? $content : get_the_content();
		}
	}

	if( !empty($content) && (!$has_excerpt) ) {
		$content = strip_shortcodes( $content ); // Strip shortcodes
		$content = wp_trim_words( $content, $word_length, $more );
	}
	
	return $content;
}

/**
 * Function to get post featured image
 * 
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0
 */
function wpspw_pro_get_post_featured_image( $post_id = '', $size = 'full', $default_img = false ) {
    
    $size   = !empty($size) ? $size : 'full';
    $image  = wp_get_attachment_image_src( get_post_thumbnail_id( $post_id ), $size );

    if( !empty($image) ) {
        $image = isset($image[0]) ? $image[0] : '';
    }
   
    return $image;
}



/**
 * Return the Google font stylesheet URL if available.
 *
 * The use of Open Sans by default is localized. For languages that use
 * characters not supported by the font, the font can be disabled.
 *
 * @package WP Clean Responsive
 * @since 1.0
 */
function wpos_get_font_url() {

	$font_url = '';
	
	$body_font_type 		= wpos_get_option('body_font_type');
	$navigation_font_type 	= wpos_get_option('navigation_font_type');
	$heading_font_type 		= wpos_get_option('heading_font_type');
	
	// Navigation google font
	if( $navigation_font_type == 'google' ){
		$font[] = wpos_get_option('navigation_google_font');
	}

	// Heading google font
	if( $heading_font_type == 'google' ){
		$font[] = wpos_get_option('heading_google_font');
	}

	// Body google font
	if( $body_font_type == 'google' ){
		$font[] = wpos_get_option('body_google_font');
	}
	
	// Creating font URL
	if( !empty($font) ) {
		$query_args = array(
							'family' => implode( '|', $font)
						);
		$font_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
	}

	return $font_url;
}


/**
 * Function to get post external link or permalink
 * 
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0
 */
function wpspw_pro_get_post_link( $post_id = '' ) {

	$post_link = '';

	if( !empty($post_id) ) {		

		if( empty($post_link) ) {
			$post_link = get_permalink( $post_id );	
		}
	}
	return $post_link;
}

/**
 * Pagination function for grid
 * 
 * @package Blog Designer - Post and Widget Pro
 * @since 1.0
 */
function wpspw_pro_pagination($args = array()){
	
	$big = 999999999; // need an unlikely integer
	
	$paging = apply_filters('wpspw_pro_post_paging_args', array(
					'base' 		=> str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
					'format' 	=> '?paged=%#%',
					'current' 	=> max( 1, $args['paged'] ),
					'total'		=> $args['total'],
					'prev_next'	=> true,
					'prev_text'	=> __('« Previous', 'blog-designer-for-post-and-widget'),
					'next_text'	=> __('Next »', 'blog-designer-for-post-and-widget'),
				));
	
	echo paginate_links($paging);
}

/**
 * Escape Tags & Slashes
 *
 * Handles escapping the slashes and tags
 *
 * @package WP Blog and Widget - Masonry Layout
 * @since 1.0
 */
function wpspw_esc_attr($data) {
	return esc_attr( stripslashes($data) );
}

/**
 * Register sidebars.
 *
 * Registers our main widget area and the front page widget areas.
 *
 * @since Twenty Twelve 1.0
 */
function wpos_widgets_init() {
	register_sidebar( array(
		'name' => __( 'Woocommerce Sidebar', 'twentytwelve' ),
		'id' => 'woocommerce-sidebar',
		'description' => __( 'Appears on woocommerce shop page', 'twentytwelve' ),
		'before_widget' => '<aside id="%1$s" class="widget-woocommerce widget %2$s">',
		'after_widget' => '</aside>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );
	register_sidebar( array(
		'name' => __( 'Instgaram Footer Sidebar', 'twentytwelve' ),
		'id' => 'instgaram-sidebar',
		'description' => __( 'Appears on Instgaram feed in footer', 'twentytwelve' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => '</aside>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );
	
}
add_action( 'widgets_init', 'wpos_widgets_init' );

 
/**
 * Theme activation function
 * 
 * @package WP Clean Responsive
 * @since 1.0
 */
function wpos_theme_activated() {

	if( isset($_GET['activated']) && $_GET['activated'] == 'true' ) {

		// get settings for the plugin
		$wpos_options = get_option( 'wpos_options' );

		if( empty($wpos_options) ) {
			
			wpos_default_settings();

			// Update theme version to option
			update_option( 'wpos_clean_responsive_version', '1.0' );
		}
	}
}

// Action for theme activation
add_action('after_switch_theme', 'wpos_theme_activated');

//Taking some globals
global $wpos_options, $wpos_image_size;

// Functions file
require_once( WPOS_DIR . '/includes/wpos-functions.php' );
$wpos_options = wpos_get_theme_settings();


// Template Tags HTML
require_once( WPOS_DIR . '/includes/wpos-template-tags.php' );


// Settings File
require_once( WPOS_DIR . '/includes/admin/settings/wpos-styling-options.php' );
require_once( WPOS_DIR . '/includes/admin/settings/wpos-footer-settings.php' );
require_once( WPOS_DIR . '/includes/admin/settings/wpos-font-settings.php' );
require_once( WPOS_DIR . '/includes/admin/settings/wpos-social-settings.php' );
require_once( WPOS_DIR . '/includes/admin/settings/wpos-blog-page-settings.php' );
require_once( WPOS_DIR . '/includes/admin/settings/wpos-cat-page-settings.php' );
require_once( WPOS_DIR . '/includes/admin/settings/wpos-single-post-page-settings.php' );
// Script Class
require_once( WPOS_DIR . '/includes/class-wpos-script.php' );

// Admin Class
require_once( WPOS_DIR . '/includes/admin/class-wpos-admin.php' );
// Public Class
require_once( WPOS_DIR . '/includes/class-wpos-public.php' );
// Widget Class
require_once( WPOS_DIR . '/includes/widgets/class-wpos-widgets.php' );
// Plugin recomendation class
require_once( WPOS_DIR . '/includes/plugins/class-wpos-recommendation.php' );

remove_action( 'woocommerce_before_main_content', array( 'WC_Twenty_Seventeen', 'output_content_wrapper' ) );
remove_action( 'woocommerce_after_main_content', array( 'WC_Twenty_Seventeen', 'output_content_wrapper_end' ) );

/**
 * Open the Twenty Seventeen wrapper.
 */
function wpos_woo_output_content_wrapper() { ?>
	<div class="wrap">
		<?php get_sidebar('shop'); ?>
		<div id="primary" class="content-area twentyseventeen">
			<main id="main" class="site-main" role="main">
	<?php
}
add_action( 'woocommerce_before_main_content', 'wpos_woo_output_content_wrapper' );

/**
 * Close the Twenty Seventeen wrapper.
 */
function wpos_woo_output_content_wrapper_end() { ?>
			</main>
		</div>
	</div>
	<?php
}
add_action( 'woocommerce_after_main_content', 'wpos_woo_output_content_wrapper_end' );
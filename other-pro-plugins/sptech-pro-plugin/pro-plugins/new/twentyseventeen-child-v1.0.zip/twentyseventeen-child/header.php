<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js no-svg">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">

<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content"><?php _e( 'Skip to content', 'twentyseventeen' ); ?></a>

	<header id="masthead" class="site-header" role="banner">

		<?php get_template_part( 'template-parts/header/header', 'image' ); ?>

		<?php if ( has_nav_menu( 'top' ) ) : ?>
			<div class="navigation-top">
				<div class="wrap">
					<?php get_template_part( 'template-parts/navigation/navigation', 'top' ); ?>
				</div><!-- .wrap -->
			</div><!-- .navigation-top -->
		<?php endif; ?>

	</header><!-- #masthead -->

	<?php

	/*
	 * If a regular post or page, and not the front page, show the featured image.
	 * Using get_queried_object_id() here since the $post global may not be set before a call to the_post().
	 */
	 $format = get_post_format( get_queried_object_id() );	
         $hide_single_feat_img                   = wpos_get_option('hide_single_feat_img',0);
	if ( ( is_single() || ( is_page() && ! twentyseventeen_is_frontpage() ) ) && has_post_thumbnail( get_queried_object_id() ) && !$hide_single_feat_img) { ?>
		<div class="single-featured-image-header">		
			<?php if($format == 'image' || $format == '0' || $format == 'aside' || $format == 'quote' || $format == 'audio' || $format == 'video' ) 
				{ 
					echo get_the_post_thumbnail( get_queried_object_id(), 'twentyseventeen-featured-image' ); 
				} else if($format == 'gallery') {
					wp_enqueue_script( 'wpos-slick-js' );
					get_template_part( 'template-parts/theme-slick-slider');
				}
			?>
		</div>
		<?php }
	?>

	<div class="site-content-contain">
		<div id="content" class="site-content">

<?php
/**
 * Admin Class
 *
 * Handles the Admin side functionality of theme
 *
 * @package WPOS Tell Your Tale
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Wpos_Admin {
	
	function __construct() {
		// Action to register admin menu
		add_action( 'admin_menu', array($this, 'wpos_register_menu') );
		
		// Action to register plugin settings
		add_action ( 'admin_init', array($this, 'wpos_register_settings') );

		// Ajax call to update option
		add_action( 'wp_ajax_wpos_update_theme_options', array($this, 'wpos_update_theme_options'));
		add_action( 'wp_ajax_nopriv_wpos_update_theme_options',array( $this, 'wpos_update_theme_options'));

		// Ajax call to backup option
		add_action( 'wp_ajax_wpos_backup_theme_options', array($this, 'wpos_backup_theme_options'));
		add_action( 'wp_ajax_nopriv_wpos_backup_theme_options',array( $this, 'wpos_backup_theme_options'));
	}
	
	
	/**
	 * Function to register admin menus
	 * 
	 * @package WPOS Tell Your Tale
	 * @since 1.0
	 */
	function wpos_register_menu() {
		add_menu_page( __('WPOS - Theme Settings', 'wpos-theme'), __('WPOS - Theme Settings', 'wpos-theme'), 'manage_options', 'wpos-theme-settings', array($this, 'wpos_theme_settings_page'), 'dashicons-welcome-view-site' );
	}

	/**
	 * Settings HTML
	 * 
	 * @package WPOS Tell Your Tale
	 * @since 1.0
	 */
	function wpos_theme_settings_page() {
		include_once( WPOS_DIR . '/includes/admin/settings/wpos-settings.php' );
	}

	/**
	 * Function register setings
	 * 
	 * @package WPOS Tell Your Tale
	 * @since 1.0.0
	 */
	function wpos_register_settings() {
		register_setting( 'wpos_theme_options_sett', 'wpos_options', array($this, 'wpos_validate_options') );
	}

	/**
	 * Validate Settings Options
	 * 
	 * @package WPOS Tell Your Tale
	 * @since 1.0.0
	 */
	function wpos_validate_options( $input ) {

		// Take some field before validate because of HTML tag
		$tracking_code 		= isset($input['tracking_code'])	? wpos_slashes_deep($input['tracking_code'], true) 	: '';
		$copyright_text 	= isset($input['copyright_text'])	? wpos_slashes_deep($input['copyright_text'], true) : '';
		$social 	= isset($input['social'])	? wpos_slashes_deep($input['social'], array()) : '';
		
		$input = wpos_slashes_deep( $input );
		$input['site_title_base'] 		= !empty($input['site_title_base']) 		? 1 : 0;
		$input['wpos_site_desc']		= !empty($input['wpos_site_desc']) 			? 1 : 0;
		$input['enable_copyright']		= !empty($input['enable_copyright'])		? 1 : 0;
		$input['enable_goto_top']		= !empty($input['enable_goto_top'])			? 1 : 0;
		$input['enable_nav_search']		= !empty($input['enable_nav_search'])		? 1 : 0;
		$input['social_media_footer']	= !empty($input['social_media_footer'])		? 1 : 0;
		$input['social_media_header']	= !empty($input['social_media_header'])		? 1 : 0;
		$input['post_full_cnt']			= !empty($input['post_full_cnt'])			? 1 : 0;
		$input['post_archives_full_cnt']= !empty($input['post_archives_full_cnt'])	? 1 : 0;
		$input['hide_indx_feat_img']	= !empty($input['hide_indx_feat_img'])		? 1 : 0;
		$input['hide_single_feat_img']	= !empty($input['hide_single_feat_img'])	? 1 : 0;
		$input['blog_masonry']			= !empty($input['blog_masonry'])	? 1 : 0;
		$input['cat_masonry']			= !empty($input['cat_masonry'])		? 1 : 0;
		$input['enable_rp_post']		= !empty($input['enable_rp_post'])	? 1 : 0;
		$input['enable_rp_post']		= !empty($input['enable_rp_post'])	? 1 : 0;
		$input['enable_full_post_page']	= !empty($input['enable_full_post_page'])	? 1 : 0;
		$input['tracking_code']			= $tracking_code;
		$input['copyright_text']		= $copyright_text;
		$input['social']                        = $social;
                
		$input['body_font_size']		= (!empty($input['body_font_size']) && $input['body_font_size'] >= 10 && $input['body_font_size'] <= 100 ) ? $input['body_font_size'] : '14';
		$input['body_line_height']		= (!empty($input['body_line_height']) && $input['body_line_height'] >= 10 && $input['body_line_height'] <= 100 ) ? $input['body_line_height'] : '24';
		$input['excerpt_lenght']		= (!empty($input['excerpt_lenght'])) ? $input['excerpt_lenght'] : '55';

		$input = apply_filters( 'wpos_validate_theme_options', $input );
		
		return $input;
	}

	/**
	 * Update Settings Options (Custom Way)
	 * 
	 * @package WPOS Tell Your Tale
	 * @since 1.0.0
	 */
	function wpos_update_theme_options() {
		
		// Taking some default
		$result = array();

		if( !empty($_POST['form_data']) ) {
			
			$output_arr = array();
			$form_data 	= parse_str( $_POST['form_data'], $output_arr );

			if( !empty($output_arr['wpos_options']) ) {

				// Update option
				update_option( 'wpos_options', $output_arr['wpos_options'] );

				$result['success'] = 1;
			}
		}

		echo json_encode($result);
		die();
	}

	/**
	 * Backup theme options
	 * 
	 * @package WPOS Tell Your Tale
	 * @since 1.0.0
	 */
	function wpos_backup_theme_options() {

		// Taking some default
		$result = array();

		if(!empty($_POST['is_ajax'])) {
			
			$theme_options = wpos_get_theme_settings(); // Get theme options
			
			if( !empty($theme_options) ) {

				$theme_options = json_encode( $theme_options );

				$result['success'] 	= 1;
				$result['data']		= $theme_options;
			} else {
				$result['success'] 	= 0;
			}
		}

		echo json_encode($result);
		die();
	}
	
}

$wpos_admin = new Wpos_Admin();
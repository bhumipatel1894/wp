<?php
/**
 * Blog Page settings
 *
 * @package WP Clean Responsive
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// Action to add Home Page settings
add_action( 'wpos_tab_content_blog_page_options', 'wpos_tab_content_blog_page_options' );

/**
 * Function to Home Page settings
 * 
 * @package WP Clean Responsive
 * @since 1.0
 */
function wpos_tab_content_blog_page_options() {
	global $wpos_options;
        
	$blog_grid 				= wpos_get_option('blog_grid', 1);
	$limit 					= wpos_get_option('limit', 10);
	$show_read_more 			= wpos_get_option('show_read_more',0);
	$blog_design 				= wpos_get_option('blog_design','design-1');
	$blog_layout_type 			= wpos_get_option('blog_layout_type', 'grid');
	$link_behaviour 			= wpos_get_option('link_behaviour', '_self');
	$blog_layout_full 			= wpos_get_option('blog_layout_full',0) ;	
	$post_full_cnt				= wpos_get_option('post_full_cnt',0);
	$enable_post_author			= wpos_get_option('enable_post_author',0);
	$enable_post_count 			= wpos_get_option('enable_post_count',0);
	$enable_post_cat 			= wpos_get_option('enable_post_cat',0);
	$enable_post_date 			= wpos_get_option('enable_post_date',0);
	$enable_post_tag 			= wpos_get_option('enable_post_tag',0);
	$enable_post_formate 			= wpos_get_option('enable_post_formate',0);
        
	$show_content                           = wpos_get_option('show_content',0);
        
	$hide_indx_feat_img                     = wpos_get_option('hide_indx_feat_img',0);
	
        
	$excerpt_lenght 			= wpos_get_option('excerpt_lenght');
        
        $wpos_blog_design_list                  = wpos_blog_design();
	$readmore_text 				= wpos_get_option('readmore_text');
        
        $blog_grid_cls 				= ($blog_layout_type == 'list') ? 'wpos-hide': '';
        
        $full_content_cls 			= ($blog_layout_type == 'masonry') ? 'wpos-hide': '';
        
        
?>
	<h2><?php _e('Blog Page Options', 'wpos-theme'); ?></h2>
        
        <div class="wpos-hide" id="wpos-design-lists"><?php echo json_encode($wpos_blog_design_list); ?></div>

	<table class="form-table">
            
            
                <!-- Layout -->
		<tr scope="row">
			<th scope="row">
				<label for="wpos-blog-layout"><?php _e('Layout Type', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<select class="wpos-select-box wpos-blog-lay out-type wpos-clickbox" name="wpos_options[blog_layout_type]" id="blog-layout-type">
					<option value="grid"    <?php selected( $blog_layout_type, 'grid' ); ?>><?php _e('Grid', 'wpos-theme'); ?></option>
					<option value="list"    <?php selected( $blog_layout_type, 'list' ); ?>><?php _e('List', 'wpos-theme'); ?></option>
					<option value="masonry" <?php selected( $blog_layout_type, 'masonry' ); ?>><?php _e('Masonry', 'wpos-theme'); ?></option>
				</select><br/>
				<span class="description"><?php _e('Select blog page layout type.', 'wpos-theme'); ?></span>
			</td>
		</tr>

		<!-- Grid -->
                <tr scope="row" class="blog_grid_cls <?php echo $blog_grid_cls; ?>" >
                    
			<th scope="row">
				<label for="wpos-blog-layout"><?php _e('Grid', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<select class="wpos-select-box wpos-blog-grid" name="wpos_options[blog_grid]" id="wpos-blog-grid">
					<option value="1" <?php selected( $blog_grid, 1 ); ?>><?php _e('One Column', 'wpos-theme'); ?></option>
					<option value="2" <?php selected( $blog_grid, 2 ); ?>><?php _e('Two Column', 'wpos-theme'); ?></option>
					<option value="3" <?php selected( $blog_grid, 3 ); ?>><?php _e('Three Column ', 'wpos-theme'); ?></option>
					<option value="4" <?php selected( $blog_grid, 4 ); ?>><?php _e('Four Column', 'wpos-theme'); ?></option>				
					<option value="5" <?php selected( $blog_grid, 5 ); ?>><?php _e('Five Column', 'wpos-theme'); ?></option>				
				</select>
                                <br/>
				<span class="description"><?php _e('Select blog page grid layout.', 'wpos-theme'); ?></span>
			</td>
		</tr>
                
		<tr>
			<th scope="row">
				<label for="wpos-post-limit"><?php _e('Limit', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<input type="number" name="wpos_options[limit]" value="<?php echo wpos_escape_attr( $limit ); ?>" id="wpos-post-limit" class="wpos-input-number wpos-post-excerpt-lenght" min="1" /><br/>
				<span class="description"><?php _e( 'Choose limit to display number of post at a time and then pagination.', 'wpos-theme' ); ?></span>
			</td>
		</tr>
                
                <!-- Design -->
		<tr scope="row">
                    
			<th scope="row">
				<label for="wpos-blog-design"><?php _e('Design', 'wpos-theme'); ?>:</label>
			</th>
                        
			<td>
				<select class="wpos-select-box wpos-blog-grid" name="wpos_options[blog_design]" id="wpos-blog-design">
                                 <?php
                                    if(!empty($wpos_blog_design_list)){
                                    foreach ($wpos_blog_design_list[$blog_layout_type] as $wpos_blog_design_lists => $val){ ?>
                                       <option value="<?php echo $val; ?>" <?php selected( $blog_design, $val ); ?>><?php _e($wpos_blog_design_lists, 'wpos-theme'); ?></option>
                                   <?php } } ?>
				</select>
                            
                                <br/>
                                
				<span class="description"><?php _e('Select Design.', 'wpos-theme'); ?></span>
			</td>
		</tr>           
                
                <tr class="">
			<th scope="row">
				<label for="wpos-post-content"><?php _e('Display content', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<div class="wpos-switch-box" id="wpos-switch-post-content">
					<label data-val="1" data-id="wpos-content" class="wpos-cb-enable <?php echo wpos_is_switch_enable($show_content,1);?>"> <?php _e('Enable','wpos-theme');?></label>
					<label data-val="0" data-id="wpos-content" class="wpos-cb-disable <?php echo wpos_is_switch_enable($show_content,0);?>"> <?php _e('Disable','wpos-theme');?></label>
				</div>
				<input type="hidden" name="wpos_options[show_content]" class="wpos-checkbox wpos-post-content" id="wpos-content" value=<?php echo $show_content; ?> /><br/>
				<span class="description"><?php _e( 'Check this box to display content or not.', 'wpos-theme' ); ?></span>
			</td>
		</tr>
		
		<tr class="full_content_cls <?php echo $full_content_cls; ?>">
			<th scope="row">
				<label for="wpos-post-full-cnt"><?php _e('Display full content', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<div class="wpos-switch-box" id="wpos-switch-post-full-cnt">
					<label data-val="1" data-id="wpos-post-full-cnt" class="wpos-cb-enable <?php echo wpos_is_switch_enable($post_full_cnt,1);?>"> <?php _e('Enable','wpos-theme');?></label>
					<label data-val="0" data-id="wpos-post-full-cnt" class="wpos-cb-disable <?php echo wpos_is_switch_enable($post_full_cnt,0);?>"> <?php _e('Disable','wpos-theme');?></label>
				</div>
				<input type="hidden" name="wpos_options[post_full_cnt]" class="wpos-checkbox wpos-post-full-cnt" id="wpos-post-full-cnt" value=<?php echo $post_full_cnt; ?> /><br/>
				<span class="description"><?php _e( 'Check this box to display the full content.', 'wpos-theme' ); ?></span>
			</td>
		</tr>
		
		<tr>
			<th scope="row">
				<label for="wpos-post-excerpt-lenght"><?php _e('Excerpt lenght', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<input type="number" name="wpos_options[excerpt_lenght]" value="<?php echo wpos_escape_attr( $excerpt_lenght ); ?>" id="wpos-post-excerpt-lenght" class="wpos-input-number wpos-post-excerpt-lenght" min="1" /><br/>
				<span class="description"><?php _e( 'Choose your excerpt length. Default is 55 words.', 'wpos-theme' ); ?></span>
			</td>
		</tr>
                
		<tr>
			<th scope="row">
				<label for="wpos-post-readmore-btn"><?php _e('Show Read More Button', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<div class="wpos-switch-box" id="wpos-switch-post-readmore-btn">
					<label data-val="1" data-id="wpos-post-readmore-btn" class="wpos-cb-enable <?php echo wpos_is_switch_enable($show_read_more,1);?>"> <?php _e('Enable','wpos-theme');?></label>
					<label data-val="0" data-id="wpos-post-readmore-btn" class="wpos-cb-disable <?php echo wpos_is_switch_enable($show_read_more,0);?>"> <?php _e('Disable','wpos-theme');?></label>
				</div>
				<input type="hidden" name="wpos_options[show_read_more]" class="wpos-checkbox wpos-post-full-cnt" id="wpos-post-readmore-btn" value=<?php echo $show_read_more; ?> /><br/>
				<span class="description"><?php _e( 'Show read more button or not.', 'wpos-theme' ); ?></span>
			</td>
		</tr>
                
		<tr>
			<th scope="row">
				<label for="wpos-post-readmore-text"><?php _e('Read More Text', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<input type="text" name="wpos_options[readmore_text]" value="<?php echo wpos_escape_attr( $readmore_text ); ?>" id="wpos-post-readmore-text" class="regular-text wpos-post-readmore-text" /><br/>
				<span class="description"><?php _e( 'Enter readmore button text.', 'wpos-theme' ); ?></span>
			</td>
		</tr>
                
                <!-- Link behaviour  -->
		<tr scope="row">
			<th scope="row">
				<label for="wpos-blog-layout"><?php _e('Link behaviour', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<select class="wpos-select-box wpos-blog-layout-type" name="wpos_options[link_behaviour]" id="blog-link-behaviour">
					<option value="_blank"    <?php selected( $link_behaviour, '_blank' ); ?>><?php _e('Blank', 'wpos-theme'); ?></option>
					<option value="_self"     <?php selected( $link_behaviour, '_self' ); ?>><?php _e('Self', 'wpos-theme'); ?></option>
				</select>
                            
                            <br/>
                            
				<span class="description"><?php _e('Select Link behaviour.', 'wpos-theme'); ?></span>
			</td>
		</tr>
                
		
                
		<tr>
			<th colspan="2">
				<div class="wpos-sub-sett-title"><?php _e('Post Meta Elements	 Dispaly Settings','wpos-theme');?></div>
			</th>
		</tr>
		<tr scope="row">
			<th scope="row">
				<label for="wpos-enable-post-author"><?php _e('Post Author', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<div class="wpos-switch-box" id="wpos-switch-enable-post-author">
					<label data-val="1" data-id="wpos-enable-post-author" class="wpos-cb-enable <?php echo wpos_is_switch_enable($enable_post_author,1);?>"> <?php _e('Enable','wpos-theme');?></label>
					<label data-val="0" data-id="wpos-enable-post-author" class="wpos-cb-disable <?php echo wpos_is_switch_enable($enable_post_author,0);?>"> <?php _e('Disable','wpos-theme');?></label>
				</div>
				<input type="hidden" name="wpos_options[enable_post_author]" class="wpos-checkbox wpos-enable-post-author" id="wpos-enable-post-author" value=<?php echo $enable_post_author; ?> /><br/>
				<span class="description"><?php _e('Check this box to display post author.', 'wpos-theme'); ?></span>
			</td>
		</tr>
		<tr scope="row">
			<th scope="row">
				<label for="wpos-enable-post-count"><?php _e('Post Comment Count', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<div class="wpos-switch-box" id="wpos-switch-enable-post-count">
					<label data-val="1" data-id="wpos-enable-post-count" class="wpos-cb-enable <?php echo wpos_is_switch_enable($enable_post_count,1);?>"> <?php _e('Enable','wpos-theme');?></label>
					<label data-val="0" data-id="wpos-enable-post-count" class="wpos-cb-disable <?php echo wpos_is_switch_enable($enable_post_count,0);?>"> <?php _e('Disable','wpos-theme');?></label>
				</div>
				<input type="hidden" name="wpos_options[enable_post_count]" class="wpos-checkbox wpos-enable-post-count" id="wpos-enable-post-count" value=<?php echo $enable_post_count; ?> /><br/>
				<span class="description"><?php _e('Check this box to display post count.', 'wpos-theme'); ?></span>
			</td>
		</tr>
		<tr scope="row">
			<th scope="row">
				<label for="wpos-enable-post-cat"><?php _e('Post Category', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<div class="wpos-switch-box" id="wpos-switch-enable-post-cat">
					<label data-val="1" data-id="wpos-enable-post-cat" class="wpos-cb-enable <?php echo wpos_is_switch_enable($enable_post_cat,1);?>"> <?php _e('Enable','wpos-theme');?></label>
					<label data-val="0" data-id="wpos-enable-post-cat" class="wpos-cb-disable <?php echo wpos_is_switch_enable($enable_post_cat,0);?>"> <?php _e('Disable','wpos-theme');?></label>
				</div>
				<input type="hidden" name="wpos_options[enable_post_cat]" class="wpos-checkbox wpos-enable-post-cat" id="wpos-enable-post-cat" value=<?php echo $enable_post_cat; ?> /><br/>
				<span class="description"><?php _e('Check this box to display post category.', 'wpos-theme'); ?></span>
			</td>
		</tr>
		<tr scope="row">
			<th scope="row">
				<label for="wpos-enable-post-date"><?php _e('Post Date', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<div class="wpos-switch-box" id="wpos-switch-enable-post-date">
					<label data-val="1" data-id="wpos-enable-post-date" class="wpos-cb-enable <?php echo wpos_is_switch_enable($enable_post_date,1);?>"> <?php _e('Enable','wpos-theme');?></label>
					<label data-val="0" data-id="wpos-enable-post-date" class="wpos-cb-disable <?php echo wpos_is_switch_enable($enable_post_date,0);?>"> <?php _e('Disable','wpos-theme');?></label>
				</div>
				<input type="hidden" name="wpos_options[enable_post_date]" class="wpos-checkbox wpos-enable-post-date" id="wpos-enable-post-date" value=<?php echo $enable_post_date; ?> /><br/>
				<span class="description"><?php _e('Check this box to display post date.', 'wpos-theme'); ?></span>
			</td>
		</tr>
		<tr scope="row">
			<th scope="row">
				<label for="wpos-enable-post-tag"><?php _e('Post Tag', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<div class="wpos-switch-box" id="wpos-switch-enable-post-tag">
					<label data-val="1" data-id="wpos-enable-post-tag" class="wpos-cb-enable <?php echo wpos_is_switch_enable($enable_post_tag,1);?>"> <?php _e('Enable','wpos-theme');?></label>
					<label data-val="0" data-id="wpos-enable-post-tag" class="wpos-cb-disable <?php echo wpos_is_switch_enable($enable_post_tag,0);?>"> <?php _e('Disable','wpos-theme');?></label>
				</div>
				<input type="hidden" name="wpos_options[enable_post_tag]" class="wpos-checkbox wpos-enable-post-tag" id="wpos-enable-post-tag" value=<?php echo $enable_post_tag; ?> /><br/>
				<span class="description"><?php _e('Check this box to display post tag.', 'wpos-theme'); ?></span>
			</td>
		</tr>
                
                <tr scope="row">
			<th scope="row">
				<label for="wpos-enable-post-formate"><?php _e('Post Format', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<div class="wpos-switch-box" id="wpos-switch-enable-post-formate">
					<label data-val="1" data-id="wpos-enable-post-formate" class="wpos-cb-enable <?php echo wpos_is_switch_enable($enable_post_formate,1);?>"> <?php _e('Enable','wpos-theme');?></label>
					<label data-val="0" data-id="wpos-enable-post-formate" class="wpos-cb-disable <?php echo wpos_is_switch_enable($enable_post_formate,0);?>"> <?php _e('Disable','wpos-theme');?></label>
				</div>
				<input type="hidden" name="wpos_options[enable_post_formate]" class="wpos-checkbox wpos-enable-post-formate" id="wpos-enable-post-formate" value=<?php echo $enable_post_formate; ?> /><br/>
				<span class="description"><?php _e('Check this box to display post formate icon.', 'wpos-theme'); ?></span>
			</td>
		</tr>
                
                
		<tr>
			<th colspan="2">
				<div class="wpos-sub-sett-title"><?php _e('Featured Image', 'wpos-theme'); ?></div>
			</th>
		</tr>

		<tr>
			<th scope="row">
				<label for="wpos-hide-indx-feat-img"><?php _e('Hide Featured Image', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<div class="wpos-switch-box" id="wpos-switch-hide-indx-feat-img">
					<label data-val="1" data-id="wpos-hide-indx-feat-img" class="wpos-cb-enable <?php echo wpos_is_switch_enable($hide_indx_feat_img,1);?>"> <?php _e('Enable','wpos-theme');?></label>
					<label data-val="0" data-id="wpos-hide-indx-feat-img" class="wpos-cb-disable <?php echo wpos_is_switch_enable($hide_indx_feat_img,0);?>"> <?php _e('Disable','wpos-theme');?></label>
				</div>
				<input type="hidden" name="wpos_options[hide_indx_feat_img]" class="wpos-checkbox wpos-hide-indx-feat-img" id="wpos-hide-indx-feat-img" value=<?php echo $hide_indx_feat_img; ?> /><br/>
				<span class="description"><?php _e( 'Check this box to hide featured images.', 'wpos-theme' ); ?></span>
			</td>
		</tr>

		
	</table>

<?php } ?>
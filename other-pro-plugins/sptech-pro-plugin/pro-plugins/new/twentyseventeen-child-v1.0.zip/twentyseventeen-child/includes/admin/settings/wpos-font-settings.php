<?php
/**
 * Font Settings
 *
 * @package WP Clean Responsive
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// Action to add font options
add_action( 'wpos_tab_content_font_options', 'wpos_tab_content_font_options' );

/**
 * Function to add Font Settings
 * 
 * @package WP Clean Responsive
 * @since 1.0
 */
function wpos_tab_content_font_options() {
    
	global $wpos_options, $wp_version;
        
	$wpos_web_fonts 		= wpos_web_fonts();
	$wpos_google_fonts		= wpos_google_fonts();
	$body_web_font_cls 		= (wpos_get_option('body_font_type') == 'standard') ? '' : 'wpos-hide';
	$body_google_font_cls           = (wpos_get_option('body_font_type') == 'google') 	? '' : 'wpos-hide';
	$heading_web_font_cls 		= (wpos_get_option('heading_font_type') == 'standard') 	? '' : 'wpos-hide';
	$heading_google_font_cls	= (wpos_get_option('heading_font_type') == 'google') 	? '' : 'wpos-hide';
	$navigation_web_font_cls 	= (wpos_get_option('navigation_font_type') == 'standard') 	? '' : 'wpos-hide';
	$navigation_google_font_cls	= (wpos_get_option('navigation_font_type') == 'google') 	? '' : 'wpos-hide';
        
        
	$body_font_type	= wpos_get_option('body_font_type','standard');
	$body_font_size	= wpos_get_option('body_font_size');
	$body_line_height	= wpos_get_option('body_line_height');
	$navigation_font_size	= wpos_get_option('navigation_font_size');
        
        
?>
	<h2><?php _e('Font Options', 'wpos-theme'); ?></h2>

	<table class="form-table">

		<!-- Body Font Starts -->
		<tr>
			<th colspan="2">
				<div class="wpos-sub-sett-title"><?php _e('Body Font Options', 'wpos-theme'); ?></div>
			</th>
		</tr>

		<tr scope="row">
			<th scope="row">
				<label for="wpos-body-font-type"><?php _e('Body Font Type', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<input type="radio" name="wpos_options[body_font_type]" value="standard" class="wpos-body-font-type wpos-clickbox" id="wpos-body-font-type" <?php checked( $body_font_type, 'standard' ); ?> data-label="body-web-font" /> <label for="wpos-body-font-type" class="wpos-radio-lbl"><?php _e('Standard', 'wpos-theme'); ?></label>
				<input type="radio" name="wpos_options[body_font_type]" value="google" class="wpos-body-font-type wpos-clickbox" id="wpos-body-font-type-google" <?php checked( $body_font_type, 'google' ); ?> data-label="body-google-font" /> <label for="wpos-body-font-type-google" class="wpos-radio-lbl"><?php _e('Google', 'wpos-theme'); ?></label> <br/>
                                
				<span class="description"><?php _e( 'Choose the type of font that you want to use for the body text.', 'wpos-theme' ); ?></span>
			</td>
		</tr>

		<!-- Body Standard Font -->
		<tr class="show-if-body-web-font hide-if-body-google-font <?php echo $body_web_font_cls; ?>">
			<th scope="row">
				<label for="wpos-body-web-font"><?php _e('Body Standard Font', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<select name="wpos_options[body_web_font]" class="wpos-select-box wpos-body-web-font" id="wpos-body-web-font">
					<?php
					if(!empty($wpos_web_fonts)) {
						foreach ($wpos_web_fonts as $body_web_font_key => $body_web_font_val) {
							echo "<option value='{$body_web_font_val}' ".selected( $wpos_options['body_web_font'], $body_web_font_val, false )." >{$body_web_font_val}</option>";
						}
					}
					?>
				</select><br/>
				<span class="description"><?php _e( 'Choose the type of font that you want to use for the body text.', 'wpos-theme' ); ?></span>
			</td>
		</tr>

		<!-- Body Google Font -->
		<tr class="show-if-body-google-font hide-if-body-web-font <?php echo $body_google_font_cls; ?>">
			<th scope="row">
				<label for="wpos-body-google-font"><?php _e('Body Google Font', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<select name="wpos_options[body_google_font]" class="wpos-select-box wpos-body-google-font" id="wpos-body-google-font">
					<?php
					if(!empty($wpos_google_fonts)) {

						foreach ($wpos_google_fonts as $body_google_font_key => $body_google_font_val) {

							if( is_array($body_google_font_val) ){

								echo "<optgroup label='{$body_google_font_key}'>";

								foreach ($body_google_font_val as $sub_font_key => $sub_font_val) {
									echo "<option value='{$sub_font_key}' ".selected( $wpos_options['body_google_font'], $sub_font_key, false )." >{$sub_font_val}</option>";
								}

								echo "</optgroup>";

							} else {
								echo "<option value='{$body_google_font_key}' ".selected( $wpos_options['body_google_font'], $body_google_font_key, false )." >{$body_google_font_val}</option>";
							}
						}
					}
					?>
				</select><br/>
				<span class="description"><?php _e( 'Choose the type of font that you want to use for the body text.', 'wpos-theme' ); ?></span>
			</td>
		</tr>

		<!-- Body Font Size -->		
		<tr>
			<th scope="row">
				<label for="wpos-body-font-size"><?php _e('Body Font Size', 'wpos-theme'); ?></label>
			</th>
			<td>			
				<div id="wpos-body-font-size-slider" style="display: inline-block; width: 40%; margin-right: 25px;"></div>
				<input name="wpos_options[body_font_size]" value="<?php echo $body_font_size; ?>" class="wpos-body-font-size" id="wpos-body-font-size" type="text" readonly="true" style="width:40px; text-align:center;"> <label for="wpos-body-font-size"><?php _e('Px', 'wpos-theme'); ?>
				<br/>
				<span class="description"><?php _e( 'Select the size of the body font.', 'wpos-theme' ); ?></span>

			</td>
			<script>
		jQuery(document).ready(function(){
			jQuery( "#wpos-body-font-size-slider" ).slider({
				value 	: jQuery( "#wpos-body-font-size" ).val(),
				min 	: 1,
				max 	:100,
				step 	: 1,
				slide 	: function( event, ui ) {
			      			jQuery( "#wpos-body-font-size" ).val( ui.value );
						 }
			});
			jQuery( "#wpos-body-font-size" ).keyup( function(){
			     jQuery( "#wpos-body-font-size-slider" ).slider( "value", jQuery(this).val() );
			});
			
		});
		</script>
		</tr>
		<!-- Body Font Line Height -->
		<tr>
			<th scope="row">
				<label for="wpos-body-line-height"><?php _e('Body Font Line Height', 'wpos-theme'); ?></label>
			</th>
			<td>			
				<div id="wpos-body-line-height-slider" style="display: inline-block; width: 40%; margin-right: 25px;"></div>
				<input name="wpos_options[body_line_height]" value="<?php echo $body_line_height; ?>" class="wpos-body-line-height" id="wpos-body-line-height" type="text" readonly="true" style="width:40px; text-align:center;"> <label for="wpos-body-line-height"><?php _e('Px', 'wpos-theme'); ?>
				<br/>
				<span class="description"><?php _e( 'Select the appropriate line height of body font.', 'wpos-theme' ); ?></span>

			</td>
			<script>
		jQuery(document).ready(function(){
			jQuery( "#wpos-body-line-height-slider" ).slider({
				value 	: jQuery( "#wpos-body-line-height" ).val(),
				min 	: 1,
				max 	:100,
				step 	: 1,
				slide 	: function( event, ui ) {
			      			jQuery( "#wpos-body-line-height" ).val( ui.value );
						 }
			});
			jQuery( "#wpos-body-line-height" ).keyup( function(){
			     jQuery( "#wpos-body-line-height-slider" ).slider( "value", jQuery(this).val() );
			});
			
		});
		</script>
		</tr>

		<!-- Body Font Ends -->

		<!-- Navigation Font Starts -->
		<tr>
			<th colspan="2">
				<div class="wpos-sub-sett-title"><?php _e('Navigation Font Options', 'wpos-theme'); ?></div>
			</th>
		</tr>

		<!-- Navigation Font Type Starts -->
		<tr scope="row">
			<th scope="row">
				<label for="wpos-navigation-font-type"><?php _e('Navigation Font Type', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<input type="radio" name="wpos_options[navigation_font_type]" value="" class="wpos-navigation-font-none wpos-clickbox" id="wpos-navigation-font-none" <?php checked( wpos_get_option('navigation_font_type'), '' ); ?> data-label="navigation-font-none" /> <label for="wpos-navigation-font-none" class="wpos-radio-lbl"><?php _e('Inherit From Body', 'wpos-theme'); ?></label>
				<input type="radio" name="wpos_options[navigation_font_type]" value="standard" class="wpos-navigation-font-type wpos-clickbox" id="wpos-navigation-font-type" <?php checked( wpos_get_option('navigation_font_type'), 'standard' ); ?> data-label="navigation-web-font" /> <label for="wpos-navigation-font-type" class="wpos-radio-lbl"><?php _e('Standard', 'wpos-theme'); ?></label>
				<input type="radio" name="wpos_options[navigation_font_type]" value="google" class="wpos-navigation-font-type wpos-clickbox" id="wpos-navigation-font-type-google" <?php checked( wpos_get_option('navigation_font_type'), 'google' ); ?> data-label="navigation-google-font" /> <label for="wpos-navigation-font-type-google" class="wpos-radio-lbl"><?php _e('Google', 'wpos-theme'); ?></label> <br/>
				<span class="description"><?php _e( 'Choose the type of font that you want to use for the navigation text.', 'wpos-theme' ); ?></span>
			</td>
		</tr>

		<!-- Navigation Web Font Starts -->
		<tr class="show-if-navigation-web-font hide-if-navigation-font-none hide-if-navigation-google-font <?php echo $navigation_web_font_cls; ?>">
			<th scope="row">
				<label for="wpos-navigation-web-font"><?php _e('Navigation Standard Font', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<select name="wpos_options[navigation_web_font]" class="wpos-select-box wpos-navigation-web-font" id="wpos-navigation-web-font">
					<?php
					if(!empty($wpos_web_fonts)) {
						foreach ($wpos_web_fonts as $web_font_key => $web_font_val) {
							echo "<option value='{$web_font_val}' ".selected( wpos_get_option('navigation_web_font'), $web_font_val, false )." >{$web_font_val}</option>";
						}
					}
					?>
				</select><br/>
				<span class="description"><?php _e( 'Choose the type of font that you want to use for the navigation text.', 'wpos-theme' ); ?></span>
			</td>
		</tr>

		<!-- Navigation Google Font Starts -->
		<tr class="show-if-navigation-google-font hide-if-navigation-font-none hide-if-navigation-web-font <?php echo $navigation_google_font_cls; ?>">
			<th scope="row">
				<label for="wpos-navigation-google-font"><?php _e('Navigation Google Font', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<select name="wpos_options[navigation_google_font]" class="wpos-select-box wpos-navigation-google-font" id="wpos-navigation-google-font">
					<?php
					if(!empty($wpos_google_fonts)) {

						foreach ($wpos_google_fonts as $google_font_key => $google_font_val) {

							if( is_array($google_font_val) ) {

								echo "<optgroup label='{$google_font_key}'>";

								foreach ($google_font_val as $sub_font_key => $sub_font_val) {
									echo "<option value='{$sub_font_key}' ".selected( wpos_get_option('navigation_google_font'), $sub_font_key, false )." >{$sub_font_val}</option>";
								}

								echo "</optgroup>";

							} else {
								echo "<option value='{$google_font_key}' ".selected( wpos_get_option('navigation_google_font'), $google_font_key, false )." >{$google_font_val}</option>";
							}
						}
					}
					?>
				</select><br/>
				<span class="description"><?php _e( 'Choose the type of font that you want to use for the navigation text.', 'wpos-theme' ); ?></span>
			</td>
		</tr>

		<!-- Navigation Font Size -->
		

		<tr>
			<th scope="row">
				<label for="wpos-navigation-font-size"><?php _e('Navigation Font Size', 'wpos-theme'); ?></label>
			</th>
			<td>			
				<div id="wpos-navigation-font-size-slider" style="display: inline-block; width: 40%; margin-right: 25px;"></div>
				<input name="wpos_options[navigation_font_size]" value="<?php echo $navigation_font_size; ?>" class="wpos-navigation-font-size" id="wpos-navigation-font-size" type="text" readonly="true" style="width:40px; text-align:center;"> <label for="wpos-navigation-font-size"><?php _e('Px', 'wpos-theme'); ?>
				<br/>
				<span class="description"><?php _e( 'Select the size of the navigation font. Leave empty to inherit it from body option.', 'wpos-theme' ); ?></span>

			</td>
			<script>
		jQuery(document).ready(function(){
			jQuery( "#wpos-navigation-font-size-slider" ).slider({
				value 	: jQuery( "#wpos-navigation-font-size" ).val(),
				min 	: 1,
				max 	:100,
				step 	: 1,
				slide 	: function( event, ui ) {
			      			jQuery( "#wpos-navigation-font-size" ).val( ui.value );
						 }
			});
			jQuery( "#wpos-navigation-font-size" ).keyup( function(){
			     jQuery( "#wpos-navigation-font-size-slider" ).slider( "value", jQuery(this).val() );
			});
			
		});
		</script>
		</tr>
		
		<!-- Heading Font Starts -->
		<tr>
			<th colspan="2">
				<div class="wpos-sub-sett-title"><?php _e('Heading Font Options', 'wpos-theme'); ?></div>
			</th>
		</tr>

		<!-- Heading Font Type Starts -->
		<tr scope="row">
			<th scope="row">
				<label for="wpos-heading-font-type"><?php _e('Heading Font Type', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<input type="radio" name="wpos_options[heading_font_type]" value="" class="wpos-heading-font-none wpos-clickbox" id="wpos-heading-font-none" <?php checked( wpos_get_option('heading_font_type'), '' ); ?> data-label="heading-font-none" /> <label for="wpos-heading-font-none" class="wpos-radio-lbl"><?php _e('Inherit From Body', 'wpos-theme'); ?></label>
				<input type="radio" name="wpos_options[heading_font_type]" value="standard" class="wpos-heading-font-type wpos-clickbox" id="wpos-heading-font-type" <?php checked( wpos_get_option('heading_font_type'), 'standard' ); ?> data-label="heading-web-font" /> <label for="wpos-heading-font-type" class="wpos-radio-lbl"><?php _e('Standard', 'wpos-theme'); ?></label>
				<input type="radio" name="wpos_options[heading_font_type]" value="google" class="wpos-heading-font-type wpos-clickbox" id="wpos-heading-font-type-google" <?php checked( wpos_get_option('heading_font_type'), 'google' ); ?> data-label="heading-google-font" /> <label for="wpos-heading-font-type-google" class="wpos-radio-lbl"><?php _e('Google', 'wpos-theme'); ?></label> <br/>
				<span class="description"><?php _e( 'Choose the type of font that you want to use for the heading text.', 'wpos-theme' ); ?></span>
			</td>
		</tr>

		<!-- Heading Web Font Starts -->
		<tr class="show-if-heading-web-font hide-if-heading-font-none hide-if-heading-google-font <?php echo $heading_web_font_cls; ?>">
			<th scope="row">
				<label for="wpos-heading-web-font"><?php _e('Heading Standard Font', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<select name="wpos_options[heading_web_font]" class="wpos-select-box wpos-heading-web-font" id="wpos-heading-web-font">
					<?php
					if(!empty($wpos_web_fonts)) {
						foreach ($wpos_web_fonts as $web_font_key => $web_font_val) {
							echo "<option value='{$web_font_val}' ".selected( wpos_get_option('heading_web_font'), $web_font_val, false )." >{$web_font_val}</option>";
						}
					}
					?>
				</select><br/>
				<span class="description"><?php _e( 'Choose the type of font that you want to use for the heading text.', 'wpos-theme' ); ?></span>
			</td>
		</tr>

		<!-- Heading Google Font Starts -->
		<tr class="show-if-heading-google-font hide-if-heading-font-none hide-if-heading-web-font <?php echo $heading_google_font_cls; ?>">
			<th scope="row">
				<label for="wpos-heading-google-font"><?php _e('Heading Google Font', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<select name="wpos_options[heading_google_font]" class="wpos-select-box wpos-heading-google-font" id="wpos-heading-google-font">
					<?php
					if(!empty($wpos_google_fonts)) {

						foreach ($wpos_google_fonts as $google_font_key => $google_font_val) {

							if( is_array($google_font_val) ) {

								echo "<optgroup label='{$google_font_key}'>";

								foreach ($google_font_val as $sub_font_key => $sub_font_val) {
									echo "<option value='{$sub_font_key}' ".selected( wpos_get_option('heading_google_font'), $sub_font_key, false )." >{$sub_font_val}</option>";
								}

								echo "</optgroup>";

							} else {
								echo "<option value='{$google_font_key}' ".selected( wpos_get_option('heading_google_font'), $google_font_key, false )." >{$google_font_val}</option>";
							}
						}
					}
					?>
				</select><br/>
				<span class="description"><?php _e( 'Choose the type of font that you want to use for the heading text.', 'wpos-theme' ); ?></span>
			</td>
		</tr>

	</table>

<?php } ?>
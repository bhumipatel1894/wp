<?php
/**
 * Footer Settings
 *
 * @package WP Clean Responsive
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// Action to add footer options
add_action( 'wpos_tab_content_footer_options', 'wpos_tab_content_footer_options' );

/**
 * Function to add footer settings
 * 
 * @package WP Clean Responsive
 * @since 1.0
 */
function wpos_tab_content_footer_options() {
	global $wpos_options;

	$footer_layout = wpos_get_option('footer_layout','light') ;
	$enable_fwdgt_cls 	= ( wpos_get_option('enable_fwdgt') == 1 ) 		? '' : 'wpos-hide';
	$copyright_cls 		= ( wpos_get_option('enable_copyright') == 1 ) 	? '' : 'wpos-hide';
	$enable_fwdgt = wpos_get_option('enable_fwdgt',0) ;
	$enable_copyright = wpos_get_option('enable_copyright',0) ;
	$enable_goto_top = wpos_get_option('enable_goto_top',0) ;
	$social_media_footer = wpos_get_option('social_media_footer',0) ;
	$copyright_text = wpos_get_option('copyright_text') ;

?>
	<h2><?php _e('Footer Options', 'wpos-theme'); ?></h2>
	<table class="form-table">

		<tr>
			<th scope="row">
				<label for="wpos-footer-layout"><?php _e('Footer Layout', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<select name="wpos_options[footer_layout]" class="wpos-select-box wpos-footer-layout" id="wpos-footer-layout">
					<option value="1" <?php selected( wpos_get_option('light'), 1 ); ?>><?php _e('Light', 'wpos-theme'); ?></option>
					<option value="2" <?php selected( wpos_get_option('dark'), 2 ); ?>><?php _e('Dark', 'wpos-theme'); ?></option>
				</select>
			</td>
		</tr>

		<tr>
			<th scope="row">
				<label for="wpos-enable-footer-wdgt"><?php _e('Enable Footer Widget', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<div class="wpos-switch-box" id="wpos-switch-enable-footer-wdgt">
					<label data-val="1" data-id="wpos-enable-footer-wdgt" class="wpos-cb-enable <?php echo wpos_is_switch_enable($enable_fwdgt,1);?>"> <?php _e('Enable','wpos-theme');?></label>
					<label data-val="0" data-id="wpos-enable-footer-wdgt" class="wpos-cb-disable <?php echo wpos_is_switch_enable($enable_fwdgt,0);?>"> <?php _e('Disable','wpos-theme');?></label>
				</div>
				<input type="hidden" name="wpos_options[enable_fwdgt]" class="wpos-checkbox wpos-enable-footer-wdgt" id="wpos-enable-footer-wdgt" value=<?php echo $enable_fwdgt; ?> /><br/>
				<span class="description"><?php _e( 'Check this box to display footer widget.', 'wpos-theme' ); ?></span>
			</td>
		</tr>

		<tr class="show-if-enable-fwdgt <?php echo $enable_fwdgt_cls; ?>">
			<th scope="row">
				<label for="wpos-footer-clmn"><?php _e('Footer Widget Column', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<select name="wpos_options[footer_clmn]" class="wpos-select-box wpos-footer-clmn" id="wpos-footer-clmn">
					<option value="1" <?php selected( wpos_get_option('footer_clmn'), 1 ); ?>><?php _e('Column 1', 'wpos-theme'); ?></option>
					<option value="2" <?php selected( wpos_get_option('footer_clmn'), 2 ); ?>><?php _e('Column 2', 'wpos-theme'); ?></option>
					<option value="3" <?php selected( wpos_get_option('footer_clmn'), 3 ); ?>><?php _e('Column 3', 'wpos-theme'); ?></option>
					<option value="4" <?php selected( wpos_get_option('footer_clmn'), 4 ); ?>><?php _e('Column 4', 'wpos-theme'); ?></option>
				</select>
			</td>
		</tr>

		<tr>
			<th scope="row">
				<label for="wpos-enable-copyright"><?php _e('Enable Copyright', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<div class="wpos-switch-box" id="wpos-switch-enable-copyright">
					<label data-val="1" data-id="wpos-enable-copyright" data-label="enable-copyright" class="wpos-cb-enable <?php echo wpos_is_switch_enable($enable_copyright,1);?>"> <?php _e('Enable','wpos-theme');?></label>
					<label data-val="0" data-id="wpos-enable-copyright" data-label="enable-copyright" class="wpos-cb-disable <?php echo wpos_is_switch_enable($enable_copyright,0);?>"> <?php _e('Disable','wpos-theme');?></label>
				</div>
				<input type="hidden" name="wpos_options[enable_copyright]" class="wpos-checkbox wpos-enable-copyright" id="wpos-enable-copyright" value=<?php echo $enable_copyright; ?> /><br/>
				<span class="description"><?php _e( 'Check this box to enable the footer copyright section.', 'wpos-theme' ); ?></span>
			</td>
		</tr>

		<tr class="show-if-enable-copyright <?php echo $copyright_cls; ?>">
			<th><label for="wpos-copy-right-text"><?php _e('Copyright Text', 'wpos-theme') ?></label></th>
			<td>
				<textarea name="wpos_options[copyright_text]" class="wpos-textarea large-text wpos-copy-right-text" id="wpos-copy-right-text" rows="6"><?php echo wpos_escape_attr( $copyright_text ); ?></textarea><br/>
				<span class="description">
					<?php
					echo __('Enter the text that display in the copyright bar. HTML markup can be used. Available template tags are:', 'wpos-theme') . "<br/>" .
					"<code>{year}</code> - " . __('Displays current year.', 'wpos-theme');
					?>
				</span>
			</td>
		</tr>

		<tr>
			<th scope="row">
				<label for="wpos-enable-goto-top"><?php _e('Enable Go To Top', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<div class="wpos-switch-box" id="wpos-switch-enable-goto-top">
					<label data-val="1" data-id="wpos-enable-goto-top" class="wpos-cb-enable <?php echo wpos_is_switch_enable($enable_goto_top,1);?>"> <?php _e('Enable','wpos-theme');?></label>
					<label data-val="0" data-id="wpos-enable-goto-top" class="wpos-cb-disable <?php echo wpos_is_switch_enable($enable_goto_top,0);?>"> <?php _e('Disable','wpos-theme');?></label>
				</div>
				<input type="hidden" name="wpos_options[enable_goto_top]" class="wpos-checkbox wpos-enable-goto-top" id="wpos-enable-goto-top" value=<?php echo $enable_goto_top; ?> /><br/>
				<span class="description"><?php _e( 'Check this box if you want to enable the go to top in the bottom right of the footer.', 'wpos-theme' ); ?></span>
			</td>
		</tr>

		<tr>
			<th scope="row">
				<label for="wpos-social-media-footer"><?php _e('Display Social Icon on Footer', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<div class="wpos-switch-box" id="wpos-switch-social-media-footer">
					<label data-val="1" data-id="wpos-social-media-footer" class="wpos-cb-enable <?php echo wpos_is_switch_enable($social_media_footer,1);?>"> <?php _e('Enable','wpos-theme');?></label>
					<label data-val="0" data-id="wpos-social-media-footer" class="wpos-cb-disable <?php echo wpos_is_switch_enable($social_media_footer,0);?>"> <?php _e('Disable','wpos-theme');?></label>
				</div>
				<input type="hidden" name="wpos_options[social_media_footer]" class="wpos-checkbox wpos-social-media-footer" id="wpos-social-media-footer" value=<?php echo $social_media_footer; ?> /><br/>
				<span class="description"><?php _e( 'Check this box if you want to display the social media icon on the footer of the page.', 'wpos-theme' ); ?></span>
			</td>
		</tr>
	</table>

<?php } ?>
<?php
/**
 * Blog Page settings
 *
 * @package WP Clean Responsive
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// Action to add Home Page settings
add_action( 'wpos_tab_content_post_page_options', 'wpos_tab_content_post_page_options' );

/**
 * Function to Home Page settings
 * 
 * @package WP Clean Responsive
 * @since 1.0
 */
function wpos_tab_content_post_page_options() {

	$enable_rp_post		= wpos_get_option('enable_rp_post',0);
	$enable_fp_page		= wpos_get_option('enable_full_post_page',0);
	$enable_single_post_author	= wpos_get_option('enable_single_post_author');
	$enable_single_post_count 	= wpos_get_option('enable_single_post_count',0);
	$enable_single_post_cat 	= wpos_get_option('enable_single_post_cat',0);
	$enable_single_post_date 	= wpos_get_option('enable_single_post_date');
	$enable_single_post_tag 	= wpos_get_option('enable_single_post_tag',0);
        $hide_single_feat_img                   = wpos_get_option('hide_single_feat_img',0);
?>
	<h2><?php _e('Single Blog Page Options', 'wpos-theme'); ?></h2>

	<table class="form-table">

		<!-- Related Posts -->
		<tr scope="row">
			<th scope="row">
				<label for="wpos-enable-single-rp-post"><?php _e('Enable Related Posts', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<div class="wpos-switch-box" id="wpos-switch-wpos-enable-single-rp-post">
					<label data-val="1" data-id="wpos-enable-single-rp-post" class="wpos-cb-enable <?php echo wpos_is_switch_enable($enable_rp_post,1);?>"> <?php _e('Enable','wpos-theme');?></label>
					<label data-val="0" data-id="wpos-enable-single-rp-post" class="wpos-cb-disable <?php echo wpos_is_switch_enable($enable_rp_post,0);?>"> <?php _e('Disable','wpos-theme');?></label>
				</div>
				<input type="hidden" name="wpos_options[enable_rp_post]" class="wpos-checkbox wpos-enable-single-rp-post" id="wpos-enable-single-rp-post" value=<?php echo $enable_rp_post; ?> /><br/>
				<span class="description"><?php _e('Check this box to enable related posts section on single post page.', 'wpos-theme'); ?></span>
			</td>
		</tr>

		<!-- Full Page -->
		<tr scope="row">
			<th scope="row">
				<label for="wpos-enable-single-full-post-page"><?php _e('Enable Full Page Layout', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<div class="wpos-switch-box" id="wpos-switch-enable-single-full-post-page">
					<label data-val="1" data-id="wpos-enable-single-full-post-page" class="wpos-cb-enable <?php echo wpos_is_switch_enable($enable_fp_page,1);?>"> <?php _e('Enable','wpos-theme');?></label>
					<label data-val="0" data-id="wpos-enable-single-full-post-page" class="wpos-cb-disable <?php echo wpos_is_switch_enable($enable_fp_page,0);?>"> <?php _e('Disable','wpos-theme');?></label>
				</div>
				<input type="hidden" name="wpos_options[enable_full_post_page]" class="wpos-checkbox wpos-enable-single-full-post-page" id="wpos-enable-single-full-post-page" value=<?php echo $enable_fp_page; ?> /><br/>
				<span class="description"><?php _e('Check this box to enable full page layout for single post page.', 'wpos-theme'); ?></span>
			</td>
		</tr>

		<tr>
			<th colspan="2">
				<div class="wpos-sub-sett-title"><?php _e('Post Meta Elements	 Dispaly Settings','wpos-theme');?></div>
			</th>
		</tr>
		<tr scope="row">
			<th scope="row">
				<label for="wpos-enable-single-post-author"><?php _e('Post Author', 'wpos-theme'); ?>:</label>
			</th>
			<td>				
				<div class="wpos-switch-box" id="wpos-switch-enable-single-post-author">
					<label data-val="1" data-id="wpos-enable-single-post-author" class="wpos-cb-enable <?php echo wpos_is_switch_enable($enable_single_post_author,1);?>"> <?php _e('Enable','wpos-theme');?></label>
					<label data-val="0" data-id="wpos-enable-single-post-author" class="wpos-cb-disable <?php echo wpos_is_switch_enable($enable_single_post_author,0);?>"> <?php _e('Disable','wpos-theme');?></label>
				</div>
				<input type="hidden" name="wpos_options[enable_single_post_author]" class="wpos-checkbox wpos-enable-single-post-author" id="wpos-enable-single-post-author" value=<?php echo $enable_single_post_author; ?> /><br/>
				<span class="description"><?php _e('Check this box to display post author on single post page.', 'wpos-theme'); ?></span>
			</td>
		</tr>
		<tr scope="row">
			<th scope="row">
				<label for="wpos-enable-single-post-count"><?php _e('Post Comment Count', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<div class="wpos-switch-box" id="wpos-switch-enable-single-post-count">
					<label data-val="1" data-id="wpos-enable-single-post-count" class="wpos-cb-enable <?php echo wpos_is_switch_enable($enable_single_post_count,1);?>"> <?php _e('Enable','wpos-theme');?></label>
					<label data-val="0" data-id="wpos-enable-single-post-count" class="wpos-cb-disable <?php echo wpos_is_switch_enable($enable_single_post_count,0);?>"> <?php _e('Disable','wpos-theme');?></label>
				</div>
				<input type="hidden" name="wpos_options[enable_single_post_count]" class="wpos-checkbox wpos-enable-single-post-count" id="wpos-enable-single-post-count" value=<?php echo $enable_single_post_count; ?> /><br/>
				<span class="description"><?php _e('Check this box to display post count on single post page.', 'wpos-theme'); ?></span>
			</td>
		</tr>
		<tr scope="row">
			<th scope="row">
				<label for="wpos-enable-single-post-cat"><?php _e('Post Category', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<div class="wpos-switch-box" id="wpos-switch-enable-single-post-cat">
					<label data-val="1" data-id="wpos-enable-single-post-cat" class="wpos-cb-enable <?php echo wpos_is_switch_enable($enable_single_post_cat,1);?>"> <?php _e('Enable','wpos-theme');?></label>
					<label data-val="0" data-id="wpos-enable-single-post-cat" class="wpos-cb-disable <?php echo wpos_is_switch_enable($enable_single_post_cat,0);?>"> <?php _e('Disable','wpos-theme');?></label>
				</div>
				<input type="hidden" name="wpos_options[enable_single_post_cat]" class="wpos-checkbox wpos-enable-single-post-cat" id="wpos-enable-single-post-cat" value=<?php echo $enable_single_post_cat; ?> /><br/>
				<span class="description"><?php _e('Check this box to display post category on single post page.', 'wpos-theme'); ?></span>
			</td>
		</tr>
		<tr scope="row">
			<th scope="row">
				<label for="wpos-enable-single-post-date"><?php _e('Post Date', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<div class="wpos-switch-box" id="wpos-switch-enable-single-post-date">
					<label data-val="1" data-id="wpos-enable-single-post-date" class="wpos-cb-enable <?php echo wpos_is_switch_enable($enable_single_post_date,1);?>"> <?php _e('Enable','wpos-theme');?></label>
					<label data-val="0" data-id="wpos-enable-single-post-date" class="wpos-cb-disable <?php echo wpos_is_switch_enable($enable_single_post_date,0);?>"> <?php _e('Disable','wpos-theme');?></label>
				</div>
				<input type="hidden" name="wpos_options[enable_single_post_date]" class="wpos-checkbox wpos-enable-single-post-date" id="wpos-enable-single-post-date" value=<?php echo $enable_single_post_date; ?> /><br/>
				<span class="description"><?php _e('Check this box to display post date on single post page.', 'wpos-theme'); ?></span>
			</td>
		</tr>
		<tr scope="row">
			<th scope="row">
				<label for="wpos-enable-single-post-tag"><?php _e('Post Tag', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<div class="wpos-switch-box" id="wpos-switch-enable-single-post-tag">
					<label data-val="1" data-id="wpos-enable-single-post-tag" class="wpos-cb-enable <?php echo wpos_is_switch_enable($enable_single_post_tag,1);?>"> <?php _e('Enable','wpos-theme');?></label>
					<label data-val="0" data-id="wpos-enable-single-post-tag" class="wpos-cb-disable <?php echo wpos_is_switch_enable($enable_single_post_tag,0);?>"> <?php _e('Disable','wpos-theme');?></label>
				</div>
				<input type="hidden" name="wpos_options[enable_single_post_tag]" class="wpos-checkbox wpos-enable-single-post-tag" id="wpos-enable-single-post-tag" value=<?php echo $enable_single_post_tag; ?> /><br/>
				<span class="description"><?php _e('Check this box to display post tag on single post page.', 'wpos-theme'); ?></span>
			</td>
		</tr>
                
                <tr>
			<th colspan="2">
				<div class="wpos-sub-sett-title"><?php _e('Featured Image', 'wpos-theme'); ?></div>
			</th>
		</tr>

		

		<tr>
			<th scope="row">
				<label for="wpos-hide-single-feat-img"><?php _e('Hide Single Page Featured Image', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<div class="wpos-switch-box" id="wpos-switch-hide-single-feat-img">
					<label data-val="1" data-id="wpos-hide-single-feat-img" class="wpos-cb-enable <?php echo wpos_is_switch_enable($hide_single_feat_img,1);?>"> <?php _e('Enable','wpos-theme');?></label>
					<label data-val="0" data-id="wpos-hide-single-feat-img" class="wpos-cb-disable <?php echo wpos_is_switch_enable($hide_single_feat_img,0);?>"> <?php _e('Disable','wpos-theme');?></label>
				</div>
				<input type="hidden" name="wpos_options[hide_single_feat_img]" class="wpos-checkbox wpos-hide-single-feat-img" id="wpos-hide-single-feat-img" value=<?php echo $hide_single_feat_img; ?> /><br/>
				<span class="description"><?php _e( 'Check this box to hide featured images.', 'wpos-theme' ); ?></span>
			</td>
		</tr>
	</table>

<?php } ?>
<?php
/**
 * Social Settings
 *
 * @package WP Clean Responsive
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// Action to add social profile options
add_action( 'wpos_tab_content_social_options', 'wpos_tab_content_social_options' );

/**
 * Function to add footer settings
 * 
 * @package WP Clean Responsive
 * @since 1.0
 */
function wpos_tab_content_social_options() {
	global $wpos_options;
	//$social_data = wpos_get_option('social',array());
	
	$site_desc_cls = !empty($wpos_options['site_title_base']) ? '' : 'wpos-hide';
	$social_links = wpos_social_links();
	$wpos_social_options = wpos_get_option('social',array());	

	if(!empty($wpos_social_options)){
		$social_links['social'] = wpos_social_link_merge($wpos_social_options,$social_links['social']);
	}
?>
	<h2><?php _e('Social Profiles', 'wpos-theme'); ?></h2>

	<table class="form-table wpos-social-sort" >
		<tbody>
		<?php 

		foreach ($social_links['social'] as $social_key => $links_data) {
		?>
		<tr>
			<th scope="row">
				<span class="handle"><i class="dashicons dashicons-move"></i></span>
				<label for="wpos-<?php echo $social_key;?>"><?php echo $links_data['label'] ?>:</label>
			</th>
			<td>
				<input type="text" name="wpos_options[social][<?php echo $social_key?>]" value="<?php if(isset($wpos_social_options[$social_key])) echo wpos_escape_attr( $wpos_social_options[$social_key] ); ?>" class="large-text wpos-<?php echo $social_key;?>" id="wpos-<?php echo $social_key;?>" /><br/>
				<span class="description"><?php echo $links_data['description']; ?></span>
			</td>
		</tr>
		<?php
		}
		?>
		</tbody>
		
	</table>

<?php } ?>
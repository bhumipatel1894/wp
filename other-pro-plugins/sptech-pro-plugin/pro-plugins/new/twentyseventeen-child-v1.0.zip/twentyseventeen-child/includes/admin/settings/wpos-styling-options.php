<?php
/**
 * Navigation Settings
 *
 * @package WP Clean Responsive
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// Action to add Home Page settings
add_action( 'wpos_tab_content_styling_options', 'wpos_tab_content_styling_options' );

/**
 * Function for navigation settings
 * 
 * @package WP Clean Responsive
 * @since 1.0
 */
function wpos_tab_content_styling_options() {
	global $wpos_options, $wp_version;
	
	$theme_color = wpos_get_option('theme_color');
	
	

?>
	<h2><?php _e('Styling Options', 'wpos-theme'); ?></h2>

	<table class="form-table">

		<tr>
			<th colspan="2">
				<div class="wpos-sub-sett-title"><?php _e('Header Options', 'wpos-theme'); ?></div>
			</th>
		</tr>

		<tr>
			<th scope="row">
				<label for="wpos-header-bgclr"><?php _e('Navigation Background Color', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<?php if( $wp_version >= 3.5 ) { ?>
					<input type="text" name="wpos_options[site_header_bgclr]" value="<?php echo wpos_get_option('site_header_bgclr'); ?>" id="wpos-header-bgclr" class="wpos-color-box wpos-header-bgclr" /><br/>
				<?php } else { ?>
					<div style='position:relative;'>
						<input type='text' name="wpos_options[site_header_bgclr]" value="<?php echo wpos_get_option('site_header_bgclr'); ?>" class="wpos-color-box-farbtastic-inp" data-default-color="" />
						<input type="button" class="wpos-color-box-farbtastic button button-secondary" value="<?php _e('Select Color', 'wpos-theme'); ?>" />
						<div class="colorpicker" style="background-color: #666; z-index:100; position:absolute; display:none;"></div>
					</div>
				<?php } ?>
					<span class="description"><?php _e( 'Select header background color.', 'wpos-theme' ); ?></span>
			</td>
		</tr>

		<tr>
			<th colspan="2">
				<div class="wpos-sub-sett-title"><?php _e('Navigation Font Options', 'wpos-theme'); ?></div>
			</th>
		</tr>

		<tr>
			<th scope="row">
				<label for="wpos-navigation-font-clr"><?php _e('Navigation Font Color', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<?php if( $wp_version >= 3.5 ) { ?>
					<input type="text" name="wpos_options[navigation_font_clr]" value="<?php echo wpos_get_option('navigation_font_clr'); ?>" id="wpos-navigation-font-clr" class="wpos-color-box wpos-navigation-font-clr" /><br/>
				<?php } else { ?>
					<div style='position:relative;'>
						<input type='text' name="wpos_options[navigation_font_clr]" value="<?php echo wpos_get_option('navigation_font_clr'); ?>" class="wpos-color-box-farbtastic-inp" data-default-color="" />
						<input type="button" class="wpos-color-box-farbtastic button button-secondary" value="<?php _e('Select Color', 'wpos-theme'); ?>" />
						<div class="colorpicker" style="background-color: #666; z-index:100; position:absolute; display:none;"></div>
					</div>
				<?php } ?>
					<span class="description"><?php _e( 'Select navigation font color.', 'wpos-theme' ); ?></span>
			</td>
		</tr>
		<tr>
			<th scope="row">
				<label for="wpos-navigation-hover-clr"><?php _e('Navigation Hover Color', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<?php if( $wp_version >= 3.5 ) { ?>
					<input type="text" name="wpos_options[navigation_hover_clr]" value="<?php echo wpos_get_option('navigation_hover_clr'); ?>" id="wpos-navigation-hover-clr" class="wpos-color-box wpos-navigation-hover-clr" /><br/>
				<?php } else { ?>
					<div style='position:relative;'>
						<input type='text' name="wpos_options[navigation_hover_clr]" value="<?php echo wpos_get_option('navigation_hover_clr'); ?>" class="wpos-color-box-farbtastic-inp" data-default-color="" />
						<input type="button" class="wpos-color-box-farbtastic button button-secondary" value="<?php _e('Select Color', 'wpos-theme'); ?>" />
						<div class="colorpicker" style="background-color: #666; z-index:100; position:absolute; display:none;"></div>
					</div>
				<?php } ?>
					<span class="description"><?php _e( 'Select navigation hover color.', 'wpos-theme' ); ?></span>
			</td>
		</tr>
		

		<tr>
			<th colspan="2">
				<div class="wpos-sub-sett-title"><?php _e('Footer Options', 'wpos-theme'); ?></div>
			</th>
		</tr>

		<tr>
			<th scope="row">
				<label for="wpos-footer-bgclr"><?php _e('Footer Background Color', 'wpos-theme'); ?>:</label>
			</th>
			<td>
				<?php if( $wp_version >= 3.5 ) { ?>
					<input type="text" name="wpos_options[site_footer_bgclr]" value="<?php echo wpos_get_option('site_footer_bgclr'); ?>" id="wpos-footer-bgclr" class="wpos-color-box wpos-footer-bgclr" /><br/>
				<?php } else { ?>
					<div style='position:relative;'>
						<input type='text' name="wpos_options[site_footer_bgclr]" value="<?php echo wpos_get_option('site_footer_bgclr'); ?>" class="wpos-color-box-farbtastic-inp" data-default-color="" />
						<input type="button" class="wpos-color-box-farbtastic button button-secondary" value="<?php _e('Select Color', 'wpos-theme'); ?>" />
						<div class="colorpicker" style="background-color: #666; z-index:100; position:absolute; display:none;"></div>
					</div>
				<?php } ?>
					<span class="description"><?php _e( 'Select footer background color.', 'wpos-theme' ); ?></span>
			</td>
		</tr>

	</table>

<?php } ?>
jQuery( document ).ready(function($) {
    
    // Update theme options
    $( document ).on( 'click', '.wpos-settings-submit', function() {
        
        var current_obj = $(this);
        current_obj.attr('disabled', 'disabled');
        $('.wpos-theme-success').css('top', ''); // Reset top position
        current_obj.parent().find('.spinner').css('visibility', 'visible');
        
        //tinyMCE.triggerSave(); // Imp to save wordpress editor content
        
        var data = {
                        action      : 'wpos_update_theme_options',
                        form_data   : $('.wpos-theme-settings-form').serialize()
                    };
        $.post(ajaxurl,data,function(response) {
            var result = $.parseJSON(response);
            
            if( result.success == 1 ){
                current_obj.removeAttr('disabled', 'disabled');
                current_obj.parent().find('.spinner').css('visibility', '');
                $('.wpos-theme-success').fadeIn().animate({"top":"30%"}, "slow");
            }
        });
        
        setTimeout("jQuery('.wpos-theme-success').fadeOut();", 2500);
        
        return false;
    });

    //  Theme tabs
	$( document ).on( 'click', '.wpos-tab-nav-li a', function() {

        if( !$(this).closest('.wpos-tab-nav-li').hasClass("wpos-tab-nav-li-active") ) {
            $('.wpos-sub-tab-nav').slideUp();
        }

        //  First remove class "active" from currently active tab
        $(".wpos-tab-nav-li").removeClass('wpos-tab-nav-li-active');
        $(".wpos-tab-nav-li a").removeClass('wpos-tab-nav-active');

        //  Now add class "active" to the selected/clicked tab
        $(this).closest('.wpos-tab-nav-li').addClass('wpos-tab-nav-li-active');
        $(this).addClass("wpos-tab-nav-active");

        //  Hide all tab content
        $(".wpos-tab-cnt").hide();

        //  Here we get the href value of the selected tab
        var selected_tab = $(this).attr("href");
        
        //  Show the selected tab content
        $(selected_tab).fadeIn('slow');

        if(  $(this).parent().find('.wpos-sub-tab-nav').is(':hidden') ) {
            $(this).parent().find('.wpos-sub-tab-nav').slideDown();
        }

        //  At the end, we add return false so that the click on the link is not executed
        return false;
    });

    /***** Media Uploader Starts *****/
    $( document ).on( 'click', '.wpos-image-upload', function() {
        
        var imgfield,showfield;
        imgfield = jQuery(this).prev('input').attr('id');
        showfield = jQuery(this).parents('td').find('.wpos-img-view');
         
        if(typeof wp == "undefined" || WposAdmin.new_ui != '1' ){// check for media uploader
            
            tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
            
            window.original_send_to_editor = window.send_to_editor;
            window.send_to_editor = function(html) {
                
                if(imgfield) {
                    
                    var mediaurl = $('img',html).attr('src');
                    $('#'+imgfield).val(mediaurl);
                    showfield.html('<img src="'+mediaurl+'" />');
                    tb_remove();
                    imgfield = '';
                    
                } else {
                    
                    window.original_send_to_editor(html);
                    
                }
            };
            return false;
            
        } else {
            
            var file_frame;
            
            //new media uploader
            var button = jQuery(this);
        
            // If the media frame already exists, reopen it.
            if ( file_frame ) {
                file_frame.open();
              return;
            }
    
            // Create the media frame.
            file_frame = wp.media.frames.file_frame = wp.media({
                frame: 'post',
                state: 'insert',
                title: button.data( 'uploader-title' ),
                button: {
                    text: button.data( 'uploader-button-text' ),
                },
                multiple: false  // Set to true to allow multiple files to be selected
            });
    
            file_frame.on( 'menu:render:default', function(view) {
                // Store our views in an object.
                var views = {};
    
                // Unset default menu items
                view.unset('library-separator');
                view.unset('gallery');
                view.unset('featured-image');
                view.unset('embed');
    
                // Initialize the views in our view object.
                view.set(views);
            });
    
            // When an image is selected, run a callback.
            file_frame.on( 'insert', function() {
    
                // Get selected size from media uploader
                var selected_size = $('.attachment-display-settings .size').val();
                
                var selection = file_frame.state().get('selection');
                selection.each( function( attachment, index ) {
                    attachment = attachment.toJSON();
                    
                    // Selected attachment url from media uploader
                    var attachment_url = attachment.sizes[selected_size].url;
                    
                    if(index == 0){
                        // place first attachment in field
                        $('#'+imgfield).val(attachment_url);
                        showfield.html('<img src="'+attachment_url+'" />');
                        
                    } else{
                        $('#'+imgfield).val(attachment_url);
                        showfield.html('<img src="'+attachment_url+'" />');
                    }
                });
            });
    
            // Finally, open the modal
            file_frame.open();
        }
    });
    /***** Media Uploader Ends *****/

    // Clear Media
    $( document ).on( 'click', '.wpos-image-clear', function() {
        $(this).parent().find('.wpos-img-upload-input').val('');
        $(this).parent().find('.wpos-img-view').html('');
    });

    /***** Color Picker Starts *****/
    if( WposAdmin.new_ui == 1 ){
        
        $('.wpos-color-box').wpColorPicker();

    } else{

        var inputcolor = jQuery('.wpos-color-box-farbtastic').prev('input').val();
        jQuery('.wpos-color-box-farbtastic').prev('input').css('background-color',inputcolor);
        jQuery('.wpos-color-box-farbtastic').click(function(e) {
            colorPicker = jQuery(this).next('div');
            input = jQuery(this).prev('input');
            jQuery.farbtastic(jQuery(colorPicker), function(a) { jQuery(input).val(a).css('background', a); });
            colorPicker.show();
            e.preventDefault();
            jQuery(document).mousedown( function() { jQuery(colorPicker).hide(); });
        });
    }
    /***** Color Picker Ends *****/

    // Call on click reset options button from theme settings page
    $( document ).on( 'click', '.wpos-settings-reset', function() {
        var ans;
        ans = confirm( WposAdmin.reset_msg );
        if(ans) {
            return true;
        } else {
            return false;
        }
    });

    // On change of checkbox
    $( document ).on( 'change', '.wpos-clickbox', function() {

        var inp_type = $(this).attr('type');
               

        if( inp_type = 'checkbox' || inp_type == 'radio' ) {

            var showlabel = $(this).attr('data-label');

            if(typeof(showlabel) == 'undefined' || showlabel == '' ) {
                showlabel = $(this).val();
            }
            
            $('.show-if-'+showlabel).hide();
            $('.hide-if-'+showlabel).hide();
            if( $(this).is(":checked") ) {
                $('.show-if-'+showlabel).show();
            }
        }
        if(inp_type ='select'){
            page_layout = $(this).val();
               
            $('.show-if-page-layout-box').hide();
            $('.hide-if-page-layout-box').hide();

            if( page_layout == 'boxed' || page_layout == 'fixed-width' ) {
                $('.show-if-page-layout-box').show();
            }
            

            
            
        }


    });
    
    
    $( document ).on( 'change', '#blog-layout-type', function() {
        
            page_layout = $(this).val();
             if( page_layout == 'masonry') {
                $('.full_content_cls').hide();
            }else{
                $('.full_content_cls').show();
            }
            
            if( page_layout == 'list') {
                $('.blog_grid_cls').hide();
            }else{
                $('.blog_grid_cls').show();
            }
            
            var wpos_design_lists = $.parseJSON($('#wpos-design-lists').text());
            if(wpos_design_lists[page_layout]){
                var design_list=''; 
                $.each( wpos_design_lists[page_layout], function( i, val ) {
                    design_list+="<option value='"+val+"'>"+i+"</option>";
                });
                $("#wpos-blog-design").html(design_list);
            }
    });
    
    $( document ).on( 'change', '#blog-layout-type-cat', function() {
        
            page_layout = $(this).val();
            if( page_layout == 'masonry') {
                $('.full_content_cls_cat').hide();
            }else{
                $('.full_content_cls_cat').show();
            }
            
            if( page_layout == 'list') {
                $('.blog_grid_cls_cat').hide();
            }else{
                $('.blog_grid_cls_cat').show();
            }
             
            var wpos_design_lists = $.parseJSON($('#wpos-design-lists-cat').text());
            if(wpos_design_lists[page_layout]){
                var design_list=''; 
                $.each( wpos_design_lists[page_layout], function( i, val ) {
                    design_list+="<option value='"+val+"'>"+i+"</option>";
                });
                $("#wpos-blog-design-cat").html(design_list);
            }
    });
    

    // On change of page layout
    $( document ).on( 'change', '.wpos-body-header-type', function() {         
            header_type = $(this).val();
                       
            $('.show-if-header-type-fixed').hide();
           
            if( page_layout == 'fixed' || page_layout == 'sticky' ) {
                $('.show-if-header-type-fixed').show();
            }
        
        
    });

    // Select horizontal header
    $( document ).on( 'click', '.horizontal .header-image', function() { 
         //  First remove class "active" from currently active tab
        $(".horizontal .header-image").removeClass('header-image-active');   
        var header = $(this).attr('data-header');  
        //  Now add class "active" to the selected/clicked tab
         $(this).addClass('header-image-active');                     
        $('#header-style').val(header);         
    });

     // Select vertical header
    $( document ).on( 'click', '.vertical .header-image', function() { 
         //  First remove class "active" from currently active tab
        $(".vertical .header-image").removeClass('header-image-active');   
        var header = $(this).attr('data-header');  
        //  Now add class "active" to the selected/clicked tab
         $(this).addClass('header-image-active');                     
        $('#header-vertical-style').val(header);         
    });

    // Select switch
    $( document ).on( 'click', '.wpos-switch-box label', function() {

        var swith_id = $(this).parent().attr('id');       
        $("#"+swith_id+" label").removeClass('wpos-selected');   
        var label_val = $(this).attr('data-val');
        label_val = parseInt(label_val);
        var wpos_option_id =  $(this).attr('data-id'); 
        //  Now add class "active" to the selected/clicked tab
         $(this).addClass('wpos-selected');                     
        $('#'+wpos_option_id).val(label_val); 

        var showlabel = $(this).attr('data-label');

            if(typeof(showlabel) == 'undefined' || showlabel == '' ) {
                showlabel = $(this).val();
            }
            $('.show-if-'+showlabel).hide();
            $('.hide-if-'+showlabel).hide();
            if(label_val){
                //alert(label_val);
                $('.show-if-'+showlabel).show();              
            }
            else{
               // alert('False '+ label_val+' .show-if-'+showlabel);
                 $('.show-if-'+showlabel).hide();               
            }
                   
    });


    // Copy theme options
    $( document ).on( 'click', '.wpos-copy-theme-sett', function() {

        var current_obj = $(this);
        var loader      = $(this).parent().find('.spinner'); // Enable loader
        
        loader.css('visibility', 'visible');
        current_obj.attr('disabled', 'disabled');
        
        var data = {
                        action      : 'wpos_backup_theme_options',
                        is_ajax     : 1
                    };
        $.post(ajaxurl,data,function(response) {
            var result = $.parseJSON(response);

            if( result.success == 1 ) {
                $('.wpos-exported-opts-row').show();
                $('.wpos-exported-opts-row .wpos-exported-opts').val( result.data );
                current_obj.removeAttr('disabled', 'disabled');
                loader.css('visibility', 'hidden');
            }
        });
    });

    // Import theme options
    $( document ).on( 'click', '.wpos-import-theme-sett', function() {

        var current_obj = $(this);
        var loader      = $(this).parent().find('.spinner'); // Enable loader
        var msg_field   = current_obj.parent().find('.wpos-imported-opts-msg');
        var theme_sett  = $.parseJSON(current_obj.parent().find('.wpos-imported-opts').val());

        // Display loader and disable button
        loader.css('visibility', 'visible');
        current_obj.attr('disabled', 'disabled');
        msg_field.html('');

        // Creating object
        var theme_opts_obj = {};

        // Creating theme object
        $.each(theme_sett, function (key,val) {
            theme_opts_obj[key] = val;
        });

        var data = {
                        action      : 'wpos_import_theme_options',
                        is_ajax     : 1,
                        import_data : theme_opts_obj
                    };
        $.post(ajaxurl,data,function(response) {
            var result = $.parseJSON(response);
            
            if( result.success == 1 ) {
                msg_field.removeClass('wpos-red').addClass('wpos-green').html( result.msg );
                
                // Reload current page
                location.reload(true);

            } else {
                msg_field.removeClass('wpos-green').addClass('wpos-red').html( result.msg );
            }

            loader.css('visibility', 'hidden');
            current_obj.removeAttr('disabled', 'disabled');
        });
    });
    
    // Home page content sortable options
    $( document ).on( 'click', '.wpos-cat-toggle', function() {

        var cls_ele     = $(this).parent('.wpos-cat-data');
        var toggle_ele  = $(this).parent('.wpos-cat-data').find(' > .wpos-cat-toggle');

        if( cls_ele.find(' > .wpos-sub-cat-wrp').is(":visible") ){
            cls_ele.find(' > .wpos-sub-cat-wrp').slideUp();
        } else {
            cls_ele.find(' > .wpos-sub-cat-wrp').slideDown();
        }
        
        if( cls_ele.find(' > .wpos-portlet-content').is(":visible") ){
            cls_ele.find(' > .wpos-portlet-content').slideUp();
        } else {
            cls_ele.find(' > .wpos-portlet-content').slideDown();
        }

        if( toggle_ele.hasClass( "dashicons-arrow-down" ) ){
            toggle_ele.removeClass('dashicons-arrow-down').addClass('dashicons-arrow-up');
        } else {
            toggle_ele.removeClass('dashicons-arrow-up').addClass('dashicons-arrow-down');
        }
    });

    $( 'ul.wpos-cat-sort' ).sortable({
        cursor  : 'move',
        axis    : 'y',
        containment         : '.wpos-cat-sort',
        scrollSensitivity   : 40,
        placeholder         : "wpos-state-highlight",
        helper: function( event, ui ) {
            return ui;
        },
        start: function( event, ui ) {
        },
        stop: function( event, ui ) {
        },
        update: function( event, ui ) {
        }
    });

    $( 'table.wpos-social-sort tbody' ).sortable({
        cursor              : 'move',
        axis                : 'y',
        handle              : '.handle',
        containment         : '.wpos-social-sort',
        scrollSensitivity   : 40,
        placeholder         : "wpos-state-highlight",
        helper              : function( event, ui ) {
                                return ui;
                              },
        start               : function( event, ui ) {
                              },
        stop                : function( event, ui ) {
                              },
        update              : function( event, ui ) {
                              }
    });

    // On select  of category display type for Home Page
    $(document).on('change', '.wpos-cat-display-type', function() {
        var sel_val     = $(this).val();
        var current_obj = $(this).closest('.form-table');
        
        current_obj.find('.wpos-grid-limit-wrp').hide();
        current_obj.find('.wpos-cat-slider-sett-wrp').hide();
        
        if( sel_val == 'grid' ) {
            current_obj.find('.wpos-grid-limit-wrp').show();
        }

        if( sel_val == 'slider' ) {
            current_obj.find('.wpos-cat-slider-sett-wrp').show();
        }
    });
});
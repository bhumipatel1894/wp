<?php
/**
 * Public Class
 * 
 * Handles Public side functionality of theme
 * 
 * @package WP Clean Responsive
 * @since 1.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Wpos_Public {

	function __construct() {

		// Action to add custom css
		add_action( 'wp_head', array($this, 'wpos_add_theme_dynemic_css'), 20 );

	}

	/**
	 * Prints theme dynemic css in head
	 *
	 * @package WP Clean Responsive
	 * @since 1.0.0
	 */
	function wpos_add_theme_dynemic_css(){

		$custom_css = '';

		/***** Body Css Starts *****/
		$custom_css .= 'body{';
		$theme_font = wpos_get_option('body_font_type', 'standard');

		if( $theme_font == 'standard' ) {
			
			$body_font_family 	= wpos_get_option('body_web_font');
			$custom_css 		.= "font-family:{$body_font_family}, sans-serif;";

		} elseif ($theme_font == 'google') {
			
			$body_google_font 		= wpos_get_option('body_google_font');
			$body_google_font_data 	= wpos_google_font_data( $body_google_font );
			$body_font_family		= !empty($body_google_font_data['font_family']) ? $body_google_font_data['font_family'] : '';

			$custom_css .= !empty($body_font_family) 						? "font-family:{$body_font_family}, sans-serif; " : '';
			$custom_css .= !empty($body_google_font_data['font_weight']) 	? "font-weight:{$body_google_font_data['font_weight']}; " 	: '';
			$custom_css .= !empty($body_google_font_data['font_style'])  	? "font-style:{$body_google_font_data['font_style']}; " 	: '';
		}

		$body_font_size = wpos_get_option('body_font_size', '14');
		$custom_css .= " font-size:{$body_font_size}px;";

		$body_line_height = wpos_get_option('body_line_height', '24');
		$custom_css .= " line-height:{$body_line_height}px;";
		
		$custom_css .= '} ';

		$custom_css .= "button, .button{";
		$custom_css .= "font-family:{$body_font_family}, sans-serif;";
		$custom_css .= "} ";

		/***** Body Css Ends *****/

		/***** Heading Font Css Starts *****/
		$heading_font_type 	= wpos_get_option('heading_font_type');
		
		if( $heading_font_type == 'standard' ) {

			$heading_web_font 	= wpos_get_option('heading_web_font');

			$custom_css .= "h1,h2,h3,h4,h5,h6{";
			$custom_css .= "font-family:{$heading_web_font};";
			$custom_css .= "} ";

		} elseif ($heading_font_type == 'google') {

			$heading_google_font 		= wpos_get_option('heading_google_font');
			$heading_google_font_data 	= wpos_google_font_data( $heading_google_font );

			$custom_css .= "h1,h2,h3,h4,h5,h6{";
			$custom_css .= !empty($heading_google_font_data['font_family']) ? "font-family:{$heading_google_font_data['font_family']}, sans-serif; " 	: '';
			$custom_css .= !empty($heading_google_font_data['font_weight']) ? "font-weight:{$heading_google_font_data['font_weight']}; " 				: '';
			$custom_css .= !empty($heading_google_font_data['font_style'])  ? "font-style:{$heading_google_font_data['font_style']}; " 					: '';
			$custom_css .= "} ";
		}
		/***** Heading Font Css Ends *****/

		/***** Navigation Font Css Starts *****/
		$navigation_font_type 	= wpos_get_option('navigation_font_type');
		$navigation_font_size 	= wpos_get_option('navigation_font_size');		

		$custom_css .= ".main-navigation ul li a{";

		if( $navigation_font_type == 'standard' ) {
			
			$navigation_web_font = wpos_get_option('navigation_web_font');
			
			$custom_css .= "font-family:{$navigation_web_font};";
			
		} elseif ( $navigation_font_type == 'google' ) {

			$navigation_google_font 		= wpos_get_option('navigation_google_font');
			$navigation_google_font_data 	= wpos_google_font_data( $navigation_google_font );

			$custom_css .= !empty($navigation_google_font_data['font_family']) ? "font-family:{$navigation_google_font_data['font_family']}, sans-serif; " 	: '';
			$custom_css .= !empty($navigation_google_font_data['font_weight']) ? "font-weight:{$navigation_google_font_data['font_weight']}; " 				: '';
			$custom_css .= !empty($navigation_google_font_data['font_style'])  ? "font-style:{$navigation_google_font_data['font_style']}; " 				: '';
		}

		if( !empty($navigation_font_size) ) {
			$custom_css .= " font-size:{$navigation_font_size}px;";
		}

		$custom_css .= "} ";
		
		/*** Navigation color **/
		$navigation_bg_color 	= wpos_get_option('site_header_bgclr');	
		$navigation_a_color 	= wpos_get_option('navigation_font_clr');	
		$navigation_ahover_color 	= wpos_get_option('navigation_hover_clr');	
		
		if(!empty($navigation_bg_color)) {
			$custom_css .= ".navigation-top{background:{$navigation_bg_color}}";
		}
		if(!empty($navigation_a_color)) {
			$custom_css .= ".navigation-top .main-navigation a{color:{$navigation_a_color}}";
			$custom_css .= ".menu-toggle{color:{$navigation_a_color}}";
			$custom_css .= ".site-header .navigation-top .menu-scroll-down{color:{$navigation_a_color}}";
		}
		if(!empty($navigation_ahover_color)) {
			$custom_css .= ".navigation-top .main-navigation ul li a:hover, .navigation-top .main-navigation ul li a:focus, .navigation-top .main-navigation ul li a:active{color:{$navigation_ahover_color}}";
			$custom_css .= ".navigation-top .current-menu-item > a, .navigation-top .current_page_item > a { color:{$navigation_ahover_color}}";
		}
                
		if( !empty($custom_css) ) {
			$css = "<style type='text/css'>" . "\n";
			$css .= "/*========== Dynemic Theme CSS Starts ==========*/" . "\n";;
			$css .= $custom_css;
			$css .= "\n" . "/*========== Dynemic Theme CSS Ends ==========*/" . "\n";;
			$css .= "</style>" . "\n";
			echo $css;
		}
	}
	
}

$wpos_public = new Wpos_Public();
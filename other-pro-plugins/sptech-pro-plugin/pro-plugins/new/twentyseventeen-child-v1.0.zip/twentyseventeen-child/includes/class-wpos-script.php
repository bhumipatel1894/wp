<?php
/**
 * Script Class
 *
 * Handles the script and style functionality of plugin
 *
 * @package WP Clean Responsive
 * @since 1.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Wpos_Script {
	
	function __construct() {

		// Action to add customizer script
		add_action( 'customize_preview_init', array($this, 'wpos_customize_preview_js') );

		// Action to add style in front end
		add_action( 'wp_enqueue_scripts', array($this, 'wpos_front_styles'), 1 );

		// Action to add script in front end
		add_action( 'wp_enqueue_scripts', array($this, 'wpos_front_scripts'), 1 );

		// Action to add style in backend
		add_action( 'admin_enqueue_scripts', array($this, 'wpos_admin_style') );

		// Action to add script in backend
		add_action( 'admin_enqueue_scripts', array($this, 'wpos_admin_script') );
	}

	/**
	 * Enqueue Javascript postMessage handlers for the Customizer.
	 * Binds JS handlers to make the Customizer preview reload changes asynchronously.
	 *
	 * @package WP Clean Responsive
	 * @since 1.0
	 */
	function wpos_customize_preview_js() {
		wp_enqueue_script( 'wpos-customizer', get_template_directory_uri() . '/assets/js/theme-customizer.js', array( 'customize-preview' ), '20141120', true );
	}

	/**
	 * Enqueue styles for front-end
	 * 
	 * @package WP Clean Responsive
	 * @since 1.0
	 */
	function wpos_front_styles() {
		global $wp_styles;
                
		// Font Awesome CSS
		// Font Awesome CSS
		wp_register_style( 'wpos-font-awesome-style',  'https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css', array(), WPOS_VERSION);
		wp_enqueue_style( 'wpos-font-awesome-style' );


		// Google Font Awesome CSS
		$google_font_url = wpos_get_font_url();
		if( !empty( $google_font_url ) ) {
			wp_register_style( 'wpos-google-fonts', esc_url_raw($google_font_url), array(), WPOS_VERSION);
			wp_enqueue_style( 'wpos-google-fonts' );
		}
                
                // Registring public style
		wp_register_script( 'wpspw-masonry-public-script', get_stylesheet_directory_uri().'/assets/js/wpspw-masonry-public.js', array('jquery'), true );
		wp_localize_script( 'wpspw-masonry-public-script', 'WpspwPro', array( 
																	'ajaxurl' 		=> admin_url( 'admin-ajax.php', ( is_ssl() ? 'https' : 'http' ) ),
																	'no_post_msg'	=> __('Sorry, No more post to display.', 'wp-blog-and-widgets')
																));	
		

	}

	/**
	 * Enqueue scripts for front-end
	 * 
	 * @package WP Clean Responsive
	 * @since 1.0
	 */
	function wpos_front_scripts() {
		
		/*
		 * Adds JavaScript to pages with the comment form to support
		 * sites with threaded comments (when in use).
		 */
		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ){
			wp_enqueue_script( 'comment-reply' );
		}
		// Registring slick slider script
		if( !wp_script_is( 'wpos-slick-jquery', 'registered' ) ) {
			wp_register_script( 'wpos-slick-js', get_stylesheet_directory_uri() . '/assets/js/slick.min.js', array('jquery'), WPOS_VERSION, true);			
		}
		

		// Public Js
		wp_register_script( 'wpos-public-js', get_stylesheet_directory_uri() . '/assets/js/public.js', array('jquery'), WPOS_VERSION, true);

		wp_localize_script( 'wpos-public-js', 'Wpos', array(
																	'enable_goto_top' => wpos_get_option('enable_goto_top', 0)
													  ));
		wp_enqueue_script( 'wpos-public-js' );

		
	}

	/**
	 * Enqueue admin styles
	 * 
	 * @package WP Clean Responsive
	 * @since 1.0
	 */
	function wpos_admin_style( $hook ) {
		global $wp_version, $wp_query, $typenow, $post_type;
                
                
		// Pages array
		$pages_array = array( 'toplevel_page_wpos-theme-settings','post.php','post-new.php');
		                
		// If page is plugin setting page then enqueue script
		if( in_array($hook, $pages_array) ) {

			// Enqueu built in style for color picker
			if( wp_style_is( 'wp-color-picker', 'registered' ) ) { // Since WordPress 3.5
				wp_enqueue_style( 'wp-color-picker' );
			} else {
				wp_enqueue_style( 'farbtastic' );
			}

			// Registring Public Style
			wp_register_style( 'wpos-admin-style', WPOS_URL.'/includes/assets/css/wpos-admin.css', null, WPOS_VERSION );
			wp_enqueue_style('wpos-admin-style');

			// Registring Jquery UI Style
			wp_register_style( 'wpos-jquiry-ui-style', WPOS_URL.'/includes/assets/css/jquery-ui.css', null, WPOS_VERSION );
			wp_enqueue_style('wpos-jquiry-ui-style');
		}
	}

	/**
	 * Enqueue admin script
	 * 
	 * @package WP Clean Responsive
	 * @since 1.0
	 */
function wpos_admin_script( $hook ) {

		global $wp_version, $wp_query, $typenow, $post_type;

		$new_ui = $wp_version >= '3.5' ? '1' : '0'; // Check wordpress version for older scripts

		// Pages array
		$pages_array = array( 'toplevel_page_wpos-theme-settings','post.php','post-new.php');


		if( in_array($hook, $pages_array) ) {
			
			wp_enqueue_script( 'jquery-ui-sortable' );
			
			// Enqueu built-in script for color picker
			if( wp_script_is( 'wp-color-picker', 'registered' ) ) { // Since WordPress 3.5
				wp_enqueue_script( 'wp-color-picker' );
			} else {
				wp_enqueue_script( 'farbtastic' );
			}
			
			wp_enqueue_media(); // For media uploader
			
			// Registring admin script
			wp_register_script( 'wpos-admin-js', WPOS_URL.'/includes/assets/js/wpos-admin.js', array('jquery'), WPOS_VERSION, true );
			wp_localize_script( 'wpos-admin-js', 'WposAdmin', array(
                                                            'new_ui' 	=>	$new_ui,
                                                            'reset_msg'	=> __('Click OK to reset all theme options. All settings will be lost!', 'wpos-theme')
                                                    ));
			wp_enqueue_script( 'wpos-admin-js' );

			
		}

		
		

	}
}

$wpos_script = new Wpos_Script();
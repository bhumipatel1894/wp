<?php
/**
 * Recommendation Class
 * 
 * Handles the recommended plugin functionality.
 * 
 * @package WP Clean Responsive
 * @since 1.0
 */

// Plugin recomendation class
require_once( WPOS_DIR . '/includes/plugins/class-tgm-plugin-activation.php' );

class Wpos_Recommendation {

	function __construct() {
		
		// Action to add recomended plugins
		add_action( 'tgmpa_register', array($this, 'wpos_recommend_plugin') );
	}

	/**
	 * Recommend Plugins
	 * 
	 * @package WP Clean Responsive
	 * @since 1.0
	 */
	function wpos_recommend_plugin() {
	    $plugins = array(
	        array(
	            'name'               => 'kingcomposer',
	            'slug'               => 'kingcomposer',
	            'required'           => false,
	        ),
                array(
	            'name'               => 'Instagram Slider and Carousel Plus Widget',
	            'slug'               => 'slider-and-carousel-plus-widget-for-instagram',
	            'required'           => false,
	        )
	    );
	    tgmpa( $plugins);
	}
}

$wpos_recommendation = new Wpos_Recommendation();
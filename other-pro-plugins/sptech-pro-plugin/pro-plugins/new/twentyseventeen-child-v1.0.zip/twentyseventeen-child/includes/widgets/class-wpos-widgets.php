<?php
/**
 * Widget Class
 * 
 * Handles the widget functionality
 * 
 * @package WP Clean Responsive
 * @since 1.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Wpos_Widget {	
	function __construct() {		
		// Action to register sidebar
		add_action( 'widgets_init', array($this, 'wpos_widgets_init' ) );
	}
	/**
	 * Register sidebars.
	 * Registers our main widget area and the front page widget areas.
	 *
	 * @package WP Clean Responsive
	 * @since 1.0
	 */
	function wpos_widgets_init() {
		
		// Footer Sidebar 1
		register_sidebar( array(
			'name' 	=> __( 'First Footer Widget Area', 'wpos-tell-your-tale' ),
			'id' 	=> 'wpos-footer-sidebar-1',
			'description' 	=> __( 'Appears in a first column of footer.', 'wpos-tell-your-tale' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget' 	=> '</aside>',
			'before_title' 	=> '<div class="widget-title"><h4>',
			'after_title' 	=> '</h4></div>',
		) );

		// Footer Sidebar 2
		register_sidebar( array(
			'name' 	=> __( 'Second Footer Widget Area', 'wpos-tell-your-tale' ),
			'id' 	=> 'wpos-footer-sidebar-2',
			'description' 	=> __( 'Appears in a second column of footer.', 'wpos-tell-your-tale' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget' 	=> '</aside>',
			'before_title' 	=> '<div class="widget-title"><h4>',
			'after_title' 	=> '</h4></div>',
		) );

		// Footer Sidebar 3
		register_sidebar( array(
			'name' 	=> __( 'Third Footer Widget Area', 'wpos-tell-your-tale' ),
			'id' 	=> 'wpos-footer-sidebar-3',
			'description' 	=> __( 'Appears in a third column of footer.', 'wpos-tell-your-tale' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget' 	=> '</aside>',
			'before_title' 	=> '<div class="widget-title"><h4>',
			'after_title' 	=> '</h4></div>',
		) );

		// Footer Sidebar 4
		register_sidebar( array(
			'name' 	=> __( 'Forth Footer Widget Area', 'wpos-tell-your-tale' ),
			'id' 	=> 'wpos-footer-sidebar-4',
			'description' 	=> __( 'Appears in a forth column of footer.', 'wpos-tell-your-tale' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget' 	=> '</aside>',
			'before_title' 	=> '<div class="widget-title"><h4>',
			'after_title' 	=> '</h4></div>',
		) );

		
		
		
	}
}
$wpos_widget = new Wpos_Widget();
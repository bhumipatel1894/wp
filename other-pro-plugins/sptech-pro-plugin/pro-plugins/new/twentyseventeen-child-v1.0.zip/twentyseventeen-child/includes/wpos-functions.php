<?php
/**
 * Functions File
 *
 * @package WPOS Tell Your Tale
 * @since 1.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Update default settings
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0
 */
function wpos_default_settings() {
	
	global $wpos_options;
	
	$wpos_options = array(
								'site_primary_clr'		=> '',								
								'copyright_text'		=> '&copy; {year} WPOS Tell Your Tale',
								'fb_url'			=> '',
								'tw_url'			=> '',
								'gp_url'			=> '',
								'li_url'			=> '',
								'inst_url'			=> '',
								'yt_url'			=> '',
								'enable_copyright'		=> 1,
								'enable_goto_top'		=> 1,								
								'body_font_type'		=> 'google',
								'body_web_font'			=> 'Arial',
								'body_google_font'		=> 'Open+Sans:regular',
								'body_font_size'		=> '14',
								'body_line_height'		=> '24',
								'heading_google_font'           => '',
								'heading_web_font'		=> '',
								'navigation_font_type'          => '',
								'navigation_font_size'          => '',
								'navigation_web_font'           => '',
								'navigation_line_height'        => '',
								'heading_font_type'         	=> '',	
								'readmore_text'			=> 'Read More',	
								'readmore_text_cat'		=> 'Read More',	
								'link_behaviour'		=> '_self',	
								'link_behaviour_cat'		=> '_self',	
								'social_media_footer'           => 1,
								'enable_post_author'            => 1,
								'enable_post_author_cat'        => 1,
								'social_media_header'           => 0,
								'blog_layout_full'              => 0,
								'blog_layout_full_cat'          => 0,
								'post_full_cnt'			=> 0,
								'post_full_cnt_cat'		=> 0,
								'post_archives_full_cnt'        => 0,
								'post_archives_full_cnt_cat'    => 0,
								'excerpt_lenght'		=> 55,
								'excerpt_lenght_cat'		=> 55,
								'hide_indx_feat_img'            => 0,
								'hide_indx_feat_img_cat'	=> 0,
								'hide_single_feat_img'          => 0,
								'hide_single_feat_img_cat'	=> 0,
								'enable_fwdgt'			=> 1,
								'footer_clmn'			=> 4,
								'blog_layout'			=> 1,
								'blog_layout_cat'		=> 1,
								'blog_layout_type'		=> 'grid',
								'blog_layout_type_cat'		=> 'grid',
								'blog_grid'			=> 1,
								'blog_grid_cat'			=> 1,
								'blog_design'			=> 'design-1',
								'blog_design_cat'		=> 'design-1',
								'blog_masonry'			=> 0,
								'enable_post_count'             => 1,
								'enable_post_count_cat'		=> 1,
								'enable_post_date'		=> 1,
								'enable_post_date_cat'		=> 1,
								'enable_single_post_author'     => 1,
								'enable_single_post_date'       => 1,
								'enable_post_tag'		=> 1,
								'enable_post_tag_cat'		=> 1,
								'enable_post_formate'		=> 1,
								'enable_post_formate_cat'	=> 1,
								'show_content'                  => 1,
								'show_content_cat'              => 1,
								'enable_post_cat'		=> 1,
								'enable_post_cat_cat'		=> 1,
								'blog_masonry_cat'		=> 0,
								'cat_layout'			=> 1,
								'cat_masonry'			=> 0,
								'enable_rp_post'		=> 1,
								'enable_full_post_page'         => 0,
								'fcs_layout'			=> 'block',
								'fcs_block_design'		=> 1,
								'show_read_more'		=> 1,
								'show_read_more_cat'		=> 1,
								'limit'				=> '10',
								'limit_cat'			=> '10',
								'nav_style'			=> '',
								'cat'				=> array(),
								'fcs_block_on' 			=> array(
																	'home' 		=> 1,
																	'blog' 		=> 1,
																	'category' 	=> 1,
																	'search' 	=> 1,
																	'404'		=> 1,
																	)
							);
	
	$default_options = apply_filters('wpos_options_default_values', $wpos_options );
	
	// Update default options
	update_option( 'wpos_options', $default_options );

	// Overwrite global variable when option is update
	$wpos_options = wpos_get_theme_settings();
}

/**
 * Get Settings From Option Page
 * 
 * Handles to return all settings value
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0
 */
function wpos_get_theme_settings() {
	
	$options = get_option('wpos_options');
	
	$settings = is_array($options) 	? $options : array();
	
	return $settings;
}

/**
 * Get an option
 * Looks to see if the specified setting exists, returns default if not
 *
 * @package WPOS Tell Your Tale
 * @since 1.0
 */
function wpos_get_option( $key = '', $default = false ) {
	global $wpos_options;

	$value = ! empty( $wpos_options[ $key ] ) ? $wpos_options[ $key ] : $default;
	$value = apply_filters( 'wpos_get_option', $value, $key, $default );
	return apply_filters( 'wpos_get_option_' . $key, $value, $key, $default );
}

/**
 * Escape Tags & Slashes
 *
 * Handles escapping the slashes and tags
 *
 * @package  WPOS Tell Your Tale
 * @since 1.0
 */
function wpos_escape_attr($data) {
	return esc_attr( stripslashes($data) );
}

/**
 * Strip Slashes From Array
 *
 * @package WPOS Tell Your Tale
 * @since 1.0
 */
function wpos_slashes_deep($data = array(), $flag = false) {
	
	if($flag != true) {
		$data = wpos_nohtml_kses($data);
	}
	$data = stripslashes_deep($data);
	return $data;
}

/**
 * Strip Html Tags 
 * 
 * It will sanitize text input (strip html tags, and escape characters)
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0
 */
function wpos_nohtml_kses($data = array()) {
	
	if ( is_array($data) ) {
		
		$data = array_map('wpos_nohtml_kses', $data);
		
	} elseif ( is_string( $data ) ) {
		
		$data = wp_filter_nohtml_kses( trim($data) );
	}
	
	return $data;
}

/**
 * Convert an object to an associative array.
 * Can handle multidimensional arrays
 *
 * @package WPOS Tell Your Tale
 * @since 1.0
 */
function wpos_object_to_array( $data ) {
	if ( is_array( $data ) || is_object( $data ) ) {
		$result = array();
		foreach ( $data as $key => $value ) {
			$result[ $key ] = wpos_object_to_array( $value );
		}
		return $result;
	}
	return $data;
}

/**
 * Function to add array after specific key
 * 
 * @package WP Team Showcase and Slider Pro
 * @since 1.0.0
 */
function wpos_add_array(&$array, $value, $index, $from_last = false) {
	
	if( is_array($array) && is_array($value) ) {

		if( $from_last ) {
			$total_count 	= count($array);
			$index 			= (!empty($total_count) && ($total_count > $index)) ? ($total_count-$index): $index;
		}

		$split_arr 	= array_splice($array, max(0, $index));
    	$array 		= array_merge( $array, $value, $split_arr);
	}
	return $array;
}

/**
 * Get theme settings tab
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0
 */
function wpos_theme_sett_tab( $only_tab_key = false ){

	// Talking default
	$theme_tabs_keys = array();

	$theme_tabs = array(
						
						
						'styling_options' 		=> array(
													'name'		=> __('Styling Options', 'wpos-theme'),
													'icon_cls'	=> 'dashicons-dashboard',
													),
						'font_options'			=> array(
													'name'		=> __('Typeography', 'wpos-theme'),
													'icon_cls'	=> 'dashicons-editor-textcolor',
													),
						
						
						
						'blog_page_options'		=> array(
													'name'		=> __('Blog Page Options', 'wpos-theme'),
													'icon_cls'	=> ' dashicons-feedback',
													),
						'post_page_options'		=> array(
													'name'		=> __('Single Blog Page Options', 'wpos-theme'),
													'icon_cls'	=> ' dashicons-feedback',
													),
						'cat_page_options'		=> array(
													'name'		=> __('Category Page Options', 'wpos-theme'),
													'icon_cls'	=> ' dashicons-feedback',
													),						
						
						'footer_options' 		=> array(
													'name'		=> __('Footer Options', 'wpos-theme'),
													'icon_cls'	=> 'dashicons-editor-insertmore',
													),
						'social_options'		=> array(
													'name'		=> __('Social Profiles', 'wpos-theme'),
													'icon_cls'	=> 'dashicons-twitter',
													),
	
	
	
	
            
					);
	$theme_tabs = apply_filters( 'wpos_theme_settings_tab', $theme_tabs );

	// If only want to get key
	if( $only_tab_key == true ) {
		foreach ($theme_tabs as $tab_key => $tab_value) {
			$theme_tabs_keys[] = $tab_key;
			
			if( !empty($tab_value['sub_menu']) ) {
				$theme_tabs_keys = array_merge( $theme_tabs_keys, array_keys($tab_value['sub_menu']) );
			}
		}
		$theme_tabs = $theme_tabs_keys;
	}

	return $theme_tabs;
}






/**
 * Blog design
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0
 */
function wpos_blog_design() {
    
	$wpos_blog_design = array(
            
                                'grid'  =>    array(
                                    
                                'Design-1'	=> 	'design-1',
                                'Design-2'	=> 	'design-2',
                                'Design-3'	=> 	'design-3',
                                'Design-4'	=> 	'design-4',
                                'Design-5'	=> 	'design-5',
				'Design-6'	=> 	'design-6',
                                'Design-7'	=> 	'design-7',
                                'Design-8'	=> 	'design-8',
                                'Design-9'	=> 	'design-9',
                                'Design-10'	=> 	'design-10',
				'Design-11'	=> 	'design-11',
                                'Design-12'	=> 	'design-12',
                                'Design-13'	=> 	'design-13',
                                'Design-14'	=> 	'design-14',
                                'Design-15'	=> 	'design-15',
				'Design-16'	=> 	'design-16',
                                'Design-17'	=> 	'design-17',
                                'Design-18'	=> 	'design-18',
                                'Design-19'	=> 	'design-19',
                                'Design-20'	=> 	'design-20',
				'Design-21'	=> 	'design-21',
                                'Design-22'	=> 	'design-22',
                                'Design-23'	=> 	'design-23',
                                'Design-24'	=> 	'design-24',
				'Design-25'	=> 	'design-25',
                                    
                                    
                                ),
            
                                'list'  =>    array(
                                    
                                   'Design-1'	=> 	'design-1',
                                   'Design-2'	=> 	'design-2',
                                   'Design-3'	=> 	'design-3',
                                   'Design-4'	=> 	'design-4',
                                   'Design-5'	=> 	'design-5',
                                   'Design-6'	=> 	'design-6',
                                    
                                ),
            
                                'masonry'  =>    array(
                                    
                                'Design-1'	=> 	'design-1',
                                'Design-2'	=> 	'design-2',
                                'Design-3'	=> 	'design-3',
                                'Design-4'	=> 	'design-4',
                                'Design-5'	=> 	'design-5',
				'Design-6'	=> 	'design-6',
                                'Design-7'	=> 	'design-7',
                                'Design-8'	=> 	'design-8',
                                'Design-9'	=> 	'design-9',
                                'Design-10'	=> 	'design-10',
				'Design-11'	=> 	'design-11',
                                'Design-12'	=> 	'design-12',
                                'Design-13'	=> 	'design-13',
                                'Design-14'	=> 	'design-14',
                                'Design-15'	=> 	'design-15',
				'Design-16'	=> 	'design-16',
                                'Design-17'	=> 	'design-17',
                                'Design-18'	=> 	'design-18',
                                'Design-19'	=> 	'design-19',
                                'Design-20'	=> 	'design-20',
				'Design-21'	=> 	'design-21',
                                'Design-22'	=> 	'design-22',
                                'Design-23'	=> 	'design-23',
                                'Design-24'	=> 	'design-24',
                                ),

                                
            
                                  );

	return apply_filters( 'wpos_blog_design', $wpos_blog_design );
}



/**
 * Get theme web fonts
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0
 */
function wpos_web_fonts() {

	$wpos_web_fonts = array('Arial', 'Courier New', 'Georgia', 'Helvetica', 'Lucida Sans', 'Lucida Sans Unicode', 'Palatino Linotype', 'Tahoma', 'Times New Roman', 'Trebuchet MS', 'Verdana');
	$wpos_web_fonts = apply_filters( 'wpos_body_web_fonts', $wpos_web_fonts );
	
	sort($wpos_web_fonts); // Sorting array

	return $wpos_web_fonts;
}

/**
 * Get theme google fonts
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0
 */
function wpos_google_fonts() {

	$google_fonts = array( 'Open Sans'	=> array(
												'Open+Sans:300' 		=> 'Open Sans 300',
												'Open+Sans:300italic' 	=> 'Open Sans 300 Italic',
												'Open+Sans:regular' 	=> 'Open Sans Regular',
												'Open+Sans:italic' 		=> 'Open Sans Italic',
												'Open+Sans:600' 		=> 'Open Sans 600',
												'Open+Sans:600italic' 	=> 'Open Sans 600 Italic',
												'Open+Sans:700' 		=> 'Open Sans 700',
												'Open+Sans:700italic' 	=> 'Open Sans 700 Italic',
												'Open+Sans:800' 		=> 'Open Sans 800',
												'Open+Sans:800italic' 			=> 'Open Sans 800 Italic',
												'Open+Sans+Condensed:300' 		=> 'Open Sans Condensed 300',
												'Open+Sans+Condensed:300italic' => 'Open Sans Condensed 300 Italic',
												'Open+Sans+Condensed:700' 		=> 'Open Sans Condensed 700'
												),
							'Roboto'		=> array(
												'Roboto' 			=> 'Roboto',
												'Roboto+Condensed' 	=> 'Roboto Condensed'
												),
							'Lato'			=> array(
												'Lato'	=> 'Lato'
												),
							'Droid Sans' 	=> array(
												'Droid+Sans' => 'Droid Sans'
												),
							'Ubuntu' 		=> array(
												'Ubuntu' 			=> 'Ubuntu',
												'Ubuntu+Condensed' 	=> 'Ubuntu Condensed'
												),
							'Oswald' 		=> array(
												'Oswald' 		=> 'Oswald',
												'Oswald:300' 	=> 'Oswald 300'
												),
							'PT Sans'		=> array(
												'PT+Sans' => 'PT Sans'
												),
							'Poppins'		=> array(
												'Poppins:300'	=> 'Poppins 300',
												'Poppins:400'	=> 'Poppins 400',
												'Poppins:500'	=> 'Poppins 500',
												'Poppins:600'	=> 'Poppins 600',
												'Poppins:700'	=> 'Poppins 700'
												),
							'Raleway'		=> array(
												'Raleway:400' => 'Raleway 400',
												'Raleway:600' => 'Raleway 600',
												'Raleway:700' => 'Raleway 700',
												),
							'Montserrat'	=> array(
												'Montserrat:400' => 'Montserrat',
												'Montserrat:700' => 'Montserrat 700'
												),
							);
	
	$google_fonts = apply_filters( 'wpos_body_web_fonts', $google_fonts );
	
	ksort($google_fonts); // Sorting array

	return $google_fonts;
}

/**
 * Converting google font data to web font data
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0
 */
function wpos_google_font_data( $font_family = '' ) {

	$result = array();

	$font_data = explode(':', $font_family);

	if( !empty($font_data[1]) ) {
		preg_match_all('/\d+/', $font_data[1], $matches);

		if( !empty($matches[0]) ){
			$font_weight = isset($matches[0]) ? reset($matches[0]) : '';
		}

		if( !empty($font_weight) ) {
			$font_style = str_replace($font_weight, '', $font_data[1]);
		} else {
			$font_style = $font_data[1];
		}
	}

	$result['font_family'] = isset($font_data[0]) ? str_replace('+', ' ', $font_data[0]) : '';
	$result['font_weight'] = isset($font_weight) ? $font_weight : '';
	$result['font_style']  = isset($font_style) ? $font_style : '';

	return $result;
}



/**
 * Get theme settings tab
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0
 */
function wpos_social_links() {

	$social_links['social'] = array(
								'facebook' 	=> array(
														'label' 		=> __('Facebook', 'wpos-theme'),
														'description'	=> __('Your facebook page/profile url.','wpos-theme'),
														'icon' 			=> 'fa-facebook',
														'class' 		=> 'wpos-facebook-icon'
													),
								'twitter' 	=> array(
														'label' 		=> __('Twitter', 'wpos-theme'),
														'description'	=> __('Your twitter url.','wpos-theme'),
														'icon' 			=> 'fa-twitter',
														'class' 		=> 'wpos-twitter-icon'
													),
							 	'google_plus' 	=> array(
														'label' => __('Google+', 'wpos-theme'),
														'description'=> __('Your Google+ url.','wpos-theme'),
														'icon' 			=> 'fa-google-plus',
														'class' 		=> 'wpos-google-plus-icon'
													),
							 	'linkedin' 	=> array(
														'label' => __('LinkedIn', 'wpos-theme'),
														'description'=> __('Your LinkedIn page/profile url.','wpos-theme'),
														'icon' 			=> 'fa-linkedin',
														'class' 		=> 'wpos-linkedin-icon'
													),
							 	'instagram' 	=> array(
														'label' => __('Instagram', 'wpos-theme'),
														'description'=> __('Your Instagram page/profile url.','wpos-theme'),
														'icon' 			=> 'fa-instagram',
														'class' 		=> 'wpos-instagram-icon'
													),
							 	'youtube' 	=> array(
														'label' => __('YouTube', 'wpos-theme'),
														'description'=> __('Your youtube url.','wpos-theme'),
														'icon' 			=> 'fa-youtube',
														'class' 		=> 'wpos-youtube-icon'
													),
							 	'rss_feed_url' 	=> array(
														'label' => __('RSS Feed URL', 'wpos-theme'),
														'description'=> __('Enter the rss feed URL for your blog.','wpos-theme'),
														'icon' 			=> 'fa-rss',
														'class' 		=> 'wpos-rss-icon'
													),
							 	
								
						);
	
	return apply_filters( 'wpos_social_links', $social_links );
}

/**
 * Change the excerpt length
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0
 */
function wpos_excerpt_length( $length ) {
	$excerpt = wpos_get_option('excerpt_lenght', '55');
	return $excerpt;
}
add_filter( 'excerpt_length', 'wpos_excerpt_length', 999 );

/**
 * Function to get post format class
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0
 */
function wpos_post_format_cls( $format = '' ) {

	switch ($format) {
		case 'aside':
			$class = 'fa fa-file-text';
			break;
		case 'image':
			$class = 'fa fa-picture-o';
			break;
		case 'gallery':
			$class = 'fa fa-camera-retro';
			break;
		case 'link':
			$class = 'fa fa-link';
			break;
		case 'quote':
			$class = 'fa fa-quote-left';
			break;
		case 'status':
			$class = 'fa fa-commenting';
			break;
		case 'video':
			$class = 'fa fa-film';
			break;
		case 'audio':
			$class = 'fa fa-music';
			break;
		default:
			$class = 'fa fa-thumb-tack';
			break;
	}
	return $class;
}

/**
 * Function to get footer sidebar class according to settings
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0
 */
function wpos_grid_cls( $grid = '' ) {

	switch ( $grid ) {
		case '2':
			$class = 'medium-6';
			break;
		case '3':
			$class = 'medium-4';
			break;
		case '4':
			$class = 'medium-3';
			break;
		default:
			$class = 'medium-12';
			break;
	}
	return $class;
}

/**
 * Function to get category hirarchical
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0
 */
function wpos_get_cat_hirarchy() {

	$cats = array();

	$cat_args = array(
						'taxonomy' 		=> 'category',
						'fields'		=> 'ids',
						'parent'		=> 0,
						'hide_empty' 	=> true,
						'hierarchical'	=> true,
					);
	$wpos_categories = get_categories( $cat_args );
	
	if( !is_wp_error($wpos_categories) && !empty($wpos_categories) ) {
		foreach ($wpos_categories as $cat_key => $cat_val) {
			
			$sub_cat_args = array(
						'taxonomy' 		=> 'category',
						'fields'		=> 'ids',
						'hide_empty' 	=> true,
						'hierarchical'	=> true,
						'child_of'		=> $cat_val
					);
			$wpos_sub_cats = get_categories( $sub_cat_args );

			if( !empty($wpos_sub_cats) ) {
				$cats[$cat_val] = $wpos_sub_cats;
			} else {
				$cats[$cat_val] = $cat_val;
			}
		}
	}
	return $cats;
}

/**
 * Function to merge array with reference to another array
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0
 */
function wpos_merge_arr(&$array, $arr1) {

	if( !empty($arr1) && is_array($arr1) ) {

		$category_keys 	= array_keys($arr1);	// Category keys
		$stored_keys 	= array_keys($array); 	// Stored category keys

		foreach ($arr1 as $arr_key => $arr_val) {
			
			if( !empty($arr_val) && is_array($arr_val) ) {
				
				if( isset($array[$arr_key]) && is_array($array[$arr_key]) ){
					$array[$arr_key] = array_intersect($array[$arr_key], $arr_val);

					$differnce_arr = array_diff($arr_val, $array[$arr_key]);

					if( !empty($differnce_arr) ) {
						$array[$arr_key] = array_merge($array[$arr_key], $differnce_arr);
					}
				} else {
					$array[$arr_key] = $arr_val;
				}
			} else {
				$array[$arr_key] = $arr_val;
			}
		}

		foreach ($array as $cat_key => $cat_val) {
			if( !in_array( $cat_key, $category_keys) ) {
				unset( $array[$cat_key] );
			}
		}

	} // End of if

	return $array;
}
/**
 * Function to merge social link
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0
 */
function wpos_social_link_merge($arra1,$arra2){
	$return_arra = array();
	foreach ($arra1 as $key => $value) {
		$return_arra[$key] = array(	'label'=>$arra2[$key]['label'],
									'description'=>$arra2[$key]['description'],
									'icon'=>$arra2[$key]['icon'],
									);
		
	}

	foreach ($arra2 as $key => $value) {
		if (!array_key_exists($key,$return_arra)){
			$return_arra[$key] = $value;
		}
	}
	return $return_arra;
	
}
/**
 * Function to get unique value number
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0
 */
function wpos_get_unique() {
	static $unique = 0;
	$unique++;

	return $unique;
}

/**
 * Function to get post featured image
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0.0
 */
function wpos_get_post_featured_image( $post_id = '', $size = 'full' ) {
	
	$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post_id ), $size );
	
	if( !empty($image) ) {
		$image = isset($image[0]) ? $image[0] : '';
	}

	return $image;
}

/**
 * Handles the numeric pagination
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0.0
 */
function wpos_paginate_links( $args = array() ) {

	global $wp_query;

	// Pagination parameter
	if( get_query_var('page') ) {
		$paged = get_query_var('page');
	} else {
		$paged = get_query_var('paged');
	}

	$big = 999999999; // need an unlikely integer

	$paging = apply_filters('wpos_paging_args', array(
					'base' 		=> str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
					'format' 	=> '?paged=%#%',
					'current' 	=> max( 1, $paged ),
					'total'		=> isset($args['total']) ? $args['total'] : $wp_query->max_num_pages,
					'prev_next'	=> isset($args['prev_next']) ? $args['prev_next'] : true,
					'prev_text'	=> isset($args['prev_text']) ? $args['prev_text'] : '&laquo; '.__('Previous', 'wpos-theme'),
					'next_text'	=> isset($args['next_text']) ? $args['next_text'] : __('Next ', 'wpos-theme').' &raquo;',
				));
	echo paginate_links($paging);
}

/**
 * Convert color hex value to rgb format
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0.0
 */
function wpos_hex2rgb( $hex = '', $format = 'string' ) {

	if( empty($hex) ) return false;

	$hex = str_replace("#", "", $hex);

	if(strlen($hex) == 3) {
		$r = hexdec(substr($hex,0,1).substr($hex,0,1));
		$g = hexdec(substr($hex,1,1).substr($hex,1,1));
		$b = hexdec(substr($hex,2,1).substr($hex,2,1));
	} else {
		$r = hexdec(substr($hex,0,2));
		$g = hexdec(substr($hex,2,2));
		$b = hexdec(substr($hex,4,2));
	}

	$rgb = array($r, $g, $b);

	if( $format == 'string' ) {
		$rgb = implode(",", $rgb);
	}

	return $rgb;
}

/**
 * Determine where to display featured content section
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0.0
 */
function wpos_fcs_display() {
	
	global $wp_query;

	$display 		= false;
	$fcs_block_on 	= wpos_get_option( 'fcs_block_on', array() );

	if( is_404() && !empty($fcs_block_on['404']) ) {
		$display = true;
	} elseif( is_search() && !empty($fcs_block_on['search']) ) {
		$display = true;
	} elseif( $wp_query->is_posts_page && !empty($fcs_block_on['blog']) ) {
		$display = true;
	} elseif( is_front_page() && !empty($fcs_block_on['home']) ) {
		$display = true;
	} elseif( !is_front_page() && is_home() && !$wp_query->is_posts_page && !empty($fcs_block_on['home']) ) { // If Front page is not set and latest post is being displayed
		$display = true;
	} elseif( get_query_var('cat') && !empty($fcs_block_on['category']) ) { // If WordPress category page
		$display = true;
	}
	
	return $display;
}




/**
 * check swithes enable or not
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0.0
 */
function wpos_is_switch_enable($selected_val,$default_val) {
	if($selected_val == $default_val){
		return 'wpos-selected';
	}
	return '';
}

/**
 * check swithes enable or not
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0.0
 */
function wpos_get_image_src( $post_id = '', $size = 'full' ) {
    $size   = !empty($size) ? $size : 'full';
    $image  = wp_get_attachment_image_src( $post_id, $size );

    if( !empty($image) ) {
        $image = isset($image[0]) ? $image[0] : '';
    }

    return $image;
}

/**
 * Function to get old browser
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0
 */
function wpos_pro_old_browser() {
    global $is_IE, $is_safari, $is_edge;

    // Only for safari
    $safari_browser = wpos_pro_check_browser_safari();

    if( $is_IE || $is_edge || ($is_safari && (isset($safari_browser['version']) && $safari_browser['version'] <= 7.1)) ) {
        return true;
    }
    return false;
}

/**
 * Determine if the browser is Safari or not (last updated 1.7)
 *
 * @package WPOS Tell Your Tale
 * @since 1.0
 */
function wpos_pro_check_browser_safari() {
    
    // Takinf some variables
    $browser    = array();
    $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : "";

    if (stripos($user_agent, 'Safari') !== false && stripos($user_agent, 'iPhone') === false && stripos($user_agent, 'iPod') === false) {
        $aresult = explode('/', stristr($user_agent, 'Version'));
        if (isset($aresult[1])) {
            $aversion = explode(' ', $aresult[1]);
            $browser['version'] = ($aversion[0]);
        } else {
            $browser['version'] = '';
        }
        $browser['browser'] = 'safari';
    }
    return $browser;
}

/**
 * Function to get post external link or permalink
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0
 */
function wpos_pro_get_profile_post_link( $post_id = '' ) {

    $post_link = '';

    if( !empty($post_id) ) {

        $prefix = WPOS_PORTFOLIO_PREFIX;

        $post_link = get_post_meta( $post_id, $prefix.'project_url', true );
    }
    
    return $post_link;
}

/**
 * Function to get grid column based on grid
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0.0
 */
function wpos_grid_column( $grid = '' ) {
    
    if($grid == '2') {
        $grid_clmn = '6';
    } else if($grid == '3') {
        $grid_clmn = '4';
    }  else if($grid == '4') {
        $grid_clmn = '3';
    } else if($grid == '6') {
    	$grid_clmn ='2';
    } else if ($grid == '1') {
        $grid_clmn = '12';
    } else {
        $grid_clmn = '4';
    }
    return $grid_clmn;
}

/**
 * Function to get header title
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0.0
 */
function wpos_is_header_hide(){
	 global $post;	
	$prefix = WPOS_META_PREFIX;
	$page_layout_meta = get_post_meta($post->ID,$prefix.'page_layout',true);
	if(!empty($page_layout_meta) && $page_layout_meta == 'hide_both'){
		return true;
	}
	return false;
}

/**
 * Function to get header title
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0.0
 */
function wpos_get_header_top() {
    global $post;
	
	$prefix = WPOS_META_PREFIX;
	
	$page_layout_meta = get_post_meta($post->ID,$prefix.'page_layout',true);
	switch ($page_layout_meta) {
		case 'display_title':
			?>
				<h1 class="entry-title"><?php the_title(); ?></h1>			
			<?php
			break;

		case 'display_breadcrumbs':
			?>			
				<div class="wpos-breadcrumb"><?php wpos_get_breadcrumb();?></div>			
			<?php
			break;
		case 'dispaly_title_breadcrumbs':
			?>			
				<h1 class="entry-title"><?php the_title(); ?></h1>
				<div class="wpos-breadcrumb"><?php wpos_get_breadcrumb();?></div>			
			<?php
			break;
		case 'hide_both':
			echo '';
			break;
		
		default:
			?>
			<div class="wpos-entry-header">
				<h1 class="entry-title"><?php the_title(); ?></h1>
			</div><!-- end .wpos-inner-header -->
			<?php
			break;
	}
}

/**
 * Function to get breadcrumb
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0.0
 */
function wpos_get_breadcrumb() {
    echo '<a href="'.home_url().'" rel="nofollow">Home</a>';
    if (is_category() || is_single()) {
        echo "&nbsp;&nbsp;&#187;&nbsp;&nbsp;";
        the_category(' &bull; ');
            if (is_single()) {
                echo " &nbsp;&nbsp;&#187;&nbsp;&nbsp; ";
                the_title();
            }
    } elseif (is_page()) {
        echo "&nbsp;&nbsp;&#187;&nbsp;&nbsp;";
        echo the_title();
    } elseif (is_search()) {
        echo "&nbsp;&nbsp;&#187;&nbsp;&nbsp;Search Results for... ";
        echo '"<em>';
        echo the_search_query();
        echo '</em>"';
    }
}

/**
 * Function to display author
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0.0
 */
function wpos_display_author(){
	if( (wpos_get_option('enable_post_author') && !is_single()) || (wpos_get_option('enable_single_post_author') && is_single()) ){
		wpos_post_stats( array('author') ); 
	}
}

/**
 * Function to display date
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0.0
 */
function wpos_display_time(){
	if( (wpos_get_option('enable_post_date') && !is_single()) || (wpos_get_option('enable_single_post_date') && is_single()) ){
		wpos_post_stats( array('time') ); 
	}
}

/**
 * Function to display category
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0.0
 */
function wpos_display_category(){
	if( (wpos_get_option('enable_post_cat') && !is_single()) || (wpos_get_option('enable_single_post_cat') && is_single()) ){
		wpos_post_stats( array('category') ); 
	}
}

/**
 * Function to display comment count
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0.0
 */
function wpos_display_comment_count(){
	if( (wpos_get_option('enable_post_count') && !is_single()) || (wpos_get_option('enable_single_post_count') && is_single()) ){
		wpos_post_stats( array('comment') ); 
	}
}

/**
 * Function to display tag
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0.0
 */
function wpos_display_tag(){
	if( (wpos_get_option('enable_post_tag') && !is_single()) || (wpos_get_option('enable_single_post_tag') && is_single()) ){
		wpos_post_stats( array('tag') ); 
	}
}

/**
 * Function to display search menu
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0.0
 */
function wpos_display_search_menu(){
	get_template_part("search-top-nav"); 
}


/**
 * Function to display hamburger menu
 * 
 * @package WPOS Tell Your Tale
 * @since 1.0.0
 */
function wpos_display_hamburger_menu($menu_calss="right"){ 
if( wpos_get_option('hamburger_menu') ) { ?>

<a class="flypanels-button-<?php echo $menu_calss; ?> icon-menu" data-panel="hamburger-<?php echo $menu_calss; ?>" href="javascript:void(0);"><i class="fa fa-bars"></i></a>

<?php } }

/**
 * Function to get footer sidebar class according to settings
 * 
 * @package WP Clean Responsive
 * @since 1.0
 */
function wpos_footer_sidebar_cls(){

	$footer_widget_column = wpos_get_option('footer_clmn', 3);

	switch ($footer_widget_column) {
		case '1':
			$class = 'wpspw-medium-12';
			break;
		case '2':
			$class = 'wpspw-medium-6';
			break;
		case '3':
			$class = 'wpspw-medium-4';
			break;
		default:
			$class = 'wpspw-medium-3';
			break;
	}
	return $class;
}
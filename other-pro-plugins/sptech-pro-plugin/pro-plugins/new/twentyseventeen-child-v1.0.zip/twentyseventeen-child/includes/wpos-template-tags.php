<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;
/**
 * Handles the footer copy right text
 *
 * @package WP Clean Responsive
 * @since 1.0.0
 */
function wpos_footer_copyright() {
	
	$enable_copyright = wpos_get_option('enable_copyright', '0');
	
	if(empty($enable_copyright)) return false;

	$current_year = date( 'Y', current_time('timestamp') );

	$copyright_text = wpos_get_option('copyright_text');
	$copyright_text = str_replace('{year}', $current_year, $copyright_text);

	return $copyright_text;
}

/**
 * Handles the Social network profiles
 *
 * @package WP Clean Responsive
 * @since 1.0.0
 */
function wpos_social_networks( $location = 'header' ) {

	// Taking some defaults
	$social_networks = '';

	

	if( $location == 'footer' ){
		$social_network_enable = wpos_get_option('social_media_footer');
	} else {
		$social_network_enable = wpos_get_option('social_media_header');
	}

	if( empty($social_network_enable) ) return $social_networks;

	$social = wpos_get_option( 'social' );
	$social_links = wpos_social_links();
	
	if(!empty($social))
	{
		foreach ($social as $social_key => $social_value) {
			
			$social_lbl = $social_links['social'][$social_key]['label'];
			$social_cls = $social_links['social'][$social_key]['class'];
			$social_icon = $social_links['social'][$social_key]['icon'];
			if(!empty($social_value))
			{
				$social_networks .= "<a href='{$social_value}' title='{$social_lbl}' target='_blank' class='wpos-social-network-icon {$social_cls}'><i class='fa {$social_icon}'></i></a>";
			}

		}
	}
	
	return $social_networks;
}

<?php
	$category 			= get_the_category();
	$cat_id 			= $category[0]->term_id;
	$cat_name 			= $category[0]->cat_name;
	$current_post_id 	= get_the_ID();
	
	$query = new WP_Query( array ( 
				'post_type'      => 'post',
				'post__not_in' 	 => array($current_post_id),
				'showposts'      => 3,
				'orderby'        => 'post_date', 
				'order'          => 'DESC',
				'cat'            => $cat_id
				));

	// If post is there
	if( $query->have_posts() ) {
?>

<div class="cat-more-post wpspw-clearfix">
	<div class="cat-post">
		<h3 class="cat-title"><span><?php echo __('You may also like from', 'twentytwelve') .' '. $cat_name; ?></span></h3>
			<div class="row">
				<?php while ($query->have_posts()) : $query->the_post(); ?>
					<div class="wpspw-medium-4 wpspw-columns end">
						<div class="entry-image-bg"> 
							<a class="entry-image-link" href="<?php the_permalink();?>" title="<?php the_title(); ?>"><?php  the_post_thumbnail('medium'); ?></a>
						</div><!-- end .entry-image-bg -->
						<div class="entry-title-header bgs">							
							<h6 class="related-entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h6>
						</div>
					</div><!-- end .medium-4 columns -->
				<?php endwhile;  ?>
			</div><!-- end .row -->
	</div><!-- end .cat-news -->
</div><!-- end .cat-more-news -->

<?php
	wp_reset_query(); // Reset query

} // End of check have post
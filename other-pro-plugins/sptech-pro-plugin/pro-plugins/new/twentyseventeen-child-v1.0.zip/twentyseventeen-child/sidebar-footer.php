<?php
/**
 * The Footer Sidebar. This sidebar contains the three footer widget areas.
 *
 * If no active widgets are in either sidebar, they will be hidden completely.
 *
 * @package WP Clean Responsive
 * @since 1.0
 */

if( wpos_get_option('enable_fwdgt') ) :
$footer_clmn = wpos_get_option('footer_clmn', 3);
?>

<div class="footer-sidebar-container">	
		
		<?php if ( is_active_sidebar('wpos-footer-sidebar-1') && ($footer_clmn >=1 && $footer_clmn <= 4) ) : ?>
        <div class="<?php echo wpos_footer_sidebar_cls(); ?> wpspw-columns wpos-footer-sidebar-1">	      
				<?php dynamic_sidebar( 'wpos-footer-sidebar-1' ); ?>	       
	    </div><!-- end .wpos-footer-sidebar-1 -->
        <?php endif; 
		if ( is_active_sidebar('wpos-footer-sidebar-2') && ($footer_clmn >=2 && $footer_clmn <= 4) ) : ?>
        <div class="<?php echo wpos_footer_sidebar_cls(); ?> wpspw-columns wpos-footer-sidebar-2">	       
				<?php dynamic_sidebar( 'wpos-footer-sidebar-2' ); ?>	     
	    </div><!-- end .wpos-footer-sidebar-2 -->
        <?php endif;
		if ( is_active_sidebar('wpos-footer-sidebar-3') && ($footer_clmn >=3 && $footer_clmn <= 4) ) : ?>
        <div class="<?php echo wpos_footer_sidebar_cls(); ?> wpspw-columns wpos-footer-sidebar-3">	       
				<?php dynamic_sidebar( 'wpos-footer-sidebar-3' ); ?>	       
	    </div><!-- end .wpos-footer-sidebar-3 -->
        <?php endif;
		if ( is_active_sidebar('wpos-footer-sidebar-4') && ($footer_clmn == 4) ) : ?>
        <div class="<?php echo wpos_footer_sidebar_cls(); ?> wpspw-columns wpos-footer-sidebar-4">	        
				<?php dynamic_sidebar( 'wpos-footer-sidebar-4' ); ?>	       
	    </div><!-- end .wpos-footer-sidebar-4 -->
        <?php endif; ?>

</div><!-- end .footer-sidebar-container -->

<?php endif ?>
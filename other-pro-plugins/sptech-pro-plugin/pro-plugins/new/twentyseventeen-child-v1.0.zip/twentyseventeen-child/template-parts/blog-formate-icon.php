<div class="icon">
    <div class="post-icon ">
        <span><i class="<?php echo wpos_post_format_cls(get_post_format()); ?>"></i></span>
    </div>
</div>	<!-- end post-icon -->  
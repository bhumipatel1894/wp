<?php
/**
 * Template Name:  Blog Page Template
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

$layouttype         = wpos_get_option('blog_layout_type');
$gridcol            = wpos_get_option('blog_grid');
$posts_per_page     = wpos_get_option('limit', 1);
$design             = wpos_get_option('blog_design'); 
$showreadmore		= wpos_get_option('show_read_more'); 
$showDate           = wpos_get_option('enable_post_date');
$showAuthor         = wpos_get_option('enable_post_author');
$show_comments      = wpos_get_option('enable_post_count');
$showCategory       = wpos_get_option('enable_post_cat');
$showContent        = wpos_get_option('show_content');
$showFullContent    = wpos_get_option('post_full_cnt');
$read_more_text      = wpos_get_option('readmore_text');
$show_tags          = wpos_get_option('enable_post_tag');
$link_target        = wpos_get_option('link_behaviour');
$words_limit		 = wpos_get_option('excerpt_lenght');
$hide_indx_feat_img         = wpos_get_option('hide_indx_feat_img', 0);
$hide_single_feat_img       = wpos_get_option('hide_single_feat_img');

$enable_post_formate        = wpos_get_option('enable_post_formate');

$effect ="effect-2";

$media_size = "full";
$post_design_file_path 	= get_stylesheet_directory() . '/blog-designs/'.$layouttype.'/'.$design.'.php';
$design_file 		= (file_exists($post_design_file_path)) ? $post_design_file_path : '';

$post_design_template 	= get_stylesheet_directory() . '/blog-designs/'.$layouttype.'/design-template.php';
$design_template 		= (file_exists($post_design_template)) ? $post_design_template : '';

global $paged, $post, $wpbawm_in_shrtcode;
$count 			= 0; 
$newscount 		= 0;
$grid_count		= 1;

get_header(); ?>

<div class="wrap blog-page-wrap">
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
		<header class="entry-header">
				<?php the_title( '<h2 class="entry-title">', '</h2>' ); ?>

				<?php twentyseventeen_edit_link( get_the_ID() ); ?>

			</header><!-- .entry-header -->
			<?php // Pagination parameter
						if(is_home() || is_front_page()) {
							$paged = get_query_var('page');
						} else {
							$paged = get_query_var('paged');
						}
						
						$order 			= 'DESC';
						$orderby 		='date';
						// WP Query Parameters
						$args = array ( 
							'post_type'      		=> 'post',
							'post_status' 			=> array('publish'),
							'order'          		=> $order,
							'orderby'        		=> $orderby, 
							'posts_per_page' 		=> $posts_per_page, 
							'paged'          		=> $paged,		
							'ignore_sticky_posts'	=> true,
						);    

						// WP Query
						$query 		= new WP_Query($args);
						$post_count = $query->post_count;
						$total_post 	= $query->found_posts;
						
						// If post is there
						if ( $query->have_posts() ) { 
						
							 // Include shortcode html file
									if( $design_template ) {
										include( $design_template );
									}
						
						} // end of have_post()

						wp_reset_query(); // Reset WP Query

					  ?>
		</main><!-- #main -->
	</div><!-- #primary -->
	
</div><!-- .wrap -->

<?php get_footer();

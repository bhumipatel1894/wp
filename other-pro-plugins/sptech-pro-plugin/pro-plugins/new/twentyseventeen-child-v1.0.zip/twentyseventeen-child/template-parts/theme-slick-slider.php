<?php if ( get_post_gallery() ) {
	            	$gallery = get_post_gallery( get_the_ID(), false );
		            if( !empty($gallery['ids']) ) {
		           	 	$ids = explode( ",", $gallery['ids'] );?>
		           	 	<div class="wpos-theme-slick-slider">							
								<?php foreach( $ids as $id ) :
								$link   = wp_get_attachment_url( $id );?>
								<div class="wpos-slide">
									<img src="<?php echo $link; ?>" class="wpos-slide-image" alt="Gallery image" />
								</div>
								<?php
							endforeach;?>							
			        	</div>
        		<?php } // End of inner if
        		} ?>
<script>
jQuery(document).ready(function(){
jQuery('.wpos-theme-slick-slider').slick({
	dots: false,
	prevArrow : '<button type="button" class="slick-prev">&#x2039;</button>',
	nextArrow : '<button type="button" class="slick-next">&#x203A;</button>'
	
	});
});
</script>				
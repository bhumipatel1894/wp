<?php
/**
 * 'wpbaw_gridbox' Shortcode
 * 
 * @package WP News and Five Widgets Pro
 * @since 2.1
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

function wpbaw_pro_get_gridbox_blog( $atts, $content = null ) {
	
	// Shortcode Parameters
	extract(shortcode_atts(array(
		'limit' 				=> '15',
		'category' 				=> '',
		'include_cat_child'		=> 'true',
		'category_name' 		=> '',
		'design'	 			=> 'design-1',		
		'image_fit' 			=> 'true',	
		'pagination' 			=> 'true',
		'pagination_type'		=> 'numeric',
		'show_date' 			=> 'true',
		'show_author' 			=> 'true',
		'show_category_name'	=> 'true',
		'show_content' 			=> 'true',		
		'show_read_more' 		=> 'true',
		'content_words_limit' 	=> '5',
		'content_tail'			=> '...',
		'order'					=> 'DESC',
		'orderby'				=> 'date',
		'link_target'			=> 'self',
		'posts'					=> array(),
		'exclude_post'			=> array(),
		'exclude_cat'			=> array(),
		'query_offset'			=> '',
		'image_height'			=> '',
		'read_more_text'		=> '',
	), $atts, 'wpbaw_gridbox'));

	$shortcode_designs 	= wpbaw_blog_gridbox_designs();
    $content_tail 		= html_entity_decode($content_tail);
    $posts_per_page		= (!empty($limit)) 						? $limit 						: '6';
    $cat 				= (!empty($category))					? explode(',',$category) 		: '';
	$blogcategory_name 	= ($category_name) 						? $category_name 				: '';
	$blogdesign 			= ($design && (array_key_exists(trim($design), $shortcode_designs))) ? trim($design) 	: 'design-1';
	$blogpagination 	= ($pagination == 'true')				? true							: false;
	$pagination_type 	= ($pagination_type == 'prev-next')		? 'prev-next' 					: 'numeric';
	$showAuthor 		= ($show_author == 'false')				? false							: true;	
	$showDate 			= ( $show_date == 'true' ) 				? true 							: false;
	$blogpagination 	= ($pagination == 'false')				? false							: true;
	$showCategory 		= ( $show_category_name == 'true' ) 	? true 							: false;
	$showContent 		= ( $show_content == 'true' ) 			? true 							: false;	
    $words_limit 		= !empty($content_words_limit) 			? $content_words_limit 			: '20';	
	$image_fit			= ($image_fit == 'false')				? false 						: true;
	$showreadmore 		= ( $show_read_more == 'true' ) 		? true 							: false;
	$order 				= ( strtolower($order) == 'asc' ) 		? 'ASC' 						: 'DESC';
	$orderby 			= (!empty($orderby))					? $orderby						: 'date';
	$link_target 		= ($link_target == 'blank') 			? '_blank' 						: '_self';
	$posts 				= !empty($posts)						? explode(',', $posts) 			: array();
	$exclude_post 		= !empty($exclude_post)					? explode(',', $exclude_post) 	: array();
	$exclude_cat		= !empty($exclude_cat)					? explode(',', $exclude_cat) 	: array();
	$query_offset		= !empty($query_offset)					? $query_offset 				: null;
	$read_more_text 	= !empty($read_more_text) 				? $read_more_text 				: __('Read More', 'sp-news-and-widget');
	$image_height 		= (!empty($image_height)) 				? $image_height 				: '';
	$height_css 		= ($image_height) 						? 'height:'.$image_height.'px;' : '';
	
	// Shortcode File
	$design_file_path 	= WPBAW_PRO_DIR . '/templates/grid-box/' . $blogdesign . '.php';
	$design_file 		= (file_exists($design_file_path)) 	? $design_file_path : '';

	// Taking some globals
	global $paged, $post;
	
	// Taking some defaults
	$count 			= 0;
	$newscount 		= 0;
	$grid_count 	= 1;
	$image_fit_class	= ($image_fit) 	? 'wpbaw-image-fit' : '';
	$default_img	= wpbaw_pro_get_option('default_img');

	// Pagination Variable
	if(is_home() || is_front_page()) {
		$paged = get_query_var('page');
	} else {
		$paged = get_query_var('paged');
	}

	// Query Parameter
	$args = array (
		'post_type'     	 	=> WPBAW_PRO_POST_TYPE,
		'post_status'			=> array( 'publish' ),
		'order'          		=> $order,
		'orderby'        		=> $orderby,
		'posts_per_page' 		=> $posts_per_page,
		'paged'          		=> $paged,
		'post__in'				=> $posts,
		'post__not_in'			=> $exclude_post,
		'ignore_sticky_posts'	=> true,
		'offset'				=> $query_offset,
	);
	
	// Category Parameter
	if( !empty($cat) ) {

		$args['tax_query'] = array(
								array(
									'taxonomy' 			=> WPBAW_PRO_CAT,
									'field' 			=> 'term_id',
									'terms' 			=> $cat,
									'include_children'	=> $include_cat_child,
							));

	} else if( !empty($exclude_cat) ) {
		
		$args['tax_query'] = array(
									array(
										'taxonomy' 			=> WPBAW_PRO_CAT,
										'field' 			=> 'term_id',
										'terms' 			=> $exclude_cat,
										'operator'			=> 'NOT IN',
										'include_children'	=> $include_cat_child,
								));
	}

	// WP Query
	$query 			= new WP_Query($args);
	$post_count 	= $query->post_count;

	ob_start();

	// If post is there
	if ( $query->have_posts() ) {
		
		if ($blogcategory_name != '') { ?>
			<h1 class="category-title-main">		   
				<?php echo $blogcategory_name; ?>
			</h1>
		<?php } ?>

	<div class="wpbaw-gridbox-main <?php echo $blogdesign.' '.$image_fit_class; ?> wpbaw-clearfix">	
		  	
		<?php while ( $query->have_posts() ) : $query->the_post();            	
            	$count++;
            	$news_links 			= array();
            	$css_class 				= '';
               	$terms 					= get_the_terms( $post->ID, WPBAW_PRO_CAT );
               	$post_link 				= wpbaw_pro_get_post_link( $post->ID );
				$post_featured_image 	= wpbaw_pro_get_post_featured_image( $post->ID, 'large', true );
				$post_featured_image 	= ($post_featured_image) ? $post_featured_image : $default_img;
                
				if($terms) {
					foreach ( $terms as $term ) {
						$term_link = get_term_link( $term );
						$news_links[] = '<a href="' . esc_url( $term_link ) . '">'.$term->name.'</a>';
					}
                }
                $cate_name = join( " ", $news_links );
				if( $design_file ) {
              		include( $design_file );
              	}
				
				$newscount++;
				$grid_count++;
            	endwhile;
           	?>			
	</div>
	<?php if($blogpagination) { ?>
		<div class="wpbaw-blog-pagination wpbaw-clearfix <?php echo $blogdesign;?>">
			<?php if($pagination_type == "numeric") {
				echo wpbaw_pro_pagination(array('paged' => $paged, 'total' => $query->max_num_pages));
			} else { ?>
				<div class="button-blog-p"><?php next_posts_link( '&laquo; '.__('Next', 'sp-blog-and-widget'), $query->max_num_pages ); ?></div>
				<div class="button-blog-n"><?php previous_posts_link( __('Previous', 'sp-blog-and-widget').' &raquo;' ); ?> </div>
			<?php } ?>
		</div>
	<?php }

	} // End of have_post()

	wp_reset_query(); // Reset WP Query

	$content .= ob_get_clean();
	return $content;			             
}

// 'wpbaw_gridbox' shortcode
add_shortcode('wpbaw_gridbox', 'wpbaw_pro_get_gridbox_blog');
<?php
/**
 * Widget API: Latest Blog Slider Widget Class
 *
 * @package WP Blog and Widgets Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

function wpbaw_pro_latest_blog_slider_widget() {
    register_widget( 'Wpbaw_Pro_Lbsw_Widget' );
}

// Action to register widget
add_action( 'widgets_init', 'wpbaw_pro_latest_blog_slider_widget' );

/**
 * Latest Blog Slider Widget Class
 *
 * @package WP Blog and Widgets Pro
 * @since 1.0.0
 */
class Wpbaw_Pro_Lbsw_Widget extends WP_Widget {

    /**
     * Sets up a new widget instance.
     *
     * @package WP Blog and Widgets Pro
     * @since 1.0.0
     */
    function __construct() {

        $widget_ops     = array( 'classname' => 'wpbaw-pro-lbsw', 'description' => __( "Display Latest Blog Items with slider.", 'wp-blog-and-widgets' ) );
        parent::__construct('wpbaw_pro_lbsw', __('Latest Blog Slider Widget', 'wp-blog-and-widgets'), $widget_ops);
    }

    /**
     * Handles updating settings for the current widget instance.
     *
     * @package WP Blog and Widgets Pro
     * @since 1.0.0
     */
    function update($new_instance, $old_instance) {
        
        $instance = $old_instance;

        $instance['title']              = sanitize_text_field( $new_instance['title'] );
        $instance['num_items']          = !empty($new_instance['num_items']) ? $new_instance['num_items'] : 5;
		$instance['author']             = !empty($new_instance['author']) ? 1 : 0;
        $instance['date']               = !empty($new_instance['date']) ? 1 : 0;
        $instance['show_category']      = !empty($new_instance['show_category']) ? 1 : 0;
        $instance['category']           = intval( $new_instance['category'] ); 
        $instance['arrows']             = $new_instance['arrows'];
        $instance['autoplay']           = $new_instance['autoplay'];
        $instance['autoplayInterval']   = (!empty($new_instance['autoplayInterval'])) ? $new_instance['autoplayInterval'] : 5000;
        $instance['speed']              = (!empty($new_instance['speed'])) ? $new_instance['speed'] : 500;
		$instance['link_target']        = !empty($new_instance['link_target']) ? 1 : 0;
        $instance['query_offset']       = !empty($new_instance['query_offset']) ? $new_instance['query_offset'] : '';
		$instance['image_fit']          = !empty($new_instance['image_fit']) ? 1 : 0;
        $instance['media_size']         = $new_instance['media_size'];
        $instance['image_height']       = $new_instance['image_height'];

        return $instance;
    }

    /**
     * Outputs the settings form for the widget.
     *
     * @package WP Blog and Widgets Pro
     * @since 1.0.0
     */
    function form( $instance ) {
        
        $defaults = array(
                'num_items'         => 5,
                'title'             => __( 'Latest Blog Slider', 'sp-blog-and-widget' ),
				'author'            => 1, 
                'date'              => 1, 
                'show_category'     => 1,
                'category'          => 0,
                'arrows'            => "true",
                'autoplay'          => "true",      
                'autoplayInterval'  => 5000,                
                'speed'             => 500,
                'num_items'         => 5,
				'link_target'       => 0,
				'query_offset'      => '',
				'media_size' 		=> 'large',
				'image_fit' 		=> 1,
				'image_height'		=> '',
            );
        $instance = wp_parse_args( (array) $instance, $defaults );
    ?>
    
        <!-- Title -->
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e( 'Title:', 'wp-blog-and-widgets' ); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($instance['title']); ?>" />
        </p>

        <!-- Number of Items -->
        <p>
            <label for="<?php echo $this->get_field_id('num_items'); ?>"><?php _e( 'Number of Items:', 'wp-blog-and-widgets' ); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('num_items'); ?>" name="<?php echo $this->get_field_name('num_items'); ?>" type="number" min="-1" value="<?php echo esc_attr($instance['num_items']); ?>" />
        </p>
		<!-- Query Offset -->
        <p>
            <label for="<?php echo $this->get_field_id('query_offset'); ?>"><?php esc_html_e( 'Query Offset:', 'sp-blog-and-widget' ); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('query_offset'); ?>" name="<?php echo $this->get_field_name('query_offset'); ?>" type="number" value="<?php echo $instance['query_offset']; ?>" min="0" />
            <span class="description"><em><?php _e('Query `offset` parameter to exclude number of post. Leave empty for default.', 'sp-blog-and-widget'); ?></em></span><br/>
            <span class="description"><em><?php _e('Note: This parameter will not work when Number of Items is set to -1.', 'sp-blog-and-widget'); ?></em></span>
        </p>

        <!-- Category -->
        <p>
            <label for="<?php echo $this->get_field_id( 'category' ); ?>"><?php _e( 'Category:', 'wp-blog-and-widgets' ); ?></label>
            <?php
            $dropdown_args = array( 
                                    'taxonomy'          => WPBAW_PRO_CAT,
                                    'class'             => 'widefat',
                                    'show_option_all'   => __( 'All', 'wp-blog-and-widgets' ),
                                    'id'                => $this->get_field_id( 'category' ),
                                    'name'              => $this->get_field_name( 'category' ),
                                    'selected'          => $instance['category']
                                );
            wp_dropdown_categories( $dropdown_args );
            ?>
        </p>
		 <!-- Display Date -->
        <p>
            <input id="<?php echo $this->get_field_id( 'date' ); ?>" name="<?php echo $this->get_field_name( 'date' ); ?>" type="checkbox" value="1" <?php checked( $instance['date'], 1 ); ?> />
            <label for="<?php echo $this->get_field_id( 'date' ); ?>"><?php _e( 'Display Date', 'wp-blog-and-widgets' ); ?></label>
        </p>
		  <!-- Display Author -->
        <p>
            <input id="<?php echo $this->get_field_id( 'author' ); ?>" name="<?php echo $this->get_field_name( 'author' ); ?>" type="checkbox" value="1" <?php checked( $instance['author'], 1 ); ?> />
            <label for="<?php echo $this->get_field_id( 'author' ); ?>"><?php _e( 'Display author', 'wp-blog-and-widgets' ); ?></label>
        </p>

        <!--  Display Category -->
        <p>
            <input id="<?php echo $this->get_field_id( 'show_category' ); ?>" name="<?php echo $this->get_field_name( 'show_category' ); ?>" type="checkbox" value="1" <?php checked( $instance['show_category'], 1 ); ?> />
            <label for="<?php echo $this->get_field_id( 'show_category' ); ?>"><?php _e( 'Display Category', 'wp-blog-and-widgets' ); ?></label>
        </p>
		 <!-- Open Link in a New Tab -->
        <p>
            <input id="<?php echo $this->get_field_id( 'link_target' ); ?>" name="<?php echo $this->get_field_name( 'link_target' ); ?>" type="checkbox" value="1" <?php checked( $instance['link_target'], 1 ); ?> />
            <label for="<?php echo $this->get_field_id( 'link_target' ); ?>"><?php _e( 'Open Link in a New Tab', 'sp-blog-and-widget' ); ?></label>
        </p>
		 <!-- Image Height -->
        <p>
            <label for="<?php echo $this->get_field_id('image_height'); ?>"><?php esc_html_e( 'Image Wrap Height(in px):', 'blog-designer-for-post-and-widget' ); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('image_height'); ?>" name="<?php echo $this->get_field_name('image_height'); ?>" type="number" value="<?php echo $instance['image_height']; ?>" min="1" />
        </p>
		 <!-- Image Fit OR Not -->
        <p>
            <input id="<?php echo $this->get_field_id( 'image_fit' ); ?>" name="<?php echo $this->get_field_name( 'image_fit' ); ?>" type="checkbox" value="1" <?php checked($instance['image_fit'], 1); ?> />
            <label for="<?php echo $this->get_field_id( 'image_fit' ); ?>"><?php _e( 'Image Fit', 'sp-blog-and-widget' ); ?></label>
        </p>
		 <!-- Media Size -->
        
		 <p>
            <label for="<?php echo $this->get_field_id('media_size'); ?>"><?php esc_html_e( 'Media Size:', 'blog-designer-for-post-and-widget' ); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('media_size'); ?>" name="<?php echo $this->get_field_name('media_size'); ?>" type="text" value="<?php echo $instance['media_size']; ?>" />
			<em><?php _e( 'Media Size values are', 'blog-designer-for-post-and-widget' ); ?> thumbnail, medium, large and full</em>      
		</p>
        
        <!-- Arrows -->
        <p>
            <label for="<?php echo $this->get_field_id( 'arrows' ); ?>"><?php _e( 'Arrows:', 'wp-blog-and-widgets' ); ?></label>
            <select name="<?php echo $this->get_field_name( 'arrows' ); ?>" class="widefat" id="<?php echo $this->get_field_id( 'arrows' ); ?>">
                <option value="true" <?php selected( $instance['arrows'], 'true' ); ?>><?php _e( 'True', 'wp-blog-and-widgets' ); ?></option>
                <option value="false" <?php selected( $instance['arrows'], 'false' ); ?>><?php _e( 'False', 'wp-blog-and-widgets' ); ?></option>
            </select>
        </p>

        <!-- Auto Play -->
        <p>
            <label for="<?php echo $this->get_field_id( 'autoplay' ); ?>"><?php _e( 'Auto Play:', 'wp-blog-and-widgets' ); ?></label>
            <select name="<?php echo $this->get_field_name( 'autoplay' ); ?>" class="widefat" id="<?php echo $this->get_field_id( 'autoplay' ); ?>">
                <option value="true" <?php selected( $instance['autoplay'], 'true' ); ?>><?php _e( 'True', 'wp-blog-and-widgets' ); ?></option>
                <option value="false" <?php selected( $instance['autoplay'], 'false' ); ?>><?php _e( 'False', 'wp-blog-and-widgets' ); ?></option>
            </select>
        </p>

        <!-- Autoplay Interval -->
        <p>
            <label for="<?php echo $this->get_field_id( 'autoplayInterval' ); ?>"><?php _e( 'Autoplay Interval:', 'wp-blog-and-widgets' ); ?></label>
            <input type="number" min="0" step="500" name="<?php echo $this->get_field_name( 'autoplayInterval' ); ?>"  value="<?php echo $instance['autoplayInterval']; ?>" class="widefat" id="<?php echo $this->get_field_id( 'autoplayInterval' ); ?>" />
        </p>

        <!-- Speed -->
        <p>
            <label for="<?php echo $this->get_field_id( 'speed' ); ?>"><?php _e( 'Speed:', 'wp-blog-and-widgets' ); ?></label>
            <input type="number" min="0" step="100" name="<?php echo $this->get_field_name( 'speed' ); ?>"  value="<?php echo $instance['speed']; ?>" class="widefat" id="<?php echo $this->get_field_id( 'speed' ); ?>" />
        </p>      

    <?php }

    /**
    * Outputs the content for the current widget instance.
    *
    * @package WP Blog and Widgets Pro
    * @since 1.0.0
    */
    function widget( $blog_args, $instance ) {

        extract($blog_args, EXTR_SKIP);

        $title              = apply_filters( 'widget_title', isset($instance['title']) ? $instance['title'] : __( 'Latest Blog Slider Widget', 'wp-blog-and-widgets' ), $instance, $this->id_base );
        $num_items          = $instance['num_items'];
        $showDate           = ( isset($instance['date']) && ($instance['date'] == 1) ) 					? true 			: false;
		$showAuthor         = ( isset($instance['author']) && ($instance['author'] == 1) ) 				? true 			: false;
        $show_category      = ( isset($instance['show_category']) && ($instance['show_category'] == 1) ) ? true 		: false;
        $category           = $instance['category'];
        $arrows             = $instance['arrows'];
        $autoplay           = $instance['autoplay'];
        $autoplay_interval  = $instance['autoplayInterval'];
        $speed              = $instance['speed'];
		$link_target        = (isset($instance['link_target']) && $instance['link_target'] == 1) ? '_blank' : '_self';
		$image_fit          = (isset($instance['image_fit']) && ($instance['image_fit'] == 1) ) 		? true 			: false;		
        $media_size         = $instance['media_size'];       
		$image_height 		= (!empty($instance['image_height'])) 										? $instance['image_height'] : '';
		$height_css 		= ($image_height) 															? 'height:'.$image_height.'px;' : '';
		$query_offset       = isset($instance['query_offset'])  ? $instance['query_offset'] : '';
        
        // Slider configuration
        $slider_conf = compact( 'speed', 'autoplay_interval', 'autoplay', 'arrows' );
        
        // Taking some global
        global $post;

        // Taking some default variables
        $postcount      = 0;
        $count          = 0;
        $unique         = wpbaw_pro_get_unique();
        $default_img    = wpbaw_pro_get_option('default_img');
		$image_fit_class	= ($image_fit) 	? 'wpbaw-image-fit' : '';

        // Enqueue required script
        wp_enqueue_script( 'wpos-slick-jquery' );
        wp_enqueue_script( 'wpbaw-pro-public-script' );

        echo $before_widget;

        if ( $title ) {
            echo $before_title . $title . $after_title;
        }
    ?>

    <div class="wpbaw-pro-blog-widget-wrp">
        <div class="wpbaw-pro-blog-slider-widget wpbaw-blog-slider-widget wpbaw-has-slider wpbaw-design-w1 <?php echo $image_fit_class; ?>" id="wpbaw-pro-blog-widget-<?php echo $unique; ?>">
        
        <?php
            // WP Query Parameter
            $blog_args = array( 
                            'suppress_filters'  => true,
                            'posts_per_page'    => $num_items,
                            'post_type'         => WPBAW_PRO_POST_TYPE,
                            'order'             => 'DESC',
							'offset'            => $query_offset,
                        );

            // Category Parameter
            if($category != 0) {
                $blog_args['tax_query'] = array(
                                                array(
                                                        'taxonomy'  => WPBAW_PRO_CAT,
                                                        'field'     => 'term_id',
                                                        'terms'     => $category
                                                    ));
            }

            // WP Query
            $cust_loop  = new WP_Query($blog_args);
            $post_count = $cust_loop->post_count;
            
            if ($cust_loop->have_posts()) : while ($cust_loop->have_posts()) : $cust_loop->the_post();
                    
                    $count++;
                    $postcount++;
                    $blog_links     		 = array();
                    $post_featured_image     = wpbaw_pro_get_post_featured_image( $post->ID, $media_size, true );
                    $post_featured_image     = ( $post_featured_image ) ? $post_featured_image : $default_img;
                    $post_link      		 = wpbaw_pro_get_post_link( $post->ID );
                    $terms         			 = get_the_terms( $post->ID, WPBAW_PRO_CAT );
                    
                    if($terms) {
                        foreach ( $terms as $term ) {
                            $term_link      = get_term_link( $term );
                            $blog_links[]   = '<a href="' . esc_url( $term_link ) . '">'.$term->name.'</a>';
                        }
                    }
                    $cate_name = join( " ", $blog_links );
    ?>
			
			<div class="wpbaw-blog-slides">  
				<div class="wpbaw-blog-grid-content">
				<a class="wpbaw-link-overlay" href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>"></a>
					<div class="wpbaw-blog-overlay">
						<div class="wpbaw-blog-image-bg" style="<?php echo $height_css; ?>">
                            <?php if( !empty($post_featured_image) ) { ?>
                            <img src="<?php echo $post_featured_image; ?>" alt="<?php the_title(); ?>" />
                            <?php } ?>                            
						</div><!-- end .blog-image-bg -->

						<div class="wpbaw-title-content">
							<?php if($show_category && $cate_name !='') { ?>
                            <div class="wpbaw-blog-categories">		
                                <?php echo $cate_name; ?>		
                            </div>
							<?php } ?>
							<h3 class="wpbaw-blog-title">
								<a href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
							</h3>
                            <?php if($showDate || $showAuthor) { ?>
									<div class="wpbaw-blog-date">
										<?php if($showAuthor) { ?> <span><?php  esc_html_e( 'By', 'wp-blog-and-widgets' ); ?> <?php the_author(); ?></span><?php } ?>
										<?php echo ($showAuthor && $showDate) ? '&nbsp;/&nbsp;' : '' ?>
										<?php if($showDate) { echo get_the_date(); } ?>
									</div>
								<?php }	?>
						</div><!-- end .blog-short-content -->

					</div><!-- end .blog-overlay -->
				</div><!-- end .blog-grid-content -->
			</div><!-- end .blog-slides -->
				
            <?php
            endwhile;
            endif;
            
            wp_reset_query();
    ?>
            </div>
            <div class="wpbaw-pro-slider-conf"><?php echo htmlspecialchars(json_encode($slider_conf)); ?></div>
        </div>

<?php
        echo $after_widget;
    }
}
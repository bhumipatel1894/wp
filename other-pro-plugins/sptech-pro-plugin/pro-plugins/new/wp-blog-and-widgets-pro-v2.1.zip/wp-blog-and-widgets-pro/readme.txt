﻿=== WP Blog and Widget Pro  ===
Contributors: wponlinesupport, anoopranawat 
Tags: wordpress blog , wordpress blog widget, Free wordpress blog, blog custom post type, blog tab, blog menu, blog page with custom post type, blog, latest blog, custom post type, cpt, widget
Requires at least: 3.1
Tested up to: 4.8
Author URI: http://wponlinesupport.com
Stable tag: trunk

A quick, easy way to add an Blog custom post type, Blog widget to Wordpress.

== Description ==

Every CMS site needs a Blog section. WP Blog and widgets, manage and display blog, date archives, widget on your website. You can display latest blog post on your homepage/frontpage as well as
in inner page. 

This plugin add a Blog custom post type,  blog widget to your Wordpress site. WP Blog adds a Blog Pro tab to your admin menu, which allows you to enter Blog post just as you would regular posts.


= This wordpress blog plugin contains 6 shorcode =

1) Recent Blog Posts Slider/Carousel
<code>[recent_blog_post_slider]</code>


2) Recent Blog Post with Grid View
<code>[recent_blog_post]</code>


3) Blog Post with Grid View
<code>[blog limit="10"]</code>

4) Blog Post with List View
<code>[baw_blog_list]</code>

5) Blog Post with GridBox  layouts
<code>[wpbaw_gridbox]</code>

6) Blog Post with GridBox  slider
<code>[wpbaw_gridbox_slider]</code>


== Changelog ==

= 2.1 (19, june 2017) =
* [+] Added new shortcode <code>[baw_blog_list]</code> for list  layouts with 8 designs.
* [+] Added new shortcode <code>[wpbaw_gridbox]</code> for GridBox  layouts with 13 designs.
* [+] Added new shortcode <code>[wpbaw_gridbox_slider]</code> for GridBox  slider layouts with 8 designs.
* [+] Added Visual Composer support for 3 new shortcodes.
* [+] Added new shortcode parameters ie image_fit(true OR false) and media_size(thumbnail, medium, large, full)
* [+] Added new 20+ blog designs in existing  Grid shortcode <code>[recent_blog_post]</code>
* [+] Added new 20+ blog designs in existing  Slider shortcode <code>[recent_blog_post_slider]</code>
* [+] Added image fit, image height parameters in shortcodes.
* [+] Added image fit, image height, show author, show content option in widgets 
* [*] Fixed some css issue for widgets.
* [*] Fixed some css issue for Grid Block view.
* [*] Added prefix for the classes to avoide the conflict with other pluigns/themes
* [-] Designs #26, #27 and #36 are depricated from shortcode <code>[blog]</code> and added in new shortcode <code>[baw_blog_list]</code> as a design #5, #6 and #7 respectively.
* [-] Designs #28, #29, #31, #45, #46 and #47 are depricated from shortcode <code>[blog]</code> and added in new shortcode <code>[wpnw_gridbox]</code> as a design #1, #2, #3, #6, #7 and #8 respectively.
* [-] Designs #40, #41 and #42 are depricated from shortcode <code>[recent_blog_post_slider]</code> and   and added in new shortcode <code>[wpbaw_gridbox_slider]</code> as a #1, #2 and #3 respectively.

= 2.0.3 (09, Dec 2017) =
* [+] Added 'Visual Composer' page builder support.
* [+] Added 'query_offset' parameter for shortcodes to exclude some blog post from starting.
* [*] Updated plugin translation code. Now user can put plugin languages file in WordPress 'language' folder so plugin language file will not be loss while plugin update.
* [*] Resolved some CSS issue.

= 2.0.2 (10, Nov 2016) =
* [+] Added 'How it Work' page for better user interface.
* [-] Removed 'Plugin Design' page.
* [*] Updated slider responsive for mobile device.
* [*] Optimized JS.
* [*] Optimized some CSS.

= 2.0.1 (12, Sep 2016) =
* [*] Removed plugin license page from plugin section and added in 'FAQ Pro' menu.
* [*] Updated plugin license page.
* Added SSL to https://www.wponlinesupport.com/ for secure updates.

= 2.0.0 (28, May 2016) =
* [+] Added 'Blog Archive' widget.

= 1.1.9 (26, May 2016) =
* [*] Optimized javascript for better performance.
* [*] Updated slick slider js to latest version.
* [*] Optimized code and improved performance.
* [*] Resolved 'image_height' shortcode parameter issue in designs.
* [*] Optimized some css.
* [+] Added 'RTL' support for slider.
* [+] Added category filter at blog listing page.
* [+] Added numeric pagination in [blog] shortcode.
* [+] Added 'read_more_text' shortcode parameter to change 'Read More' button text.
* [+] Added 'pagination_type' shortcode parameter to switch between numeric and next-prev shortcode.
* [+] Added 'posts' shortcode parameter to display some specific posts only.
* [+] Added 'exclude_post' shortcode parameter to exclude some post.
* [+] Added 'exclude_cat' shortcode parameter to exclude some categoty post.

= 1.1.8 (12, APR 2016) =
* [+] Added 2 more new designs.

= 1.1.7 (12, APR 2016) =
* [+] Added 10 more stunning designs.
* [+] Introduced a long awaited feature 'Grid Slider' with cool designs.
* [+] Added links on images and title in all designs.
* [+] Added 'content_tail' short code parameter for text.
* [+] Added 'link_target' short code parameter for link behavior.
* [+] Added 'order' short code parameter for blog post ordering.
* [+] Added 'orderby' short code parameter for blog post order by.
* [+] Added Drag & Drop feature to display blog post in your desired order.
* [+] Added plugin settings page for custom CSS and default post featured image.
* [+] Added 'publicize' Jetpack support for blog post type.
* [+] Added some filters to change blog post type slug and taxonomy slug.
* [+] Added some useful plugin links for user at plugins page.
* [+] Added German (Switzerland), Spanish (Spain), French (Canada), Italian and Dutch Beta translation.
* [*] Improved 'Blog Categories' widget and added more options in widget.
* [*] Optimized slick slider and blog ticker js enqueue process.
* [*] Improved CSS to display images properly. Optimized CSS.
* [*] Code optimization and improved plugin performance.
* [*] Improved PRO plugin design page.

= 1.1.6 =
* Fixed some slider bugs.

= 1.1.5 =
* Fixed some css issues.
* Resolved multiple slider jquery conflict issue.

= 1.1.4 =
* Fixed some bug
* change blog_post to blog

= 1.1.3 =
* Added Blog category widget
* Fixed some bugs
* Added language for German, French (France)  (Beta)

= 1.1.2 =
* Added 2 New designs (design-37 and design-38)
* Fixed some bugs

= 1.1.1 =
* Fixed some design bug
* Added language for German, French (France)  (Beta)

= 1.1 =
* Fixed some design bug

= 1.0 =
* Initial release


== Upgrade Notice ==

= 2.1 (19, june 2017) =
* [+] Added new shortcode <code>[baw_blog_list]</code> for list  layouts with 8 designs.
* [+] Added new shortcode <code>[wpbaw_gridbox]</code> for GridBox  layouts with 13 designs.
* [+] Added new shortcode <code>[wpbaw_gridbox_slider]</code> for GridBox  slider layouts with 8 designs.
* [+] Added Visual Composer support for 3 new shortcodes.
* [+] Added new shortcode parameters ie image_fit(true OR false) and media_size(thumbnail, medium, large, full)
* [+] Added new 20+ blog designs in existing  Grid shortcode <code>[recent_blog_post]</code>
* [+] Added new 20+ blog designs in existing  Slider shortcode <code>[recent_blog_post_slider]</code>
* [+] Added image fit, image height parameters in shortcodes.
* [+] Added image fit, image height, show author, show content option in widgets 
* [*] Fixed some css issue for widgets.
* [*] Fixed some css issue for Grid Block view.
* [*] Added prefix for the classes to avoide the conflict with other pluigns/themes
* [-] Designs #26, #27 and #36 are depricated from shortcode <code>[blog]</code> and added in new shortcode <code>[baw_blog_list]</code> as a design #5, #6 and #7 respectively.
* [-] Designs #28, #29, #31, #45, #46 and #47 are depricated from shortcode <code>[blog]</code> and added in new shortcode <code>[wpnw_gridbox]</code> as a design #1, #2, #3, #6, #7 and #8 respectively.
* [-] Designs #40, #41 and #42 are depricated from shortcode <code>[recent_blog_post_slider]</code> and   and added in new shortcode <code>[wpbaw_gridbox_slider]</code> as a #1, #2 and #3 respectively.


= 2.0.3 (09, Dec 2017) =
* [+] Added 'Visual Composer' page builder support.
* [+] Added 'query_offset' parameter for shortcodes to exclude some blog post from starting.
* [*] Updated plugin translation code. Now user can put plugin languages file in WordPress 'language' folder so plugin language file will not be loss while plugin update.
* [*] Resolved some CSS issue.

= 2.0.2 (10, Nov 2016) =
* [+] Added 'How it Work' page for better user interface.
* [-] Removed 'Plugin Design' page.
* [*] Updated slider responsive for mobile device.
* [*] Optimized JS.
* [*] Optimized some CSS.

= 2.0.1 (12, Sep 2016) =
* [*] Removed plugin license page from plugin section and added in 'FAQ Pro' menu.
* [*] Updated plugin license page.
* Added SSL to https://www.wponlinesupport.com/ for secure updates.

= 2.0.0 (28, May 2016) =
* [+] Added 'Blog Archive' widget.

= 1.1.9 (26, May 2016) =
* [*] Optimized javascript for better performance.
* [*] Updated slick slider js to latest version.
* [*] Optimized code and improved performance.
* [*] Resolved 'image_height' shortcode parameter issue in designs.
* [*] Optimized some css.
* [+] Added 'RTL' support for slider. 
* [+] Added category filter at blog listing page.
* [+] Added numeric pagination in [blog] shortcode.
* [+] Added 'read_more_text' shortcode parameter to change 'Read More' button text.
* [+] Added 'pagination_type' shortcode parameter to switch between numeric and next-prev shortcode.
* [+] Added 'posts' shortcode parameter to display some specific posts only.
* [+] Added 'exclude_post' shortcode parameter to exclude some post.
* [+] Added 'exclude_cat' shortcode parameter to exclude some categoty post.

= 1.1.8 (12, APR 2016) =
* [+] Added 2 more new designs.

= 1.1.7 (12, APR 2016) =
* [+] Added 10 more stunning designs.
* [+] Introduced a long awaited feature 'Grid Slider' with cool designs.
* [+] Added links on images and title in all designs.
* [+] Added 'content_tail' short code parameter for text.
* [+] Added 'link_target' short code parameter for link behavior.
* [+] Added 'order' short code parameter for blog post ordering.
* [+] Added 'orderby' short code parameter for blog post order by.
* [+] Added Drag & Drop feature to display blog post in your desired order.
* [+] Added plugin settings page for custom CSS and default post featured image.
* [+] Added 'publicize' Jetpack support for blog post type.
* [+] Added some filters to change blog post type slug and taxonomy slug.
* [+] Added some useful plugin links for user at plugins page.
* [+] Added German (Switzerland), Spanish (Spain), French (Canada), Italian and Dutch Beta translation.
* [*] Improved 'Blog Categories' widget and added more options in widget.
* [*] Optimized slick slider and blog ticker js enqueue process.
* [*] Improved CSS to display images properly. Optimized CSS.
* [*] Code optimization and improved plugin performance.
* [*] Improved PRO plugin design page.

= 1.1.6 =
* Fixed some slider bugs.

= 1.1.5 =
* Fixed some css issues.
* Resolved multiple slider jquery conflict issue.

= 1.1.4 =
* Fixed some bug
* change blog_post to blog

= 1.1.3 =
* Added Blog category widget
* Fixed some bugs
* Added language for German, French (France)  (Beta)

= 1.1.2 =
* Added 2 New designs (design-37 and design-38)
* Fixed some bugs

= 1.1.1 =
* Fixed some design bug
* Added language for German, French (France)  (Beta)

= 1.1 =
* Fixed some design bug

= 1.0 =
* Initial release.
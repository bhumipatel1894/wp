<?php 
$css_class = ( $newscount % 2  == 1 ) ? ' wpbaw-first' : '';
if($newscount == "0") {
$wpnw_post_large_image 	= wpbaw_pro_get_post_featured_image( $post->ID, 'large', true ); // Post large image	?>

	<div class="wpbaw-medium-12 wpbaw-columns">
		<div class="wpbaw-blog-image-bg" style="<?php echo $height_css; ?>">
			<?php if( !empty($wpnw_post_large_image) ) { ?>
				<img src="<?php echo $wpnw_post_large_image; ?>" alt="<?php _e('Post Image', 'sp-blog-and-widget'); ?>" />
			<?php } ?>

			<div class="wpbaw-blog-fetured-content">
				<div class="wpbaw-blog-inner-content">

					<?php if($showCategory && $cate_name !='') { ?>
					<div class="wpbaw-blog-categories">	
						<?php echo $cate_name; ?>
					</div>
					<?php } ?>

					<h2 class="wpbaw-blog-title">
						<a href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>"><?php the_title(); ?></a>
					</h2>

					<?php if($showDate || $showAuthor) { ?>
						<div class="wpbaw-blog-date">
							<?php if($showAuthor) { ?> <span><?php  esc_html_e( 'By', 'wp-blog-and-widgets' ); ?> <?php the_author(); ?></span><?php } ?>
							<?php echo ($showAuthor && $showDate) ? '&nbsp;/&nbsp;' : '' ?>
							<?php if($showDate) { echo get_the_date(); } ?>
						</div>
					<?php }	 					
					if($showContent) { ?>
						<div class="wpbaw-blog-content">							
								<div class="wpbaw-blog-short-content"><?php echo wpbaw_pro_get_post_excerpt( $post->ID, get_the_content(), $words_limit, $content_tail ); ?></div>					
								<?php if($showreadmore) { ?>
									<a class="readmorebtn" href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>"><?php esc_html_e($read_more_text); ?></a>
								<?php }	?>
						</div>
					<?php } ?>	
				</div>
			</div>
		</div>
	</div>
	
<?php } else {
	$wpnw_post_medium_image = wpbaw_pro_get_post_featured_image( $post->ID, 'large', true ); // Post large image?>
	
	<div class="wpbaw-medium-12 wpbaw-columns">
		<div class="wpbaw-blog-right-block wpbaw-medium-12 wpbaw-columns">
			<?php if(!empty($wpnw_post_medium_image)) { ?>
				<div class="wpbaw-s-medium-4 wpbaw-columns">
					<div class="wpbaw-blog-image-bg">					
						<img src="<?php echo $wpnw_post_medium_image; ?>" alt="<?php _e('Post Image', 'sp-blog-and-widget'); ?>" />
						
					</div>
				</div>
			<?php } ?>

			<div class="<?php if(!empty($wpnw_post_medium_image)) { echo 'wpbaw-s-medium-8 wpbaw-columns'; } else { echo 'wpbaw-s-medium-12 wpbaw-columns'; } ?> ">
				<?php if($showCategory && $cate_name !='') { ?>
				<div class="wpbaw-blog-categories">
					<?php echo $cate_name; ?>
				</div>
				<?php } ?>

				<h2 class="wpbaw-blog-title">
					<a href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>"><?php the_title(); ?></a>
				</h2>

				<?php if($showDate || $showAuthor) { ?>
						<div class="wpbaw-blog-date">
							<?php if($showAuthor) { ?> <span><?php  esc_html_e( 'By', 'wp-blog-and-widgets' ); ?> <?php the_author(); ?></span><?php } ?>
							<?php echo ($showAuthor && $showDate) ? '&nbsp;/&nbsp;' : '' ?>
							<?php if($showDate) { echo get_the_date(); } ?>
						</div>
					<?php }	 					
					if($showContent) { ?>
						<div class="wpbaw-blog-content">							
								<div class="wpbaw-blog-short-content"><?php echo wpbaw_pro_get_post_excerpt( $post->ID, get_the_content(), $words_limit, $content_tail ); ?></div>					
								<?php if($showreadmore) { ?>
									<a class="readmorebtn" href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>"><?php esc_html_e($read_more_text); ?></a>
								<?php }	?>
						</div>
					<?php } ?>	
			</div>
		</div>
	</div>

<?php } ?>
<?php 
$image_height 		= (!empty($image_height)) ? $image_height : '500';
$dynamic_height = ($grid_count == 1) ? $image_height : (($image_height/2)-2);
$height_css = ($dynamic_height) ? 'height:'.$dynamic_height.'px;' : '';
?>

	<div class="wpbaw-blog-grid-box wpbaw-clr-<?php echo $grid_count; ?> wpbaw-medium-4 wpbaw-columns">
	<a class="wpbaw-link-overlay" href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>"></a>
		<div class="wpbaw-blog-grid-content">
			<div class="wpbaw-blog-overlay">
				<div class="wpbaw-blog-image-bg" style="<?php echo $height_css; ?>">
					<?php if( !empty($post_featured_image) ) { ?>
					<img src="<?php echo $post_featured_image; ?>" alt="<?php the_title(); ?>" />
					<?php } ?>
				</div>
				<div class="wpbaw-title-content">
				<?php if($showCategory && $cate_name !='') { ?>
					<div class="wpbaw-blog-categories">	
						<?php echo $cate_name; ?>
					</div>
					<?php } ?>
					<div class="wpbaw-bottom-content">
					 <h2 class="wpbaw-blog-title">
						<a href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>"><?php the_title(); ?></a>
					</h2>
					<?php if($showDate || $showAuthor) { ?>
						<div class="wpbaw-blog-date">
							<?php if($showAuthor) { ?> <span><?php  esc_html_e( 'By', 'wp-blog-and-widgets' ); ?> <?php the_author(); ?></span><?php } ?>
							<?php echo ($showAuthor && $showDate) ? '&nbsp;/&nbsp;' : '' ?>
							<?php if($showDate) { echo get_the_date(); } ?>
						</div>
					<?php }	 					
					if($showContent) { ?>
						<div class="wpbaw-blog-content">							
								<div class="wpbaw-blog-short-content"><?php echo wpbaw_pro_get_post_excerpt( $post->ID, get_the_content(), $words_limit, $content_tail ); ?></div>					
								<?php if($showreadmore) { ?>
									<a class="readmorebtn" href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>"><?php esc_html_e($read_more_text); ?></a>
								<?php }	?>
						</div>
					<?php } ?>	
					</div>
				</div>
			</div>
		</div>
	</div>

<?php
	if( $grid_count == 5 || ( $post_count == $count ) ) {
		$grid_count = 0;
}?>
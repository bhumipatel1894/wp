<?php if(0 == $newscount % 2 ) { ?>
	<div class="wpbaw-blog-list wpbaw-clearfix">
		<div class="wpbaw-blog-list-content">

			<?php if( !empty($post_featured_image) ) { ?>
			<div class="wpbaw-medium-6 wpbaw-columns">
				<div class="wpbaw-blog-image-bg" style="<?php echo $height_css; ?>">					
					<a href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>">
						<img src="<?php echo $post_featured_image; ?>" alt="<?php _e('Post Image', 'sp-blog-and-widget'); ?>" />
					</a>					
				</div>
			</div>
			<?php } ?>
	
			<div class="<?php if ( !has_post_thumbnail() ) { echo 'wpbaw-medium-12 wpbaw-columns wpbaw-content-border'; } else { echo 'wpbaw-medium-6 wpbaw-columns wpbaw-content-border'; } ?>">
				<div class="wpbaw-title-overlay-border">
					<?php if($showCategory && $cate_name !='') { ?>
					<div class="wpbaw-blog-categories">	
					<?php echo $cate_name; ?>
					</div>
					<?php } ?>

					<h2 class="wpbaw-blog-title">
						<a href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>"><?php the_title(); ?></a>
					</h2>

					<?php if($showDate || $showAuthor) { ?>
						<div class="wpbaw-blog-date">
								<?php if($showAuthor) { ?> <span><?php  esc_html_e( 'By', 'wp-blog-and-widgets' ); ?> <?php the_author(); ?></span><?php } ?>
								<?php echo ($showAuthor && $showDate) ? '&nbsp;/&nbsp;' : '' ?>
								<?php if($showDate) { echo get_the_date(); } ?>
							</div>
				<?php }	 ?>
				</div>
				<?php if($showContent) { ?>
					<div class="wpbaw-blog-content">
						<?php if(!$showFullContent) { ?>
							<div class="wpbaw-blog-short-content"><?php echo wpbaw_pro_get_post_excerpt( $post->ID, get_the_content(), $words_limit, $content_tail ); ?></div>					
							<?php if($showreadmore) { ?>
								<a class="readmorebtn" href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>"><?php esc_html_e($read_more_text); ?></a>
							<?php }				
						} else {
							the_content();
						} ?>
					</div>
				<?php } ?>
			</div>
		</div>
	</div>
	
<?php } else { ?>

	<div class="wpbaw-blog-list wpbaw-clearfix">
		<div class="wpbaw-blog-list-content">
		
			<div class="<?php if ( !has_post_thumbnail() ) { echo 'wpbaw-medium-12 wpbaw-columns wpbaw-content-border'; } else { echo 'wpbaw-medium-6 wpbaw-columns wpbaw-content-border'; } ?>">
				<div class="wpbaw-title-overlay-border">			
								<?php if($showCategory && $cate_name !='') { ?>
								<div class="wpbaw-blog-categories">	
									<?php echo $cate_name; ?>
								</div>
								<?php } ?>

								<h2 class="wpbaw-blog-title">
									<a href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>"><?php the_title(); ?></a>
								</h2>
								<?php if($showDate || $showAuthor) { ?>
									<div class="wpbaw-blog-date">
											<?php if($showAuthor) { ?> <span><?php  esc_html_e( 'By', 'wp-blog-and-widgets' ); ?> <?php the_author(); ?></span><?php } ?>
											<?php echo ($showAuthor && $showDate) ? '&nbsp;/&nbsp;' : '' ?>
											<?php if($showDate) { echo get_the_date(); } ?>
										</div>
							<?php }	 ?>
				</div>
				<?php if($showContent) { ?>
					<div class="wpbaw-blog-content">
						<?php if(!$showFullContent) { ?>
							<div class="wpbaw-blog-short-content"><?php echo wpbaw_pro_get_post_excerpt( $post->ID, get_the_content(), $words_limit, $content_tail ); ?></div>					
							<?php if($showreadmore) { ?>
								<a class="readmorebtn" href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>"><?php esc_html_e($read_more_text); ?></a>
							<?php }				
						} else {
							the_content();
						} ?>
					</div>
				<?php } ?>
			</div>
			<?php if( !empty($post_featured_image) ) { ?>
			<div class="wpbaw-medium-6 wpbaw-columns">
				<div class="wpbaw-blog-image-bg">					
					<a href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>">
						<img src="<?php echo $post_featured_image; ?>" alt="<?php _e('Post Image', 'sp-blog-and-widget'); ?>" />
					</a>					
				</div>
			</div>
			<?php } ?>

		</div>
	</div>
	
<?php } ?>
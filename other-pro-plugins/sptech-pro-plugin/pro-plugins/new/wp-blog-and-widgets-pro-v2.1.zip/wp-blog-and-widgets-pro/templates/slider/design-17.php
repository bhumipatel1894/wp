<div class="wpbaw-blog-slides">		
	<div class="wpbaw-blog-grid-content <?php if ( !has_post_thumbnail() ) { echo 'no-thumb-image'; } ?>">
		<?php		
		if ( has_post_thumbnail() ) { ?>
		<div class="wpbaw-blog-image-bg" style="<?php echo $height_css; ?>">
			<a href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>">
				<img src="<?php echo $post_featured_image; ?>" alt="<?php _e('Post Image', 'sp-blog-and-widget'); ?>" />
			</a>
		</div>
		<?php } ?>	
		<div class="wpbaw-content-above-image">	
			<h2 class="wpbaw-blog-title">
				<a href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>"><?php the_title(); ?></a>
			</h2>
			<?php if($showCategory && $cate_name !='') { ?>
			<div class="wpbaw-blog-categories">
				<?php echo $cate_name; ?>
			</div>
			<?php }
			if($showDate || $showAuthor) { ?>
						<div class="wpbaw-blog-date">
							<?php if($showAuthor) { ?> <span><?php  esc_html_e( 'By', 'wp-blog-and-widgets' ); ?> <?php the_author(); ?></span><?php } ?>
							<?php echo ($showAuthor && $showDate) ? '&nbsp;/&nbsp;' : '' ?>
							<?php if($showDate) { echo get_the_date(); } ?>
						</div>
					<?php }	 					
					if($showContent) { ?>
						<div class="wpbaw-blog-content">							
								<div class="wpbaw-blog-short-content"><?php echo wpbaw_pro_get_post_excerpt( $post->ID, get_the_content(), $words_limit, $content_tail ); ?></div>					
								<?php if($showreadmore) { ?>
									<a class="readmorebtn" href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>"><?php esc_html_e($read_more_text); ?></a>
								<?php }	?>
						</div>
					<?php } ?>
		</div>
	</div>
</div>
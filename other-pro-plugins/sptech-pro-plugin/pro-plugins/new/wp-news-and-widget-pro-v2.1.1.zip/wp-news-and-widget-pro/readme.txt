=== WP News and Scrolling Widgets Pro  ===
Contributors: wponlinesupport 
Tags: wordpress news plugin, main news page scrolling , wordpress vertical news plugin widget, wordpress horizontal news plugin widget , Free scrolling news wordpress plugin, Free scrolling news widget wordpress plugin, WordPress set post or page as news, WordPress dynamic news, news, latest news, custom post type, cpt, widget, vertical news scrolling widget, news widget
Requires at least: 3.1
Tested up to: 4.8
Author URI: http://wponlinesupport.com

A quick, easy way to add an News custom post type, News widget to WordPress website.

== Description ==

Every CMS site needs a news section. WP News and widget pro  allows you add, manage and display news, date archives, widget on your website.

6 types of different shortcodes and 7 types of different widgets
<code>[sp_news],  [sp_news_slider], [wpnw_news_list], [wpnw_gridbox], [wpnw_gridbox_slider] and [wpnw_news_ticker]</code>

* <code>[sp_news]</code> - News Shortcode
* <code>[sp_news_slider]</code> - News Slider Shortcode
* <code>[wpnw_gridbox]</code> - News Gridbox Shortcode
* <code>[wpnw_gridbox_slider]</code> - News Gridbox Slider Shortcode
* <code>[wpnw_news_ticker]</code> - News Ticker Shortcode


== Installation ==

1. Upload the 'wp-news-and-widget-pro' folder to the '/wp-content/plugins/' directory.
2. Activate the WP News and widget pro plugin through the 'Plugins' menu in WordPress.
3. Add and manage news items on your site by clicking on the  'News' tab that appears in your admin menu.
4. Create a page with the any name and paste your desired short code in that.


== Changelog ==

= 2.1.1 (18, July 2017) =
* [*] Fixed Grid shortcode all issue regarding designs.
* [*] Fixed News slider issue ie showing 10px space left and right and issues regarding designs.
* [*] Fixed News Slider widget issue (Link on image)

= 2.1 (19, June 2017) =
* [+] Added new shortcode <code>[wpnw_news_list]</code> for list news layouts with 8 designs.
* [+] Added new shortcode <code>[wpnw_gridbox]</code> for GridBox news layouts with 13 designs.
* [+] Added new shortcode <code>[wpnw_gridbox_slider]</code> for GridBox news slider layouts with 8 designs.
* [+] Added Visual Composer for 3 new shortcodes.
* [+] Added new shortcode parameters ie image_fit(true OR false) and media_size(thumbnail, medium, large, full)
* [+] Added new 20+ news designs in existing News Grid shortcode <code>[sp_news]</code>
* [+] Added new 20+ news designs in existing News Slider shortcode <code>[sp_news_slider]</code>
* [+] Added Image Fit, Media Size and Image height options in widgets.
* [+] Added 'Russian translation' (Beta) - Thanks to @Zo5m
* [*] Fixed some css issue for widgets.
* [*] Fixed some css issue for Grid Block view.
* [*] Added prefix for the classes to avoide the conflict with other pluigns/themes
* [-] Designs #26, #27 and #36 are depricated from shortcode <code>[sp_news]</code> and added in new shortcode <code>[wpnw_news_list]</code> as a design #5, #6 and #7 respectively.
* [-] Designs #28, #29, #31, #45, #46 and #47 are depricated from shortcode <code>[sp_news]</code> and added in new shortcode <code>[wpnw_gridbox]</code> as a design #1, #2, #3, #6, #7 and #8 respectively.
* [-] Designs #40, #41 and #42 are depricated from shortcode <code>[sp_news_slider]</code> and   and added in new shortcode <code>[wpnw_gridbox_slider]</code> as a #1, #2 and #3 respectively.

= 2.0.6 (06, Jan 2016) =
* [+] Added 'Visual Composer' page builder support.
* [*] Updated plugin translation code. Now user can put plugin languages file in WordPress 'language' folder so plugin language file will not be loss while plugin update.

= 2.0.5 (09, Dec 2016) =
* [*] Resolved conflict when 'WP News and Widget - Masonry Layout' is activated.

= 2.0.4 (10, Nov 2016) =
* [+] Added 'How it Work' page for better user interface.
* [-] Removed 'Plugin Design' page.
* [*] Optimized some CSS.

= 2.0.3 (08, Oct 2016) =
* [*] Updated news ticker js for better performance.
* [*] Updated post featured image title.
* [*] Resolved some CSS issue for Widget.

= 2.0.2 (04, Oct 2016) =
* [+] Added news ticker functionality.
* [*] Resolved slider responsive issue on iphone mobile device.
* [*] Resolved widget over lapping issue.

= 2.0.1 (12, Sep 2016) =
* [*] Updated plugin license page.
* Added SSL to https://www.wponlinesupport.com/ for secure updates.

= 2.0 (07, Sep 2016) =
* [+] Added multiple category support. Now you can pass multiple categories by comma seperated to shortcode.

= 1.1.9 (11, Aug 2016) =
* [*] Resolved slider responsive issue.

= 1.1.8 (06, Aug 2016) =
* [+] Added 'query_offset' shortcode parameter.
* [+] Added 'News Archieve' widget.
* [*] Optimized widget code and improved performance.
* [*] Optimized some CSS.

= 1.1.7 (21, July 2016) =
* [+] Added category filter at news listing page.
* [*] Updated slider js to latest version.
* [*] Resolved 'image_height' shortcode parameter issue.
* [*] Resolved WPML category post fetch issue with multilanguage.
* [*] Optimized some CSS.

= 1.1.6 (22, APR 2016) =
* [+] Added 10 more stunning designs.
* [+] Introduced a long awaited feature 'Grid Slider' with cool designs.
* [+] Added links on images and title in all designs.
* [+] Added 'link_target' short code parameter for link behavior.
* [+] Added 'order' short code parameter for news post ordering.
* [+] Added 'orderby' short code parameter for news post order by.
* [+] Added 'exclude_post' short code parameter to exclude some news post.
* [+] Added 'posts' short code parameter to display only some specific news post.
* [+] Added 'image_height' short code parameter to control News post image height.
* [+] Added Drag & Drop feature to display news post in your desired order.
* [+] Added default post featured image settings.
* [+] Added 'publicize' Jetpack support for news post type.
* [+] Added some useful plugin links for user at plugins page.
* [+] Added 'News Categories' widget.
* [*] Optimized slick slider and news ticker js enqueue process.
* [*] Resolved slick slider intialize issue.
* [*] Improved CSS to display images properly. Optimized CSS.
* [*] Code optimization and improved plugin performance.
* [*] Improved PRO plugin design page.
* [*] Improved plugin license page with instruction.

= 1.1.5 =
* Added anchor links on images.
* Added 'content_tail' parameter in shortcode.
* Added custom CSS setting.
* Added user useful links in plugin.
* Added filter to change the plugin post type name and slug.
* Improved plugin functionality.

= 1.1.4 =
* Fixed some bugs.
* Added Turkish(tr_TR) languages (Beta).

= 1.1.3 =
* Fixed some css issues.
* Resolved multiple slider jquery conflict issue.

= 1.1.2 =
* Added translation in German, French (France), Polish languages (Beta)
* Fixed some bug
* Added 2 new design for pro version

= 1.1.1 =
* fixed some bugs.

= 1.1 =
* Added 3 more design and fixed some bugs.

= 1.0 =
* Initial release.


== Upgrade Notice ==

= 2.1.1 (18, July 2017) =
* [*] Fixed Grid shortcode all issue regarding designs.
* [*] Fixed News slider issue ie showing 10px space left and right and issues regarding designs.
* [*] Fixed News Slider widget issue (Link on image)

= 2.1 (19, June 2017) =
* [+] Added new shortcode <code>[wpnw_news_list]</code> for list news layouts with 8 designs.
* [+] Added new shortcode <code>[wpnw_gridbox]</code> for GridBox news layouts with 13 designs.
* [+] Added new shortcode <code>[wpnw_gridbox_slider]</code> for GridBox news slider layouts with 8 designs.
* [+] Added Visual Composer for 3 new shortcodes.
* [+] Added new shortcode parameters ie image_fit(true OR false) and media_size(thumbnail, medium, large, full)
* [+] Added new 20+ news designs in existing News Grid shortcode <code>[sp_news]</code>
* [+] Added new 20+ news designs in existing News Slider shortcode <code>[sp_news_slider]</code>
* [+] Added Image Fit, Media Size and Image height options in widgets.
* [+] Added 'Russian translation' (Beta) - Thanks to @Zo5m
* [*] Fixed some css issue for widgets.
* [*] Fixed some css issue for Grid Block view.
* [*] Added prefix for the classes to avoide the conflict with other pluigns/themes
* [-] Designs #26, #27 and #36 are depricated from shortcode <code>[sp_news]</code> and added in new shortcode <code>[wpnw_news_list]</code> as a design #5, #6 and #7 respectively.
* [-] Designs #28, #29, #31, #45, #46 and #47 are depricated from shortcode <code>[sp_news]</code> and added in new shortcode <code>[wpnw_gridbox]</code> as a design #1, #2, #3, #6, #7 and #8 respectively.
* [-] Designs #40, #41 and #42 are depricated from shortcode <code>[sp_news_slider]</code> and   and added in new shortcode <code>[wpnw_gridbox_slider]</code> as a #1, #2 and #3 respectively.

= 2.0.6 (06, Jan 2017) =
* [+] Added 'Visual Composer' page builder support.
* [*] Updated plugin translation code. Now user can put plugin languages file in WordPress 'language' folder so plugin language file will not be loss while plugin update.

= 2.0.5 (09, Dec 2016) =
* [*] Resolved conflict when 'WP News and Widget - Masonry Layout' is activated.

= 2.0.4 (10, Nov 2016) =
* [+] Added 'How it Work' page for better user interface.
* [-] Removed 'Plugin Design' page.
* [*] Optimized some CSS.

= 2.0.3 (08, Oct 2016) =
* [*] Updated news ticker js for better performance.
* [*] Updated post featured image title.
* [*] Resolved some CSS issue for Widget.

= 2.0.2 (04, Oct 2016) =
* [+] Added news ticker functionality.
* [*] Resolved slider responsive issue on iphone mobile device.
* [*] Resolved widget over lapping issue.

= 2.0.1 (12, Sep 2016) =
* [*] Updated plugin license page.
* Added SSL to https://www.wponlinesupport.com/ for secure updates.

= 2.0 (07, Sep 2016) =
* [+] Added multiple category support. Now you can pass multiple categories by comma seperated to shortcode.

= 1.1.9 (11, Aug 2016) =
* [*] Resolved slider responsive issue.

= 1.1.8 (06, Aug 2016) =
* [+] Added 'query_offset' shortcode parameter.
* [+] Added 'News Archieve' widget.
* [*] Optimized widget code and improved performance.
* [*] Optimized some CSS.

= 1.1.7 (21, July 2016) =
* [+] Added category filter at news listing page.
* [*] Updated slider js to latest version.
* [*] Resolved 'image_height' shortcode parameter issue.
* [*] Resolved WPML category post fetch issue with multilanguage.
* [*] Optimized some CSS.

= 1.1.6 (22, APR 2016) =
* [+] Added 10 more stunning designs.
* [+] Introduced a long awaited feature 'Grid Slider' with cool designs.
* [+] Added links on images and title in all designs.
* [+] Added 'link_target' short code parameter for link behavior.
* [+] Added 'order' short code parameter for news post ordering.
* [+] Added 'orderby' short code parameter for news post order by.
* [+] Added 'exclude_post' short code parameter to exclude some news post.
* [+] Added 'posts' short code parameter to display only some specific news post.
* [+] Added 'image_height' short code parameter to control News post image height.
* [+] Added Drag & Drop feature to display news post in your desired order.
* [+] Added default post featured image settings.
* [+] Added 'publicize' Jetpack support for news post type.
* [+] Added some useful plugin links for user at plugins page.
* [+] Added 'News Categories' widget.
* [*] Optimized slick slider and news ticker js enqueue process.
* [*] Resolved slick slider intialize issue.
* [*] Improved CSS to display images properly. Optimized CSS.
* [*] Code optimization and improved plugin performance.
* [*] Improved PRO plugin design page.
* [*] Improved plugin license page with instruction.

= 1.1.5 =
* Added anchor links on images.
* Added 'content_tail' parameter in shortcode.
* Added custom CSS setting.
* Added user useful links in plugin.
* Added Netherlands(nl_NL) languages (Beta).
* Added filter to change the plugin post type labels and slug.
* Improved plugin functionality.

= 1.1.4 =
* Fixed some bugs.
* Added Turkish(tr_TR) languages (Beta).

= 1.1.3 =
* Fixed some css issues.
* Resolved multiple slider jquery conflict issue.

= 1.1.2 =
* Added translation in German, French (France), Polish languages (Beta).
* Fixed some bug.
* Added 2 new design for pro version.

= 1.1.1 =
* fixed some bugs.

= 1.1 =
* Added 3 more design and fixed some bugs.

= 1.0 =
* Initial release.
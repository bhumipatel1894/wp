<?php
$image_height 	= (!empty($image_height)) ? $image_height : '500';
$dynamic_height = ($grid_count == 1) 	? $image_height : (($image_height/2)-2);
$height_css = ($dynamic_height) 		? 'height:'.$dynamic_height.'px;' : '';
$dynamic_class = ($grid_count == 1) 	? 'wpnews-medium-8' : 'wpnews-medium-4';

if( $grid_count == 1 ) { ?>
	<div class="wpnaw-grid-slider-wrp">
<?php } ?>

	<div class="wpnaw-news-slides wpnaw-clr-<?php echo $grid_count; ?> <?php echo $dynamic_class; ?> wpnews-columns">
	<a class="wpnaw-link-overlay" href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>"></a>
		<div class="wpnaw-news-grid-content">
			<div class="wpnaw-news-overlay">

				<div class="wpnaw-news-image-bg" style="<?php echo $height_css; ?>">
					<?php if( !empty($post_featured_image) ) { ?>
					<img src="<?php echo $post_featured_image; ?>" alt="<?php the_title(); ?>" />
					<?php } ?>
				</div>

				<div class="wpnaw-title-content">
				<?php if($showCategory == "true" && $cate_name !='') { ?>
					<div class="wpnaw-news-categories">	
						<?php echo $cate_name; ?>
					</div>
					<?php } ?>
					<div class="wpnaw-bottom-content">

					 <h2 class="wpnaw-news-title">
						<a href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>"><?php the_title(); ?></a>
					</h2>

					<?php if($showDate == "true") { ?>
					<div class="wpnaw-news-date">
						<?php if($showDate == "true") { echo get_the_date(); } ?>
					</div>
					<?php } 
					if($showContent == "true") { ?>
						<div class="wpnaw-news-content">				
								<div><?php echo wpnw_get_post_excerpt( $post->ID, get_the_content(), $words_limit, $content_tail ); ?></div>				
								<?php if($showreadmore == 'true') { ?>
								<a href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>" class="readmorebtn"><?php echo esc_html($read_more_text); ?></a>
								<?php } ?>
						</div>
					<?php } ?> 

					</div>
				</div>

			</div>
		</div>
	</div>

<?php
	if( $grid_count == 3 || ( $post_count == $count ) ) {
		$grid_count = 0;
?>
</div>
<?php } ?>
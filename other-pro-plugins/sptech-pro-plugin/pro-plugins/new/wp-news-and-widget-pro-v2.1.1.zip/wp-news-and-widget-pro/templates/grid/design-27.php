<?php if($gridcol == '2') {
	$newsprogrid = "6";
} else if($gridcol == '3') {
	$newsprogrid = "4";
}  else if($gridcol == '4') {
	$newsprogrid = "3";
}  else if($gridcol == '5') {
	$newsprogrid = "c5";	
} else if ($gridcol == '1') {
	$newsprogrid = "12";
} else {
	$newsprogrid = "12";
}
if(0 == $newscount % 2 ) { ?>
	<div class="wpnaw-news-grid  wpnews-medium-<?php echo $newsprogrid; ?> wpnews-columns <?php echo $css_class; ?>">
		<div class="wpnaw-news-grid-content">
		<a class="wpnaw-link-overlay" href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>"></a>			
			<div class="wpnaw-news-image-bg" style="<?php echo $height_css; ?>">
				<?php if( !empty($post_featured_image) ) { ?>
					<img src="<?php echo $post_featured_image; ?>" alt="<?php _e('Post Image', 'sp-news-and-widget'); ?>" />
				<?php } ?>				
			</div>			
					<?php if($showCategory == "true" && $cate_name !='') { ?>
					<div class="wpnaw-news-categories">	
						<?php echo $cate_name; ?>
					</div>
					<?php } ?>
					<div class="wpnaw-title-content">
						<h2 class="wpnaw-news-title">
							<a href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>"><?php the_title(); ?></a>
						</h2>
						<?php if($showDate == "true") { ?>
						<div class="wpnaw-news-date">		
							<?php echo get_the_date(); ?>
						</div>
						<?php }						
						if($showContent == "true") {  ?>	
							<div class="wpnaw-news-content">								
								<div class="wpnaw-news-subshort-content"><?php echo wpnw_get_post_excerpt( $post->ID, get_the_content(), $words_limit, $content_tail ); ?></div>
								<?php if($showreadmore == 'true') { ?>
									<a href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>" class="readmorebtn"><?php echo esc_html($read_more_text); ?></a>
								<?php } ?>
							</div>
				<?php } ?>
			</div>				
		</div>
	</div>
	
 <?php } else {  ?>
	
	<div class="wpnaw-news-grid  wpnews-medium-<?php echo $newsprogrid; ?> wpnews-columns wpnaw-news-smallimage <?php echo $css_class; ?>" style="<?php echo $height_css; ?>">
 		<div class="wpnaw-news-grid-content">
			<?php		
			if ( has_post_thumbnail() ) { ?>
			<div class="wpnaw-news-image-bg">
				<a href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>">
					<img src="<?php echo $post_featured_image; ?>" alt="<?php _e('Post Image', 'sp-news-and-widget'); ?>" />
				</a>				
				<?php if($showCategory == "true" && $cate_name !='') { ?>
					<div class="wpnaw-news-categories">
					<?php echo $cate_name; ?>
					</div>
					<?php } ?>
			</div>
			<?php } ?>			
			<div class="wpnaw-news-title-content">
				<h2 class="wpnaw-news-title">
					<a href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>"><?php the_title(); ?></a>
				</h2>
				<?php if($showDate == "true") { ?>
				<div class="wpnaw-news-date">
					<?php echo get_the_date(); ?>
				</div>
				<?php } 
				if($showContent == "true") {  ?>	
				<div class="wpnaw-news-content">				
					<div class="wpnaw-news-subshort-content"><?php echo wpnw_get_post_excerpt( $post->ID, get_the_content(), $words_limit, $content_tail ); ?></div>
					<?php if($showreadmore == 'true') { ?>
						<a href="<?php echo $post_link; ?>" target="<?php echo $link_target; ?>" class="readmorebtn"><?php echo esc_html($read_more_text); ?></a>
					<?php } ?>
				</div>
				<?php } ?>
			</div>
		</div>
	</div>
	
 <?php } ?>
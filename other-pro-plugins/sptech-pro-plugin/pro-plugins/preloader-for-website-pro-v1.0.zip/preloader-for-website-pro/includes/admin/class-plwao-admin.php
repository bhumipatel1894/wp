<?php
/**
 * Admin Class
 *
 * Handles the Admin side functionality of plugin
 *
 * @package Preloader for Website Pro - WPOS
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Plwao_Pro_Admin {

	function __construct() {

		// Action to register admin menu
		add_action( 'admin_menu', array($this, 'plwao_pro_register_menu') );

		// Action to register plugin settings
		add_action ( 'admin_init', array($this, 'plwao_pro_register_settings') );

		// Filter to add plugin links
		add_filter( 'plugin_row_meta', array( $this, 'plwao_pro_plugin_row_meta' ), 10, 2 );
	}

	/**
	 * Function to register admin menus
	 * 
	 * @package Preloader for Website Pro - WPOS
	 * @since 1.0.0
	 */
	function plwao_pro_register_menu() {
		add_menu_page(__('Preloader Pro - WPOS', 'preloader-for-website'), __('Preloader Pro - WPOS', 'preloader-for-website'), 'manage_options', 'plwao-pro-settings', array($this, 'plwao_pro_main_page'), 'dashicons-image-rotate' );
	}

	/**
	 * Function to handle the setting page html
	 * 
	 * @package Preloader for Website Pro - WPOS
	 * @since 1.0.0
	 */
	function plwao_pro_main_page() {
		include_once( PLWAO_PRO_DIR . '/includes/admin/settings/plwao-settings.php' );
	}

	/**
	 * Function register setings
	 * 
	 * @package Preloader for Website Pro - WPOS
	 * @since 1.0.0
	 */
	function plwao_pro_register_settings() {
		register_setting( 'plwao_pro_plugin_options', 'plwao_pro_options', array($this, 'plwao_pro_validate_options') );
	}

	/**
	 * Validate Settings Options
	 * 
	 * @package Preloader for Website Pro - WPOS
	 * @since 1.0.0
	 */
	function plwao_pro_validate_options( $input ) {

		$input['is_preloader']  		= !empty($input['is_preloader']) 		? 1 													: 0;
		$input['plwao_bgcolor'] 		= isset($input['plwao_bgcolor']) 		? plwao_pro_slashes_deep($input['plwao_bgcolor']) 		: '';
		$input['plwao_spinner'] 		= isset($input['plwao_spinner']) 		? plwao_pro_slashes_deep($input['plwao_spinner'])		: 'spinner-1';
		$input['plwao_spinner_size'] 	= !empty($input['plwao_spinner_size']) 	? plwao_pro_slashes_deep($input['plwao_spinner_size']) 	: 'medium';
		$input['plwao_imagepath'] 		= isset($input['plwao_imagepath']) 		? $input['plwao_imagepath'] 							: '';

		return $input;
	}

	/**
	 * Function to unique number value
	 * 
	 * @package Preloader for Website Pro - WPOS
	 * @since 1.0.0
	 */
	function plwao_pro_plugin_row_meta( $links, $file ) {
		
		if ( $file == PLWAO_PRO_PLUGIN_BASENAME ) {
			
			$row_meta = array(
				'docs'    => '<a href="' . esc_url('https://www.wponlinesupport.com/pro-plugin-document/preloader-website-pro/') . '" title="' . esc_attr( __( 'View Documentation', 'preloader-for-website' ) ) . '" target="_blank">' . __( 'Docs', 'preloader-for-website' ) . '</a>',
				'support' => '<a href="' . esc_url('https://www.wponlinesupport.com/welcome-wp-online-support-forum/') . '" title="' . esc_attr( __( 'Visit Customer Support Forum', 'preloader-for-website' ) ) . '" target="_blank">' . __( 'Support', 'preloader-for-website' ) . '</a>',
			);
			return array_merge( $links, $row_meta );
		}
		return (array) $links;
	}
}

$plwao_pro_admin = new Plwao_Pro_Admin();
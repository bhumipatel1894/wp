<?php
/**
 * Settings Page
 *
 * @package Preloader for Website Pro - WPOS
 * @since 1.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// Taking saved options
$plwao_spinner 		= plwao_pro_get_option('plwao_spinner', 'spinner-1');
$plwao_spinner_size = plwao_pro_get_option('plwao_spinner_size', 'medium');
?>

<div class="wrap plwao-settings">

	<h2><?php _e( 'Preloader for Website Pro - Settings', 'preloader-for-website' ); ?></h2>

	<?php
	// Success message
	if( isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true' ) {
		echo '<div id="message" class="updated notice notice-success is-dismissible">
				<p>'.__("Your changes saved successfully.", "preloader-for-website").'</p>
			  </div>';
	}
	?>

	<form action="options.php" method="POST" id="plwao-settings-form" class="plwao-settings-form">

		<?php
		    settings_fields( 'plwao_pro_plugin_options' );
		?>

		<!-- General Settings Starts -->
		<div id="plwao-general-sett" class="post-box-container plwao-general-sett">
			<div class="metabox-holder">
				<div class="meta-box-sortables ui-sortable">
					<div id="general" class="postbox">

						<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'General Settings', 'preloader-for-website' ); ?></span>
						</h3>
						
						<div class="inside" id="123">
						
							<table class="form-table plwao-general-sett-tbl">
								<tbody>

									<tr>
										<th scope="row">
											<label for="plwao-enable-preloader"><?php _e('Enable Site Preloader', 'preloader-for-website'); ?></label>
										</th>
										<td>
											<input id="plwao-enable-preloader" type="checkbox" name="plwao_pro_options[is_preloader]" value="1" <?php checked(plwao_pro_get_option('is_preloader'),1); ?>/><br/>
											<span class="description"><?php _e('Check this box to enable preloader.','preloader-for-website'); ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label for="plwao-bgcolor"><?php _e('Preloader Area Background Color', 'preloader-for-website'); ?></label>
										</th>
										<td>
											<input id="plwao-bgcolor" class="plwao-color-box" type="text" name="plwao_pro_options[plwao_bgcolor]" value="<?php echo plwao_pro_esc_attr( plwao_pro_get_option('plwao_bgcolor') ); ?>"/><br/>
											<span class="description"><?php _e('Select background color.','preloader-for-website'); ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label for="plwao-spinner"><?php _e('Spinner', 'preloader-for-website'); ?></label>
										</th>
										
										<td>
											<label class="plwao-spinner-class <?php if ( $plwao_spinner == 'spinner-1' ){ echo 'plwao-active'; } ?>" for="plwao-spinner-1">
												<input class="plwao-check" id="plwao-spinner-1" type="radio" name="plwao_pro_options[plwao_spinner]" value="spinner-1" <?php checked( 'spinner-1', $plwao_spinner ); ?>/>
												<img src="<?php echo PLWAO_PRO_URL; ?>assets/images/medium/spinner-1.gif">
											</label>

											<label class="plwao-spinner-class <?php if ( $plwao_spinner == 'spinner-2' ){ echo 'plwao-active'; } ?>" for="plwao-spinner-2">
												<input class="plwao-check" id="plwao-spinner-2" type="radio" name="plwao_pro_options[plwao_spinner]" value="spinner-2" <?php checked( 'spinner-2', $plwao_spinner ); ?>/>
												<img src="<?php echo PLWAO_PRO_URL; ?>assets/images/medium/spinner-2.gif">
											</label>

											<label class="plwao-spinner-class <?php if ( $plwao_spinner == 'spinner-3' ){ echo 'plwao-active'; } ?>" for="plwao-spinner-3">
												<input class="plwao-check" id="plwao-spinner-3" type="radio" name="plwao_pro_options[plwao_spinner]" value="spinner-3" <?php checked( 'spinner-3', $plwao_spinner ); ?>/>
												<img src="<?php echo PLWAO_PRO_URL; ?>assets/images/medium/spinner-3.gif">
											</label>

											<label class="plwao-spinner-class <?php if ( $plwao_spinner == 'spinner-4' ){ echo 'plwao-active'; } ?>" for="plwao-spinner-4">
												<input class="plwao-check" id="plwao-spinner-4" type="radio" name="plwao_pro_options[plwao_spinner]" value="spinner-4" <?php checked( 'spinner-4', $plwao_spinner ); ?>/>
												<img src="<?php echo PLWAO_PRO_URL; ?>assets/images/medium/spinner-4.gif">
											</label>

											<label class="plwao-spinner-class <?php if ( $plwao_spinner == 'spinner-5' ){ echo 'plwao-active'; } ?>" for="plwao-spinner-5">
												<input class="plwao-check" id="plwao-spinner-5" type="radio" name="plwao_pro_options[plwao_spinner]" value="spinner-5" <?php checked( 'spinner-5', $plwao_spinner ); ?>/>
												<img src="<?php echo PLWAO_PRO_URL; ?>assets/images/medium/spinner-5.gif">
											</label>

											<label class="plwao-spinner-class <?php if ( $plwao_spinner == 'spinner-6' ){ echo 'plwao-active'; } ?>" for="plwao-spinner-6">
												<input class="plwao-check" id="plwao-spinner-6" type="radio" name="plwao_pro_options[plwao_spinner]" value="spinner-6" <?php checked( 'spinner-6', $plwao_spinner ); ?>/>
												<img src="<?php echo PLWAO_PRO_URL; ?>assets/images/medium/spinner-6.gif">
											</label>

											<label class="plwao-spinner-class <?php if ( $plwao_spinner == 'spinner-7' ){ echo 'plwao-active'; } ?>" for="plwao-spinner-7">
												<input class="plwao-check" id="plwao-spinner-7" type="radio" name="plwao_pro_options[plwao_spinner]" value="spinner-7" <?php checked( 'spinner-7', $plwao_spinner ); ?>/>
												<img src="<?php echo PLWAO_PRO_URL; ?>assets/images/medium/spinner-7.gif">
											</label>

											<label class="plwao-spinner-class <?php if ( $plwao_spinner == 'spinner-8' ){ echo 'plwao-active'; } ?>" for="plwao-spinner-8">
												<input class="plwao-check" id="plwao-spinner-8" type="radio" name="plwao_pro_options[plwao_spinner]" value="spinner-8" <?php checked( 'spinner-8', $plwao_spinner ); ?>/>
												<img src="<?php echo PLWAO_PRO_URL; ?>assets/images/medium/spinner-8.gif">
											</label>

											<label class="plwao-spinner-class <?php if ( $plwao_spinner == 'spinner-9' ){ echo 'plwao-active'; } ?>" for="plwao-spinner-9">
												<input class="plwao-check" id="plwao-spinner-9" type="radio" name="plwao_pro_options[plwao_spinner]" value="spinner-9" <?php checked( 'spinner-9', $plwao_spinner ); ?>/>
												<img src="<?php echo PLWAO_PRO_URL; ?>assets/images/medium/spinner-9.gif">
											</label>

											<label class="plwao-spinner-class <?php if ( $plwao_spinner == 'spinner-10' ){ echo 'plwao-active'; } ?>" for="plwao-spinner-10">
												<input class="plwao-check" id="plwao-spinner-10" type="radio" name="plwao_pro_options[plwao_spinner]" value="spinner-10" <?php checked( 'spinner-10', $plwao_spinner ); ?>/>
												<img src="<?php echo PLWAO_PRO_URL; ?>assets/images/medium/spinner-10.gif">
											</label>

											<label class="plwao-spinner-class <?php if ( $plwao_spinner == 'spinner-11' ){ echo 'plwao-active'; } ?>" for="plwao-spinner-11">
												<input class="plwao-check" id="plwao-spinner-11" type="radio" name="plwao_pro_options[plwao_spinner]" value="spinner-11" <?php checked( 'spinner-11', $plwao_spinner ); ?>/>
												<img src="<?php echo PLWAO_PRO_URL; ?>assets/images/medium/spinner-11.gif">
											</label>

											<label class="plwao-spinner-class <?php if ( $plwao_spinner == 'spinner-12' ){ echo 'plwao-active'; } ?>" for="plwao-spinner-12">
												<input class="plwao-check" id="plwao-spinner-12" type="radio" name="plwao_pro_options[plwao_spinner]" value="spinner-12" <?php checked( 'spinner-12', $plwao_spinner ); ?>/>
												<img src="<?php echo PLWAO_PRO_URL; ?>assets/images/medium/spinner-12.gif">
											</label>

											<label class="plwao-spinner-class <?php if ( $plwao_spinner == 'spinner-13' ){ echo 'plwao-active'; } ?>" for="plwao-spinner-13">
												<input class="plwao-check" id="plwao-spinner-13" type="radio" name="plwao_pro_options[plwao_spinner]" value="spinner-13" <?php checked( 'spinner-13', $plwao_spinner ); ?>/>
												<img src="<?php echo PLWAO_PRO_URL; ?>assets/images/medium/spinner-13.gif">
											</label>

											<label class="plwao-spinner-class <?php if ( $plwao_spinner == 'spinner-14' ){ echo 'plwao-active'; } ?>" for="plwao-spinner-14">
												<input class="plwao-check" id="plwao-spinner-14" type="radio" name="plwao_pro_options[plwao_spinner]" value="spinner-14" <?php checked( 'spinner-14', $plwao_spinner ); ?>/>
												<img src="<?php echo PLWAO_PRO_URL; ?>assets/images/medium/spinner-14.gif">
											</label>

											<label class="plwao-spinner-class <?php if ( $plwao_spinner == 'spinner-15' ){ echo 'plwao-active'; } ?>" for="plwao-spinner-15">
												<input class="plwao-check" id="plwao-spinner-15" type="radio" name="plwao_pro_options[plwao_spinner]" value="spinner-15" <?php checked( 'spinner-15', $plwao_spinner ); ?>/>
												<img src="<?php echo PLWAO_PRO_URL; ?>assets/images/medium/spinner-15.gif">
											</label>

											<label class="plwao-spinner-class <?php if ( $plwao_spinner == 'spinner-16' ){ echo 'plwao-active'; } ?>" for="plwao-spinner-16">
												<input class="plwao-check" id="plwao-spinner-16" type="radio" name="plwao_pro_options[plwao_spinner]" value="spinner-16" <?php checked( 'spinner-16', $plwao_spinner ); ?>/>
												<img src="<?php echo PLWAO_PRO_URL; ?>assets/images/medium/spinner-16.gif">
											</label>

											<label class="plwao-spinner-class <?php if ( $plwao_spinner == 'spinner-17' ){ echo 'plwao-active'; } ?>" for="plwao-spinner-17">
												<input class="plwao-check" id="plwao-spinner-17" type="radio" name="plwao_pro_options[plwao_spinner]" value="spinner-17" <?php checked( 'spinner-17', $plwao_spinner ); ?>/>
												<img src="<?php echo PLWAO_PRO_URL; ?>assets/images/medium/spinner-17.gif">
											</label>
											<br/>
											<span class="description"><?php _e('Select spinner design.','preloader-for-website'); ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label for="plwao-spinner-size"><?php _e('Spinner Size', 'preloader-for-website'); ?></label>
										</th>
										<td>
											<select id="plwao-spinner-size" name="plwao_pro_options[plwao_spinner_size]">
												<option value="small" <?php selected( $plwao_spinner_size, 'small'); ?>><?php _e('Small - (32 x 32)', 'preloader-for-website'); ?></option>
												<option value="medium" <?php selected( $plwao_spinner_size, 'medium'); ?>><?php _e('Medium - (64 x 64)', 'preloader-for-website'); ?></option>
												<option value="large" <?php selected( $plwao_spinner_size, 'large'); ?>><?php _e('Large - (128 x 128)', 'preloader-for-website'); ?></option>
											</select><br/>
											<span class="description"><?php _e('Select spinner size.','preloader-for-website'); ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label for="plwao-custom-img"><?php _e('Custom Spinner Image', 'preloader-for-website'); ?></label>
										</th>
										<td>
											<input id="plwao-custom-img" type="text" name="plwao_pro_options[plwao_imagepath]" value="<?php echo plwao_pro_esc_attr( plwao_pro_get_option('plwao_imagepath') ); ?>" id="plwao-custom-image" class="regular-text plwao-default-img plwao-img-upload-input" />
											<input type="button" name="plwao_default_img" class="button-secondary plwao-img-uploader" value="<?php _e( 'Upload Image', 'preloader-for-website'); ?>" />
											<input type="button" name="plwao_default_img_clear" id="plwao-default-img-clear" class="button button-secondary plwao-image-clear" value="<?php _e( 'Clear', 'preloader-for-website'); ?>" />
											<?php
												$plwao_imagepath = '';
												if( plwao_pro_get_option('plwao_imagepath') ) { 
													$plwao_imagepath = '<img src="'.plwao_pro_get_option('plwao_imagepath').'" alt="" />';
												}
											?>
											<div class="plwao-imgs-preview"><?php echo $plwao_imagepath; ?></div>
											<span class="description"><?php _e( 'upload custom image which you want to set as a preloader.', 'preloader-for-website' ); ?></span><br/>
											<span class="description"><?php _e( 'Note: If you set custom image as a preloader then spinner image will be ignored.', 'preloader-for-website' ); ?></span>
										</td>
									</tr>

									<tr>
										<td colspan="2" valign="top" scope="row">
											<input type="submit" id="plwao-settings-submit" name="plwao-settings-submit" class="button button-primary right" value="<?php _e('Save Changes','preloader-for-website'); ?>" />
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</form><!-- end .plwao-settings-form -->
</div><!-- end .plwao-settings -->
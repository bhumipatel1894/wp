<?php
/**
 * Public Class
 *
 * Handles the public side functionality of plugin
 *
 * @package Preloader for Website Pro - WPOS
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Plwao_Pro_Public {

	function __construct() {

		// calling loader in footer
		add_action( 'wp_footer', array($this, 'plwao_pro_loader_function') );
	}

	/**
	 * Function to add preloader in footer
	 * 
	 * @package Preloader for Website Pro - WPOS
	 * @since 1.0.0
	 */
	function plwao_pro_loader_function() {

		$is_preloader = plwao_pro_get_option('is_preloader');
		
    	if($is_preloader == 1) {

    		$plwao_bgcolor 		= plwao_pro_get_option('plwao_bgcolor');
    		$plwao_spinner 		= plwao_pro_get_option('plwao_spinner');
			$plwao_spinner_size = plwao_pro_get_option('plwao_spinner_size');
			$plwao_imagepath 	= plwao_pro_get_option('plwao_imagepath');
    ?>
			<style type="text/css">
				.plwao-pro-site-loader{position: fixed;left: 0px;top: 0px;width: 100%;height: 100%;z-index: 9999;}
				<?php if(!empty($plwao_imagepath)) { ?>
					.plwao-pro-site-loader{background: url(<?php echo $plwao_imagepath; ?>) center no-repeat <?php echo $plwao_bgcolor; ?>;}
				<?php } else { ?>
					.plwao-pro-site-loader{background: url(<?php echo PLWAO_PRO_URL ?>assets/images/<?php echo $plwao_spinner_size; ?>/<?php echo $plwao_spinner; ?>.gif) center no-repeat <?php echo $plwao_bgcolor; ?>;}
				<?php } ?>
			</style>
			<div class="plwao-pro-site-loader"></div>

	    	<script type="text/javascript">
           	jQuery(window).load(function() {
				jQuery(".plwao-pro-site-loader").fadeOut('slow'); // Animate loader off screen
			});
	        </script>
	<?php
        }
	}
}

$plwao_pro_public = new Plwao_Pro_Public();
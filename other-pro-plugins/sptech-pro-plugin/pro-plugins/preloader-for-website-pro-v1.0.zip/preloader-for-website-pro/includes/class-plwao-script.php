<?php
/**
 * Script Class
 *
 * Handles the script and style functionality of plugin
 *
 * @package Preloader for Website Pro - WPOS
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class PlwaoPro_Script {

	function __construct() {

		// Action to add style in backend
		add_action( 'admin_enqueue_scripts', array($this, 'plwao_pro_admin_style') );

		// Action to add script at admin side
		add_action( 'admin_enqueue_scripts', array($this, 'plwao_pro_admin_script') );
	}

	/**
	 * Enqueue admin styles
	 * 
	 * @package Preloader for Website Pro - WPOS
	 * @since 1.0.0
	 */
	function plwao_pro_admin_style( $hook ) {
		
		// Pages array
		$pages_array = array( 'toplevel_page_plwao-pro-settings' );

		// If page is plugin setting page then enqueue script
		if( in_array($hook, $pages_array) ) {
			
			// Enqueu built in style for color picker
			wp_enqueue_style( 'wp-color-picker' );

			// Registring admin script
			wp_register_style( 'plwao-pro-admin.css', PLWAO_PRO_URL.'assets/css/plwao-pro-admin.css', null, PLWAO_PRO_VERSION );
			wp_enqueue_style( 'plwao-pro-admin.css' );
		}
	}

	/**
	 * Function to add script at admin side
	 * 
	 * @package Preloader for Website Pro - WPOS
	 * @since 1.0.0
	 */
	function plwao_pro_admin_script( $hook ) {

		global $wp_version, $wp_query, $typenow;
		
		// Pages array
		$pages_array = array( 'toplevel_page_plwao-pro-settings' );
		
		$new_ui = $wp_version >= '3.5' ? '1' : '0'; // Check wordpress version for older scripts
		
		if( in_array($hook, $pages_array) ) {
			
			// Enqueu built-in script for color picker
			wp_enqueue_script( 'wp-color-picker' );

			// Registring admin script
			wp_register_script( 'plwao-pro-admin-script', PLWAO_PRO_URL.'assets/js/plwao-pro-admin.js', array('jquery'), PLWAO_PRO_VERSION, true );
			wp_localize_script( 'plwao-pro-admin-script', 'plwaoProAdmin', array(
																	'new_ui' =>	$new_ui,
																));
			wp_enqueue_script( 'plwao-pro-admin-script' );
			
			wp_enqueue_media(); // For media uploader
		}
	}
}

$plwao_pro_script = new PlwaoPro_Script();
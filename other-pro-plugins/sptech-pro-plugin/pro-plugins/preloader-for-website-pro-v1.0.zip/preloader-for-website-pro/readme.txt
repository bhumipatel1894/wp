=== Preloader for Website Pro - WPOS ===
Contributors: wponlinesupport, anoopranawat 
Tags: page loader, loader, page load animations, animated pre-loader, animated preloader, colorful, customize, Jquery Loader, jquery pre-loader, jquery preloader, load, loader, pre-loader, preload, preloader 
Requires at least: 3.1
Tested up to: 4.7.1
Stable tag: trunk

== Description ==
PageLoader is a tiny, customizable add-on that gives your site an animated loading screen. It also adds a nifty slide-in animation to all your content; as the loading screen fades away, your content slides down in an unobtrusive yet memorable way.

It's a great and lightweight way to add spice to any site. Simply insert some code (clear instructions included) and your site will instantly boast a little extra pizazz! :) Optionally, you can color customize the loading screen as well as the icon, and give them both any color you choose.

And, it works everywhere. It's been tested on desktop browsers along with a variety of iOS, Android and Windows devices.

= Available Features : =
* Animated load screen
* Slides in your content
* Customize
* Light weight


== Installation ==

1. Upload the 'preloader-for-website-pro' folder to the '/wp-content/plugins/' directory.
2. Activate the "Preloader for Website Pro - WPOS" list plugin through the 'Plugins' menu in WordPress.
3. Do plugin settings and done.


== Changelog ==

= 1.0 =
* Initial release.

== Upgrade Notice ==

= 1.0 =
* Initial release.
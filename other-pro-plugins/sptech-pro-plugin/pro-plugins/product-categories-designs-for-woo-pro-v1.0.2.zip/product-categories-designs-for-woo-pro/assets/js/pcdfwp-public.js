jQuery(document).ready(function($){

	$( '.pcdfwp-pdt-cat-slider' ).each(function( index ) {
		
		var slider_id   = $(this).attr('id');
		var slider_conf = $.parseJSON( $(this).closest('.pcdfwp-cat-wrap').find('.pcdfwp-slider-conf').attr('data-conf') );
		
		jQuery('#'+slider_id).slick({
			dots			: (slider_conf.dots) == "true" ? true : false,
			infinite		: (slider_conf.loop) == "true" ? true : false,
			arrows			: (slider_conf.arrows) == "true" ? true : false,
			speed			: parseInt(slider_conf.speed),
			autoplay		: (slider_conf.autoplay) == "true" ? true : false,
			autoplaySpeed	: parseInt(slider_conf.autoplay_interval),
			slidesToShow	: parseInt(slider_conf.slidestoshow),
			slidesToScroll	: parseInt(slider_conf.slidestoscroll),
			mobileFirst     : (Pcdfwp.is_mobile == 1) ? true : false,
			rtl             : (slider_conf.rtl) == "true" ? true : false,
			responsive: [{
				breakpoint: 1023,
				settings: {
					slidesToShow: (parseInt(slider_conf.slidestoshow) > 3) ? 3 : (parseInt(slider_conf.slidestoshow)),
					slidesToScroll: 1,
				}
			},{
				breakpoint: 767,	  			
				settings: {
					slidesToShow: (parseInt(slider_conf.slidestoshow) > 2) ? 2 : (parseInt(slider_conf.slidestoshow)),
					slidesToScroll: 1
				}
			},
			{
				breakpoint: 479,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
					dots: false
				}
			},
			{
				breakpoint: 319,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
					dots: false
				}
			}]
		});
	});

	// For older browser compatibility (Image Fallback)
    if( Pcdfwp.is_old_browser == 1 ) {
        $( '.pcdfwp-image-fit .pcdfwp-pdt-cat-wrap' ).each(function( index ) {
            var img_obj = $(this).find('.pcdfwp-cat-img');

            if( typeof(img_obj) !== 'undefined' ) {
                var img_url = img_obj.attr('src');

                img_obj.closest('.pcdfwp-cat-img-bg').css({"background": "url("+img_url+") no-repeat top center", "background-size": "cover"});
                img_obj.hide();
            }
        });
    }
});
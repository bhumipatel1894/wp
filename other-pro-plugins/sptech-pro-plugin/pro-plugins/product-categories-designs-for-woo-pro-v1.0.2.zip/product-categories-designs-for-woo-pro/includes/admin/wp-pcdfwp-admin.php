<?php
/**
 * Admin Class
 *
 * Handles the Admin side functionality of plugin
 *
 * @package Product Categories Designs for WooCommerce Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Wp_Pcdfwp_Admin {

	function __construct() {

		//Add Prodcut category page
		add_action(PCDFWP_PRODUCT_CAT.'_add_form_fields', array($this, 'pcdfwp_taxonomy_add_new_meta_field'));

		//Edit Prodcut category page
		add_action(PCDFWP_PRODUCT_CAT.'_edit_form_fields',array($this, 'pcdfwp_taxonomy_edit_meta_field'));

		// Save taxonomy fields
		add_action('edited_'.PCDFWP_PRODUCT_CAT, array($this, 'pcdfwp_save_taxonomy_custom_meta'));
		add_action('create_'.PCDFWP_PRODUCT_CAT, array($this, 'pcdfwp_save_taxonomy_custom_meta'));

		// Filter to add plugin links
		add_filter( 'plugin_row_meta', array( $this, 'wp_pap_pro_plugin_row_meta' ), 10, 2 );
	}

	/**
	 * Function to add term field on add screen
	 * 
	 * @package Product Categories Designs for WooCommerce Pro
	 * @since 1.0.1
	 */
	function pcdfwp_taxonomy_add_new_meta_field() {

		$prefix = PCDFWP_PRO_META_PREFIX; // Taking metabox prefix
    ?>
	    <div class="form-field">
	        <label for="pcdfwp-custom-link"><?php _e('Product Category Custom Link', 'product-categories-designs-for-woocommerce'); ?></label>
	        <input type="text" name="<?php echo $prefix;?>custom_link" id="pcdfwp-custom-link" class="pcdfwp-custom-link" />
	        <p class="description"><?php _e('Enter product category custom link. Leave empty for default category link.', 'product-categories-designs-for-woocommerce'); ?></p>
	    </div>
<?php
	}

	/**
	 * Function to add term field on edit screen
	 * 
	 * @package Product Categories Designs for WooCommerce Pro
	 * @since 1.0.1
	 */
	function pcdfwp_taxonomy_edit_meta_field( $term ) {
		
		$prefix = PCDFWP_PRO_META_PREFIX; // Taking metabox prefix
	    
	    //getting term ID
	    $term_id = $term->term_id;

	    // Getting stored values
	    $pcdfwp_custom_link = get_term_meta($term_id, $prefix.'custom_link', true);    
?>
	    <tr class="form-field">
	        <th scope="row" valign="top"><label for="pcdfwp-custom-link"><?php _e('Product Category Custom Link', 'product-categories-designs-for-woocommerce'); ?></label></th>
	        <td>
	            <input type="url" name="<?php echo $prefix;?>custom_link" id="pcdfwp-custom-link" value="<?php echo pcdfwp_esc_attr($pcdfwp_custom_link); ?>" />
	            <p class="description"><?php _e('Enter product category custom link. Leave empty for default category link.', 'product-categories-designs-for-woocommerce'); ?></p>
	        </td>
	    </tr>  
<?php
	}

	/**
	 * Function to add term field on edit screen
	 * 
	 * @package Product Categories Designs for WooCommerce Pro
	 * @since 1.0.1
	 */
	function pcdfwp_save_taxonomy_custom_meta($term_id) {

		$prefix = PCDFWP_PRO_META_PREFIX; // Taking metabox prefix

	    $pcdfwp_custom_link = !empty($_POST[$prefix.'custom_link']) ? pcdfwp_slashes_deep($_POST[$prefix.'custom_link']) : '';

	    update_term_meta($term_id, $prefix.'custom_link', $pcdfwp_custom_link);
	}

	/**
	 * Function to unique number value
	 * 
	 * @package Product Categories Designs for WooCommerce Pro
	 * @since 1.0.0
	 */
	function wp_pap_pro_plugin_row_meta( $links, $file ) {
		
		if ( $file == PCDFWP_PLUGIN_BASENAME ) {
			
			$row_meta = array(
				'docs'    => '<a href="' . esc_url('https://www.wponlinesupport.com/pro-plugin-document/document-product-categories-designs-woo-pro/') . '" title="' . esc_attr( __( 'View Documentation', 'product-categories-designs-for-woocommerce' ) ) . '" target="_blank">' . __( 'Docs', 'product-categories-designs-for-woocommerce' ) . '</a>',
				'support' => '<a href="' . esc_url('https://www.wponlinesupport.com/welcome-wp-online-support-forum/') . '" title="' . esc_attr( __( 'Visit Customer Support Forum', 'product-categories-designs-for-woocommerce' ) ) . '" target="_blank">' . __( 'Support', 'product-categories-designs-for-woocommerce' ) . '</a>',
			);
			return array_merge( $links, $row_meta );
		}
		return (array) $links;
	}
}

$wp_pcdfwp_admin = new Wp_Pcdfwp_Admin();
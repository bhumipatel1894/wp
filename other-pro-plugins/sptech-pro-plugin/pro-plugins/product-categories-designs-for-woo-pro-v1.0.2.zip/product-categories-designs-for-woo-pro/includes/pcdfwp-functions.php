<?php
/**
 * Plugin generic functions file
 *
 * @package Product Categories Designs for WooCommerce Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Escape Tags & Slashes
 *
 * Handles escapping the slashes and tags
 *
 * @package Product Categories Designs for WooCommerce Pro
 * @since 1.0.0
 */
function pcdfwp_esc_attr($data) {
    return esc_attr( stripslashes($data) );
}

/**
 * Strip Slashes From Array
 *
 * @package Product Categories Designs for WooCommerce Pro
 * @since 1.0.1
 */
function pcdfwp_slashes_deep($data = array(), $flag = false) {
    if($flag != true) {
        $data = pcdfwp_nohtml_kses($data);
    }
    $data = stripslashes_deep($data);
    return $data;
}

/**
 * Strip Html Tags 
 * 
 * It will sanitize text input (strip html tags, and escape characters)
 * 
 * @package Product Categories Designs for WooCommerce Pro
 * @since 1.0.1
 */
function pcdfwp_nohtml_kses($data = array()) {

    if ( is_array($data) ) {
        
        $data = array_map('pcdfwp_nohtml_kses', $data);
        
    } elseif ( is_string( $data ) ) {
        $data = trim( $data );
        $data = wp_filter_nohtml_kses($data);
    }

    return $data;
}

/**
 * Function to get post external link or permalink
 * 
 * @package Product Categories Designs for WooCommerce Pro
 * @since 1.0.1
 */
function pcdfwp_get_term_link( $term = '' ) {
    
    $term_link = '';
    
    if( !empty($term) ) {
        
        $prefix = PCDFWP_PRO_META_PREFIX;
        
        $term_link = get_term_meta($term->term_id, $prefix.'custom_link', true);
        
        if( empty($term_link) ) {
            $term_link = get_term_link( $term, PCDFWP_PRODUCT_CAT );
        }
    }
    return $term_link;
}

/**
 * Function to unique number value
 * 
 * @package Product Categories Designs for WooCommerce Pro
 * @since 1.0.0
 */
function pcdfwp_get_unique() {
    static $unique = 0;
    $unique++;

    return $unique;
}

/**
 * Function to get featured content column
 * 
 * @package Product Categories Designs for WooCommerce Pro
 * @since 1.0.0
 */
function pcdfwp_column( $row = '' ) {
	if($row == 2) {
		$per_row = 6;
	} else if($row == 3) {
		$per_row = 4;	
	} else if($row == 4) {
		$per_row = 3;
	} else if($row == 1) {
		$per_row = 12;
	} else{
        $per_row = 4;
    }
    return $per_row;
}

/**
 * Function to get old browser
 * 
 * @package Product Categories Designs for WooCommerce Pro
 * @since 1.0.2
 */
function pcdfwp_old_browser() {
    global $is_IE, $is_safari, $is_edge;

    // Only for safari
    $safari_browser = pcdfwp_check_browser_safari();

    if( $is_IE || $is_edge || ($is_safari && (isset($safari_browser['version']) && $safari_browser['version'] <= 7.1)) ) {
        return true;
    }
    return false;
}

/**
 * Determine if the browser is Safari or not (last updated 1.7)
 * 
 * @package Product Categories Designs for WooCommerce Pro
 * @since 1.0.2
 */
function pcdfwp_check_browser_safari() {

    // Takinf some variables
    $browser    = array();
    $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : "";

    if (stripos($user_agent, 'Safari') !== false && stripos($user_agent, 'iPhone') === false && stripos($user_agent, 'iPod') === false) {
        $aresult = explode('/', stristr($user_agent, 'Version'));
        if (isset($aresult[1])) {
            $aversion = explode(' ', $aresult[1]);
            $browser['version'] = ($aversion[0]);
        } else {
            $browser['version'] = '';
        }
        $browser['browser'] = 'safari';
    }
    return $browser;
}

/**
 * Function to get category shortcode designs
 * 
 * @package Product Categories Designs for WooCommerce Pro
 * @since 1.0.2
 */
function pcdfwp_pdt_cat_designs() {
    $design_arr = array(
                'default-1'  => __('Default Design 1', 'product-categories-designs-for-woocommerce'),
                'default-2'  => __('Default Design 2', 'product-categories-designs-for-woocommerce'),
                'design-1'  => __('Design 1', 'product-categories-designs-for-woocommerce'),
                'design-2'  => __('Design 2', 'product-categories-designs-for-woocommerce'),
                'design-3'  => __('Design 3', 'product-categories-designs-for-woocommerce'),
                'design-4'  => __('Design 4', 'product-categories-designs-for-woocommerce'),
                'design-5'  => __('Design 5', 'product-categories-designs-for-woocommerce'),
                'design-6'  => __('Design 6', 'product-categories-designs-for-woocommerce'),
                'design-7'  => __('Design 7', 'product-categories-designs-for-woocommerce'),
                'design-8'  => __('Design 8', 'product-categories-designs-for-woocommerce'),
                'design-9'  => __('Design 9', 'product-categories-designs-for-woocommerce'),
                'design-10' => __('Design 10', 'product-categories-designs-for-woocommerce'),
            );
    return apply_filters('pcdfwp_pdt_cat_designs', $design_arr );
}
<?php
/**
 * 'wpos_product_categories' Shortcode
 * 
 * @package Product Categories Designs for WooCommerce Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;
	
function pcdfwp_product_categories( $atts, $content ) {

	// Shortcode Parameter
	extract(shortcode_atts(array(
		'limit'     		=> '',
		'orderby'   		=> 'name',
		'order'     		=> 'ASC',
		'design'     		=> 'design-1',
		'columns'    		=> 3,
		'hide_empty' 		=> 'true',
		'parent'     		=> 0,
		'ids'       		=> array(),
		'exclude'			=> array(),
		'offset'			=> '',
		'show_count'		=> 'true',
		'show_desc'			=> 'false',
		'link_target'		=> 'self',
		'image_fit'			=> 'true',
	), $atts));

	$cat_designs 		= pcdfwp_pdt_cat_designs();
	$limit				= !empty($limit) 					? $limit : '';
	$ids				= !empty($ids) 						? explode( ',', $ids ) 		: array();
	$exclude			= !empty($exclude) 					? explode( ',', $exclude ) 	: array();
	$order 				= ( strtolower($order) == 'asc' ) 	? 'ASC' 	: 'DESC';
	$orderby 			= (!empty($orderby))				? $orderby	: 'name';
	$hide_empty 		= ( $hide_empty == 'false') 		? 0 		: 1;
	$parent 			= isset($parent) 					? $parent 	: '';
	$show_count			= ($show_count == 'false') 			? 0 		: 1;
	$show_desc			= ($show_desc == 'true') 			? 1 		: 0;
	$offset 			= !empty($offset) 					? $offset 	: null;
	$design 			= ($design && (array_key_exists(trim($design), $cat_designs))) ? trim($design) : 'design-1';
	$columns 			= (!empty($columns) && $columns <= 4) ? $columns : 3;
	$column_grid 		= pcdfwp_column($columns);
	$link_target 		= ($link_target == 'blank') 		? '_blank' 		: '_self';
	$image_fit			= ($image_fit == 'false')			? 0 : 1;

	// Shortcode file
	$woo_design_file_path 	= PCDFWP_DIR . '/templates/' . $design . '.php';
	$design_file 			= (file_exists($woo_design_file_path)) ? $woo_design_file_path : '';

	// Taking some variables
	$count 			= 0;
	$prefix 		= PCDFWP_PRO_META_PREFIX;
	$old_browser	= pcdfwp_old_browser();

	$main_wrap_cls 	= "pcdfwp-{$design} pcdfwp-col-{$columns}";
	$main_wrap_cls	.= ($image_fit) 	? ' pcdfwp-image-fit' 	: '';
	$main_wrap_cls	.= ($old_browser) 	? ' pcdfwp-old-browser' : '';

	// Enqueue required script
	if( $image_fit && $old_browser ) {
		wp_enqueue_script( 'pcdfwp-public-js' );
	}

	// Terms Parameters
	$cat_args = array(
						'number'		=> $limit,
						'order'     	=> $order,
						'orderby'    	=> $orderby,
						'hide_empty' 	=> $hide_empty,
						'include'    	=> $ids,
						'exclude'		=> $exclude,
						'parent'     	=> $parent,
						'offset'		=> $offset,
						'pad_counts'	=> true
					);

	// Getting product category
	$product_categories = get_terms( PCDFWP_PRODUCT_CAT, $cat_args );

	ob_start();

	if ( !is_wp_error($product_categories) && !empty($product_categories) ) {

		// Element count
		$pdt_cat_count = count( $product_categories );
	?>

		<div class="pcdfwp-cat-wrap pcdfwp-clearfix">
			<div class="pcdfwp-product-cat-grid pcdfwp-product-cat <?php echo $main_wrap_cls; ?>">

				<?php foreach ( $product_categories as $category ) {

					// Wrapper class
					$wrapper_cls = "pcdfwp-pdt-cat-wrap pcdfwp-medium-{$column_grid} pcdfwp-columns";
					$wrapper_cls .= ($count%$columns == 0) ? ' pcdfwp-first' : '';

					$cat_thumb_id 		= get_woocommerce_term_meta( $category->term_id, 'thumbnail_id', true );
					$cat_thumb_url 		= wp_get_attachment_image_src( $cat_thumb_id, 'shop_catalog' );
					$cat_thumb_link 	= !empty($cat_thumb_url[0]) ? $cat_thumb_url[0] : wc_placeholder_img_src();
					$term_link 			= pcdfwp_get_term_link( $category );

					if( $design_file ) {
						include( $woo_design_file_path );
					}

					$count++;
				 } ?>
			</div>
		</div>
	<?php
	} // End of main if

	$content .= ob_get_clean();
	return $content;
}

// 'wpos_product_categories' shortcode
add_shortcode('wpos_product_categories', 'pcdfwp_product_categories');
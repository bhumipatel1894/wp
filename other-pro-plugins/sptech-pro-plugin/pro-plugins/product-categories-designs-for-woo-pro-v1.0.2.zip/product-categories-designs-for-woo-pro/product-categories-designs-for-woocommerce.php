<?php
/**
 * Plugin Name: Product Categories Designs Pro - WooCommerce
 * Plugin URI: https://www.wponlinesupport.com/
 * Description: Display WooCommerce product categories designs with grid and silder view.
 * Author: WP Online Support
 * Text Domain: product-categories-designs-for-woocommerce
 * Domain Path: /languages/
 * Version: 1.0.2
 * Author URI: https://www.wponlinesupport.com/
 *
 * @package WordPress
 * @author WP Online Support
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

if( !defined( 'PCDFWP_VERSION' ) ) {
	define( 'PCDFWP_VERSION', '1.0.2' ); // Version of plugin
}
if( !defined( 'PCDFWP_DIR' ) ) {
    define( 'PCDFWP_DIR', dirname( __FILE__ ) ); // Plugin dir
}
if( !defined( 'PCDFWP_URL' ) ) {
    define( 'PCDFWP_URL', plugin_dir_url( __FILE__ ) ); // Plugin url
}
if( !defined( 'PCDFWP_PRODUCT_POST_TYPE' ) ) {
    define( 'PCDFWP_PRODUCT_POST_TYPE', 'product' ); // Plugin post type name
}
if( !defined( 'PCDFWP_PRODUCT_CAT' ) ) {
    define( 'PCDFWP_PRODUCT_CAT', 'product_cat' ); // Plugin category name
}
if( !defined( 'PCDFWP_PLUGIN_BASENAME' ) ) {
    define( 'PCDFWP_PLUGIN_BASENAME', plugin_basename( __FILE__ ) ); // Plugin base name
}
if( !defined( 'PCDFWP_PRO_META_PREFIX' ) ) {
    define( 'PCDFWP_PRO_META_PREFIX', '_pcdfwp_' ); // Plugin metabox prefix
}

/**
 * Check WooCommerce is active
 *
 * @package Product Categories Designs for WooCommerce Pro
 * @since 1.0
 */
function pcdfwp_check_activation() {

	if ( !class_exists('WooCommerce') ) {
		// is this plugin active?
		if ( is_plugin_active( plugin_basename( __FILE__ ) ) ) {
			// deactivate the plugin
	 		deactivate_plugins( plugin_basename( __FILE__ ) );
	 		// unset activation notice
	 		unset( $_GET[ 'activate' ] );
	 		// display notice
	 		add_action( 'admin_notices', 'pcdfwp_admin_notices' );
		}
	}
}

// Check required plugin is activated or not
add_action( 'admin_init', 'pcdfwp_check_activation' );

/**
 * Admin notices
 * 
 * @package Product Categories Designs for WooCommerce Pro
 * @since 1.0
 */
function pcdfwp_admin_notices() {
	
	if ( !class_exists('WooCommerce') ) {
		echo '<div class="error notice is-dismissible">';
		echo '<p><strong>Product Categories Designs Pro - WooCommerce</strong> '.__(' recommends the following plugin to use.', 'product-categories-designs-for-woocommerce').'</p>';
		echo '<p><strong><a href="https://wordpress.org/plugins/woocommerce/" target="_blank">WooCommerce</a></strong></p>';
		echo '</div>';
	}
}

/**
 * Load Text Domain
 * This gets the plugin ready for translation
 * 
 * @package Product Categories Designs for WooCommerce Pro
 * @since 1.0.0
 */
function pcdfwp_load_textdomain() {

	global $wp_version;

	// Set filter for plugin's languages directory
    $wp_pcdfwp_lang_dir = dirname( plugin_basename( __FILE__ ) ) . '/languages/';
    $wp_pcdfwp_lang_dir = apply_filters( 'wp_pcdfwp_languages_directory', $wp_pcdfwp_lang_dir );

    // Traditional WordPress plugin locale filter.
    $get_locale = get_locale();

    if ( $wp_version >= 4.7 ) {
        $get_locale = get_user_locale();
    }

    // Traditional WordPress plugin locale filter
    $locale = apply_filters( 'plugin_locale',  $get_locale, 'product-categories-designs-for-woocommerce' );
    $mofile = sprintf( '%1$s-%2$s.mo', 'product-categories-designs-for-woocommerce', $locale );

    // Setup paths to current locale file
    $mofile_global  = WP_LANG_DIR . '/plugins/' . basename( PCDFWP_DIR ) . '/' . $mofile;

    if ( file_exists( $mofile_global ) ) { // Look in global /wp-content/languages/plugin-name folder
        load_textdomain( 'product-categories-designs-for-woocommerce', $mofile_global );
    } else { // Load the default language files
        load_plugin_textdomain( 'product-categories-designs-for-woocommerce', false, $wp_pcdfwp_lang_dir );
    }
}

/***** Updater Code Starts *****/
define( 'EDD_PCDFWP_STORE_URL', 'https://www.wponlinesupport.com' );
define( 'EDD_PCDFWP_ITEM_NAME', 'Product Categories Designs WooCommerce Pro' );

// Plugin Updator Class 
if( !class_exists( 'EDD_SL_Plugin_Updater' ) ) {    
    include( dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php' );
}

/**
 * Updater Function
 * 
 * @package Product Categories Designs for WooCommerce Pro
 * @since 1.0.0
 */
function pcdfwp_plugin_updater() {
    
    $license_key = trim( get_option( 'pcdfwp_plugin_license_key' ) );

    $edd_updater = new EDD_SL_Plugin_Updater( EDD_PCDFWP_STORE_URL, __FILE__, array(
                'version'   => PCDFWP_VERSION,       	// current version number
                'license'   => $license_key,            // license key (used get_option above to retrieve from DB)
                'item_name' => EDD_PCDFWP_ITEM_NAME,    // name of this plugin
                'author'    => 'WP Online Support'      // author of this plugin
            ));
}
add_action( 'admin_init', 'pcdfwp_plugin_updater', 0 );

include( dirname( __FILE__ ) . '/pcdfwp-plugin-updater.php' );
/***** Updater Code Ends *****/

/**
 * Load the plugin after the main plugin is loaded.
 * 
 * @package Product Categories Designs for WooCommerce Pro
 * @since 1.0.0
 */
function pcdfwp_load_plugin() {

	// Check main plugin is active or not
	if( class_exists('WooCommerce') ) {

		pcdfwp_load_textdomain(); // Load plugin text domain

		// Functions File
		require_once( PCDFWP_DIR . '/includes/pcdfwp-functions.php' );

		// Admin Class
		require_once( PCDFWP_DIR . '/includes/admin/wp-pcdfwp-admin.php' );

		// Script Class
		require_once( PCDFWP_DIR . '/includes/class-pcdfwp-script.php' );

		// Shortcode File
		require_once( PCDFWP_DIR . '/includes/shortcode/pcdfwp-shortcode.php' );
		require_once( PCDFWP_DIR . '/includes/shortcode/pcdfwp-slider-shortcode.php' );

		// Load admin side files
		if ( is_admin() || ( defined( 'WP_CLI' ) && WP_CLI ) ) {   
		    // Designs file
		    include_once( PCDFWP_DIR . '/includes/admin/wp-pcdfwp-how-it-work.php' );
		}
	}
}

// Action to load plugin after the main plugin is loaded
add_action('plugins_loaded', 'pcdfwp_load_plugin', 15);
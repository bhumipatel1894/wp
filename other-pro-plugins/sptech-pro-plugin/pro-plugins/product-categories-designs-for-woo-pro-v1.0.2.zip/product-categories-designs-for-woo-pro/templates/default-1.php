<div class="<?php echo $wrapper_cls; ?>">
	<div class="pcdfwp-pdt-cat-inner">
		<div class="pcdfwp-img-wrapper pcdfwp-cat-img-bg">
			<?php if(!empty($cat_thumb_link)) { ?>
			<img src="<?php echo $cat_thumb_link; ?>" alt="<?php echo pcdfwp_esc_attr($category->name); ?>" class="pcdfwp-cat-img" />
			<?php } ?>
			<div class="pcdfwp-cat-meta-wrap">
				<?php if( $show_count ) { ?>
				<span class="pcdfwp-cat-count"><?php echo $category->count; ?></span>
				<?php } ?>

				<div class="pcdfwp-title"><?php echo $category->name; ?></div>
			</div>
			<a class="pcdfwp-hover" href="<?php echo $term_link; ?>" target="<?php echo $link_target; ?>"></a>
		</div>

		<?php if( $show_desc && $category->description ) { ?>
		<div class="pcdfwp-bottom-wrapper">
			<div class="pcdfwp-cat-desc"><?php echo wpautop($category->description); ?></div>
		</div>
		<?php } ?>
	</div>
</div>
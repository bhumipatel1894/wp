<div class="<?php echo $wrapper_cls; ?>">
	<div class="pcdfwp-pdt-cat-inner">
		<div class="pcdfwp-img-wrapper pcdfwp-cat-img-bg">
			<a class="pcdfwp-hover" href="<?php echo $term_link; ?>" target="<?php echo $link_target; ?>">
				<?php if(!empty($cat_thumb_link)) { ?>
				<img src="<?php echo $cat_thumb_link; ?>" alt="<?php echo pcdfwp_esc_attr($category->name); ?>" class="pcdfwp-cat-img" />
				<?php } ?>
			</a>
			<?php if( $show_count ) { ?>
				<span class="pcdfwp-cat-count"><?php echo $category->count; ?></span>
			<?php } ?>
		</div>

		<div class="pcdfwp-bottom-wrapper">
			<div class="pcdfwp-title">
				<a href="<?php echo $term_link; ?>" target="<?php echo $link_target; ?>"><?php echo $category->name; ?></a>
			</div>
			<span class="pcdfwp-line"></span>
			<?php if( $show_desc && $category->description ) { ?>
			<div class="pcdfwp-cat-desc"><?php echo wpautop($category->description); ?></div>
			<?php } ?>
		</div>
	</div>
</div>
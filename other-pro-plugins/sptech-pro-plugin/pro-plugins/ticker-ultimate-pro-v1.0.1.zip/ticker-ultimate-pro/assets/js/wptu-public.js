jQuery( document ).ready(function($) {

    // Initialize ticker style 1
    $( '.wptu-ticker-main' ).each(function( index ) {
        
        var ticker_id   = $(this).attr('id');
        var ticker_conf = $.parseJSON( $(this).find('.wptu-ticker-conf').text() );
        
        if( typeof(ticker_id) != 'undefined' && ticker_id != '' && ticker_conf != 'undefined' ) {
            $('#'+ticker_id).wposTicker({
               	effect      : ticker_conf.effect,
                autoplay    : (ticker_conf.autoplay == 'false') ? false : true,
                timer       : parseInt(ticker_conf.timer),
                border      : (ticker_conf.border == 'false') ? false : true,
                fontstyle   : ticker_conf.fontstyle,
            });
        }
    });

    // Initialize ticker style 2
    $( '.wptu-style-two-ticker' ).each(function( index ) {
        var ticker_id   = $(this).attr('id');
        var ticker_conf = $.parseJSON( $(this).find('.wptu-ticker-conf').text() );

        if( typeof(ticker_id) != 'undefined' && ticker_id != '' && ticker_conf != 'undefined' ) {

            if (ticker_conf.fontstyle == "italic") {
                $(this).addClass("wpos-italic");
            }                   
            if (ticker_conf.fontstyle == "bold") {
                $(this).addClass("wpos-bold");
            }                   
            if (ticker_conf.fontstyle == "bold-italic") {
                $(this).addClass("wpos-bold wpos-italic");
            }

            $('#'+ticker_id).modernTicker({
                effect         : ticker_conf.effect, //fade, type, slide, scroll
                autoplay       : (ticker_conf.autoplay == 'false') ? false : true,
                transitionTime : 400,
            });
        }
    });
});
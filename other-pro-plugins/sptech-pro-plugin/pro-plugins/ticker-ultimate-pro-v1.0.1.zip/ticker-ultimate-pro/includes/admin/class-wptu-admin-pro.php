<?php
/**
 * Admin Class
 *
 * Handles the Admin side functionality of plugin
 *
 * @package Ticker Ultimate Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Wptu_Admin_Pro {
	
	function __construct() {

		// Action to add metabox
		add_action( 'add_meta_boxes', array($this, 'wptu_pro_metabox') );

		// Action to save metabox
		add_action( 'save_post', array($this,'wptu_pro_save_metabox_value') );

		// Action to add category filter dropdown
		add_action( 'restrict_manage_posts', array($this, 'wptu_pro_add_post_filters'), 50 );

		// Filter to add row data
		add_filter( 'post_row_actions', array($this, 'wptu_pro_add_post_row_data'), 10, 2 );

		// Filter to add extra column in `ticker category` table
		add_filter( 'manage_'.WPTU_PRO_CAT.'_custom_column', array($this, 'wptu_pro_ticker_category_data'), 10, 3 );
		add_filter( 'manage_edit-'.WPTU_PRO_CAT.'_columns', array($this, 'wptu_pro_manage_category_columns') ); 

		// Filter to add plugin links
		add_filter( 'plugin_row_meta', array( $this, 'wptu_pro_plugin_row_meta' ), 10, 2 );
	}

	/**
	 * Ticker Post Settings Metabox
	 * 
	 * @package Ticker Ultimate Pro
	 * @since 1.0.0
	 */
	function wptu_pro_metabox() {
		add_meta_box( 'wptu-post-sett', __( 'Ticker Ultimate Pro - Settings', 'ticker-ultimate' ), array($this, 'wptu_pro_ticker_metabox_sett_mb_content'), WPTU_PRO_POST_TYPE, 'normal', 'high' );
	}

	/**
	 * Post Settings Metabox HTML
	 * 
	 * @package Ticker Ultimate Pro
	 * @since 1.0.0
	 */
	function wptu_pro_ticker_metabox_sett_mb_content() {
		include_once( WPTU_PRO_DIR .'/includes/admin/metabox/wptu-post-sett-metabox-pro.php');
	}

	/**
	 * Function to save metabox values
	 * 
	 * @package Ticker Ultimate Pro
	 * @since 1.0.0
	 */
	function wptu_pro_save_metabox_value( $post_id ) {

		global $post_type;
		
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )                	// Check Autosave
		|| ( ! isset( $_POST['post_ID'] ) || $post_id != $_POST['post_ID'] )  	// Check Revision
		|| ( $post_type !=  WPTU_PRO_POST_TYPE ) )              					// Check if current post type is supported.
		{
		  return $post_id;
		}

		$prefix = WPTU_PRO_META_PREFIX; // Taking metabox prefix

		// Taking variables
		$read_more_link = isset($_POST[$prefix.'more_link']) ? wptu_pro_slashes_deep(trim($_POST[$prefix.'more_link'])) : '';

		update_post_meta($post_id, $prefix.'more_link', $read_more_link);
	}

	/**
	 * Add category dropdown to Slider listing page
	 * 
	 * @package Ticker Ultimate Pro
	 * @since 1.0.0
	 */
	function wptu_pro_add_post_filters() {
		
		global $typenow;
		
		if( $typenow == WPTU_PRO_POST_TYPE ) {
			
			$wptu_pro_cat = isset($_GET[WPTU_PRO_CAT]) ? $_GET[WPTU_PRO_CAT] : '';

			$dropdown_options = apply_filters('wptu_pro_cat_filter_args', array(
					'show_option_none'  => __('All Categories', 'ticker-ultimate'),
					'option_none_value' => '',
					'hide_empty' 		=> 1,
					'hierarchical' 		=> 1,
					'show_count' 		=> 0,
					'orderby' 			=> 'name',
					'name'				=> WPTU_PRO_CAT,
					'taxonomy'			=> WPTU_PRO_CAT,
					'selected' 			=> $wptu_pro_cat,
					'value_field'		=> 'slug',
				));
			wp_dropdown_categories( $dropdown_options );
		}
	}

	/**
	 * Function to add custom quick links at post listing page
	 * 
	 * @package Ticker Ultimate Pro
	 * @since 1.0.1
	 */
	function wptu_pro_add_post_row_data( $actions, $post ) {
		
		if( $post->post_type == WPTU_PRO_POST_TYPE ) {
			return array_merge( array( 'wptu_pro_id' => 'ID: ' . $post->ID ), $actions );
		}
		
		return $actions;
	}

	/**
	 * Add extra column to ticker category
	 * 
	 * @package Ticker Ultimate Pro
	 * @since 1.0.0
	 */
	function wptu_pro_manage_category_columns($columns) {

		$new_columns['wptu_cat_shortcode'] = __( 'Ticker Category Shortcode', 'ticker-ultimate' );

		$columns = wptu_pro_add_array( $columns, $new_columns, 2 );

		return $columns;
	}

	/**
	 * Add data to extra column to ticker category
	 * 
	 * @package Ticker Ultimate Pro
	 * @since 1.0.0
	 */
	function wptu_pro_ticker_category_data($ouput, $column_name, $tax_id) {
		
		if( $column_name == 'wptu_cat_shortcode' ) {
			$ouput .= '[wp_ticker category="' . $tax_id. '"]<br/>';
			$ouput .= '[wp_ticker_rss category="' . $tax_id. '"]';
	    }
	    return $ouput;
	}

	/**
	 * Function to add extra link to plugins action link
	 * 
	 * @package Ticker Ultimate Pro
	 * @since 1.0.0
	 */
	function wptu_pro_plugin_row_meta( $links, $file ) {
		
		if ( $file == WPTU_PRO_PLUGIN_BASENAME ) {

			$row_meta = array(
				'docs'    => '<a href="' . esc_url('https://www.wponlinesupport.com/pro-plugin-document/document-ticker-ultimate-pro') . '" title="' . esc_attr( __( 'View Documentation', 'ticker-ultimate' ) ) . '" target="_blank">' . __( 'Docs', 'ticker-ultimate' ) . '</a>',
				'support' => '<a href="' . esc_url('https://www.wponlinesupport.com/welcome-wp-online-support-forum/') . '" title="' . esc_attr( __( 'Visit Customer Support Forum', 'ticker-ultimate' ) ) . '" target="_blank">' . __( 'Support', 'ticker-ultimate' ) . '</a>',
			);
			return array_merge( $links, $row_meta );
		}
		return (array) $links;
	}
}
$wptu_admin = new Wptu_Admin_Pro();
<?php
/**
 * Script Class
 *
 * Handles the script and style functionality of plugin
 *
 * @package Ticker Ultimate Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Wptu_Script_Pro {

	function __construct() {
		
 		// Action to add style at front side
		add_action( 'wp_enqueue_scripts', array( $this, 'wptu_pro_front_style') );
		
		// Action to add script at front side
		add_action( 'wp_enqueue_scripts', array( $this, 'wptu_pro_front_script') );

		// Action to add style in backend
		add_action( 'admin_enqueue_scripts', array($this, 'wptu_pro_admin_style') );
	}

	/**
	 * Function to add style at front side
	 * 
	 * @package Ticker Ultimate Pro
 	 * @since 1.0.0
	 */
	function wptu_pro_front_style() {

		// Registring public style
		wp_register_style( 'wptu-front-style', WPTU_PRO_URL.'assets/css/wptu-front.css', null, WPTU_PRO_VERSION );
		wp_enqueue_style('wptu-front-style');
	}
 
	/**
	 * Function to add script at front side
	 * 
	 * @package Ticker Ultimate Pro
	 * @since 1.0.0
	 */
	function wptu_pro_front_script() {
		
		// Registring ticker script
		if( !wp_script_is( 'wpos-ticker-script', 'registered' ) ) {
			wp_register_script( 'wpos-ticker-script', WPTU_PRO_URL . 'assets/js/wptu-ticker.js', array('jquery'), WPTU_PRO_VERSION, true );
		}

		if( !wp_script_is( 'wpos-ticker-advanced-script', 'registered' ) ) {
			wp_register_script( 'wpos-ticker-advanced-script', WPTU_PRO_URL . 'assets/js/wptu-ticker-advanced.js', array('jquery'), WPTU_PRO_VERSION, true );
		}

		// Registring public script
		wp_register_script( 'wptu-public-js', WPTU_PRO_URL . 'assets/js/wptu-public.js', array('jquery'), WPTU_PRO_VERSION, true );
	}

	/**
	 * Function to add style at admin side
	 * 
	 * @package Ticker Ultimate Pro
 	 * @since 1.0.0
	 */
	function wptu_pro_admin_style( $hook ) {

		global $typenow;

		// Taking pages array
		$pages_arr = array(WPTU_PRO_POST_TYPE);

		if( in_array( $typenow, $pages_arr ) ) {

			// Registring public style
			wp_register_style( 'wptu-admin-style', WPTU_PRO_URL.'assets/css/wptu-admin.css', null, WPTU_PRO_VERSION );
			wp_enqueue_style('wptu-admin-style');
		}
	}
}

$wptu_script = new Wptu_Script_Pro();
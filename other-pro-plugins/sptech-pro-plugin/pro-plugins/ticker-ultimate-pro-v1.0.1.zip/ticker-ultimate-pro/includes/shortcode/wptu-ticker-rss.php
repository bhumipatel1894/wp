<?php
/**
 * `wp_ticker_rss` Shortcode
 * 
 * @package Ticker Ultimate Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

function wptu_pro_ticker_rss( $atts, $content = null ) {

	// Shortcode Parameters
	extract(shortcode_atts(array(
		'limit' 				=> '-1',
		'ticker_title'			=> __('Latest News','ticker-ultimate'),
		'color'					=> '#000',
		'background_color'		=> '#2096CD',
		'effect'				=> 'fade',
		'fontstyle'				=> 'normal',
		'autoplay'				=> 'true',
		'timer'					=> 4000,
		'title_color'			=> '#fff',
		'border'				=> 'true',
		'style'                 => 'style-1',
		'rss_url'				=> '',
	), $atts));

    $posts_per_page		= (!empty($limit)) 			  	? $limit 						: '-1';
    $color 				= (!empty($color)) 			  	? $color 						: '#000';
	$background_color   = (!empty($background_color)) 	? $background_color 			: '#2096CD';
	$effect 			= (!empty($effect)) 		  	? $effect 						: 'fade';
	$fontstyle 			= (!empty($fontstyle))  	  	? $fontstyle 					: 'normal';
	$autoplay           = (!empty($autoplay)) 		  	? $autoplay 					: 'true';
	$title_color		= (!empty($title_color)) 	  	? $title_color 					: '#fff';
	$border				= ($border == 'false') 	  	  	? 'false' 						: 'true';
	$border_class		= ($border == 'false') 			? 'wpos-bordernone' 			: '';
	$style				= ($style == 'style-1') 	  	? 'style-1' 					: 'style-2';
	$rss_url			= (!empty($rss_url)) 			? wptu_pro_addhttp($rss_url)	: 'https://en.blog.wordpress.com/feed/';
	$timer				= (!empty($timer)) 	    	  	? $timer 						: '4000';

	// Shortcode File
	$design_file_path 	= WPTU_PRO_DIR . '/includes/templates/rss/' . $style . '.php';
	$design_file 		= (file_exists($design_file_path)) 	? $design_file_path : '';
	
	// Enqueue required script
	if($style == 'style-1') {
		wp_enqueue_script('wpos-ticker-script');
	} elseif ($style == 'style-2'){
		wp_enqueue_script('wpos-ticker-advanced-script');
	}
	wp_enqueue_script('wptu-public-js'); // Public Script
	
	// Taking some globals
	global $post;

	// Taking some defaults
	$unique 	= wptu_pro_get_unique();
	$maxitems	= 0;
	
	// Ticker Cinfiguration
	$ticker_conf = compact( 'effect' ,'fontstyle', 'autoplay', 'timer');

	// Including feed file
	include_once( ABSPATH . WPINC . '/feed.php' );

	// Get a SimplePie feed object from the specified feed source.
	$rss = fetch_feed( $rss_url );

	if ( !is_wp_error( $rss )) : // Checks that the object is created correctly

		// Figure out how many total items there are, but limit it to 5. 
		$maxitems = $rss->get_item_quantity( $posts_per_page );

		// Build an array of all the items, starting with element 0 (first element).
		$rss_items = $rss->get_items( 0, $maxitems );

	endif;

	ob_start();	
	
	if($design_file) {
		
		include($design_file);

	} // End of style()

	$content .= ob_get_clean();
	return $content;
}

// 'wp_ticker_rss' shortcode
add_shortcode('wp_ticker_rss', 'wptu_pro_ticker_rss');
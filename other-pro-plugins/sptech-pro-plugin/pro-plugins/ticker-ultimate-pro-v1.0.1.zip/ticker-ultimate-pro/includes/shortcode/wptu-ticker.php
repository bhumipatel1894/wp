<?php
/**
 * `wp_ticker` Shortcode
 * 
 * @package Ticker Ultimate Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

function wptu_pro_ticker( $atts, $content = null ) {
	
	// Shortcode Parameters
	extract(shortcode_atts(array(		
		'limit' 				=> '15',
		'category' 				=> '',		
		'ticker_title'			=> __('Latest News','ticker-ultimate'),
		'color'					=> '#000',
		'background_color'		=> '#2096CD',
		'effect'				=> 'fade',
		'fontstyle'				=> 'normal',
		'autoplay'				=> 'true',
		'timer'					=> 4000,	
		'title_color'			=> '#fff',
		'border'				=> 'true',
		'post_type'				=> '',
		'post_cat'				=> '',
		'style'                 => 'style-1',
		'order'					=> 'DESC',
		'orderby'				=> 'date',
		'exclude_cat'			=> array(),
		'exclude_post'			=> array(),
		'posts'					=> array(),
		'query_offset'			=> '',
	), $atts));
	
	$ticker_title		= !empty($ticker_title)				? $ticker_title					: '';
    $posts_per_page		= (!empty($limit)) 			  		? $limit 						: '15';
    $cat    			= (!empty($category))		  		? explode(',',$category) 		: '';
    $color 				= (!empty($color)) 			  		? $color 						: '#000';
	$background_color   = (!empty($background_color)) 		? $background_color 			: '#2096CD';
	$effect 			= (!empty($effect)) 		  		? $effect 						: 'fade';
	$fontstyle 			= (!empty($fontstyle))  	  		? $fontstyle 					: 'normal';
	$autoplay           = (!empty($autoplay)) 		  		? $autoplay 					: 'true';
	$title_color		= (!empty($title_color)) 	  		? $title_color 					: '#fff';
	$border				= ($border == 'false') 	  	  		? 'false' 						: 'true';
	$posts 				= !empty($posts)			  		? explode(',', $posts) 			: array();
	$post_type 			= (!empty($post_type)) 		  		? $post_type 					: WPTU_PRO_POST_TYPE;
	$post_cat 			= (!empty($post_cat)) 		  		? $post_cat 					: WPTU_PRO_CAT;
	$border_class		= ($border == 'false') 				? 'wpos-bordernone' 			: '';
	$style				= ($style == 'style-1') 	  		? 'style-1' 					: 'style-2';
	$timer				= (!empty($timer)) 	    	  		? $timer 						: '4000';
	$order 				= ( strtolower($order) == 'asc' ) 	? 'ASC' 						: 'DESC';
	$orderby 			= (!empty($orderby))				? $orderby						: 'date';
	$exclude_cat 		= !empty($exclude_cat)				? explode(',', $exclude_cat) 	: array();
	$exclude_post 		= !empty($exclude_post)				? explode(',', $exclude_post) 	: array();
	$posts 				= !empty($posts)					? explode(',', $posts) 			: array();
	$query_offset		= !empty($query_offset)				? $query_offset 				: null;

	// Shortcode File
	$design_file_path 	= WPTU_PRO_DIR . '/includes/templates/' . $style . '.php';
	$design_file 		= (file_exists($design_file_path)) 	? $design_file_path : '';
	
	// Enqueue required script
	if($style == 'style-1') {
		wp_enqueue_script('wpos-ticker-script');
	} elseif ($style == 'style-2') {
		wp_enqueue_script('wpos-ticker-advanced-script');
	}
	wp_enqueue_script('wptu-public-js'); // Public Script

	// Taking some globals
	global $post;

	// Taking some defaults
	$unique = wptu_pro_get_unique();

	// Ticker Cinfiguration
	$ticker_conf = compact( 'effect' ,'fontstyle', 'autoplay', 'timer');

	// Query Parameter
	$args = array (
		'post_type'     	 	=> $post_type,
		'post_status'			=> array( 'publish' ),
		'order'          		=> $order,
		'orderby'        		=> $orderby,
		'posts_per_page' 		=> $posts_per_page,
		'post__in'				=> $posts,
		'post__not_in'			=> $exclude_post,
		'offset'				=> $query_offset,
		'ignore_sticky_posts'	=> true,
	);

	// Category Parameter
	if( !empty($cat) ) {

		$args['tax_query'] = array(
									array(
										'taxonomy' 			=> $post_cat,
										'field' 			=> 'term_id',
										'terms' 			=> $cat,
									));

	} else if(!empty($exclude_cat)) {
		
		$args['tax_query'] = array(
								array(
									'taxonomy' 			=> WPSPW_CAT,
									'field' 			=> 'term_id',
									'terms' 			=> $exclude_cat,
									'operator'			=> 'NOT IN',
								));
	}

	// WP Query
	$query = new WP_Query($args);

	ob_start();

	// If post is there
	if ( $query->have_posts() ) {

		if($design_file) {
			
			include($design_file);

		} // End of style()

	 } // End of have_post()

	wp_reset_query(); // Reset WP Query

	$content .= ob_get_clean();
	return $content;
}

// 'wp_ticker' shortcode
add_shortcode('wp_ticker', 'wptu_pro_ticker');
<style>
	#wptu-ticker-<?php echo $unique; ?> {border-color: <?php echo $background_color; ?>;}
	#wptu-ticker-<?php echo $unique; ?> .wpos-ticker-title {background: <?php echo $background_color; ?>;}
	#wptu-ticker-<?php echo $unique; ?> .wpos-ticker-title > span {border-color: transparent transparent transparent <?php echo $background_color; ?>}
	#wptu-ticker-<?php echo $unique; ?> .wptu-ticker-block > ul > li > a:hover {color: <?php echo $background_color; ?>}
	#wptu-ticker-<?php echo $unique; ?> .wptu-ticker-block > ul > li > a {color: <?php echo $color; ?>;}
	#wptu-ticker-<?php echo $unique; ?> .wpos-ticker-title .wpos-ticker-head {background-color: <?php echo $background_color; ?>;color: <?php echo $title_color; ?>}
</style>

<div class="wptu-ticker wptu-ticker-main wptu-clearfix <?php echo $border_class; ?>" id="wptu-ticker-<?php echo $unique; ?>">
	<div class="wpos-ticker-title">
		<?php if( $ticker_title ) { ?>
		<div class="wpos-ticker-head">
			<?php echo $ticker_title; ?>
		</div>
		<?php } ?>
		<span></span>
	</div>

	<div class="wptu-ticker-block">	
		<ul>
			<?php if ( $maxitems == 0 ) : ?>
				<li><?php _e( 'Sorry, No items found.', 'ticker-ultimate' ); ?></li>
			<?php else : ?>
			
				<?php foreach ( $rss_items as $item ) : ?>
					<li>
						<a class="wptu-ticker-news wpos-ticker-news" href="<?php echo esc_url( $item->get_permalink() ); ?>" title="<?php printf( __( 'Posted %s', 'ticker-ultimate' ), $item->get_date('j F Y | g:i a') ); ?>">
							<?php echo esc_html( $item->get_title() ); ?>
						</a>
					</li>
				<?php endforeach; ?>
			<?php endif; ?>
		</ul>
	</div>
		
	<div class="wptu-ticker-navi wpos-ticker-navi">
    	<span></span>
        <span></span>
    </div>
	<div class="wptu-ticker-conf"><?php echo htmlspecialchars(json_encode($ticker_conf)); ?></div>
</div>
<style>
	#wptu-ticker-style-<?php echo $unique; ?> {border-color: <?php echo $background_color; ?>;}
	#wptu-ticker-style-<?php echo $unique; ?> .wptu-style-body .wptu-style-label {background-color: <?php echo $background_color; ?>;}
	#wptu-ticker-style-<?php echo $unique; ?> .wptu-style-body .wptu-style-label .wptu-style-label-title {color: <?php echo $title_color; ?>;}
	#wptu-ticker-style-<?php echo $unique; ?> .wptu-style-label > span {border-color: transparent transparent transparent <?php echo $background_color; ?>}
	#wptu-ticker-style-<?php echo $unique; ?> .wptu-style-news a:hover {color: <?php echo $background_color; ?>}
	#wptu-ticker-style-<?php echo $unique; ?> .wptu-style-news a {color: <?php echo $color; ?>;}
</style>

<div class="wptu-style-two-ticker  wptu-clearfix <?php echo $border_class; ?>" id="wptu-ticker-style-<?php echo $unique; ?>">
	<div class="wptu-style-body">		
		
		<?php if( $ticker_title ) { ?>
		<div class="wptu-style-label">
			<div class="wptu-style-label-title">
				<?php echo $ticker_title; ?>
			</div>
			<span></span>
		</div>
		<?php } ?>

		<div class="wptu-style-news">
			<ul>
				<?php if ( $maxitems == 0 ) : ?>	
					<li><span class="wptu-ticker-news wpos-ticker-news"><?php _e( 'Sorry, No items found.', 'ticker-ultimate' ); ?></span></li>
				<?php else : ?>
				   
					<?php foreach ( $rss_items as $item ) : ?>
						<li>
							<a class="wptu-ticker-news wpos-ticker-news" href="<?php echo esc_url( $item->get_permalink() ); ?>" title="<?php printf( __( 'Posted %s', 'ticker-ultimate' ), $item->get_date('j F Y | g:i a') ); ?>">
								<?php echo esc_html( $item->get_title() ); ?>
							</a>
						</li>
					<?php endforeach; ?>
				<?php endif; ?>
			</ul>
		</div>
		
		<div class="wptu-style-controls">
			<div class="wptu-style-prev"></div>
			<div class="wptu-style-play"></div>
			<div class="wptu-style-next"></div>
		</div>
	</div>
	<div class="wptu-ticker-conf"><?php echo htmlspecialchars(json_encode($ticker_conf)); ?></div>
</div>
<style>
	#wptu-ticker-style-<?php echo $unique; ?> {border-color: <?php echo $background_color; ?>;}
	#wptu-ticker-style-<?php echo $unique; ?> .wptu-style-body .wptu-style-label {background-color: <?php echo $background_color; ?>;}
	#wptu-ticker-style-<?php echo $unique; ?> .wptu-style-body .wptu-style-label-title {color: <?php echo $title_color; ?>;}
	#wptu-ticker-style-<?php echo $unique; ?> .wptu-style-label > span {border-color: transparent transparent transparent <?php echo $background_color; ?>}
	#wptu-ticker-style-<?php echo $unique; ?> .wptu-style-news a:hover {color: <?php echo $background_color; ?>}
	#wptu-ticker-style-<?php echo $unique; ?> .wptu-style-news a {color: <?php echo $color; ?>;}
</style>

<div class="wptu-ticker wptu-style-two-ticker wptu-clearfix <?php echo $border_class; ?>" id="wptu-ticker-style-<?php echo $unique; ?>">
	<div class="wptu-style-body">
		
		<?php if( $ticker_title ) { ?>
		<div class="wptu-style-label">
			<div class="wptu-style-label-title">
				<?php echo $ticker_title; ?>
			</div>
			<span></span>
		</div>
		<?php } ?>
		
		<div class="wptu-style-news">
			<ul>
				<?php while ( $query->have_posts() ) : $query->the_post();	
					$post_link = wptu_pro_get_post_link( $post->ID );
				?>
					<li>
						<?php if( !empty($post_link) ) { ?>
							<a class="wptu-ticker-news wpos-ticker-news" href="<?php echo $post_link; ?>"><?php the_title(); ?></a>
						<?php } else { ?>
							<span class="wptu-ticker-news wpos-ticker-news"><?php the_title(); ?></span>
						<?php } ?>
					</li>
				<?php endwhile; ?>
			</ul>
		</div>

		<div class="wptu-style-controls">
			<div class="wptu-style-prev"></div>
			<div class="wptu-style-play"></div>
			<div class="wptu-style-next"></div>
		</div>
	</div>
	<div class="wptu-ticker-conf"><?php echo htmlspecialchars(json_encode($ticker_conf)); ?></div>
</div>
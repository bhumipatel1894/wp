<?php
/**
 * Plugin generic functions file
 *
 * @package Ticker Ultimate Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Escape Tags & Slashes
 *
 * Handles escapping the slashes and tags
 *
 * @package Ticker Ultimate Pro
 * @since 1.0.0
 */
function wptu_pro_esc_attr($data) {
	return esc_attr( stripslashes($data) );
}

/**
 * Strip Slashes From Array
 *
 * @package Ticker Ultimate Pro
 * @since 1.0.0
 */
function wptu_pro_slashes_deep($data = array(), $flag = false) {
	
	if($flag != true) {
		$data = wptu_pro_nohtml_kses($data);
	}
	$data = stripslashes_deep($data);
	return $data;
}

/**
 * Strip Html Tags 
 * 
 * It will sanitize text input (strip html tags, and escape characters)
 * 
 * @package Ticker Ultimate Pro
 * @since 1.0.0
 */
function wptu_pro_nohtml_kses($data = array()) {
	
	if ( is_array($data) ) {
		
		$data = array_map('wptu_pro_nohtml_kses', $data);
		
	} elseif ( is_string( $data ) ) {
		$data = trim( $data );
		$data = wp_filter_nohtml_kses($data);
	}
	
	return $data;
}

/**
 * Function to get post external link or permalink
 * 
 * @package Ticker Ultimate Pro
 * @since 1.0.0
 */
function wptu_pro_get_post_link( $post_id = '' ) {

	$post_link = '';

	if( !empty($post_id) ) {

		$prefix = WPTU_PRO_META_PREFIX;
		
		$post_link = get_post_meta( $post_id, $prefix.'more_link', true );

		if( empty($post_link) && (get_post_type($post_id) != WPTU_PRO_POST_TYPE) ) {
			$post_link = get_the_permalink( $post_id );	
		}
	}
	return $post_link;
}

/**
 * Function to unique number value
 * 
 * @package Ticker Ultimate Pro
 * @since 1.0.0
 */
function wptu_pro_get_unique() {
  static $unique = 0;
  $unique++;

  return $unique;
}

/**
 * Function to add array after specific key
 * 
 * @package Ticker Ultimate Pro
 * @since 1.0.0
 */
function wptu_pro_add_array(&$array, $value, $index, $from_last = false) {
    
    if( is_array($array) && is_array($value) ) {

        if( $from_last ) {
            $total_count    = count($array);
            $index          = (!empty($total_count) && ($total_count > $index)) ? ($total_count-$index): $index;
        }
        
        $split_arr  = array_splice($array, max(0, $index));
        $array      = array_merge( $array, $value, $split_arr);
    }
    return $array;
}

/**
 * add http in url if not exist
 * 
 * it will add http in url if not exist
 * 
 * @package Ticker Ultimate Pro
 * @since 1.0.0
 */
function wptu_pro_addhttp($url) {
    if (!preg_match("~^(?:f|ht)tps?://~i", $url)) {
        $url = "http://" . $url;
    }
    return $url;
}
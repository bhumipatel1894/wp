=== Ticker Ultimate Pro ===
Contributors: wponlinesupport, anoopranawat 
Tags: wponlinesupport, ticker, news ticker, blog ticker, post ticker, ticker slider, ticker vertical slider, ticker horizontal slider
Requires at least: 3.1
Tested up to: 4.7.1
Stable tag: trunk
License: GNU Version 2 or Any Later Version

A quick, easy way to add and display Tickers to your site.

== Description ==
A very simple plugin to add and display News Tickers in horizontal slider, vertical slider that work with wordpress posts with the help of shortcode.

Ticker Ultimate Plugin enables you to create and display posts in fade, vertical and horizontal slider effect.

With Rss shortcode you can fetch RSS feed from website and display in ticker mode with two cool designs.

View [DEMO](https://www.wponlinesupport.com/wp-plugin/ticker-ultimate/) for more details.

**This plugin contain two shortcodes**

= Here is the shortcode example =
- Ticker Ultimate Shortcode: 
<code>[wp_ticker]</code>
<code>[wp_ticker_rss]</code>

Where you can display your recent post as headline.

= Complete shortcode with all parameters =
Ticker Ultimate Shortcode:
<code>[wp_ticker limit="5" category="5" ticker_title="News Tickers" color="#000" background_color="#2096CD" effect="fade" fontstyle="normal" autoplay="false" timer="4000" title_color="#000" border="false" post_type="post" post_cat="category" style="style-1" exclude_cat="2,5,9" exclude_post="12,45,69" posts="56,48,26"]</code>

<code>[wp_ticker_rss limit="5" ticker_title="News Tickers" color="#000" background_color="#2096CD" effect="fade" fontstyle="normal" autoplay="false" timer="4000" title_color="#000" border="false" post_type="post" post_cat="category" style="style-1" rss_url="http://www.wponlinesupport.com/feed"]</code>
 
= Use Following parameters with shortcode =
<code>[wp_ticker]</code>

* **Limit:** [wp_ticker limit="5"] (number of posts that you want to display.)
* **Category:** [wp_ticker category="5"] (Ticker id for which you want to display posts.)
* **Ticker Title:** [wp_ticker ticker_title="News Tickers"] (Title of the Ticker you want to display.)
* **Color:** [wp_ticker color="#000"] (To change the post content color)
* **Title Color:** [wp_ticker title_color="#000"] (To change the Ticker Title color.)
* **Background Color:** [wp_ticker background_color="#2096CD"] (To change the News Ticker title background color.)
* **Effect:** [wp_ticker effect="fade"] (You can change the content effect. default effect is fade effect. values are "slide-h", "slide-v", "fade".)
* **Font Style:** [wp_ticker fontstyle="normal"] (You can change the Font Style of the content. Values are "normal", "bold", "italic" and "bold-italic".)
* **Border:** [wp_ticker border="true"] (Display Border to the Tickers. Values are "true" OR "false".)
* **Autoplay:** [wp_ticker autoplay="true"] (Start tickers automatically. Values are "true" OR "false".)
* **Timer:** [wp_ticker timer="3000"] (Control speed of ticker slider.)
* **Post Type:** [wp_ticker post_type="post"] (You can view the Default wordpress posts with ticker plugin.)
* **Post Category:** [wp_ticker post_cat="category"] (You can apply the Default wordpress category with ticker plugin..)
* **Exclude Category:** [wp_ticker exclude_cat="12,45,78"] (Comma separated category ids of the post that you dont want to display.)
* **Exclude post:** [wp_ticker exclude_post="12,45,78"] (Comma separated post ids that you dont want to display.)
* **Posts:** [wp_ticker posts="12,45,78"] (Comma separated post ids that you want to display.)
* **Order :** [wp_ticker order="DESC"] (Controls post order. Values are "ASC" OR "DESC".)
* **Orderby :** [wp_ticker orderby="date"] (Display post in your order. Values are "post_date", "modified", "title", "name" (Post Slug), "ID", "rand", "menu_order")

<code>[wp_ticker_rss]</code>

* **Limit:** [wp_ticker_rss limit="5"] (number of posts that you want to display.)
* **Ticker Title:** [wp_ticker_rss ticker_title="News Tickers"] (Title of the Ticker you want to display.)
* **Color:** [wp_ticker_rss color="#000"] (To change the post content color)
* **Title Color:** [wp_ticker_rss title_color="#000"] (To change the Ticker Title color.)
* **Background Color:** [wp_ticker_rss background_color="#2096CD"] (To change the News Ticker title background color.)
* **Effect:** [wp_ticker_rss effect="fade"] (You can change the content effect. default effect is fade effect. values are "scroll", "type", "slide".)
* **Font Style:** [wp_ticker_rss fontstyle="normal"] (You can change the Font Style of the content. Values are "normal", "bold", "italic" and "bold-italic".)
* **Border:** [wp_ticker_rss border="true"] (Display Border to the Tickers. Values are "true" OR "false".)
* **Autoplay:** [wp_ticker_rss autoplay="true"] (Start tickers automatically. Values are "true" OR "false".)
* **Timer:** [wp_ticker_rss timer="3000"] (Control speed of ticker slider.)
* **RSS URL:** [wp_ticker_rss rss_url="https://en.blog.wordpress.com/feed/"] (Fetch the RSS feeds from website. by default is "https://en.blog.wordpress.com/feed/")

= Template code is =
<code><?php echo do_shortcode('[wp_ticker]'); ?></code>
<code><?php echo do_shortcode('[wp_ticker_rss]'); ?></code>

= Available Features : =
* Custom Color Change of the Title
* Custom Background Color Change of the Title
* Ticker Slider Effect
* Ticker Slider Timer
* Default Wordpress Posts Support
* Strong shortcode parameters
* 100% Multilanguage
 
== Installation ==

1. Upload the 'Ticker Ultimate Pro' folder to the '/wp-content/plugins/' directory.
2. Activate the "Ticker Ultimate Pro" list plugin through the 'Plugins' menu in WordPress.
3. Add a new page and add desired short code in that.

== Screenshots ==


== Changelog ==

= 1.0.1 (23 Jan, 2017) =
* [*] Resolved plugin update issue.

= 1.0 =
* Initial release.

== Upgrade Notice ==

= 1.0.1 (23 Jan, 2017) =
* [*] Resolved plugin update issue.

= 1.0 =
* Initial release.
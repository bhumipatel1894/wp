<?php
/*
 * Plugin Name: Ticker Ultimate Pro
 * Plugin URL: https://www.wponlinesupport.com/
 * Text Domain: ticker-ultimate
 * Domain Path: /languages/
 * Description: Ultimate Ticker Plugin work with custom post type, WordPress post and RSS
 * Version: 1.0.1
 * Author: WP Online Support
 * Author URI: http://www.wponlinesupport.com/
 * Contributors: WP Online Support
*/

if( !defined( 'WPTU_PRO_VERSION' ) ) {
    define( 'WPTU_PRO_VERSION', '1.0.1' ); // Version of plugin
}
if( !defined( 'WPTU_PRO_POST_TYPE' ) ) {
    define( 'WPTU_PRO_POST_TYPE', 'wptu_ticker' ); // Plugin post type
}
if( !defined( 'WPTU_PRO_DIR' ) ) {
    define( 'WPTU_PRO_DIR', dirname( __FILE__ ) ); // Plugin dir
}
if( !defined( 'WPTU_PRO_URL' ) ) {
    define( 'WPTU_PRO_URL', plugin_dir_url( __FILE__ ) ); // Plugin url
}
if( !defined( 'WPTU_PRO_PLUGIN_BASENAME' ) ) {
    define( 'WPTU_PRO_PLUGIN_BASENAME', plugin_basename( __FILE__ ) ); // Plugin base name
}
if( !defined( 'WPTU_PRO_CAT' ) ) {
    define( 'WPTU_PRO_CAT', 'wptu-ticker-category' ); // Plugin category name
}
if( !defined( 'WPTU_PRO_META_PREFIX' ) ) {
    define( 'WPTU_PRO_META_PREFIX', '_wptu_' ); // Plugin metabox prefix
}

/**
 * Load Text Domain
 * This gets the plugin ready for translation
 * 
 * @package Ticker Ultimate Pro
 * @since 1.0.0
 */
function wptu_pro_ticker_load_textdomain() {
    
    global $wp_version;

    // Set filter for plugin's languages directory
    $wptu_pro_lang_dir = dirname( plugin_basename( __FILE__ ) ) . '/languages/';
    $wptu_pro_lang_dir = apply_filters( 'wptu_pro_languages_directory', $wptu_pro_lang_dir );
    
    // Traditional WordPress plugin locale filter.
    $get_locale = get_locale();

    if ( $wp_version >= 4.7 ) {
        $get_locale = get_user_locale();
    }

    // Traditional WordPress plugin locale filter
    $locale = apply_filters( 'plugin_locale',  $get_locale, 'ticker-ultimate' );
    $mofile = sprintf( '%1$s-%2$s.mo', 'ticker-ultimate', $locale );

    // Setup paths to current locale file
    $mofile_global  = WP_LANG_DIR . '/plugins/' . basename( WPTU_PRO_DIR ) . '/' . $mofile;

    if ( file_exists( $mofile_global ) ) { // Look in global /wp-content/languages/plugin-name folder
        load_textdomain( 'ticker-ultimate', $mofile_global );
    } else { // Load the default language files
        load_plugin_textdomain( 'ticker-ultimate', false, $wptu_pro_lang_dir );
    }
}
add_action('plugins_loaded', 'wptu_pro_ticker_load_textdomain');

/**
 * Activation Hook
 * 
 * Register plugin activation hook.
 * 
 * @package Ticker Ultimate Pro
 * @since 1.0.0
 */
register_activation_hook( __FILE__, 'wptu_pro_ticker_install' );

/**
 * Plugin Activation Function
 * Does the initial setup, sets the default values for the plugin options
 * 
 * @package Ticker Ultimate Pro
 * @since 1.0.0
 */
function wptu_pro_ticker_install() {
    
    // Custom post type and taxonomy function
    wptu_pro_register_post_type();
    wptu_pro_register_taxonomies();
    
    // IMP to call to generate new rules
    flush_rewrite_rules();

    // Check if free version of plugin is active or not
    if( is_plugin_active('ticker-ultimate/wp-ticker.php') ) {
        add_action('update_option_active_plugins', 'wptu_pro_deactivate_free_version');
    }
}

/**
 * Plugin Setup (On Deactivation)
 * 
 * Delete  plugin options.
 * 
 * @package Ticker Ultimate Pro
 * @since 1.0.0
 */
function wptu_pro_uninstall() {
    // Uninstall functionality
}

/**
 * Deactivate free plugin
 * 
 * @package Ticker Ultimate Pro
 * @since 1.0.0
 */
function wptu_pro_deactivate_free_version() {
    deactivate_plugins('ticker-ultimate/wp-ticker.php', true);
}

/**
 * Function to display admin notice of activated plugin.
 * 
 * @package Ticker Ultimate Pro
 * @since 1.0.0
 */
function wptu_pro_admin_notice() {
    
    $dir = WP_PLUGIN_DIR . '/ticker-ultimate/wp-ticker.php';

    // If PRO plugin is active and free plugin exist
    if( is_plugin_active( 'ticker-ultimate-pro/wptu-ticker-ultimate-pro.php' ) && file_exists($dir) ) {

        global $pagenow;

        if( $pagenow == 'plugins.php' && current_user_can( 'install_plugins' ) ) {
            echo '<div id="message" class="updated notice is-dismissible">
                    <p><strong>'.__('Thank you for activating  Ticker Ultimate Pro', 'ticker-ultimate').'</strong><br />
                    '.sprintf( __('It looks like you had FREE version %s of this plugin activated. To avoid conflicts the extra version has been deactivated and we recommend you delete it.', 'ticker-ultimate'), '<strong>(Ticker Ultimate)</strong>' ).'
                    </p>
                 </div>';
        }
    }
}
add_action( 'admin_init', 'wptu_pro_admin_notice', 0 );

/***** Updater Code Starts *****/
define( 'EDD_WPTU_STORE_URL', 'https://www.wponlinesupport.com' );
define( 'EDD_WPTU_ITEM_NAME', 'Ticker Ultimate Pro' );

// Plugin Updator Class 
if( !class_exists( 'EDD_SL_Plugin_Updater' ) ) {    
    include( dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php' );
}

/**
 * Updater Function
 * 
 * @package Ticker Ultimate Pro
 * @since 1.0.0
 */
function wptu_pro_plugin_updater() {

    $license_key = trim( get_option( 'edd_wptu_license_key' ) );

    $edd_updater = new EDD_SL_Plugin_Updater( EDD_WPTU_STORE_URL, __FILE__, array(
                'version'   => WPTU_PRO_VERSION,         // current version number
                'license'   => $license_key,             // license key (used get_option above to retrieve from DB)
                'item_name' => EDD_WPTU_ITEM_NAME,      // name of this plugin
                'author'    => 'WP Online Support'       // author of this plugin
            )
    );
}
add_action( 'admin_init', 'wptu_pro_plugin_updater', 0 );
include( dirname( __FILE__ ) . '/wptu-plugin-updater.php' );
/***** Updater Code Ends *****/

// Functions file
require_once( WPTU_PRO_DIR . '/includes/wptu-functions-pro.php' );

// Plugin Post type file
require_once( WPTU_PRO_DIR . '/includes/wptu-post-types-pro.php' );

// Scripts Class
require_once( WPTU_PRO_DIR . '/includes/class-wptu-script-pro.php' );

// Admin Class
require_once( WPTU_PRO_DIR . '/includes/admin/class-wptu-admin-pro.php');

// Shortcodes
require_once( WPTU_PRO_DIR . '/includes/shortcode/wptu-ticker.php');
require_once( WPTU_PRO_DIR . '/includes/shortcode/wptu-ticker-rss.php');

// Load admin files
if ( is_admin() || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
    require_once( WPTU_PRO_DIR . '/includes/admin/wptu-how-it-work.php' );
}
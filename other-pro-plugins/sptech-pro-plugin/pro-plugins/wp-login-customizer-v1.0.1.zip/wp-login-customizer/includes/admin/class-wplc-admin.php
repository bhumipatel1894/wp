<?php
/**
 * Admin Class
 *
 * Handles the Admin side functionality of plugin
 *
 * @package WP Login Customizer
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Wplc_Admin {
	
	function __construct() {

		// Action to register admin menu
		add_action( 'admin_menu', array($this, 'wplc_register_menu') );

		// Action to register plugin settings
		add_action ( 'admin_init', array($this,'wplc_register_settings') );

		// Filter to add plugin links
		add_filter( 'plugin_action_links_' . WPLC_PLUGIN_BASENAME, array($this, 'wplc_plugin_action_links') );
	}

	/**
	 * Function to register admin menus
	 * 
	 * @package WP Login Customizer
	 * @since 1.0.0
	 */
	function wplc_register_menu() {
		add_menu_page ( __('Login Customizer', 'wplc'), __('Login Customizer', 'wplc'), 'manage_options', 'wplc-settings', array($this, 'wplc_settings_page'), 'dashicons-desktop' );
	}

	/**
	 * Function to handle the setting page html
	 * 
	 * @package WP Login Customizer
	 * @since 1.0.0
	 */
	function wplc_settings_page() {
		include_once( WPLC_DIR . '/includes/admin/form/wplc-settings.php' );
	}

	/**
	 * Function register setings
	 * 
	 * @package WP Login Customizer
	 * @since 1.0.0
	 */
	function wplc_register_settings(){
		register_setting( 'wplc_plugin_options', 'wplc_options', array($this, 'wplc_validate_options') );
	}

	/**
	 * Validate Settings Options
	 * 
	 * @package WP Login Customizer
	 * @since 1.0.0
	 */
	function wplc_validate_options( $input ) {

		$input['enable_customizer']		= !empty($input['enable_customizer']) 		? 1 : 0;
		$input['form_bg_transparent']	= !empty($input['form_bg_transparent'])		? 1 : 0;
		$input['form_inp_transparent']	= !empty($input['form_inp_transparent']) 	? 1 : 0;
		$input['logo_title']			= !empty($input['logo_title']) 	? wplc_slashes_deep( $input['logo_title'] ) 	: '';
		$input['logo_url']				= !empty($input['logo_url']) 	? wplc_slashes_deep( $input['logo_url'] ) 		: '';
		$input['bg_url']				= !empty($input['bg_url']) 		? wplc_slashes_deep( $input['bg_url'] ) 		: '';
		$input['form_bg_url']			= !empty($input['form_bg_url']) 	? wplc_slashes_deep( $input['form_bg_url'] ) 	: '';
		$input['custom_css'] 			= !empty($input['custom_css']) 	? wplc_slashes_deep( $input['custom_css'] ) 	: '';
		$input['form_opacity']			= ( isset($input['form_opacity']) && $input['form_opacity'] != '' && $input['form_opacity'] <= 1 ) ? $input['form_opacity'] : 1;
		
		return $input;
	}

	/**
	 * Function to add extra plugins link
	 * 
	 * @package WP Login Customizer
	 * @since 1.0.1
	 */
	function wplc_plugin_action_links( $links ) {

		$license_url = add_query_arg( array( 'page' => 'wplc-pro-license'), admin_url('plugins.php') );
		
		$links['license'] = '<a href="' . esc_url($license_url) . '" title="' . esc_attr( __( 'Activate Plugin License', 'wp-slick-slider-and-image-carousel' ) ) . '">' . __( 'License', 'wp-slick-slider-and-image-carousel' ) . '</a>';
		
		return $links;
	}
}

$wplc_admin = new Wplc_Admin();
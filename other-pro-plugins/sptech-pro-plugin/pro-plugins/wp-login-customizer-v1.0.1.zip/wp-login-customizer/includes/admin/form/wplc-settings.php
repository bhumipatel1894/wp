<?php
/**
 * Settings Page
 *
 * @package WP Login Customizer
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

global $wp_version;

// Background position array
$bg_position_arr = array(
							'left top' 		=> __('Left Top', 'wplc'),
							'left center' 	=> __('Left Center', 'wplc'),
							'left bottom'	=> __('Left Bottom', 'wplc'),
							'right top'		=> __('Right Top', 'wplc'),
							'right center'	=> __('Right Center', 'wplc'),
							'right bottom'	=> __('Right Bottom', 'wplc'),
							'center top'	=> __('Center Top', 'wplc'),
							'center center'	=> __('Center Center', 'wplc'),
							'center bottom'	=> __('Center Bottom', 'wplc'),
					);
// Background position array
$bg_repeat_arr = array(
							'no-repeat' => __('No Repeat', 'wplc'),
							'repeat' 	=> __('Repeat', 'wplc'),
							'repeat-x'	=> __('Repeat X', 'wplc'),
							'repeat-y'	=> __('Repeat Y', 'wplc')
					);
?>

<div class="wrap wplc-settings">

<h2><?php _e( 'WP Login Customizer Settings', 'wplc' ); ?></h2><br />

<?php
if( isset($_POST['wplc_reset_settings']) && !empty($_POST['wplc_reset_settings']) ) {
	
	wplc_default_settings(); // set default settings
	
	// Reset message
	echo '<div id="message" class="updated notice notice-success is-dismissible">
			<p>' . __( 'All settings reset successfully.', 'wplc') . '</p>
		 </div>';
}

// Success message
if( isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true' ) {
	echo '<div id="message" class="updated notice notice-success is-dismissible">
			<p>'.__("Your changes saved successfully.", "wplc").'</p>
		  </div>';
}
?>

<!-- Plugin reset settings form -->
<form action="" method="post" id="wplc-reset-sett-form">
	<div class="wplc-reset-sett-form-wrp wplc-clearfix">
		<input type="submit" class="button button-primary right wplc-reset-sett" name="wplc_reset_settings" id="wplc-reset-sett" value="<?php _e( 'Reset All Settings', 'wplc' ); ?>" />
	</div>
</form>

<form action="options.php" method="POST" id="wplc-settings-form" class="wplc-settings-form">
	
	<?php
	    settings_fields( 'wplc_plugin_options' );
	    global $wplc_options;

	    $logo_cust_link_class 	= $wplc_options['logo_link'] != 'custom' ? 'wplc-hide' : '';
	    $form_bg_opacity_class 	= !empty($wplc_options['form_bg_transparent'])	? 'wplc-hide' : '';
	    $form_inp_bg_sett_class = !empty($wplc_options['form_inp_transparent']) ? 'wplc-hide' : '';
	?>

	<!-- General Settings Ends -->
	<div id="wplc-general-settings" class="post-box-container wplc-general-settings">
		<div class="metabox-holder">
			<div class="meta-box-sortables ui-sortable">
				<div id="general" class="postbox">

					<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'General Settings', 'wplc' ); ?></span>
						</h3>
						
						<div class="inside">
						
						<table class="form-table wplc-general-settings-tbl">
							<tbody>
								<tr>
									<th scope="row">
										<label for="wplc-enable-customizer"><?php _e('Enable Login Customizer', 'wplc'); ?>:</label>
									</th>
									<td>
										<input type="checkbox" name="wplc_options[enable_customizer]" value="1" class="wplc-enable-customizer" id="wplc-enable-customizer" <?php checked( $wplc_options['enable_customizer'], 1 ); ?> /><br/>
										<span class="description"><?php _e('Check this box if you want to change login screen.', 'wplc'); ?></span>
									</td>
								</tr>
								<tr>
									<td colspan="2" valign="top" scope="row">
										<input type="submit" id="wplc-settings-submit" name="wplc-settings-submit" class="button button-primary right" value="<?php _e('Save Changes','wplc');?>" />
									</td>
								</tr>
							</tbody>
						 </table>

					</div><!-- .inside -->
				</div><!-- #general -->
			</div><!-- .meta-box-sortables ui-sortable -->
		</div><!-- .metabox-holder -->
	</div><!-- #wplc-general-settings -->
	<!-- General Settings Ends -->


	<!-- Logo Settings Start -->
	<div id="wplc-logo-settings" class="post-box-container wplc-logo-settings">
		<div class="metabox-holder">
			<div class="meta-box-sortables ui-sortable">
				<div id="logo-settings" class="postbox">

					<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'Logo Settings', 'wplc' ); ?></span>
						</h3>
						
						<div class="inside">
						
						<table class="form-table wplc-logo-settings-tbl">
							<tbody>
								<tr>
									<th scope="row">
										<label for="wplc-logo-link"><?php _e('Logo Link', 'wplc'); ?>:</label>
									</th>
									<td>
										<select name="wplc_options[logo_link]" class="wplc-logo-link" id="wplc-logo-link">
											<option value=""><?php _e('Default', 'wplc') ?></option>
											<option value="site_url" <?php selected( $wplc_options['logo_link'], 'site_url' ); ?>><?php _e('Site URL', 'wplc') ?></option>
											<option value="custom" <?php selected( $wplc_options['logo_link'], 'custom' ); ?>><?php _e('Custom URL', 'wplc') ?></option>
										</select><br />
										<span class="description"><?php _e( 'Choose logo link.', 'wplc' ); ?></span>
									</td>
								</tr>
								<tr class="wplc-logo-custom-link-row <?php echo $logo_cust_link_class; ?>">
									<th scope="row">
										<label for="wplc-logo-custom-link"><?php _e('Custom Logo Link', 'wplc'); ?>:</label>
									</th>
									<td>
										<input type="text" name="wplc_options[custom_logo_url]" value="<?php echo wplc_escape_attr( $wplc_options['custom_logo_url'] ); ?>" id="wplc-logo-custom-link" class="large-text wplc-logo-custom-link" /><br />
										<span class="description"><?php _e( 'Enter custom logo link. (i.e http://wponlinesupport.com)', 'wplc' ); ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="wplc-logo-title"><?php _e('Logo Title', 'wplc'); ?>:</label>
									</th>
									<td>
										<input type="text" name="wplc_options[logo_title]" value="<?php echo wplc_escape_attr( $wplc_options['logo_title'] ); ?>" id="wplc-logo-title" class="regular-text wplc-logo-title" /><br />
										<span class="description"><?php _e( 'Enter logo title. Default is `Powered by WordPress`.', 'wplc' ); ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="wplc-logo-url"><?php _e('Logo Image', 'wplc'); ?>:</label>
									</th>
									<td>
										<input type="text" name="wplc_options[logo_url]" value="<?php echo wplc_escape_attr( $wplc_options['logo_url'] ); ?>" id="wplc-logo-url" class="regular-text wplc-logo-url wplc-img-upload-input" />
										<input type="button" name="wplc_logo_url_btn" id="wplc_icon_url" class="button-secondary wplc-image-upload" value="<?php _e( 'Upload Image', 'wplc'); ?>" data-uploader-title="<?php _e('Choose Logo', 'wplc'); ?>" data-uploader-button-text="<?php _e('Insert Logo', 'wplc'); ?>" /> <input type="button" name="wplc_logo_url_clear" id="wplc-logo-url-clear" class="button button-secondary wplc-image-clear" value="<?php _e( 'Clear', 'wplc'); ?>" /> <br />
										<span class="description"><?php _e( 'Upload your custom logo.', 'wplc' ); ?></span>
										<?php
											$logourl = '';
											if( isset( $wplc_options['logo_url'] ) && !empty( $wplc_options['logo_url'] ) ) { 
												$logourl = '<img src="'.$wplc_options['logo_url'].'" alt="" />';
											}
										?>
										<div class="wplc-img-view"><?php echo $logourl;?></div>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="wplc-logo-width"><?php _e('Logo Width and Height', 'wplc'); ?>:</label>
									</th>
									<td>
										<input type="text" name="wplc_options[logo_width]" value="<?php echo $wplc_options['logo_width']; ?>" size="6" class="wplc-logo-width" id="wplc-logo-width" /> <label for="wplc-logo-width"><?php _e('Width', 'wplc'); ?></label> &nbsp;&nbsp;
										<input type="text" name="wplc_options[logo_height]" value="<?php echo $wplc_options['logo_height']; ?>" size="6" class="wplc-logo-height" id="wplc-logo-height" /> <label for="wplc-logo-height"><?php _e('Height', 'wplc'); ?></label> <br/>
										<span class="description"><?php _e('Enter custom width and height for logo.'); ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="wplc-logo-bg-pos"><?php _e('Logo Background Position', 'wplc'); ?>:</label>
									</th>
									<td>
										<select name="wplc_options[logo_bg_pos]" class="wplc-logo-bg-pos" id="wplc-logo-bg-pos">
										<option value=""><?php _e('Select Background Position', 'wplc'); ?></option>
										<?php foreach ($bg_position_arr as $bg_pos_key => $bg_position_val) { ?>
											<option value="<?php echo $bg_pos_key; ?>" <?php selected( $wplc_options['logo_bg_pos'], $bg_pos_key ); ?> ><?php echo $bg_position_val; ?></option>
										<?php } ?>
										</select><br/>
										<span class="description"><?php _e('Select logo background position.'); ?></span>
									</td>
								</tr>
								<tr>
									<td colspan="2" valign="top" scope="row">
										<input type="submit" id="wplc-settings-submit" name="wplc-settings-submit" class="button button-primary right" value="<?php _e('Save Changes','wplc');?>" />
									</td>
								</tr>
							</tbody>
						 </table>
					</div><!-- .inside -->
				</div><!-- #logo-settings -->
			</div><!-- .meta-box-sortables ui-sortable -->
		</div><!-- .metabox-holder -->
	</div><!-- #wplc-logo-settings -->
	<!-- Logo Settings Ends -->


	<!-- Background Settings Start -->
	<div id="wplc-bg-settings-wrp" class="post-box-container wplc-bg-settings">
		<div class="metabox-holder">
			<div class="meta-box-sortables ui-sortable">
				<div id="wplc-bg-settings" class="postbox">

					<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'Login Page Background Settings', 'wplc' ); ?></span>
						</h3>
						
						<div class="inside">
						
						<table class="form-table wplc-bg-settings-tbl">
							<tbody>
								<tr>
									<th scope="row">
										<label for="wplc-bg-url"><?php _e('Background Image', 'wplc'); ?>:</label>
									</th>
									<td>
										<input type="text" name="wplc_options[bg_url]" value="<?php echo wplc_escape_attr( $wplc_options['bg_url'] ); ?>" id="wplc-bg-url" class="regular-text wplc-bg-url wplc-img-upload-input" />
										<input type="button" name="wplc_bg_url_btn" id="wplc-bg-url-btn" class="button-secondary wplc-bg-url-btn wplc-image-upload" value="<?php _e( 'Upload Image', 'wplc'); ?>" data-uploader-title="<?php _e('Choose Background', 'wplc'); ?>" data-uploader-button-text="<?php _e('Insert Background', 'wplc'); ?>" /> <input type="button" name="wplc_bg_url_clear" id="wplc-bg-url-clear" class="button button-secondary wplc-image-clear" value="<?php _e( 'Clear', 'wplc'); ?>" /> <br />
										<span class="description"><?php _e( 'Upload your custom background for login page.', 'wplc' ); ?></span>
										<?php
											$bg_url = '';
											if( isset( $wplc_options['bg_url'] ) && !empty( $wplc_options['bg_url'] ) ) { 
												$bg_url = '<img src="'.$wplc_options['bg_url'].'" alt="" />';
											}
										?>
										<div class="wplc-img-view"><?php echo $bg_url; ?></div>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="wplc-bgcolor"><?php _e('Background Color', 'wplc'); ?>:</label>
									</th>
									<td>
										<?php if( $wp_version >= 3.5 ) { ?>
											<input type="text" name="wplc_options[bg_color]" value="<?php echo $wplc_options['bg_color']; ?>" id="wplc-bgcolor" class="wplc-color-box" /><br/>
										<?php } else { ?>
											<div style='position:relative;'>
												<input type='text' name="wplc_options[bg_color]" value="<?php echo $wplc_options['bg_color']; ?>" class="wplc-color-box-farbtastic-inp" data-default-color="" />
												<input type="button" class="wplc-color-box-farbtastic button button-secondary" value="<?php _e('Select Color', 'wplc'); ?>" />
												<div class="colorpicker" style="background-color: #666; z-index:100; position:absolute; display:none;"></div>
											</div>
										<?php } ?>
											<span class="description"><?php _e('Select login screen background color.', 'wplc'); ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="wplc-bg-pos"><?php _e('Background Position', 'wplc'); ?>:</label>
									</th>
									<td>
										<select name="wplc_options[bg_pos]" class="wplc-bg-pos" id="wplc-bg-pos">
										<option value=""><?php _e('Select Background Position', 'wplc'); ?></option>
										<?php foreach ($bg_position_arr as $bg_pos_key => $bg_position_val) { ?>
											<option value="<?php echo $bg_pos_key; ?>" <?php selected( $wplc_options['bg_pos'], $bg_pos_key ); ?>><?php echo $bg_position_val; ?></option>
										<?php } ?>
										</select><br/>
										<span class="description"><?php _e('Select login background image position.'); ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="wplc-bg-repeat"><?php _e('Background Repeat', 'wplc'); ?>:</label>
									</th>
									<td>
										<select name="wplc_options[bg_repeat]" class="wplc-bg-repeat" id="wplc-bg-repeat">
										<?php foreach ($bg_repeat_arr as $bg_repeat_key => $bg_repeat_val) { ?>
											<option value="<?php echo $bg_repeat_key; ?>" <?php selected( $wplc_options['bg_repeat'], $bg_repeat_key ); ?>><?php echo $bg_repeat_val; ?></option>
										<?php } ?>
										</select><br/>
										<span class="description"><?php _e('Select login background image repeatation.'); ?></span>
									</td>
								</tr>
								<tr>
									<td colspan="2" valign="top" scope="row">
										<input type="submit" id="wplc-settings-submit" name="wplc-settings-submit" class="button button-primary right" value="<?php _e('Save Changes','wplc');?>" />
									</td>
								</tr>
							</tbody>
						 </table>
					</div><!-- .inside -->
				</div><!-- #wplc-bg-settings -->
			</div><!-- .meta-box-sortables ui-sortable -->
		</div><!-- .metabox-holder -->
	</div><!-- #wplc-bg-settings-wrp -->
	<!-- Background Settings Ends -->


	<!-- Login Form Settings Start -->
	<div id="wplc-login-form-settings-wrp" class="post-box-container wplc-login-form-settings">
		<div class="metabox-holder">
			<div class="meta-box-sortables ui-sortable">
				<div id="wplc-login-form-settings" class="postbox">

					<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'Login Form Settings', 'wplc' ); ?></span>
						</h3>
						
						<div class="inside">
						
						<table class="form-table wplc-login-form-settings-tbl">
							<tbody>
								<tr>
									<th scope="row">
										<label for="wplc-form-width"><?php _e('Login Form Width', 'wplc'); ?>:</label>
									</th>
									<td>
										<input type="text" name="wplc_options[form_width]" value="<?php echo $wplc_options['form_width']; ?>" min="1" class="wplc-form-width" id="wplc-form-width" size="6" /><br/>
										<span class="description"><?php _e('Enter login form width. Leave empty for default. (i.e 400px OR 40%)'); ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="wplc-form-bg-transparent"><?php _e('Transparent Background', 'wplc'); ?>:</label>
									</th>
									<td>
										<input type="checkbox" name="wplc_options[form_bg_transparent]" value="1" class="wplc-form-bg-transparent" id="wplc-form-bg-transparent" <?php checked( $wplc_options['form_bg_transparent'], 1 ); ?> /><br/>
										<span class="description"><?php _e('Check this box if you want to transparent the login form.', 'wplc'); ?></span>
									</td>
								</tr>
								<tr class="wplc-form-bg-sett <?php echo $form_bg_opacity_class; ?>">
									<th scope="row">
										<label for="wplc-login-form-bg-url"><?php _e('Background Image', 'wplc'); ?>:</label>
									</th>
									<td>
										<input type="text" name="wplc_options[form_bg_url]" value="<?php echo wplc_escape_attr( $wplc_options['form_bg_url'] ); ?>" id="wplc-login-form-bg-url" class="regular-text wplc-img-upload-input" />
										<input type="button" name="wplc_login_form_bg_url_btn" id="wplc-login-form-bg-url-btn" class="button-secondary wplc-image-upload wplc-login-form-bg-url-btn" value="<?php _e( 'Upload Image', 'wplc'); ?>" data-uploader-title="<?php _e('Choose Background', 'wplc'); ?>" data-uploader-button-text="<?php _e('Insert Background', 'wplc'); ?>" /> <input type="button" name="wplc_bg_url_clear" id="wplc-login-form-bg-url-clear" class="button button-secondary wplc-image-clear" value="<?php _e( 'Clear', 'wplc'); ?>" /> <br />
										<span class="description"><?php _e( 'Upload your custom background for login form.', 'wplc' ); ?></span>
										<?php
											$form_bg_url = '';
											if( isset( $wplc_options['form_bg_url'] ) && !empty( $wplc_options['form_bg_url'] ) ) { 
												$form_bg_url = '<img src="'.$wplc_options['form_bg_url'].'" alt="" />';
											}
										?>
										<div class="wplc-img-view"><?php echo $form_bg_url; ?></div>
									</td>
								</tr>
								<tr class="wplc-form-bg-sett <?php echo $form_bg_opacity_class; ?>">
									<th scope="row">
										<label for="wplc-login-form-color"><?php _e('Background Color', 'wplc'); ?>:</label>
									</th>
									<td>
										<?php if( $wp_version >= 3.5 ) { ?>
											<input type="text" name="wplc_options[form_bg_color]" value="<?php echo $wplc_options['form_bg_color']; ?>" id="wplc-login-formcolor" class="wplc-color-box" /><br/>
										<?php } else { ?>
											<div style='position:relative;'>
												<input type='text' name="wplc_options[form_bg_color]" value="<?php echo $wplc_options['form_bg_color']; ?>" class="wplc-color-box-farbtastic-inp" data-default-color="" />
												<input type="button" class="wplc-color-box-farbtastic button button-secondary" value="<?php _e('Select Color', 'wplc'); ?>" />
												<div class="colorpicker" style="background-color: #666; z-index:100; position:absolute; display:none;"></div>
											</div>
										<?php } ?>
											<span class="description"><?php _e('Select login form background color.', 'wplc'); ?></span>
									</td>
								</tr>
								<tr class="wplc-form-bg-sett <?php echo $form_bg_opacity_class; ?>">
									<th scope="row">
										<label for="wplc-form-opacity"><?php _e('Background Opacity', 'wplc'); ?>:</label>
									</th>
									<td>
										<input type="number" name="wplc_options[form_opacity]" value="<?php echo $wplc_options['form_opacity']; ?>" min="0" max="1" step="0.01" class="wplc-form-opacity" id="wplc-form-opacity" /><br/>
										<span class="description"><?php _e('Enter login form opacity.'); ?></span>
									</td>
								</tr>
								<tr class="wplc-form-bg-sett <?php echo $form_bg_opacity_class; ?>">
									<th scope="row">
										<label for="wplc-form-bg-pos"><?php _e('Background Position', 'wplc'); ?>:</label>
									</th>
									<td>
										<select name="wplc_options[form_bg_pos]" class="wplc-form-bg-pos" id="wplc-form-bg-pos">
										<option value=""><?php _e('Select Background Position', 'wplc'); ?></option>
										<?php foreach ($bg_position_arr as $bg_pos_key => $bg_position_val) { ?>
											<option value="<?php echo $bg_pos_key; ?>" <?php selected( $wplc_options['form_bg_pos'], $bg_pos_key ); ?> ><?php echo $bg_position_val; ?></option>
										<?php } ?>
										</select><br/>
										<span class="description"><?php _e('Select login form background image position.'); ?></span>
									</td>
								</tr>
								<tr class="wplc-form-bg-sett <?php echo $form_bg_opacity_class; ?>">
									<th scope="row">
										<label for="wplc-form-bg-repeat"><?php _e('Background Repeat', 'wplc'); ?>:</label>
									</th>
									<td>
										<select name="wplc_options[form_bg_repeat]" class="wplc-form-bg-repeat" id="wplc-form-bg-repeat">
										<?php foreach ($bg_repeat_arr as $bg_repeat_key => $bg_repeat_val) { ?>
											<option value="<?php echo $bg_repeat_key; ?>" <?php selected( $wplc_options['form_bg_repeat'], $bg_repeat_key ); ?> ><?php echo $bg_repeat_val; ?></option>
										<?php } ?>
										</select><br/>
										<span class="description"><?php _e('Select login form background image repeatation.'); ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="wplc-form-border-width"><?php _e('Border Width', 'wplc'); ?>:</label>
									</th>
									<td>
										<input type="number" name="wplc_options[form_border_width]" value="<?php echo $wplc_options['form_border_width']; ?>" class="wplc-form-border-width" id="wplc-form-border-width" min="0" /><br/>
										<span class="description"><?php _e('Enter login form border width. Leave blank for default.'); ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="wplc-form-border-radius"><?php _e('Border Radius', 'wplc'); ?>:</label>
									</th>
									<td>
										<input type="number" name="wplc_options[form_border_radius]" value="<?php echo $wplc_options['form_border_radius']; ?>" class="wplc-form-border-radius" id="wplc-form-border-radius" min="0" /><br/>
										<span class="description"><?php _e('Enter login form border radius. Leave blank for default.'); ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="wplc-login-form-border-color"><?php _e('Border Color', 'wplc'); ?>:</label>
									</th>
									<td>
										<?php if( $wp_version >= 3.5 ) { ?>
											<input type="text" value="<?php echo $wplc_options['form_border_color']; ?>" id="wplc-login-form-border-color" name="wplc_options[form_border_color]" class="wplc-color-box" /><br/>
										<?php } else { ?>
											<div style='position:relative;'>
												<input type='text' name="wplc_options[form_border_color]" value="<?php echo $wplc_options['form_border_color']; ?>" class="wplc-color-box-farbtastic-inp" data-default-color="" />
												<input type="button" class="wplc-color-box-farbtastic button button-secondary" value="<?php _e('Select Color', 'wplc'); ?>" />
												<div class="colorpicker" style="background-color: #666; z-index:100; position:absolute; display:none;"></div>
											</div>
										<?php } ?>
											<span class="description"><?php _e('Select login form border color.', 'wplc'); ?></span>
									</td>
								</tr>
								<tr>
									<th colspan="2">
										<div class="wplc-sub-sett-title"><?php _e('Form Label Settings', 'wplc'); ?></div>
									</th>
								</tr>
								<tr>
									<th scope="row">
										<label for="wplc-login-form-label-color"><?php _e('Form Label Color', 'wplc'); ?>:</label>
									</th>
									<td>
										<?php if( $wp_version >= 3.5 ) { ?>
											<input type="text" value="<?php echo $wplc_options['form_label_color']; ?>" id="wplc-login-form-label-color" name="wplc_options[form_label_color]" class="wplc-color-box" /><br/>
										<?php } else { ?>
											<div style='position:relative;'>
												<input type='text' name="wplc_options[form_label_color]" value="<?php echo $wplc_options['form_label_color']; ?>" class="wplc-color-box-farbtastic-inp" data-default-color="" />
												<input type="button" class="wplc-color-box-farbtastic button button-secondary" value="<?php _e('Select Color', 'wplc'); ?>" />
												<div class="colorpicker" style="background-color: #666; z-index:100; position:absolute; display:none;"></div>
											</div>
										<?php } ?>
											<span class="description"><?php _e('Select login form label color.', 'wplc'); ?></span>
									</td>
								</tr>
								<tr>
									<th colspan="2">
										<div class="wplc-sub-sett-title"><?php _e('Form Input Field Settings', 'wplc'); ?></div>
									</th>
								</tr>
								<tr>
									<th scope="row">
										<label for="wplc-form-inp-border-width"><?php _e('Input Field Border Width', 'wplc'); ?>:</label>
									</th>
									<td>
										<input type="number" name="wplc_options[form_inp_border_width]" value="<?php echo $wplc_options['form_inp_border_width']; ?>" class="wplc-form-inp-border-width" id="wplc-form-inp-border-width" min="0" /><br/>
										<span class="description"><?php _e('Enter login form input field border width. Leave blank for default.'); ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="wplc-form-inp-border-radius"><?php _e('Input Field Border Radius', 'wplc'); ?>:</label>
									</th>
									<td>
										<input type="number" name="wplc_options[form_inp_border_radius]" value="<?php echo $wplc_options['form_inp_border_radius']; ?>" class="wplc-form-inp-border-radius" id="wplc-form-inp-border-radius" min="0" /><br/>
										<span class="description"><?php _e('Enter login form input field border radius. Leave blank for default.'); ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="wplc-form-inp-border-color"><?php _e('Input Field Border Color', 'wplc'); ?>:</label>
									</th>
									<td>
										<?php if( $wp_version >= 3.5 ) { ?>
											<input type="text" name="wplc_options[form_inp_border_color]" value="<?php echo $wplc_options['form_inp_border_color']; ?>" id="wplc-form-inp-border-color" class="wplc-color-box wplc-form-inp-border-color" /><br/>
										<?php } else { ?>
											<div style='position:relative;'>
												<input type='text' name="wplc_options[form_inp_border_color]" value="<?php echo $wplc_options['form_inp_border_color']; ?>" class="wplc-form-inp-border-color wplc-color-box-farbtastic-inp" data-default-color="" />
												<input type="button" class="wplc-color-box-farbtastic button button-secondary" value="<?php _e('Select Color', 'wplc'); ?>" />
												<div class="colorpicker" style="background-color: #666; z-index:100; position:absolute; display:none;"></div>
											</div>
										<?php } ?>
											<span class="description"><?php _e('Select Input field border color.', 'wplc'); ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="wplc-form-inp-font-color"><?php _e('Input Field Font Color', 'wplc'); ?>:</label>
									</th>
									<td>
										<?php if( $wp_version >= 3.5 ) { ?>
											<input type="text" name="wplc_options[form_inp_font_color]" value="<?php echo $wplc_options['form_inp_font_color']; ?>" id="wplc-form-inp-font-color" class="wplc-color-box wplc-form-inp-font-color" /><br/>
										<?php } else { ?>
											<div style='position:relative;'>
												<input type='text' name="wplc_options[form_inp_font_color]" value="<?php echo $wplc_options['form_inp_font_color']; ?>" class="wplc-form-inp-font-color wplc-color-box-farbtastic-inp" data-default-color="" />
												<input type="button" class="wplc-color-box-farbtastic button button-secondary" value="<?php _e('Select Color', 'wplc'); ?>" />
												<div class="colorpicker" style="background-color: #666; z-index:100; position:absolute; display:none;"></div>
											</div>
										<?php } ?>
											<span class="description"><?php _e('Select Input field font color.', 'wplc'); ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="wplc-form-inp-transparent"><?php _e('Input Field Transparent Background', 'wplc'); ?>:</label>
									</th>
									<td>
										<input type="checkbox" name="wplc_options[form_inp_transparent]" value="1" class="wplc-form-inp-transparent" id="wplc-form-inp-transparent" <?php checked( $wplc_options['form_inp_transparent'], 1 ); ?> /><br/>
										<span class="description"><?php _e('Check this box if you want to transparent the input field of login form.', 'wplc'); ?></span>
									</td>
								</tr>
								<tr class="wplc-form-inp-bg-sett <?php echo $form_inp_bg_sett_class; ?>">
									<th scope="row">
										<label for="wplc-form-inp-bg-color"><?php _e('Input Field Background Color', 'wplc'); ?>:</label>
									</th>
									<td>
										<?php if( $wp_version >= 3.5 ) { ?>
											<input type="text" name="wplc_options[form_inp_bg_color]" value="<?php echo $wplc_options['form_inp_bg_color']; ?>" id="wplc-form-inp-bg-color" class="wplc-color-box wplc-form-inp-bg-color" /><br/>
										<?php } else { ?>
											<div style='position:relative;'>
												<input type='text' name="wplc_options[form_inp_bg_color]" value="<?php echo $wplc_options['form_inp_bg_color']; ?>" class="wplc-form-inp-bg-color wplc-color-box-farbtastic-inp" data-default-color="" />
												<input type="button" class="wplc-color-box-farbtastic button button-secondary" value="<?php _e('Select Color', 'wplc'); ?>" />
												<div class="colorpicker" style="background-color: #666; z-index:100; position:absolute; display:none;"></div>
											</div>
										<?php } ?>
											<span class="description"><?php _e('Select Input field background color.', 'wplc'); ?></span>
									</td>
								</tr>
								<tr>
									<th colspan="2">
										<div class="wplc-sub-sett-title"><?php _e('Form Button Settings', 'wplc'); ?></div>
									</th>
								</tr>
								<tr>
									<th scope="row">
										<label for="wplc-form-btn-color"><?php _e('Button Color', 'wplc'); ?>:</label>
									</th>
									<td>
										<?php if( $wp_version >= 3.5 ) { ?>
											<input type="text" name="wplc_options[form_btn_color]" value="<?php echo $wplc_options['form_btn_color']; ?>" id="wplc-form-btn-color" class="wplc-color-box wplc-form-btn-color" /><br/>
										<?php } else { ?>
											<div style='position:relative;'>
												<input type='text' name="wplc_options[form_btn_color]" value="<?php echo $wplc_options['form_btn_color']; ?>" class="wplc-form-btn-color wplc-color-box-farbtastic-inp" data-default-color="" />
												<input type="button" class="wplc-color-box-farbtastic button button-secondary" value="<?php _e('Select Color', 'wplc'); ?>" />
												<div class="colorpicker" style="background-color: #666; z-index:100; position:absolute; display:none;"></div>
											</div>
										<?php } ?>
											<span class="description"><?php _e('Select button color for login form.', 'wplc'); ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="wplc-form-btn-font-color"><?php _e('Button Font Color', 'wplc'); ?>:</label>
									</th>
									<td>
										<?php if( $wp_version >= 3.5 ) { ?>
											<input type="text" name="wplc_options[form_btn_font_color]" value="<?php echo $wplc_options['form_btn_font_color']; ?>" id="wplc-form-btn-font-color" class="wplc-color-box wplc-form-btn-font-color" /><br/>
										<?php } else { ?>
											<div style='position:relative;'>
												<input type='text' name="wplc_options[form_btn_font_color]" value="<?php echo $wplc_options['form_btn_font_color']; ?>" class="wplc-form-btn-font-color wplc-color-box-farbtastic-inp" data-default-color="" />
												<input type="button" class="wplc-color-box-farbtastic button button-secondary" value="<?php _e('Select Color', 'wplc'); ?>" />
												<div class="colorpicker" style="background-color: #666; z-index:100; position:absolute; display:none;"></div>
											</div>
										<?php } ?>
											<span class="description"><?php _e('Select button font color for login form.', 'wplc'); ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="wplc-form-btn-hcolor"><?php _e('Button Hover Color', 'wplc'); ?>:</label>
									</th>
									<td>
										<?php if( $wp_version >= 3.5 ) { ?>
											<input type="text" name="wplc_options[form_btn_hcolor]" value="<?php echo $wplc_options['form_btn_hcolor']; ?>" id="wplc-form-btn-hcolor" class="wplc-color-box wplc-form-btn-hcolor" /><br/>
										<?php } else { ?>
											<div style='position:relative;'>
												<input type='text' name="wplc_options[form_btn_hcolor]" value="<?php echo $wplc_options['form_btn_hcolor']; ?>" class="wplc-form-btn-hcolor wplc-color-box-farbtastic-inp" data-default-color="" />
												<input type="button" class="wplc-color-box-farbtastic button button-secondary" value="<?php _e('Select Color', 'wplc'); ?>" />
												<div class="colorpicker" style="background-color: #666; z-index:100; position:absolute; display:none;"></div>
											</div>
										<?php } ?>
											<span class="description"><?php _e('Select button hover color for login form.', 'wplc'); ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="wplc-form-btn-font-hcolor"><?php _e('Button Hover Font Color', 'wplc'); ?>:</label>
									</th>
									<td>
										<?php if( $wp_version >= 3.5 ) { ?>
											<input type="text" name="wplc_options[form_btn_font_hcolor]" value="<?php echo $wplc_options['form_btn_font_hcolor']; ?>" id="wplc-form-btn-font-hcolor" class="wplc-color-box wplc-form-btn-font-hcolor" /><br/>
										<?php } else { ?>
											<div style='position:relative;'>
												<input type='text' name="wplc_options[form_btn_font_hcolor]" value="<?php echo $wplc_options['form_btn_font_hcolor']; ?>" class="wplc-form-btn-font-hcolor wplc-color-box-farbtastic-inp" data-default-color="" />
												<input type="button" class="wplc-color-box-farbtastic button button-secondary" value="<?php _e('Select Color', 'wplc'); ?>" />
												<div class="colorpicker" style="background-color: #666; z-index:100; position:absolute; display:none;"></div>
											</div>
										<?php } ?>
											<span class="description"><?php _e('Select button hover font color for login form.', 'wplc'); ?></span>
									</td>
								</tr>
								<tr>
									<th colspan="2">
										<div class="wplc-sub-sett-title"><?php _e('Link Below Form Settings', 'wplc'); ?></div>
									</th>
								</tr>
								<tr>
									<th scope="row">
										<label for="wplc-below-form-link-color"><?php _e('Link Color', 'wplc'); ?>:</label>
									</th>
									<td>
										<?php if( $wp_version >= 3.5 ) { ?>
											<input type="text" name="wplc_options[below_form_link_color]" value="<?php echo $wplc_options['below_form_link_color']; ?>" id="wplc-below-form-link-color" class="wplc-color-box wplc-below-form-link-color" /><br/>
										<?php } else { ?>
											<div style='position:relative;'>
												<input type='text' name="wplc_options[below_form_link_color]" value="<?php echo $wplc_options['below_form_link_color']; ?>" class="wplc-below-form-link-color wplc-color-box-farbtastic-inp" data-default-color="" />
												<input type="button" class="wplc-color-box-farbtastic button button-secondary" value="<?php _e('Select Color', 'wplc'); ?>" />
												<div class="colorpicker" style="background-color: #666; z-index:100; position:absolute; display:none;"></div>
											</div>
										<?php } ?>
											<span class="description"><?php _e('Select link color which are below login form.', 'wplc'); ?></span>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="wplc-below-form-link-hcolor"><?php _e('Link Hover Color', 'wplc'); ?>:</label>
									</th>
									<td>
										<?php if( $wp_version >= 3.5 ) { ?>
											<input type="text" name="wplc_options[below_form_link_hcolor]" value="<?php echo $wplc_options['below_form_link_hcolor']; ?>" id="wplc-below-form-link-hcolor" class="wplc-color-box wplc-below-form-link-hcolor" /><br/>
										<?php } else { ?>
											<div style='position:relative;'>
												<input type='text' name="wplc_options[below_form_link_hcolor]" value="<?php echo $wplc_options['below_form_link_hcolor']; ?>" class="wplc-below-form-link-hcolor wplc-color-box-farbtastic-inp" data-default-color="" />
												<input type="button" class="wplc-color-box-farbtastic button button-secondary" value="<?php _e('Select Color', 'wplc'); ?>" />
												<div class="colorpicker" style="background-color: #666; z-index:100; position:absolute; display:none;"></div>
											</div>
										<?php } ?>
											<span class="description"><?php _e('Select link hover color which are below login form.', 'wplc'); ?></span>
									</td>
								</tr>
								<tr>
									<td colspan="2" valign="top" scope="row">
										<input type="submit" id="wplc-settings-submit" name="wplc-settings-submit" class="button button-primary right" value="<?php _e('Save Changes','wplc');?>" />
									</td>
								</tr>
							</tbody>
						 </table>
					</div><!-- .inside -->
				</div><!-- #wplc-login-form-settings -->
			</div><!-- .meta-box-sortables ui-sortable -->
		</div><!-- .metabox-holder -->
	</div><!-- #wplc-login-form-settings-wrp -->
	<!-- Login Form Settings Ends -->


	<!-- Login Form Custom CSS Settings Start -->
	<div id="wplc-login-form-custom-css-wrp" class="post-box-container wplc-login-form-custom-css">
		<div class="metabox-holder">
			<div class="meta-box-sortables ui-sortable">
				<div id="wplc-login-form-custom-css" class="postbox">

					<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'Custom CSS', 'wplc' ); ?></span>
						</h3>
						
						<div class="inside">
						
						<table class="form-table wplc-login-form-custom-css-tbl">
							<tbody>
								<tr>
									<th scope="row">
										<label for="wplc-custom-css"><?php _e('Custom CSS', 'wplc'); ?>:</label>
									</th>
									<td>
										<textarea name="wplc_options[custom_css]" class="wplc-custom-css large-text" id="wplc-custom-css" rows="12"><?php echo wplc_escape_attr($wplc_options['custom_css']); ?></textarea><br/>
										<span class="description"><?php _e('Enter custom css for login screen.') ?></span>
									</td>
								</tr>
								<tr>
									<td colspan="2" valign="top" scope="row">
										<input type="submit" id="wplc-settings-submit" name="wplc-settings-submit" class="button button-primary right" value="<?php _e('Save Changes','wplc');?>" />
									</td>
								</tr>
							</tbody>
						 </table>
					</div><!-- .inside -->
				</div><!-- #wplc-login-form-custom-css -->
			</div><!-- .meta-box-sortables ui-sortable -->
		</div><!-- .metabox-holder -->
	</div><!-- #wplc-login-form-custom-css-wrp -->
	<!-- Login Form Custom CSS Settings Ends -->

</form><!-- end .wplc-settings-form -->

</div><!-- end .wplc-settings -->
<?php
/**
 * Public Class
 *
 * Handles the public side functionality of plugin
 *
 * @package WP Login Customizer
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Wplc_Public {
	
	function __construct() {

		// Filter to change the login logo URL
		add_filter( 'login_headerurl', array( $this, 'wplc_login_logo_url') );

		// Filter to chnage the login logo title
		add_filter( 'login_headertitle', array($this, 'wplc_login_logo_title') );

		// Action to add custom style on login page
		add_action('login_head', array($this, 'wplc_add_login_style') );

		// Action to add custom style on login page
		add_action('login_head', array($this, 'wplc_add_custom_login_style'), 12 );
	}

	/**
	 * Function to change the login logo URL
	 * 
	 * @package WP Login Customizer
	 * @since 1.0.0
	 */
	function wplc_login_logo_url( $url ){

		global $wplc_options;

		if( !empty($wplc_options['enable_customizer']) ) {

			if( $wplc_options['logo_link'] == 'site_url' ){
				$url = home_url();
			} elseif ($wplc_options['logo_link'] == 'custom') {
				$url = !empty($wplc_options['custom_logo_url']) ? $wplc_options['custom_logo_url'] : '';
			}
		}

		return $url;
	}

	/**
	 * Function to change the login logo title
	 * 
	 * @package WP Login Customizer
	 * @since 1.0.0
	 */
	function wplc_login_logo_title( $login_header_title ){

		global $wplc_options;

		if( !empty($wplc_options['enable_customizer']) && !empty($wplc_options['logo_title']) ) {
			$login_header_title = $wplc_options['logo_title'];
		}

		return $login_header_title;
	}

	/**
	 * Function to add custom user added css
	 * 
	 * @package WP Login Customizer
	 * @since 1.0.0
	 */
	function wplc_add_custom_login_style() {

		global $wplc_options;

		if( !empty($wplc_options['enable_customizer']) && !empty($wplc_options['custom_css']) ) {
			
			$css = '';
			$css .= '<style type="text/css">';
			$css .= $wplc_options['custom_css'];
			$css .= '</style>';

			echo $css;
		}
	}

	/**
	 * Function to add custom css on login page
	 * 
	 * @package WP Login Customizer
	 * @since 1.0.0
	 */
	function wplc_add_login_style() {

		global $wplc_options;

		if( !empty($wplc_options['enable_customizer']) ) {

			$opacity = isset($wplc_options['form_opacity']) ? $wplc_options['form_opacity'] : 1;

			$css = '';
			$css .= '<style type="text/css">';

			// Login Logo CSS
			$css .= '.login h1 a{';
			if( !empty($wplc_options['logo_url']) ) {
				$css .= "background-image: none, url('{$wplc_options['logo_url']}');";
			}
			if( !empty($wplc_options['logo_width']) ) {
				$css .= "width:{$wplc_options['logo_width']}; background-size:{$wplc_options['logo_width']} auto;";
			}
			if( !empty($wplc_options['logo_height']) ) {
				$css .= "height:{$wplc_options['logo_height']};";
			}
			if( !empty($wplc_options['logo_bg_pos']) ) {
				$css .= "background-position:{$wplc_options['logo_bg_pos']};";
			}
			$css .= '}';

			// Login Page CSS
			$css .= 'body, html{';
			if( !empty($wplc_options['bg_url']) ){
				$css .= "background: url('{$wplc_options['bg_url']}');";
			}
			if( !empty($wplc_options['bg_pos']) ){
				$css .= "background-position:{$wplc_options['bg_pos']};";
			}
			if( !empty($wplc_options['bg_repeat']) ){
				$css .= "background-repeat:{$wplc_options['bg_repeat']};";
			}
			if( !empty($wplc_options['bg_color']) ){
				$css .= "background-color:{$wplc_options['bg_color']};";
			}
			$css .= '}';

			// Login Form CSS
			$css .= '.login form{';

			if( empty($wplc_options['form_bg_transparent']) ) {
				if( !empty($wplc_options['form_bg_url']) ) {
					$css .= "background: url('{$wplc_options['form_bg_url']}');";
				}
				if( !empty($wplc_options['form_bg_pos']) ) {
					$css .= "background-position:{$wplc_options['form_bg_pos']};";
				}
				if( !empty($wplc_options['form_bg_repeat']) ) {
					$css .= "background-repeat:{$wplc_options['form_bg_repeat']};";
				}
				if( !empty($wplc_options['form_bg_color']) ) {
					$css .= "background-color:rgba( ".wplc_hex2rgb($wplc_options['form_bg_color']).",{$opacity});";
				}

			} else{
				if( !empty($wplc_options['form_bg_transparent']) ) {
					$css .= "background:transparent; background-color:transparent; box-shadow:none;";
				}
			}

			if( !empty($wplc_options['form_border_width']) ) {
				$css .= "border-width:{$wplc_options['form_border_width']}px; border-style:solid;";
			}
			if( !empty($wplc_options['form_border_color']) ) {
				$css .= "border-color:{$wplc_options['form_border_color']};";
			}
			if( !empty($wplc_options['form_border_radius']) ) {
				$css .= "border-radius:{$wplc_options['form_border_radius']}px;";
			}
			$css .= '}';

			// Login Form Width CSS
			$css .= '#login{';
			if( !empty($wplc_options['form_width']) ) {
				$css .= "max-width:{$wplc_options['form_width']}; width:100%;";
			}
			$css .= '}';

			// Form Label CSS
			$css .= '.login label{';
			if( !empty($wplc_options['form_label_color']) ) {
				$css .= "color:{$wplc_options['form_label_color']};";
			}
			$css .= '}';

			// Below Form Link CSS
			$css .= '.login #backtoblog a, .login #nav a{';
			if( !empty($wplc_options['below_form_link_color']) ) {
				$css .= "color:{$wplc_options['below_form_link_color']};";
			}
			$css .= '}';

			// Below Form Link Hover CSS
			$css .= '.login #backtoblog a:hover, .login #nav a:hover{';
			if( !empty($wplc_options['below_form_link_hcolor']) ) {
				$css .= "color:{$wplc_options['below_form_link_hcolor']};";
			}
			$css .= '}';

			// Form Button CSS
			$css .= '.wp-core-ui .button-primary{';
			if( !empty($wplc_options['form_btn_color']) ) {
				$css .= "background:{$wplc_options['form_btn_color']}; border-color:{$wplc_options['form_btn_color']}; box-shadow:none; text-shadow:none;";
			}
			if( !empty($wplc_options['form_btn_font_color']) ) {
				$css .= "color:{$wplc_options['form_btn_font_color']};";
			}
			$css .= '}';

			// Form Button Hover CSS
			$css .= '.wp-core-ui .button-primary.hover, .wp-core-ui .button-primary:focus, .wp-core-ui .button-primary:hover{';
			if( !empty($wplc_options['form_btn_hcolor']) ) {
				$css .= "background:{$wplc_options['form_btn_hcolor']}; border-color:{$wplc_options['form_btn_hcolor']};";
			}
			if( !empty($wplc_options['form_btn_font_hcolor']) ) {
				$css .= "color:{$wplc_options['form_btn_font_hcolor']};";
			}
			$css .= '}';

			// Form Field CSS
			$css .= '.login input[type="text"], .login input[type="search"], .login input[type="radio"], .login input[type="url"], .login input[type="password"], .login input[type="checkbox"], .login input[type="email"], .login select, .login textarea{';
			
			// If input field not transparent
			if( empty($wplc_options['form_inp_transparent']) ) {
				
				if( !empty($wplc_options['form_inp_bg_color']) ) {
					$css .= "background:{$wplc_options['form_inp_bg_color']};";
				}

			} else {
				$css .= "background:transparent; background-color:transparent; box-shadow:none;";
			}

			if( ($wplc_options['form_inp_border_width']) != '' ) {
				$css .= "border-width:{$wplc_options['form_inp_border_width']}px;";
			}
			if( !empty($wplc_options['form_inp_border_radius']) ) {
				$css .= "border-radius:{$wplc_options['form_inp_border_radius']}px;";
			}
			if( !empty($wplc_options['form_inp_border_color']) ) {
				$css .= "border-color:{$wplc_options['form_inp_border_color']};";
			}
			if( !empty($wplc_options['form_inp_font_color']) ) {
				$css .= "color:{$wplc_options['form_inp_font_color']};";
			}
			$css .= '}';

			// Form Field Hover CSS
			$css .= 'input[type="text"]:focus, input[type="search"]:focus, input[type="radio"]:focus, input[type="url"]:focus, input[type="password"]:focus, input[type="checkbox"]:focus, input[type="email"]:focus, select:focus, textarea:focus{';
			if( !empty($wplc_options['form_inp_border_color']) ) {
				$css .= "border-color:{$wplc_options['form_inp_border_color']}; box-shadow:none;";
			}
			if( !empty($wplc_options['form_inp_font_color']) ) {
				$css .= "color:{$wplc_options['form_inp_font_color']};";
			}
			$css .= '}';

			$css .= '</style>';
			echo $css;

		} // End of main IF
	}
}

$wplc_public = new Wplc_Public();
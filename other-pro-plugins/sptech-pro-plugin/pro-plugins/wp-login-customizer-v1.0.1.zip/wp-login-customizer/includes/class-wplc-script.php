<?php
/**
 * Script Class
 *
 * Handles the script and style functionality of plugin
 *
 * @package WP Login Customizer
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Wplc_Script {
	
	function __construct() {

		// Action to add style in backend
		add_action( 'admin_enqueue_scripts', array($this, 'wplc_admin_style') );

		// Action to add script in backend
		add_action( 'admin_enqueue_scripts', array($this, 'wplc_admin_script') );
	}

	/**
	 * Enqueue admin styles
	 * 
	 * @package WP Login Customizer
	 * @since 1.0.0
	 */
	function wplc_admin_style( $hook ) {

		// Pages array
		$pages_array = array( 'toplevel_page_wplc-settings' );

		// If page is plugin setting page then enqueue script
		if( in_array($hook, $pages_array) ) {

			// Enqueu built in style for color picker
			if( wp_style_is( 'wp-color-picker', 'registered' ) ) { // Since WordPress 3.5
				wp_enqueue_style( 'wp-color-picker' );
			} else {
				wp_enqueue_style( 'farbtastic' );
			}

			// Registring admin script
			wp_register_style( 'wplc-admin-css', WPLC_URL.'assets/css/wplc-admin.css', null, WPLC_VERSION );
			wp_enqueue_style( 'wplc-admin-css' );
		}
	}

	/**
	 * Enqueue admin script
	 * 
	 * @package WP Modal Popup with Cookie Integration
	 * @since 1.0.0
	 */
	function wplc_admin_script( $hook ) {

		global $wp_version;

		$new_ui = $wp_version >= '3.5' ? '1' : '0'; // Check wordpress version for older scripts

		// Pages array
		$pages_array = array( 'toplevel_page_wplc-settings' );

		// If page is plugin setting page then enqueue script
		if( in_array($hook, $pages_array) ) {

			// Enqueu built-in script for color picker
			if( wp_script_is( 'wp-color-picker', 'registered' ) ) { // Since WordPress 3.5
				wp_enqueue_script( 'wp-color-picker' );
			} else {
				wp_enqueue_script( 'farbtastic' );
			}

			// Registring admin script
			wp_register_script( 'wplc-admin-js', WPLC_URL.'assets/js/wplc-admin.js', array('jquery'), WPLC_VERSION, true );
			wp_localize_script( 'wplc-admin-js', 'WplcAdmin', array(
																	'new_ui' =>	$new_ui
																));
			wp_enqueue_script( 'wplc-admin-js' );
			wp_enqueue_media(); // For media uploader
		}
	}
}

$wplc_script = new Wplc_Script();
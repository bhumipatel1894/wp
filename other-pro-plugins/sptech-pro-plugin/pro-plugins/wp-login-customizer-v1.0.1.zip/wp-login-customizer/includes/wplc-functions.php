<?php
/**
 * Functions File
 *
 * @package WP Login Customizer
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Update default settings
 * 
 * @package WP Login Customizer
 * @since 1.0.0
 */
function wplc_default_settings(){
	
	global $wplc_options;
	
	$wplc_options = array(
								'enable_customizer'			=> 0,
								'logo_link'					=> '',
								'custom_logo_url'			=> '',
								'logo_title'				=> '',
								'logo_url'					=> '',
								'logo_width'				=> '',
								'logo_height'				=> '',
								'logo_bg_pos'				=> 'center top',
								'bg_url'					=> '',
								'bg_color'					=> '',
								'bg_pos'					=> '',
								'bg_repeat'					=> 'no-repeat',
								'form_width'				=> '',
								'form_bg_transparent'		=> 0,
								'form_bg_url'				=> '',
								'form_bg_color'				=> '',
								'form_opacity'				=> 1,
								'form_bg_pos'				=> '',
								'form_bg_repeat'			=> 'no-repeat',
								'form_border_width'			=> '',
								'form_border_color'			=> '',
								'form_border_radius'		=> '',
								'form_label_color'			=> '',
								'form_inp_border_width'		=> '',
								'form_inp_border_radius'	=> '',
								'form_inp_border_color'		=> '',
								'form_inp_transparent'		=> '',
								'form_inp_bg_color'			=> '',
								'form_inp_font_color'		=> '',
								'form_btn_color'			=> '',
								'form_btn_font_color'		=> '',
								'form_btn_hcolor'			=> '',
								'form_btn_font_hcolor'		=> '',
								'below_form_link_color'		=> '',
								'below_form_link_hcolor'	=> '',
								'custom_css'				=> '',
							);
	
	$default_options = apply_filters('wplc_options_default_values', $wplc_options );
	
	// Update default options
	update_option( 'wplc_options', $default_options );

	// Overwrite global variable when option is update
	$wplc_options = wplc_get_settings();
}

/**
 * Get Settings From Option Page
 * 
 * Handles to return all settings value
 * 
 * @package WP Login Customizer
 * @since 1.0.0
 */
function wplc_get_settings() {
	
	$options = get_option('wplc_options');
	
	$settings = is_array($options) 	? $options : array();
	
	return $settings;
}

/**
 * Escape Tags & Slashes
 *
 * Handles escapping the slashes and tags
 *
 * @package  WP Login Customizer
 * @since 1.0.0
 */
function wplc_escape_attr($data) {
	return esc_attr( stripslashes($data) );
}
	
/**
 * Strip Slashes From Array
 *
 * @package WP Login Customizer
 * @since 1.0.0
 */
function wplc_slashes_deep($data = array(), $flag = false) {
	
	if($flag != true) {
		$data = wplc_nohtml_kses($data);
	}
	$data = stripslashes_deep($data);
	return $data;
}

/**
 * Strip Html Tags 
 * 
 * It will sanitize text input (strip html tags, and escape characters)
 * 
 * @package WP Login Customizer
 * @since 1.0.0
 */
function wplc_nohtml_kses($data = array()) {
	
	if ( is_array($data) ) {
		
		$data = array_map('wplc_nohtml_kses', $data);
		
	} elseif ( is_string( $data ) ) {
		
		$data = wp_filter_nohtml_kses($data);
	}
	
	return $data;
}

/**
 * Convert color hex value to rgb format
 * 
 * @package WP Login Customizer
 * @since 1.0.0
 */
function wplc_hex2rgb( $hex = '', $format = 'string' ) {

	if( empty($hex) ) return false;

	$hex = str_replace("#", "", $hex);

	if(strlen($hex) == 3) {
		$r = hexdec(substr($hex,0,1).substr($hex,0,1));
		$g = hexdec(substr($hex,1,1).substr($hex,1,1));
		$b = hexdec(substr($hex,2,1).substr($hex,2,1));
	} else {
		$r = hexdec(substr($hex,0,2));
		$g = hexdec(substr($hex,2,2));
		$b = hexdec(substr($hex,4,2));
	}

	$rgb = array($r, $g, $b);

	if( $format == 'string' ) {
		$rgb = implode(",", $rgb);
	}

	return $rgb;
}
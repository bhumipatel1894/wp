=== WP Login Customizer ===
Contributors: wponlinesupport, anoopranawat
Tags: login, WordPress Login, Login Customizer, Login Screen Customizer, Login Screen
Requires at least: 3.1
Tested up to: 4.6.1

A quick, easy way to customize wordpress login screen.

== Description ==
WP Login Customizer allows you to customize the login screen the way you want.


= Why Use WP Login Customizer Plugin? =
* WP Login Customizer Plugin is made with WordPress standard and comes with easy setup.
* This plugin helps you to customize the login screen without any coding knowledge.


== Installation ==

1. Upload the 'WP Login Customizer' Plugin folder to the '/wp-content/plugins/' directory.
2. Activate the "WP Login Customizer" Plugin list plugin through the 'Plugins' menu in WordPress.
3. Goto 'Login Customizer' from the admin menu and customize your login, registration screen as you want.


== Changelog ==

= 1.0.1 (12, Sep 2016) =
* [*] Removed plugin license page from plugin section and added in 'Login Customizer' menu.
* [*] Updated plugin license page.
* Added SSL to https://www.wponlinesupport.com/ for secure updates.

= 1.0 =
* Initial release.


== Upgrade Notice ==

= 1.0.1 (12, Sep 2016) =
* [*] Removed plugin license page from plugin section and added in 'Login Customizer' menu.
* [*] Updated plugin license page.
* Added SSL to https://www.wponlinesupport.com/ for secure updates.

= 1.0 =
* Initial release.
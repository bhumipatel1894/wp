<?php
/**
 * Plugin Name: WP Login Customizer
 * Plugin URI: https://www.wponlinesupport.com
 * Description: Customize your login screen.
 * Author: WP Online Support 
 * Version: 1.0.1
 * Author URI: https://www.wponlinesupport.com
 *
 * @package WordPress
 * @author SP Technolab
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Basic plugin definitions
 * 
 * @package WP Login Customizer
 * @since 1.0.0
 */
if( !defined( 'WPLC_VERSION' ) ) {
	define( 'WPLC_VERSION', '1.0.1' );	// Version of plugin
}
if( !defined( 'WPLC_DIR' ) ) {
	define( 'WPLC_DIR', dirname( __FILE__ ) );	// Plugin dir
}
if( !defined( 'WPLC_URL' ) ) {
	define( 'WPLC_URL', plugin_dir_url( __FILE__ ) );	// Plugin url
}
if( !defined( 'WPLC_PLUGIN_BASENAME' ) ) {
	define( 'WPLC_PLUGIN_BASENAME', plugin_basename( __FILE__ ) ); // plugin base name
}

/**
 * Load Text Domain
 * This gets the plugin ready for translation
 * 
 * @package WP Login Customizer
 * @since 1.0.0
 */
function wplc_load_textdomain() {
	load_plugin_textdomain( 'wplc', false, dirname( plugin_basename(__FILE__) ) . '/languages/' );
}

// Action to load plugin text domain
add_action('plugins_loaded', 'wplc_load_textdomain');

/**
 * Activation Hook
 * 
 * Register plugin activation hook.
 * 
 * @package WP Login Customizer
 * @since 1.0.0
 */
register_activation_hook( __FILE__, 'wplc_install' );

/**
 * Deactivation Hook
 * 
 * Register plugin deactivation hook.
 * 
 * @package WP Login Customizer
 * @since 1.0.0
 */
register_deactivation_hook( __FILE__, 'wplc_uninstall');

/**
 * Plugin Activation Function
 * Does the initial setup, sets the default values for the plugin options
 * 
 * @package WP Login Customizer
 * @since 1.0.0
 */
function wplc_install() {

	// Get settings for the plugin
	$wplc_options = get_option( 'wplc_options' );
	
	if( empty( $wplc_options ) ) { // Check plugin version option
		
		// set default settings
		wplc_default_settings();

		// Update plugin version to option
		update_option( 'wplc_plugin_version', '1.0' );
	}
}

/**
 * Plugin Deactivation Function
 * Delete  plugin options
 * 
 * @package WP Login Customizer
 * @since 1.0.0
 */
function wplc_uninstall(){
}

/***** Updater Code Starts *****/
define( 'EDD_WPLC_PRO_STORE_URL', 'https://www.wponlinesupport.com' );
define( 'EDD_WPLC_PRO_ITEM_NAME', 'WP Login Customizer' );

// Plugin Updator Class
if( !class_exists( 'EDD_SL_Plugin_Updater' ) ) {	
	include( dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php' );
}

/**
 * Updater Function
 * 
 * @package WP Login Customizer
 * @since 1.0.0
 */
function edd_sl_wplc_pro_plugin_updater() {
	
	$license_key = trim( get_option( 'edd_wplc_pro_license_key' ) );
	
	$edd_updater = new EDD_SL_Plugin_Updater( EDD_WPLC_PRO_STORE_URL, __FILE__, array(
			'version' 	=> WPLC_VERSION, 			// current version number
			'license' 	=> $license_key, 			// license key (used get_option above to retrieve from DB)
			'item_name' => EDD_WPLC_PRO_ITEM_NAME, 	// name of this plugin
			'author' 	=> 'WP Online Support'  	// author of this plugin
		)
	);
}
add_action( 'admin_init', 'edd_sl_wplc_pro_plugin_updater', 0 );
include( dirname( __FILE__ ) . '/edd-wplc-pro-plugin.php' );
/***** Updater Code Ends *****/

// Global Variables
global $wplc_options;

// Functions file
require_once( WPLC_DIR . '/includes/wplc-functions.php' );
$wplc_options = wplc_get_settings();

// Admin Class File
require_once( WPLC_DIR . '/includes/admin/class-wplc-admin.php' );

// Script Class File
require_once( WPLC_DIR . '/includes/class-wplc-script.php' );

// Public Class File
require_once( WPLC_DIR . '/includes/class-wplc-public.php' );
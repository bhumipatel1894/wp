<?php
/**
 * Public Class
 *
 * Handles the public side functionality of plugin
 *
 * @package WP Responsive Recent Post Slider Pro
 * @since 1.2.7
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Wprpsp_Pro_Public {
	
	function __construct() {
	
	}	
}

$wprpsp_pro_public = new Wprpsp_Pro_Public();
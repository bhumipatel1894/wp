<?php
/**
 * Public Class
 *
 * Handles the public side functionality of plugin
 *
 * @package WP Team Showcase and Slider Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Wp_Tsasp_Public {
	
	function __construct() {

	}
}

$wp_tsasp_public = new Wp_Tsasp_Public();
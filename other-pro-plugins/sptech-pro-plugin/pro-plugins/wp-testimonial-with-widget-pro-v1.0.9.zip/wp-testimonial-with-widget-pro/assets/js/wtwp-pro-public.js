jQuery( document ).ready(function($) {
	
	// Testimonial Slider
	$( '.wtwp-testimonials-slidelist' ).each(function( index ) {

		var slider_id   		= $(this).attr('id');
		var testimonial_conf 	= $.parseJSON( $(this).parent('.wtwp-pro-slider-wrp').find('.wtwp-pro-slider-conf').text() );

		if( typeof(slider_id) != 'undefined' && slider_id != '' ) {
			
			jQuery('#'+slider_id).slick({
				
				dots			: (testimonial_conf.dots) == "true" ? true : false,
				infinite		: (testimonial_conf.loop) == "true" ? true : false,
				arrows			: (testimonial_conf.arrows) == "true" ? true : false,
				speed 			: parseInt(testimonial_conf.speed),
				autoplay 		: (testimonial_conf.autoplay) == "true" ? true : false,						
				autoplaySpeed 	: parseInt(testimonial_conf.autoplay_interval),
				slidesToShow 	: parseInt(testimonial_conf.slides_column),
				slidesToScroll 	: parseInt(testimonial_conf.slides_scroll),
				centerMode 		: (testimonial_conf.center_mode) == "true" ? true : false,
				fade 			: (testimonial_conf.effect) == "true" ? true : false,
				mobileFirst    	: (WtwpPro.is_mobile == 1) 	? true : false,
				rtl             : (testimonial_conf.rtl) == "true" ? true : false,
				responsive 		: [
				{
					breakpoint: 1023,
					settings: {
						slidesToShow: (parseInt(testimonial_conf.slides_column) > 3) ? 3 : parseInt(testimonial_conf.slides_column),
						slidesToScroll: 1
					}
				},
				{
					breakpoint: 767,
					settings: {
						slidesToShow: (parseInt(testimonial_conf.slides_column) > 2) ? 2 : parseInt(testimonial_conf.slides_column),
						slidesToScroll: 1
					}
				},
				{
					breakpoint: 480,
					settings: {
						slidesToShow: 1,
						slidesToScroll: 1
					}
				},
				{
					breakpoint: 319,
					settings: {
						slidesToShow: 1,
						slidesToScroll: 1
					}
				}]
			});
		}
	});

	// Testimonial Widget
	$( '.testimonials-slide-widget' ).each(function( index ) {

		var slider_id   		= $(this).attr('id');
		var testimonial_conf 	= $.parseJSON( $(this).parent('.wtwp-pro-slider-wrp').find('.wtwp-pro-slider-conf').text() );

		if( typeof(slider_id) != 'undefined' && slider_id != '' ) {
			
			jQuery('#'+slider_id).slick({
				
				dots			: (testimonial_conf.dots) == "true" 			? true : false,
				infinite		: (testimonial_conf.loop) == "true" 			? true : false,
				arrows			: (testimonial_conf.arrows) == "true" 			? true : false,
				speed 			: parseInt(testimonial_conf.speed),
				autoplay 		: (testimonial_conf.autoplay) == "true" 		? true : false,						
				autoplaySpeed 	: parseInt(testimonial_conf.autoplay_interval),
				slidesToShow 	: parseInt(testimonial_conf.slides_column),
				slidesToScroll 	: parseInt(testimonial_conf.slides_scroll),
				centerMode 		: (testimonial_conf.center_mode) == "true" 		? true : false,
				mobileFirst    	: (WtwpPro.is_mobile == 1) 						? true : false,
				responsive 		: [{
					breakpoint: 1023,
					settings: {
						slidesToShow: (parseInt(testimonial_conf.slides_column) > 3) ? 3 : parseInt(testimonial_conf.slides_column),
						slidesToScroll: 1
					}
				},{
					breakpoint: 767,
					settings: {
						slidesToShow: (parseInt(testimonial_conf.slides_column) > 2) ? 2 : parseInt(testimonial_conf.slides_column),
						slidesToScroll: 1
					}
				},{
					breakpoint: 480,
					settings: {
						slidesToShow: 1,
						slidesToScroll: 1
					}
				},{
					breakpoint: 319,
					settings: {
						slidesToShow: 1,
						slidesToScroll: 1
					}
				}]
			});
		}
	});

	// Validate testimonial form
	$(document).on("submit", ".wtwp-testimonial-form", function (e) {
		
		var error 		= false;
		var cls_form	= $(this);
		var title		= cls_form.find('.wtwp-tstmnl-title');
		var title_val	= $.trim(title.val());
		var cname		= cls_form.find('.wtwp-tstmnl-cname');
		var cname_val	= $.trim(cname.val());
		var content		= cls_form.find('.wtwp-tstmnl-content');
		var content_val	= $.trim(content.val());
		var captcha		= cls_form.find('.wtwp-tstmnl-captcha');
		var captcha_val	= $.trim(captcha.val());
		var tstmnl_img	= cls_form.find('.wtwp-tstmnl-img');
		var tstmnl_img_val		= tstmnl_img.val();
		var allowedExtensions 	= ['jpg', 'jpeg', 'png', 'gif', 'bmp']; // Allowed file types

		// Removing errors
		cls_form.find('.wtwp-frm-error').remove();
		cls_form.closest('.wtwp-testimonial-form-wrp').find('.wtwp-tstmnl-err').remove();
		cls_form.closest('.wtwp-testimonial-form-wrp').find('.wtwp-tstmnl-succ').remove();

		// Validate title
		if( title_val == '' || title_val == null ) {
			title.after('<span class="wtwp-frm-error">'+WtwpPro.form_error.title+'</span>');
			error = true;
		}

		// Validate client name
		if( cname_val == '' || cname_val == null ){
			cname.after('<span class="wtwp-frm-error">'+WtwpPro.form_error.client_name+'</span>');
			error = true;
		}

		// Validate testimonial content
		if( content_val == '' || content_val == null ){
			content.after('<span class="wtwp-frm-error">'+WtwpPro.form_error.content+'</span>');
			error = true;
		}

		// Validate Image
		if( typeof(tstmnl_img_val) != '' && tstmnl_img_val != '' ){
			var img_ext = tstmnl_img_val.split('.').pop().toLowerCase();
			if( jQuery.inArray( img_ext, allowedExtensions ) == -1 ){
				tstmnl_img.after('<span class="wtwp-frm-error">'+WtwpPro.form_error.image+'</span>');
				error = true;
			}
		}

		// Validate captcha
		if( captcha_val == '' || captcha_val == null ){
			captcha.after('<span class="wtwp-frm-error">'+WtwpPro.form_error.captcha+'</span>');
			error = true;
		}

		// If error is there then return false
		if( error == true ){
			cls_form.before('<div class="wtwp-tstmnl-err">'+WtwpPro.form_error.error_msg+'</div>');
			return false;
		}
	});
});
<?php
/**
 * Admion Class
 *
 * Handles admin side functionality of plugin
 *
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Wtwp_Admin {
	
	function __construct(){

		// Action to add metabox
		add_action( 'add_meta_boxes', array($this, 'wtwp_add_testimonial_metabox') );

		// Action to save metabox
		add_action( 'save_post', array($this,'wtwp_save_metabox_value') );

		// Action to register admin menu
		add_action( 'admin_menu', array($this, 'wtwp_pro_register_menu'), 9 );

		// Action to register plugin settings
		add_action ( 'admin_init', array($this, 'wtwp_pro_register_settings') );

		// Action to add category dropdown
		add_action( 'restrict_manage_posts', array($this, 'wtwp_pro_add_post_filters'), 50 );

		// Manage Category Shortcode Columns
		add_filter('manage_edit-'.WTWP_CAT.'_columns', array($this,'wtwp_pro_tstmnl_cat_columns'));
		add_filter('manage_'.WTWP_CAT.'_custom_column', array($this,'wtwp_pro_tstmnl_cat_columns_data'), 10, 3);

		// Action to add sorting link at Testimonial listing page
		add_filter( 'views_edit-'.WTWP_POST_TYPE, array($this, 'wtwp_pro_sorting_link') );

		// Filter to add row data
		add_filter( 'post_row_actions', array($this, 'wtwp_pro_add_post_row_data'), 10, 2 );

		// Action to add custom column to Testimonial listing
		add_filter( 'manage_'.WTWP_POST_TYPE.'_posts_columns', array($this, 'wtwp_pro_posts_columns') );

		// Action to add custom column data to testimonial listing
		add_action('manage_'.WTWP_POST_TYPE.'_posts_custom_column', array($this, 'wtwp_pro_post_columns_data'), 10, 2);

		// Action to add `Save Order` button
		add_action( 'restrict_manage_posts', array($this, 'wtwp_pro_restrict_manage_posts') );

		// Ajax call to update option
		add_action( 'wp_ajax_wtwp_pro_update_post_order', array($this, 'wtwp_pro_update_post_order'));
		add_action( 'wp_ajax_nopriv_wtwp_pro_update_post_order',array( $this, 'wtwp_pro_update_post_order'));

		// Filter to add plugin links
		add_filter( 'plugin_row_meta', array( $this, 'wtwp_pro_plugin_row_meta' ), 10, 2 );
		add_filter( 'plugin_action_links_' . WTWP_PRO_PLUGIN_BASENAME, array( $this, 'wtwp_pro_plugin_action_links' ) );
	}

	/**
	 * Function to register metabox
	 * 
	 * @package WP Testimonials with rotator widget Pro
	 * @since 1.0.0
	 */
	function wtwp_add_testimonial_metabox() {
		add_meta_box( 'testimonial-details', __( 'Testimonial Details', 'wp-testimonial-with-widget' ), array($this, 'wtwp_meta_box_content'), WTWP_POST_TYPE, 'normal', 'high' );
	}

	/**
	 * Function to handle metabox content
	 * 
	 * @package WP Testimonials with rotator widget Pro
	 * @since 1.0.0
	 */
	function wtwp_meta_box_content() {
		include_once( WTWP_DIR .'/includes/admin/metabox/wtwp-testimonial-metabox-html.php');
	}

	/**
	 * Function to save metabox values
	 * 
	 * @package WP Testimonials with rotator widget Pro
	 * @since 1.0.0
	 */
	function wtwp_save_metabox_value( $post_id ){

		global $post_type;
		
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )                	// Check Autosave
		|| ( ! isset( $_POST['post_ID'] ) || $post_id != $_POST['post_ID'] )  	// Check Revision
		|| ( $post_type !=  WTWP_POST_TYPE ) )              					// Check if current post type is supported.
		{
			return $post_id;
		}

		$prefix = WTWP_META_PREFIX; // Taking metabox prefix

		// Getting saved values
		$client 	= isset($_POST['_testimonial_client']) 	? wtwp_slashes_deep(trim($_POST['_testimonial_client'])) 	: '';
		$job 		= isset($_POST['_testimonial_job'])		? wtwp_slashes_deep(trim($_POST['_testimonial_job'])) 		: '';
		$company 	= isset($_POST['_testimonial_company']) ? wtwp_slashes_deep(trim($_POST['_testimonial_company'])) 	: '';
		$url 		= isset($_POST['_testimonial_url']) 	? wtwp_slashes_deep(trim($_POST['_testimonial_url'])) 		: '';
		$rating 	= isset($_POST[$prefix.'rating']) 		? wtwp_slashes_deep(trim($_POST[$prefix.'rating'])) 		: '';

		update_post_meta($post_id, '_testimonial_client', $client);
		update_post_meta($post_id, '_testimonial_job', $job);
		update_post_meta($post_id, '_testimonial_company', $company);
		update_post_meta($post_id, '_testimonial_url', $url);
		update_post_meta($post_id, $prefix.'rating', $rating);
	}

	/**
	 * Function to register admin menus
	 * 
	 * @package WP Testimonials with rotator widget Pro
	 * @since 1.0.0
	 */
	function wtwp_pro_register_menu() {
		add_submenu_page( 'edit.php?post_type='.WTWP_POST_TYPE, __('Settings', 'wp-testimonial-with-widget'), __('Settings', 'wp-testimonial-with-widget'), 'manage_options', 'wtwp-pro-settings', array($this, 'wtwp_pro_settings_page') );
	}

	/**
	 * Function to handle the setting page html
	 * 
	 * @package WP Logo Showcase Responsive Slider Pro
	 * @since 1.0.0
	 */
	function wtwp_pro_settings_page() {
		include_once( WTWP_DIR . '/includes/admin/settings/wtwp-settings.php' );
	}

	/**
	 * Function register setings
	 * 
	 * @package WP Testimonials with rotator widget Pro
	 * @since 1.0.0
	 */
	function wtwp_pro_register_settings() {
		register_setting( 'wtwp_pro_plugin_options', 'wtwp_pro_options', array($this, 'wtwp_pro_validate_options') );
	}

	/**
	 * Validate Settings Options
	 * 
	 * @package WP Testimonials with rotator widget Pro
	 * @since 1.0.0
	 */
	function wtwp_pro_validate_options( $input ) {

		$input['default_img'] 	= isset($input['default_img']) ? wtwp_slashes_deep($input['default_img']) 		: '';
		$input['custom_css'] 	= isset($input['custom_css']) ? wtwp_slashes_deep($input['custom_css'], true) 	: '';
		
		return $input;
	}

	/**
	 * Add category dropdown to testimonial listing page
	 * 
	 * @package WP Testimonials with rotator widget Pro
	 * @since 1.0.0
	 */
	function wtwp_pro_add_post_filters() {

		global $typenow;
		
		if( $typenow == WTWP_POST_TYPE ) {

			$dropdown_options = apply_filters('wtwp_cat_filter_args', array(
					'show_option_none'  => __('All Categories', 'wp-testimonial-with-widget'),
					'option_none_value' => '',
					'hide_empty' 		=> 1,
					'hierarchical' 		=> 1,
					'show_count' 		=> 0,
					'orderby' 			=> 'name',
					'name'				=> WTWP_CAT,
					'taxonomy'			=> WTWP_CAT,
					'selected' 			=> isset($_GET[WTWP_CAT]) ? $_GET[WTWP_CAT] : '',
					'value_field'		=> 'slug'
				));

			wp_dropdown_categories( $dropdown_options );
		}
	}

	/**
	 * Add extra column to testimonial category
	 * 
	 * @package WP Testimonials with rotator widget Pro
	 * @since 1.0.0
	 */
	function wtwp_pro_tstmnl_cat_columns( $columns ) {

    	$new_columns['wtwp_shortcode'] = __( 'Testimonial Category Shortcode', 'wp-testimonial-with-widget' );

		$columns = wtwp_pro_add_array( $columns, $new_columns, 2 );

		return $columns;
	}

	/**
	 * Add data to extra column to testimonial category
	 * 
	 * @package WP Testimonials with rotator widget Pro
	 * @since 1.0.0
	 */
	function wtwp_pro_tstmnl_cat_columns_data($ouput, $column_name, $tax_id) {
	   
	   if( $column_name == 'wtwp_shortcode' ){
			$ouput .= '[sp_testimonials category="' . $tax_id. '"]<br/>';
			$ouput .= '[sp_testimonials_slider category="' . $tax_id. '"]';
	    }
		
	    return $ouput;
	}

	/**
	 * Add 'Sort Testimonial' link at Testimonial listing page
	 * 
	 * @package WP Testimonials with rotator widget Pro
	 * @since 1.0.0
	 */
	function wtwp_pro_sorting_link( $views ) {

		global $wp_query;

		$class            = ( isset( $wp_query->query['orderby'] ) && $wp_query->query['orderby'] == 'menu_order title' ) ? 'current' : '';
		$query_string     = remove_query_arg(array( 'orderby', 'order' ));
		$query_string     = add_query_arg( 'orderby', urlencode('menu_order title'), $query_string );
		$query_string     = add_query_arg( 'order', urlencode('ASC'), $query_string );
		$views['byorder'] = '<a href="' . esc_url( $query_string ) . '" class="' . esc_attr( $class ) . '">' . __( 'Sort Testimonial', 'wp-testimonial-with-widget' ) . '</a>';

		return $views;
	}

	/**
	 * Function to add custom quick links at post listing page
	 * 
	 * @package WP Testimonials with rotator widget Pro
	 * @since 1.0.0
	 */
	function wtwp_pro_add_post_row_data( $actions, $post ) {
		
		if( $post->post_type == WTWP_POST_TYPE ) {
			return array_merge( array( 'wtwp_pro_id' => 'ID: ' . $post->ID ), $actions );
		}
		
		return $actions;
	}

	/**
	 * Add custom column to Testimonial listing page
	 * 
	 * @package WP Testimonials with rotator widget Pro
	 * @since 1.0.0
	 */
	function wtwp_pro_posts_columns( $columns ){

		$new_columns['wtwp_image'] 		= __('Image', 'wp-testimonial-with-widget');
		$new_columns['wtwp_rating'] 	= __('Rating', 'wp-testimonial-with-widget');
		$new_columns['wtwp_pro_order'] 	= __('Order', 'wp-testimonial-with-widget');

		$columns = wtwp_pro_add_array( $columns, $new_columns, 4 );

		return $columns;
	}

	/**
	 * Add custom column data to Testimonial listing page
	 * 
	 * @package WP Testimonials with rotator widget Pro
	 * @since 1.0.0
	 */
	function wtwp_pro_post_columns_data( $column, $post_id ) {

		global $post;

		if( $column == 'wtwp_pro_order' ) {

			$post_menu_order = isset($post->menu_order) ? $post->menu_order : '';
			
			echo $post_menu_order;
			echo "<input type='hidden' value='{$post_id}' name='wtwp_pro_post[]' class='wtwp-testimonial-order' id='wtwp-testimonial-order-{$post_id}' />";

		} elseif($column == 'wtwp_image') {
			
			$value = wtwp_pro_get_image( get_the_ID(), 40 ,'square');
			echo $value;

		} elseif ( $column == 'wtwp_rating' ) {

			$prefix 		= WTWP_META_PREFIX;
			$tstmnl_rating 	= get_post_meta( $post_id, $prefix.'rating', true );
			
			for ($i = 0; $i < 5; $i++) {
				if( $i < $tstmnl_rating ) {
					echo '<i class="dashicons dashicons-star-filled"></i>';
				} else {
					echo '<i class="dashicons dashicons-star-empty"></i>';
				}
			} // End for loop
		}
	}
	
	/**
	 * Add Save button to Testimonials listing page
	 * 
	 * @package WP Testimonials with rotator widget Pro
	 * @since 1.0.0
	 */
	function wtwp_pro_restrict_manage_posts(){

		global $typenow, $wp_query;

		if( $typenow == WTWP_POST_TYPE && isset($wp_query->query['orderby']) && $wp_query->query['orderby'] == 'menu_order title' ) {

			$html  = '';
			$html .= "<span class='spinner wtwp-spinner'></span>";
			$html .= "<input type='button' name='wtwp_save_order' class='button button-secondary right wtwp-save-order' id='wtwp-save-order' value='".__('Save Sort Order', 'wp-testimonial-with-widget')."' />";
			echo $html;
		}
	}

	/**
	 * Update Testimonials order
	 * 
	 * @package WP Testimonials with rotator widget Pro
	 * @since 1.0.0
	 */
	function wtwp_pro_update_post_order() {
		// Taking some defaults
		$result 			= array();
		$result['success'] 	= 0;
		$result['msg'] 		= __('Sorry, Something happened wrong.', 'wp-testimonial-with-widget');

		if( !empty($_POST['form_data']) ) {

			$form_data 		= parse_str($_POST['form_data'], $output_arr);
			$wtwp_posts 	= !empty($output_arr['wtwp_pro_post']) ? $output_arr['wtwp_pro_post'] : '';

			if( !empty($wtwp_posts) ) {

				$post_menu_order = 0;

				// Loop od ids
				foreach ($wtwp_posts as $wpbab_post_key => $wtwp_post) {
					
					// Update post order
					$update_post = array(
						'ID'           => $wtwp_post,
						'menu_order'   => $post_menu_order,
						);

					// Update the post into the database
					wp_update_post( $update_post );

					$post_menu_order++;
				}

				$result['success'] 	= 1;
				$result['msg'] 		= __('Testimonials order saved successfully.', 'wp-testimonial-with-widget');
			}
		}

		echo json_encode($result);
		exit;
	}

	/**
	 * Function to unique number value
	 * 
	 * @package WP Testimonials with rotator widget Pro
	 * @since 1.0.0
	 */
	function wtwp_pro_plugin_row_meta( $links, $file ) {
		
		if ( $file == WTWP_PRO_PLUGIN_BASENAME ) {
			
			$row_meta = array(
				'docs'    => '<a href="' . esc_url('http://wponlinesupport.com/pro-plugin-document/document-wp-testimonials-with-rotator-widget-pro/') . '" title="' . esc_attr( __( 'View Documentation', 'wp-testimonial-with-widget' ) ) . '" target="_blank">' . __( 'Docs', 'wp-testimonial-with-widget' ) . '</a>',
				'support' => '<a href="' . esc_url('http://wponlinesupport.com/welcome-wp-online-support-forum/') . '" title="' . esc_attr( __( 'Visit Customer Support Forum', 'wp-testimonial-with-widget' ) ) . '" target="_blank">' . __( 'Support', 'wp-testimonial-with-widget' ) . '</a>',
			);
			return array_merge( $links, $row_meta );
		}
		return (array) $links;
	}

	/**
	 * Function to add extra plugins link
	 * 
	 * @package WP Testimonials with rotator widget Pro
	 * @since 1.0.0
	 */
	function wtwp_pro_plugin_action_links( $links ) {
		
		$license_url = add_query_arg( array( 'post_type' => WTWP_POST_TYPE, 'page' => 'wtwp-pro-license'), admin_url('edit.php') );
		
		$links['license'] = '<a href="' . esc_url($license_url) . '" title="' . esc_attr( __( 'Activate Plugin License', 'wp-testimonial-with-widget' ) ) . '">' . __( 'License', 'wp-testimonial-with-widget' ) . '</a>';
		
		return $links;
	}
}

$wtwp_admin = new Wtwp_Admin();
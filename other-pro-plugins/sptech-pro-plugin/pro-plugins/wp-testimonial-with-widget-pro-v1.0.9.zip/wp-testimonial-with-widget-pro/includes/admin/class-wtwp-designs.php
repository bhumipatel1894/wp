<?php
/**
 * Design Class
 *
 * Display all designs of plugin
 *
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// Action to register menu
add_action( 'admin_menu', 'wtwp_add_design_page' );

/**
* Function to add disign template page in menu
* 
* @package WP Testimonials with rotator widget Pro
* @since 1.0.0
*/
function wtwp_add_design_page() {
    add_submenu_page( 'edit.php?post_type='.WTWP_POST_TYPE, __('Testimonial Designs', 'wp-testimonial-with-widget'), __('Testimonial Designs', 'wp-testimonial-with-widget'), 'manage_options', 'wtwp-pro-designs-page', 'wtwp_pro_designs_page' );
}

/**
* Function to display disign template page
* 
* @package WP Testimonials with rotator widget Pro
* @since 1.0.0
*/
function wtwp_pro_designs_page() {

    $wtwp_feed_tabs = array(
                                'design-feed'   => __('Plugin Designs', 'wp-testimonial-with-widget'),
                                'plugins-feed'  => __('Our Plugins', 'wp-testimonial-with-widget')
                            );
    
    $active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'design-feed';
    ?>
    
    <div class="wrap wtwp-wrap">

        <h2 class="nav-tab-wrapper">
            <?php
            foreach ($wtwp_feed_tabs as $tab_key => $tab_val) {

                $active_cls = ($tab_key == $active_tab) ? 'nav-tab-active' : '';
                $tab_link   = add_query_arg( array('post_type' => WTWP_POST_TYPE, 'page' => 'wtwp-pro-designs-page', 'tab' => $tab_key), admin_url('edit.php') );
            ?>

            <a class="nav-tab <?php echo $active_cls; ?>" href="<?php echo $tab_link; ?>"><?php echo $tab_val; ?></a>

            <?php } ?>
        </h2>

        <div class="wtwp-tab-cnt-wrp">
        <?php 
            if( isset($_GET['tab']) && $_GET['tab'] == 'plugins-feed' ) {
                echo wtwp_pro_get_design( 'plugins-feed' );
            } else {
                echo wtwp_pro_get_design();
            }
        ?>
        </div><!-- end .wtwp-tab-cnt-wrp -->

    </div><!-- end .wtwp-wrap -->

<?php
}

/**
 * Gets the plugin design part feed
 *
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */
function wtwp_pro_get_design( $feed_type = '' ) {
    
    $active_tab     = isset($_GET['tab']) ? $_GET['tab'] : 'design-feed';
    $transient_key  = 'wtwp_pro_' . $active_tab;
    
    // Feed URL
    if( $feed_type == 'plugins-feed' ) {
        $url            = 'http://wponlinesupport.com/plugin-data-api/plugins-data.php';
        $transient_key  = 'wpos_plugins_feed';
    } else {
        $url = 'http://wponlinesupport.com/plugin-data-api/wp-testimonial-with-widget/wp-testimonial-with-widget-pro.php';
    }

    $cache = get_transient( $transient_key );
    
    if ( false === $cache ) {
        
        $feed           = wp_remote_get( esc_url_raw( $url ), array( 'timeout' => 120, 'sslverify' => false ) );
        $response_code  = wp_remote_retrieve_response_code( $feed );
        
        if ( ! is_wp_error( $feed ) && $response_code == 200 ) {
            if ( isset( $feed['body'] ) && strlen( $feed['body'] ) > 0 ) {
                $cache = wp_remote_retrieve_body( $feed );
                set_transient( $transient_key, $cache, 172800 );
            }
        } else {
            $cache = '<div class="error"><p>' . __( 'There was an error retrieving the data from the server. Please try again later.', 'wp-testimonial-with-widget' ) . '</div>';
        }
    }
    return $cache;
}
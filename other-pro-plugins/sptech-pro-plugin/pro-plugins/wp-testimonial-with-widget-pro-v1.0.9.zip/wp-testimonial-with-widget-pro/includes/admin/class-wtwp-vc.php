<?php
/**
 * Visual Composer Class
 *
 * Handles the visual composer shortcode functionality of plugin
 *
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Wtwp_Vc {
	
	function __construct() {
		
		// Action to add 'sp_testimonials' shortcode in vc
		add_action( 'vc_before_init', array($this, 'wtwp_pro_integrate_grid_vc') );
		
		// Action to add 'sp_testimonials_slider' shortcode in vc
		add_action( 'vc_before_init', array($this, 'wtwp_pro_integrate_slider_vc') );
	}

	/**
	 * Function to add 'sp_testimonials' shortcode in vc
	 * 
	 * @package WP Testimonials with rotator widget Pro
	 * @since 1.0.0
	 */
	function wtwp_pro_integrate_grid_vc() {
		vc_map( array(
			'name' 			=> __( 'WPOS - Testimonial Grid', 'wp-testimonial-with-widget' ),
			'base' 			=> 'sp_testimonials',
			'icon' 			=> 'icon-wpb-wp',
			'class' 		=> '',
			'category' 		=> __( 'Content', 'wp-testimonial-with-widget'),
			'description' 	=> __( 'Display testimonial grid.', 'wp-testimonial-with-widget' ),
			'params' 		=> array(
				// General settings
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Design', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'design',
					'value' 		=> array(
											__( 'Grid Design 1', 'wp-testimonial-with-widget' ) 	=> 'design-1',
											__( 'Grid Design 2', 'wp-testimonial-with-widget' ) 	=> 'design-2',
											__( 'Grid Design 3', 'wp-testimonial-with-widget' ) 	=> 'design-3',
											__( 'Grid Design 4', 'wp-testimonial-with-widget' ) 	=> 'design-4',
											__( 'Grid Design 5', 'wp-testimonial-with-widget' ) 	=> 'design-5',
											__( 'Grid Design 6', 'wp-testimonial-with-widget' ) 	=> 'design-6',
											__( 'Grid Design 7', 'wp-testimonial-with-widget' ) 	=> 'design-7',
											__( 'Grid Design 8', 'wp-testimonial-with-widget' ) 	=> 'design-8',
											__( 'Grid Design 9', 'wp-testimonial-with-widget' ) 	=> 'design-9',
											__( 'Grid Design 10', 'wp-testimonial-with-widget' ) 	=> 'design-10',
											__( 'Grid Design 11', 'wp-testimonial-with-widget' ) 	=> 'design-11',
											__( 'Grid Design 12', 'wp-testimonial-with-widget' ) 	=> 'design-12',
											__( 'Grid Design 13', 'wp-testimonial-with-widget' ) 	=> 'design-13',
											__( 'Grid Design 14', 'wp-testimonial-with-widget' ) 	=> 'design-14',
											__( 'Grid Design 15', 'wp-testimonial-with-widget' ) 	=> 'design-15',
											__( 'Grid Design 16', 'wp-testimonial-with-widget' ) 	=> 'design-16',
											__( 'Grid Design 17', 'wp-testimonial-with-widget' ) 	=> 'design-17',
											__( 'Grid Design 18', 'wp-testimonial-with-widget' ) 	=> 'design-18',
											__( 'Grid Design 19', 'wp-testimonial-with-widget' ) 	=> 'design-19',
											__( 'Grid Design 20', 'wp-testimonial-with-widget' ) 	=> 'design-20',
										),
					'description' 	=> __( 'Choose grid design.', 'wp-testimonial-with-widget' ),
					'admin_label' 	=> true,
				),
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Display Title', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'show_title',
					'value' 		=> array(
											__( 'True', 'wp-testimonial-with-widget' ) 		=> 'true',
											__( 'False', 'wp-testimonial-with-widget' )		=> 'false',
										),
					'description' 	=> __( 'display title.', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Display Client', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'display_client',
					'value' 		=> array(
											__( 'True', 'wp-testimonial-with-widget' ) 		=> 'true',
											__( 'False', 'wp-testimonial-with-widget' )		=> 'false',
										),
					'description' 	=> __( 'display client.', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Display Avatar', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'display_avatar',
					'value' 		=> array(
											__( 'True', 'wp-testimonial-with-widget' ) 		=> 'true',
											__( 'False', 'wp-testimonial-with-widget' )		=> 'false',
										),
					'description' 	=> __( 'display avatar.', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Display Job', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'display_job',
					'value' 		=> array(
											__( 'True', 'wp-testimonial-with-widget' ) 		=> 'true',
											__( 'False', 'wp-testimonial-with-widget' )		=> 'false',
										),
					'description' 	=> __( 'display job.', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Display Company', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'display_company',
					'value' 		=> array(
											__( 'True', 'wp-testimonial-with-widget' ) 		=> 'true',
											__( 'False', 'wp-testimonial-with-widget' )		=> 'false',
										),
					'description' 	=> __( 'display company.', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Display Ratings', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'show_rating',
					'value' 		=> array(
											__( 'True', 'wp-testimonial-with-widget' ) 		=> 'true',
											__( 'False', 'wp-testimonial-with-widget' )		=> 'false',
										),
					'description' 	=> __( 'display ratings.', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Image Style', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'image_style',
					'value' 		=> array(
											__( 'Circle', 'wp-testimonial-with-widget' ) 	=> 'circle',
											__( 'Square', 'wp-testimonial-with-widget' )	=> 'square',
										),
					'description' 	=> __( 'image style.', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'textfield',
					'class' 		=> '',
					'heading' 		=> __( 'Image Size', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'size',
					'value' 		=> 100,
					'description' 	=> __( 'Enter number for image size.', 'wp-testimonial-with-widget' ),
				),
				
				// Data Settings
				array(
					'type' 			=> 'textfield',
					'class' 		=> '',
					'heading' 		=> __( 'Total Items', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'limit',
					'value' 		=> 20,
					'description' 	=> __( 'Enter number to be displayed. Enter -1 to display all.', 'wp-testimonial-with-widget' ),
					'group' 		=> __( 'Data Settings', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'textfield',
					'class' 		=> '',
					'heading' 		=> __( 'Per Row', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'per_row',
					'value' 		=> 3,
					'description' 	=> __( 'Enter number to be displayed testimonial per row.', 'wp-testimonial-with-widget' ),
					'group' 		=> __( 'Data Settings', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Post Order By', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'orderby',
					'value' 		=> array(
											__( 'Post Date', 'wp-testimonial-with-widget' ) 			=> 'date',
											__( 'Post ID', 'wp-testimonial-with-widget' ) 				=> 'ID',
											__( 'Post Author', 'wp-testimonial-with-widget' ) 			=> 'author',
											__( 'Post Title', 'wp-testimonial-with-widget' ) 			=> 'title',
											__( 'Post Modified Date', 'wp-testimonial-with-widget' ) 	=> 'modified',
											__( 'Random', 'wp-testimonial-with-widget' ) 				=> 'rand',
											__( 'Menu Order', 'wp-testimonial-with-widget' ) 			=> 'menu_order',
											),
					'description' 	=> __( 'Select order type.', 'wp-testimonial-with-widget' ),
					'group' 		=> __( 'Data Settings', 'wp-testimonial-with-widget' )
				),
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Order', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'order',
					'value' 		=> array(
											__( 'Descending', 'wp-testimonial-with-widget' ) 	=> 'desc',
											__( 'Ascending', 'wp-testimonial-with-widget' ) 	=> 'asc',
										),
					'description' 	=> __( 'Post Order.', 'wp-testimonial-with-widget' ),
					'group' 		=> __( 'Data Settings', 'wp-testimonial-with-widget' )
				),
				array(
					'type' 			=> 'textfield',
					'class' 		=> '',
					'heading' 		=> __( 'Category', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'category',
					'value' 		=> '',
					'description' 	=> __( 'Enter category id to display Testimonials categories wise.', 'wp-testimonial-with-widget' ),
					'group' 		=> __( 'Data Settings', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Include Child Category Post', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'include_cat_child',
					'value' 		=> array(
											__( 'True', 'wp-testimonial-with-widget' ) 	=> 'desc',
											__( 'False', 'wp-testimonial-with-widget' ) => 'asc',
										),
					'description' 	=> __( 'Include Child Category Post.', 'wp-testimonial-with-widget' ),
					'group' 		=> __( 'Data Settings', 'wp-testimonial-with-widget' )
				),
				array(
					'type' 			=> 'textfield',
					'class' 		=> '',
					'heading' 		=> __( 'Exclude Category', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'exclude_cat',
					'value' 		=> '',
					'description' 	=> __( 'Exclude testimonial category. Works only if `Category` field is empty.', 'wp-testimonial-with-widget' ),
					'group' 		=> __( 'Data Settings', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'textfield',
					'class' 		=> '',
					'heading' 		=> __( 'Display Specific Testimonial', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'posts',
					'value' 		=> '',
					'description' 	=> __( 'Enter post id which you only want to display. You can enter multiple post id with comma seperated.', 'wp-testimonial-with-widget' ),
					'group' 		=> __( 'Data Settings', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'textfield',
					'class' 		=> '',
					'heading' 		=> __( 'Exclude Post', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'exclude_post',
					'value' 		=> '',
					'description' 	=> __( 'Enter post id which you do not want to display. You can enter multiple post id with comma seperated.', 'wp-testimonial-with-widget' ),
					'group' 		=> __( 'Data Settings', 'wp-testimonial-with-widget' ),
					),
				),
	));
}

	/**
	 * Function to add 'sp_testimonials_slider' shortcode in vc
	 * 
	 * @package WP Testimonials with rotator widget Pro
	 * @since 1.0.0
	 */
	function wtwp_pro_integrate_slider_vc() {
		vc_map( array(
			'name' 			=> __( 'WPOS - Testimonial Slider', 'wp-testimonial-with-widget' ),
			'base' 			=> 'sp_testimonials_slider',
			'icon' 			=> 'icon-wpb-wp',
			'class' 		=> '',
			'category' 		=> __( 'Content', 'wp-testimonial-with-widget'),
			'description' 	=> __( 'Display Testimonial slider.', 'wp-testimonial-with-widget' ),
			'params' 	=> array(
			// General settings
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Design', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'design',
					'value' 		=> array(
											__( 'Slider Design 1', 'wp-testimonial-with-widget' ) 	=> 'design-1',
											__( 'Slider Design 2', 'wp-testimonial-with-widget' ) 	=> 'design-2',
											__( 'Slider Design 3', 'wp-testimonial-with-widget' ) 	=> 'design-3',
											__( 'Slider Design 4', 'wp-testimonial-with-widget' ) 	=> 'design-4',
											__( 'Slider Design 5', 'wp-testimonial-with-widget' ) 	=> 'design-5',
											__( 'Slider Design 6', 'wp-testimonial-with-widget' ) 	=> 'design-6',
											__( 'Slider Design 7', 'wp-testimonial-with-widget' ) 	=> 'design-7',
											__( 'Slider Design 8', 'wp-testimonial-with-widget' ) 	=> 'design-8',
											__( 'Slider Design 9', 'wp-testimonial-with-widget' ) 	=> 'design-9',
											__( 'Slider Design 10', 'wp-testimonial-with-widget' ) 	=> 'design-10',
											__( 'Slider Design 11', 'wp-testimonial-with-widget' ) 	=> 'design-11',
											__( 'Slider Design 12', 'wp-testimonial-with-widget' ) 	=> 'design-12',
											__( 'Slider Design 13', 'wp-testimonial-with-widget' ) 	=> 'design-13',
											__( 'Slider Design 14', 'wp-testimonial-with-widget' ) 	=> 'design-14',
											__( 'Slider Design 15', 'wp-testimonial-with-widget' ) 	=> 'design-15',
											__( 'Slider Design 16', 'wp-testimonial-with-widget' ) 	=> 'design-16',
											__( 'Slider Design 17', 'wp-testimonial-with-widget' ) 	=> 'design-17',
											__( 'Slider Design 18', 'wp-testimonial-with-widget' ) 	=> 'design-18',
											__( 'Slider Design 19', 'wp-testimonial-with-widget' ) 	=> 'design-19',
											__( 'Slider Design 20', 'wp-testimonial-with-widget' ) 	=> 'design-20',
										),
					'description' 	=> __( 'Choose Slider design.', 'wp-testimonial-with-widget' ),
					'admin_label' 	=> true,
				),
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Display Title', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'show_title',
					'value' 		=> array(
											__( 'True', 'wp-testimonial-with-widget' ) 		=> 'true',
											__( 'False', 'wp-testimonial-with-widget' )		=> 'false',
										),
					'description' 	=> __( 'display title.', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Display Client', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'display_client',
					'value' 		=> array(
											__( 'True', 'wp-testimonial-with-widget' ) 		=> 'true',
											__( 'False', 'wp-testimonial-with-widget' )		=> 'false',
										),
					'description' 	=> __( 'display client.', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Display Avatar', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'display_avatar',
					'value' 		=> array(
											__( 'True', 'wp-testimonial-with-widget' ) 		=> 'true',
											__( 'False', 'wp-testimonial-with-widget' )		=> 'false',
										),
					'description' 	=> __( 'display avatar.', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Display Job', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'display_job',
					'value' 		=> array(
											__( 'True', 'wp-testimonial-with-widget' ) 		=> 'true',
											__( 'False', 'wp-testimonial-with-widget' )		=> 'false',
										),
					'description' 	=> __( 'display job.', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Display Company', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'display_company',
					'value' 		=> array(
											__( 'True', 'wp-testimonial-with-widget' ) 		=> 'true',
											__( 'False', 'wp-testimonial-with-widget' )		=> 'false',
										),
					'description' 	=> __( 'display company.', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Display Ratings', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'show_rating',
					'value' 		=> array(
											__( 'True', 'wp-testimonial-with-widget' ) 		=> 'true',
											__( 'False', 'wp-testimonial-with-widget' )		=> 'false',
										),
					'description' 	=> __( 'display ratings.', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Image Style', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'image_style',
					'value' 		=> array(
											__( 'Circle', 'wp-testimonial-with-widget' ) 		=> 'circle',
											__( 'Square', 'wp-testimonial-with-widget' )		=> 'square',
										),
					'description' 	=> __( 'image style.', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'textfield',
					'class' 		=> '',
					'heading' 		=> __( 'Image Size', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'size',
					'value' 		=> 100,
					'description' 	=> __( 'Enter number for image size.', 'wp-testimonial-with-widget' ),
				),
				// Date Setting
				array(
					'type' 			=> 'textfield',
					'class' 		=> '',
					'heading' 		=> __( 'Total items', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'limit',
					'value' 		=> 20,
					'description' 	=> __( 'Enter number to be displayed. Enter -1 to display all.', 'wp-testimonial-with-widget' ),
					'group' 		=> __( 'Data Settings', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Post Order By', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'orderby',
					'value' 		=> array(
											__( 'Post Date', 'wp-testimonial-with-widget' ) 			=> 'date',
											__( 'Post ID', 'wp-testimonial-with-widget' ) 				=> 'ID',
											__( 'Post Author', 'wp-testimonial-with-widget' ) 			=> 'author',
											__( 'Post Title', 'wp-testimonial-with-widget' ) 			=> 'title',
											__( 'Post Modified Date', 'wp-testimonial-with-widget' ) 	=> 'modified',
											__( 'Random', 'wp-testimonial-with-widget' ) 				=> 'rand',
											__( 'Menu Order', 'wp-testimonial-with-widget' ) 			=> 'menu_order',
											),
					'description' 	=> __( 'Select order type.', 'wp-testimonial-with-widget' ),
					'group' 		=> __( 'Data Settings', 'wp-testimonial-with-widget' )
				),
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Order', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'order',
					'value' 		=> array(
											__( 'Descending', 'wp-testimonial-with-widget' ) 	=> 'desc',
											__( 'Ascending', 'wp-testimonial-with-widget' )		=> 'asc',
										),
					'description' 	=> __( 'Post Order.', 'wp-testimonial-with-widget' ),
					'group' 		=> __( 'Data Settings', 'wp-testimonial-with-widget' )
				),
				array(
					'type' 			=> 'textfield',
					'class' 		=> '',
					'heading' 		=> __( 'Category', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'category',
					'value' 		=> '',
					'description' 	=> __( 'Enter category id to display Testimonials categories wise.', 'wp-testimonial-with-widget' ),
					'group' 		=> __( 'Data Settings', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'textfield',
					'class' 		=> '',
					'heading' 		=> __( 'Exclude Category', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'exclude_cat',
					'value' 		=> '',
					'description' 	=> __( 'Exclude slides category. Works only if `Category` field is empty.', 'wp-testimonial-with-widget' ),
					'group' 		=> __( 'Data Settings', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'textfield',
					'class' 		=> '',
					'heading' 		=> __( 'Display Specific Post', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'posts',
					'value' 		=> '',
					'description' 	=> __( 'Enter post id which you only want to display. You can enter multiple post id with comma seperated.', 'wp-testimonial-with-widget' ),
					'group' 		=> __( 'Data Settings', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'textfield',
					'class' 		=> '',
					'heading' 		=> __( 'Exclude Post', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'exclude_post',
					'value' 		=> '',
					'description' 	=> __( 'Enter post id which you do not want to display. You can enter multiple post id with comma seperated.', 'wp-testimonial-with-widget' ),
					'group' 		=> __( 'Data Settings', 'wp-testimonial-with-widget' ),
				),

				//Slider Setting
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Dots', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'dots',
					'value' 		=> array(
											__( 'True', 'wp-testimonial-with-widget' ) 	=> 'true',
											__( 'False', 'wp-testimonial-with-widget' ) => 'false',
										),
					'description' 	=> __( 'Show pagination dots.', 'wp-testimonial-with-widget' ),
					'group' 		=> __( 'Slider Settings', 'wp-testimonial-with-widget' )
				),
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Arrows', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'arrows',
					'value' 		=> array(
											__( 'True', 'wp-testimonial-with-widget' ) 	=> 'true',
											__( 'False', 'wp-testimonial-with-widget' ) => 'false',
										),
					'description' 	=> __( 'Show Prev - Next arrows.', 'wp-testimonial-with-widget' ),
					'group' 		=> __( 'Slider Settings', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'textfield',
					'class' 		=> '',
					'heading' 		=> __( 'Slide To Show', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'slides_column',
					'value' 		=> '2',
					'description' 	=> __( 'Enter Slide to show.', 'wp-testimonial-with-widget' ),
					'group' 		=> __( 'Slider Settings', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'textfield',
					'class' 		=> '',
					'heading' 		=> __( 'Slide To Scroll', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'slides_scroll',
					'value' 		=> '1',
					'description' 	=> __( 'Enter slide to scroll.', 'wp-testimonial-with-widget' ),
					'group' 		=> __( 'Slider Settings', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Autoplay', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'autoplay',
					'value' 		=> array(
											__( 'True', 'wp-testimonial-with-widget' ) 	=> 'true',
											__( 'False', 'wp-testimonial-with-widget' ) => 'false',
										),
					'description' 	=> __( 'Enable autoplay.', 'wp-testimonial-with-widget' ),
					'group' 		=> __( 'Slider Settings', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Loop', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'loop',
					'value' 		=> array(
											__( 'True', 'wp-testimonial-with-widget' ) 	=> 'true',
											__( 'False', 'wp-testimonial-with-widget' ) => 'false',
										),
					'description' 	=> __( 'Enable loop.', 'wp-testimonial-with-widget' ),
					'group' 		=> __( 'Slider Settings', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Fade Effect', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'effect',
					'value' 		=> array(
											__( 'False', 'wp-testimonial-with-widget' ) => 'slide',
											__( 'True', 'wp-testimonial-with-widget' ) 	=> 'fade',
										),
					'description' 	=> __( 'Enable fade effect.', 'wp-testimonial-with-widget' ),
					'group' 		=> __( 'Slider Settings', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'textfield',
					'class' 		=> '',
					'heading' 		=> __( 'Autoplay Interval', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'autoplay_interval',
					'value' 		=> '3000',
					'description' 	=> __( 'Enter autoplay speed.', 'wp-testimonial-with-widget' ),
					'group' 		=> __( 'Slider Settings', 'wp-testimonial-with-widget' ),
					'dependency' 	=> array(
										'element' 	=> 'autoplay',
										'value' 	=> array( 'true' ),
										),
				),
				array(
					'type' 			=> 'textfield',
					'class' 		=> '',
					'heading' 		=> __( 'Speed', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'speed',
					'value' 		=> '600',
					'description' 	=> __( 'Enter slide speed.', 'wp-testimonial-with-widget' ),
					'group' 		=> __( 'Slider Settings', 'wp-testimonial-with-widget' ),
				),
				array(
					'type' 			=> 'dropdown',
					'class' 		=> '',
					'heading' 		=> __( 'Centermode', 'wp-testimonial-with-widget' ),
					'param_name' 	=> 'center_mode',
					'value' 		=> array(
											__( 'False', 'wp-testimonial-with-widget' ) => 'false',
											__( 'True', 'wp-testimonial-with-widget' ) 	=> 'true',
										),
					'description' 	=> __( 'Enable centermode.', 'wp-testimonial-with-widget' ),
					'group' 		=> __( 'Slider Settings', 'wp-testimonial-with-widget' ),
				)
			)
		));
	}
}

$wtwp_vc = new Wtwp_Vc();
<?php
/**
 * Handles testimonial metabox HTML
 *
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

global $post;

$prefix = WTWP_META_PREFIX; // Metabox prefix

// Getting saved values
$client 	= get_post_meta( $post->ID, '_testimonial_client', true );
$job 		= get_post_meta( $post->ID, '_testimonial_job', true );
$company 	= get_post_meta( $post->ID, '_testimonial_company', true );
$url 		= get_post_meta( $post->ID, '_testimonial_url', true );
$rating 	= get_post_meta( $post->ID, $prefix.'rating', true );
?>

<table class="form-table wtwp-tstmnl-table">
	<tbody>
		<tr valign="top">
			<th scope="row">
				<label for="wtwp-client-name"><?php _e('Client Name', 'wp-testimonial-with-widget'); ?></label>
			</th>
			<td>
				<input type="text" value="<?php echo wtwp_escape_attr($client); ?>" class="regular-text" id="wtwp-client-name" name="_testimonial_client" />
			</td>
		</tr>

		<tr valign="top">
			<th scope="row">
				<label for="wtwp-job-title"><?php _e('Job Title', 'wp-testimonial-with-widget'); ?></label>
			</th>
			<td>
				<input type="text" value="<?php echo wtwp_escape_attr($job); ?>" class="regular-text" id="wtwp-job-title" name="_testimonial_job" />
			</td>
		</tr>

		<tr valign="top">
			<th scope="row">
				<label for="wtwp-company"><?php _e('Company', 'wp-testimonial-with-widget'); ?></label>
			</th>
			<td>
				<input type="text" value="<?php echo wtwp_escape_attr($company); ?>" class="regular-text" id="wtwp-company" name="_testimonial_company" />
			</td>
		</tr>

		<tr valign="top">
			<th scope="row">
				<label for="wtwp-url"><?php _e('URL', 'wp-testimonial-with-widget'); ?></label>
			</th>
			<td>
				<input type="text" value="<?php echo wtwp_escape_attr($url); ?>" class="regular-text" id="wtwp-url" name="_testimonial_url" />
			</td>
		</tr>

		<tr valign="top">
			<th scope="row">
				<label for="wtwp-tstmnl-rating"><?php _e('Rating', 'wp-testimonial-with-widget'); ?></label>
			</th>
			<td>
				<select name="<?php echo $prefix; ?>rating" class="wtwp-tstmnl-rating" id="wtwp-tstmnl-rating">
					<option value=""><?php _e('None', 'wp-testimonial-with-widget'); ?></option>
					<?php for( $i=1; $i<=5; $i++ ) { ?>
					<option value="<?php echo $i; ?>" <?php selected( $rating, $i ); ?>><?php echo $i; ?></option>
					<?php } ?>
				</select>
			</td>
		</tr>

	</tbody>
</table><!-- end .wtwp-tstmnl-table -->
<?php
/**
 * Settings Page
 *
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

?>

<div class="wrap wtwp-settings">

<h2><?php _e( 'WP Testimonials Settings', 'wp-testimonial-with-widget' ); ?></h2><br />

<?php
// Success message
if( isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true' ) {
	echo '<div id="message" class="updated notice notice-success is-dismissible">
			<p><strong>'.__("Your changes saved successfully.", "wp-testimonial-with-widget").'</strong></p>
		  </div>';
}
?>

<form action="options.php" method="POST" id="wtwp-settings-form" class="wtwp-settings-form">
	
	<?php
	    settings_fields( 'wtwp_pro_plugin_options' );
	    global $wtwp_pro_options;
	?>

	<div id="wtwp-general-sett" class="post-box-container wtwp-general-sett">
		<div class="metabox-holder">
			<div class="meta-box-sortables ui-sortable">
				<div id="general" class="postbox">

					<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'General Settings', 'wp-testimonial-with-widget' ); ?></span>
						</h3>
						
						<div class="inside">
						
						<table class="form-table wtwp-general-sett-tbl">
							<tbody>
								<tr>
									<th scope="row">
										<label for="wtwp-pro-default-img"><?php _e('Default Featured Image', 'wp-testimonial-with-widget'); ?>:</label>
									</th>
									<td>
										<input type="text" name="wtwp_pro_options[default_img]" value="<?php echo wtwp_pro_esc_attr( wtwp_pro_get_option('default_img') ); ?>" id="wtwp-pro-default-img" class="regular-text wtwp-pro-default-img wtwp-pro-img-upload-input" />
										<input type="button" name="wtwp_pro_default_img" class="button-secondary wtwp-pro-image-upload" value="<?php _e( 'Upload Image', 'wp-testimonial-with-widget'); ?>" data-uploader-title="<?php _e('Choose Logo', 'wp-testimonial-with-widget'); ?>" data-uploader-button-text="<?php _e('Insert Logo', 'wp-testimonial-with-widget'); ?>" /> <input type="button" name="wtwp_pro_default_img_clear" id="wtwp-pro-default-img-clear" class="button button-secondary wtwp-pro-image-clear" value="<?php _e( 'Clear', 'wp-testimonial-with-widget'); ?>" /> <br />
										<span class="description"><?php _e( 'Upload default featured image or provide an external URL of image. If your testimonial does not have image then this will be displayed instead blank box.', 'wp-testimonial-with-widget' ); ?></span>
										<?php
											$default_img = '';
											if( wtwp_pro_get_option('default_img') ) { 
												$default_img = '<img src="'.wtwp_pro_get_option('default_img').'" alt="" />';
											}
										?>
										<div class="wtwp-pro-img-view"><?php echo $default_img; ?></div>
									</td>
								</tr>
								<tr>
									<td colspan="2" valign="top" scope="row">
										<input type="submit" id="wtwp-settings-submit" name="wtwp-settings-submit" class="button button-primary right" value="<?php _e('Save Changes','wp-testimonial-with-widget'); ?>" />
									</td>
								</tr>
							</tbody>
						 </table>

					</div><!-- .inside -->
				</div><!-- #general -->
			</div><!-- .meta-box-sortables ui-sortable -->
		</div><!-- .metabox-holder -->
	</div><!-- #wtwp-general-sett -->
	<!-- General Settings Ends -->

	<!-- Custom CSS Settings Starts -->
	<div id="wtwp-custom-css-sett" class="post-box-container wtwp-custom-css-sett">
		<div class="metabox-holder">
			<div class="meta-box-sortables ui-sortable">
				<div id="custom-css" class="postbox">

					<button class="handlediv button-link" type="button"><span class="toggle-indicator"></span></button>

						<!-- Settings box title -->
						<h3 class="hndle">
							<span><?php _e( 'Custom CSS Settings', 'wp-testimonial-with-widget' ); ?></span>
						</h3>
						
						<div class="inside">
						
						<table class="form-table wtwp-custom-css-sett-tbl">
							<tbody>
								<tr>
									<th scope="row">
										<label for="wtwp-custom-css"><?php _e('Custom Css', 'wp-testimonial-with-widget'); ?>:</label>
									</th>
									<td>
										<textarea name="wtwp_pro_options[custom_css]" class="large-text wtwp-custom-css" id="wtwp-custom-css" rows="15"><?php echo wtwp_pro_esc_attr(wtwp_pro_get_option('custom_css')); ?></textarea><br/>
										<span class="description"><?php _e('Enter custom CSS to override plugin CSS.', 'wp-testimonial-with-widget'); ?></span>
									</td>
								</tr>
								<tr>
									<td colspan="2" valign="top" scope="row">
										<input type="submit" id="wtwp-settings-submit" name="wtwp-settings-submit" class="button button-primary right" value="<?php _e('Save Changes','wp-testimonial-with-widget'); ?>" />
									</td>
								</tr>
							</tbody>
						 </table>

					</div><!-- .inside -->
				</div><!-- #custom-css -->
			</div><!-- .meta-box-sortables ui-sortable -->
		</div><!-- .metabox-holder -->
	</div><!-- #wtwp-custom-css-sett -->
	<!-- Custom CSS Settings Ends -->

</form><!-- end .wtwp-settings-form -->

</div><!-- end .wtwp-settings -->
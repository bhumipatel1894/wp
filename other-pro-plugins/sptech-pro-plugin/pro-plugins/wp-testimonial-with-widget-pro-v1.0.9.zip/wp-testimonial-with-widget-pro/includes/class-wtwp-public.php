<?php
/**
 * Public Class
 *
 * Handles front side functionality of plugin
 *
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Wtwp_Public {
	
	function __construct() {
		
		// Action to handle submission of testimonial
		add_action('wp', array($this, 'wtwp_process_testimonial_submission'));
	}
	
	/**
	 * Function to handle testimonial form submission process
	 * 
	 * @package WP Testimonials with rotator widget Pro
	 * @since 1.0.0
	 */
	function wtwp_process_testimonial_submission() {

		// If form is posted
		if( isset($_POST['wtwp_tstmnl_submit']) && !empty($_POST['wtwp_tstmnl_submit']) ){

			global $post, $current_user, $wtwp_form_error;

			// Taking some defaults
			$prefix 			= WTWP_META_PREFIX; // Taking metabox prefix
			$wtwp_form_error 	= array();
			
			$wtwp_form_err_mgs 		= wtwp_pro_tstmnl_form_msgs();
			$testimonial_title 		= isset($_POST['title']) 				? wtwp_slashes_deep(trim($_POST['title'])) 					: '';
			$testimonial_content 	= isset($_POST['content']) 				? wtwp_slashes_deep(trim($_POST['content'])) 				: '';
			$testimonial_category 	= isset($_POST['category']) 			? wtwp_slashes_deep(trim($_POST['category'])) 				: '';
			$client_name 			= isset($_POST['testimonial_client']) 	? wtwp_slashes_deep(trim($_POST['testimonial_client'])) 	: '';
			$job_title 				= isset($_POST['testimonial_job']) 		? wtwp_slashes_deep(trim($_POST['testimonial_job'])) 		: '';
			$company 				= isset($_POST['testimonial_company']) 	? wtwp_slashes_deep(trim($_POST['testimonial_company'])) 	: '';
			$website 				= isset($_POST['testimonial_url']) 		? wtwp_slashes_deep(trim($_POST['testimonial_url'])) 		: '';
			$rating 				= isset($_POST['rating']) 				? wtwp_slashes_deep(trim($_POST['rating'])) 				: '';
			$captcha				= isset($_POST['captcha']) 				? wtwp_slashes_deep(trim($_POST['captcha'])) 				: '';
			$image					= isset($_FILES['tstmnl_image'])		? $_FILES['tstmnl_image'] : '';

			// If title is empty
			if( empty($testimonial_title) ) {
				$wtwp_form_error['title'] = isset($wtwp_form_err_mgs['title']) ? $wtwp_form_err_mgs['title'] : '';
			}

			// If testimonial content is empty
			if( empty($testimonial_content) ){
				$wtwp_form_error['content'] = isset($wtwp_form_err_mgs['content']) ? $wtwp_form_err_mgs['content'] : '';
			}

			// If client name is empty
			if( empty($client_name) ){
				$wtwp_form_error['client_name'] = isset($wtwp_form_err_mgs['client_name']) ? $wtwp_form_err_mgs['client_name'] : '';
			}

			// If client name is empty
			if( empty($captcha) || $captcha != 3 ) {
				$wtwp_form_error['captcha'] = isset($wtwp_form_err_mgs['captcha']) ? $wtwp_form_err_mgs['captcha'] : '';
			}
			
			// Check uploaded image
			if( isset($_FILES['tstmnl_image']) && !empty($_FILES['tstmnl_image']['name']) ){
				$allowed_file_type	= array( 'jpg', 'jpeg', 'png', 'gif', 'bmp' );						// Allowed file types
				$check_file_type 	= wp_check_filetype($_FILES['tstmnl_image']['name']);				// Check uploaded file type
				$file_ext			= isset($check_file_type['ext']) ? $check_file_type['ext'] : '';	// Taking uploaded file extention

				// Checking proper file types
				if( !in_array($file_ext, $allowed_file_type) ) {
					$wtwp_form_error['image'] = isset($wtwp_form_err_mgs['image']) ? $wtwp_form_err_mgs['image'] : '';
				}
			}
			
			// If there is no error
			if( empty($wtwp_form_error) ){

				// Creating testimonial
				$post_data = array(
									  'post_title'    	=> $testimonial_title,
									  'post_content'  	=> $testimonial_content,
									  'post_status'   	=> 'pending',
									  'post_author'   	=> !empty($current_user->ID) ? $current_user->ID : 0,
									  'post_type'		=> WTWP_POST_TYPE
									);
				 
				// Insert the post into the database
				$wtwp_post_id = wp_insert_post( $post_data );

				// If post is inserted successfully
				if( !empty($wtwp_post_id) ) {

					// Inserting post meta
					update_post_meta($wtwp_post_id, '_testimonial_client', $client_name);
					update_post_meta($wtwp_post_id, '_testimonial_job', $job_title);
					update_post_meta($wtwp_post_id, '_testimonial_company', $company);
					update_post_meta($wtwp_post_id, '_testimonial_url', $website);
					update_post_meta($wtwp_post_id, $prefix.'rating', $rating);
					
					// Set categories to post
					// Note: Here integer type casting is necessary, Otherwise it creates new category
					if($testimonial_category){
						wp_set_object_terms( $wtwp_post_id, (int)$testimonial_category, WTWP_CAT );
					}

					/***** End of file upload process *****/
					// If file is submitted
					if( !empty($_FILES['tstmnl_image']) && !empty($_FILES['tstmnl_image']['name']) ) {

						// Need to require these files
						if ( !function_exists('media_handle_upload') ) {
							require_once(ABSPATH . "wp-admin" . '/includes/image.php');
							require_once(ABSPATH . "wp-admin" . '/includes/file.php');
							require_once(ABSPATH . "wp-admin" . '/includes/media.php');
						}

						$attach_id = media_handle_upload( 'tstmnl_image', $wtwp_post_id );

						// Set post thumbnail
						if ( !is_wp_error( $attach_id ) ) {
							set_post_thumbnail( $wtwp_post_id, $attach_id );
						}
					}
					/***** End of file upload process *****/
				}

				$redirect_url = get_permalink();
				$redirect_url = add_query_arg( array('success' => true), $redirect_url );
				wp_redirect( $redirect_url );
				exit;
			}
		} // End of main if
	}
}

$wtwp_public = new Wtwp_Public();
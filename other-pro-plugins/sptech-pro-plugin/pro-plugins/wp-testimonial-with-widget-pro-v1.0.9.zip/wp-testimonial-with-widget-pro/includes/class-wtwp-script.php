<?php
/**
 * Script Class
 *
 * Handles the script and style functionality of plugin
 *
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Wtwp_Script {
	
	function __construct(){

		// Action to add style on frontend
		add_action( 'wp_enqueue_scripts', array($this, 'wtwp_front_end_style') );

		// Action to add script on frontend
		add_action( 'wp_enqueue_scripts', array($this, 'wtwp_front_end_script'), 15 );

		// Action to add style in backend
		add_action( 'admin_enqueue_scripts', array($this, 'wtwp_pro_admin_style') );

		// Action to add script at admin side
		add_action( 'admin_enqueue_scripts', array($this, 'wtwp_pro_admin_script') );

		// Action to add custom css in head
		add_action( 'wp_head', array($this, 'wtwp_pro_custom_css'), 20 );
	}

	/**
	 * Function to add style at front side
	 * 
	 * @package WP Testimonials with rotator widget Pro
	 * @since 1.0.0
	 */
	function wtwp_front_end_style() {

		// Registring and enqueing font awesome css
		if( !wp_style_is( 'wpos-font-awesome', 'registered' ) ) {
			wp_register_style( 'wpos-font-awesome', WTWP_URL.'assets/css/font-awesome.min.css', null, WTWP_VERSION );
			wp_enqueue_style( 'wpos-font-awesome' );
		}

		// Registring slider style
		wp_register_style( 'wtwp-pro-slick-style', WTWP_URL.'assets/css/slick.css', null, WTWP_VERSION );
		wp_enqueue_style('wtwp-pro-slick-style');

		// Registring testimonials style
		wp_register_style( 'wtwp-pro-public-style', WTWP_URL.'assets/css/wtwp-pro-public.css', null, WTWP_VERSION );
		wp_enqueue_style( 'wtwp-pro-public-style' );
	}

	/**
	 * Function to add script at front side
	 * 
	 * @package WP Testimonials with rotator widget Pro
	 * @since 1.0.0
	 */
	function wtwp_front_end_script() {
		
		// Registring slick slider script
		if( !wp_script_is( 'wpos-slick-jquery', 'registered' ) ) {
			wp_register_script( 'wpos-slick-jquery', WTWP_URL.'assets/js/slick.min.js', array('jquery'), WTWP_VERSION, true );
		}
		
		// Registring public script
		wp_register_script( 'wtwp-pro-public-script', WTWP_URL.'assets/js/wtwp-pro-public.js', array('jquery'), WTWP_VERSION, true );
		wp_localize_script( 'wtwp-pro-public-script', 'WtwpPro', array(
																	'is_mobile' 		=> (wp_is_mobile()) ? 	1 	: 0,
																	'is_rtl' 			=> (is_rtl()) 		? 	1 	: 0,
																	'form_error'		=> wtwp_pro_tstmnl_form_msgs(),
																));
	}
	
	/**
	 * Enqueue admin styles
	 * 
	 * @package WP Testimonials with rotator widget Pro
	 * @since 1.0.0
	 */
	function wtwp_pro_admin_style( $hook ) {

		global $typenow;
		
		// If page is plugin setting page then enqueue script
		if( $typenow == WTWP_POST_TYPE ) {
			
			// Registring admin script
			wp_register_style( 'wtwp-pro-admin-css', WTWP_URL.'assets/css/wtwp-pro-admin.css', null, WTWP_VERSION );
			wp_enqueue_style( 'wtwp-pro-admin-css' );
		}
	}
	
	/**
	 * Function to add script at admin side
	 * 
	 * @package WP Testimonials with rotator widget Pro
	 * @since 1.0.0
	 */
	function wtwp_pro_admin_script( $hook ) {
		
		global $wp_version, $wp_query, $post_type;

		$new_ui = $wp_version >= '3.5' ? '1' : '0'; // Check wordpress version for older scripts

		// Pages array
		$pages_array = array( 'testimonial_page_wtwp-pro-settings' );

		// If page is plugin setting page then enqueue script
		if( in_array($hook, $pages_array) ) {

			// Registring admin script
			wp_register_script( 'wtwp-pro-admin-js', WTWP_URL.'assets/js/wtwp-pro-admin.js', array('jquery'), WTWP_VERSION, true );
			wp_localize_script( 'wtwp-pro-admin-js', 'WtwpProAdmin', array(
																	'new_ui' =>	$new_ui
																));
			wp_enqueue_script( 'wtwp-pro-admin-js' );
			wp_enqueue_media(); // For media uploader
		}

		// Product sorting - only when sorting by menu order on the testimonial listing page
	    if ( $post_type == WTWP_POST_TYPE && isset( $wp_query->query['orderby'] ) && $wp_query->query['orderby'] == 'menu_order title' ) {
	        wp_register_script( 'wtwp-pro-ordering', WTWP_URL . 'assets/js/wtwp-pro-ordering.js', array( 'jquery-ui-sortable' ), WTWP_VERSION, true );
	        wp_enqueue_script( 'wtwp-pro-ordering' );
	    }
	}

	/**
	 * Add custom css to head
	 * 
	 * @package WP Testimonials with rotator widget Pro
	 * @since 1.0.0
	 */
	function wtwp_pro_custom_css() {

		$custom_css = wtwp_pro_get_option('custom_css');
		
		if( !empty($custom_css) ) {
			$css  = '<style type="text/css">' . "\n";
			$css .= $custom_css;
			$css .= "\n" . '</style>' . "\n";

			echo $css;
		}
	}
}

$wtwp_script = new Wtwp_Script();
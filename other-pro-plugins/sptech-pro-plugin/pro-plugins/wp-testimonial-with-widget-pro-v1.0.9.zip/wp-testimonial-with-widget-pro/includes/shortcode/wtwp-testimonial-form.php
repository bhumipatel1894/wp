<?php
/**
 * 'sp_testimonials_form' Shortcodes
 *
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Function to handle testimonial form
 * 
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */
function wtwp_sp_testimonials_form( $atts, $content ){
	
	// Getting attributes of shortcode
	extract( shortcode_atts( array(
		), $atts ) );
	
	// Enqueuing required script
	wp_enqueue_script('wtwp-public-script');

	ob_start();
	include( WTWP_DIR . '/templates/wtwp-testimonial-form.php' );
	$content .= ob_get_clean();

	return $content;
}

// Testimonial form shortcode
add_shortcode( 'sp_testimonials_form', 'wtwp_sp_testimonials_form' );
<?php
/**
 * `sp_testimonials` Shortcode
 * 
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Function to handle testimonial shortcode
 * 
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */
function wtwp_pro_testimonial_grid( $atts, $content ) {
	
	extract(shortcode_atts(array(
		'limit' 				=> 20,
		'design'            	=> 'design-1',
		'per_row' 				=> 3,
		'orderby' 				=> 'date',
		'order' 				=> 'DESC',
		'category' 				=> '',
		'include_cat_child'		=> 'true',
		'display_client' 		=> 'true',
		'display_avatar' 		=> 'true',
		'display_job' 			=> 'true',
		'display_company' 		=> 'true',
		'image_style'       	=> 'circle',
		'size' 					=> 100,
		'show_rating'			=> 'true',
		'show_title'			=> 'true',
		'posts'					=> array(),
		'exclude_post'			=> array(),
		'exclude_cat'			=> array(),
	), $atts));

	$shortcode_designs 	= wtwp_pro_testimonials_designs();
	$limit 				= !empty($limit) 					? $limit 						: '20';
	$design 			= ($design && (array_key_exists(trim($design), $shortcode_designs))) ? trim($design) 	: 'design-1';
	$per_row			= !empty($per_row) 					? $per_row 						: '3';
	$orderby 			= !empty($orderby) 					? $orderby 						: 'date';
	$order 				= ( strtolower($order) == 'asc' ) 	? 'ASC' 						: 'DESC';
	$cat 				= (!empty($category))				? explode(',',$category) 		: '';
	$exclude_cat 		= !empty($exclude_cat)				? explode(',', $exclude_cat) 	: array();
	$display_client 	= ( $display_client == 'true' ) 	? 'true' 						: 'false';
	$display_avatar 	= ( $display_avatar == 'true' ) 	? 'true' 						: 'false';
	$display_job 		= ( $display_job == 'true' ) 		? 'true' 						: 'false';
	$display_company	= ( $display_company == 'true' ) 	? 'true' 						: 'false';
	$show_rating 		= ( $show_rating == 'true' ) 		? 'true' 						: 'false';
	$show_title 		= ( $show_title == 'true' ) 		? 'true' 						: 'false';
	$image_style 		= ( $image_style == 'circle' ) 		? 'wtwp-circle' 				: 'wtwp-square';
	$size 				= !empty($size) 					? $size 						: '300';
	$exclude_post 		= !empty($exclude_post)				? explode(',', $exclude_post) 	: array();
	$posts 				= !empty($posts)					? explode(',', $posts) 			: array();

	$testimonialsdesign 	= WTWP_DIR . '/templates/designs/' . $design . '.php';
	$design_file 			= (file_exists($testimonialsdesign)) ? $testimonialsdesign : '';

	// Taking some globals
	global $post;

	// Taking some variables
	$prefix 	= WTWP_META_PREFIX;
	$count 		= 0;
	$tper_row	= wtwp_pro_grid_column( $per_row );
	$class 		= ' wtwp-medium-'.$tper_row.' wtwp-columns ';

	// Query Parameter
	$args = array (
		'post_type'      		=> WTWP_POST_TYPE,
		'post_status'			=> array( 'publish' ),
		'order'          		=> $order,
		'orderby'        		=> $orderby,
		'posts_per_page' 		=> $limit,
		'post__not_in'			=> $exclude_post,
		'post__in'				=> $posts,
		'ignore_sticky_posts'	=> true,
	);

	// Category Parameter
	if($cat != '') {

		$args['tax_query'] = array(
								array(
									'taxonomy' 			=> WTWP_CAT,
									'field' 			=> 'term_id',
									'terms' 			=> $cat,
									'include_children'	=> $include_cat_child,
							));

	} elseif( !empty($exclude_cat) ) {

		$args['tax_query'] = array(
								array(
									'taxonomy' 			=> WTWP_CAT,
									'field' 			=> 'term_id',
									'terms' 			=> $exclude_cat,
									'operator'			=> 'NOT IN',
									'include_children'	=> $include_cat_child,
							));
	}

	// WP Query
	$query = new WP_Query($args);

	ob_start();

	// If post is there
	if ( $query->have_posts() ) { ?>

		<div class="wtwp-testimonials-wrp wtwp-testimonials-list <?php echo 'wtwp-'.$design; ?> wtwp-clearfix">
		
		<?php while ( $query->have_posts() ) : $query->the_post();

				$count++;
				$css_class = 'wtwp-quote';

				$pertestimonial_image 	= wtwp_pro_get_image($post->ID, $size, $image_style);
				$pertestimonial_client 	= get_post_meta($post->ID, '_testimonial_client', true);
				$pertestimonial_job 	= get_post_meta($post->ID, '_testimonial_job', true);
				$pertestimonial_company = get_post_meta($post->ID, '_testimonial_company', true);
				$pertestimonial_url 	= get_post_meta($post->ID, '_testimonial_url', true);
				$pertestimonial_rating 	= get_post_meta($post->ID, $prefix.'rating', true);

				if ( ( is_numeric( $per_row ) && ( $per_row > 0 ) && ( 0 == ( $count - 1 ) % $per_row ) ) || 1 == $count ) { $css_class .= ' wtwp-first'; }
				if ( ( is_numeric( $per_row ) && ( $per_row > 0 ) && ( 0 == $count % $per_row ) ) || count( $query ) == $count ) { $css_class .= ' wtwp-last'; }

				// Add a CSS class if no image is available.
				if ( isset( $pertestimonial_image ) && ( $pertestimonial_image == '' ) ) {
					$css_class .= ' wtwp-no-image';
				}

				$testimonial_job = ($display_job == 'true' && $pertestimonial_job != '') ? $pertestimonial_job : "";
				$testimonial_job .= ($display_company == 'true' && $pertestimonial_company != '' && $display_job == 'true' && $pertestimonial_job != '') ? " / ": "";

				if( $display_company == 'true' && $pertestimonial_company != '' ){
					$testimonial_job .= (!empty($pertestimonial_url)) ? '<a href="'.$pertestimonial_url.'" target="_blank">'.$pertestimonial_company.'</a>' : $pertestimonial_company;
				}

				$author = ($display_client == 'true' && $pertestimonial_client != '') ? '<strong>'.$pertestimonial_client.'</strong>' : "";

				// Include shortcode html file
				if( $design_file ) {
					include( $testimonialsdesign );
				}

			endwhile; ?>

		</div><!-- end .wtwp-testimonials-wrp -->

	<?php } // end of have_post()

	wp_reset_query(); // Reset WP Query

	$content .= ob_get_clean();
	return $content;
}

// 'sp_testimonials' Testimonial shortcode
add_shortcode( 'sp_testimonials', 'wtwp_pro_testimonial_grid' );
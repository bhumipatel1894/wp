<?php
/**
 * `sp_testimonials_slider` Shortcode
 * 
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Function to handle testimonial slider shortcode
 * 
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */
function wtwp_pro_testimonial_slider( $atts, $content ) {
	
	// Shortcode Parameter
	extract(shortcode_atts(array(
		'limit' 				=> 20,
		'design'            	=> 'design-1',
		'orderby' 				=> 'date',
		'order' 				=> 'DESC',
		'slides_column'     	=> 2,
		'slides_scroll'     	=> 1,
		'category' 				=> '',
		'include_cat_child'		=> 'true',
		'display_client' 		=> 'true',
		'display_avatar' 		=> 'true',
		'display_job' 			=> 'true',
		'display_company' 		=> 'true',
		'image_style'       	=> 'circle',
		'dots'     				=> 'true',
		'arrows'     			=> 'true',
		'autoplay'     			=> 'true',
		'autoplay_interval' 	=> 3000,
		'speed'             	=> 300,
		'size' 					=> 100,
		'show_rating'			=> 'true',
		'show_title'			=> 'true',
		'loop'					=> 'true',
		'effect'				=> 'slide',
		'center_mode'			=> 'false',
		'posts'					=> array(),
		'exclude_post'			=> array(),
		'exclude_cat'			=> array(),
		'rtl'					=> false,
	), $atts));
	
	$shortcode_designs 	= wtwp_pro_testimonials_designs();
	$limit 				= !empty($limit) 					? $limit 						: 20;
	$design 			= ($design && (array_key_exists(trim($design), $shortcode_designs))) ? trim($design) 	: 'design-1';
	$orderby 			= !empty($orderby) 					? $orderby 						: 'date';
	$order 				= ( strtolower($order) == 'asc' ) 	? 'ASC' 						: 'DESC';
	$slides_column 		= !empty($slides_column) 			? $slides_column				: '2';
	$slides_scroll 		= !empty($slides_scroll) 			? $slides_scroll 				: '1';
	$cat 				= (!empty($category))				? explode(',',$category) 		: '';
	$exclude_cat 		= !empty($exclude_cat)				? explode(',', $exclude_cat) 	: array();
	$display_client 	= ( $display_client == 'true' ) 	? 'true' 						: 'false';
	$display_avatar 	= ( $display_avatar == 'true' ) 	? 'true' 						: 'false';
	$display_job 		= ( $display_job == 'true' ) 		? 'true' 						: 'false';
	$display_company	= ( $display_company == 'true' ) 	? 'true' 						: 'false';
	$show_rating 		= ( $show_rating == 'true' ) 		? 'true' 						: 'false';
	$show_title 		= ( $show_title == 'true' ) 		? 'true' 						: 'false';
	$image_style 		= ( $image_style == 'circle' ) 		? 'wtwp-circle' 				: 'wtwp-square';
	$dots 				= ( $dots == 'true' ) 				? 'true' 						: 'false';
	$arrows 			= ( $arrows == 'true' ) 			? 'true' 						: 'false';
	$loop 				= ( $loop == 'true' ) 				? 'true' 						: 'false';
	$autoplay 			= ( $autoplay == 'true' ) 			? 'true' 						: 'false';
	$autoplay_interval 	= !empty($autoplay_interval) 		? $autoplay_interval 			: '2000';
	$speed 				= !empty($speed) 					? $speed 						: '300';
	$size 				= !empty($size) 					? $size 						: '100';
	$exclude_post 		= !empty($exclude_post)				? explode(',', $exclude_post) 	: array();
	$posts 				= !empty($posts)					? explode(',', $posts) 			: array();
	$center_mode 		= ( $center_mode == 'true' ) 		? 'true' 						: 'false';
	$effect 			= ( $effect == 'fade' ) 			? 'true' 						: 'false';

	// Shortcode File
	$testimonialsdesign 	= WTWP_DIR . '/templates/designs/' . $design . '.php';
	$design_file 			= (file_exists($testimonialsdesign)) ? $testimonialsdesign : '';

	// For RTL
	if( empty($rtl) && is_rtl() ) {
		$rtl = 'true';
	} elseif ( $rtl == 'true' ) {
		$rtl = 'true';
	} else {
		$rtl = 'false';
	}

	// Taking some globals
	global $post;

	// Taking some variables
	$prefix 			= WTWP_META_PREFIX;
	$class 				= '';
	$center_mode_cls 	= ($center_mode == 'true') ? 'wtwp-center' : '';
	$unique				= wtwp_pro_get_unique();

	// Slider configuration
	$slider_conf = compact('slides_column', 'slides_scroll', 'dots', 'loop', 'arrows', 'autoplay', 'autoplay_interval', 'speed', 'center_mode', 'effect', 'rtl');
	
	// Enqueing required script
	wp_enqueue_script('wpos-slick-jquery');
	wp_enqueue_script('wtwp-pro-public-script');

	// Query Parameter
	$args = array (
		'post_type'      		=> WTWP_POST_TYPE,
		'post_status'			=> array( 'publish' ),
		'order'          		=> $order,
		'orderby'        		=> $orderby,
		'posts_per_page' 		=> $limit,
		'post__in'				=> $posts,
		'post__not_in'			=> $exclude_post,
		'ignore_sticky_posts'	=> true,
	);

	// Category Parameter
	if($cat != "") {

		$args['tax_query'] = array(
								array(
									'taxonomy' 			=> WTWP_CAT,
									'field' 			=> 'term_id',
									'terms' 			=> $cat,
									'include_children'	=> $include_cat_child,
								));

	} elseif(!empty($exclude_cat)) {

		$args['tax_query'] = array(
								array(
									'taxonomy' 			=> WTWP_CAT,
									'field' 			=> 'term_id',
									'terms' 			=> $exclude_cat,
									'operator'			=> 'NOT IN',
									'include_children'	=> $include_cat_child,
								));
	}

	// WP Query
	$query = new WP_Query($args);

	ob_start();

	// If post is there
	if ( $query->have_posts() ) { ?>

		<div class="wtwp-pro-slider-wrp">
			<div class="wtwp-pro-testimonials-slider wtwp-testimonials-slidelist <?php echo 'wtwp-'.$design.' '.$center_mode_cls; ?> <?php echo "wtwp-slider-clmn-".$slides_column; ?>" id="wtwp-pro-testimonials-<?php echo $unique; ?>">
				
				<?php while ( $query->have_posts() ) : $query->the_post();

					$css_class = 'wtwp-quote';

					$pertestimonial_image 	= wtwp_pro_get_image($post->ID, $size, $image_style);
					$pertestimonial_client 	= get_post_meta($post->ID, '_testimonial_client', true);
					$pertestimonial_job 	= get_post_meta($post->ID, '_testimonial_job', true);
					$pertestimonial_company = get_post_meta($post->ID, '_testimonial_company', true);
					$pertestimonial_url 	= get_post_meta($post->ID, '_testimonial_url', true);
					$pertestimonial_rating 	= get_post_meta($post->ID, $prefix.'rating', true);

					// Add a CSS class if no image is available.
					if ( isset( $pertestimonial_image ) && ( $pertestimonial_image ==  '' ) ) {
						$css_class .= ' wtwp-no-image';
					}

					$testimonial_job = ($display_job == 'true' && $pertestimonial_job != '') ? $pertestimonial_job : "";
					$testimonial_job .= ($display_company == 'true' && $pertestimonial_company != '' && $display_job == 'true' && $pertestimonial_job != '') ? " / ": "";

					if( $display_company == 'true' && $pertestimonial_company != '' ){
						$testimonial_job .= (!empty($pertestimonial_url)) ? '<a href="'.$pertestimonial_url.'" target="_blank">'.$pertestimonial_company.'</a>' : $pertestimonial_company;
					}

					$author = ($display_client == 'true' && $pertestimonial_client != '') ? '<strong>'.$pertestimonial_client.'</strong>' : "";

					// Include shortcode html file
					if( $design_file ) {
						include( $testimonialsdesign );
					}

				endwhile;
				?>
			</div><!-- end .wtwp-pro-testimonials-slider -->
			<div class="wtwp-pro-slider-conf"><?php echo json_encode( $slider_conf ); ?></div>
		</div><!-- end .wtwp-pro-slider-wrp -->

		<?php } // End of have_post()
		
		wp_reset_query(); // Reset WP Query

		$content .= ob_get_clean();
		return $content;
}

// Testimonial slider shortcode
add_shortcode( 'sp_testimonials_slider', 'wtwp_pro_testimonial_slider' );
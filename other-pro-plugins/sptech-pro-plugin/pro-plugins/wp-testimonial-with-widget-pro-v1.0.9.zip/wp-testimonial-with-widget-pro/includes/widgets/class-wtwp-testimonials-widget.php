<?php
/**
 * Widget Class
 *
 * Handles testimonial widget functionality of plugin
 *
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' )) exit;

function wtwp_pro_testimonial_widget() {
    register_widget( 'wtwp_pro_testimonials_widget' );
}

// Action to register widget
add_action( 'widgets_init', 'wtwp_pro_testimonial_widget' );

class wtwp_pro_testimonials_widget extends WP_Widget {

    /**
     * Sets up a new widget instance.
     *
     * @package WP Testimonials with rotator widget Pro
     * @since 1.0.0
     */
    function __construct() {

        $widget_ops = array( 'classname' => 'widget_sp_testimonials', 'description' => __( 'Display testimonials on your site.', 'wp-testimonial-with-widget' ) );
        parent::__construct( 'sp_testimonials', __( 'WP Testimonials Slider', 'wp-testimonial-with-widget' ), $widget_ops );
    }

    /**
     * Handles updating settings for the current widget instance.
     *
     * @package WP Testimonials with rotator widget Pro
     * @since 1.0.0
     */
    function update ( $new_instance, $old_instance ) {

        $instance = $old_instance;

        $instance['title']              = sanitize_text_field( $new_instance['title'] );
        $instance['limit']              = intval( $new_instance['limit'] );
        $instance['size']               = intval( $new_instance['size'] );
        $instance['slides_column']      = intval( $new_instance['slides_column'] );
        $instance['slides_scroll']      = intval( $new_instance['slides_scroll'] );
        $instance['category']           = intval( $new_instance['category'] );
        $instance['orderby']            = $new_instance['orderby'];
        $instance['order']              = $new_instance['order'];
        $instance['image_style']        = $new_instance['image_style'];
        $instance['design']             = $new_instance['design'];
        $instance['dots']               = $new_instance['dots'];
        $instance['arrows']             = $new_instance['arrows'];
        $instance['loop']               = $new_instance['loop'];
        $instance['autoplay']           = $new_instance['autoplay'];
        $instance['autoplayInterval']   = intval( $new_instance['autoplayInterval'] );
        $instance['speed']              = intval( $new_instance['speed'] );
        $instance['display_client']     = !empty($new_instance['display_client']) ? 1 : 0;
        $instance['display_avatar']     = !empty($new_instance['display_avatar']) ? 1 : 0;
        $instance['show_title']         = !empty($new_instance['show_title']) ? 1 : 0;
        $instance['display_job']        = !empty($new_instance['display_job']) ? 1 : 0;
        $instance['display_company']    = !empty($new_instance['display_company']) ? 1 : 0;
        $instance['show_rating']        = !empty($new_instance['show_rating']) ? 1 : 0;

        return $instance;
    }

    /**
     * Outputs the settings form for the widget.
     *
     * @package WP Testimonials with rotator widget Pro
     * @since 1.0.0
     */
    function form( $instance ) {
        $defaults = array(
            'limit'             => 20,
            'orderby'           => 'date',
            'order'             => 'DESC',
            'title'             => '',
            'slides_column'     => 1,
            'slides_scroll'     => 1, 
            'category'          => '',
            'display_client'    => 1,
            'display_avatar'    => 1,
            'display_job'       => 1,
            'display_company'   => 1,
            'image_style'       => 'circle',
            'design'            => 'design-1',
            'dots'              => "true",
            'arrows'            => "true",
            'loop'              => 'true',
            'autoplay'          => "true",      
            'autoplayInterval'  => 3000,                
            'speed'             => 300,
            'size'              => 100,
            'show_title'        => 1,
            'show_rating'       => 1,
        );

        $instance       = wp_parse_args( (array) $instance, $defaults );
        $wtwp_designs   = wtwp_pro_testimonials_widget_designs();
    ?>
        
        <!-- Widget Title: Text Input -->
        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', 'wp-testimonial-with-widget' ); ?></label>
            <input type="text" name="<?php echo $this->get_field_name( 'title' ); ?>"  value="<?php echo esc_attr($instance['title']); ?>" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" />
        </p>

        <!-- Widget Order By: Select Input -->
        <p>
            <label for="<?php echo $this->get_field_id( 'design' ); ?>"><?php _e( 'Design:', 'wp-testimonial-with-widget' ); ?></label>
            <select name="<?php echo $this->get_field_name( 'design' ); ?>" class="widefat" id="<?php echo $this->get_field_id( 'design' ); ?>">
                <?php if( !empty($wtwp_designs) ) {
                    foreach ( $wtwp_designs as $k => $v ) { ?>
                        <option value="<?php echo $k; ?>"<?php selected( $instance['design'], $k ); ?>><?php echo $v; ?></option>
                <?php } } ?>
            </select>
        </p>

        <!-- Widget Limit: Text Input -->
        <p>
            <label for="<?php echo $this->get_field_id( 'limit' ); ?>"><?php _e( 'Limit:', 'wp-testimonial-with-widget' ); ?></label>
            <input type="number" name="<?php echo $this->get_field_name( 'limit' ); ?>"  value="<?php echo $instance['limit']; ?>" class="widefat" id="<?php echo $this->get_field_id( 'limit' ); ?>" min="-1" />
        </p>

        <!-- Widget Order: Design Style -->
         <p>
            <label for="<?php echo $this->get_field_id( 'orderby' ); ?>"><?php _e( 'Order By:', 'wp-testimonial-with-widget' ); ?></label>
            <select name="<?php echo $this->get_field_name( 'orderby' ); ?>" class="widefat" id="<?php echo $this->get_field_id( 'orderby' ); ?>">
                <option value="date" <?php selected( $instance['orderby'], 'date' ); ?>><?php _e( 'Date', 'wp-testimonial-with-widget' ); ?></option>
                <option value="modified" <?php selected( $instance['orderby'], 'modified' ); ?>><?php _e( 'Modified Date', 'wp-testimonial-with-widget' ); ?></option>
                <option value="ID" <?php selected( $instance['orderby'], 'ID' ); ?>><?php _e( 'ID', 'wp-testimonial-with-widget' ); ?></option>
                <option value="author" <?php selected( $instance['orderby'], 'author' ); ?>><?php _e( 'Author', 'wp-testimonial-with-widget' ); ?></option>
                <option value="title" <?php selected( $instance['orderby'], 'title' ); ?>><?php _e( 'Title', 'wp-testimonial-with-widget' ); ?></option>
                <option value="name" <?php selected( $instance['orderby'], 'name' ); ?>><?php _e( 'Testimonial URL Slug', 'wp-testimonial-with-widget' ); ?></option>
                <option value="rand" <?php selected( $instance['orderby'], 'rand' ); ?>><?php _e( 'Random', 'wp-testimonial-with-widget' ); ?></option>
                <option value="menu_order" <?php selected( $instance['orderby'], 'menu_order' ); ?>><?php _e( 'Menu Order', 'wp-testimonial-with-widget' ); ?></option>
            </select>
        </p>

        <!-- Widget Order: Select Input -->
        <p>
            <label for="<?php echo $this->get_field_id( 'order' ); ?>"><?php _e( 'Order:', 'wp-testimonial-with-widget' ); ?></label>
            <select name="<?php echo $this->get_field_name( 'order' ); ?>" class="widefat" id="<?php echo $this->get_field_id( 'order' ); ?>">
                <option value="ASC" <?php selected( $instance['order'], 'asc' ); ?>><?php _e( 'Ascending', 'wp-testimonial-with-widget' ); ?></option>
                <option value="DESC" <?php selected( $instance['order'], 'desc' ); ?>><?php _e( 'Descending', 'wp-testimonial-with-widget' ); ?></option>
            </select>
        </p>

        <!-- Widget Category: Select Input -->
        <p>
            <label for="<?php echo $this->get_field_id( 'category' ); ?>"><?php _e( 'Category:', 'wp-testimonial-with-widget' ); ?></label>
            <?php
                $dropdown_args = array(
                    'hide_empty'        => 0, 
                    'taxonomy'          => WTWP_CAT,
                    'class'             => 'widefat',
                    'show_option_all'   => __( 'All', 'wp-testimonial-with-widget' ),
                    'id'                => $this->get_field_id( 'category' ),
                    'name'              => $this->get_field_name( 'category' ),
                    'selected'          => $instance['category']
                );
                wp_dropdown_categories( $dropdown_args );
            ?>
        </p>

        <!-- Widget ID:  col -->
        <p>
            <label for="<?php echo $this->get_field_id( 'size' ); ?>"><?php _e( 'Image Size:', 'wp-testimonial-with-widget' ); ?></label>
            <input type="number" name="<?php echo $this->get_field_name( 'size' ); ?>"  value="<?php echo $instance['size']; ?>" class="widefat" id="<?php echo $this->get_field_id( 'slides_column' ); ?>" min="0" step="50" />
        </p>

        <!-- Widget ID:  size -->
        <p>
            <label for="<?php echo $this->get_field_id( 'slides_column' ); ?>"><?php _e( 'Slides Column:', 'wp-testimonial-with-widget' ); ?></label>
            <input type="number" name="<?php echo $this->get_field_name( 'slides_column' ); ?>"  value="<?php echo $instance['slides_column']; ?>" class="widefat" id="<?php echo $this->get_field_id( 'slides_column' ); ?>" min="1" />
        </p>

        <!-- Widget ID:  col to scroll -->
        <p>
            <label for="<?php echo $this->get_field_id( 'slides_scroll' ); ?>"><?php _e( 'Slides to Scroll:', 'wp-testimonial-with-widget' ); ?></label>
            <input type="number" name="<?php echo $this->get_field_name( 'slides_scroll' ); ?>"  value="<?php echo $instance['slides_scroll']; ?>" class="widefat" id="<?php echo $this->get_field_id( 'slides_scroll' ); ?>" min="1" />
        </p>

        <!-- Widget Order: Select Dots -->
        <p>
            <label for="<?php echo $this->get_field_id( 'dots' ); ?>"><?php _e( 'Dots:', 'wp-testimonial-with-widget' ); ?></label>
            <select name="<?php echo $this->get_field_name( 'dots' ); ?>" class="widefat" id="<?php echo $this->get_field_id( 'dots' ); ?>">
                <option value="true" <?php selected( $instance['dots'], 'true' ); ?>><?php _e( 'True', 'wp-testimonial-with-widget' ); ?></option>
                <option value="false" <?php selected( $instance['dots'], 'false' ); ?>><?php _e( 'False', 'wp-testimonial-with-widget' ); ?></option>
            </select>
        </p>

        <!-- Widget Order: Select Arrows -->
        <p>
            <label for="<?php echo $this->get_field_id( 'arrows' ); ?>"><?php _e( 'Arrows:', 'wp-testimonial-with-widget' ); ?></label>
            <select name="<?php echo $this->get_field_name( 'arrows' ); ?>" class="widefat" id="<?php echo $this->get_field_id( 'arrows' ); ?>">
                <option value="true" <?php selected( $instance['arrows'], 'true' ); ?>><?php _e( 'True', 'wp-testimonial-with-widget' ); ?></option>
                <option value="false" <?php selected( $instance['arrows'], 'false' ); ?>><?php _e( 'False', 'wp-testimonial-with-widget' ); ?></option>
            </select>
        </p>

        <!-- Widget Order: Loop -->
        <p>
            <label for="<?php echo $this->get_field_id( 'loop' ); ?>"><?php _e( 'Loop:', 'wp-testimonial-with-widget' ); ?></label>
            <select name="<?php echo $this->get_field_name( 'loop' ); ?>" class="widefat" id="<?php echo $this->get_field_id( 'loop' ); ?>">
                <option value="true" <?php selected( $instance['loop'], 'true' ); ?>><?php _e( 'True', 'wp-testimonial-with-widget' ); ?></option>
                <option value="false" <?php selected( $instance['loop'], 'false' ); ?>><?php _e( 'False', 'wp-testimonial-with-widget' ); ?></option>
            </select>
        </p>

        <!-- Widget ID:  Autoplay -->
        <p>
            <label for="<?php echo $this->get_field_id( 'autoplay' ); ?>"><?php _e( 'Auto Play:', 'wp-testimonial-with-widget' ); ?></label>
            <select name="<?php echo $this->get_field_name( 'autoplay' ); ?>" class="widefat" id="<?php echo $this->get_field_id( 'autoplay' ); ?>">
                <option value="true" <?php selected( $instance['autoplay'], 'true' ); ?>><?php _e( 'True', 'wp-testimonial-with-widget' ); ?></option>
                <option value="false" <?php selected( $instance['autoplay'], 'false' ); ?>><?php _e( 'False', 'wp-testimonial-with-widget' ); ?></option>
            </select>
        </p>

        <!-- Widget ID:  AutoplayInterval -->
        <p>
            <label for="<?php echo $this->get_field_id( 'autoplayInterval' ); ?>"><?php _e( 'Autoplay Interval:', 'wp-testimonial-with-widget' ); ?></label>
            <input type="number" name="<?php echo $this->get_field_name( 'autoplayInterval' ); ?>"  value="<?php echo $instance['autoplayInterval']; ?>" class="widefat" id="<?php echo $this->get_field_id( 'autoplayInterval' ); ?>" min="0" step="500" />
        </p>

        <!-- Widget ID:  Speed -->
        <p>
            <label for="<?php echo $this->get_field_id( 'speed' ); ?>"><?php _e( 'Speed:', 'wp-testimonial-with-widget' ); ?></label>
            <input type="number" name="<?php echo $this->get_field_name( 'speed' ); ?>"  value="<?php echo $instance['speed']; ?>" class="widefat" id="<?php echo $this->get_field_id( 'speed' ); ?>" min="0" step="100" />
        </p>

        <!-- Widget Order: Image Style -->
        <p>
            <label for="<?php echo $this->get_field_id( 'image_style' ); ?>"><?php _e( 'Image Style:', 'wp-testimonial-with-widget' ); ?></label>
            <select name="<?php echo $this->get_field_name( 'image_style' ); ?>" class="widefat" id="<?php echo $this->get_field_id( 'image_style' ); ?>">
                <option value="circle" <?php selected( $instance['image_style'], 'true' ); ?>><?php _e( 'Circle', 'wp-testimonial-with-widget' ); ?></option>
                <option value="square" <?php selected( $instance['image_style'], 'false' ); ?>><?php _e( 'Square', 'wp-testimonial-with-widget' ); ?></option>
            </select>
        </p>

        <!-- Widget Display Avatar: Checkbox Input -->
        <p>
            <input id="<?php echo $this->get_field_id( 'display_avatar' ); ?>" name="<?php echo $this->get_field_name( 'display_avatar' ); ?>" type="checkbox" value="1" <?php checked($instance['display_avatar'], 1); ?> />
            <label for="<?php echo $this->get_field_id( 'display_avatar' ); ?>"><?php _e( 'Display Avatar', 'wp-testimonial-with-widget' ); ?></label>
        </p>

        <!-- Widget Show title Checkbox Input -->
        <p>
            <input id="<?php echo $this->get_field_id( 'show_title' ); ?>" name="<?php echo $this->get_field_name( 'show_title' ); ?>" type="checkbox" value="1" <?php checked($instance['show_title'], 1); ?> />
            <label for="<?php echo $this->get_field_id( 'show_title' ); ?>"><?php _e( 'Display Title', 'wp-testimonial-with-widget' ); ?></label>
        </p>

        <!-- Widget Display Client: Checkbox Input -->
        <p>
            <input id="<?php echo $this->get_field_id( 'display_client' ); ?>" name="<?php echo $this->get_field_name( 'display_client' ); ?>" type="checkbox" value="1" <?php checked( $instance['display_client'], 1 ); ?> />
            <label for="<?php echo $this->get_field_id( 'display_client' ); ?>"><?php _e( 'Display Client', 'wp-testimonial-with-widget' ); ?></label>
        </p>

        <!-- Widget Display Job: Checkbox Input -->
        <p>
            <input id="<?php echo $this->get_field_id( 'display_job' ); ?>" name="<?php echo $this->get_field_name( 'display_job' ); ?>" type="checkbox" value="1" <?php checked($instance['display_job'], 1); ?> />
            <label for="<?php echo $this->get_field_id( 'display_job' ); ?>"><?php _e( 'Display Job', 'wp-testimonial-with-widget' ); ?></label>
        </p>

        <!-- Widget Display Company: Checkbox Input -->
        <p>
            <input id="<?php echo $this->get_field_id( 'display_company' ); ?>" name="<?php echo $this->get_field_name( 'display_company' ); ?>" type="checkbox" value="1" <?php checked($instance['display_company'], 1); ?> />
            <label for="<?php echo $this->get_field_id( 'display_company' ); ?>"><?php _e( 'Display Company', 'wp-testimonial-with-widget' ); ?></label>
        </p>

        <!-- Widget Rating Checkbox Input -->
        <p>
            <input id="<?php echo $this->get_field_id( 'show_rating' ); ?>" name="<?php echo $this->get_field_name( 'show_rating' ); ?>" type="checkbox" value="1" <?php checked($instance['show_rating'], 1); ?> />
            <label for="<?php echo $this->get_field_id( 'show_rating' ); ?>"><?php _e( 'Display Rating', 'wp-testimonial-with-widget' ); ?></label>
        </p>
    <?php
        } // End form()
    
    /**
    * Outputs the content for the current widget instance.
    *
    * @package WP Testimonials with rotator widget Pro
    * @since 1.0.0
    */
    function widget( $args, $instance ) {

        extract( $args, EXTR_SKIP );

        $title              = empty($instance['title']) ? '' : apply_filters('widget_title', $instance['title']);
        $shortcode_designs  = wtwp_pro_testimonials_designs();
        $limit              = !empty($instance['limit'])                    ? $instance['limit']                    : '5';
        $design             = ($instance['design'] && (array_key_exists(trim($instance['design']), $shortcode_designs))) ? trim($instance['design'])    : 'design-1';
        $orderby            = !empty($instance['orderby'])                  ? $instance['orderby']                  : 'post_date';
        $order              = ( strtolower($instance['order']) == 'asc' )   ? 'ASC'                                 : 'DESC';
        $slides_column      = !empty($instance['slides_column'])            ? $instance['slides_column']            : '3';
        $slides_scroll      = !empty($instance['slides_scroll'])            ? $instance['slides_scroll']            : '1';
        $cat                = (!empty($instance['category']))               ? explode(',',$instance['category'])    : '';
        $display_client     = ( $instance['display_client'] == 1 )          ? 'true'                                : 'false';
        $display_avatar     = ( $instance['display_avatar'] == 1 )          ? 'true'                                : 'false';
        $display_job        = ( $instance['display_job'] == 1 )             ? 'true'                                : 'false';
        $display_company    = ( $instance['display_company'] == 1 )         ? 'true'                                : 'false';
        $image_style        = ( $instance['image_style'] == 'circle' )      ? 'wtwp-circle'                         : 'wtwp-square';
        $dots               = ( $instance['dots'] == 'true' )               ? 'true'                                : 'false';
        $arrows             = ( $instance['arrows'] == 'true' )             ? 'true'                                : 'false';
        $loop               = ( $instance['loop'] == 'true' )               ? 'true'                                : 'false';
        $autoplay           = ( $instance['autoplay'] == 'true' )           ? 'true'                                : 'false';
        $autoplay_interval  = !empty($instance['autoplayInterval'])         ? $instance['autoplayInterval']         : '2000';
        $speed              = !empty($instance['speed'])                    ? $instance['speed']                    : '300';
        $size               = !empty($instance['size'])                     ? $instance['size']                     : '100';
        $show_title         = ( $instance['show_title'] == 1 )              ? 'true'                                : 'false';
        $show_rating        = ( $instance['show_rating'] == 1 )             ? 'true'                                : 'false';

        // Shortcode File
        $testimonialsdesign     = WTWP_DIR . '/templates/designs/' . $design . '.php';
        $design_file            = (file_exists($testimonialsdesign)) ? $testimonialsdesign : '';

        // Slider Configuration
        $slider_conf = compact('slides_column', 'slides_scroll', 'dots', 'arrows', 'autoplay', 'autoplay_interval', 'speed', 'loop', 'effect');
        
        // Enqueing required script
        wp_enqueue_script('wpos-slick-jquery');
        wp_enqueue_script('wtwp-pro-public-script');

        // Taking some globals
        global $post;

        // Taking some variables
        $prefix = WTWP_META_PREFIX;
        $class  = '';
        $unique = wtwp_pro_get_unique();

        // Query Parameter
        $args = array (
            'post_type'             => WTWP_POST_TYPE,
            'post_status'           => array( 'publish' ),
            'posts_per_page'        => $limit,
            'order'                 => $order,
            'orderby'               => $orderby,
            'ignore_sticky_posts'   => true,
        );

        // Category Parameter
        if($cat != "") {

            $args['tax_query'] = array(
                                    array(
                                        'taxonomy'  => WTWP_CAT,
                                        'field'     => 'term_id',
                                        'terms'     => $cat
                                    ));
        }

        // WP Query
        $query = new WP_Query($args);

        echo $before_widget;

        if ( $title ) {
            echo $before_title . $title . $after_title;
        }

        // If post is there
        if( $query->have_posts() ) {
    ?>
        <div class="wtwp-pro-slider-wrp">
            <div class="testimonials-slide-widget <?php echo 'wtwp-'.$design; ?>" id="wtwp-pro-testimonials-<?php echo $unique; ?>">
                    
                    <?php while ( $query->have_posts() ) : $query->the_post();

                        $css_class = 'wtwp-quote';

                        $pertestimonial_image   = wtwp_pro_get_image($post->ID, $size, $image_style);
                        $pertestimonial_client  = get_post_meta($post->ID, '_testimonial_client', true);
                        $pertestimonial_job     = get_post_meta($post->ID, '_testimonial_job', true);
                        $pertestimonial_company = get_post_meta($post->ID, '_testimonial_company', true);
                        $pertestimonial_url     = get_post_meta($post->ID, '_testimonial_url', true);
                        $pertestimonial_rating  = get_post_meta($post->ID, $prefix.'rating', true);

                        // Add a CSS class if no image is available.
                        if ( isset( $pertestimonial_image ) && ( $pertestimonial_image == '' ) ) {
                            $css_class .= ' wtwp-no-image';
                        }

                        $testimonial_job = ($display_job == 'true' && $pertestimonial_job != '') ? $pertestimonial_job : "";
                        $testimonial_job .= ($display_company == 'true' && $pertestimonial_company != '' && $display_job == 'true' && $pertestimonial_job != '') ? " / ": "";

                        if( $display_company == 'true' && $pertestimonial_company != '' ){
                            $testimonial_job .= (!empty($pertestimonial_url)) ? '<a href="'.$pertestimonial_url.'" target="_blank">'.$pertestimonial_company.'</a>' : $pertestimonial_company;
                        }

                        $author = ($display_client == 'true' && $pertestimonial_client != '') ? '<strong>'.$pertestimonial_client.'</strong>' : "";
                        
                        // Include shortcode html file
                        if( $design_file ) {
                            include( $testimonialsdesign );
                        }

                        endwhile;
                    ?>
            </div><!-- end .testimonials-slide-widget -->
            <div class="wtwp-pro-slider-conf"><?php echo json_encode( $slider_conf ); ?></div>
        </div><!-- end .wtwp-pro-slider-wrp -->

    <?php
        } // End of have_post()

        wp_reset_query(); // Reset WP Query

        echo $after_widget;
    }
}
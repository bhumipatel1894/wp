<?php
/**
 * Plugin generic functions file
 *
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;


/**
 * Update default settings
 * 
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */
function wtwp_pro_default_settings() {
	
	global $wtwp_pro_options;
	
	$wtwp_pro_options = array(
		'default_img'	=> '',
		'custom_css' 	=> '',
	);

	$default_options = apply_filters( 'wtwp_pro_options_default_values', $wtwp_pro_options );
	
	// Update default options
	update_option( 'wtwp_pro_options', $default_options );

	// Overwrite global variable when option is update
	$wtwp_pro_options = wtwp_pro_get_settings();
}


/**
 * Get Settings From Option Page
 * 
 * Handles to return all settings value
 * 
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */
function wtwp_pro_get_settings() {
	
	$options = get_option('wtwp_pro_options');
	
	$settings = is_array($options) 	? $options : array();
	
	return $settings;
}

/**
 * Escape Tags & Slashes. Handles escapping the slashes and tags
 *
 * @package  WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */
function wtwp_escape_attr($data){
	return esc_attr(stripslashes($data));
}

/**
 * Strip Slashes From Array
 * If $flag is passed then it will allow HTML
 *
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */
function wtwp_slashes_deep($data = array(), $flag = false){
	
	if($flag != true) {
		$data = wtwp_nohtml_kses($data);
	}

	$data = stripslashes_deep($data);
	return $data;
}

/**
 * Escape Tags & Slashes
 *
 * Handles escapping the slashes and tags
 *
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */
function wtwp_pro_esc_attr($data) {
	return esc_attr( stripslashes($data) );
}

/**
 * Get an option
 * Looks to see if the specified setting exists, returns default if not
 * 
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */
function wtwp_pro_get_option( $key = '', $default = false ) {
	global $wtwp_pro_options;

	$value = ! empty( $wtwp_pro_options[ $key ] ) ? $wtwp_pro_options[ $key ] : $default;
	$value = apply_filters( 'wtwp_pro_get_option', $value, $key, $default );
	return apply_filters( 'wtwp_pro_get_option_' . $key, $value, $key, $default );
}

/**
 * Strip Html Tags 
 * 
 * It will sanitize text input fields. Strip html tags and escape characters)
 * 
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */
function wtwp_nohtml_kses($data = array()){
	
	if ( is_array($data) ) {
		
		$data = array_map('wtwp_nohtml_kses', $data);
		
	} elseif ( is_string( $data ) ) {
		
		$data = wp_filter_nohtml_kses($data);
	}
	
	return $data;
}

/**
 * Function to add array after specific key
 * 
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */
function wtwp_pro_add_array(&$array, $value, $index, $from_last = false) {
    
    if( is_array($array) && is_array($value) ) {

        if( $from_last ) {
            $total_count    = count($array);
            $index          = (!empty($total_count) && ($total_count > $index)) ? ($total_count-$index): $index;
        }
        
        $split_arr  = array_splice($array, max(0, $index));
        $array      = array_merge( $array, $value, $split_arr);
    }
    
    return $array;
}

/**
 * Function to get user image
 * 
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */
function wtwp_pro_get_image ( $id, $size, $style = "wtwp-circle" ) {
		
	$response = '';

	if ( has_post_thumbnail( $id ) ) {
		// If not a string or an array, and not an integer, default to 150x9999.
		if ( ( is_int( $size ) || ( 0 < intval( $size ) ) ) && ! is_array( $size ) ) {
			$size = array( intval( $size ), intval( $size ) );
		} elseif ( ! is_string( $size ) && ! is_array( $size ) ) {
			$size = array( 100, 100 );
		}
		
		$response = get_the_post_thumbnail( intval( $id ), $size, array('class' => $style) );
		
	} else {
		
		$testimonial_email = get_post_meta( $id, '_testimonial_email', true );

		if ( $testimonial_email != '' && is_email( $testimonial_email ) ) {
			$response = get_avatar( $testimonial_email, $size );
		}
	}

	if($response == '') {
		
		$default_image = wtwp_pro_get_option('default_img');
		
		if(!empty($default_image)) {
			$response = '<img class="'.$style.'"  src="'.$default_image.'" width="'.$size.'" height="'.$size.'" alt="" />';
		}
	}
	return $response;
}

/**
 * Function to unique number value
 * 
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.3
 */
function wtwp_pro_get_unique() {
	static $unique = 0;
	$unique++;

	return $unique;
}

/**
 * Function to get grid column based on grid
 * 
 * @package WP Team Showcase and Slider Pro
 * @since 1.0.0
 */
function wtwp_pro_grid_column( $grid = '' ) {

	if($grid == '2') {
		$grid_clmn = '6';
	} else if($grid == '3') {
		$grid_clmn = '4';
	}  else if($grid == '4') {
		$grid_clmn = '3';
	} else if ($grid == '1') {
		$grid_clmn = '12';
	} else {
		$grid_clmn = '12';
	}
	
	return $grid_clmn;
}

/**
 * Function to get testimonial form messages
 * 
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.4
 */
function wtwp_pro_tstmnl_form_msgs() {
	
	$wtwp_form_error = array(
								'title' 		=> __('Please enter title.', 'wp-testimonial-with-widget'),
								'content' 		=> __('Please enter testimonial content.', 'wp-testimonial-with-widget'),
								'client_name' 	=> __('Please enter client name.', 'wp-testimonial-with-widget'),
								'captcha' 		=> __('Please answer the anti-spam question correctly.', 'wp-testimonial-with-widget'),
								'image' 		=> __('Please upload valid image file.', 'wp-testimonial-with-widget'),
								'error_msg' 	=> __('Please fill in the required fields.', 'wp-testimonial-with-widget'),
								'success_msg' 	=> __('Your testimonial submitted successfully.', 'wp-testimonial-with-widget'),
							);

	return apply_filters( 'wtwp_pro_testimonial_form_msgs', $wtwp_form_error );
}

/**
 * Function to get testimonial shortcode designs
 * 
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */
function wtwp_pro_testimonials_designs() {
	$design_arr = array(
		'design-1'	=> __('Design 1', 'wp-testimonial-with-widget'),
		'design-2'	=> __('Design 2', 'wp-testimonial-with-widget'),
		'design-3'	=> __('Design 3', 'wp-testimonial-with-widget'),
		'design-4'	=> __('Design 4', 'wp-testimonial-with-widget'),
		'design-5'	=> __('Design 5', 'wp-testimonial-with-widget'),
		'design-6'	=> __('Design 6', 'wp-testimonial-with-widget'),
		'design-7'	=> __('Design 7', 'wp-testimonial-with-widget'),
		'design-8'	=> __('Design 8', 'wp-testimonial-with-widget'),
		'design-9'	=> __('Design 9', 'wp-testimonial-with-widget'),
		'design-10'	=> __('Design 10', 'wp-testimonial-with-widget'),
		'design-11'	=> __('Design 11', 'wp-testimonial-with-widget'),
		'design-12'	=> __('Design 12', 'wp-testimonial-with-widget'),
		'design-13'	=> __('Design 13', 'wp-testimonial-with-widget'),
		'design-14'	=> __('Design 14', 'wp-testimonial-with-widget'),
		'design-15'	=> __('Design 15', 'wp-testimonial-with-widget'),
		'design-16'	=> __('Design 16', 'wp-testimonial-with-widget'),
		'design-17'	=> __('Design 17', 'wp-testimonial-with-widget'),
		'design-18'	=> __('Design 18', 'wp-testimonial-with-widget'),
		'design-19'	=> __('Design 19', 'wp-testimonial-with-widget'),
		'design-20'	=> __('Design 20', 'wp-testimonial-with-widget'),
	);
	return apply_filters('wtwp_pro_testimonials_designs', $design_arr );
}

/**
 * Function to get testimonial shortcode designs
 * 
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */
function wtwp_pro_testimonials_widget_designs() {
	$design_arr = array(
		'design-1'	=> __('Design 1', 'wp-testimonial-with-widget'),
		'design-2'	=> __('Design 2', 'wp-testimonial-with-widget'),
		'design-3'	=> __('Design 3', 'wp-testimonial-with-widget'),
		'design-5'	=> __('Design 5', 'wp-testimonial-with-widget'),
		'design-6'	=> __('Design 6', 'wp-testimonial-with-widget'),
		'design-7'	=> __('Design 7', 'wp-testimonial-with-widget'),
		'design-8'	=> __('Design 8', 'wp-testimonial-with-widget'),
		'design-9'	=> __('Design 9', 'wp-testimonial-with-widget'),
		'design-10'	=> __('Design 10', 'wp-testimonial-with-widget'),
		'design-12'	=> __('Design 12', 'wp-testimonial-with-widget'),
		'design-13'	=> __('Design 13', 'wp-testimonial-with-widget'),
		'design-14'	=> __('Design 14', 'wp-testimonial-with-widget'),
		'design-15'	=> __('Design 15', 'wp-testimonial-with-widget'),
		'design-16'	=> __('Design 16', 'wp-testimonial-with-widget'),
		'design-19'	=> __('Design 19', 'wp-testimonial-with-widget'),
	);
	return apply_filters('wtwp_pro_testimonials_widget_designs', $design_arr );
}
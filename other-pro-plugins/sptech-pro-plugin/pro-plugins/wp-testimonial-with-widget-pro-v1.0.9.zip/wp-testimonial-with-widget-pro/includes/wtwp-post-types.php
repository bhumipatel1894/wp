<?php
/**
 * Register Post type functionality
 *
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Function to register post type
 * 
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */
function wtwp_pro_register_post_type () {

	$wtwp_post_labels = apply_filters( 'wtwp_pro_testimonials_post_labels', array(
							'name' 					=> _x( 'SP Testimonials', 'post type general name', 'wp-testimonial-with-widget' ),
							'singular_name' 		=> _x( 'Testimonial', 'post type singular name', 'wp-testimonial-with-widget' ),
							'add_new' 				=> _x( 'Add New', 'testimonial', 'wp-testimonial-with-widget' ),
							'add_new_item' 			=> __( 'Add New Testimonial', 'wp-testimonial-with-widget' ),
							'edit_item' 			=> __( 'Edit Testimonial', 'wp-testimonial-with-widget' ),
							'new_item' 				=> __( 'New Testimonial', 'wp-testimonial-with-widget' ),
							'all_items' 			=> __( 'All Testimonials', 'wp-testimonial-with-widget' ),
							'view_item' 			=> __( 'View Testimonial', 'wp-testimonial-with-widget' ),
							'search_items' 			=> __( 'Search Testimonials', 'wp-testimonial-with-widget' ),
							'not_found' 			=> __( 'No Testimonials Found', 'wp-testimonial-with-widget' ),
							'not_found_in_trash'	=> __( 'No Testimonials Found In Trash', 'wp-testimonial-with-widget' ),
							'parent_item_colon' 	=> '',
							'featured_image'        => __( 'Testimonial Image', 'wp-testimonial-with-widget' ),
							'set_featured_image'    => __( 'Set testimonial image', 'wp-testimonial-with-widget' ),
							'remove_featured_image' => __( 'Remove testimonial image', 'wp-testimonial-with-widget' ),
							'use_featured_image'    => __( 'Use as testimonial image', 'wp-testimonial-with-widget' ),
							'insert_into_item'      => __( 'Insert into testimonial', 'wp-testimonial-with-widget' ),
							'uploaded_to_this_item' => __( 'Uploaded to this testimonial', 'wp-testimonial-with-widget' ),
							'menu_name' 			=> __( 'WP Testimonials Pro', 'wp-testimonial-with-widget' ),
						));

	$testimonial_args = array(
								'labels' 				=> $wtwp_post_labels,
								'public' 				=> true,
								'publicly_queryable' 	=> true,
								'show_ui' 				=> true,
								'show_in_menu' 			=> true,
								'query_var' 			=> true,
								'exclude_from_search'	=> false,
								'rewrite' 				=> array( 
																'slug' 			=> apply_filters( 'wtwp_pro_testimonials_post_slug', 'testimonial' ),
																'with_front' 	=> false
															),
								'capability_type' 		=> 'post',
								'has_archive' 			=> apply_filters( 'wtwp_pro_testimonials_archive_slug', false ),
								'hierarchical' 			=> false,
								'supports' 				=> apply_filters('wtwp_pro_post_supports', array('title', 'author' ,'editor', 'thumbnail', 'page-attributes', 'publicize', 'wpcom-markdown')),
								'menu_position' 		=> 5,
								'menu_icon' 			=> 'dashicons-format-quote',
							);

	// Register testimonial post type
	register_post_type( WTWP_POST_TYPE, apply_filters('wtwp_pro_testimonials_post_type_args', $testimonial_args) );
}

// Action to register post type
add_action( 'init', 'wtwp_pro_register_post_type');

/**
 * Function to register taxonomy
 * 
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */
function wtwp_pro_register_taxonomies() {

	$wtwp_cat_labels = apply_filters('wtwp_pro_testimonials_cat_labels', array(
					'name'              => __( 'Category', 'wp-testimonial-with-widget' ),
					'singular_name'     => __( 'Category', 'wp-testimonial-with-widget' ),
					'search_items'      => __( 'Search Category', 'wp-testimonial-with-widget' ),
					'all_items'         => __( 'All Category', 'wp-testimonial-with-widget' ),
					'parent_item'       => __( 'Parent Category', 'wp-testimonial-with-widget' ),
					'parent_item_colon' => __( 'Parent Category', 'wp-testimonial-with-widget' ),
					'edit_item'         => __( 'Edit Category', 'wp-testimonial-with-widget' ),
					'update_item'       => __( 'Update Category', 'wp-testimonial-with-widget' ),
					'add_new_item'      => __( 'Add New Category', 'wp-testimonial-with-widget' ),
					'new_item_name'     => __( 'New Category Name', 'wp-testimonial-with-widget' ),
					'menu_name'         => __( 'Category', 'wp-testimonial-with-widget' ),
				));
	
	$wtwp_cat_args = array(
					'hierarchical'      => true,
					'labels'            => $wtwp_cat_labels,
					'show_ui'           => true,
					'show_admin_column' => true,
					'query_var'         => true,
					'rewrite'           => array( 'slug' => WTWP_CAT ),
				);
	
	// Register testimonial category
	register_taxonomy( WTWP_CAT, array( WTWP_POST_TYPE ), apply_filters('wtwp_pro_testimonials_cat_args', $wtwp_cat_args) );
}

// Action to register taxonomies
add_action( 'init', 'wtwp_pro_register_taxonomies');

/**
 * Function to update post message for testimonial post type
 * 
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.5
 */
function wtwp_pro_post_updated_messages( $messages ) {

	global $post, $post_ID;

	$messages[WTWP_POST_TYPE] = array(
		0 => '', // Unused. Messages start at index 1.
		1 => sprintf( __( 'Testimonial updated. <a href="%s">View Testimonial</a>', 'wp-testimonial-with-widget' ), esc_url( get_permalink( $post_ID ) ) ),
		2 => __( 'Custom field updated.', 'wp-testimonial-with-widget' ),
		3 => __( 'Custom field deleted.', 'wp-testimonial-with-widget' ),
		4 => __( 'Testimonial updated.', 'wp-testimonial-with-widget' ),
		5 => isset( $_GET['revision'] ) ? sprintf( __( 'Testimonial restored to revision from %s', 'wp-testimonial-with-widget' ), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
		6 => sprintf( __( 'Testimonial published. <a href="%s">View Testimonial</a>', 'wp-testimonial-with-widget' ), esc_url( get_permalink( $post_ID ) ) ),
		7 => __( 'Testimonial saved.', 'wp-testimonial-with-widget' ),
		8 => sprintf( __( 'Testimonial submitted. <a target="_blank" href="%s">Preview Testimonial</a>', 'wp-testimonial-with-widget' ), esc_url( add_query_arg( 'preview', 'true', get_permalink( $post_ID ) ) ) ),
		9 => sprintf( __( 'Testimonial scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview Testimonial</a>', 'wp-testimonial-with-widget' ),
		  date_i18n( 'M j, Y @ G:i', strtotime($post->post_date) ), esc_url(get_permalink($post_ID)) ),
		10 => sprintf( __( 'Testimonial draft updated. <a target="_blank" href="%s">Preview Testimonial</a>', 'wp-testimonial-with-widget' ), esc_url( add_query_arg( 'preview', 'true', get_permalink( $post_ID ) ) ) ),
	);

	return $messages;
}

// Filter to update testimonial post message
add_filter( 'post_updated_messages', 'wtwp_pro_post_updated_messages' );
=== WP Testimonials with Rotator Widget Pro ===
Contributors: wponlinesupport, anoopranawat 
Tags: testimonial, Testimonial, testimonials, Testimonials, widget,  Best testimonial slider, Responsive testimonial slider, client testimonial slider, easy testimonial slider, testimonials with widget, wordpress testimonial with widget, testimonial rotator, testimonial slider, Testimonial slider , testimonial with shortcode, client testimonial, client, customer, quote, shortcodes
Requires at least: 3.1
Tested up to: 4.7.2
Stable tag: trunk


A quick, easy way to add and display responsive, clean client's testimonial on your website using a shortcode or a widget.

== Description ==
Many CMS site needs to display client's testimonial on their website. WP Testimonial Plugin with Widget allow you to add testimonial
from wp-admin side same like you add post, which allows you to display testimonials on your website the easy way.
You can quickly add your testimonials with their authors, jobs, pictures, pictures size, Website URL and Position. Testimonials plugin is the easiest way to start adding your
customer testimonials.

**This testimonial plugin contain two shortcode**
<code>[sp_testimonials] and [sp_testimonials_slider]</code>
Where you can display testimonial in list view, in grid view and slider testimonial with responsive. You can also select design theme from "SP Testimonials -> Designs".

A really simple way to manage testimonials on your site. This plugin creates a testimonial and a testimonial rotator/testimonial slider custom post type,
complete with WordPress admin fields for adding testimonials. It includes a Widget and Shortcode to display the testimonials.

= Shortcode Examples =

= Here is the shortcode example =
<code>[sp_testimonials]</code> - Testimonial Grid Shortcode
<code>[sp_testimonials_slider]</code> - Testimonial Slider Shortcode
<code>[sp_testimonials_form]</code> - Testimonial Entry Form Shortcode

= Complete shortcode with all parameters =
Testimonial Grid Shortcode
<code>[sp_testimonials limit="5" design="design-1" per_row="3" orderby="date" order="ASC" category="5" include_cat_child="true" display_client="true" display_avatar="true" display_job="true" display_company="true" image_style="square" size="100" show_rating="true" show_title="true" posts="5,10" exclude_post="5,10" exclude_cat="5,10"]</code>

Testimonial Slider Shortcode
<code>[sp_testimonials_slider limit="5" design="design-1" orderby="date" order="DEC" slides_column="3" slides_scroll="1" category="5" include_cat_child="true" display_client="true" display_avatar="true" display_job="true" display_company="true" show_rating="true" show_title="true" image_style="square" dots="true" arrows="true" autoplay="true" autoplay_interval="3000" speed="300" size="100" loop="true" effect="fade" center_mode="true" posts="5,10" exclude_post="5,10" exclude_cat="5,10"]</code>

Testimonial Entry Form Shortcode
<code>[sp_testimonials_form]</code>

= Use Following Testimonial parameters with shortcode =
<code>[sp_testimonials]</code>

* **Limit:** [sp_testimonials limit="5"] (Display 5 testimonials on your website. To display all testimonial set limit="-1")
* **Design:** [sp_testimonials design="design-1"] (Select the design for testimonial. Values are design-1 to design-20)
* **Grid:** [sp_testimonials per_row="2"] (Display your testimonials by Grid view. You can set grid up to 4.)
* **Order:** [sp_testimonials order="ASC"] (Order your testimonials by "Ascending" OR "Descending". Values are "ASC" OR "DESC".)
* **Orderby:** [sp_testimonials orderby="title"] ( Set Orderby testimonials. Values are "title", "date" (Post Date), "none", "title" (Post Title), "name" (Post Slug), "rand" (Random), "ID", "menu_order" (Sort Order))
* **Show Title:** [sp_testimonials show_title="true"] (Display testimonial title OR not. Values are "true" OR "false")
* **Show Rating:** [sp_testimonials show_rating="true"] (Display testimonial Rating OR not.  Values "true" OR "false")
* **Display Client:** [sp_testimonials display_client="true"] (Display Client name or not. Values are "true" OR "false")
* **Display Job Title:** [sp_testimonials display_job="true"] (Display Client job title. Values are "true" OR "false")
* **Display Company Name:** [sp_testimonials display_company="true"] (Display Client company name. Values are "true" OR "false")
* **Display Avatar (Image):** [sp_testimonials display_avatar="true"] (Display Client avatar. Values "true" OR "false")
* **Avatar size and Style:** [sp_testimonials size="150" image_style="square"] (Set size of Client avatar and style. Style values are "square" OR "circle")
* **Display By Category:** [sp_testimonials category="category_id"] (Display testimonials by their category ID.)
* **Include Category Child:** [sp_testimonials include_cat_child="true"] (If you are using parent category testimonial then whether to display child category testimonial or not. Values are "true" OR "false")
* **Display Specific Testimonial:** [sp_testimonials posts="5,10"] (Display specific testimonial.)
* **Exclude Specific Testimonial:** [sp_testimonials exclude_post="5,10"] (Exclude some testimonials which you do not want to display.)
* **Exclude Category:** [sp_testimonials exclude_cat="5,10"] (Exclude specific testimonial category which you do not want to display.)


= Use Following Testimonial Slider parameters with shortcode =
<code>[sp_testimonials_slider]</code>

* **Limit:** [sp_testimonials_slider limit="5"] (Display 5 testimonials on your website. To display all testimonial set limit="-1")
* **Design:** [sp_testimonials_slider design="design-1"] (Select the design for testimonial. Values are design-1 to design-20)
* **Order:** [sp_testimonials_slider order="ASC"] (Order your testimonials by "Ascending" OR "Descending". Values are "ASC" OR "DESC".)
* **Orderby:** [sp_testimonials_slider orderby="title"] ( Set Orderby testimonials. Values are "title", "date" (Post Date), "none", "title" (Post Title), "name" (Post Slug), "rand" (Random), "ID", "menu_order" (Sort Order))
* **Slider Columns:** [sp_testimonials_slider slides_column="2"] (Display number of testimonials at a time in slider.)
* **Slides to Scroll:** [sp_testimonials_slider slides_scroll="2"] (Scroll number of testimonials at a time.)
* **Slider Pagination and Arrows:** [sp_testimonials_slider dots="false" arrows="false"]
* **Autoplay : ** [sp_testimonials_slider autoplay="true"] (Start slider automatically. Values are "true" OR "false".)
* **Autoplay Interval : ** [sp_testimonials_slider autoplay_interval="3000"] (Delay between two slides.)
* **Slider Speed:** [sp_testimonials_slider speed="3000"] (Control speed of slider.)
* **Loop:** [sp_testimonials_slider loop="true"] ( Run slider contineously. Values are "true" OR "false")
* **Slider Effect:** [sp_testimonials_slider effect="slide"] ( Set slider effect. Values are "slide" OR "fade". Note use fade effect with slides_column="1")
* **Center Mode:** [sp_testimonials_slider center_mode="true"]
* **Show Title:** [sp_testimonials_slider show_title="true"] (Display testimonial title OR not. Values are "true" OR "false")
* **Show Rating:** [sp_testimonials_slider show_rating="true"] (Display testimonial Rating OR not.  Values "true" OR "false")
* **Display Client:** [sp_testimonials_slider display_client="true"] (Display Client name or not. Values are "true" OR "false")
* **Display Job Title:** [sp_testimonials_slider display_job="true"] (Display Client job title. Values are "true" OR "false")
* **Display company name:** [sp_testimonials_slider display_company="false"] ( Display Client company name : You can use "true" OR "false")
* **Display Avatar (Image):** [sp_testimonials_slider display_avatar="true"] (Display Client avatar. Values "true" OR "false")
* **Avatar size and Style:** [sp_testimonials_slider size="150" image_style="square"] (Set size of Client avatar and style. Style values are "square" OR "circle")
* **Display By Category:** [sp_testimonials_slider category="category_id"] (Display testimonials by their category ID.)
* **Include Category Child:** [sp_testimonials_slider include_cat_child="true"] (If you are using parent category testimonial then whether to display child category testimonial or not. Values are "true" OR "false")
* **Display Specific Testimonial:** [sp_testimonials_slider posts="5,10"] (Display specific testimonial.)
* **Exclude Specific Testimonial:** [sp_testimonials_slider exclude_post="5,10"] (Exclude some testimonials which you do not want to display.)
* **Exclude Category:** [sp_testimonials_slider exclude_cat="5,10"] (Exclude specific testimonial category which you do not want to display.)

= Template code is =
<code><?php echo do_shortcode('[sp_testimonials]'); ?></code>
<code><?php echo do_shortcode('[sp_testimonials_slider]'); ?></code>
<code><?php echo do_shortcode('[sp_testimonials_form]'); ?></code>

= Available fields : =
* Title
* Testimonial Content
* Job Title
* Company
* Website URL
* Picture
* Rating
* Category Selection

= New Features include: =
* Added 20 New Designs.
* Testimonial front-end form.
* Display Testimonial categories wise.
* Display Testimonial on home page with limit [sp_testimonials limit="1" ]
* Adding a Random Testimonial to Your Page.
* Responsive.
* Display testimonials using an easy testimonial widget.
* Add Client image.


== Installation ==

1. Upload the 'WP Testimonial Plugin with Widget Pro' folder to the '/wp-content/plugins/' directory.
2. Activate the "WP Testimonial Plugin with Widget Pro" list plugin through the 'Plugins' menu in WordPress.
3. Add a new page and add this short code 
<code>[sp_testimonials]</code>
4. If you want to display Testimonial using slider then use this short code 
<code>[sp_testimonials_slider]</code>
5. Here is Template code 
<code><?php echo do_shortcode('[sp_testimonials]'); ?> </code>
6. If you want to display Testimonial using slider then use this template code
<code><?php echo do_shortcode('[sp_testimonials_slider]'); ?> </code>


== Changelog ==

= 1.0.9 (03, Feb 2017) =
* [*] Resolved slider 'RTL' issue.
* [*] Updated plugin translation code. Now user can put plugin languages file in WordPress 'language' folder so plugin language file will not be loss while plugin update.

= 1.0.8 (12, Sep 2016) =
* [*] Updated plugin license page.
* Added SSL to https://www.wponlinesupport.com/ for secure updates.

= 1.0.7 (07, Sep 2016) =
* [+] Added filter for has_archive

= 1.0.6 (11, Aug 2016) =
* [*] Removed unnecessary 'ob_start' from the widget.

= 1.0.5 (05, Aug 2016) =
* [+] Added 5 more testimonial designs.
* [+] Added Visual Composer page builder support.
* [+] Update slider js to latest version.
* [+] Added RTL support for slider.
* [+] Added category filter in admin testimonial listing page.
* [+] Added Drag & Drop feature to display testimonial in your desired order.
* [+] Added plugin settings page for custom CSS and default testimonial image.
* [+] Added some useful plugin links for user at plugins page.
* [+] Added some filters to change testimonial post type slug and taxonomy slug.
* [+] Added 'posts' shortcode parameter to display only specific testimonial.
* [+] Added 'exclude_post' shortcode parameter to exclude testimonials.
* [+] Added 'exclude_cat' shortcode parameter to exclude testimonial categoty.
* [+] Added 'include_cat_child' shortcode parameter to include testimonial category child post or not.
* [*] Improved 'Testimonial Slider' widget and added some options in widget.
* [*] Optimized Testimonial form process and added translation in error messages.
* [*] Optimized js for better and smooth performance.
* [*] Code optimization and improved plugin performance.
* [*] Improved plugin design page.
* [*] Optimized slick slider and Testimonial js enqueue process.
* [*] Optimized CSS.

= 1.0.4 (13, APR 2016) =
* [*] Fixed some css issues.
* [*] Resolved slick slider initialize issue.

= 1.0.3 =
* Fixed some css issues.
* Resolved multiple slider jquery conflict issue.

= 1.0.2 =
* Updated testimonial form design,

= 1.0.1 =
* Fixed some bug,

= 1.0 =
* Initial release.
* Adds custom post type.

== Upgrade Notice ==

= 1.0.9 (03, Feb 2017) =
* [*] Resolved slider 'RTL' issue.
* [*] Updated plugin translation code. Now user can put plugin languages file in WordPress 'language' folder so plugin language file will not be loss while plugin update.

= 1.0.8 (12, Sep 2016) =
* [*] Updated plugin license page.
* Added SSL to https://www.wponlinesupport.com/ for secure updates.

= 1.0.7 (07, Sep 2016) =
* [+] Added filter for has_archive

= 1.0.6 (11, Aug 2016) =
* [*] Removed unnecessary 'ob_start' from the widget.

= 1.0.5 (05, Aug 2016) =
* [+] Added 5 more testimonial designs.
* [+] Added Visual Composer page builder support.
* [+] Update slider js to latest version.
* [+] Added RTL support for slider.
* [+] Added category filter in admin testimonial listing page.
* [+] Added Drag & Drop feature to display testimonial in your desired order.
* [+] Added plugin settings page for custom CSS and default testimonial image.
* [+] Added some useful plugin links for user at plugins page.
* [+] Added some filters to change testimonial post type slug and taxonomy slug.
* [+] Added 'posts' shortcode parameter to display only specific testimonial.
* [+] Added 'exclude_post' shortcode parameter to exclude testimonials.
* [+] Added 'exclude_cat' shortcode parameter to exclude testimonial categoty.
* [+] Added 'include_cat_child' shortcode parameter to include testimonial category child post or not.
* [*] Improved 'Testimonial Slider' widget and added some options in widget.
* [*] Optimized Testimonial form process and added translation in error messages.
* [*] Optimized js for better and smooth performance.
* [*] Code optimization and improved plugin performance.
* [*] Improved plugin design page.
* [*] Optimized slick slider and Testimonial js enqueue process.
* [*] Optimized CSS.

= 1.0.4 (13, APR 2016) =
* [*] Fixed some css issues.
* [*] Resolved slick slider initialize issue.

= 1.0.3 =
* Fixed some css issues.
* Resolved multiple slider jquery conflict issue.

= 1.0.2 =
* Updated testimonial form design.

= 1.0.1 =
* Fixed some bug.

= 1.0 =
* Initial release.
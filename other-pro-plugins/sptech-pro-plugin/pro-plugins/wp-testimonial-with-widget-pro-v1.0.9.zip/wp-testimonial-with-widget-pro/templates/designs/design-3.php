	
<div id="quote-<?php echo $post->ID;?>" class="wtwp-testimonial-box <?php echo $css_class.' '.$class;?>">
	<div class="wtwp-testimonial-inner">
		<div class="wtwp-testimonial-avatar">
			<?php if ( isset( $pertestimonial_image ) && ($pertestimonial_image != '' ) && $display_avatar == 'true' ){?>
				<div class="wtwp-avtar-image"><?php echo $pertestimonial_image;?></div>
				<?php }?>
		</div>

		<div class="wtwp-testimonial-author">
			<?php if($display_client == 'true' && $pertestimonial_client != ''){ ?>
				<div class="wtwp-testimonial-author">
					<?php
					echo $author;
					?>
				</div>
			<?php } 
			if($display_company == 'true' && $pertestimonial_company != '' || $display_job == 'true' && $pertestimonial_job != ''){?>
				<div class="wtwp-testimonial-cdec">
					<?php
					echo $testimonial_job;
					?>
				</div>
			<?php } ?>

			<?php if( !empty($pertestimonial_rating) && $show_rating == 'true' ) { ?>
				<div class="wtwp-testimonial-rating">
					<?php
					for ($i=0; $i<5; $i++) {
						if( $i < $pertestimonial_rating ){
							echo '<i class="fa fa-star"></i>';
						} else {
							echo '<i class="fa fa-star-o"></i>';
						}
					}
					?>
				</div><!-- end .testimonial-rating -->
			<?php } ?>

		</div>

		<div class="wtwp-testimonial-content">

			<?php if( $show_title == 'true' ) { ?>
				<div class="wtwp-testimonial-title"><?php the_title(); ?></div>
				<?php } ?>

				<div class="wtwp-testimonials-text"><em><?php echo get_the_content(); ?></em></div>
		</div>
	</div>
</div>
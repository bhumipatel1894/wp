<?php
/**
 * Handles testimonial form HTML
 *
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

global $wtwp_form_error;

// Taking some variables
$wtwp_form_err_mgs 	= wtwp_pro_tstmnl_form_msgs();
$form_error_msg 	= isset($wtwp_form_err_mgs['error_msg']) 	? $wtwp_form_err_mgs['error_msg'] 	: '';
$form_success_msg 	= isset($wtwp_form_err_mgs['success_msg']) 	? $wtwp_form_err_mgs['success_msg'] : '';

// Taking post variable
$rating = isset($_POST['rating']) ? $_POST['rating'] : '';

// Category arguments
$cat_args = apply_filters( 'wtwp_pro_testimonial_form_cat_args', array(
				'show_option_none'	=> __('Select Category'),
				'option_none_value' => '0',
				'hide_empty' 		=> false,
				'name'       		=> 'category',
				'id'         		=> 'wtwp-tstmnl-cat',
				'class'      		=> 'wtwp-input-sel wtwp-tstmnl-cat',
				'taxonomy'   		=> WTWP_CAT,
				'hierarchical'      => 1,
				'selected'			=> isset($_POST['category']) ? $_POST['category'] 	: ''
			));
?>

<div class="wtwp-testimonial-form-wrp" id="wtwp-testimonial-form-wrp">
	
	<?php if( !empty($_GET['success']) && $_GET['success'] == 1 && empty($wtwp_form_error) ) { ?>
	<div class="wtwp-tstmnl-succ">
		<?php echo $form_success_msg; ?>
	</div>
	<?php } ?>
	
	<?php if( !empty($wtwp_form_error) ) { ?>
	<div class="wtwp-tstmnl-err">
		<?php echo $form_error_msg; ?>
	</div>
	<?php } ?>
	
	<form name="wtwp-testimonial-form" id="wtwp-testimonial-form" class="wtwp-testimonial-form" action="" method="post" enctype="multipart/form-data">

		<div class="wtwp-tstmnl-row wtwp-clearfix">
			<div class="wtwp-medium-6 wtwp-columns">
				<label for="wtwp-tstmnl-title" class="wtwp-tstmnl-lbl"><?php _e('Title', 'wp-testimonial-with-widget'); ?><span class="wtwp-forms-req-symbol">*</span></label><br/>
				<input type="text" class="wtwp-input wtwp-tstmnl-title" id="wtwp-tstmnl-title" name="title" value="<?php if(isset($_POST['title'])){ echo wtwp_escape_attr($_POST['title']); } ?>" />
				<?php if(isset($wtwp_form_error['title'])){echo '<span class="wtwp-frm-error">'.$wtwp_form_error['title'].'</span>';} ?>
			</div>
			
			<div class="wtwp-medium-6 wtwp-columns">
				<label for="wtwp-tstmnl-cat" class="wtwp-tstmnl-lbl"><?php _e('Testimonial Category', 'wp-testimonial-with-widget') ?></label><br/>
				<?php wp_dropdown_categories( $cat_args ); ?>
			</div>
		</div>

		<div class="wtwp-tstmnl-row wtwp-clearfix">
			<div class="wtwp-medium-6 wtwp-columns">
				<label for="wtwp-tstmnl-cname" class="wtwp-tstmnl-lbl"><?php _e('Client Name', 'wp-testimonial-with-widget'); ?><span class="wtwp-forms-req-symbol">*</span></label><br/>
				<input type="text" class="wtwp-input wtwp-tstmnl-cname" id="wtwp-tstmnl-cname" name="testimonial_client" value="<?php if(isset($_POST['testimonial_client'])){ echo wtwp_escape_attr($_POST['testimonial_client']); } ?>" />
				<?php if(isset($wtwp_form_error['client_name'])){echo '<span class="wtwp-frm-error">'.$wtwp_form_error['client_name'].'</span>';} ?>
			</div>

			<div class="wtwp-medium-6 wtwp-columns">
				<label for="wtwp-tstmnl-job-title" class="wtwp-tstmnl-lbl"><?php _e('Job Title', 'wp-testimonial-with-widget'); ?></label><br/>
				<input type="text" class="wtwp-input wtwp-tstmnl-job-title" id="wtwp-tstmnl-job-title" name="testimonial_job" value="<?php if(isset($_POST['testimonial_job'])){ echo wtwp_escape_attr($_POST['testimonial_job']); } ?>" />
			</div>
		</div>

		<div class="wtwp-tstmnl-row wtwp-clearfix">
			<div class="wtwp-medium-6 wtwp-columns">
				<label for="wtwp-tstmnl-company" class="wtwp-tstmnl-lbl"><?php _e('Company Name', 'wp-testimonial-with-widget'); ?></label><br/>
				<input type="text" class="wtwp-input wtwp-tstmnl-company" id="wtwp-tstmnl-company" name="testimonial_company" value="<?php if(isset($_POST['testimonial_company'])){ echo wtwp_escape_attr($_POST['testimonial_company']); } ?>" />
			</div>

			<div class="wtwp-medium-6 wtwp-columns">
				<label for="wtwp-tstmnl-url" class="wtwp-tstmnl-lbl"><?php _e('Company Website', 'wp-testimonial-with-widget'); ?></label><br/>
				<input type="text" class="wtwp-input wtwp-tstmnl-url" id="wtwp-tstmnl-url" name="testimonial_url" value="<?php if(isset($_POST['testimonial_url'])){ echo wtwp_escape_attr($_POST['testimonial_url']); } ?>" />
			</div>
		</div>

		<div class="wtwp-tstmnl-row wtwp-clearfix">
			<div class="wtwp-medium-6 wtwp-columns">
				<label for="wtwp-tstmnl-rating" class="wtwp-tstmnl-lbl"><?php _e('Rating', 'wp-testimonial-with-widget'); ?></label><br/>
				<select class="wtwp-input-sel wtwp-tstmnl-rating" id="wtwp-tstmnl-rating" name="rating">
					<option value=""><?php _e('None', 'wp-testimonial-with-widget'); ?></option>
					<?php for( $i=1; $i<=5; $i++ ) { ?>
					<option value="<?php echo $i; ?>" <?php selected( $rating, $i ); ?>><?php echo $i; ?></option>
					<?php } ?>
				</select>
			</div>

			<div class="wtwp-medium-6 wtwp-columns">
				<label for="wtwp-tstmnl-img" class="wtwp-tstmnl-lbl"><?php _e('Image', 'wp-testimonial-with-widget'); ?></label><br/>
				<input type="file" class="wtwp-input-file wtwp-tstmnl-img" id="wtwp-tstmnl-img" name="tstmnl_image" />
				<?php if(isset($wtwp_form_error['image'])){echo '<span class="wtwp-frm-error">'.$wtwp_form_error['image'].'</span>';} ?>
			</div>
		</div>

		<div class="wtwp-tstmnl-row wtwp-clearfix">
			<div class="wtwp-tstmnl-row wtwp-medium-12 wtwp-columns wtwp-clearfix">
				<label for="wtwp-tstmnl-content" class="wtwp-tstmnl-lbl"><?php _e('Testimonial', 'wp-testimonial-with-widget'); ?><span class="wtwp-forms-req-symbol">*</span></label><br/>
				<textarea class="wtwp-input-textarea wtwp-tstmnl-content" id="wtwp-tstmnl-content" name="content"><?php if(isset($_POST['content'])){ echo wtwp_escape_attr($_POST['content']); } ?></textarea>
				<?php if(isset($wtwp_form_error['content'])){echo '<span class="wtwp-frm-error">'.$wtwp_form_error['content'].'</span>';} ?>
			</div>
		</div>

		<div class="wtwp-tstmnl-row wtwp-clearfix">
			<div class="wtwp-medium-6 wtwp-columns">
				<label for="wtwp-tstmnl-captcha" class="wtwp-tstmnl-lbl"><?php _e('Are you Human?', 'wp-testimonial-with-widget'); ?><span class="wtwp-forms-req-symbol">*</span></label>
			</div>

			<div class="wtwp-medium-10 wtwp-columns">
				<label for="wtwp-tstmnl-captcha" class="wtwp-tstmnl-lbl"><?php _e('What is nine minus 6?', 'wp-testimonial-with-widget') ?></label>
				<input type="text" class="wtwp-input wtwp-tstmnl-captcha" id="wtwp-tstmnl-captcha" name="captcha" value="" />
				<?php if(isset($wtwp_form_error['captcha'])){echo '<span class="wtwp-frm-error">'.$wtwp_form_error['captcha'].'</span>';} ?>
			</div>
		</div>

		<div class="wtwp-tstmnl-row wtwp-clearfix">
			<div class="wtwp-tstmnl-row wtwp-medium-12 wtwp-columns wtwp-clearfix">
				<input type="submit" class="wtwp-submit-btn" id="wtwp-tstmnl-submit-btn" name="wtwp_tstmnl_submit" value="<?php _e('Submit', 'wp-testimonial-with-widget'); ?>" />
			</div>
		</div>

	</form><!-- end .wtwp-testimonial-form -->
</div><!-- end .wtwp-testimonial-form-wrp -->
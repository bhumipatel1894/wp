<?php
/**
 * Plugin Name: WP Testimonials with rotator widget Pro
 * Plugin URI: https://www.wponlinesupport.com/
 * Text Domain: wp-testimonial-with-widget
 * Domain Path: /languages/
 * Description: Easy to add and display client's testimonial on your website with rotator widget. 
 * Author: WP Online Support
 * Version: 1.0.9
 * Author URI: https://www.wponlinesupport.com/
 *
 * @package WordPress
 * @author WP Online Support
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Basic plugin definitions
 * 
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */
if( !defined( 'WTWP_VERSION' ) ) {
	define( 'WTWP_VERSION', '1.0.9' ); // Version of plugin
}
if( !defined( 'WTWP_DIR' ) ) {
	define( 'WTWP_DIR', dirname( __FILE__ ) ); // Plugin dir
}
if( !defined( 'WTWP_URL' ) ) {
	define( 'WTWP_URL', plugin_dir_url( __FILE__ ) ); // Plugin url
}
if( !defined( 'WTWP_PRO_PLUGIN_BASENAME' ) ) {
    define( 'WTWP_PRO_PLUGIN_BASENAME', plugin_basename( __FILE__ ) ); // Plugin base name
}
if( !defined( 'WTWP_POST_TYPE' ) ) {
	define( 'WTWP_POST_TYPE', 'testimonial' ); // Plugin registered post type name
}
if( !defined( 'WTWP_CAT' ) ) {
	define( 'WTWP_CAT', 'testimonial-category' ); // Plugin category name
}
if( !defined( 'WTWP_META_PREFIX' ) ) {
	define( 'WTWP_META_PREFIX', '_wtwp_' ); // Plugin metabox prefix
}

/**
 * Load Text Domain
 * This gets the plugin ready for translation
 * 
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */
function wtwp_pro_load_textdomain() {

	global $wp_version;

    // Set filter for plugin's languages directory
    $wtwp_pro_lang_dir = dirname( plugin_basename( __FILE__ ) ) . '/languages/';
    $wtwp_pro_lang_dir = apply_filters( 'wtwp_pro_languages_directory', $wtwp_pro_lang_dir );

    // Traditional WordPress plugin locale filter.
    $get_locale = get_locale();

    if ( $wp_version >= 4.7 ) {
        $get_locale = get_user_locale();
    }

    // Traditional WordPress plugin locale filter
    $locale = apply_filters( 'plugin_locale',  $get_locale, 'wp-testimonial-with-widget' );
    $mofile = sprintf( '%1$s-%2$s.mo', 'wp-testimonial-with-widget', $locale );

    // Setup paths to current locale file
    $mofile_global  = WP_LANG_DIR . '/plugins/' . basename( WTWP_DIR ) . '/' . $mofile;

    if ( file_exists( $mofile_global ) ) { // Look in global /wp-content/languages/plugin-name folder
        load_textdomain( 'wp-testimonial-with-widget', $mofile_global );
    } else { // Load the default language files
        load_plugin_textdomain( 'wp-testimonial-with-widget', false, $wtwp_pro_lang_dir );
    }
}
add_action('plugins_loaded', 'wtwp_pro_load_textdomain');

/**
 * Activation Hook
 * 
 * Register plugin activation hook.
 * 
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */
register_activation_hook( __FILE__, 'wtwp_pro_install' );

/**
 * Deactivation Hook
 * 
 * Register plugin deactivation hook.
 * 
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */
register_deactivation_hook( __FILE__, 'wtwp_pro_uninstall');

/**
 * Plugin Setup (On Activation)
 * 
 * Does the initial setup,
 * stest default values for the plugin options.
 * 
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */
function wtwp_pro_install() {
	
	// Get settings for the plugin
    $wpwt_pro_options = get_option( 'wtwp_pro_options' );
    
    if( empty( $wpwt_pro_options ) ) { // Check plugin version option
        
        // Set default settings
        wtwp_pro_default_settings();
        
        // Update plugin version to option
        update_option( 'wtwp_pro_plugin_version', '1.0' );
    }

	// Custom post type and taxonomy function
	wtwp_pro_register_post_type();
	wtwp_pro_register_taxonomies();

	// Need to call when custom post type is being used in plugin
	flush_rewrite_rules();

	// To deactivate the free version of plugin
	if( is_plugin_active('wp-testimonial-with-widget/wp-testimonials.php') ){
     	add_action( 'update_option_active_plugins', 'wtwp_pro_deactivate_free_version' );
    }
}

/**
 * Function to deactivate the free version plugin
 * 
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */
function wtwp_pro_deactivate_free_version() {
	deactivate_plugins( 'wp-testimonial-with-widget/wp-testimonials.php', true );
}

/**
 * Plugin Setup (On Deactivation)
 * 
 * Delete  plugin options.
 * 
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */
function wtwp_pro_uninstall(){
	// Uninstall functionality
	
	// Need to call when custom post type is being used in plugin
	flush_rewrite_rules();
}

// Action to add admin notice
add_action( 'admin_notices', 'wtwp_pro_admin_notice');

/**
 * Admin notice
 * 
 * @package WP Testimonials with rotator widget Pro
 * @since 1.0.0
 */
function wtwp_pro_admin_notice() {

    $dir = ABSPATH . 'wp-content/plugins/wp-testimonial-with-widget/wp-testimonials.php';
    
    // If PRO plugin is active and free plugin exist
    if( is_plugin_active( 'wp-testimonial-with-widget-pro/wp-testimonials.php' ) && file_exists($dir) ) {
        
        global $pagenow;
        
        if( $pagenow == 'plugins.php' && current_user_can('install_plugins') ) {

            if ( current_user_can( 'install_plugins' ) ) {
                echo '<div id="message" class="updated notice is-dismissible"><p><strong>Thank you for activating WP Testimonials with rotator widget Pro</strong>.<br /> It looks like you had FREE version <strong>(<em>WP Testimonials with rotator widget</em>)</strong> of this plugin activated. To avoid conflicts the extra version has been deactivated and we recommend you delete it. </p></div>';
            }
        }
    }
}

/***** Updater Code Starts *****/
define( 'EDD_WTWPPRO_STORE_URL', 'https://www.wponlinesupport.com' );
define( 'EDD_WTWPPRO_ITEM_NAME', 'WP Testimonials With Rotator Widget Pro' ); 
if( !class_exists( 'EDD_SL_Plugin_Updater' ) ) {	
	include( dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php' );
}

function edd_sl_wtwppro_plugin_updater() {
	
	$license_key = trim( get_option( 'edd_wtwppro_license_key' ) );

	$edd_updater = new EDD_SL_Plugin_Updater( EDD_WTWPPRO_STORE_URL, __FILE__, array(
			'version' 	=> WTWP_VERSION, 			// current version number
			'license' 	=> $license_key, 			// license key (used get_option above to retrieve from DB)
			'item_name' => EDD_WTWPPRO_ITEM_NAME, 	// name of this plugin
			'author' 	=> 'WP Online Support'  	// author of this plugin
		)
	);
}
add_action( 'admin_init', 'edd_sl_wtwppro_plugin_updater', 0 );
include( dirname( __FILE__ ) . '/edd-wtwppro-plugin.php' );
/***** Updater Code Ends *****/

// Global variables
global $wtwp_form_error, $wtwp_pro_options;

// Functions file
require_once( 'includes/wtwp-functions.php' );
$wtwp_pro_options = wtwp_pro_get_settings();

// Register post type file
require_once( WTWP_DIR . '/includes/wtwp-post-types.php' );

// Script class file
require_once( WTWP_DIR . '/includes/class-wtwp-script.php' );

// Admin class file
require_once( WTWP_DIR . '/includes/admin/class-wtwp-admin.php' );

// Public class file
require_once( WTWP_DIR . '/includes/class-wtwp-public.php' );

// Shortcode File
require_once( WTWP_DIR . '/includes/shortcode/wtwp-testimonial-grid.php' );
require_once( WTWP_DIR . '/includes/shortcode/wtwp-testimonial-slider.php' );
require_once( WTWP_DIR . '/includes/shortcode/wtwp-testimonial-form.php' );

// Requiring Testimonial widget file
require_once( WTWP_DIR . '/includes/widgets/class-wtwp-testimonials-widget.php' );

// VC Shortcode File
require_once( WTWP_DIR . '/includes/admin/class-wtwp-vc.php' );

// Load admin files
if ( is_admin() || ( defined( 'WP_CLI' ) && WP_CLI ) ) {

	// Design file
	require_once( WTWP_DIR . '/includes/admin/class-wtwp-designs.php' );
}
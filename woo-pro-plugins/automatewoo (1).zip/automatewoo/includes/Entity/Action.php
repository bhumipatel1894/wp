<?php

namespace AutomateWoo\Entity;

/**
 * @class Action
 * @since 5.1.0
 */
class Action extends NamedEntityWithOptions {}

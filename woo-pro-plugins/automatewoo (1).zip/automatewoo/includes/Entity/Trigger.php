<?php

namespace AutomateWoo\Entity;

/**
 * @class Trigger
 * @since 5.1.0
 */
class Trigger extends NamedEntityWithOptions {}

<?php

namespace AutomateWoo\Entity;

/**
 * @class WorkflowTimingImmediate
 * @since 5.1.0
 */
class WorkflowTimingImmediate extends WorkflowTimingBase {

	const TYPE = 'immediately';
}

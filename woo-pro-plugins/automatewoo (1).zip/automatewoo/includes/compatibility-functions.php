<?php
/**
 * Add compatible functions for older versions of WC or WP.
 *
 * @package AutomateWoo
 */

defined( 'ABSPATH' ) || exit;

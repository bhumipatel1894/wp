<?php
// phpcs:ignoreFile
/**
 * Plain email header
 *
 * Override this template by copying it to yourtheme/automatewoo/email/plain/email-header.php
 *
 */

if ( ! defined( 'ABSPATH' ) ) exit;

?>

<html><body><?php // important to set a body tag for preheader usage  ?>

jQuery(
	function ($) {

		var selectopt   = ['woo_column_linkable', 'woo_column_date_format', 'woo_column_quantity', 'woo_column_add_types', 'woo_column_add_selected_cart', 'woo_column_width_type'];
		var id_types    = ['id', 'title', 'sku', 'date', 'price', 'descr', 'short_desc', 'reviews'];
		var sorted_cols = ['id', 'title', 'date', 'reviews', 'price'];

		$( '.cart_position' ).hide();
		$( '#cart-types' ).change(
			function () {
				if ($( this ).children( "option:selected" ).val() == 'add_checkbox' || $( this ).children( "option:selected" ).val() == 'add_button_checkbox') {
					$( '.cart_position' ).show();
				} else {
					$( '.cart_position' ).hide();
				}
			}
		);
		$( "#custom-hidden-fields :input" ).attr( "disabled", true );
		$( ".wcpt-columns-sortable" ).sortable(
			{
				revert: true,
				start: function (ev, ui) {
					if (ui.item.not( ".ui-draggable-dragging" )) {
						ui.item.addClass( "noclick" );
					}
				},
				stop: function (ev, ui) {
					filling_fields_option();
				}
			}
		);
		$( ".wcpt-columns-draggable li" ).draggable(
			{
				connectToSortable: ".wcpt-columns-sortable",
				helper: "clone",
				revert: "invalid",
				stop: function (event, ui) {
					var clone = $( '#custom-hidden-fields' ).clone();
					clone.find( 'input' ).removeAttr( 'disabled' );

					clone.find( 'input[data-opt=woo_column_ids]' ).addClass( 'fixed_options' );
					clone.find( 'input[data-opt=woo_column_name]' ).addClass( 'fixed_options' );
					clone.find( 'input[data-opt=woo_column_width]' ).addClass( 'fixed_options' );
					clone.find( 'input[data-opt=woo_column_width_type]' ).addClass( 'fixed_options' );

					switch (ui.helper.data( 'type' )) {
						case 'title':
						case 'featured_img':
							clone.find( 'input[data-opt=woo_column_linkable]' ).addClass( 'fixed_options' );
							break;
						case 'descr':
							clone.find( 'input[data-opt=woo_column_descr]' ).addClass( 'fixed_options' );
							break;
						case 'date':
							clone.find( 'input[data-opt=woo_column_date_format]' ).addClass( 'fixed_options' );
							break;
						case 'cart_button':
							clone.find( 'input[data-opt=woo_column_add_types]' ).addClass( 'fixed_options' );
							clone.find( 'input[data-opt=woo_column_add_selected_cart]' ).addClass( 'fixed_options' );
							clone.find( 'input[data-opt=woo_column_quantity]' ).addClass( 'fixed_options' );
							break;
						case 'attributes':
							clone.find( 'input[data-opt=woo_column_attrs]' ).addClass( 'fixed_options' );
							break;
						case 'custom_fields':
							clone.find( 'input[data-opt=woo_column_custom_keys]' ).addClass( 'fixed_options' );
							break;
						case 'taxonomy':
							clone.find( 'input[data-opt=woo_column_taxonomy]' ).addClass( 'fixed_options' );
							break;
						default:
							clone.find( 'input' ).each(
								function () {
									if ($( this ).is( ":not(.fixed_options)" )) {
										$( this ).remove();
									}
								}
							);
							break;
					}

					clone.find( 'input' ).each(
						function () {
							if ($( this ).is( ":not(.fixed_options)" )) {
								$( this ).remove();
							}
						}
					);

					clone.find( 'input' ).removeAttr( "disabled" );
					if (ui.helper.data( 'type' ) == 'cart_button' && $( ".wcpt-columns-sortable" ).find( 'li[data-type="cart_button"]' ).length > 1) {
						$( ".wcpt-columns-sortable" ).find( 'li[data-type="cart_button"]:last' ).remove();
					}

					clone.appendTo( ui.helper );

					ui.helper.find( 'input[name^="woo_ids"]' ).val( ui.helper.data( 'type' ) );
					ui.helper.find( 'input[name^="woo_label"]' ).val( ui.helper.data( 'def-name' ) );
					if (ui.helper.data( 'type' ) == 'cart_button') {
						ui.helper.find( 'input[name^=woo_add_types]' ).val( 'add_button' );
						ui.helper.find( 'input[name^=woo_quantity]' ).val( 'true' );
					}

					ui.helper.find( 'input[name^=woo_width_type]' ).val( 'percent' );

					filling_fields_option();
				}
			}
		);

		var opt = {
			autoOpen: false,
			modal: true,
			width: 550,
			height: 650,
			open: function () {
				$( ".ui-dialog-titlebar-close" ).hide();
			},
			buttons: [
			{
				text: "Cancel",
				"class": 'cancel_action',
				click: function () {
					$( this ).dialog( "close" );
				}
			},
			{
				text: "Save",
				"class": 'save_action',
				click: function () {
					// save code here
					var li_select          = $( '.wcpt-columns-sortable' ).find( "li:eq(" + $( '#dialog' ).attr( 'data-index' ) + ")" ),
							field_type     = $( '#dialog' ).attr( 'data-type' ),
							current_dialog = $( this );

					li_select.find( 'input[name^=woo_label]' ).val( current_dialog.find( 'input.woo_column_name' ).val() );
					li_select.find( 'input[name^=woo_width_text]' ).val( current_dialog.find( 'input.woo_column_width' ).val() );
					li_select.find( 'input[name^=woo_width_type]' ).val( current_dialog.find( 'select[name=woo_column_width_type] option:selected' ).val() );
					li_select.find( 'span.label-title' ).text( current_dialog.find( 'input.woo_column_name' ).val() );

					switch (field_type) {
						case 'title':
						case 'featured_img':
							li_select.find( 'input[name^=woo_linkable]' ).val( current_dialog.find( 'select[name=woo_column_linkable] option:selected' ).val() );
							break;
						case 'descr':
							li_select.find( 'input[name^=woo_descr]' ).val( current_dialog.find( 'input.woo_column_descr' ).val() );
							break;
						case 'date':
							li_select.find( 'input[name^=woo_date_format]' ).val( current_dialog.find( 'select[name=woo_column_date_format] option:selected' ).val() );
							break;
						case 'cart_button':
							li_select.find( 'input[name^=woo_quantity]' ).val( current_dialog.find( 'select[name=woo_column_quantity] option:selected' ).val() );
							li_select.find( 'input[name^=woo_add_types]' ).val( current_dialog.find( 'select[name=woo_column_add_types] option:selected' ).val() );
							li_select.find( 'input[name^=woo_add_selected_cart]' ).val( current_dialog.find( 'select[name=woo_column_add_selected_cart] option:selected' ).val() );
							li_select.find( 'input[name^=woo_ajax_option]' ).val( current_dialog.find( 'select[name=woo_column_ajax_option] option:selected' ).val() );
							break;
						case 'attributes':
							li_select.find( 'input[name^=woo_attrs]' ).val( current_dialog.find( 'input.woo_column_attrs' ).val() );
							break;
						case 'custom_fields':
							li_select.find( 'input[name^=woo_custom_keys]' ).val( current_dialog.find( 'input.woo_column_custom_keys' ).val() );
							break;
						case 'taxonomy':
							li_select.find( 'input[name^=woo_taxonomy]' ).val( current_dialog.find( 'input.woo_column_taxonomy' ).val() );
							break;
						default:
							break;
					}

					filling_fields_option( "save" );
					current_dialog.dialog( "close" );
				}
			},
			{
				text: "Delete",
				"class": 'delete_action',
				click: function () {
					// delete code here
					$( '.wcpt-columns-sortable' ).find( "li:eq(" + $( '#dialog' ).attr( 'data-index' ) + ")" ).remove();
					filling_fields_option();
					$( this ).dialog( "close" );
				}
			}
			]
		};

		var theDialog = $( "#dialog" ).dialog( opt );
		$( '.wcpt-columns-sortable' ).on(
			'click',
			'li',
			function (e) {
				
				e.preventDefault();

				var current_li   = $( this ),
					type         = current_li.data( 'type' ),
					title        = current_li.data( 'def-name' ),
					$column_name = '';

				custom_field_options( type );
				current_li.attr( 'data-index', current_li.index() );
				$( '#dialog' ).attr( 'data-index', current_li.index() );
				$( '#dialog' ).attr( 'data-type', type );
				if (current_li.hasClass( 'noclick' )) {
					current_li.removeClass( 'noclick' );
					return;
				}

				if (current_li.find( 'input[name^=woo_label]' ).val()) {
					$column_name = current_li.find( 'input[name^=woo_label]' ).val();
				} else {
					$column_name = current_li.find( 'input[name^=woo_label]' ).val( title );
				}

				if ($column_name) {
					$( '.woo-product-table-field-options' ).find( 'input.woo_column_name' ).val( $column_name );
				}

				$( ".all-fields-options" ).each(
					function (i, e) {
						$( this ).find( 'select option:selected' ).prop( 'selected', false );
						$( this ).find( 'input' ).val( '' );
					}
				);

				current_li.find( '#custom-hidden-fields input' ).each(
					function (i, e) {
						if ($.inArray( $( this ).attr( 'data-opt' ), selectopt ) !== -1) {
							if ($( this ).val()) {
								$( "select[name='" + $( this ).attr( 'data-opt' ) + "']" ).val($( this ).val());
							}
						} else {
							if ($( this ).attr( 'data-opt' )) {
								$( "." + $( this ).attr( 'data-opt' ) + "" ).val( $( this ).val() );
							}
						}
					}
				);
				theDialog.dialog( "open" );
				theDialog.dialog( 'option', 'title', $column_name );

				if ($( 'select[name="woo_column_add_types"] option:selected' ).val() == 'add_checkbox' || $( 'select[name="woo_column_add_types"] option:selected' ).val() == 'add_button_checkbox') {
					$( '.cart_position' ).show();
				} else {
					$( '.cart_position' ).hide();
				}

			}
		);

		function filling_fields_option(type = '') {
			$( '#sorted_cols option' ).remove().end();
			$( '#columns_mobile_show option' ).remove().end();
			$( '#columns_show option' ).remove().end();
			$( '#columns_tablet_show option' ).remove().end();
			$( '.wcpt-columns-sortable li' ).each(
				function (i, e) {
					if ($( this ).is( ":not('.ui-sortable-placeholder')" )) {
						if ($.inArray( $( this ).data( 'type' ), sorted_cols ) !== -1) {
							$( '#sorted_cols' ).append( "<option value=" + $( this ).data( 'type' ) + "_" + i + ">" + $( '.wcpt-columns-sortable' ).find( "li:eq(" + i + ")" ).find( 'input[name^=woo_label]' ).val() + "</option>" );
						}
						if ($.inArray( $( this ).data( 'type' ), id_types ) !== -1) {
							var current_type = $( this );
							var def_name     = '';
							if (type == 'save') {
								def_name = $( '.wcpt-columns-sortable' ).find( "li:eq(" + i + ")" ).find( 'input[name^=woo_label]' ).val();
							}
							filling_responsive_selection_fields( current_type, i, def_name );
						}
					}
				}
			);
		}

		function filling_responsive_selection_fields(current_type, index, def_name) {
			if (def_name == '') {
				def_name = current_type.data( 'def-name' );
			}
			$( '#columns_mobile_show' ).append( "<option value=" + current_type.data( 'type' ) + "_" + index + ">" + def_name + "</option>" );
			$( '#columns_tablet_show' ).append( "<option value=" + current_type.data( 'type' ) + "_" + index + ">" + def_name + "</option>" );
			$( '#columns_show' ).append( "<option value=" + current_type.data( 'type' ) + "_" + index + ">" + def_name + "</option>" );
		}
		function custom_field_options(field_type) {

			$( '.all-fields-options' ).hide();
			switch (field_type) {
				case 'title':
				case 'featured_img':
					$( '.woo-title-img-link' ).show();
					break;
				case 'descr':
					$( '.woo-short-descr' ).show();
					break;
				case 'date':
					$( '.woo-date-format' ).show();
					break;
				case 'cart_button':
					$( '.woo-add-cart-options' ).show();
					break;
				case 'attributes':
					$( '.woo-attr-options' ).show();
					break;
				case 'custom_fields':
					$( '.woo-custom-fields-options' ).show();
					break;
				case 'taxonomy':
					$( '.woo-tax-options' ).show();
					break;
				default:
					$( '.all-fields-options' ).hide();
					break;
			}
			$( '.woo-column-width' ).show();
		}

	}
);

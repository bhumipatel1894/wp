jQuery(
	function ($) {

		var settings_multiple_select = [ ,'wcpt_inc_product_cats', 'wcpt_wholesale_selected_roles', 'wcpt_addon_display', 'wcpt_ex_product_cats', 'wcpt_inc_product_tags', 'wcpt_filters_obj', 'columns_show', 'sorted_cols', 'columns_mobile_show', 'columns_tablet_show'];

		if (settings_multiple_select) {
			$.each(
				settings_multiple_select,
				function (index, value) {
					var setting_id = $( '#' + value );
					setting_id.select2();
					get_selection_as_sorted( setting_id );
				}
			);
		}

		var obj_show_hide_elements = [
		{
			id: 'show_search',
			element_class: 'show_search_filter'
		},
		{
			id: 'show_filter',
			element_class: 'show_filter'
		},
		{
			id: 'enable_sort_cols',
			element_class: 'sorting-clickable'
		}
		];

		$.each(
			obj_show_hide_elements,
			function (index, value) {
				if ($( '#' + value.id ).is( ':checked' )) {
					$( '.' + value.element_class ).show();
				} else {
					$( '.' + value.element_class ).hide();
				}

				$( '#' + value.id ).click(
					function () {
						if ($( this ).is( ':checked' )) {
							$( '.' + value.element_class ).show();

						} else {
							$( '.' + value.element_class ).hide();
						}
					}
				);

			}
		);

		get_responsive_options();

		$( '.wcpt-resp-display' ).on(
			'click',
			'',
			function () {
				get_responsive_options();
			}
		);

		$( "#wcpt_rows_page" ).attr(
			{
				"max": 50,
				"min": 1
			}
		);

		$( "#wcpt_product_limit" ).attr(
			{
				"min": 0
			}
		);

		$( '.wcpt-date-picker' ).datepicker(
			{
				dateFormat: 'yy-mm-dd',
				maxDate: '0' // Today
			}
		);

		$( '.woocommerce-help-tip' ).tipTip(
			{
				'attribute': 'data-tip',
				'fadeIn': 50,
				'fadeOut': 50,
				'delay': 200
			}
		);

		function get_responsive_options() {
			var responsive_selected = $( 'input[name=display_responsive]:checked' ).val();

			switch (responsive_selected) {
				case "priority_opt":
					$( '.wcpt-based-priority' ).show();
					$( ".column-brk-pts" ).css( "display", "none" );
					break;
				case "column_breakpts":
					$( ".column-brk-pts" ).css( "display", "block" );
					$( '.wcpt-based-priority' ).hide();
					break;
				default:
					$( '.wcpt-based-priority' ).hide();
					$( ".column-brk-pts" ).css( "display", "none" );
					break;
			}

		}

		function get_selection_as_sorted($el) {
			$el.on(
				"select2:select",
				function (evt) {
					var element  = evt.params.data.element;
					var $element = $( element );
					$element.detach();
					$( this ).append( $element );
					$( this ).trigger( "change" );
				}
			);

		}

	}
);

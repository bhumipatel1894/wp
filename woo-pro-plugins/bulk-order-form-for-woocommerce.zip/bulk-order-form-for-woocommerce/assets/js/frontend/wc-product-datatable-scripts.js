jQuery(
	function ($) {
		$( document ).ready(
			function () {
				$( '.product-table' ).each(
					function (index) {
						var current_table          = $( this ),
							table_id               = current_table.data( 'id' ),
							hidden_col_ids         = current_table.data( 'hidden-col-ids' ),
							search                 = current_table.data( 'search' ),
							filter                 = current_table.data( 'filter' ),
							column_width           = [],
							rows_per_page          = 10,
							default_sort_col       = 0,
							default_sort_dir       = "asc",
							hidden_col_mobile_ids  = current_table.data( 'hidden-col-mob-ids' ),
							hidden_col_tab_ids     = current_table.data( 'hidden-col-tab-ids' ),
							paging_type            = current_table.data( 'paging-type' ),
							empty_message          = current_table.find( '.wcpt-no-product-message' ).val(),
							display_page_length    = current_table.data( 'display-page-length' ),
							display_product_totals = current_table.data( 'display-product-totals' ),
							display_pagination     = current_table.data( 'display-pagination' ),
							wcpt_scroll            = current_table.data( 'scroll-offset' );
						wcpt_scroll                = parseInt( wcpt_scroll );
						// prepae datable parameters
						var datatable_params = {
							processing: true,
							serverSide: true,
							responsive: true,
							lengthMenu: [10, 20, 50],
							columnDefs: [],
						}

						if (empty_message !== 'undefined') {
							datatable_params.language = {
								emptyTable: empty_message
							}
						}
						if (typeof hidden_col_ids !== 'undefined') {
							if (hidden_col_ids.length > 1) {
								hidden_col_ids = hidden_col_ids.split( ',' );
							}
						}
						if (typeof hidden_col_mobile_ids !== 'undefined') {
							if (hidden_col_mobile_ids.length >= 1) {
								hidden_col_mobile_ids = hidden_col_mobile_ids.split( ',' );
							}
							hidden_col_mobile_ids = Object.values( hidden_col_mobile_ids ).map( Number );
							if ($( window ).width() <= 480) {
								datatable_params.columnDefs = [
								{visible: true, targets: hidden_col_mobile_ids},
								{visible: false, targets: ['_all']}

								];
							}
						}
						if (typeof hidden_col_tab_ids !== 'undefined') {
							if (hidden_col_tab_ids.length >= 1) {
								hidden_col_tab_ids = hidden_col_tab_ids.split( ',' );
							}
							hidden_col_tab_ids = Object.values( hidden_col_tab_ids ).map( Number );
							if ($( window ).width() <= 768 && $( window ).width() > 480) {

								datatable_params.columnDefs = [
								{visible: true, targets: hidden_col_tab_ids},
								{visible: false, targets: ['_all']}

								];
							}
						}
						// set number of rows in datatable
						if (current_table.data( 'rows' )) {
							rows_per_page = current_table.data( 'rows' );
						}
						/**
						 * animate to table top on pagination
						 */
						$( current_table ).on(
							"page.dt",
							function () {
								var wcpt_scroll   = parseFloat( current_table.data( 'scroll-offset' ) );
								var targer_offset = $( current_table ).offset().top - wcpt_scroll;
								$( "html,body" ).animate( {scrollTop: targer_offset}, "slow" );
							}
						);
						// ajax to load woocommerce product data
						var ajax_data = {
							table_id: table_id,
                            nonce:product_table_params.nonce,
							action: 'wcpt_load_products'
						};

						if (filter === 1) {
							var filters_id = [];
							$( '#select-filter-' + table_id + ' select' ).each(
								function () {
									var all_filters = $( this );
									all_filters.val( '' );
									filters_id.push( all_filters.attr( 'id' ) );
								}
							);

							ajax_data['filters'] = function () {
								var val = [];
								filters_id.map(
									function (i, e) {
										val.push(
											{
												key: i,
												value: $( '#' + i ).val()
											}
										);
									}
								);
								return JSON.stringify( val );
							};

						}
						// set column width
						if (current_table.find( 'thead' ).length > 0) {
							current_table.find( "thead tr th" ).each(
								function (index) {
									if ($( this ).data( 'width' )) {
										column_width.push(
											{
												width: $( this ).data( 'width' ),
												targets: index
											}
										);
									}
								}
							);
							if (column_width.length > 0) {
								datatable_params.autoWidth = false;
							}
						}
						// default sort column
						if (current_table.find( "thead" ).data( 'sort_col' )) {
							default_sort_col = current_table.find( "thead" ).data( 'sort_col' );
						}
						if (current_table.find( "thead" ).data( 'sort_dir' )) {
							default_sort_dir = current_table.find( "thead" ).data( 'sort_dir' );
						}
						// set number of rows per page
						datatable_params.pageLength = rows_per_page;
						// set default sort column
						datatable_params.order              = [[default_sort_col, default_sort_dir]];
								datatable_params.pagingType = paging_type;
						datatable_params.columnDefs.push( column_width, {targets: 'no-sort', orderable: false} );
						datatable_params.dom     = 'Bfrltip';
						datatable_params.buttons = [
						{
							text: 'show all <span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>',
							action: function (e, dt, node, config) {
								if ($( window ).width() <= 768 && $( window ).width() > 480 && typeof hidden_col_tab_ids !== 'undefined') {
									dt.columns().every(
										function () {
											if ( ! hidden_col_tab_ids.includes( this.index() )) {
												this.visible( ! this.visible() );
											}
										}
									)
								}
								if ($( window ).width() <= 480 && typeof hidden_col_mobile_ids != 'undefined') {
									dt.columns().every(
										function () {
											if ( ! hidden_col_mobile_ids.includes( this.index() )) {
												this.visible( ! this.visible() );
											}
										}
									)
								}

							},
							available: function (dt, config) {
								return 768 > $( window ).width() && $( window ).width() >= 320 && (typeof hidden_col_tab_ids !== 'undefined' || typeof hidden_col_mobile_ids != 'undefined');
							}
						},
						];

						if (display_pagination == 'yes') {
							datatable_params.paging = false;
							var custom_pages = '4';
						} else {
							var custom_pages = '9999';
						}
						if (display_page_length == 'yes') {
							datatable_params.lengthChange = false;
						}

						if (display_product_totals == 'yes') {
							datatable_params.info = false;
						}
						if (search === 'yes') {
							datatable_params.searching = true;
						}

						datatable_params.ajax         = $.fn.dataTable.pipeline(
							{
								url: product_table_params.ajax_url,
								data: ajax_data,
								type: "POST",
								pages: custom_pages,
							}
						);
						datatable_params.drawCallback = function (settings) {
							// hidde qantity and add to cat button according to woocommerce settings
							current_table.find( ".product-cart-chechbox-wrapper.hide-quantity" ).each(
								function (index) {
									$( this ).find( '.quantity' ).hide();
								}
							);
							current_table.find( ".product-cart-chechbox-wrapper.hide-submit-btn" ).each(
								function (index) {
									$( this ).find( '.single_add_to_cart_button' ).hide();
								}
							);
							// apply product variations functions
							if (typeof wc_add_to_cart_variation_params !== 'undefined') {
								current_table.find( '.variations_form' ).each(
									function () {
										$( this ).wc_variation_form();
									}
								);
								current_table.find( '.variable-product-add-cart .variation_id' ).each(
									function () {
										enable_disable_varitaion_buttons( $( this ) );
									}
								)
							}
							// load variation change price
							
							jQuery( "input.variation_id" ).change(function() {
							// Check input( $( this ).val() ) for validity here
							 
							load_variation_total_price();
							});
							load_variation_total_price();
							
							
						}

						var table = current_table.DataTable( datatable_params );
						if ((filter === 1) && ($( '#select-filter-' + table_id ).data( 'col-filter' ) == 'load_archive')) {
							$( '#select-filter-' + table_id ).find( '.filter-attr' ).bind(
								"change",
								function () {
									if ($( this ).data( 'filter-link' ) === '') {
										var sel = $( this ).find( ':selected' );
										if (sel.data( 'tax-link' )) {
											window.location.href = sel.data( 'tax-link' );
										}
									} else {
										table.ajax.reload();
										table.clearPipeline().draw();
									}
								}
							);
						}

						// reset filter button
						$( '#select-filter-' + table_id ).find( '.reset-filters' ).on(
							"click",
							function (e) {
								e.preventDefault();
								$( '.filter-attr' ).each(
									function () {
										$( this ).val( '' );
									}
								);
								table.ajax.reload();
								table.clearPipeline().draw();
							}
						);

						if ((filter === 1) && ($( '#select-filter-' + table_id ).data( 'col-filter' ) == 'perform_filter')) {
							$( '#select-filter-' + table_id ).find( '.filter-attr' ).bind(
								"change",
								function () {
									table.ajax.reload();
									table.clearPipeline().draw();
								}
							);
						}

						table.on(
							'responsive-display',
							function (e, datatable, row, showHide, update) {
								if (row.child()) {
									row.child().find( '.variations_form' ).each(
										function () {
											$( this ).wc_variation_form();
											enable_disable_varitaion_buttons( $( this ).find( '.variation_id' ) );
										}
									);
									// hidde qantity and add to cat button according to woocommerce settings
									if ($( this ).find( ".product-cart-chechbox-wrapper.hide-quantity" ).length > 0) {
										$( this ).find( '.quantity' ).hide();
									}
									if ($( this ).find( ".product-cart-chechbox-wrapper.hide-submit-btn" ).length > 0) {
										$( this ).find( '.single_add_to_cart_button' ).hide();
									}
								}
							}
						);
					}
				);

				// $( document ).on(
				// 	'click',
				// 	'.product-cart-wrapper button[type="submit"]:not(.disabled)',
				// 	function (e) {
				// 		e.preventDefault();
				// 		var current_button   = $( this ),
				// 			product_id       = false,
				// 			product_quantity = current_button.closest( '.product-cart-wrapper' ).find( '.quantity .qty' ).val();

				// 		current_button.closest( '.product-table-wrap' ).find( '.product-table-loader' ).show();
				// 		// get product id for variation product
				// 		if (current_button.closest( '.variable-product-add-cart' ).length > 0) {
				// 			product_id = current_button.closest( '.product-cart-wrapper' ).find( '.variation_id' ).val();
				// 		} else {
				// 			product_id = current_button.val();
				// 		}

				// 		if (product_id) {
				// 			nyc_price = $( this ).closest( '.product-cart-chechbox-wrapper' ).find( '.nyp-input' ).val();
				// 			$.post(
				// 				product_table_params.ajax_url,
				// 				{
				// 					'action': 'wcpt_add_to_cart',
				// 					'product_id': product_id,
				// 					'nyp': nyc_price,
				// 					'quantity': product_quantity
				// 					},
				// 				function (response) {
				// 					current_button.closest( '.product-table-wrap' ).find( '.product-table-loader' ).hide();
				// 					after_add_products_cart( response, current_button );
				// 					reset_product_data( current_button );
				// 				}
				// 			);
				// 		}

				// 	}
				// );
				$( document ).on(
					'submit',
					'.product-cart-wrapper form.cart',
					function (e) {
						e.preventDefault();
						var current_button   = $( this ).find('button[type="submit"]:not(.disabled)'),
							product_id       = false,
							product_quantity = current_button.closest( '.product-cart-wrapper' ).find( '.quantity .qty' ).val();

						current_button.closest( '.product-table-wrap' ).find( '.product-table-loader' ).show();
						// get product id for variation product
						if (current_button.closest( '.variable-product-add-cart' ).length > 0) {
							product_id = current_button.closest( '.product-cart-wrapper' ).find( '.variation_id' ).val();
						} else {
							product_id = current_button.val();
						}

						if (product_id) {
							nyc_price = $( this ).closest( '.product-cart-chechbox-wrapper' ).find( '.nyp-input' ).val();
							var formData = $(':not(input[type=hidden])',this).serialize();
							var formData = formData + '&action=wcpt_add_to_cart&nyp=' + nyc_price + '&product_id=' + product_id;
							$.post(
								product_table_params.ajax_url,
								formData,
								function (response) {
									current_button.closest( '.product-table-wrap' ).find( '.product-table-loader' ).hide();
									after_add_products_cart( response, current_button );
									reset_product_data( current_button );
								}
							);
						}

					}
				);

				$( document ).on(
					'click',
					'.product-table-wrap .wcpt-selected-cart',
					function (e) {
						e.preventDefault();
						// simple products
						var current_button    = $( this );
						var selected_products = current_button.closest( '.product-table-wrap' ).find( '.product-cart-chechbox-wrapper .product-cart-chechbox:checked' ),
							quantity          = '',
							product_id        = '',
							product_ids       = [],
							nyc_product_ids	  = [],
							nyp               = {},
							product_quantites = [];
						
							
	
						selected_products.each(
							function (index) {
								// get product id for variation product
								if ($( this ).closest( '.variable-product-add-cart' ).length > 0) {
									product_id = $( this ).closest( '.variable-product-add-cart' ).find( '.variation_id' ).val();
								} else {
									product_id = $( this ).val();
								}
								if (product_id) {
									quantity = $( this ).closest( '.product-cart-chechbox-wrapper' ).find( '.quantity .qty' ).val();
									nyc_price = $( this ).closest( '.product-cart-chechbox-wrapper' ).find( '.nyp-input' ).val();
									product_ids.push( product_id );
									product_quantites.push( quantity );
									
								 
									if(nyc_price){  
										 nyp[product_id] = nyc_price ;
										console.log(nyp);
										
									}
								}
							}
						);	
						if (product_id == '') {
							current_button.closest( '.product-table-wrap' ).find( '.no-product-added' ).remove();
							current_button.closest( '.product-table-wrap' ).find( '.wcpt-added-products' ).remove();
							current_button.closest( '.product-table-wrap' ).find( '.added_to_cart.wc-forward' ).remove();

							current_button.closest( '.wcpt-selected-cart-wrapper' ).append( "<span class='no-product-added'>" + product_table_params.error_message + "</span>" );
						} else {
							current_button.closest( '.product-table-wrap' ).find( '.no-product-added' ).remove();
							current_button.closest( '.product-table-wrap' ).find( '.product-table-loader' ).show();
							 
							$.post(
								product_table_params.ajax_url,
								{
									'action': 'wcpt_add_selected_products_cart',
									'product_ids': product_ids,
									'nyp_data': nyp,
									'product_quantites': product_quantites,
									'nonce': product_table_params.nonce
									},
								function (response) {
									current_button.closest( '.product-table-wrap' ).find( '.product-table-loader' ).hide();
									after_add_products_cart( response, current_button );
									if (response.fragments && response.fragments.wcpt_added_products) {
										if (current_button.closest( '.product-table-wrap' ).find( '.wcpt-added-products' ).length > 0) {
											current_button.closest( '.product-table-wrap' ).find( '.wcpt-added-products' ).remove();
										}
										current_button.after( response.fragments.wcpt_added_products );
									}
									selected_products.each(
										function (index) {
											reset_product_data( $( this ) );
											$( this ).attr( 'checked', false );
										}
									);
								}
							);
						}
					}
				);

				$( document ).on(
					'change',
					'.product-cart-wrapper .variation_id',
					function (e) {
						enable_disable_varitaion_buttons( $( this ) );
					}
				);

				$( document ).on(
					'change keyup',
					'.quantity-wrapper .wc-quantity',
					function () {
						$( this ).parents( 'tr' ).find( '.product-cart-chechbox-wrapper .quantity .qty' ).val( $( this ).val() );
					}
				);

			}
		);

		function enable_disable_varitaion_buttons(variation_element) {
			if (variation_element.val() == 0 || ! variation_element.val()) {
				variation_element.closest( '.product-cart-chechbox-wrapper' ).find( '.product-cart-chechbox' ).attr( 'disabled', 'disabled' );
				variation_element.closest( '.product-cart-chechbox-wrapper' ).find( '.single_add_to_cart_button' ).addClass( 'disabled' );
				variation_element.closest( '.product-cart-chechbox-wrapper' ).find( '.product-cart-chechbox' ).attr( 'checked', false );
			} else {
				variation_element.closest( '.product-cart-chechbox-wrapper' ).find( '.product-cart-chechbox' ).removeAttr( 'disabled', 'disabled' );
				variation_element.closest( '.product-cart-chechbox-wrapper' ).find( '.single_add_to_cart_button' ).removeClass( 'disabled' );
			}
		}

		function reset_product_data(product_element) {
			// set quantity to min value
			var qty_field = product_element.closest( '.product-cart-chechbox-wrapper' ).find( '.quantity .qty' );
			if (qty_field.attr( 'min' )) {
				qty_field.val( qty_field.attr( 'min' ) );
			}
			// reser variatiobs
			if (product_element.closest( '.variable-product-add-cart' ).length > 0) {
				product_element.closest( '.variable-product-add-cart' ).find( '.reset_variations' ).click();
				enable_disable_varitaion_buttons( product_element.closest( '.variable-product-add-cart' ).find( '.variation_id' ) );
			}
		}

		function after_add_products_cart(response, current_button) {
			if ( ! response) {
				return;
			}

			if (response.error && response.product_url) {
				window.location = response.product_url;
				return;
			}

			// Redirect to cart option
			if (wc_add_to_cart_params.cart_redirect_after_add === 'yes') {
				window.location = wc_add_to_cart_params.cart_url;
				return;
			}

			// Trigger event so themes can refresh other areas.
			$( document.body ).trigger( 'added_to_cart', [response.fragments, response.cart_hash, current_button] );
		}

		/**
		 // Pipelining function for DataTables. To be used to the `ajax` option of DataTables
		 **/

		$.fn.dataTable.pipeline = function (opts) {
			// Configuration options
			var conf = $.extend(
				{
					pages: 4, // number of pages to cache
					url: '', // script url
					data: null, // function or object with parameters to send to the server
					// matching how `ajax.data` works in DataTables
					method: 'POST' // Ajax HTTP method
				},
				opts
			);
			// Private variables for storing the cache
			var cacheLower       = -1;
			var cacheUpper       = null;
			var cacheLastRequest = null;
			var cacheLastJson    = null;

			return function (request, drawCallback, settings) {
				var ajax          = false;
				var requestStart  = request.start;
				var drawStart     = request.start;
				var requestLength = request.length;
				var requestEnd    = requestStart + requestLength;

				if (settings.clearCache) {
					// API requested that the cache be cleared
					ajax                = true;
					settings.clearCache = false;
				} else if (cacheLower < 0 || requestStart < cacheLower || requestEnd > cacheUpper) {
					// outside cached data - need to make a request
					ajax = true;
				} else if (JSON.stringify( request.order ) !== JSON.stringify( cacheLastRequest.order ) ||
					JSON.stringify( request.columns ) !== JSON.stringify( cacheLastRequest.columns ) ||
					JSON.stringify( request.search ) !== JSON.stringify( cacheLastRequest.search )
					) {
					// properties changed (ordering, columns, searching)
					ajax = true;
				}

				// Store the request for checking next time around
				cacheLastRequest = $.extend( true, {}, request );

				if (ajax) {
					// Need data from the server
					if (requestStart < cacheLower) {
						requestStart = requestStart - (requestLength * (conf.pages - 1));

						if (requestStart < 0) {
							requestStart = 0;
						}
					}

					cacheLower = requestStart;
					cacheUpper = requestStart + (requestLength * conf.pages);

					request.start  = requestStart;
					request.length = requestLength * conf.pages;

					// Provide the same `data` options as DataTables.
					if (typeof conf.data === 'function') {
						// As a function it is executed with the data object as an arg
						// for manipulation. If an object is returned, it is used as the
						// data object to submit
						var d = conf.data( request );
						if (d) {
							$.extend( request, d );
						}
					} else if ($.isPlainObject( conf.data )) {
						// As an object, the data given extends the default
						$.extend( request, conf.data );
					}

					settings.jqXHR = $.ajax(
						{
							"type": conf.method,
							"url": conf.url,
							"data": request,
							"dataType": "json",
							"cache": false,
							"success": function (json) {
								cacheLastJson = $.extend( true, {}, json );

								if (cacheLower != drawStart) {
									json.data.splice( 0, drawStart - cacheLower );
								}
								if (requestLength >= -1) {
									json.data.splice( requestLength, json.data.length );
								}

								drawCallback( json );
							}
						}
					);
				} else {
					json      = $.extend( true, {}, cacheLastJson );
					json.draw = request.draw; // Update the echo for each response
					json.data.splice( 0, requestStart - cacheLower );
					json.data.splice( requestLength, json.data.length );

					drawCallback( json );
				}
			}
		};

		// Register an API method that will empty the pipelined data, forcing an Ajax
		// fetch on the next draw (i.e. `table.clearPipeline().draw()`)
		$.fn.dataTable.Api.register(
			'clearPipeline()',
			function () {
				return this.iterator(
					'table',
					function (settings) {
						settings.clearCache = true;
					}
				);
			}
		);
		
		// price variation change and stock
		function load_variation_total_price(){ 
			jQuery( '.variations_form' ).each( function() { 

				product_id = jQuery(this).attr('data-product_id');
				variation_id = jQuery(this).find('.variation_id').val();
				if( jQuery(this).find('.variation_id').val() == '' ) {
					jQuery('.price_'+product_id).hide();
					jQuery('.stock_'+product_id).html(jQuery('.stock_'+product_id).attr('data-stock') ); 
				}
				jQuery(this).on( 'found_variation', function( event, variation ) {
				product_id = jQuery(this).attr('data-product_id');
					if( variation.price_html ) {
						// price append
						jQuery('.price_'+product_id).html( "<hr>" + variation.price_html );
						jQuery('.price_'+product_id).show();
					}
					if( variation.availability_html ) {
						// stock append
						jQuery('.stock_'+product_id).html( variation.availability_html );
						jQuery('.stock_'+product_id).show();
					}
					if( !variation.is_in_stock ) {
						jQuery(this).find('.single_add_to_cart_button').addClass('disabled');
					}
				});
			});
		
		}
	}
);
<?php
/**
 * WC_Product_Table_CPT Class
 *
 * @package Woocommerce Product Table/Includes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * WC_Product_Table_CPT Class.
 */
class WC_Product_Table_CPT {


	/**
	 * Init the Product Table Type
	 */
	public function __construct() {
		// create custom post type.
		add_action( 'init', array( $this, 'wcpt_cpt' ) );
		// include scripts.
		add_action( 'admin_enqueue_scripts', array( $this, 'wcpt_enqueue_scripts' ), 20 );
		// Table settings.
		add_action( 'add_meta_boxes', array( $this, 'wcpt_register_meta_boxes' ) );
		add_action( 'save_post', array( $this, 'wcpt_save_post' ), 10, 3 );

		// Add Custom Column.
		add_filter( 'manage_wcpt_posts_columns', array( $this, 'wcpt_set_shortcode_columns' ) );
		add_action( 'manage_wcpt_posts_custom_column', array( $this, 'wcpt_shortcode_column' ), 10, 2 );
		add_filter( 'woocommerce_product_data_tabs', array( $this, 'wcpt_variation_modify_tab' ) );
		add_action( 'woocommerce_product_data_panels', array( $this, 'wcpt_product_bulk_data_fields' ) );
		add_action( 'woocommerce_process_product_meta', array( $this, 'woocommerce_process_product_meta_fields_save' ) );
	}

	public function wcpt_variation_modify_tab( $product_data_tabs ) {
		$product_data_tabs['wcpt-variation-bulk'] = array(
			'label' => __( 'Bulk Order Form', 'woo-product-table' ),
			'target' => 'wcpt_product_bulk_data',
			'class' => array('show_if_variable')
		);
		return $product_data_tabs;
	}

	public function wcpt_product_bulk_data_fields() {
		global $woocommerce, $post;
		?>
		<div id="wcpt_product_bulk_data" class="panel woocommerce_options_panel">
			<?php
			woocommerce_wp_checkbox( array( 
				'id'            => '_show_bulk_variation', 
				'wrapper_class' => 'show_if_variable', 
				'label'         => __( 'Enable Order Form', 'woo-product-table' ),
				'description'   => __( 'Enabling this option will display Bulk Order Form on single product page', 'woo-product-table' ),
				'default'       => '0',
				'desc_tip'      => false
			) );
			?>

				
		</div>
		<?php
	}

	public function woocommerce_process_product_meta_fields_save( $post_id ) {
		$data = $_REQUEST;
		$woo_checkbox = isset( $data['_show_bulk_variation'] ) ? 'yes' : 'no';
		update_post_meta( $post_id, '_show_bulk_variation', $woo_checkbox );
	}

	/**
	 * Create product table custom post type.
	 */
	public function wcpt_cpt() {
		/**
		 * Filter product table menu title
		 * 
		 * @since 1.1.5
		**/
		$product_table_title = apply_filters( 'wcpt_menu_title', __( 'Product Table', 'woo-product-table' ) );
		$button_labels = array(
			'name'               => $product_table_title,
			'singular_name'      => $product_table_title,
			'menu_name'          => $product_table_title,
			'name_admin_bar'     => $product_table_title,
			'add_new'            => __( 'Add New', 'woo-product-table' ),
			'add_new_item'       => __( 'Add New Product Table', 'woo-product-table' ),
			'new_item'           => __( 'New Product Table', 'woo-product-table' ),
			'edit_item'          => __( 'Edit Product Table', 'woo-product-table' ),
			'view_item'          => __( 'View Product Table', 'woo-product-table' ),
			'all_items'          => __( 'Product Table', 'woo-product-table' ),
			'search_items'       => __( 'Search Product Table', 'woo-product-table' ),
			'parent_item_colon'  => __( 'Parent Product Table:', 'woo-product-table' ),
			'not_found'          => __( 'No results found.', 'woo-product-table' ),
			'not_found_in_trash' => __( 'No results found in Trash.', 'woo-product-table' ),
		);

		$button_args = array(
			'labels'             => $button_labels,
			'description'        => __( 'Products Table.', 'woo-product-table' ),
			'public'             => false,
			'publicly_queryable' => false,
			'show_ui'            => true,
			/**
			 * Filter product table show in menu
			 * 
			 * @since 1.1.5
			**/
			'show_in_menu'       => apply_filters('wcpt_show_in_menu', 'woocommerce'),
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'wcpt' ),
			'capability_type'    => 'post',
			/**
			 * Filter product table menu position
			 * 
			 * @since 1.1.5
			**/
			'menu_position'      => apply_filters( 'wcpt_menu_position', null ),
			'menu_icon'          => 'dashicons-editor-table',
			// 'has_archive'        => true,
			// 'hierarchical'       => false,
			'supports'           => array( 'title' ),
		);

		register_post_type( 'wcpt', $button_args );
	}

	/**
	 * Enqueue scripts in backend
	 */
	public function wcpt_enqueue_scripts() {
		global $post_type;
		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		if ( 'wcpt' !== $post_type ) {
			return;
		}

		wp_enqueue_style( 'wcpt-jquery-ui-style', WCPT_PLUGIN_URL . '/assets/css/jquery-ui/jquery-ui.min.css', array(), WCPT_PLUGIN_VERSION );
		wp_enqueue_style( 'wcpt-style', WCPT_PLUGIN_URL . '/assets/css/admin/style' . $suffix . '.css', array(), WCPT_PLUGIN_VERSION );
		wp_enqueue_style( 'wcpt-select2', WCPT_PLUGIN_URL . '/assets/css/admin/select2/select2' . $suffix . '.css', array(), WCPT_PLUGIN_VERSION );
		wp_enqueue_style( 'woocommerce_admin_styles', WC()->plugin_url() . '/assets/css/admin.css', array(), WC_VERSION );
		wp_enqueue_script( 'wcpt-scripts', WCPT_PLUGIN_URL . 'assets/js/admin/wcpt-scripts' . $suffix . '.js', array( 'jquery', 'jquery-ui-droppable', 'jquery-ui-sortable', 'jquery-ui-draggable', 'jquery-ui-dialog' ), WCPT_PLUGIN_VERSION, true );
		wp_enqueue_script( 'wcpt-select2', WCPT_PLUGIN_URL . 'assets/js/admin/select2/select2' . $suffix . '.js', array( 'jquery' ), WCPT_PLUGIN_VERSION, true );
		wp_enqueue_script( 'jquery-tiptip' );

		// please create also an empty JS file in your theme directory and include it too.
		wp_enqueue_script( 'wcpt-custom-sel', WCPT_PLUGIN_URL . 'assets/js/admin/wcpt-settings-script' . $suffix . '.js', array( 'jquery', 'wcpt-select2', 'jquery-ui-datepicker' ), WCPT_PLUGIN_VERSION, true );
	}

	/**
	 * Register metabox
	 */
	public function wcpt_register_meta_boxes() {
		add_meta_box( 'wcpt-settings', __( 'Product Table Settings', 'woo-product-table' ), array( $this, 'wcpt_settings_display_callback' ), 'wcpt' );

		add_meta_box( 'wcpt-header-footer-settings', __( 'Table Header & Footer Settings', 'woo-product-table' ), array( $this, 'wcpt_header_footer_display_options' ), 'wcpt' );
		add_meta_box( 'wcpt-variation-product-settings', __( 'Variation Product Display Settings', 'woo-product-table' ), array( $this, 'wcpt_variation_product_display_options' ), 'wcpt' );
		add_meta_box( 'wcpt-table-contols-settings', __( 'Add controls above & below the table Settings', 'woo-product-table' ), array( $this, 'wcpt_table_controls_display_options' ), 'wcpt' );
		add_meta_box( 'wcpt-table-size-settings', __( 'Control Table Size Settings', 'woo-product-table' ), array( $this, 'wcpt_table_size_display_options' ), 'wcpt' );
		add_meta_box( 'wcpt-table-content-settings', __( 'Control Table Contents Settings', 'woo-product-table' ), array( $this, 'wcpt_table_content_display_options' ), 'wcpt' );
		add_meta_box( 'wcpt-adv-search-settings', __( 'Advanced Search Settings', 'woo-product-table' ), array( $this, 'wcpt_advanced_search_display_options' ), 'wcpt' );
		add_meta_box( 'wcpt-product-sorted-settings', __( 'Controls how products are sorted Settings', 'woo-product-table' ), array( $this, 'wcpt_products_sort_display_options' ), 'wcpt' );
		add_meta_box( 'wcpt-products-display-settings', __( 'Choosing which products appear in the table', 'woo-product-table' ), array( $this, 'wcpt_products_display_options' ), 'wcpt' );
		add_meta_box( 'wcpt-responsive-settings', __( 'Responsive', 'woo-product-table' ), array( $this, 'wcpt_responsive_display_options' ), 'wcpt' );
		if ( class_exists( 'WC_Product_Addons' ) ) {
			add_meta_box( 'wcpt-product-addon-settings', __( 'Product Addons', 'woo-product-table' ), array( $this, 'wcpt_product_addon_settings' ), 'wcpt' );
		}
		if ( class_exists( 'Wwp_Wholesale_Pricing' ) ) {
			add_meta_box( 'wcpt-wholesale-settings', __( 'Wholesale Settings', 'woo-product-table' ), array( $this, 'wcpt_wholesaler_settings' ), 'wcpt' );
		}
		add_meta_box( 'wcpt-shortcode-generates', __( 'Shortcode', 'woo-product-table' ), array( $this, 'wcpt_shortcode_display_options' ), 'wcpt', 'side' );
	}

	/**
	 * Mapping settings callback
	 *
	 * @param int $post post id.
	 */
	public function wcpt_settings_display_callback( $post ) {
		$id = $post->ID;

		$table_fields = get_post_meta( get_the_ID(), 'product_table_fields', true );
		$names        = array(
			'woo_column_ids'               => 'woo_ids',
			'woo_column_name'              => 'woo_label',
			'woo_column_linkable'          => 'woo_linkable',
			'woo_column_width'             => 'woo_width_text',
			'woo_column_width_type'        => 'woo_width_type',
			'woo_column_descr'             => 'woo_descr',
			'woo_column_date_format'       => 'woo_date_format',
			'woo_column_add_types'         => 'woo_add_types',
			'woo_column_add_selected_cart' => 'woo_add_selected_cart',
			'woo_column_quantity'          => 'woo_quantity',
			'woo_column_attrs'             => 'woo_attrs',
			'woo_column_custom_keys'       => 'woo_custom_keys',
			'woo_column_taxonomy'          => 'woo_taxonomy',
		);

		$mapping_labels = array(
			'id'            => __( 'ID', 'woo-product-table' ),
			'title'         => __( 'Title', 'woo-product-table' ),
			'sku'           => __( 'SKU', 'woo-product-table' ),
			'short_desc'    => __( 'Short Description', 'woo-product-table' ),
			'descr'         => __( 'Description', 'woo-product-table' ),
			'date'          => __( 'Date', 'woo-product-table' ),
			'cat'           => __( 'Categories', 'woo-product-table' ),
			'featured_img'  => __( 'Featured Image', 'woo-product-table' ),
			'reviews'       => __( 'Reviews', 'woo-product-table' ),
			'stock'         => __( 'Stock', 'woo-product-table' ),
			'weight'        => __( 'Weight', 'woo-product-table' ),
			'dimensions'    => __( 'Dimensions', 'woo-product-table' ),
			'price'         => __( 'Price', 'woo-product-table' ),
			'cart_button'   => __( 'Add To Cart Button', 'woo-product-table' ),
			'attributes'    => __( 'Attributes', 'woo-product-table' ),
			'custom_fields' => __( 'Custom Fields', 'woo-product-table' ),
			'tags'          => __( 'Tags', 'woo-product-table' ),
			'taxonomy'      => __( 'Taxonomy', 'woo-product-table' ),
		);
		wp_nonce_field( 'wcpt_settings_display_callback', 'wcpt_settings_display_nonce' );
		require_once WCPT_PLUGIN_FILE . 'includes/views/product-table-settings.php';
	}

	/**
	 * Header Footer Options
	 *
	 * @param int $post post id.
	 */
	public function wcpt_header_footer_display_options( $post ) {
		$post_id        = $post->ID;
		$header_checked = get_post_meta( $post_id, 'display_table_header', true );
		$footer_checked = get_post_meta( $post_id, 'display_table_footer', true );

		require_once WCPT_PLUGIN_FILE . 'includes/views/admin/meta-boxes/html-header-footer-options.php';
	}

	/**
	 * Variation Display Options
	 *
	 * @param int $post post id.
	 */
	public function wcpt_variation_product_display_options( $post ) {
		require_once WCPT_PLUGIN_FILE . 'includes/views/admin/meta-boxes/html-variation-product-display-options.php';
	}

	/**
	 * Table Controls Display Options
	 *
	 * @param int $post post id.
	 */
	public function wcpt_table_controls_display_options( $post ) {
		$post_id             = $post->ID;
		$show_page_length    = get_post_meta( $post_id, 'display_page_length', true );
		$show_product_totals = get_post_meta( $post_id, 'display_product_totals', true );
		$show_pagination     = get_post_meta( $post_id, 'display_pagination', true );
		$wcpt_wrap           = get_post_meta( $post_id, 'wcpt_wrap', true );
		require_once WCPT_PLUGIN_FILE . 'includes/views/admin/meta-boxes/html-controls-table-options.php';
	}

	/**
	 * Table Size Display Options
	 *
	 * @param int $post post id.
	 */
	public function wcpt_table_size_display_options( $post ) {
		require_once WCPT_PLUGIN_FILE . 'includes/views/admin/meta-boxes/html-table-size-options.php';
	}

	/**
	 * Table Content Display Options
	 *
	 * @param int $post post id.
	 */
	public function wcpt_table_content_display_options( $post ) {
		$post_id         = $post->ID;
		$shortocode_html = get_post_meta( $post_id, 'shortocode_html_formatting', true );

		require_once WCPT_PLUGIN_FILE . 'includes/views/admin/meta-boxes/html-table-content-options.php';
	}

	/**
	 * Table Advanced Search Display Options
	 *
	 * @param int $post post id.
	 */
	public function wcpt_advanced_search_display_options( $post ) {
		$post_id            = $post->ID;
		$show_search        = get_post_meta( $post_id, 'show_search', true );
		$show_filter        = get_post_meta( $post_id, 'show_filter', true );
		$show_reset         = get_post_meta( $post_id, 'display_reset', true );
		$product_taxonomies = get_object_taxonomies( 'product', 'objects' );
		$saved_filters      = get_post_meta( $post_id, 'wcpt_filters_obj', true );
		if ( $product_taxonomies ) {
			$selected_option     = array();
			$product_tax_objects = array();

			$taxonomy_excluded = array(
				'product_visibility',
				'product_type',
				'product_shipping_class',
			);

			foreach ( $product_taxonomies as $k => $product_taxonomy ) {
				if ( in_array( $k, $taxonomy_excluded, true ) ) {
					continue;
				}
				$product_tax_objects[ $k ] = $product_taxonomy->label;
			}
			if ( $saved_filters ) {
				foreach ( $saved_filters as $saved_filter ) {
					$selected_option[ $saved_filter ] = $product_tax_objects[ $saved_filter ];
				}
			}

			$selected_option = $selected_option + $product_tax_objects;
		}

		require_once WCPT_PLUGIN_FILE . 'includes/views/admin/meta-boxes/html-advanced-search-options.php';
	}

	/**
	 * Table Sort Display Options
	 *
	 * @param int $post post id.
	 */
	public function wcpt_products_sort_display_options( $post ) {
		$post_id                   = $post->ID;
		$enable_clickable_sort_col = get_post_meta( $post_id, 'enable_sort_cols', true );
		$product_table_fields      = get_post_meta( $post_id, 'product_table_fields', true );
		$selected_option           = array();
		$fields                    = array();
		$default_sorted            = '';

		$saved_sorting_fields  = get_post_meta( $post_id, 'sorted_cols', true );
		$saved_sorting_default = get_post_meta( $post_id, 'default_sorted_col', true );
		if ( $product_table_fields ) {
			$acceptable_sorting_fields = array(
				'id',
				'title',
				'date',
				'reviews',
				'price',
			);

			foreach ( $product_table_fields as $i => $product_table_field ) {
				if ( in_array( $product_table_field['woo_ids'], $acceptable_sorting_fields, true ) ) {
					$fields[ $product_table_field['woo_ids'] . '_' . $i ] = $product_table_field['woo_label'];
				}
			}

			if ( $saved_sorting_default ) {
				$sel = (int) substr( strrchr( $saved_sorting_default, '_' ), 1 );
				if ( is_int( $sel ) ) {
					$default_sorted = $product_table_fields[ $sel ]['woo_ids'] . '_' . $sel;
				} else {
					$default_sorted = '';
				}
			} else {
				$default_sorted = '';
			}

			if ( $saved_sorting_fields ) {
				foreach ( $saved_sorting_fields as $saved_sorting_field ) {
					$selected[] = (int) substr( strrchr( $saved_sorting_field, '_' ), 1 );
				}
				foreach ( $selected as $select ) {
					if ( is_int( $select ) ) {
						$selected_option[ $product_table_fields[ $select ]['woo_ids'] . '_' . $select ] = $product_table_fields[ $select ]['woo_label'];
					}
				}
			}

			$selected_option = $selected_option + $fields;
		}

		require_once WCPT_PLUGIN_FILE . 'includes/views/admin/meta-boxes/html-products-sort-options.php';
	}

	/**
	 * Table Products Display Options
	 *
	 * @param int $post post id.
	 */
	public function wcpt_products_display_options( $post ) {
		$post_id = $post->ID;

		$product_ids     = get_post_meta( $post_id, 'wcpt_inc_product_ids', true );
		$product_exc_ids = get_post_meta( $post_id, 'wcpt_ex_product_ids', true );

		$product_categories = get_terms( 'product_cat', 'orderby=name&hide_empty=0' );
		$product_tags       = get_terms( 'product_tag', 'hide_empty=0' );

		if ( $product_categories ) {
			$category_options = array();
			foreach ( $product_categories as $product_category ) {
				$category_options[ $product_category->term_id ] = $product_category->name;
			}
		}

		if ( $product_tags ) {
			$tag_options = array();
			foreach ( $product_tags as $product_tag ) {
				$tag_options[ $product_tag->term_id ] = $product_tag->name;
			}
		}

		require_once WCPT_PLUGIN_FILE . 'includes/views/admin/meta-boxes/html-products-display-options.php';
	}

	/**
	 * Table Responsive Display Options
	 *
	 * @param int $post post id.
	 */
	public function wcpt_responsive_display_options( $post ) {
		$post_id            = $post->ID;
		$mobile_check       = get_post_meta( $post_id, 'mobile_icon_chck', true );
		$tablet_check       = get_post_meta( $post_id, 'tablet_icon_chck', true );
		$responsive_checked = get_post_meta( $post_id, 'display_responsive', true ) ? get_post_meta( $post_id, 'display_responsive', true ) : 'fully_resp';

		$product_table_fields = get_post_meta( $post_id, 'product_table_fields', true );

		$acceptable_fields = array(
			'id',
			'title',
			'sku',
			'date',
			'price',
			'descr',
			'short_desc',
			'reviews',
			'price',
		);

		$selected_option        = array();
		$selected_mobile_option = array();
		$selected_tablet_option = array();
		$saved_fields           = get_post_meta( $post_id, 'columns_show', true );
		$mobile_save_fields     = get_post_meta( $post_id, 'columns_mobile_show', true );
		$tablet_save_fields     = get_post_meta( $post_id, 'columns_tablet_show', true );

		if ( $product_table_fields ) {
			foreach ( $product_table_fields as $i => $product_table_field ) {
				$field_option[ $product_table_field['woo_ids'] . '_' . $i ] = $product_table_field['woo_label'];
				/*if ( in_array( $product_table_field['woo_ids'], $acceptable_fields, true ) ) {
					
				}*/
			}

			if ( $saved_fields ) {
				foreach ( $saved_fields as $saved_field ) {
					$selected[] = (int) substr( strrchr( $saved_field, '_' ), 1 );
				}
				foreach ( $selected as $select ) {
					$selected_option[ $product_table_fields[ $select ]['woo_ids'] . '_' . $select ] = $product_table_fields[ $select ]['woo_label'];
				}
			}
			if ( $mobile_save_fields ) {
				foreach ( $mobile_save_fields as $mobile_save_field ) {
					$selected_mobile[] = (int) substr( strrchr( $mobile_save_field, '_' ), 1 );
				}
				foreach ( $selected_mobile as $select ) {
					$selected_mobile_option[ $product_table_fields[ $select ]['woo_ids'] . '_' . $select ] = $product_table_fields[ $select ]['woo_label'];
				}
			}
			if ( $tablet_save_fields ) {
				foreach ( $tablet_save_fields as $tablet_save_field ) {
					$selected_tablet[] = (int) substr( strrchr( $tablet_save_field, '_' ), 1 );
				}
				foreach ( $selected_tablet as $select ) {
					$selected_tablet_option[ $product_table_fields[ $select ]['woo_ids'] . '_' . $select ] = $product_table_fields[ $select ]['woo_label'];
				}
			}
			$selected_option        = $selected_option + $field_option;
			$selected_mobile_option = $selected_mobile_option + $field_option;
			$selected_tablet_option = $selected_tablet_option + $field_option;
		}

		require_once WCPT_PLUGIN_FILE . 'includes/views/admin/meta-boxes/html-responsive-options.php';
	}

	/**
	 * Table Wholesaler Role Options
	 *
	 * @param int $post post id.
	 */
	public function wcpt_wholesaler_settings( $post ) {
		$post_id = $post->ID;

		$display_wholesale_only     = get_post_meta( $post_id, 'display_wholesale_only', true );
		$selected_roles = get_post_meta( $post_id, 'wcpt_wholesale_selected_roles', true );

		$wholesale_user_roles       = get_terms( 'wholesale_user_roles', 'hide_empty=0' );

		if ( $wholesale_user_roles ) {
			$user_roles = array();
			foreach ( $wholesale_user_roles as $wholesale_user_role ) {
				$user_roles[ $wholesale_user_role->slug ] = $wholesale_user_role->name;
			}
		}

		require_once WCPT_PLUGIN_FILE . 'includes/views/admin/meta-boxes/html-wholesale-user-settings.php';
	}
	/**
	 * Table Wholesaler Role Options
	 *
	 * @param int $post post id.
	 */
	public function wcpt_product_addon_settings( $post ) {
		$post_id = $post->ID;
		$display_product_addon     = !empty( get_post_meta( $post_id, 'wcpt_addon_display', true ) ) ? get_post_meta( $post_id, 'wcpt_addon_display', true ) : 'vertical';

		require_once WCPT_PLUGIN_FILE . 'includes/views/admin/meta-boxes/html-product-addon-settings.php';
	}

	/**
	 * Table Shortcode
	 *
	 * @param int $post post id.
	 */
	public function wcpt_shortcode_display_options( $post ) {
		echo esc_html( "[wc_products_table id=$post->ID]" );
	}

	/**
	 * Table Save
	 *
	 * @param int $product_table_id product table id.
	 * @param int $post post id.
	 * @param int $update update.
	 */
	public function wcpt_save_post( $product_table_id, $post, $update ) {

		// Only set for post_type = post!.
		if ( 'wcpt' !== $post->post_type ) {
			return;
		}

		if ( ! isset( $_POST['wcpt_settings_display_nonce'] ) ) {
			return;
		}

		// Verify that the nonce is valid.
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wcpt_settings_display_nonce'] ) ), 'wcpt_settings_display_callback' ) ) {
			return;
		}
		$fields = array();

		$link_key   = 0;
		$descr_key  = 0;
		$date_key   = 0;
		$attr_key   = 0;
		$tax_key    = 0;
		$custom_key = 0;
		$cart_key   = 0;
		if ( isset( $_POST['woo_ids'] ) ) {
			$woo_ids = array_map( 'sanitize_text_field', wp_unslash( $_POST['woo_ids'] ) );
			foreach ( $woo_ids as $key => $id ) {
				$fields[ $key ]['woo_ids'] = $id;
				if ( isset( $_POST['woo_label'][ $key ] ) ) {
					$fields[ $key ]['woo_label'] = sanitize_text_field( wp_unslash( $_POST['woo_label'][ $key ] ) );
				}

				if ( isset( $_POST['woo_width_text'] ) ) {
					if ( isset( $_POST['woo_width_text'][ $key ] ) ) {
						$width_text = sanitize_text_field( wp_unslash( $_POST['woo_width_text'][ $key ] ) );
					}

					if ( $width_text ) {
						if ( isset( $_POST['woo_width_type'][ $key ] ) ) {
							$width_type = sanitize_text_field( wp_unslash( $_POST['woo_width_type'][ $key ] ) );
						}
						if ( 'percent' === $width_type ) {
							$option = '%';
						} else {
							$option = 'px';
						}
						$fields[ $key ]['woo_width']      = $width_text . '' . $option;
						$fields[ $key ]['woo_width_text'] = $width_text;
						$fields[ $key ]['woo_width_type'] = $width_type;
					} else {
						$fields[ $key ]['woo_width']      = '';
						$fields[ $key ]['woo_width_text'] = '';
					}
				}

				if ( isset( $_POST['woo_linkable'][ $link_key ] ) && ( 'title' === $id || 'featured_img' === $id ) ) {
					$fields[ $key ]['woo_linkable'] = sanitize_text_field( wp_unslash( $_POST['woo_linkable'][ $link_key ] ) );
					$link_key++;
				} elseif ( isset( $_POST['woo_descr'][ $descr_key ] ) && 'descr' === $id ) {
					$fields[ $key ]['woo_descr'] = sanitize_text_field( wp_unslash( $_POST['woo_descr'][ $descr_key ] ) );
					$descr_key++;
				} elseif ( isset( $_POST['woo_date_format'][ $date_key ] ) && 'date' === $id ) {
					$fields[ $key ]['woo_date_format'] = sanitize_text_field( wp_unslash( $_POST['woo_date_format'][ $date_key ] ) );
					$date_key++;
				} elseif ( isset( $_POST['woo_attrs'][ $attr_key ] ) && 'attributes' === $id ) {
					$fields[ $key ]['woo_attrs'] = sanitize_text_field( wp_unslash( $_POST['woo_attrs'][ $attr_key ] ) );
					$attr_key++;
				} elseif ( isset( $_POST['woo_custom_keys'][ $custom_key ] ) && 'custom_fields' === $id ) {
					$fields[ $key ]['woo_custom_keys'] = sanitize_text_field( wp_unslash( $_POST['woo_custom_keys'][ $custom_key ] ) );
					$custom_key++;
				} elseif ( isset( $_POST['woo_taxonomy'][ $tax_key ] ) && 'taxonomy' === $id ) {
					$fields[ $key ]['woo_taxonomy'] = sanitize_text_field( wp_unslash( $_POST['woo_taxonomy'][ $tax_key ] ) );
					$tax_key++;
				} elseif ( ( isset( $_POST['woo_quantity'][ $cart_key ] ) || isset( $_POST['woo_add_types'][ $cart_key ] ) || isset( $_POST['woo_add_selected_cart'][ $cart_key ] ) ) && 'cart_button' === $id ) {
					$fields[ $key ]['woo_quantity']          = sanitize_text_field( wp_unslash( $_POST['woo_quantity'][ $cart_key ] ) );
					$fields[ $key ]['woo_add_types']         = sanitize_text_field( wp_unslash( $_POST['woo_add_types'][ $cart_key ] ) );
					$fields[ $key ]['woo_add_selected_cart'] = sanitize_text_field( wp_unslash( $_POST['woo_add_selected_cart'][ $cart_key ] ) );
					$cart_key++;
				}
			}
		}

		update_post_meta( $product_table_id, 'product_table_fields', $fields );

		$wcpt_meta_settings = array(
			'display_wholesale_only',
			'display_table_header',
			'display_table_footer',
			'display_reset',
			'display_page_length',
			'display_product_totals',
			'display_pagination',
			'variable_list_view',
			'wcpt_custom_products_msg',
			'default_sorted_col',
			'default_sorted_dir',
			'wcpt_rows_page',
			'wcpt_product_limit',
			'enable_sort_cols',
			'show_search',
			'show_filter',
			'wcpt_inc_product_cats',
			'wcpt_wholesale_selected_roles',
			'wcpt_addon_display',
			'wcpt_inc_product_tags',
			'wcpt_product_status',
			'wcpt_ex_product_cats',
			'display_responsive',
			'columns_show',
			'wcpt_date_opt',
			'wcpt_date',
			'wcpt_filters_col',
			'wcpt_filters_obj',
			'filter_product_based_term',
			'shortocode_html_formatting',
			'wcpt_wrap',
			'wcpt_scroll',
			'wcpt_checked',
			'sorted_cols',
			'mobile_icon_chck',
			'columns_mobile_show',
			'tablet_icon_chck',
			'columns_tablet_show',
			'pagingType',
		);

		foreach ( $wcpt_meta_settings as $wcpt_meta_setting ) {
			if ( isset( $_POST[ $wcpt_meta_setting ] ) ) {
				if ( is_array( $_POST[ $wcpt_meta_setting ] ) ) {
					$wcpt_meta = array_map( 'sanitize_text_field', wp_unslash( $_POST[ $wcpt_meta_setting ] ) );
				} else {
					$wcpt_meta = sanitize_text_field( wp_unslash( $_POST[ $wcpt_meta_setting ] ) );
				}

							update_post_meta( $product_table_id, $wcpt_meta_setting, $wcpt_meta );
			} else {
							update_post_meta( $product_table_id, $wcpt_meta_setting, '' );
			}
		}

		if ( isset( $_POST['wcpt_inc_product_ids'] ) ) {
			$product_ids = sanitize_text_field( wp_unslash( $_POST['wcpt_inc_product_ids'] ) ) ? explode( ',', sanitize_text_field( wp_unslash( $_POST['wcpt_inc_product_ids'] ) ) ) : '';
			update_post_meta( $product_table_id, 'wcpt_inc_product_ids', $product_ids );
		}

		if ( isset( $_POST['wcpt_ex_product_ids'] ) ) {
			$product_ex_ids = sanitize_text_field( wp_unslash( $_POST['wcpt_ex_product_ids'] ) ) ? explode( ',', sanitize_text_field( wp_unslash( $_POST['wcpt_ex_product_ids'] ) ) ) : '';
			update_post_meta( $product_table_id, 'wcpt_ex_product_ids', $product_ex_ids );
		}
	}

	/**
	 * Table Set Columns Shortcode
	 *
	 * @param int $columns columns.
	 */
	public function wcpt_set_shortcode_columns( $columns ) {
		$columns['shortcode'] = __( 'Shortcode', 'woo-product-table' );

		return $columns;
	}

	/**
	 * Table Columns Shortcode
	 *
	 * @param int $column column.
	 * @param int $post_id post id.
	 */
	public function wcpt_shortcode_column( $column, $post_id ) {

		if ( 'shortcode' === $column ) {
			echo esc_html( "[wc_products_table id=$post_id]" );
		}
	}
}

new WC_Product_Table_CPT();

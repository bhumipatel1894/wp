<?php
/**
 * WooCommerce Product Table setup
 *
 * @package Woocommerce Product Table/Includes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * WC_Product_Table Class.
 */
class WC_Product_Table {


	/**
	 * Create single instance of the class.
	 *
	 * @var static
	 */
	protected static $instance = null;

	/**
	 * Create WooCommerce Product Table Instance.
	 *
	 * @return WooCommerce Product Table - Main instance.
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * WooCommerce Product Table Constructor.
	 */
	public function __construct() {
		$this->includes();
		$this->ajax();
		/**
		 * Action product table loaded
		 * 
		 * @since 1.1.5
		**/
		do_action( 'wcpt_product_table_loaded' );
		add_action( 'wcpt_single_variation', 'woocommerce_single_variation_add_to_cart_button', 20 );
		add_action( 'wp', array( $this, 'remove_product_fields' ) );
		
	}

	public static function remove_product_fields() {
		global $post;

		if ( $post && 'product' === $post->post_type && is_product() ) {
			$product_id = $post->ID;
			$product    = wc_get_product( $product_id );
			if ( is_a( $product, 'WC_Product_Variable' ) ) {
				$enable = 'yes' === get_post_meta( $product_id, '_show_bulk_variation', true ) ? true : false;
				if ( $enable ) {
					add_action( 'woocommerce_before_single_product', array( __CLASS__, 'hook_into_summary_actions' ), 1 );
				}
			}
		}

	}

	public static function hook_into_summary_actions() {

		if ( has_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart' ) ) {
			$location = has_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart' );
			remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', $location );
			add_action( 'woocommerce_single_product_summary', array( __CLASS__, 'print_variation_table' ), 21 );
		} elseif ( has_action( 'woocommerce_single_product_summary_single_add_to_cart', 'woocommerce_template_single_add_to_cart' ) ) {
			$location = has_action( 'woocommerce_single_product_summary_single_add_to_cart', 'woocommerce_template_single_add_to_cart' );
			remove_action( 'woocommerce_single_product_summary_single_add_to_cart', 'woocommerce_template_single_add_to_cart', $location );
			add_action( 'woocommerce_single_product_summary_single_add_to_cart', array( __CLASS__, 'print_variation_table' ) );
		} else {
			remove_action( 'woocommerce_variable_add_to_cart', 'woocommerce_variable_add_to_cart', 30 );
			add_action( 'woocommerce_variable_add_to_cart', array( __CLASS__, 'print_variation_table' ), 30 );
		}

	}
	public static function print_variation_table() {
		global $product;
		$product_id = $product ? $product->get_id() : 0;
		$variations_data = array( 'variation_attribute' => '', 'variation_images' => 'row' );
		$variations_structure = array();
		if ( $product_id ) {
			$attributes =  array_keys($product->get_variation_attributes());
			$variations_structure['columnsxz'] = isset( $attributes[0] ) ? $attributes[0] : '';
			$variations_structure['rows'] = isset( $attributes[1] ) ? $attributes[1] : '';

			$atts = array_merge( $variations_data, $variations_structure );

			$atts['include'] = $product_id;

			// Fill-in missing attributes
			$r = wp_parse_args( $atts, WCPTArgs::get_defaults() );

			// Return the table as HTML
			$grid = WCPTGrid_Factory::create( $r );
			/**
			 * Filter product table output
			 * 
			 * @since 1.1.5
			**/
			$output = apply_filters( 'wcpt_product_output', $grid->render(), $product_id );

			// disables $theme_compat styling
			$styles  = '';
			$classes = array();

			$classes = implode(
				' ',
				array_merge(
					array( 'wcpt-table-wrapper' ),
					/**
					 * Filter wcpt product classes
					 * 
					 * @since 1.1.5
					**/
					apply_filters(
						'wcpt_product_classes',
						$classes,
						$product_id
					)
				)
			);

			printf(
				'<div class="%2$s" %3$s>%1$s</div>',
				nl2br($output),
				esc_attr($classes),
				esc_attr($styles)
			);
		}
	}

	/**
	 * Include required core files used in admin and on the frontend.
	 */
	public function includes() {
		
		require_once WCPT_PLUGIN_FILE . 'includes/class-wcpt-cart.php';

		require_once WCPT_PLUGIN_FILE . 'includes/class-wcpt-product-args.php';

		require_once WCPT_PLUGIN_FILE . 'includes/class-wcpt-grid-factory.php';

		require_once WCPT_PLUGIN_FILE . 'includes/class-wcpt-grid.php';

		require_once WCPT_PLUGIN_FILE . 'includes/class-wcpt-data-factory.php';
		/**
		 * Wc product table CPT
		 */
		require_once WCPT_PLUGIN_FILE . 'includes/class-wc-product-table-cpt.php';
		/**
		 * WC Product Table Quick Order Form
		 */
		require_once WCPT_PLUGIN_FILE . 'includes/class-wcpt-quick-order.php';
		/**
		 * Wc product table Functions
		 */
		require_once WCPT_PLUGIN_FILE . 'includes/wc-product-table-core-functions.php';
		/**
		 * Wc product table Core shortcodes
		 */
		require_once WCPT_PLUGIN_FILE . 'includes/shortcodes/class-product-table-shortcode.php';

		/**
		 * Wc quick order Core shortcodes
		 */
		require_once WCPT_PLUGIN_FILE . 'includes/shortcodes/class-quick-order-shortcode.php';

		require_once WCPT_PLUGIN_FILE . 'includes/Common/class-wcpt-common-collection.php';

		require_once WCPT_PLUGIN_FILE . 'includes/class-wcpt-quick-order-process.php';
	}

	/**
	 * Define woocommerce product table ajax
	 */
	public function ajax() {
		// load woocommerce products.
		add_action( 'wp_ajax_wcpt_load_products', array( $this, 'wcpt_load_products' ) );
		add_action( 'wp_ajax_nopriv_wcpt_load_products', array( $this, 'wcpt_load_products' ) );
		// add woocommerce product to cart.
		add_action( 'wp_ajax_wcpt_add_to_cart', array( $this, 'wcpt_add_to_cart' ) );
		add_action( 'wp_ajax_nopriv_wcpt_add_to_cart', array( $this, 'wcpt_add_to_cart' ) );
		// add woocommerce multiple products to cart.
		add_action( 'wp_ajax_wcpt_add_selected_products_cart', array( $this, 'wcpt_add_selected_products_cart' ) );
		add_action( 'wp_ajax_nopriv_wcpt_add_selected_products_cart', array( $this, 'wcpt_add_selected_products_cart' ) );
		// Set names of the products that added to cart.
		add_filter( 'woocommerce_add_to_cart_fragments', array( $this, 'wcpt_set_title_products_added_cart' ) );
	}

	/**
	 * Get woocommerce product table headings.
	 *
	 * @param int $product_table_id table id.
	 * @return array $product_table_headings
	 */
	public function products_table_heading( $product_table_id ) {
		// Check if display table heading or not.
		$product_table_headings = array();
		// get product table fields.
		$product_table_fields = wc_product_table()->get_product_table_fields( $product_table_id );
		if ( $product_table_fields ) {
			foreach ( $product_table_fields as $product_table_field ) {
				$product_table_headings[] = array(
					'label' => $product_table_field['woo_label'],
					'type'  => $product_table_field['woo_ids'],
					'width' => $product_table_field['woo_width'],
				);
			}
		}
		/**
		 * Filter product table headings
		 * 
		 * @since 1.1.5
		**/
		return apply_filters( 'wcpt_product_table_headings', $product_table_headings, $product_table_fields, $product_table_id );
	}

	/**
	 * Get product table selected product to cart position.
	 *
	 * @param int $product_table_id product table id.
	 * @return string $selected_cart_position
	 */
	public function product_table_add_selected_cart( $product_table_id ) {
		$selected_cart_position = '';
		// get product table fields.
		$product_table_fields = wc_product_table()->get_product_table_fields( $product_table_id );
		if ( $product_table_fields ) {
			foreach ( $product_table_fields as $product_table_field ) {
				if ( 'cart_button' === $product_table_field['woo_ids'] && 'add_button' !== $product_table_field['woo_add_types'] ) {
					$selected_cart_position = $product_table_field['woo_add_selected_cart'];
				}
			}
		}
		/**
		 * Filter wcpt selected cart position
		 * 
		 * @since 1.1.5
		**/
		return apply_filters( 'wcpt_selected_cart_position', $selected_cart_position, $product_table_fields, $product_table_id );
	}

	/**
	 * Load woocommerce products
	 */
	public function wcpt_load_products() {
		// get request data.
		if ( ! isset( $_POST['nonce'] ) ) {
					return;
		}
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'ajax-nonce' ) ) {
					return;
		}

		$wcpt_collection = new WCPT_Common_Collection( $_POST );
		// get products data.
		$products_data = wc_product_table()->get_wc_product_data( $wcpt_collection );
		echo wp_json_encode(
			array(
				'draw'            => $wcpt_collection->get( 'draw' ),
				'recordsTotal'    => $products_data['records_total'],
				'recordsFiltered' => $products_data['records_filtered'],
				'data'            => $products_data['wc_products'],
			)
		);
		wp_die();
	}

	/**
	 * Get woocommerce product table.
	 *
	 * @param array $wcpt_collection array of wcpt_collection.
	 * @return array $products_data
	 */
	public function get_wc_product_data( $wcpt_collection ) {

		// query to get woocommerce products.
		$wc_products          = array();
		$products_data        = array();
		$records_total        = 0;
		$records_filtered     = 0;
		$product_table_id     = $wcpt_collection->get( 'table_id' );
		$list_variations_type = get_post_meta( $product_table_id, 'variable_list_view', true );

		$products_query = $this->wc_products_query( $wcpt_collection, $product_table_id, $list_variations_type );

		// loop and popuplate products array with data.
		if ( $products_query && $products_query->have_posts() ) {
			// get product table fields.
			$product_table_fields = wc_product_table()->get_product_table_fields( $product_table_id );
			while ( $products_query->have_posts() ) {
				$products_query->the_post();
				$product_id     = get_the_ID();
				$product        = wc_get_product( $product_id );
				$product_record = array();
				$stock_status       = get_post_meta( $product_table_id, 'wcpt_product_status', true );
				
				if ( $stock_status ) {
					if ( 'instock' === $stock_status && $stock_status === $product->get_stock_status() ) {
						$check_status = true;
					} elseif ( 'outofstock' === $stock_status && $stock_status === $product->get_stock_status() ) {
						$check_status = true;
					} else {
						$check_status = false;
					}
				} else {
					$check_status = true;
				}
				if ( $product && $check_status) {
					foreach ( $product_table_fields as $product_table_field ) {
						$args = array();
						ob_start();
						$args['shortocode_html_formatting'] = get_post_meta( $product_table_id, 'shortocode_html_formatting', true );
						switch ( $product_table_field['woo_ids'] ) {
							case 'id':
								$args['product_id'] = $product_id;
								wc_product_table_get_template( 'fields/product-table-id.php', $args );
								$product_record[] = ob_get_clean();
								break;
							case 'title':
								$args['product_title'] = $product->get_name();
								if ( 'variation' === $product->get_type() ) {
									$args['product_title'] .= wc_get_formatted_variation( $product, false, true, true );
								}
								$args['product_linkable'] = $product_table_field['woo_linkable'];
								if ( $args['product_linkable'] ) {
									$args['product_url'] = get_permalink( $product_id );
								}

								$formatted_variation_list = wc_get_formatted_variation( $product, true, true, true );
								wc_product_table_get_template( 'fields/product-table-title.php', $args );
								$product_record[] = ob_get_clean();
								break;
							case 'sku':
								$args['product_sku'] = $product->get_sku();
								wc_product_table_get_template( 'fields/product-table-sku.php', $args );
								$product_record[] = ob_get_clean();
								break;
							case 'short_desc':
								$args['product_short_description'] = $product->get_short_description();
								wc_product_table_get_template( 'fields/product-table-short-description.php', $args );
								$product_record[] = ob_get_clean();
								break;
							case 'descr':
								$descrption_length           = $product_table_field['woo_descr'];
								$args['product_description'] = $product->get_description();
								if ( $descrption_length ) {
									$args['product_description'] = substr( $args['product_description'], 0, $descrption_length );
								}
								wc_product_table_get_template( 'fields/product-table-description.php', $args );
								$product_record[] = ob_get_clean();
								break;
							case 'date':
								$args['product_date'] = $product->get_date_created();
								// product date fotmat.
								if ( $product_table_field['woo_date_format'] ) {
									$args['product_date_format'] = $product_table_field['woo_date_format'];
								} else {
									$args['product_date_format'] = get_option( 'date_format', true );
								}
								wc_product_table_get_template( 'fields/product-table-date.php', $args );
								$product_record[] = ob_get_clean();
								break;
							case 'cat':
								$product_category_ids = $product->get_category_ids();
								$product_categories   = '';
								if ( $product_category_ids ) {
									$product_categories = implode(
										',',
										get_terms(
											array(
												'taxonomy' => 'product_cat',
												'include'  => $product_category_ids,
												'fields'   => 'names',
											)
										)
									);
								}

								$args['product_categories'] = $product_categories;
								wc_product_table_get_template( 'fields/product-table-categories.php', $args );
								$product_record[] = ob_get_clean();
								break;
							case 'featured_img':
								$args['product_image']    = $product->get_image();
								$args['product_linkable'] = $product_table_field['woo_linkable'];
								if ( $args['product_linkable'] ) {
									$args['product_url'] = get_permalink( $product_id );
								}
								wc_product_table_get_template( 'fields/product-table-image.php', $args );
								$product_record[] = ob_get_clean();
								break;
							case 'reviews':
								$args['product_reviews'] = $product->get_average_rating();
								wc_product_table_get_template( 'fields/product-table-reviews.php', $args );
								$product_record[] = ob_get_clean();
								break;
							case 'stock':
								$args['product_stock_status'] = $product->get_stock_status();
								$args['product']              = $product;
								wc_product_table_get_template( 'fields/product-table-stock-status.php', $args );
								$product_record[] = ob_get_clean();
								break;
							case 'weight':
								$args['product_weight'] = $product->get_weight();
								wc_product_table_get_template( 'fields/product-table-weight.php', $args );
								$product_record[] = ob_get_clean();
								break;
							case 'dimensions':
								$args['product_dimensions'] = $product->get_dimensions();
								wc_product_table_get_template( 'fields/product-table-dimensions.php', $args );
								$product_record[] = ob_get_clean();
								break;
							case 'price':
								$args['product_price'] = $product->get_price_html();
								$args['product_id'] = $product_id;
								wc_product_table_get_template( 'fields/product-table-price.php', $args );
								$product_record[] = ob_get_clean();
								break;
							case 'attributes':
								$attribute_key              = $product_table_field['woo_attrs'];
								$args['product_attributes'] = $product->get_attribute( $attribute_key );
								wc_product_table_get_template( 'fields/product-table-attributes.php', $args );
								$product_record[] = ob_get_clean();
								break;
							case 'custom_fields':
								$custom_key                   = $product_table_field['woo_custom_keys'];
								$args['product_custom_field'] = $product->get_meta( $custom_key, true );
								wc_product_table_get_template( 'fields/product-table-custom-field.php', $args );
								$product_record[] = ob_get_clean();
								break;
							case 'tags':
								$product_tag_ids = $product->get_tag_ids();
								$product_tags    = '';
								if ( $product_tag_ids ) {
									$product_tags = implode(
										',',
										get_terms(
											array(
												'taxonomy' => 'product_tag',
												'include'  => $product_tag_ids,
												'fields'   => 'names',
											)
										)
									);
								}

								$args['product_tags'] = $product_tags;
								wc_product_table_get_template( 'fields/product-table-tags.php', $args );
								$product_record[] = ob_get_clean();
								break;
							case 'taxonomy':
								$custom_taxonomy          = $product_table_field['woo_taxonomy'];
								$product_custom_tax_terms = '';
								if ( taxonomy_exists( $custom_taxonomy ) ) {
									$product_custom_tax_terms = implode(
										',',
										get_terms(
											array(
												'taxonomy' => $custom_taxonomy,
												'object_ids' => $product_id,
												'fields'   => 'names',
											)
										)
									);
								}

								$args['product_custom_tax_terms'] = $product_custom_tax_terms;
								wc_product_table_get_template( 'fields/product-table-custom-taxonomy.php', $args );
								$product_record[] = ob_get_clean();
								break;
							case 'cart_button':
								if ( $product->is_purchasable() ) {
									$args['product']          = $product;
									$args['classes']          = '';
									$args['cart_button_type'] = $product_table_field['woo_add_types'];
									if ( 'add_checkbox' === $product_table_field['woo_add_types'] ) {
										$args['classes'] = ' hide-submit-btn';
									}
									$args['show_quantity'] = $product_table_field['woo_quantity'];
									if ( 'true' !== $product_table_field['woo_quantity'] ) {
										$args['classes'] = ' hide-quantity';
									}
									$args['cart_button_position'] = $product_table_field['woo_add_selected_cart'];
									//$args['cart_ajax']            = $product_table_field['woo_ajax_option'];
									if ( 'variable' === $product->get_type() || 'variable-subscription' === $product->get_type() ) {
										$args['list_variations_type'] = $list_variations_type;
									}

									if ( 'variable' === $product->get_type() || 'variable-subscription' === $product->get_type() ) {
										/**
										 * Filter woocommerce ajax variation threshold
										 * 
										 * @since 1.1.5
										**/
										$get_variations = count( $product->get_children() ) <= apply_filters( 'woocommerce_ajax_variation_threshold', 30, $product );

										$variation_args = array(
											'available_variations' => $get_variations ? $product->get_available_variations() : false,
											'attributes' => $product->get_variation_attributes(),
											'selected_attributes' => $product->get_default_attributes(),
										);

										$args = array_merge( $args, $variation_args );
									}
									if ( 'subscription_variation' === $product->get_type() ) {
										wc_product_table_get_template( 'fields/subscription-variation-product-add-to-cart.php', $args );
									} else {
										wc_product_table_get_template( 'fields/' . $product->get_type() . '-product-add-to-cart.php', $args );
									}
									$product_record[] = ob_get_clean();
								} else {
									$args['product'] = $product;
									if ( 'external' === $product->get_type() ) {
										wc_product_table_get_template( 'fields/' . $product->get_type() . '-product-add-to-cart.php', $args );
									}
									$product_record[] = ob_get_clean();
								}
								break;
							default:
								$product_record[] = '';
						}
						/**
						 * Filter after product table field
						 * 
						 * @since 1.1.5
						**/
						$product_record = apply_filters( 'product_table_field_after', $product_record , $product_table_field['woo_ids'] , $args , $product_id );
					
					}
					$wc_products[] = $product_record;
				}
			}
			$records_filtered = $products_query->found_posts;
			$records_total    = $products_query->found_posts;
		}

		// get posts.
		$products_limit = get_post_meta( $product_table_id, 'wcpt_product_limit', true );
		if ( $products_limit ) {
			if ( $products_limit < $records_total ) {
				$records_total = $products_limit;
			}
			if ( $products_limit < $records_filtered ) {
				$records_filtered = $products_limit;
			}
		}
		$products_data['wc_products']      = $wc_products;
		$products_data['records_filtered'] = $records_filtered;
		$products_data['records_total']    = $records_total;
		/**
		 * Filter product table products data
		 * 
		 * @since 1.1.5
		**/
		return apply_filters( 'wcpt_products_data', $products_data, $product_table_id );
	}

	/**
	 * Get woocommerce product table query.
	 *
	 * @param array $wcpt_collection array of wcpt_collection.
	 * @param int   $product_table_id product table ID.
	 * @param array $list_variations_type array of variation type.
	 * @return array $products_query
	 */
	public function wc_products_query( $wcpt_collection, $product_table_id, $list_variations_type ) {
		$products_query     = false;
		$parent_variations  = array();
		$product_variations = array();

		if ( $wcpt_collection && $product_table_id ) {
			// prepare products args.
			$products_limit = get_post_meta( $product_table_id, 'wcpt_product_limit', true );
			$posts_per_page = $wcpt_collection->get( 'length' );

			$offset         = $wcpt_collection->get( 'start' );
			// apply Product limit.
			$max_offset = $posts_per_page + $offset;


			if ( $products_limit && $max_offset > $products_limit ) {
				$posts_per_page = $products_limit - $offset;
			}

			$filter_terms = $wcpt_collection->get( 'filters' );

			$product_inc_ids = get_post_meta( $product_table_id, 'wcpt_inc_product_ids', true );

			$product_exc_ids = get_post_meta( $product_table_id, 'wcpt_ex_product_ids', true );
			$tax_query       = $this->wc_get_tax_query( $product_table_id, $filter_terms );

			$meta_query_attrs = $this->wc_get_meta_attr_query( $filter_terms );

			$meta_product_query = $this->wc_get_meta_query( $product_table_id );

			$date_query = $this->wc_get_date_query( $product_table_id );

			$search_filter_term = $this->wc_get_search_query( $product_table_id );

			// display each variable in seperated row.
			if ( 'separate_row' === $list_variations_type ) {
				// get variations parent ids to exculde.

				$tax_query_variation = array( 'relation' => 'AND' );

				$tax_query_variation[] = array(
					'relation' => 'OR',
					array(
						'taxonomy' => 'product_type',
						'field'    => 'slug',
						'terms'    => 'variable',
					),
					array(
						'taxonomy' => 'product_type',
						'field'    => 'slug',
						'terms'    => 'variable-subscription',
					),
				);

				$parent_variations_args = array(
					'post_type'      => 'product',
					'fields'         => 'ids',
					'post_status' 	 => 'publish',
					'posts_per_page' => -1,
					'_meta_or_title' => $search_filter_term,
					'meta_value' 	 => $search_filter_term,
					'meta_compare' 	 => 'LIKE',
				);

				// set tax query.
				if ( $tax_query ) {
					$parent_variations_args['tax_query'] = array_merge( $tax_query_variation, $tax_query );
				} else {
					$parent_variations_args['tax_query'] = $tax_query_variation;
				}
				// set date query.
				if ( $date_query ) {
					$parent_variations_args['date_query'] = $date_query;
				}
				// set meta query.
				if ( $meta_product_query ) {
					$parent_variations_args['meta_query'] = $meta_product_query;
				}

				// if ( $search_filter_term ) {
					//$parent_variations_args['s'] = $search_filter_term;
				// }
				/**
				 * Filter product table parent variation args
				 * 
				 * @since 1.1.5
				**/
				$parent_variations_args = apply_filters( 'wcpt_parent_variations_args', $parent_variations_args );

				$parent_variations = new WP_Query( $parent_variations_args );
				// get product variations.
				if ( $parent_variations->posts ) {
					$product_variations_args = array(
						'fields'          => 'ids',
						'post_type'       => 'product_variation',
						'posts_per_page'  => -1,
						'post_parent__in' => $parent_variations->posts,
					);

					if ( $meta_query_attrs ) {
						$product_variations_args['meta_query'] = $meta_query_attrs;
					}
					/**
					 * Filter product table variation args
					 * 
					 * @since 1.1.5
					**/
					$product_variations_args = apply_filters( 'wcpt_product_variations_args', $product_variations_args );
					$product_variations      = new WP_Query( $product_variations_args );
				}
			}

			// get all products except variations.
			if ( ( 'separate_row' === $list_variations_type ) && $product_variations && $product_variations->have_posts() ) {
				$products_per_page = -1;
			} else {
				$posts_per_page = isset($posts_per_page) && $posts_per_page > 0 ? $posts_per_page : -1;
				$products_per_page = $posts_per_page;
			}
			// get order query.
			$order_query = $this->prepare_wcpt_order_query( $wcpt_collection, $product_table_id );

			$product_args = array(
				'post_type'      => 'product',
				'post_status'    => 'publish',
				'posts_per_page' => $products_per_page,
				'_meta_or_title' => $search_filter_term,
				'meta_value' 	 => $search_filter_term,
				'meta_compare' 	 => 'LIKE',

			);
			// set tax query.
			if ( $tax_query ) {
				$product_args['tax_query'] = $tax_query;
			}
			// set date query.
			if ( $date_query ) {
				$product_args['date_query'] = $date_query;
			}
			// set meta query.
			if ( $meta_product_query ) {
				$product_args['meta_query'] = $meta_product_query;
			}

			// if ( $search_filter_term ) {
				//$product_args['s'] = $search_filter_term;
			// }

			if ( 'separate_row' === $list_variations_type && $parent_variations ) {
				$product_args['post__not_in'] = $product_exc_ids ? array_merge( $parent_variations->posts, $product_exc_ids ) : $parent_variations->posts;
				$product_args['fields']       = 'ids';
			} else {
				if ( $product_exc_ids ) {
					$product_args['post__not_in'] = $product_exc_ids;
				}
				if ( $product_inc_ids ) {
					$product_args['post__in'] = $product_inc_ids;
				}
				if ( $order_query ) {
					$product_args = array_merge( $product_args, $order_query );
				}
				$product_args['offset'] = $offset;
			}
			/**
			 * Filter product table args
			 * 
			 * @since 1.1.5
			**/
			$product_args = apply_filters( 'wcpt_product_table_args', $product_args );
			// Products Query.
			$products_query = new WP_Query( $product_args );

			// query to get all types of products.
			if ( 'separate_row' === $list_variations_type && $product_variations && $product_variations->have_posts() ) {
				$product_ids      = array_merge( $products_query->posts, $product_variations->posts );
				$all_product_args = array(
					'post_type'      => array( 'product', 'product_variation' ),
					'post__in'       => $product_inc_ids ? $product_inc_ids : $product_ids,
					'posts_per_page' => $posts_per_page,
					'post_status'    => 'publish',
					'offset'         => $offset,
					'_meta_or_title' => $search_filter_term,
					'meta_value' 	 => $search_filter_term,
					'meta_compare' 	 => 'LIKE',
				);
				if ( $order_query ) {
					$all_product_args = array_merge( $all_product_args, $order_query );
				}
				/**
				 * Filter all products args
				 * 
				 * @since 1.1.5
				**/
				$all_product_args = apply_filters( 'wcpt_all_product_args', $all_product_args );

				$products_query = new WP_Query( $all_product_args );
			}
		}
		return $products_query;
	}

	/**
	 * Get woocommerce product table taxonomy query.
	 *
	 * @param int    $product_table_id product table ID.
	 * @param string $filter_terms terms.
	 * @return array $tax_query
	 */
	public function wc_get_tax_query( $product_table_id, $filter_terms = '' ) {
		$cat_ids     = get_post_meta( $product_table_id, 'wcpt_inc_product_cats', true );
		$tag_ids     = get_post_meta( $product_table_id, 'wcpt_inc_product_tags', true );
		$cat_exc_ids = get_post_meta( $product_table_id, 'wcpt_ex_product_cats', true );
		$search_filter_term = $this->wc_get_search_query( $product_table_id );
		$tax_query   = array();
		if ( $cat_ids ) {
			$tax_query[] = array(
				'taxonomy' => 'product_cat',
				'terms'    => $cat_ids,
			);
		}
		
		if ( $tag_ids ) {
			$tax_query[] = array(
				'taxonomy' => 'product_tag',
				'terms'    => $tag_ids,
			);
		}
		if ( $cat_exc_ids ) {
			$tax_query[] = array(
				'taxonomy' => 'product_cat',
				'terms'    => $cat_exc_ids,
				'operator' => 'NOT IN',
			);
		}

		if ( $filter_terms ) {
			$filters_col  = get_post_meta( $product_table_id, 'wcpt_filters_col', true );
			$filter_terms = json_decode( stripslashes( $filter_terms ) );
			$tax_query[]  = array(
				'relation' => 'AND',
			);
			foreach ( $filter_terms as $filter_term ) {
				if ( $filter_term->value ) {
					if ( 'load_archive' === $filters_col && ! taxonomy_is_product_attribute( $filter_term->key ) ) {
						continue;
					}
					$tax_query[] = array(
						'taxonomy' => $filter_term->key,
						'terms'    => $filter_term->value,
					);
				}
			}
		}
		return $tax_query;
	}

	/**
	 * Get meta attribute query
	 *
	 * @param string $filter_terms terms.
	 */
	public function wc_get_meta_attr_query( $filter_terms = '' ) {
		$meta_attr_product_query = array();
		if ( $filter_terms ) {
			$filter_terms = json_decode( stripslashes( $filter_terms ) );
			foreach ( $filter_terms as $filter_term ) {
				if ( $filter_term->value ) {
					if ( taxonomy_is_product_attribute( $filter_term->key ) ) {
						$term                    = get_term_by( 'id', $filter_term->value, $filter_term->key );
						$meta_attr_product_query = array(
							'relation' => 'AND',
							array(
								'key'     => wc_variation_attribute_name( $filter_term->key ),
								'value'   => $term->slug,
								'compare' => '=',
							),
						);
					}
				}
			}
		}
		return $meta_attr_product_query;
	}

	/**
	 * Get meta query
	 *
	 * @param int $product_table_id product table ID.
	 */
	public function wc_get_meta_query( $product_table_id ) {
		$stock_status       = get_post_meta( $product_table_id, 'wcpt_product_status', true );
		$meta_product_query = array();
		if ( $stock_status ) {
			$meta_product_query = array(
				'relation' => 'AND',
				array(
					'key'   => '_stock_status',
					'value' => $stock_status,
				),
			);
		}
		return $meta_product_query;
	}

	/**
	 * Get date query
	 *
	 * @param int $product_table_id table id.
	 */
	public function wc_get_date_query( $product_table_id ) {
		$date_option = get_post_meta( $product_table_id, 'wcpt_date_opt', true );
		$date        = get_post_meta( $product_table_id, 'wcpt_date', true );
		$date_query  = array();
		if ( $date_option && $date ) {
			$date_query[ $date_option ] = $date;
		}
		return $date_query;
	}

	/**
	 * Get search query
	 *
	 * @param int $product_table_id table id.
	 */
	public function wc_get_search_query( $product_table_id ) {
		$search_filter_term = '';
		$search             = get_post_meta( $product_table_id, 'show_search', true );
		if ( $search ) {
			$search_filter_term = get_post_meta( $product_table_id, 'filter_product_based_term', true );
			if ( ! isset( $_POST['nonce'] ) ) {
				return;
			}
			if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'ajax-nonce' ) ) {
								return;
			}

			if ( isset( $_POST['search']['value'] ) && ! empty( $_POST['search']['value'] ) ) {
				$search_filter_term = sanitize_text_field( wp_unslash( $_POST['search']['value'] ) );
			}
		}
		return $search_filter_term;
	}

	/**
	 * Prepare woocommerce product table order
	 *
	 * @param array $wcpt_collection array of wcpt collection.
	 * @param int   $product_table_id table id.
	 */
	public function prepare_wcpt_order_query( $wcpt_collection, $product_table_id ) {
		$order_query = array();
		if ( $wcpt_collection && $product_table_id ) {
			// get order column.
			$order_columns = $wcpt_collection->get( 'order' );
			if ( $order_columns ) {
				// get order column and order direction.
				$order_column = $order_columns[0]['column'];
				// check if column is orderable.
				$columns         = $wcpt_collection->get( 'columns' );
				$column_name     = $columns[ $order_column ]['name'];
				$order_direction = $order_columns[0]['dir'];
				switch ( $column_name ) {
					case 'id':
						$order_query['orderby'] = 'ID';
						$order_query['order']   = $order_direction;
						break;
					case 'title':
						$order_query['orderby'] = 'title';
						$order_query['order']   = $order_direction;
						break;
					case 'date':
						$order_query['orderby'] = 'date';
						$order_query['order']   = $order_direction;
						break;
					case 'reviews':
						$order_query['orderby']  = 'meta_value_num';
						$order_query['meta_key'] = '_wc_average_rating';
						$order_query['order']    = $order_direction;
						break;
					case 'price':
						$order_query['orderby']  = 'meta_value_num';
						$order_query['meta_key'] = '_price';
						$order_query['order']    = $order_direction;
						break;
				}
				// }
			}
		}
		/**
		 * Filter products order query
		 * 
		 * @since 1.1.5
		**/
		return apply_filters( 'wcpt_products_order_query', $order_query, $wcpt_collection, $product_table_id );
	}

	/**
	 * Get product table saved fields
	 *
	 * @param int $product_table_id product table id.
	 * @return array $product_table_fields
	 */
	public function get_product_table_fields( $product_table_id ) {
		$product_table_fields = array();
		if ( $product_table_id ) {
			// get product table fields.
			$product_table_fields = get_post_meta( $product_table_id, 'product_table_fields', true );
		}
		/**
		 * Filter product table fields
		 * 
		 * @since 1.1.5
		**/
		$product_table_fields = apply_filters( 'wcpt_product_table_fields', $product_table_fields, $product_table_id );
		return $product_table_fields;
	}

	/**
	 * Ajax to add woocommerce product to cart
	 */
	public function wcpt_add_to_cart() {
		WC_AJAX::add_to_cart();
		wp_die();
	}

	/**
	 * Ajax to add woocommerce multiple products to cart
	 */
	public function wcpt_add_selected_products_cart() {
		if ( ! isset( $_POST['nonce'] ) ) {
			return;
		}
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'ajax-nonce' ) ) {
			return;
		}
		$post_data = $_POST;
		// $product_ids       = ( isset( $_POST['product_ids'] ) && sanitize_text_field(  $_POST['product_ids']  ) ) ? sanitize_text_field(  $_POST['product_ids']  ) : array();
		// $product_quantites = ( isset( $_POST['product_quantites'] ) && sanitize_text_field( wp_unslash( $_POST['product_quantites'] ) ) ) ? sanitize_text_field( $_POST['product_quantites']  ) : array();
		$cart_message      = '';
		$added_products    = array();
		
		if ( isset( $_POST['product_ids'] ) ) {
			$product_ids = $post_data['product_ids'];
			$product_quantites = $post_data['product_quantites'];
		} else {
			$product_ids = array();
			$product_quantites = array();
		}
		if ( $product_ids && $product_quantites ) {
			foreach ( $product_ids as $product_key => $product_id ) {
				// get product data.
				$product        = wc_get_product( $product_id );
				$quantity       = empty( $post_data['product_quantites'][ $product_key ] ) ? 1 : wc_stock_amount(  wp_unslash( $post_data['product_quantites'][ $product_key ] )  );
				$product_status = get_post_status( $product_id );
				$variation_id   = 0;
				$variation      = array();
				$cart_item_data = array(); 
				// for variation product.
				if ( $product && 'variation' === $product->get_type() ) {
					$variation_id = $product_id;
					$product_id   = $product->get_parent_id();
					$variation    = $product->get_variation_attributes();
					
				} 
				if ( $product && 'variation' === $product->get_type() ) {
					if ( isset( $post_data['nyp_data'][$variation_id] ) ) {
						$cart_item_data = $this->cart_item_data_generate( $variation_id, $post_data );
						if ( empty($cart_item_data) ) {
							continue;
						}
					}
				} else {
					if ( isset( $post_data['nyp_data'][$product_id] )) {
						$cart_item_data = $this->cart_item_data_generate( $product_id, $post_data );
						if ( empty($cart_item_data) ) {
							continue;
						}
					}
				}
				if ( WC()->cart->add_to_cart( $product_id, $quantity, $variation_id, $variation, $cart_item_data ) ) {
					$added_products[] = '"' . get_the_title( $product_id ) . '"';
				}
			}
		}
		if ( $added_products ) {
			$added_products = implode( ' And ', $added_products );
			// translators: Added Product.
			$added_products = '<p class="wcpt-added-products">' . sprintf( __( '%s Added to cart', 'woo-product-table' ), $added_products ) . '</p>';
		}
		WC()->session->set( 'wcpt_added_products', $added_products );

		// Return fragments.
		WC_AJAX::get_refreshed_fragments();
		wp_die();
	}
	
	public function cart_item_data_generate( $product_id, $post_data ) {
	
		if ( isset( $post_data['nyp_data'][$product_id] )) {
			
			$nyp_price = $post_data['nyp_data'][$product_id];
			$min_price = get_post_meta( $product_id, '_min_price', true );
			$maximum_price = get_post_meta( $product_id, '_maximum_price', true );						
			 
			if ( !empty($min_price) && !empty($maximum_price) ) {
				if ( $nyp_price >= $min_price &&  $nyp_price <= $maximum_price  ) {
					return array( 'nyp' =>  $nyp_price );
				}
			} elseif (!empty($min_price)) {
				if ( $nyp_price >= $min_price ) {
					return array( 'nyp' =>  $nyp_price );
				}  
			} elseif (!empty($maximum_price)) {
				if ( $nyp_price <= $maximum_price  ) {
					return array( 'nyp' =>  $nyp_price );
				}
			} else {
				return array( 'nyp' => $nyp_price );
			}
		}
	}
	
	/**
	 * Set names of the products that added to cart
	 *
	 * @param array $fragments array of fragments.
	 * @return array $fragments
	 */
	public function wcpt_set_title_products_added_cart( $fragments ) {
		if ( WC()->session && WC()->session->get( 'wcpt_added_products' ) ) {
			$fragments['wcpt_added_products'] = WC()->session->get( 'wcpt_added_products' );
			WC()->session->__unset( 'wcpt_added_products' );
		}
		return $fragments;
	}

}

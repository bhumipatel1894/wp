<?php 
class WCPTGrid_Factory {

	private static $grids      = array();
	private static $current_id = 1;

	/**
	 * Create a new grid based on the supplied args.
	 *
	 * @param array $args The args to use for the grid.
	 * @return Grid The product grid object.
	 */
	public static function create( $args ) {

		// Merge in the default args, so our grid ID reflects the full list of args, including settings page.
		$id = self::generate_id( $args );

		$grid               = new WCPTGrid( $id, $args );
		self::$grids[ $id ] = $grid;

		return $grid;
	}

	/**
	 * Fetch an existing grid by ID.
	 *
	 * @param string $id The product grid ID.
	 * @return Grid The product varriations grid object.
	 */
	public static function fetch( $id ) {

		if ( empty( $id ) ) {
			return false;
		}

		$grid = false;

		if ( isset( self::$grids[ $id ] ) ) {
			$grid = self::$grids[ $id ];
		}

		return $grid;
	}

	private static function generate_id( $args ) {
		$id = 'wpt_' . substr( md5( serialize( $args ) ), 0, 16 ) . '_' . self::$current_id; //phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_serialize
		self::$current_id ++;

		return $id;
	}
}

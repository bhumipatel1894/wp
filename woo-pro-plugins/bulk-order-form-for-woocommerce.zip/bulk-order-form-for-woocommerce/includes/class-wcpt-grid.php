<?php
class WCPTGrid {

	public $id;
	private $product_id;
	private $grid;
	private $attributes;

	private $has_column_images = false;

	/**
	 * Helper classes
	 * phpcs:ignore Squiz.Commenting.VariableComment.MissingVar
	 */
	public $args;
	private $data_factory;

	/**
	 * Internal flags
	 * phpcs:ignore Squiz.Commenting.VariableComment.MissingVar
	 */
	private $grid_initialised = false;
	private $cells_added      = false;

	private $current_row = 0;

	private $use_table_tags;

	public function __construct( $id, $args = array() ) {
		$this->id             = $id;
		$this->args           = new WCPTArgs( $args );
		$this->data_factory   = new WCPTData_Factory( $this->args );
		$this->product_id     = isset( $this->args->include ) ? $this->args->include : 0;
		$this->use_table_tags = false;
	}

	private function get_table_tag( $type ) {
		if ( ! $this->use_table_tags ) {
			return 'div';
		}

		return $type;
	}

	public function add_attribute( $name, $value ) {
		$this->attributes[ $name ] = $value;
	}

	public function render_grid( $content_only = false ) {
		$content = '';

		$content = sprintf( '<%s class="wcpt-head-group" role="rowgroup">', $this->get_table_tag( 'thead' ) );

		foreach ( $this->grid as $index => $row ) {
			$cells = '';
			foreach ( $row as $cell ) {
				$cells .= $this->render_cell( $cell );
			}
			$class    = trim( implode( ' ', array( 'wcpt-row', 0 === ( $index + $this->has_column_images ) % 2 ? '' : 'wcpt-alt' ) ) );
			$content .= sprintf( '<%3$s class="%1$s" role="row">%2$s</%3$s>', $class, $cells, $this->get_table_tag( 'tr' ) );

			if ( (int) $this->has_column_images === $index ) {
				$content .= sprintf( '</%1$s><%2$s class="wcpt-row-group" role="rowgroup">', $this->get_table_tag( 'thead' ), $this->get_table_tag( 'tbody' ) );
			}
		}

		$content .= sprintf( '</%s>', $this->get_table_tag( 'tbody' ) );

		if ( $content_only ) {
			return $content;
		}

		return sprintf(
			'<%3$s %1$s>%2$s</%3$s>',
			wc_implode_html_attributes( $this->attributes ),
			$content,
			$this->get_table_tag( 'table' )
		);
	}

	public function reset() {
		$this->attributes = array();

		$this->reset_data();
	}

	public function reset_data() {
		$this->content = array();
	}

	public function render_cell( $cell ) {

		return sprintf(
			'<%3$s %1$s>%2$s</%3$s>',
			wc_implode_html_attributes( $cell['attributes'] ),
			$cell['content'],
			$this->get_table_tag( 'td' )
		);
	}

	public function get_add_to_cart_text() {
		if ( $this->product_id ) {
			$product_obj = wc_get_product( $this->product_id );

			if ( $product_obj ) {
				$text = $product_obj->single_add_to_cart_text();
				return $text;
			}
		}

		return __( 'Add to cart', 'woocommerce' );
	}

	public function render() {
		if ( ! wc_get_product( $this->product_id ) ) {
			return '';
		}

		if ( ! $this->grid_initialised ) {
			// Add attriutes and grid headers.
			$this->add_attributes();
			$this->add_headers();

			// Get the data populating the grid.
			$this->add_cells();
			/**
			 * Action product table after get table
			 * 
			 * @since 1.1.6
			**/
			do_action( 'wcpt_table_after_get_table', $this );

			$this->grid_initialised = true;
		}

		$classes = array(
			'wcpt-cart',
			'cart',
			// "wcpt-{$this->args->grid_mode}-grid-mode",
		);

		// if ( count( $this->args->attributes ) > 2 ) {
			// $classes[] = 'wcpt-multivariation-cells';
		// }

		// if ( $this->args->has_fast_pool ) {
			// $classes[] = 'wcpt-fast-pool';
		// }

		$attrs  = array(
			'class'                   => implode( ' ', $classes ),
			'method'                  => 'post',
			'enctype'                 => 'multipart/form-data',
			'data-attribute_count'    => count( $this->args->attributes ),
			'data-product_variations' => wp_json_encode( $this->data_factory->get_available_variations() ),
		);
		$output = sprintf(
			'<div class="wcpt-grid-wrapper">%1$s</div><form %2$s>%3$s</form>',
			$this->render_grid(),
			wc_implode_html_attributes( $attrs ),
			$this->add_footer()
		);
		/**
		 * Filter product table get output
		 * 
		 * @since 1.1.6
		**/
		return apply_filters( 'wcpt_get_table_output', $output, '', $this );
	}

	private function add_headers() {
		// get the taxonomies for the two grid dimensions
		// 1-attribute products will have only one
		list( $h_dimension, $v_dimension ) = $this->args->dimensions;

		$top_left_content = wc_attribute_label( $h_dimension['name'] );

		if ( $v_dimension ) {
			$top_left_content = '';
			/**
			 * Filter product able has topleft labels 
			 * 
			 * @since 1.1.6
			**/
			if ( apply_filters( 'wcpt_table_has_topleft_labels', false, $this->product_id ) ) {
				$top_left_content = sprintf( '%s / %s', wc_attribute_label( $h_dimension['name'] ), wc_attribute_label( $v_dimension['name'] ) );
			}

			if ( $this->args->has_fast_pool && 'compact' === $this->args->grid_mode ) {
				$top_left_content = $this->data_factory->get_extra_attribute_dropdown_html();
			}
		}

		$this->grid[ $this->current_row ] = array();

		$this->grid[ $this->current_row ][] = array(
			'content'    => $top_left_content,
			'role'       => 'columnheader',
			'attributes' => array( 'class' => 'wcpt-header wcpt-col-header wcpt-row-header' ),
		);

		// add the column headers
		$this->add_dimension_headers( $h_dimension['terms'] );
	}

	private function add_dimension_headers( $terms, $type = 'col' ) {
		$first = true;

		foreach ( $terms as $index => $term ) {
			if ( 0 === $term['count'] ) {
				continue;
			}

			$term_slug = wc_sanitize_taxonomy_name( $term['slug'] );
			$classes   = array(
				'wcpt-header',
				"wcpt-{$type}-header",
				"product-{$type}-{$term_slug}",
			);

			if ( $this->is_even_term( $term, 'row' === $type ? 1 : 0 ) ) {
				$classes[] = 'row' === $type ? 'wcpt-alt' : 'wcpt-v-alt';
			}

			if ( 'row' !== $type ) {
				$classes[] = "col-{$term_slug}";
			}
			/**
			 * Action product table type class
			 * 
			 * @since 1.1.6
			**/
			$classes = apply_filters_deprecated( "wcpt_table_{$type}_class", array( $classes ), '2.0.0', "wcpt_table_{$type}_class_{%term_slug%}" );
			/**
			 * Action product table type classes
			 * 
			 * @since 1.1.6
			**/
			$classes = apply_filters( "wcpt_table_{$type}_class_{$term['slug']}", $classes );
			$attrs   = array(
				'class'          => implode( ' ', $classes ),
				'role'           => 'col' === $type ? 'columnheader' : 'rowheader',
				'aria-label'     => $term['name'],
				'data-attribute' => $term['slug'],
				'data-label'     => $term['name'],
			);

			$this->grid[ $this->current_row ][] = array(
				'content'    => $this->prepare_header( $term, $type ),
				'attributes' => $attrs,
			);

			if ( 'col' === $type && ( count( $this->args->attributes ) > 1 || 'vert' !== $this->args->variation_attribute ) ) {
				if ( $type === $this->args->variation_images ||
					1 === count( $this->args->attributes ) ||
					'both' === $this->args->variation_images ) {

					if ( ! isset( $this->grid[ $this->current_row + 1 ] ) ) {
						$this->grid[ $this->current_row + 1 ] = array();
					}

					// translators: the variation name (e.g. blue or small)
					$aria_label = sprintf( __( 'Variation picture for %s', 'woo-product-table' ), $term['name'] );
					$image      = $this->data_factory->get_attribute_image_html( $term['slug'], $aria_label );
					$attrs      = array(
						'class'      => trim( implode( ' ', array( 'wcpt-col-image', 0 === $index % 2 ? '' : 'wcpt-v-alt' ) ) ),
						'role'       => 'columnheader',
						'aria-label' => $aria_label,
					);

					if ( $first && ( count( $this->args->attributes ) > 1 || 'vert' === $this->args->variation_attribute ) ) {
						$this->grid[ $this->current_row + 1 ][] = array(
							'content'    => '',
							'attributes' => array( 'class' => 'wcpt-colrow-image' ),
						);

						$first = false;
					}

					$this->grid[ $this->current_row + 1 ][] = array(
						'content'    => $image,
						'attributes' => $attrs,
					);

					$this->has_column_images = true;
				}
			}

		}

		$this->current_row = count( $this->grid );
	}

	private function add_cells() {
		if ( $this->cells_added ) {
			return;
		}

		// Reset the grid data
		$this->reset_data();
		/**
		 * Action product table before get data
		 * 
		 * @since 1.1.6
		**/
		do_action_deprecated( 'wcpt_table_before_get_data', array( $this ), '2.0.0', 'wcpt_table_before_add_cells' );
		/**
		 * Action product table before add cells
		 * 
		 * @since 1.1.6
		**/
		do_action( 'wcpt_table_before_add_cells', $this );

		// get the taxonomies for the two grid dimensions
		// 1-attribute products will have only one
		list( $h_dimension, $v_dimension ) = $this->args->dimensions;

		if ( $v_dimension && isset( $v_dimension['terms'] ) ) {
			// the product has 2 attributes or more
			// start from the second dimension because the cells
			// must be added row by row (horizontal order)
			foreach ( $v_dimension['terms'] as $v_term ) {
				if ( $v_term['count'] > 0 ) {
					$this->current_row++;
					$this->grid[ $this->current_row ] = array();
					$this->add_dimension_headers( array( $v_term ), 'row' );

					foreach ( $h_dimension['terms'] as $h_term ) {
						if ( $h_term['count'] > 0 ) {
							$this->add_cell( $h_term, $v_term );
						}
					}
				}
			}
		} else {
			// the product has 1 attribute only
			$this->current_row++;
			$this->grid[ $this->current_row ]   = array();
			$this->grid[ $this->current_row ][] = array(
				/**
				 * Filter product table single variation header
				 * 
				 * @since 1.1.6
				**/
				'content'    => apply_filters( 'wcpt_single_variation_header', __( 'Price', 'woo-product-table' ) ),
				'attributes' => array( 'class' => 'wcpt-header wcpt-row-header' ),
			);

			foreach ( $h_dimension['terms'] as $h_term ) {
				if ( $h_term['count'] > 0 ) {
					$this->add_cell( $h_term );
				}
			}
		}
		/**
		 * Action product table after get data
		 * 
		 * @since 1.1.6
		**/
		do_action_deprecated( 'wcpt_table_after_get_data', array( $this ), '2.0.0', 'wcpt_table_after_add_cells' );
		/**
		 * Action product table after add cells
		 * 
		 * @since 1.1.6
		**/
		do_action( 'wcpt_table_after_add_cells', $this );

		$this->cells_added = true;
	}

	private function add_cell( $column, $row = null ) {
		list( $h_dimension, $v_dimension ) = $this->args->dimensions;

		$matrix = $this->args->variation_matrix;

		$content = '';

		if ( ! $row && isset( $matrix[ $column['slug'] ] ) && ! empty( $matrix[ $column['slug'] ] ) ) {

			$content = $this->data_factory->get_cell_content( $column['slug'], $row );
		} elseif ( isset( $matrix[ $column['slug'] ] ) && isset( $matrix[ $column['slug'] ][ $row['slug'] ] ) && ! empty( $matrix[ $column['slug'] ][ $row['slug'] ] ) ||
			! $row && isset( $matrix[ $column['slug'] ] ) && ! empty( $matrix[ $column['slug'] ] ) ) {

			$content = $this->data_factory->get_cell_content( $column['slug'], $row['slug'] );
		}

		$classes = array(
			'wcpt-cell',
			'wcpt-cell-' . wc_sanitize_taxonomy_name( $column['slug'] ),
		);

		if ( $this->is_even_term( $column, 0 ) ) {
			$classes[] = 'wcpt-v-alt';
		}

		if ( $row ) {
			$classes[] = 'wcpt-cell-' . wc_sanitize_taxonomy_name( $row['slug'] );

			if ( $this->is_even_term( $row ) ) {
				$classes[] = 'wcpt-alt';
			}
			$data_variation_ids = implode( ',', $this->args->get_cell_variation_ids( $column['slug'], $row['slug'] ) );
		} else {
			$data_variation_ids = implode( ',', $this->args->get_cell_variation_ids( $column['slug'], $row ) );
		}

		$attrs = array(
			'class'              => implode( ' ', $classes ),
			'role'               => 'gridcell',
			'aria-label'         => sprintf( '%s %s', $h_dimension['label'], $column['name'] ),
			'data-h_taxonomy'    => wc_sanitize_taxonomy_name( $h_dimension['name'] ),
			'data-h_attribute'   => $column['slug'],
			'data-h_label'       => $column['name'],
			'data-variation_ids' => $data_variation_ids,
		);

		if ( $row ) {
			$attrs['data-v_taxonomy']  = wc_sanitize_taxonomy_name( $v_dimension['name'] );
			$attrs['data-v_attribute'] = $row['slug'];
			$attrs['data-v_label']     = $row['name'];
			$attrs['aria-label']       = sprintf( '%s %s, %s %s', $h_dimension['label'], $column['name'], $v_dimension['label'], $row['name'] );
		}

		$this->grid[ $this->current_row ][] = array(
			'content'    => $content,
			'attributes' => $attrs,
		);
	}

	private function is_even_term( $term, $dimension_index = 1 ) {
		if ( ! $this->args->dimensions[ $dimension_index ] || empty( $this->args->dimensions[ $dimension_index ] ) ) {
			return false;
		}

		$dimension = $this->args->dimensions[ $dimension_index ];

		$key = array_keys(
			array_filter(
				$dimension['terms'],
				function( $t ) use ( $term ) {
					return $term['slug'] === $t['slug'];
				}
			)
		);

		if ( ! empty( $key ) ) {
			return ! ! ( reset( $key ) % 2 );
		}

		return false;
	}

	private function add_footer() {

		$footer = '';

		if ( ! $this->args->disable_purchasing ) {
			$price            = wc_price( 0 );
			$add_to_cart_text = $this->get_add_to_cart_text();

			ob_start();
			?>

			<div id="wcpt_wrapper_<?php echo esc_attr( $this->id ); ?>" class="wcpt-total-wrapper">
				<div class="wcpt-variation-pool"></div>
				<div class="wcpt-total-left">
					<p>
						<span class="wcpt_total_label"><?php esc_html_e( 'Items', 'woo-product-table' ); ?></span>:
						<span class="wcpt_total_items">0</span>
					</p>
					<p>
						<span class="wcpt_total_label"><?php esc_html_e( 'Total', 'woo-product-table' ); ?></span>:
						<span class="wcpt_total_price"><?php echo wp_kses($price, wcpt_allowed_html()); ?></span>
					</p>
					<label role="status">0 Items, Total $0.00</label>
				</div>
				<div class="wcpt-total-right">
					<button disabled class="single_add_to_cart_button button alt disabled wc-variation-selection-needed">
						<?php echo esc_html( $add_to_cart_text ); ?>
					</button>
				</div>
			</div>

			<?php
			$footer = ob_get_clean();
		}

		return $footer;
	}

	private function prepare_header( $term, $type = 'col' ) {
		$image = '';

		if ( 'row' === $type || ( 1 === count( $this->args->attributes ) && 'vert' === $this->args->variation_attribute ) ) {
			if ( $type === $this->args->variation_images ||
				1 === count( $this->args->attributes ) && in_array( $type, array( 'col', 'row' ), true ) ||
				'both' === $this->args->variation_images ) {
				/* translators: %s: Term Name. */
				$aria_label = sprintf( __( 'Variation picture for %s', 'woo-product-table' ), $term['name'] );
				$image      = $this->data_factory->get_attribute_image_html( $term['slug'], $aria_label );
			}
		}

		$header_template = '<div class="wcpt-header-block">%1$s<span class="%3$s">%2$s</span></div>';

		$content = sprintf(
			$header_template,
			$image,
			$term['name'],
			$term['name'],
			$image ? 'with-image' : 'no-image'
		);

		return $content;
	}

	private function get_grid_style_attribute() {
		$styles = array();

		list( $h_dimension, $v_dimension ) = $this->args->dimensions;

		$col = count(
			array_filter(
				$h_dimension['terms'],
				function( $t ) {
					return $t['count'] > 0;
				}
			)
		);

		$row = 1;

		if ( isset( $v_dimension['terms'] ) ) {
			$row = count(
				array_filter(
					$v_dimension['terms'],
					function( $t ) {
						return $t['count'] > 0;
					}
				)
			);
		}

		if ( empty( $v_dimension ) && 'vert' === $this->args->variation_attribute ) {
			$col--;
		}

		$styles['--h'] = $row;
		$styles['--v'] = $col;

		return implode(
			';',
			array_map(
				function( $k, $v ) {
					return "$k:$v";
				},
				array_keys( $styles ),
				$styles
			)
		);
	}

	private function add_attributes() {

		list( $h_dimension, $v_dimension ) = $this->args->dimensions;

		// Set grid attributes.
		$classes = array(
			'wc-bulk-variations-table',
			'wc-bulk-variations-grid',
			'nowrap',
		);

		if ( empty( $v_dimension ) ) {
			if ( $this->args->variation_attribute ) {
				$classes[] = $this->args->variation_attribute;
			} else {
				$classes[] = 'headless';
			}
		}

		if ( 'off' !== $this->args->variation_images ) {
			$classes[] = "{$this->args->variation_images}-header-images";
		}

		if ( ! $this->use_table_tags ) {
			$classes[] = 'wcpt-table';
		}

		$classes = array_filter(
			array_merge(
				$classes,
				/**
				 * Filter product table custom class
				 * 
				 * @since 1.1.6
				**/
				array( trim( apply_filters( 'wcpt_table_custom_class', '', $this ) ) )
			)
		);

		$this->attributes = array(
			'id'    => $this->id,
			'role'  => 'grid',
			/**
			 * Filter product table classes
			 * 
			 * @since 1.1.6
			**/
			'class' => implode( ' ', apply_filters( 'wcpt_table_classes', $classes, $this ) ),
			'style' => $this->get_grid_style_attribute(),
		);
	}
}

<?php
/**
 * WC Add to Form Processing
 *
 * The WooCommerce form class stores form data and maintain session of forms.
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WC_Quick_Order_Process class.
 */
class WC_Quick_Order_Process {

	/**
	 * Contains an array of form items.
	 *
	 * @var array
	 */
	public $form_contents = array();

	/**
	 * Constructor for the Add_To_Form class. Loads form contents.
	 */
	public function __construct( $form_contents_arr = array(), $form_id = 0 ) {

		$this->form_contents = $form_contents_arr;

		if ( empty( $this->form_contents ) && isset( WC()->session ) && 0 !== $form_id ) {
			$this->form_contents = (array) WC()->session->get( 'wc_quick_order_' . $form_id );
		}

	}


	public function check_product_availability_for_variation( $variation_id, $form_id ) {

		if ( empty( $variation_id ) ) {
			return true;
		}

		$variation = wc_get_product( $variation_id );
		$stock_status       = get_post_meta( $quick_order_id, 'wcpt_product_status', true );
		$show_on_stock = isset($stock_status) ? $stock_status : '';
		if ( ! $variation->is_in_stock() && 'instock' === $show_on_stock ) {
			return false;
		}

		return true;
	}

	/**
	 * Add a product to the Form.
	 *
	 * @throws Exception Plugins can throw an exception to prevent adding to form.
	 * @param int   $product_id contains the id of the product to add to the form.
	 * @param int   $quantity contains the quantity of the item to add.
	 * @param int   $variation_id ID of the variation being added to the form.
	 * @param array $variation attribute values.
	 * @param array $form_item_data extra form item data we want to pass into the item.
	 * @return string|bool $form_item_key
	 */
	public function add_to_form( $form_data = array(), $form_id, $product_id = 0, $quantity = 1, $variation_id = 0, $variation = array(), $form_item_data = array(), $return_contents = false ) {
		try {

			$product_id   = absint( $product_id );
			$variation_id = absint( $product_id );

			// // Ensure we don't add a variation to the form directly by variation ID.
			// if ( 'product_variation' === get_post_type( $product_id ) ) {
			// 	$variation_id = $product_id;
			// 	$product_id   = wp_get_post_parent_id( $variation_id );
			// }

			$product_data = wc_get_product( $variation_id ? $variation_id : $product_id );
			/**
			 * Filter quick order quantity
			 * 
			 * @since 1.1.6
			**/
			$quantity     = apply_filters( 'wc_quick_order_quantity', $quantity, $product_id );

			if ( $quantity <= 0 || ! $product_data || 'trash' === $product_data->get_status() ) {
				return false;
			}

			if ( $product_data->is_type( 'variation' ) ) {

				$missing_attributes = array();
				$parent_data        = wc_get_product( $product_data->get_parent_id() );

				$variation_attributes = $product_data->get_variation_attributes();
				// Filter out 'any' variations, which are empty, as they need to be explicitly specified while adding to form.
				$variation_attributes = array_filter( $variation_attributes );

				// Gather posted attributes.
				$posted_attributes = array();
				foreach ( $parent_data->get_attributes() as $attribute ) {
					if ( ! $attribute['is_variation'] ) {
						continue;
					}
					$attribute_key = 'attribute_' . sanitize_title( $attribute['name'] );

					if ( isset( $variation[ $attribute_key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
						if ( $attribute['is_taxonomy'] ) {
							// Don't use wc_clean as it destroys sanitized characters.
							$value = sanitize_title( wp_unslash( $variation[ $attribute_key ] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
						} else {
							$value = html_entity_decode( wc_clean( wp_unslash( $variation[ $attribute_key ] ) ), ENT_QUOTES, get_bloginfo( 'charset' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
						}

						// Don't include if it's empty.
						if ( ! empty( $value ) || '0' === $value ) {
							$posted_attributes[ $attribute_key ] = $value;
						}
					}
				}

				// Merge variation attributes and posted attributes.
				$posted_and_variation_attributes = array_merge( $variation_attributes, $posted_attributes );

				// If no variation ID is set, attempt to get a variation ID from posted attributes.
				if ( empty( $variation_id ) ) {
					$data_store   = WC_Data_Store::load( 'product' );
					$variation_id = $data_store->find_matching_product_variation( $parent_data, $posted_attributes );
				}

				// Do we have a variation ID?
				if ( empty( $variation_id ) ) {
					throw new Exception( __( 'Please choose product options&hellip;', 'woo-product-table' ) );
				}

				// Do we have a variation ID?
				if ( ! $this->check_product_availability_for_variation( $variation_id, $form_id  ) ) {
					throw new Exception( __( 'Order is not permitted for selected variation &hellip;', 'woo-product-table' ) );
				}

				// Check the data we have is valid.
				$variation_data = wc_get_product_variation_attributes( $variation_id );
				$attributes     = array();

				foreach ( $parent_data->get_attributes() as $attribute ) {
					if ( ! $attribute['is_variation'] ) {
						continue;
					}

					// Get valid value from variation data.
					$attribute_key = 'attribute_' . sanitize_title( $attribute['name'] );
					$valid_value   = isset( $variation_data[ $attribute_key ] ) ? $variation_data[ $attribute_key ] : '';

					/**
					 * If the attribute value was posted, check if it's valid.
					 *
					 * If no attribute was posted, only error if the variation has an 'any' attribute which requires a value.
					 */
					if ( isset( $posted_and_variation_attributes[ $attribute_key ] ) ) {
						$value = $posted_and_variation_attributes[ $attribute_key ];

						// Allow if valid or show error.
						if ( $valid_value === $value ) {
							$attributes[ $attribute_key ] = $value;
						} elseif ( '' === $valid_value && in_array( $value, $attribute->get_slugs(), true ) ) {
							// If valid values are empty, this is an 'any' variation so get all possible values.
							$attributes[ $attribute_key ] = $value;
						} else {
							/* translators: %s: Attribute name. */
							throw new Exception( sprintf( __( 'Invalid value posted for %s', 'woo-product-table' ), wc_attribute_label( $attribute['name'] ) ) );
						}
					} elseif ( '' === $valid_value ) {
						$missing_attributes[] = wc_attribute_label( $attribute['name'] );
					}

					$variation = $attributes;
				}
				if ( ! empty( $missing_attributes ) && ! is_admin() ) {
					/* translators: %s: Attribute name. */
					throw new Exception( sprintf( _n( '%s is a required field', '%s are required fields', count( $missing_attributes ), 'woo-product-table' ), wc_format_list_of_items( $missing_attributes ) ) );
				}
			}

			/**
			 * Filter quick order add item data
			 * 
			 * @since 1.1.6
			**/
			$form_item_data = (array) apply_filters( 'wc_quick_order_add_item_data', $form_item_data, $product_id, $variation_id, $quantity, $form_data );

			// Generate a ID based on product ID, variation ID, variation data, and other form item data.
			$row_id = $this->generate_row_id( $product_id, $variation_id, $variation, $form_item_data );

			// Find the form item key in the existing form.
			$form_item_key = $this->find_product_in_form( $row_id );

			// Force quantity to 1 if sold individually and check for existing item in form.
			if ( $product_data->is_sold_individually() ) {
				/**
				 * Filter quick order sold individually quantity
				 * 
				 * @since 1.1.6
				**/
				$quantity       = apply_filters( 'wc_quick_order_sold_individually_quantity', 1, $quantity, $product_id, $variation_id, $form_item_data );
				/**
				 * Filter quick order sold individually found
				 * 
				 * @since 1.1.6
				**/
				$found_in_form = apply_filters( 'wc_quick_order_sold_individually_found_in_form', $form_item_key && $this->form_contents[ $form_item_key ]['quantity'] > 0, $product_id, $variation_id, $form_item_data, $row_id );

				if ( $found_in_form ) {
					/* translators: %s: product name */
					$message = sprintf( __( 'You cannot add another "%s" to your form.', 'woo-product-table' ), $product_data->get_name() );

					/**
					 * Filters message about more than 1 product being added to form.
					 *
					 * @since 4.5.0
					 * @param string     $message Message.
					 * @param WC_Product $product_data Product data.
					 */
					$message = apply_filters( 'wc_quick_order_cannot_add_another_message', $message, $product_data );

					throw new Exception( $message );
				}
			}

			if ( ! $product_data->is_purchasable() ) {
				$message = __( 'Sorry, this product cannot be purchased.', 'woo-product-table' );
				/**
				 * Filters message about product unable to be purchased.
				 *
				 * @since 1.1.6
				 * @param string     $message Message.
				 * @param WC_Product $product_data Product data.
				*/
				$message = apply_filters( 'wc_quick_order_cannot_be_purchased_message', $message, $product_data );
				throw new Exception( $message );
			}

			// If form_item_key is set, the item is already in the form.
			if (  !empty( $form_item_key ) ) {

				$this->form_contents[ $form_item_key ]['quantity'] += intval( $quantity );
				
			} else {
				$form_item_key = $row_id;

				/**
				 * Filter quick order add item
				 * 
				 * @since 1.1.6
				**/
				$this->form_contents[ $form_item_key ] = apply_filters(
					'wc_quick_order_add_item',
					array_merge(
						$form_item_data,
						array(
							'key'           => $form_item_key,
							'product_id'    => $product_id,
							'variation_id'  => $variation_id,
							'variation'     => $variation,
							'quantity'      => $quantity,
							'data'          => $product_data,
							'data_hash'     => wc_get_cart_item_data_hash( $product_data )
						)
					),
					$form_item_key
				);
			}
			/**
			 * Filter quick order contents changed
			 * 
			 * @since 1.1.6
			**/
			$this->form_contents = apply_filters( 'wc_quick_order_form_contents_changed', $this->form_contents );

			if ( $return_contents ) {
				return $this->form_contents;
			} else {

				wc()->session->set( 'wc_quick_order_' . $form_id, $this->form_contents );
				/**
				 * Action quick order on session change
				 * 
				 * @since 1.1.6
				**/
				do_action('wc_quick_order_session_changed');
			}
			/**
			 * Action quick order add to form
			 * 
			 * @since 1.1.6
			**/
			do_action( 'wc_quick_order_add_to_form', $form_item_key, $product_id, $quantity, $variation_id, $variation, $form_item_data );

			return $form_item_key;

		} catch ( Exception $e ) {
			if ( $e->getMessage() && ! is_admin() ) {
				wc_add_notice( $e->getMessage(), 'error' );
			}
			return false;
		}
	}

	/**
	 * Generate a unique ID for the form item being added.
	 *
	 * @param int   $product_id - id of the product the key is being generated for.
	 * @param int   $variation_id of the product the key is being generated for.
	 * @param array $variation data for the form item.
	 * @param array $form_item_data other form item data passed which affects this items uniqueness in the form.
	 * @return string form item key
	 */
	public function generate_row_id( $product_id, $variation_id = 0, $variation = array(), $form_item_data = array() ) {
		$id_parts = array( $product_id );

		if ( $variation_id && 0 !== $variation_id ) {
			$id_parts[] = $variation_id;
		}

		if ( is_array( $variation ) && ! empty( $variation ) ) {
			$variation_key = '';
			foreach ( $variation as $key => $value ) {
				$variation_key .= trim( $key ) . trim( $value );
			}
			$id_parts[] = $variation_key;
		}

		if ( is_array( $form_item_data ) && ! empty( $form_item_data ) ) {
			$form_item_data_key = '';
			foreach ( $form_item_data as $key => $value ) {
				if ( is_array( $value ) || is_object( $value ) ) {
					$value = http_build_query( $value );
				}
				$form_item_data_key .= trim( $key ) . trim( $value );

			}
			$id_parts[] = $form_item_data_key;
		}
		/**
		 * Filter quick order row id
		 * 
		 * @since 1.1.6
		**/
		return apply_filters( 'wc_quick_order_row_id', md5( implode( '_', $id_parts ) ), $product_id, $variation_id, $variation, $form_item_data );
	}

	/**
	 * Check if product is in the form and return form item key.
	 *
	 * Cart item key will be unique based on the item and its properties, such as variations.
	 *
	 * @param mixed $row_id id of product to find in the form.
	 * @return string form item key
	 */
	public function find_product_in_form( $row_id = false ) {
		if ( false !== $row_id ) {
			if ( is_array( $this->form_contents ) && isset( $this->form_contents[ $row_id ] ) ) {
				return $row_id;
			}
		}
		return '';
	}

	public function remove_form_item( $form_item_key ) {
		if ( isset( $this->form_contents[ $form_item_key ] ) ) {
			/**
			 * Action quick order remove form item
			 * 
			 * @since 1.1.6
			**/
			do_action( 'wc_quick_order_remove_form_item', $form_item_key, $this );
			unset( $this->form_contents[ $form_item_key ] );
			/**
			 * Action quick order form item removed
			 * 
			 * @since 1.1.6
			**/
			do_action( 'wc_quick_order_item_removed', $form_item_key, $this );
			return true;
		}
		return false;
	}
}

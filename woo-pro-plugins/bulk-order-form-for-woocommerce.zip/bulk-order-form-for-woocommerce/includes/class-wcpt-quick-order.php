<?php
/**
 * WC_Product_Table_CPT Class
 *
 * @package Woocommerce Product Table/Includes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * WCPT_Quick_Order_Form Class.
 */
class WCPT_Quick_Order_Form {


	/**
	 * Init the Product Table Type
	 */
	public function __construct() {
		// create custom post type.
		add_action( 'init', array( $this, 'wcpt_quick_order' ) );
		// include scripts.
		add_action( 'admin_enqueue_scripts', array( $this, 'wcpt_enqueue_scripts' ), 20 );
		// Table settings.
		add_action( 'add_meta_boxes', array( $this, 'wcpt_register_meta_boxes' ) );
		add_action( 'save_post', array( $this, 'wcpt_quick_order_save_post' ), 10, 3 );

		// Add Custom Column.
		add_filter( 'manage_wcpt_quick_order_posts_columns', array( $this, 'wcpt_set_shortcode_columns' ) );
		add_action( 'manage_wcpt_quick_order_posts_custom_column', array( $this, 'wcpt_shortcode_column' ), 10, 2 );
	}

	public function wcpt_variation_modify_tab( $product_data_tabs ) {
		$product_data_tabs['wcpt-variation-bulk'] = array(
			'label' => __( 'Bulk Order Form', 'woo-product-table' ),
			'target' => 'wcpt_product_bulk_data',
			'class' => array('show_if_variable')
		);
		return $product_data_tabs;
	}

	

	
	/**
	 * Create product table custom post type.
	 */
	public function wcpt_quick_order() {
		/**
		 * Filter quick order menu title
		 * 
		 * @since 1.1.6
		**/
		$quick_order_title = apply_filters( 'quick_order_menu_title', __( 'Quick Order Form', 'woo-product-table' ) );
		$button_labels = array(
			'name'               => $quick_order_title,
			'singular_name'      => $quick_order_title,
			'menu_name'          => $quick_order_title,
			'name_admin_bar'     => $quick_order_title,
			'add_new'            => __( 'Add New', 'woo-product-table' ),
			'add_new_item'       => __( 'Add New Quick Order Form', 'woo-product-table' ),
			'new_item'           => __( 'New Quick Order Form', 'woo-product-table' ),
			'edit_item'          => __( 'Edit Quick Order Form', 'woo-product-table' ),
			'view_item'          => __( 'View Quick Order Form', 'woo-product-table' ),
			'all_items'          => __( 'Quick Order Form', 'woo-product-table' ),
			'search_items'       => __( 'Search Quick Order Form', 'woo-product-table' ),
			'parent_item_colon'  => __( 'Parent Quick Order Form:', 'woo-product-table' ),
			'not_found'          => __( 'No results found.', 'woo-product-table' ),
			'not_found_in_trash' => __( 'No results found in Trash.', 'woo-product-table' ),
		);

		$button_args = array(
			'labels'             => $button_labels,
			'description'        => __( 'Quick Order Form.', 'woo-product-table' ),
			'public'             => false,
			'publicly_queryable' => false,
			'show_ui'            => true,
			/**
			 * Filter quick order show in menu
			 * 
			 * @since 1.1.6
			**/
			'show_in_menu'       => apply_filters('quick_order_show_in_menu', 'woocommerce'),
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'wcpt_quick_order' ),
			'capability_type'    => 'post',
			/**
			 * Filter quick order menu
			 * 
			 * @since 1.1.6
			**/
			'menu_position'      => apply_filters( 'quick_order_menu_position', null ),
			'menu_icon'          => 'dashicons-editor-table',
			// 'has_archive'        => true,
			// 'hierarchical'       => false,
			'supports'           => array( 'title' ),
		);

		register_post_type( 'wcpt_quick_order', $button_args );
	}

	/**
	 * Enqueue scripts in backend
	 */
	public function wcpt_enqueue_scripts() {
		global $post_type;
		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		if ( 'wcpt_quick_order' !== $post_type ) {
			return;
		}

		wp_enqueue_style( 'wcpt-jquery-ui-style', WCPT_PLUGIN_URL . '/assets/css/jquery-ui/jquery-ui.min.css', array(), WCPT_PLUGIN_VERSION );
		wp_enqueue_style( 'wcpt-style', WCPT_PLUGIN_URL . '/assets/css/admin/style' . $suffix . '.css', array(), WCPT_PLUGIN_VERSION );
		wp_enqueue_style( 'wcpt-select2', WCPT_PLUGIN_URL . '/assets/css/admin/select2/select2' . $suffix . '.css', array(), WCPT_PLUGIN_VERSION );
		wp_enqueue_style( 'woocommerce_admin_styles', WC()->plugin_url() . '/assets/css/admin.css', array(), WC_VERSION );
		wp_enqueue_script( 'wcpt-scripts', WCPT_PLUGIN_URL . 'assets/js/admin/wcpt-scripts' . $suffix . '.js', array( 'jquery', 'jquery-ui-droppable', 'jquery-ui-sortable', 'jquery-ui-draggable', 'jquery-ui-dialog' ), WCPT_PLUGIN_VERSION, true );
		wp_enqueue_script( 'wcpt-select2', WCPT_PLUGIN_URL . 'assets/js/admin/select2/select2' . $suffix . '.js', array( 'jquery' ), WCPT_PLUGIN_VERSION, true );
		wp_enqueue_script( 'jquery-tiptip' );

		// please create also an empty JS file in your theme directory and include it too.
		wp_enqueue_script( 'wcpt-custom-sel', WCPT_PLUGIN_URL . 'assets/js/admin/wcpt-settings-script' . $suffix . '.js', array( 'jquery', 'wcpt-select2', 'jquery-ui-datepicker' ), WCPT_PLUGIN_VERSION, true );
	}

	/**
	 * Register metabox
	 */
	public function wcpt_register_meta_boxes() {
		add_meta_box( 'wcpt-settings', __( 'Product Table Settings', 'woo-product-table' ), array( $this, 'wcpt_settings_display_callback' ), 'wcpt_quick_order' );
		add_meta_box( 'wcpt-products-display-settings', __( 'Choosing which products appear in the table', 'woo-product-table' ), array( $this, 'wcpt_products_display_options' ), 'wcpt_quick_order' );
		// if ( class_exists( 'Wwp_Wholesale_Pricing' ) ) {
		// 	add_meta_box( 'wcpt-wholesale-settings', __( 'Wholesale Settings', 'woo-product-table' ), array( $this, 'wcpt_wholesaler_settings' ), 'wcpt_quick_order' );
		// }
		add_meta_box( 'wcpt-shortcode-generates', __( 'Shortcode', 'woo-product-table' ), array( $this, 'wcpt_shortcode_display_options' ), 'wcpt_quick_order', 'side' );
	}

	/**
	 * Mapping settings callback
	 *
	 * @param int $post post id.
	 */
	public function wcpt_settings_display_callback( $post ) {
		$id = $post->ID;

		$table_fields = get_post_meta( get_the_ID(), 'product_table_fields', true );
		$names        = array(
			'woo_column_ids'               => 'woo_ids',
			'woo_column_name'              => 'woo_label',
			'woo_column_linkable'          => 'woo_linkable',
			'woo_column_width'             => 'woo_width_text',
			'woo_column_width_type'        => 'woo_width_type',
			'woo_column_descr'             => 'woo_descr',
			'woo_column_date_format'       => 'woo_date_format',
			'woo_column_add_types'         => 'woo_add_types',
			'woo_column_add_selected_cart' => 'woo_add_selected_cart',
			'woo_column_quantity'          => 'woo_quantity',
			'woo_column_attrs'             => 'woo_attrs',
			'woo_column_custom_keys'       => 'woo_custom_keys',
			'woo_column_taxonomy'          => 'woo_taxonomy'
		);

		$mapping_labels = array(
			'sku'           => __( 'SKU', 'woo-product-table' ),
			'short_desc'    => __( 'Short Description', 'woo-product-table' ),
			'cat'           => __( 'Categories', 'woo-product-table' ),
			'featured_img'  => __( 'Featured Image', 'woo-product-table' ),
			'stock'         => __( 'Stock', 'woo-product-table' ),
			'weight'        => __( 'Weight', 'woo-product-table' ),
			'dimensions'    => __( 'Dimensions', 'woo-product-table' ),
			'price'         => __( 'Price', 'woo-product-table' )
		);
		wp_nonce_field( 'wcpt_settings_display_callback', 'wcpt_settings_display_nonce' );
		require_once WCPT_PLUGIN_FILE . 'includes/views/product-table-settings.php';
	}

	/**
	 * Table Products Display Options
	 *
	 * @param int $post post id.
	 */
	public function wcpt_products_display_options( $post ) {
		$post_id = $post->ID;

		$product_ids     = get_post_meta( $post_id, 'wcpt_inc_product_ids', true );
		$product_exc_ids = get_post_meta( $post_id, 'wcpt_ex_product_ids', true );

		$product_categories = get_terms( 'product_cat', 'orderby=name&hide_empty=0' );
		$product_tags       = get_terms( 'product_tag', 'hide_empty=0' );

		if ( $product_categories ) {
			$category_options = array();
			foreach ( $product_categories as $product_category ) {
				$category_options[ $product_category->term_id ] = $product_category->name;
			}
		}

		if ( $product_tags ) {
			$tag_options = array();
			foreach ( $product_tags as $product_tag ) {
				$tag_options[ $product_tag->term_id ] = $product_tag->name;
			}
		}

		require_once WCPT_PLUGIN_FILE . 'includes/views/admin/meta-boxes/html-products-display-options.php';
	}

	/**
	 * Table Wholesaler Role Options
	 *
	 * @param int $post post id.
	 */
	// public function wcpt_wholesaler_settings( $post ) {
	// 	$post_id = $post->ID;

	// 	$display_wholesale_only     = get_post_meta( $post_id, 'display_wholesale_only', true );
	// 	$selected_roles = get_post_meta( $post_id, 'wcpt_wholesale_selected_roles', true );

	// 	$wholesale_user_roles       = get_terms( 'wholesale_user_roles', 'hide_empty=0' );

	// 	if ( $wholesale_user_roles ) {
	// 		$user_roles = array();
	// 		foreach ( $wholesale_user_roles as $wholesale_user_role ) {
	// 			$user_roles[ $wholesale_user_role->slug ] = $wholesale_user_role->name;
	// 		}
	// 	}

	// 	require_once WCPT_PLUGIN_FILE . 'includes/views/admin/meta-boxes/html-wholesale-user-settings.php';
	// }
	/**
	 * Table Wholesaler Role Options
	 *
	 * @param int $post post id.
	 */
	// public function wcpt_product_addon_settings( $post ) {
	// 	$post_id = $post->ID;
	// 	$display_product_addon     = !empty( get_post_meta( $post_id, 'wcpt_addon_display', true ) ) ? get_post_meta( $post_id, 'wcpt_addon_display', true ) : 'vertical';

	// 	require_once WCPT_PLUGIN_FILE . 'includes/views/admin/meta-boxes/html-product-addon-settings.php';
	// }

	/**
	 * Table Shortcode
	 *
	 * @param int $post post id.
	 */
	public function wcpt_shortcode_display_options( $post ) {
		echo esc_html( "[wc_quick_order id=$post->ID]" );
	}

	/**
	 * Table Save
	 *
	 * @param int $product_table_id product table id.
	 * @param int $post post id.
	 * @param int $update update.
	 */
	public function wcpt_quick_order_save_post( $product_table_id, $post, $update ) {

		// Only set for post_type = post!.
		if ( 'wcpt_quick_order' !== $post->post_type ) {
			return;
		}

		if ( ! isset( $_POST['wcpt_settings_display_nonce'] ) ) {
			return;
		}

		// Verify that the nonce is valid.
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wcpt_settings_display_nonce'] ) ), 'wcpt_settings_display_callback' ) ) {
			return;
		}
		
		$fields = array();

		$link_key   = 0;
		$descr_key  = 0;
		$date_key   = 0;
		$attr_key   = 0;
		$tax_key    = 0;
		$custom_key = 0;
		$cart_key   = 0;
		if ( isset( $_POST['woo_ids'] ) ) {
			$woo_ids = array_map( 'sanitize_text_field', wp_unslash( $_POST['woo_ids'] ) );
			foreach ( $woo_ids as $key => $id ) {
				$fields[ $key ]['woo_ids'] = $id;
				if ( isset( $_POST['woo_label'][ $key ] ) ) {
					$fields[ $key ]['woo_label'] = sanitize_text_field( wp_unslash( $_POST['woo_label'][ $key ] ) );
				}

				if ( isset( $_POST['woo_width_text'] ) ) {
					if ( isset( $_POST['woo_width_text'][ $key ] ) ) {
						$width_text = sanitize_text_field( wp_unslash( $_POST['woo_width_text'][ $key ] ) );
					}

					if ( $width_text ) {
						if ( isset( $_POST['woo_width_type'][ $key ] ) ) {
							$width_type = sanitize_text_field( wp_unslash( $_POST['woo_width_type'][ $key ] ) );
						}
						if ( 'percent' === $width_type ) {
							$option = '%';
						} else {
							$option = 'px';
						}
						$fields[ $key ]['woo_width']      = $width_text . '' . $option;
						$fields[ $key ]['woo_width_text'] = $width_text;
						$fields[ $key ]['woo_width_type'] = $width_type;
					} else {
						$fields[ $key ]['woo_width']      = '';
						$fields[ $key ]['woo_width_text'] = '';
					}
				}

				if ( isset( $_POST['woo_linkable'][ $link_key ] ) && ( 'title' === $id || 'featured_img' === $id ) ) {
					$fields[ $key ]['woo_linkable'] = sanitize_text_field( wp_unslash( $_POST['woo_linkable'][ $link_key ] ) );
					$link_key++;
				} elseif ( isset( $_POST['woo_descr'][ $descr_key ] ) && 'descr' === $id ) {
					$fields[ $key ]['woo_descr'] = sanitize_text_field( wp_unslash( $_POST['woo_descr'][ $descr_key ] ) );
					$descr_key++;
				} elseif ( isset( $_POST['woo_date_format'][ $date_key ] ) && 'date' === $id ) {
					$fields[ $key ]['woo_date_format'] = sanitize_text_field( wp_unslash( $_POST['woo_date_format'][ $date_key ] ) );
					$date_key++;
				} elseif ( isset( $_POST['woo_attrs'][ $attr_key ] ) && 'attributes' === $id ) {
					$fields[ $key ]['woo_attrs'] = sanitize_text_field( wp_unslash( $_POST['woo_attrs'][ $attr_key ] ) );
					$attr_key++;
				} elseif ( isset( $_POST['woo_custom_keys'][ $custom_key ] ) && 'custom_fields' === $id ) {
					$fields[ $key ]['woo_custom_keys'] = sanitize_text_field( wp_unslash( $_POST['woo_custom_keys'][ $custom_key ] ) );
					$custom_key++;
				} elseif ( isset( $_POST['woo_taxonomy'][ $tax_key ] ) && 'taxonomy' === $id ) {
					$fields[ $key ]['woo_taxonomy'] = sanitize_text_field( wp_unslash( $_POST['woo_taxonomy'][ $tax_key ] ) );
					$tax_key++;
				} elseif ( ( isset( $_POST['woo_quantity'][ $cart_key ] ) || isset( $_POST['woo_add_types'][ $cart_key ] ) || isset( $_POST['woo_add_selected_cart'][ $cart_key ] ) ) && 'cart_button' === $id ) {
					$fields[ $key ]['woo_quantity']          = sanitize_text_field( wp_unslash( $_POST['woo_quantity'][ $cart_key ] ) );
					$fields[ $key ]['woo_add_types']         = sanitize_text_field( wp_unslash( $_POST['woo_add_types'][ $cart_key ] ) );
					$fields[ $key ]['woo_add_selected_cart'] = sanitize_text_field( wp_unslash( $_POST['woo_add_selected_cart'][ $cart_key ] ) );
					$cart_key++;
				}
			}
		}

		update_post_meta( $product_table_id, 'product_table_fields', $fields );

		$wcpt_meta_settings = array(
			'display_wholesale_only',
			'wcpt_inc_product_cats',
			'wcpt_wholesale_selected_roles',
			'wcpt_addon_display',
			'wcpt_product_status'
		);

		foreach ( $wcpt_meta_settings as $wcpt_meta_setting ) {
			if ( isset( $_POST[ $wcpt_meta_setting ] ) ) {
				if ( is_array( $_POST[ $wcpt_meta_setting ] ) ) {
					$wcpt_meta = array_map( 'sanitize_text_field', wp_unslash( $_POST[ $wcpt_meta_setting ] ) );
				} else {
					$wcpt_meta = sanitize_text_field( wp_unslash( $_POST[ $wcpt_meta_setting ] ) );
				}

							update_post_meta( $product_table_id, $wcpt_meta_setting, $wcpt_meta );
			} else {
							update_post_meta( $product_table_id, $wcpt_meta_setting, '' );
			}
		}

	}

	/**
	 * Table Set Columns Shortcode
	 *
	 * @param int $columns columns.
	 */
	public function wcpt_set_shortcode_columns( $columns ) {
		$columns['shortcode'] = __( 'Shortcode', 'woo-product-table' );

		return $columns;
	}

	/**
	 * Table Columns Shortcode
	 *
	 * @param int $column column.
	 * @param int $post_id post id.
	 */
	public function wcpt_shortcode_column( $column, $post_id ) {

		if ( 'shortcode' === $column ) {
			echo esc_html( "[wc_quick_order id=$post_id]" );
		}
	}
}

new WCPT_Quick_Order_Form();

<?php
/**
 * Product Table Shortcode
 *
 * @class    Product_Table_Shortcode
 * @package Woocommerce Product Table/Shortcode
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/**
 * Product_Table_Shortcode class.
 */
class Product_Table_Shortcode {

	/**
	 * Class Constructor.
	 */
	public function __construct() {
		// enqueue woocommerce product table scripts.
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_wc_products_table_scripts' ) );
		// woocommerce products table shortcode.
		add_shortcode( 'wc_products_table', array( $this, 'wc_products_table' ) );
	}

	/**
	 * Enqueue woocommerce product table scripts.
	 */
	public function enqueue_wc_products_table_scripts() {
		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
		// enqueue datatables scripts and styles.
		wp_register_style( 'datatables_style', WCPT_PLUGIN_URL . 'assets/css/frontend/jquery.dataTables' . $suffix . '.css', array(), true );
		wp_register_style( 'wcpt_single_product', WCPT_PLUGIN_URL . 'assets/css/frontend/wcpt-product' . $suffix . '.css', array(), true );
		wp_enqueue_style( 'wcpt_single_product' );
		wp_register_script( 'wcpt_calculate', WCPT_PLUGIN_URL . 'assets/js/frontend/wcpt-calculate' . $suffix . '.js', array( 'jquery' ), true, true );
		wp_enqueue_script( 'wcpt_calculate' );
		/**
		 * Filter bulk variation script params
		 * 
		 * @since 1.1.6
		**/
		$params = apply_filters(
			'wc_bulk_variations_script_params',
			array(
				'debug'                   => defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG,
				'currency_options'        => array(
					'decimals'        => wc_get_price_decimals(),
					'd_separator'     => wc_get_price_decimal_separator(),
					't_separator'     => wc_get_price_thousand_separator(),
					'currency_symbol' => get_woocommerce_currency_symbol(),
					'price_format'    => get_woocommerce_price_format(),
					'price_markup'    => '<span class="woocommerce-Price-amount amount"><bdi>%s</bdi></span>'
				),
				'hide_out_of_stock_items' => filter_var( get_option( 'woocommerce_hide_out_of_stock_items' ), FILTER_VALIDATE_BOOLEAN ),
				'show_stock'              => false,
				'disable_purchasing'      => false,
				'i18n_item_singular'      => __( 'Item', 'woo-product-table' ),
				'i18n_item_plural'        => __( 'Items', 'woo-product-table' ),
				// translators: the total amount (currency)
				'i18n_your_total'         => __( 'Your total is %s', 'woo-product-table' ),
			)
		);

		$script = sprintf( 'const wcpt_params = %s;', wp_json_encode( $params ) );

		wp_add_inline_script( 'wcpt_calculate', $script, 'before' );
		wp_register_script( 'datatables_script', WCPT_PLUGIN_URL . 'assets/js/frontend/jquery.dataTables' . $suffix . '.js', array( 'jquery' ), true, true );

		wp_register_script( 'product_table_script', WCPT_PLUGIN_URL . 'assets/js/frontend/wc-product-datatable-scripts' . $suffix . '.js', array( 'jquery' ), true, true );
		wp_register_style( 'product_table_style', WCPT_PLUGIN_URL . 'assets/css/frontend/wcpt-style' . $suffix . '.css', array(), true );
		// localize product table script.
		$product_table_params = array(
			'ajax_url'      => admin_url( 'admin-ajax.php' ),
			'error_message' => __( 'No product added to cart', 'woo-product-table' ),
			'nonce'         => wp_create_nonce( 'ajax-nonce' ),
		);
		wp_register_style( 'responsive_datatables_style', WCPT_PLUGIN_URL . 'assets/css/frontend/responsive.dataTables.css', array(), true );
		wp_register_script( 'responsive_datatables_script', WCPT_PLUGIN_URL . 'assets/js/frontend/responsive.dataTables.js', array( 'jquery' ), true, true );
		wp_register_script( 'button_datatables_script', WCPT_PLUGIN_URL . 'assets/js/frontend/button.dataTables.js', array( 'jquery' ), true, true );
		wp_register_script( 'colvis_button_datatables_script', WCPT_PLUGIN_URL . 'assets/js/frontend/colvis.button.dataTables.js', array( 'jquery' ), true, true );

		wp_localize_script( 'product_table_script', 'product_table_params', $product_table_params );
	}

	/**
	 * Add woocommerce products table shortcode.
	 *
	 * @param array $atts attributes for product table.
	 */
	public function wc_products_table( $atts ) {

		wp_enqueue_style( 'datatables_style' );
		wp_enqueue_style( 'product_table_style' );
		wp_enqueue_script( 'datatables_script' );
		wp_enqueue_script( 'product_table_script' );
		wp_enqueue_script( 'wc-add-to-cart' );
		wp_enqueue_script( 'wc-add-to-cart-variation' );
		wp_enqueue_style( 'responsive_datatables_style' );
		wp_enqueue_script( 'responsive_datatables_script' );
		wp_enqueue_script( 'button_datatables_script' );
		wp_enqueue_script( 'colvis_button_datatables_script' );


		
		$atts = shortcode_atts(
			array(
				'id' => '',
			),
			$atts
		);
		// get product table settings with id.
		if ( $atts['id'] && !in_array( get_post_status( $atts['id'] ), array( 'trash', false ) ) ) {
			$product_table_id       = $atts['id'];
			$display_wholesale_only = !empty( get_post_meta( $product_table_id, 'display_wholesale_only', true ) ) ? get_post_meta( $product_table_id, 'display_wholesale_only', true ) : 'no';
			$wcpt_addon_display = !empty( get_post_meta( $product_table_id, 'wcpt_addon_display', true ) ) ? get_post_meta( $product_table_id, 'wcpt_addon_display', true ) : 'vertical';
			if ( 'horizontal' === $wcpt_addon_display ) {
				$horizontal_css = '#ptholder table.product-table.dataTable .product-cart-wrapper p.wc-pao-addon-wrap{display:inline-block;width:auto;margin-right:10px;}';
				wp_add_inline_style( 'product_table_style', $horizontal_css );
			}
			$wcpt_wholesale_selected_roles = !empty( get_post_meta( $product_table_id, 'wcpt_wholesale_selected_roles', true ) ) ? get_post_meta( $product_table_id, 'wcpt_wholesale_selected_roles', true ) : array();
			$roles = is_user_logged_in() ? wp_get_current_user()->roles : array();
			
			if ( class_exists('Wwp_Wholesale_Pricing') && 'yes' === $display_wholesale_only && !empty($wcpt_wholesale_selected_roles) && empty( array_intersect( $roles, $wcpt_wholesale_selected_roles ) ) ) {
					ob_start();
				?>

				<p class="woocommerce-info"><?php echo esc_html__( 'You don\'t have permissions', 'woo-product-table' ); ?></p>
				<?php
				return ob_get_clean();
			}
			/**
			 * Filter product table footer
			 * 
			 * @since 1.1.6
			**/
			$product_table_footer           = apply_filters( 'wcpt_product_table_footer', get_post_meta( $product_table_id, 'display_table_footer', true ), $product_table_id );
			$selected_cart_position         = wc_product_table()->product_table_add_selected_cart( $product_table_id );
			$args['id']                     = $product_table_id;
			$args['product_table_header']   = get_post_meta( $product_table_id, 'display_table_header', true );
			$args['rows_per_page']          = get_post_meta( $product_table_id, 'wcpt_rows_page', true );
			$args['product_table_headings'] = wc_product_table()->products_table_heading( $product_table_id );
			// get sorted columns.

			if ( get_post_meta( $product_table_id, 'default_sorted_col', true ) ) {
				$default_sorted_col = get_post_meta( $product_table_id, 'default_sorted_col', true );
				$default_sorted_col         = explode( '_', $default_sorted_col );
				$args['default_sorted_col'] = end( $default_sorted_col );
			} else {
				$args['default_sorted_col'] = '';
			}
			$args['default_sorted_dir'] = get_post_meta( $product_table_id, 'default_sorted_dir', true );
			$enable_sort_cols           = get_post_meta( $product_table_id, 'enable_sort_cols', true );
			if ( $enable_sort_cols ) {
				$args['sorted_cols'] = get_post_meta( $product_table_id, 'sorted_cols', true );
			} else {
				$args['sorted_cols'] = array();
			}
			$args['table_id']               = $product_table_id;
			$args['responsive_options']     = $this->get_responsive_options( $args );
			$args['search']                 = get_post_meta( $product_table_id, 'show_search', true );
			$args['filters']                = get_post_meta( $product_table_id, 'show_filter', true );
			$args['filter_terms']           = get_post_meta( $product_table_id, 'wcpt_filters_obj', true );
			$args['col_filters']            = get_post_meta( $product_table_id, 'wcpt_filters_col', true );
			$args['product_table_headings'] = wc_product_table()->products_table_heading( $product_table_id );
			$args['wcpt_scroll']            = get_post_meta( $product_table_id, 'wcpt_scroll', true );
			$args['reset_button']           = get_post_meta( $product_table_id, 'display_reset', true );
			if ( ! $args['wcpt_scroll'] ) {
				$args['wcpt_scroll'] = 0;
			}

			$wcpt_wrap                   = get_post_meta( $product_table_id, 'wcpt_wrap', true );
			$args['wcpt_wrap']           = ( 'yes' === $wcpt_wrap ? 'wrap' : 'nowrap' );
			$args['paging_type']         = get_post_meta( $product_table_id, 'pagingType', true );
			$args['no_products_msg']     = get_post_meta( $product_table_id, 'wcpt_custom_products_msg', true );
			$display_page_length         = get_post_meta( $product_table_id, 'display_page_length', true );
			$args['display_page_length'] = ( $display_page_length ? 'yes' : 'no' );

			$display_product_totals         = get_post_meta( $product_table_id, 'display_product_totals', true );
			$args['display_product_totals'] = ( $display_product_totals ? 'yes' : 'no' );

			$display_pagination         = get_post_meta( $product_table_id, 'display_pagination', true );
			$args['display_pagination'] = ( $display_pagination ? 'yes' : 'no' );
			/**
			 * Filter product table heading args
			 * 
			 * @since 1.1.6
			**/
			$args = apply_filters( 'wcpt_product_table_heading_args', $args, $atts );
			ob_start();
			wc_product_table_get_template( 'product-table-wrap-start.php' );

			if ( ( $selected_cart_position && 'below_add' !== $selected_cart_position ) || $args['filters'] ) {
				wc_product_table_get_template( 'product-table-filter-cart-start.php' );
			}
			// add selected cart before table.
			if ( $selected_cart_position && 'below_add' !== $selected_cart_position ) {
				wc_product_table_get_template( 'product-table-add-selected-cart.php' );
			}
			if ( $args['filters'] ) {
				wc_product_table_get_template( 'product-table-filters.php', $args );
			}
			if ( ( $selected_cart_position && 'below_add' !== $selected_cart_position ) || $args['filters'] ) {
				wc_product_table_get_template( 'product-table-filter-cart-end.php' );
			}
			// woocommerce product table start tag.
			wc_product_table_get_template( 'product-table-start.php', $args );
			// woocommerce product table header.
			wc_product_table_get_template( 'product-table-header.php', $args );

			// woocommerce product table footer.
			if ( $product_table_footer ) {
				wc_product_table_get_template( 'product-table-footer.php', $args );
			}

			// woocommerce product table end tag.
			wc_product_table_get_template( 'product-table-end.php' );

			// add selected cart below table.
			if ( $selected_cart_position && 'above_add' !== $selected_cart_position ) {
				wc_product_table_get_template( 'product-table-add-selected-cart.php' );
			}
			wc_product_table_get_template( 'product-table-wrap-end.php' );
		}

		return ob_get_clean();
	}
	/**
	 * Get responsive options in datatable.
	 *
	 * @param array $args array of arguments.
	 */
	public function get_responsive_options( $args ) {

		$responsive            = get_post_meta( $args['id'], 'display_responsive', true );
		$data_attr             = '';
		$options               = array();
		$hidden_col_mobile     = array();
		$hidden_col_mobile_ids = '';
		$hidden_col_tablet     = array();
		$hidden_col_tablet_ids = '';
		$hidden_col_ids        = '';
		$hidden_col            = '';
		if ( $responsive ) {
			if ( 'priority_opt' === $responsive ) {
				$hidden_col = get_post_meta( $args['id'], 'columns_show', true );
				if ( is_array( $hidden_col ) ) {
					$hidden_col_ids          = $this->prepare_columns_ids( $hidden_col );
					$hidden_col_ids_imploded = implode( ',', $hidden_col_ids );

					$data_attr = 'data-hidden-col-ids=' . esc_attr( $hidden_col_ids_imploded );
				}
			} elseif ( 'column_breakpts' === $responsive ) {
				$data_attr         = 'data-column_breakpts="yes"';
				$hidden_col_mobile = get_post_meta( $args['id'], 'columns_mobile_show', true );
				if ( is_array( $hidden_col_mobile ) ) {
					$hidden_col_mobile_ids          = $this->prepare_columns_ids( $hidden_col_mobile );
					$hidden_col_mobile_ids_imploded = implode( ',', $hidden_col_mobile_ids );
					$data_attr                     .= 'data-hidden-col-mob-ids=' . esc_attr( $hidden_col_mobile_ids_imploded );
				}

				$hidden_col_tablet = get_post_meta( $args['id'], 'columns_tablet_show', true );
				if ( is_array( $hidden_col_tablet ) ) {
					$hidden_col_tablet_ids          = $this->prepare_columns_ids( $hidden_col_tablet );
					$hidden_col_tablet_ids_imploded = implode( ',', $hidden_col_tablet_ids );

					$data_attr .= ' data-hidden-col-tab-ids=' . esc_attr( $hidden_col_tablet_ids_imploded );
				}
			} else {
				if ( 'fully_resp' === $responsive ) {
					$data_attr = 'data-responsive=' . esc_attr( $responsive );
				}
			}
		}
		$options = array(
			'data_attr'             => $data_attr,
			'hidden_col_mobile'     => $hidden_col_mobile,
			'hidden_col_mobile_ids' => $hidden_col_mobile_ids,
			'hidden_col_tablet'     => $hidden_col_tablet,
			'hidden_col_tablet_ids' => $hidden_col_tablet_ids,
			'hidden_col'            => $hidden_col,
			'hidden_col_ids'        => $hidden_col_ids,
		);
		return $options;
	}
	/**
	 * Get array of hidden columns ids
	 *
	 * @param array $col_ids array of column ids.
	 * @return array
	 */
	public function prepare_columns_ids( $col_ids ) {
		$hidden_col_ids = array_map(
			function ( $val ) {
						$data = explode( '_', $val );
						return end( $data );
			},
			$col_ids
		);

		return $hidden_col_ids;
	}
}

	new Product_Table_Shortcode();

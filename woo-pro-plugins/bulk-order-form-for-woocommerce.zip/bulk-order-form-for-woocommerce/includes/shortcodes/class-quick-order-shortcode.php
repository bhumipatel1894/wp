<?php
/**
 * Quick Order Shortcode
 *
 * @class    Quick_Order_Shortcode
 * @package Woocommerce Product Table/Shortcode
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/**
 * Quick_Order_Shortcode class.
 */
class Quick_Order_Shortcode {

	/**
	 * Class Constructor.
	 */
	public function __construct() {
		// enqueue woocommerce product table scripts.
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_wc_quick_order_scripts' ) );
		// woocommerce products table shortcode.
		add_shortcode( 'wc_quick_order', array( $this, 'wc_quick_order' ) );
		add_action('wp_ajax_wc_quick_order_add', array( $this, 'wc_quick_order_add' ) );
		add_action('wp_ajax_nopriv_wc_quick_order_add', array( $this, 'wc_quick_order_add' ) );
		// add_action( 'wp_ajax_wc_quick_add_to_cart', array( $this, 'wc_quick_order_add_to_cart' ) );
		// add_action( 'wp_ajax_nopriv_wc_quick_add_to_cart', array( $this, 'wc_quick_order_add_to_cart' ) );

		add_action( 'wp_ajax_nopriv_woocommerce_json_search_products_and_variations', array( $this, 'wc_quick_order_search_nopriv' ), 99 );
		/**
		* Ajax remove form item action.
		*/
		add_action( 'wp_ajax_wc_quick_order_remove_item', array( $this, 'wc_quick_order_remove_item' ) );
		add_action( 'wp_ajax_nopriv_wc_quick_order_remove_item', array( $this, 'wc_quick_order_remove_item' ) );

		add_action( 'wp_ajax_wc_quick_order_update', array( $this, 'wc_quick_order_update' ) );
		add_action( 'wp_ajax_nopriv_wc_quick_order_update', array( $this, 'wc_quick_order_update' ) );

		add_action( 'wp_ajax_wc_quick_order_update_items', array( $this, 'wc_quick_order_update_items' ) );
		add_action( 'wp_ajax_nopriv_wc_quick_order_update_items', array( $this, 'wc_quick_order_update_items' ) );

		add_action( 'wp_ajax_wc_quick_order_add_to_cart', array( $this, 'wc_quick_order_add_to_cart' ) );
		add_action( 'wp_ajax_nopriv_wc_quick_order_add_to_cart', array( $this, 'wc_quick_order_add_to_cart' ) );
	}

	public static function wc_quick_order_search_nopriv() {
		self::json_search_products( '', true );
	}

	public static function json_search_products( $term = '', $include_variations = false ) {

		check_ajax_referer( 'search-products', 'security' );
		$get = $_GET;
		if ( empty( $term ) && isset( $_GET['term'] ) ) {
			$term = (string) wc_clean( wp_unslash( $_GET['term'] ) );
		}

		if ( empty( $term ) ) {
			wp_die();
		}

		if ( ! empty( $_GET['limit'] ) ) {
			$limit = absint( $_GET['limit'] );
		} else {
			/**
			 * Filter woocommerce json search limit
			 * 
			 * @since 1.1.6
			**/
			$limit = absint( apply_filters( 'woocommerce_json_search_limit', 30 ) );
		}

		$include_ids = ! empty( $_GET['include'] ) ? array_map( 'absint', (array) wp_unslash( $_GET['include'] ) ) : array();
		$exclude_ids = ! empty( $_GET['exclude'] ) ? array_map( 'absint', (array) wp_unslash( $_GET['exclude'] ) ) : array();

		$exclude_types = array();
		if ( ! empty( $_GET['exclude_type'] ) ) {
			// Support both comma-delimited and array format inputs.
			$exclude_types = wp_unslash( $get['exclude_type'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			if ( ! is_array( $exclude_types ) ) {
				$exclude_types = explode( ',', $exclude_types );
			}

			// Sanitize the excluded types against valid product types.
			foreach ( $exclude_types as &$exclude_type ) {
				$exclude_type = strtolower( trim( $exclude_type ) );
			}
			$exclude_types = array_intersect(
				array_merge( array( 'variation' ), array_keys( wc_get_product_types() ) ),
				$exclude_types
			);
		}

		$data_store = WC_Data_Store::load( 'product' );
		$ids        = $data_store->search_products( $term, '', (bool) $include_variations, false, $limit, $include_ids, $exclude_ids );
		
		$products = array();

		foreach ( $ids as $id ) {
			$product_object = wc_get_product( $id );

			if ( ! is_a( $product_object, 'WC_Product' ) ) {
				continue;
			}
			$formatted_name = $product_object->get_formatted_name();
			$managing_stock = $product_object->managing_stock();

			if ( in_array( $product_object->get_type(), $exclude_types, true ) ) {
				continue;
			}

			if ( $managing_stock && ! empty( $_GET['display_stock'] ) ) {
				$stock_amount = $product_object->get_stock_quantity();
				/* Translators: %d stock amount */
				$formatted_name .= ' &ndash; ' . sprintf( __( 'Stock: %d', 'woocommerce' ), wc_format_stock_quantity_for_display( $stock_amount, $product_object ) );
			}

			$products[ $product_object->get_id() ] = rawurldecode( wp_strip_all_tags( $formatted_name ) );
		}
		/**
		 * Filter woocommerce_json_search_found_products
		 * 
		 * @since 1.1.6
		**/
		wp_send_json( apply_filters( 'woocommerce_json_search_found_products', $products ) );

	}

	public function change_key( $array, $old_key, $new_key ) {
		if ( ! array_key_exists( $old_key, $array ) ) {
			return $array;
		}

		$keys = array_keys( $array );
		$keys[ array_search( $old_key, $keys ) ] = $new_key;

		return array_combine( $keys, $array );
	}

	/**
	* Ajax update form controller.
	*/
	public function wc_quick_order_update() {
		if ( isset( $_POST['nonce'] ) && ! empty( $_POST['nonce'] ) ) {
			$nonce = sanitize_text_field( wp_unslash( $_POST['nonce'] ) );
		} else {
			$nonce = 0;
		}

		if ( ! wp_verify_nonce( $nonce, 'search-products' ) ) {
			die( 'Failed ajax security check!' );
		}

		if ( isset( $_POST ) ) {
			$form_data = sanitize_meta('', wp_unslash( $_POST), '' );
		} else {
			$form_data = '';
		}

		$_POST      = $form_data;
		$product_id = isset( $form_data['product_id'] ) ? intval( $form_data['product_id'] ) : '';
		$quantity   = isset( $form_data['quantity'] ) ? intval( $form_data['quantity'] ) : 1;
		$quick_order_id = isset( $form_data['form_id'] ) ? intval( $form_data['form_id'] ) : '';
		$quick_order_fields = wc_product_table()->get_product_table_fields( $quick_order_id );
		$item_key = isset( $_POST['form_key'] ) ? sanitize_text_field( wp_unslash( $_POST['form_key'] ) ) : '';

		$wc_quick_order = new WC_Quick_Order_Process(array(), $quick_order_id);
		/**
		 * Filter quick order validation passed
		 * 
		 * @since 1.1.6
		**/
		$passed_validation = apply_filters( 'wc_quick_order_form_validation', true, $product_id, $quantity, $form_data );

		if ( !$passed_validation ) {
			echo 'failed';
			die();
		}

		$form_item_key = $wc_quick_order->add_to_form( $form_data, $quick_order_id, $product_id, $quantity );

		$form_contents = wc()->session->get( 'wc_quick_order_' . $quick_order_id );

		if ( isset( $form_contents[ $form_item_key ] ) ) {
			$form_contents[ $item_key ] = $form_contents[ $form_item_key ];
			$form_contents = $this->change_key($form_contents, $item_key, $form_item_key);
			
			WC()->session->set( 'wc_quick_order_' . $quick_order_id, array_filter( $form_contents ) );
		}
		ob_start();

		if ( file_exists( get_stylesheet_directory() . '/woocommerce/bulkorder/templates/quick-order-table.php' ) ) {

			include get_stylesheet_directory() . '/woocommerce/bulkorder/templates/quick-order-table.php';

		} else {

			include WCPT_PLUGIN_FILE . '/templates/quick-order-table.php';
		}
		$form_table = ob_get_clean();
		if ( false === $form_item_key ) {
			/* translators: %s: Product name */
			wc_add_notice( sprintf( __( '“%s” cannot be added.', 'woo-product-table' ), $product_name ), 'error' );
			echo 'success';
		} else {
			wp_send_json(
				array(
					'form_empty'  => empty( WC()->session->get('wc_quick_order_' . $quick_order_id) ) ? true : false,
					'form-table'  => $form_table
				)
			);
		}
		die();
	}

	/**
	* Ajax update form controller.
	*/
	public function wc_quick_order_update_items() {

		if ( isset( $_POST['nonce'] ) && ! empty( $_POST['nonce'] ) ) {
			$nonce = sanitize_text_field( wp_unslash( $_POST['nonce'] ) );
		} else {
			$nonce = 0;
		}

		if ( ! wp_verify_nonce( $nonce, 'search-products' ) ) {
			die( 'Failed ajax security check!' );
		}

		if ( isset( $_POST ) ) {
			$form_data = sanitize_meta('', wp_unslash( $_POST), '' );
		} else {
			$form_data = '';
		}

		$_POST      = $form_data;
		$quantity   = isset( $form_data['quantity'] ) ? intval( $form_data['quantity'] ) : 1;
		$quick_order_id = isset( $form_data['form_id'] ) ? intval( $form_data['form_id'] ) : '';
		$quick_order_fields = wc_product_table()->get_product_table_fields( $quick_order_id );
		$item_key = isset( $form_data['form_key'] ) ? sanitize_text_field( wp_unslash( $form_data['form_key'] ) ) : '';
		$contents = WC()->session->get( 'wc_quick_order_' . $quick_order_id );


		if ( 0 == $quantity || empty( $quantity ) ) {

			unset( $contents[ $item_key ] );

		} else {

			$contents[ $item_key ]['quantity'] = intval( $quantity );
		}

		WC()->session->set( 'wc_quick_order_' . $quick_order_id, array_filter( $contents ) );

		/**
		 * Action quick order on session change
		 * 
		 * @since 1.1.6
		**/
		do_action('wc_quick_order_session_changed');

		wp_send_json(
			array(
				'form_empty'  => empty( WC()->session->get('wc_quick_order_' . $quick_order_id ) ) ? true : false
			)
		);
		die();
	}

	/**
	* Ajax remove item from form.
	*/
	public function wc_quick_order_remove_item() {

		if ( isset( $_POST['nonce'] ) && ! empty( $_POST['nonce'] ) ) {

			$nonce = sanitize_text_field( wp_unslash( $_POST['nonce'] ) );
		} else {
			$nonce = 0;
		}

		if ( ! wp_verify_nonce( $nonce, 'search-products' ) ) {

			die( 'Failed ajax security check!' );
		}

		$form_key = isset( $_POST['form_key'] ) ? sanitize_text_field( wp_unslash( $_POST['form_key'] ) ) : '';
		$quick_order_id = isset( $_POST['form_id'] ) ? intval( $_POST['form_id'] ) : '';
		$quick_order_fields = wc_product_table()->get_product_table_fields( $quick_order_id );

		if ( empty( $form_key ) ) {
			die( 'Form key is empty' );
		}
		//$wc_quick_order = new WC_Quick_Order_Process(array(),$quick_order_id);
		$contents = WC()->session->get( 'wc_quick_order_' . $quick_order_id );
		$product = $contents[ $form_key ]['data'];
		$product_name = '';
		if ( is_object( $product ) ) {
			$product_name = $product->get_name();
		}

		unset( $contents[ $form_key ] );

		WC()->session->set( 'wc_quick_order_' . $quick_order_id, $contents );
		/**
		 * Action quick order on session change
		 * 
		 * @since 1.1.6
		**/
		do_action( 'wc_quick_order_session_changed' );
		/**
		 * Action quick order on item removed
		 * 
		 * @since 1.1.6
		**/
		do_action( 'wc_quick_order_item_removed', $form_key, $product );

		ob_start();
		if ( file_exists( get_stylesheet_directory() . '/woocommerce/bulkorder/templates/quick-order-table.php' ) ) {

			include get_stylesheet_directory() . '/woocommerce/bulkorder/templates/quick-order-table.php';

		} else {

			include WCPT_PLUGIN_FILE . '/templates/quick-order-table.php';
		}
		$form_table = ob_get_clean();

		wp_send_json(
			array(
				'form_empty'  => empty( WC()->session->get('wc_quick_order_' . $quick_order_id ) ) ? true : false,
				'form-table'  => $form_table
			)
		);

		die();
	}

	/**
	 * Ajax Add form to cart controller.
	 */
	public function wc_quick_order_add_to_cart() {
		global $woocommerce;
		if ( isset( $_POST['nonce'] ) && ! empty( $_POST['nonce'] ) ) {
			$nonce = sanitize_text_field( wp_unslash( $_POST['nonce'] ) );
		} else {
			$nonce = 0;
		}

		if ( ! wp_verify_nonce( $nonce, 'search-products' ) ) {
			die( 'Failed ajax security check!' );
		}
		$quick_order_id = isset( $_POST['form_id'] ) ? intval( $_POST['form_id'] ) : '';
		$items = wc()->session->get( 'wc_quick_order_' . $quick_order_id );
		foreach ( $items as $item => $form_data ) {
			$product_id = isset( $form_data['product_id'] ) ? intval( $form_data['product_id'] ) : '';
			$quantity   = isset( $form_data['quantity'] ) ? intval( $form_data['quantity'] ) : 1;
			$variation_id   = isset( $form_data['variation_id'] ) && $product_id !== $form_data['variation_id'] ? intval( $form_data['variation_id'] ) : 0;
			$variation   = isset( $form_data['variation'] ) ? $form_data['variation'] : array();
			/**
			 * Filter quick order validation passed
			 * 
			 * @since 1.1.6
			**/
			$passed_validation = apply_filters( 'wc_quick_order_add_to_cart_validation', true, $product_id, $quantity, $form_data );

			if ( !$passed_validation ) {
				echo 'failed';
				die();
			}
			$product_cart_id = WC()->cart->generate_cart_id( $product_id, $variation_id, $variation );
			$cart_item_key = WC()->cart->find_product_in_cart( $product_cart_id );
			if ( $cart_item_key ) {
				WC()->cart->remove_cart_item( $cart_item_key );
			}
			$cart_item_key = $woocommerce->cart->add_to_cart( $product_id, $quantity, $variation_id, $variation );

			$cart_contents = $woocommerce->cart->get_cart();
			$product        = '';
			$product_name   = 'Product';

			if ( isset( $cart_contents[ $cart_item_key ] ) ) {
				$product = $cart_contents[ $cart_item_key ]['data'];
			}

			if ( is_object( $product ) ) {
				$product_name = $product->get_name();
			}

			if ( false === $cart_item_key ) {

				/* translators: %s: Product name */
				wc_add_notice( sprintf( __( '“%s” has not been added to your cart.', 'woo-product-table' ), $product_name ), 'error' );

			} else {
				unset( $items[ $item ] );
				WC()->session->set( 'wc_quick_order_' . $quick_order_id, $contents );
				/* translators: %s: Product name */
				wc_add_notice( sprintf( __( '“%s” has been added to your cart.', 'woo-product-table' ), $product_name ), 'success' );
			}

		}
		echo 'success';

		die();
	}

	public function wc_quick_order_add() {

		if ( isset( $_POST['nonce'] ) && ! empty( $_POST['nonce'] ) ) {
			$nonce = sanitize_text_field( wp_unslash( $_POST['nonce'] ) );
		} else {
			$nonce = 0;
		}

		if ( ! wp_verify_nonce( $nonce, 'search-products' ) ) {
			die( 'Failed ajax security check!' );
		}

		if ( isset( $_POST ) ) {
			$form_data = sanitize_meta('', wp_unslash( $_POST), '' );
		} else {
			$form_data = '';
		}

		$_POST      = $form_data;
		$product_id = isset( $form_data['product_id'] ) ? intval( $form_data['product_id'] ) : '';
		$quantity   = isset( $form_data['quantity'] ) ? intval( $form_data['quantity'] ) : 1;
		$quick_order_id = isset( $form_data['form_id'] ) ? intval( $form_data['form_id'] ) : '';
		$quick_order_fields = wc_product_table()->get_product_table_fields( $quick_order_id );

		$wc_quick_order = new WC_Quick_Order_Process(array(), $quick_order_id);
		/**
		 * Filter quick order validation passed
		 * 
		 * @since 1.1.6
		**/
		$passed_validation = apply_filters( 'wc_quick_order_form_validation', true, $product_id, $quantity, $form_data );

		if ( !$passed_validation ) {
			echo 'failed';
			die();
		}

		$form_item_key = $wc_quick_order->add_to_form( $form_data, $quick_order_id, $product_id, $quantity );

		$form_contents = wc()->session->get( 'wc_quick_order_' . $quick_order_id );
		$product        = '';
		$product_name   = 'Product';

		if ( isset( $form_contents[ $form_item_key ] ) ) {
			$product = $form_contents[ $form_item_key ]['data'];
		}

		if ( is_object( $product ) ) {
			$product_name = $product->get_name();
		}
		ob_start();

		if ( file_exists( get_stylesheet_directory() . '/woocommerce/bulkorder/templates/quick-order-table.php' ) ) {

			include get_stylesheet_directory() . '/woocommerce/bulkorder/templates/quick-order-table.php';

		} else {

			include WCPT_PLUGIN_FILE . '/templates/quick-order-table.php';
		}
		$form_table = ob_get_clean();
		if ( false === $form_item_key ) {
			/* translators: %s: Product name */
			wc_add_notice( sprintf( __( '“%s” cannot be added.', 'woo-product-table' ), $product_name ), 'error' );
			echo 'success';
		} else {
			wp_send_json(
				array(
					'form_empty'  => empty( WC()->session->get('wc_quick_order_' . $quick_order_id) ) ? true : false,
					'form-table'  => $form_table
				)
			);
		}
		die();
	}

	/**
	 * Enqueue woocommerce product table scripts.
	 */
	public function enqueue_wc_quick_order_scripts() {
		
	}

	/**
	 * Add woocommerce products table shortcode.
	 *
	 * @param array $atts attributes for product table.
	 */
	public function wc_quick_order( $atts ) {
		
		$atts = shortcode_atts(
			array(
				'id' => '',
			),
			$atts
		);
		// get quick order settings with id.
		if ( $atts['id'] && !in_array( get_post_status( $atts['id'] ), array( 'trash', false ) ) ) {
			wp_enqueue_script( 'selectWoo' );

			wp_register_script( 'wc-enhanced-select', WC()->plugin_url() . '/assets/js/admin/wc-enhanced-select.js', array( 'jquery', 'selectWoo' ), WCPT_PLUGIN_VERSION );
			wp_localize_script(
				'wc-enhanced-select',
				'wc_enhanced_select_params',
				array(
					'i18n_no_matches'           => _x( 'No matches found', 'enhanced select', 'woocommerce' ),
					'i18n_ajax_error'           => _x( 'Loading failed', 'enhanced select', 'woocommerce' ),
					'i18n_input_too_short_1'    => _x( 'Please enter 1 or more characters', 'enhanced select', 'woocommerce' ),
					'i18n_input_too_short_n'    => _x( 'Please enter %qty% or more characters', 'enhanced select', 'woocommerce' ),
					'i18n_input_too_long_1'     => _x( 'Please delete 1 character', 'enhanced select', 'woocommerce' ),
					'i18n_input_too_long_n'     => _x( 'Please delete %qty% characters', 'enhanced select', 'woocommerce' ),
					'i18n_selection_too_long_1' => _x( 'You can only select 1 item', 'enhanced select', 'woocommerce' ),
					'i18n_selection_too_long_n' => _x( 'You can only select %qty% items', 'enhanced select', 'woocommerce' ),
					'i18n_load_more'            => _x( 'Loading more results&hellip;', 'enhanced select', 'woocommerce' ),
					'i18n_searching'            => _x( 'Searching&hellip;', 'enhanced select', 'woocommerce' ),
					'ajax_url'                  => admin_url( 'admin-ajax.php' ),
					'search_products_nonce'     => wp_create_nonce( 'search-products' ),
					'search_customers_nonce'    => wp_create_nonce( 'search-customers' ),
					'search_categories_nonce'   => wp_create_nonce( 'search-categories' ),
					'search_pages_nonce'        => wp_create_nonce( 'search-pages' ),
				)
			);
			wp_register_style( 'woocommerce_admin_styles', WC()->plugin_url() . '/assets/css/admin.css', array(), WCPT_PLUGIN_VERSION );

			wp_enqueue_script( 'wc-enhanced-select' );
			wp_enqueue_style('woocommerce_admin_styles');
			$extra_css = '.select2-container .select2-search__field{min-width:auto !important;}.product-quantity .quantity .qty{width:100%}table.wc-quick-order__contents{table-layout:fixed;border-collapse:collapse;width:100%;}table.wc-quick-order__contents tr .product-name{width:200px;}table.wc-quick-order__contents tr .product-remove{width:30px;}#order_actions a.wc_quick_order_add_to_cart{float:right;}#order_actions a.wc_quick_order_add_row{float:left;}table.wc-quick-order__contents td, table.wc-quick-order__contents th{vertical-align:middle;}';
			wp_add_inline_style('woocommerce_admin_styles', $extra_css);
			$quick_order_id       = $atts['id'];
			ob_start();
			if ( file_exists( get_stylesheet_directory() . '/woocommerce/bulkorder/templates/quick-order-page.php' ) ) {

				include get_stylesheet_directory() . '/woocommerce/bulkorder/templates/quick-order-page.php';

			} else {

				include WCPT_PLUGIN_FILE . '/templates/quick-order-page.php';
			}
		}
		return ob_get_clean();
	}
}

new Quick_Order_Shortcode();

<?php
/**
 * Advanced search
 *
 * @package Woocommerce Product Table/metaboxes views
 */

?>
<div class="woocommerce_options_panel">
	<?php
	woocommerce_wp_checkbox(
		array(
			'id'    => 'show_search',
			'name'  => 'show_search',
			'label' => __( 'Search box appears', 'woo-product-table' ),
			'value' => wc_bool_to_string( $show_search ),
		)
	);

	woocommerce_wp_text_input(
		array(
			'id'            => 'filter_product_based_term',
			'name'          => 'filter_product_based_term',
			'wrapper_class' => 'show_search_filter',
			'label'         => __( 'Search Term', 'woo-product-table' ),
			'desc_tip'      => true,
			'description'   => __( 'Filter the products by search term when the table loads', 'woo-product-table' ),
		)
	);


	woocommerce_wp_checkbox(
		array(
			'id'    => 'show_filter',
			'name'  => 'show_filter',
			'label' => __( 'Filter appears', 'woo-product-table' ),
			'value' => wc_bool_to_string( $show_filter ),
		)
	);


	if ( $product_taxonomies ) {
		woocommerce_wp_select(
			array(
				'id'                => 'wcpt_filters_obj',
				'name'              => 'wcpt_filters_obj[]',
				'class'             => 'wcpt-enhanced-select',
				'wrapper_class'     => 'show_filter',
				'label'             => __( 'Add filter dropdown lists above the table', 'woo-product-table' ),
				'options'           => $selected_option,
				'custom_attributes' => array( 'multiple' => 'multiple' ),
			)
		);
	}

	woocommerce_wp_checkbox(
		array(
			'id'            => 'display_reset',
			'name'          => 'display_reset',
			'label'         => __( 'Show the reset link', 'woo-product-table' ),
			'wrapper_class' => 'show_filter',
			'value'         => wc_bool_to_string( $show_reset ),
		)
	);

	woocommerce_wp_select(
		array(
			'id'          => 'wcpt_filters_col',
			'name'        => 'wcpt_filters_col',
			'class'       => 'wcpt-enhanced-select',
			'label'       => __( 'Customizable column filters', 'woo-product-table' ),
			'desc_tip'    => true,
			'description' => __( 'Choose whether clicking on a category, tag or custom taxonomy in the table will perform a filter or load the relevant archive page', 'woo-product-table' ),
			'options'     => array(
				'perform_filter' => __( 'Perform a filter', 'woo-product-table' ),
				'load_archive'   => __( 'Load the relevant archive page', 'woo-product-table' ),
			),
		)
	);
	?>
</div>

<?php
/**
 * Add controls above & below the table
 *
 * @package Woocommerce Product Table/metaboxes views
 */

?>
<div class="woocommerce_options_panel">
	<?php
	woocommerce_wp_checkbox(
		array(
			'id'    => 'display_page_length',
			'name'  => 'display_page_length',
			'label' => __( 'Hide the “Show x products” dropdown list', 'woo-product-table' ),
			'value' => wc_bool_to_string( $show_page_length ),
		)
	);
	woocommerce_wp_checkbox(
		array(
			'id'    => 'display_product_totals',
			'name'  => 'display_product_totals',
			'label' => __( 'Hide the product totals', 'woo-product-table' ),
			'value' => wc_bool_to_string( $show_product_totals ),
		)
	);

	woocommerce_wp_checkbox(
		array(
			'id'          => 'display_pagination',
			'name'        => 'display_pagination',
			'label'       => __( 'Hide the pagination', 'woo-product-table' ),
			'value'       => wc_bool_to_string( $show_pagination ),
			'desc_tip'    => true,
			'description' => __( 'Show paging options that appear below the table when a product table goes onto multiple pages', 'woo-product-table' ),
		)
	);

	woocommerce_wp_select(
		array(
			'label'         => __( 'Pagination display', 'woo-product-table' ),
			'id'            => 'pagingType',
			'name'          => 'pagingType',
			'wrapper_class' => 'pagination-type',
			'class'         => 'wcpt-enhanced-select',
			'options'       => array(
				'numbers'            => __( 'Page number buttons only', 'woo-product-table' ),
				'simple'             => __( "'Previous' and 'Next' buttons only", 'woo-product-table' ),
				'simple_numbers'     => __( "'Previous' and 'Next' buttons, plus page numbers", 'woo-product-table' ),
				'full'               => __( "'First', 'Previous', 'Next' and 'Last' buttons", 'woo-product-table' ),
				'full_numbers'       => __( "'First', 'Previous', 'Next' and 'Last' buttons, plus page numbers", 'woo-product-table' ),
				'first_last_numbers' => __( " 'First' and 'Last' buttons, plus page numbers", 'woo-product-table' ),
			),
		)
	);


	woocommerce_wp_text_input(
		array(
			'id'          => 'wcpt_custom_products_msg',
			'name'        => 'wcpt_custom_products_msg',
			'label'       => __( '"No Products" found message', 'woo-product-table' ),
			'desc_tip'    => true,
			'description' => __( 'Change the text that appears when there are no products in the table', 'woo-product-table' ),
		)
	);

	woocommerce_wp_checkbox(
		array(
			'id'          => 'wcpt_wrap',
			'name'        => 'wcpt_wrap',
			'label'       => __( 'Table Wrap', 'woo-product-table' ),
			'value'       => wc_bool_to_string( $wcpt_wrap ),
			'desc_tip'    => true,
			'description' => __( 'Control whether or not content is wrapped onto multiple lines', 'woo-product-table' ),
		)
	);

	woocommerce_wp_text_input(
		array(
			'id'          => 'wcpt_scroll',
			'name'        => 'wcpt_scroll',
			'label'       => __( 'Scroll Offset', 'woo-product-table' ),
			'type'        => 'number',
			'desc_tip'    => true,
			'description' => __( 'Change the height that the page scrolls to when you move between pages in the product table', 'woo-product-table' ),
		)
	);
	?>
</div>

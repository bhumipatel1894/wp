<?php
/**
 * Footer Options
 *
 * @package Woocommerce Product Table/metaboxes views
 */

?>
<div class="woocommerce_options_panel">
	<?php
	woocommerce_wp_checkbox(
		array(
			'id'    => 'display_table_header',
			'name'  => 'display_table_header',
			'label' => __( 'Show the header row of the table', 'woo-product-table' ),
			'value' => wc_bool_to_string( $header_checked ),
		)
	);


	woocommerce_wp_checkbox(
		array(
			'id'    => 'display_table_footer',
			'name'  => 'display_table_footer',
			'label' => __( 'Show the footer row of the table', 'woo-product-table' ),
			'value' => wc_bool_to_string( $footer_checked ),
		)
	);
	?>
</div>

<?php
/**
 * Control which products appear in the table
 *
 * @package Woocommerce Product Table/metaboxes views
 */

?>
<table class="form-table product-addon-settings">
	<tbody>
		<tr scope="row">
			<th>
				<label for="product_addon_setting"><?php echo esc_html__( 'Addon Display Settings', 'woo-product-table' ); ?></label>
			</th>
			<td>
				<label for="display_product_addon" style="margin-right: 10px;">
					<input id="display_product_addon" type="radio" name="wcpt_addon_display" <?php checked( 'vertical', $display_product_addon ); ?> value="vertical">
					<span class="display_addon"><?php echo esc_html__( 'Vertical', 'woo-product-table' ); ?></span>
				</label>
				<label for="display_product_addon_1">
					<input id="display_product_addon_1" type="radio" name="wcpt_addon_display" <?php checked( 'horizontal', $display_product_addon ); ?> value="horizontal">
					<span class="display_addon"><?php echo esc_html__( 'Horizontal', 'woo-product-table' ); ?></span>
				</label>
			</td>
		</tr>
	</tbody>
</table>

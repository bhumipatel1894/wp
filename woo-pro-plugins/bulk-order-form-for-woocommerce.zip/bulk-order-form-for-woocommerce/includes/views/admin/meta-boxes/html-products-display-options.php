<?php
/**
 * Control which products appear in the table
 *
 * @package Woocommerce Product Table/metaboxes views
 */

?>
<div class="woocommerce_options_panel">
	<?php
	if ( $product_categories ) {
		woocommerce_wp_select(
			array(
				'id'                => 'wcpt_inc_product_cats',
				'name'              => 'wcpt_inc_product_cats[]',
				'class'             => 'wcpt-enhanced-select',
				'label'             => __( 'Included Product categories', 'woo-product-table' ),
				'options'           => $category_options,
				'custom_attributes' => array( 'multiple' => 'multiple' ),
			)
		);
	}

	if ( $product_tags && 'wcpt_quick_order' !== get_post_type($post) ) {
		woocommerce_wp_select(
			array(
				'id'                => 'wcpt_inc_product_tags',
				'name'              => 'wcpt_inc_product_tags[]',
				'class'             => 'wcpt-enhanced-select',
				'label'             => __( 'Included Product Tags', 'woo-product-table' ),
				'options'           => $tag_options,
				'custom_attributes' => array( 'multiple' => 'multiple' ),
			)
		);
	}


	woocommerce_wp_select(
		array(
			'id'      => 'wcpt_product_status',
			'name'    => 'wcpt_product_status',
			'label'   => __( 'Stock Status', 'woo-product-table' ),
			'options' => array(
				''           => __( '--Select Stock Status--', 'woo-product-table' ),
				'instock'    => __( 'In Stock', 'woo-product-table' ),
				'outofstock' => __( 'Out of Stock', 'woo-product-table' ),
			),
		)
	);
	if ( 'wcpt_quick_order' !== get_post_type($post) ) {
		woocommerce_wp_textarea_input(
			array(
				'id'          => 'wcpt_inc_product_ids',
				'name'        => 'wcpt_inc_product_ids',
				'label'       => __( 'Included Products', 'woo-product-table' ),
				'desc_tip'    => true,
				'description' => __( 'Include specific products based on their ID by comma separated', 'woo-product-table' ),
				'value'       => $product_ids ? implode( ',', $product_ids ) : '',
			)
		);

		woocommerce_wp_textarea_input(
			array(
				'id'          => 'wcpt_ex_product_ids',
				'name'        => 'wcpt_ex_product_ids',
				'label'       => __( 'Excluded Products', 'woo-product-table' ),
				'desc_tip'    => true,
				'description' => __( 'Exclude specific products based on their ID by comma separated', 'woo-product-table' ),
				'value'       => $product_exc_ids ? implode( ',', $product_exc_ids ) : '',
			)
		);

		woocommerce_wp_select(
			array(
				'id'                => 'wcpt_ex_product_cats',
				'name'              => 'wcpt_ex_product_cats[]',
				'class'             => 'wcpt-enhanced-select',
				'label'             => __( 'Excluded Product categories', 'woo-product-table' ),
				'options'           => $category_options,
				'custom_attributes' => array( 'multiple' => 'multiple' ),
			)
		);

		woocommerce_wp_select(
			array(
				'id'      => 'wcpt_date_opt',
				'name'    => 'wcpt_date_opt',
				'label'   => __( 'Choose the products before or after date', 'woo-product-table' ),
				'options' => array(
					'before' => __( 'Before the selected date', 'woo-product-table' ),
					'after'  => __( 'After the selected date', 'woo-product-table' ),
				),
			)
		);

		woocommerce_wp_text_input(
			array(
				'id'          => 'wcpt_date',
				'name'        => 'wcpt_date',
				'label'       => __( 'Date', 'woo-product-table' ),
				'class'       => 'wcpt-date-picker',
				'desc_tip'    => true,
				'description' => __( 'Choosing which products appear in the table', 'woo-product-table' ),
			)
		);
	}
	?>
</div>

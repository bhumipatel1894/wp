<?php
/**
 * Sorted Options
 *
 * @package Woocommerce Product Table/metaboxes views
 */

?>
<div class="woocommerce_options_panel">
	<?php
	woocommerce_wp_checkbox(
		array(
			'label'       => __( 'Sorted Column Headings', 'woo-product-table' ),
			'id'          => 'enable_sort_cols',
			'name'        => 'enable_sort_cols',
			'value'       => wc_bool_to_string( $enable_clickable_sort_col ),
			'desc_tip'    => true,
			'description' => __( 'Click on a column heading to sort by that column', 'woo-product-table' ),
		)
	);

	woocommerce_wp_select(
		array(
			'label'             => __( 'Fields Sort By', 'woo-product-table' ),
			'id'                => 'sorted_cols',
			'name'              => 'sorted_cols[]',
			'wrapper_class'     => 'sorting-clickable',
			'class'             => 'wcpt-enhanced-select',
			'options'           => $selected_option,
			'custom_attributes' => array( 'multiple' => 'multiple' ),
		)
	);

	echo '<hr>';

	woocommerce_wp_select(
		array(
			'label'       => __( 'Default Sort By Field', 'woo-product-table' ),
			'id'          => 'default_sorted_col',
			'name'        => 'default_sorted_col',
			'class'       => 'wcpt-enhanced-select',
			'value'       => $default_sorted,
			'options'     => array_merge( array( '' => __( 'Select Default Sort Field', 'woo-product-table' ) ), $fields ),
			'desc_tip'    => true,
			'description' => __( 'Choose which field will be used in by default in sorting', 'woo-product-table' ),
		)
	);

	woocommerce_wp_select(
		array(
			'label'       => __( 'Default Sort Direction', 'woo-product-table' ),
			'id'          => 'default_sorted_dir',
			'name'        => 'default_sorted_dir',
			'class'       => 'wcpt-enhanced-select',
			'options'     => array(
				'asc'  => __( 'Ascending', 'woo-product-table' ),
				'desc' => __( 'Descending', 'woo-product-table' ),
			),
			'desc_tip'    => true,
			'description' => __( 'The sort order option controls the direction in which the table is sorted', 'woo-product-table' ),
		)
	);
	?>
</div>

<?php
/**
 * Responsive Options
 *
 * @package Woocommerce Product Table/metaboxes views
 */

?>
<?php
woocommerce_wp_radio(
	array(
		'id'      => 'display_responsive',
		'name'    => 'display_responsive',
		'label'   => '',
		'class'   => 'wcpt-resp-display',
		'value'   => $responsive_checked,
		'options' => array(
			'fully_resp'      => __( ' 100% responsive ', 'woo-product-table' ),
			'priority_opt'    => __( 'Controls which columns are hidden on screen sizes when there are too many to fit on the page ', 'woo-product-table' ),
			'column_breakpts' => __( 'Choose which columns are shown on different screen sizes and devices', 'woo-product-table' ),
		),
	)
);
?>
<div class="woocommerce_options_panel">
	<?php
	woocommerce_wp_select(
		array(
			'id'                => 'columns_show',
			'name'              => 'columns_show[]',
			'wrapper_class'     => 'wcpt-based-priority',
			'label'             => __( 'Columns to hide', 'woo-product-table' ),
			'class'             => 'wcpt-enhanced-select',
			'options'           => $selected_option,
			'custom_attributes' => array( 'multiple' => 'multiple' ),
		)
	);
	?>
	<div class="column-brk-pts">
			<strong><?php esc_html_e( 'Mobile', 'woo-product-table' ); ?></strong>
		<?php
		woocommerce_wp_checkbox(
			array(
				'id'    => 'mobile_icon_chck',
				'name'  => 'mobile_icon_chck',
				'label' => __( 'Show Icon', 'woo-product-table' ),
				'value' => wc_bool_to_string( $mobile_check ),
			)
		);

		woocommerce_wp_select(
			array(
				'id'                => 'columns_mobile_show',
				'name'              => 'columns_mobile_show[]',
				'label'             => __( 'Columns to show in mobile', 'woo-product-table' ),
				'class'             => 'wcpt-enhanced-select',
				'options'           => $selected_mobile_option,
				'custom_attributes' => array( 'multiple' => 'multiple' ),
			)
		);
		?>
		<strong><?php esc_html_e( 'Tablet', 'woo-product-table' ); ?></strong>
		<?php
		woocommerce_wp_checkbox(
			array(
				'id'    => 'tablet_icon_chck',
				'name'  => 'tablet_icon_chck',
				'label' => __( 'Show Icon', 'woo-product-table' ),
				'value' => wc_bool_to_string( $tablet_check ),
			)
		);


		woocommerce_wp_select(
			array(
				'id'                => 'columns_tablet_show',
				'name'              => 'columns_tablet_show[]',
				'label'             => __( 'Columns to show in tablet', 'woo-product-table' ),
				'class'             => 'wcpt-enhanced-select',
				'options'           => $selected_tablet_option,
				'custom_attributes' => array( 'multiple' => 'multiple' ),
			)
		);
		?>
	</div>
</div>

<?php
/**
 * Customize the table size
 *
 * @package Woocommerce Product Table/metaboxes views
 */

?>
<div class="woocommerce_options_panel">
	<?php
	woocommerce_wp_text_input(
		array(
			'id'          => 'wcpt_rows_page',
			'name'        => 'wcpt_rows_page',
			'label'       => __( 'Rows per page', 'woo-product-table' ),
			'desc_tip'    => true,
			'description' => __( 'Set the number of products on each page of the table', 'woo-product-table' ),
			'type'        => 'number',
		)
	);

	woocommerce_wp_text_input(
		array(
			'id'          => 'wcpt_product_limit',
			'name'        => 'wcpt_product_limit',
			'label'       => __( 'Product limit', 'woo-product-table' ),
			'desc_tip'    => true,
			'description' => __( 'Set maximum number of products that can appear in the table', 'woo-product-table' ),
			'type'        => 'number',
		)
	);
	?>
</div>

<?php
/**
 * Control which products appear in the table
 *
 * @package Woocommerce Product Table/metaboxes views
 */

?>
<table class="form-table wholesale-settings">
	<tbody>
		<tr scope="row">
			<th>
				<label for="wholesale_settings"><?php echo esc_html__( 'Wholesale Only', 'woo-product-table' ); ?></label>
			</th>
			<td>
				<label for="display_wholesale_only" class="switch">
					<input id="display_wholesale_only" type="checkbox" value="yes" name="display_wholesale_only" <?php checked( 'yes', $display_wholesale_only ); ?>>
					<span class="slider round"></span>
				</label>
				<span class="description"><?php echo esc_html__( 'Enable to display order form to wholesalers only.', 'woo-product-table' ); ?></span>
			</td>
		</tr>
		<tr scope="row">
			<th>
				<label for="wholesale-settings"><?php echo esc_html__( 'Select Roles', 'woo-product-table' ); ?></label>
			</th>
			<td>
				<?php
				if ( $user_roles ) {
					woocommerce_wp_select(
						array(
							'id'                => 'wcpt_wholesale_selected_roles',
							'name'              => 'wcpt_wholesale_selected_roles[]',
							'class'             => 'wcpt-enhanced-select',
							'label'             => '',
							'options'           => $user_roles,
							'custom_attributes' => array( 'multiple' => 'multiple' ),
						)
					);
				}
				?>
			</td>
		</tr>
	</tbody>
</table>

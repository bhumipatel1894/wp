<?php
/**
 * List attributes for each field
 *
 * @package Woocommerce Product Table/Template
 */

$taxonomies = get_object_taxonomies( 'product', 'objects' );

?>
<form>

	<div class="woo-product-table-field-options">
			<label style="padding:4px; display: block;"><?php esc_html_e( 'Column name', 'woo-product-table' ); ?></label>
		<div class="clear"></div>
		<input type="text" class="woo_column_name" value=""/>
		<?php if ( 'wcpt_quick_order' !== $post->post_type ) : ?>
		<div class="woo-column-width all-fields-options" style="display:block;">
			<div class="d-flex">
				<label style="padding:4px; display: block;"><?php esc_html_e( 'Column Width', 'woo-product-table' ); ?></label>
				<input type="text" class="woo_column_width" value=""/>
				<select name="woo_column_width_type">
					<option value="percent"><?php esc_html_e( '%', 'woo-product-table' ); ?></option>
					<option value="px"><?php esc_html_e( 'px', 'woo-product-table' ); ?></option>
				</select>
			</div>
		</div>
		<?php endif; ?>
		<div class="woo-title-img-link all-fields-options">
					<label style="padding:4px;"><?php esc_html_e( 'Linkable', 'woo-product-table' ); ?></label>
			<select name="woo_column_linkable">
				<option value="" ><?php esc_html_e( 'No', 'woo-product-table' ); ?></option>
				<option value="true"><?php esc_html_e( 'Yes', 'woo-product-table' ); ?></option>
			</select>
		</div>
		<div class="woo-short-descr all-fields-options" >
			<label style="padding:4px; "><?php esc_html_e( 'Set the length of product description', 'woo-product-table' ); ?></label>
			<input type="text" class="woo_column_descr" value=""/>
		</div>

		<div class="woo-date-format all-fields-options">
			<label style="padding:4px;"><?php esc_html_e( 'Date Format', 'woo-product-table' ); ?></label>
			<select name="woo_column_date_format">
				<option value=""><?php esc_html_e( '--Select Date Format--', 'woo-product-table' ); ?></option>
								<option value="F j,Y"><?php echo esc_html( gmdate( 'F j, Y' ) ); ?></option>
								<option value="Y-m-d"><?php echo esc_html( gmdate( 'Y-m-d' ) ); ?></option>
				<option value='m/d/Y'><?php echo esc_html( gmdate( 'm/d/Y' ) . __( ' Month/Day/Year', 'woo-product-table' ) ); ?></option>
				<option value='d/m/Y'><?php echo esc_html( gmdate( 'd/m/Y' ) . __( ' Day/Month/Year', 'woo-product-table' ) ); ?></option>
			</select>
		</div>


		<div class="woo-add-cart-options all-fields-options">
			<label style="padding:4px;"><?php esc_html_e( 'Add to cart button Types', 'woo-product-table' ); ?></label>
			<select name="woo_column_add_types" id="cart-types">
				<option value="add_button"><?php esc_html_e( 'Add to cart button', 'woo-product-table' ); ?></option>
				<option value="add_checkbox"><?php esc_html_e( 'Multi-Select check-boxes', 'woo-product-table' ); ?></option>
				<option value="add_button_checkbox"><?php esc_html_e( 'both button and checkbox', 'woo-product-table' ); ?></option>
			</select>   

			<div class="cart_position">
				<label style="padding:4px;"><?php esc_html_e( 'Add Selected to Cart button Position', 'woo-product-table' ); ?></label>
				<select name="woo_column_add_selected_cart">
					<option value="above_add"><?php esc_html_e( 'above the product table', 'woo-product-table' ); ?></option>
										<option value="below_add"><?php esc_html_e( 'below the product table', 'woo-product-table' ); ?></option>
					<option value="both_add"><?php esc_html_e( 'both', 'woo-product-table' ); ?></option>
				</select> 
			</div> 

			<label style="padding:4px;"><?php esc_html_e( 'Show Quantity', 'woo-product-table' ); ?></label>
			<select name="woo_column_quantity">
				<option value="true"><?php esc_html_e( 'Yes', 'woo-product-table' ); ?></option>
				<option value="false"><?php esc_html_e( 'No', 'woo-product-table' ); ?></option>
			</select>  
		</div>

		<div class="woo-attr-options all-fields-options">
			<label style="padding:4px; display: block;"><?php esc_html_e( 'Attribute Name', 'woo-product-table' ); ?></label>
			<input type="text" class="woo_column_attrs" value=""/>
		</div>

		<div class="woo-custom-fields-options all-fields-options">
			<label style="padding:4px; display: block;"><?php esc_html_e( 'Custom Field Key', 'woo-product-table' ); ?></label>
			<input type="text" class="woo_column_custom_keys" value=""/>
		</div>


		<div class="woo-tax-options all-fields-options">
			<label style="padding:4px;"><?php esc_html_e( 'Taxonomy', 'woo-product-table' ); ?></label>
			<input type="text" class="woo_column_taxonomy" value=""/>
		</div>

	</div>
</form>

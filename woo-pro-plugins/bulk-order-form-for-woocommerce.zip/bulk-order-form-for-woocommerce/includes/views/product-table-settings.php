<?php
/**
 * Settings for product table
 *
 * @package Woocommerce Product Table/Views
 */
?>
<div class="wcpt-sections">
	<section class="wcpt-section columns">
			<h3><?php esc_html_e( 'Columns', 'woo-product-table' ); ?></h3>
		<ul class="wcpt-columns-draggable">
			<?php if ( $mapping_labels ) { ?>
				<?php foreach ( $mapping_labels as $label_type => $mapping_label ) { ?>
					<li class="ui-state-default" data-type="<?php echo esc_attr( $label_type ); ?>" data-def-name="<?php echo esc_attr( $mapping_label ); ?>"><span class="label-title"><?php echo esc_attr( $mapping_label ); ?></span></li>
				<?php } ?>
			<?php } ?>
		</ul>

		<div id="custom-hidden-fields">
			<?php foreach ( $names as $n => $name ) { ?>
				<input type="hidden" data-opt="<?php echo esc_attr( $n ); ?>" name="<?php echo esc_attr( $name ); ?>[]" />
			<?php } ?>
		</div>
		<ul class="wcpt-columns-sortable">
			<?php if ( $table_fields ) { ?>
				<?php
				foreach ( $table_fields as $i => $field ) {
					?>
					<li class="ui-state-default wcpt-saved-columns" data-type="<?php echo esc_attr( $field['woo_ids'] ); ?>" data-def-name="<?php echo esc_attr( $field['woo_label'] ); ?>"><span class="label-title"><?php echo $field['woo_label'] ? esc_html( $field['woo_label'] ) : esc_html( $mapping_labels[ $field['woo_ids'] ] ); ?></span>
						<div id="custom-hidden-fields">
							<?php
							foreach ( $field as $key => $value ) {
								?>
								<input type="hidden" data-opt="<?php echo esc_attr( array_search( $key, $names, true ) ); ?>" name="<?php echo esc_attr( $key ); ?>[]" value="<?php echo esc_attr( $value ); ?>"/>
								<?php
							}
							?>
						</div>
					</li>
					<?php
				}
				?>
				<?php
			}
			?>
		</ul>
	</section>

	<div id="dialog" class="woo-setings-dialog">
		<?php
		require_once 'admin/template/product-table-view-custom-settings.php';
		?>
	</div>


</div>





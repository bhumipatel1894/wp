<?php
/**
 * Add to Cart for external product
 *
 * @package  WooCommerce Product Table/Templates
 */

?>
<div class="product-cart-chechbox-wrapper simple-product-add-cart <?php echo esc_attr( $classes ); ?>">
	<div class="product-cart-wrapper">
		<a href="<?php echo esc_url( $product->add_to_cart_url() ); ?>" class="button product_type_external alt" aria-label="<?php echo esc_attr( get_the_title( $product->get_id() ) ); ?>" rel="nofollow"><?php echo esc_html( $product->single_add_to_cart_text() ); ?></a>
	</div>
</div>

<?php
/**
 * Product Table Attributes Field
 *
 * @package  WooCommerce Product Table/Templates
 */

?>
<span><?php echo esc_html( $product_attributes ); ?></span>

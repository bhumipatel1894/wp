<?php
/**
 * Product Table Categories Field
 *
 * @package  WooCommerce Product Table/Templates
 */

?>

<span><?php echo esc_html( $product_categories ); ?></span>

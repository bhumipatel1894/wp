<?php
/**
 * Product Table Custom Taxonomy Field
 *
 * @package  WooCommerce Product Table/Templates
 */

?>

<span><?php echo esc_html( $product_custom_tax_terms ); ?></span>

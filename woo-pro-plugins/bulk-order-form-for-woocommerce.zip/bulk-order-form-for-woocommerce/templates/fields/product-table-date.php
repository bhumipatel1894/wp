<?php
/**
 * Product Table Date Field
 *
 * @package  WooCommerce Product Table/Templates
 */

?>
<span><?php echo esc_html( gmdate( $product_date_format, strtotime( $product_date ) ) ); ?></span>

<?php
/**
 * Product Table Description Field
 *
 * @package  WooCommerce Product Table/Templates
 */

?>
<span>
	<?php
	
	if ( 'yes' === $shortocode_html_formatting ) {
		/**
		 * Filter product description content
		 * 
		 * @since 1.1.6
		**/
		echo wp_kses_post(apply_filters( 'the_content', $product_description )); 
	} else {
		echo wp_kses_post($product_description); 
	}
	
	?>
</span>

<?php
/**
 * Product Table Dimensions Field
 *
 * @package  WooCommerce Product Table/Templates
 */

?>

<span><?php echo esc_html( $product_dimensions ); ?></span> 

<?php
/**
 * Product Table ID Field
 *
 * @package  WooCommerce Product Table/Templates
 */

?>
<span><?php echo esc_html( $product_id ); ?></span>

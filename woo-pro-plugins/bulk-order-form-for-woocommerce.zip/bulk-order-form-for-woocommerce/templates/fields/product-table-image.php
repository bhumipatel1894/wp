<?php
/**
 * Product Table Image Field
 *
 * @package  WooCommerce Product Table/Templates
 */

?>

<?php
if ( 'true' === $product_linkable ) {
	?>
<a href="<?php echo esc_url( $product_url ); ?>"><?php echo wp_kses_post($product_image); ?></a>
	<?php
} else {
	echo wp_kses_post($product_image);
}

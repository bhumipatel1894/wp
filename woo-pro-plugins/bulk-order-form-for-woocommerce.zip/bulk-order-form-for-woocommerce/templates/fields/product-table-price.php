<?php
/**
 * Product Table Price Field
 *
 * @package  WooCommerce Product Table/Templates
 */

?>

<span><?php echo wp_kses_post($product_price); ?></span>
<span class="wcpt_v_p price_<?php echo wp_kses_post($product_id); ?>"></span>

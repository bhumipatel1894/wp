<?php
/**
 * Product Table Reviews Field
 *
 * @package  WooCommerce Product Table/Templates
 */

?>

<span><?php echo wp_kses_post( wc_get_rating_html( $product_reviews ) ); ?></span>

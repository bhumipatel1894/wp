<?php
/**
 * Product Table Stock Status Field
 *
 * @package  WooCommerce Product Table/Templates
 */

if ( ! $product->is_in_stock() ) {
	$class = 'out-of-stock';
} elseif ( ( $product->managing_stock() && $product->is_on_backorder( 1 ) ) || ( ! $product->managing_stock() && $product->is_on_backorder( 1 ) ) ) {
	$class = 'available-on-backorder';
} else {
	$class = 'in-stock';
}
?>
<span class="stock_<?php echo esc_attr( $product->get_id() ); ?>" data-stock='<span class="stock <?php echo esc_attr( $class ); ?>">
		<?php echo esc_html( $product_stock_status ); ?>
	</span>'>
	<span class="stock <?php echo esc_attr( $class ); ?>">
		<?php echo esc_html( $product_stock_status ); ?>
	</span>
</span>

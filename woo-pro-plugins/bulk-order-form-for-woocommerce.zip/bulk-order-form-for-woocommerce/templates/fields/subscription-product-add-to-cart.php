<?php
/**
 * Add to Cart for subscription product
 *
 * @package  WooCommerce Product Table/Templates
 */

?>
<div class="product-cart-chechbox-wrapper simple-product-add-cart <?php echo esc_attr( $classes ); ?>">
	<?php if ( $product->is_in_stock() ) { ?>
		<div class="product-cart-wrapper"> 
			<form class="cart" action="
			<?php 
			/**
			 * Filter woocommerce form action
			 * 
			 * @since 1.1.6
			**/
			echo esc_url( apply_filters( 'woocommerce_add_to_cart_form_action', $product->get_permalink() ) ); 
			?>
			" method="post" enctype='multipart/form-data'>
			<?php
			if ( ! isset( $_POST['nonce'] ) ) {
				return;
			}
			if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'ajax-nonce' ) ) {
				return;
			}
			woocommerce_quantity_input(
				array(
						/**
						 * Filter woocommerce min quantity
						 * 
						 * @since 1.1.6
						**/
						'min_value'   => apply_filters( 'woocommerce_quantity_input_min', $product->get_min_purchase_quantity(), $product ),
						/**
						 * Filter woocommerce reset variation link
						 * 
						 * @since 1.1.6
						**/
						'max_value'   => apply_filters( 'woocommerce_quantity_input_max', $product->get_max_purchase_quantity(), $product ),
						'input_value' => isset( $_POST['quantity'] ) ? wc_stock_amount( wp_unslash( $_POST['quantity'] ) ) : $product->get_min_purchase_quantity(),
					)
			);
			?>

			<button type="submit" class="single_add_to_cart_button button alt" name="add-to-cart" value="<?php echo absint( $product->get_id() ); ?>"><?php echo esc_html( $product->single_add_to_cart_text() ); ?></button>

		</form>
		<?php
		if ( 'add_button' !== $cart_button_type ) {
			?>
			<input type="checkbox" class="product-cart-chechbox" name="product_ids[]" value="<?php echo absint( $product->get_id() ); ?>">
			<?php
		}
		?>
	</div>
		<?php
	} else {
		esc_html_e( 'Out of Stock', 'woo-product-table' );
	}
	?>
</div>

<?php
/**
 * Product Table Filters
 *
 * @package  WooCommerce Product Table/Templates
 */

?>
<div class="wc-product-table-select-filters" id="select-filter-<?php echo esc_attr( $id ); ?>" data-col-filter="<?php echo esc_attr( $col_filters ); ?>">
	<?php
	if ( $filter_terms ) {
		?>
		<div class="wc-product-table-select-filter">
			<label><?php esc_html_e( 'Filters', 'woo-product-table' ); ?></label>
			<div class="wc-product-table-select">
				<?php
				$product_table_link = '';
				foreach ( $filter_terms as $i => $filter_term ) {
					if ( get_terms( $filter_term ) ) {
						$product_table_taxonomy = get_taxonomy( $filter_term );
						?>
						<select name="wcpt_filter_<?php echo esc_attr( $filter_term ); ?>" id="<?php echo esc_attr( $filter_term ); ?>" class="filter-attr" data-filter-link="<?php echo esc_html( taxonomy_is_product_attribute( $product_table_taxonomy->name ) ); ?>">
							<option value=""><?php echo esc_html( $product_table_taxonomy->label ); ?></option>
							<?php
							foreach ( get_terms( $filter_term ) as $term_value ) {
								if ( false === taxonomy_is_product_attribute( $product_table_taxonomy->name ) ) {
									$product_table_link = get_term_link( $term_value->term_id, $taxonomy->name );
								}
								?>
								<option value="<?php echo esc_attr( $term_value->term_id ); ?>" data-tax-link="<?php echo esc_attr( $product_table_link ); ?>" ><?php echo esc_html( $term_value->name ); ?></option>
								<?php
							}
							?>
						</select>
						<?php
					}
				}
				?>
			</div>
		</div>
		<?php if ( $reset_button ) { ?>
			<a href="#" class="reset-filters"><?php esc_html_e( 'Reset', 'woo-product-table' ); ?></a>
			<?php
		}
	}
	?>
</div>

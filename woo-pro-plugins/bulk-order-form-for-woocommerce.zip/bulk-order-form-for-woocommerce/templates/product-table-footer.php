<?php
/**
 * Product Table Footer
 * This template can be overridden by copying it to yourtheme/wc_product_table/product-table-footer.php.
 *
 * @package  WooCommerce Product Table/Templates
 */

if ( $product_table_headings ) {
	?>
	<tfoot>
		<tr>
			<?php
			foreach ( $product_table_headings as $product_table_heading ) {
				?>
			<th data-name="<?php echo esc_attr( $product_table_heading['type'] ); ?>"><?php echo esc_attr( $product_table_heading['label'] ); ?></th>
				<?php
			}
			?>
		</tr>
	</tfoot>
	<?php
}


<?php
/**
 * Product Table Header
 *
 * This template can be overridden by copying it to yourtheme/wc_product_table/product-table-header.php.
 *
 * @package  WooCommerce Product Table/Templates
 */

$device_class         = '';
$data_hidden_priority = 10001;

if ( $product_table_headings ) {
	?>
	<thead <?php echo ( ! $product_table_header ) ? 'style="visibility:hidden"' : ''; ?> data-sort_col="<?php echo esc_attr( $default_sorted_col ); ?>" data-sort_dir="<?php echo esc_attr( $default_sorted_dir ); ?>">
		<tr>
			<?php
			foreach ( $product_table_headings as $key => $product_table_heading ) {
				$data_piriority = $key;

				if ( ! empty( $responsive_options['hidden_col_mobile_ids'] ) && $responsive_options['hidden_col_mobile_ids'] && is_array( $responsive_options['hidden_col_mobile_ids'] ) && in_array( $key, $responsive_options['hidden_col_mobile_ids'], true ) ) {
					$device_class = 'min-phone-l custom-hidden';
				}
				if ( ! empty( $responsive_options['hidden_col_tablet_ids'] ) && is_array( $responsive_options['hidden_col_tablet'] ) && in_array( $key, $responsive_options['hidden_col_tablet_ids'], true ) ) {
					$device_class = 'min-tablet custom-hidden';
				}
				if ( ! empty( $responsive_options['hidden_col_ids'] ) && is_array( $responsive_options['hidden_col_ids'] ) && in_array( $key, array_values( $responsive_options['hidden_col_ids'] ), true ) ) {
					$device_class   = '';
					$data_piriority = $data_hidden_priority--;
				}
				$sort_col       = $product_table_heading['type'] . '_' . $key;
				$header_classes = ( ! $sorted_cols || ! in_array( $sort_col, $sorted_cols, true ) ) ? $device_class . ' no-sort' : $device_class;
				?>
				<th class="<?php echo esc_attr( $header_classes ); ?>" data-name="<?php echo esc_attr( $product_table_heading['type'] ); ?>" data-width="<?php echo ( isset( $product_table_heading['width'] ) ) ? esc_attr( $product_table_heading['width'] ) : ''; ?>" data-priority="<?php echo esc_attr( $data_piriority ); ?>">
					<?php echo esc_attr( $product_table_heading['label'] ); ?>
				</th>
				<?php
			}
			?>
		</tr>
	</thead>
	<?php
}
if ( $no_products_msg ) {
	?>
	<input  class="wcpt-no-product-message" type="hidden" value="<?php echo esc_attr( $no_products_msg ); ?>">
	<?php
}




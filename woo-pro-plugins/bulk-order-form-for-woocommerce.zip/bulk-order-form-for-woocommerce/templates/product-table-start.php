<?php
/**
 * Product Table Start
 * This template can be overridden by copying it to yourtheme/wc_product_table/product-table-start.php.
 *
 * @package  WooCommerce Product Table/Templates
 */

?>
<table class="product-table display responsive <?php echo esc_attr( $wcpt_wrap ); ?>" data-id="<?php echo esc_attr( $id ); ?>" <?php echo wp_kses_post($responsive_options['data_attr']); ?> style="width:100%"  data-rows="<?php echo esc_attr( $rows_per_page ); ?>" data-search="<?php echo esc_attr( $search ); ?>" data-filter="<?php echo esc_attr( $filters ) ? true : false; ?>" data-scroll-offset="<?php echo esc_attr( $wcpt_scroll ); ?>" data-paging-type="<?php echo esc_attr( $paging_type ); ?>" data-display-pagination="<?php echo esc_attr( $display_pagination ); ?>" data-display-product-totals="<?php echo esc_attr( $display_product_totals ); ?>" data-display-page-length="<?php echo esc_attr( $display_page_length ); ?>">


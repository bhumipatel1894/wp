<?php
/**
 * Product Table Wrap End
 * This template can be overridden by copying it to yourtheme/wc_product_table/product-table-wrap-end.php.
 *
 * @package  WooCommerce Product Table/Templates
 */

?>
</div>
</div>

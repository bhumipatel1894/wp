<?php
/**
 * Product Table Wrap Start
 * This template can be overridden by copying it to yourtheme/wc_product_table/product-table-wrap-start.php.
 *
 * @package  WooCommerce Product Table/Templates
 */

?>
<div id="ptholder">
	<div class="product-table-wrap single single-product">
		<div class="product-table-loader">
			<span class="spinner-loader"></span>
		</div>

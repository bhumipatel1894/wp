<?php $quick_order_fields = wc_product_table()->get_product_table_fields( $quick_order_id ); 
//WC()->session->set( 'wc_quick_order_' . $quick_order_id, '' );
?>
<div class="woocommerce">
	<div class="woocommerce-notices-wrapper">
	</div>
	<form class="woocommerce-cart-form wc-quick-order-form" method="post" enctype="multipart/form-data">
		<?php 
		$cat_ids     = get_post_meta( $quick_order_id, 'wcpt_inc_product_cats', true );
		$stock_status       = get_post_meta( $quick_order_id, 'wcpt_product_status', true );
		$meta_product_query = array();
		$tax_product_query = array();
		$product_ids = array();
		if ( $stock_status ) {
			$meta_product_query = array(
				array(
					'key'   => '_stock_status',
					'value' => $stock_status,
				)
			);
		}
		if ( $cat_ids ) {
			$tax_product_query = array(
				array(
					'taxonomy' => 'product_cat',
					'field' => 'term_id',
					'terms' => $cat_ids,
					'operator' => 'IN',
				)
			);
		}

		$all_ids = get_posts( array(
			'post_type' => array( 'product' ),
			'posts_per_page' => -1,
			'post_status' => 'publish',
			'fields' => 'ids',
			'tax_query' => $tax_product_query,
			'meta_query' => $meta_product_query
		) );
		
		foreach ( $all_ids as $product_id ) {
			$product = wc_get_product($product_id);
			if ( $product->get_type() === 'variable'  ) {
				$variations = $product->get_available_variations();
				$variations_id= wp_list_pluck( $variations, 'variation_id' );
				$product_ids= array_merge($product_ids, $variations_id);

			} else {
				$product_ids[]= $product_id;
			}
		}
		$product_ids = implode(',', $product_ids);
		?>
		<script type="text/javascript">
			jQuery(document).ready(function(){
				var currentRequest = null;
				function selectionSearch (){
					jQuery(document).on('select2:select','.wc-product-search', function (e) {
						var product = e.params.data;
						var quantity = 1;
						var update = jQuery(this).data('update');
						if ( update ) {
							var action_name = 'wc_quick_order_update';
							var form_key = jQuery(this).data('cart_item_key');
							var quantity = jQuery('input[name="order_qty['+form_key+']"]').val();
						}
						else{
							var action_name = 'wc_quick_order_add';
							var form_key = '';
						}
						jQuery.ajax({

							url: wc_enhanced_select_params.ajax_url,
							type: 'POST',
							dataType: 'JSON',
							data: {
								action: action_name,
								product_id: product.id,
								form_id: <?php echo esc_attr($quick_order_id); ?>,
								quantity: quantity,
								form_key: form_key,
								nonce: wc_enhanced_select_params.search_products_nonce
							},

							success: function (response) {



								if( response['form_empty'] ){
									location.reload();
								}

								jQuery('table.wc-quick-order__contents').replaceWith( response['form-table'] );
								initSearch();
								jQuery('body').animate({
									scrollTop: jQuery('div.woocommerce-notices-wrapper').offset().top,
								}, 500
								);

							},

							error: function (response) {

							}
						});
					});
				}
				function initSearch(){
					var select2_args = {
						allowClear:  jQuery( '.wc-product-search' ).data( 'allow_clear' ) ? true : false,
						placeholder: jQuery( '.wc-product-search' ).data( 'placeholder' ),
						minimumInputLength: jQuery( '.wc-product-search' ).data( 'minimum_input_length' ) ? jQuery( '.wc-product-search' ).data( 'minimum_input_length' ) : '3',
						escapeMarkup: function( m ) {
							return m;
						},
						ajax: {
							url:         wc_enhanced_select_params.ajax_url,
							dataType:    'json',
							delay:       250,
							data:        function( params ) {
								return {
									term         : params.term,
									action       : jQuery( '.wc-product-search' ).data( 'action' ) || 'woocommerce_json_search_products_and_variations',
									security     : wc_enhanced_select_params.search_products_nonce,
									exclude      : jQuery( '.wc-product-search' ).data( 'exclude' ),
									exclude_type : jQuery( '.wc-product-search' ).data( 'exclude_type' ),
									include      : jQuery( '.wc-product-search' ).data( 'include' ),
									limit        : jQuery( '.wc-product-search' ).data( 'limit' ),
									display_stock: jQuery( '.wc-product-search' ).data( 'display_stock' )
								};
							},
							processResults: function( data ) {
								var terms = [];
								if ( data ) {
									jQuery.each( data, function( id, text ) {
										terms.push( { id: id, text: text } );
									});
								}
								return {
									results: terms
								};
							},
							cache: true
						}
					};
					jQuery('.wc-product-search').selectWoo(select2_args);
				}
				selectionSearch();
				jQuery(document).on('click', '.wc_quick_order_add_row', function(){
					jQuery('.wc-quick-order__contents tbody').append('<tr><td class="product-remove"><a href="javascript:void(0)" class="remove remove-cart-item remove-row" >&times;</a></td><td class="product-name" data-title="<?php esc_attr_e( 'Product', 'woo-product-table' ); ?>"><select style="width:100%" class="wc-product-search" data-placeholder="<?php esc_attr_e( 'Search for a product&hellip;', 'woocommerce' ); ?>" data-action="woocommerce_json_search_products_and_variations" data-include="[<?php echo esc_attr( $product_ids ); ?>]" data-exclude_type="variable"></td>' + 
						<?php foreach ($quick_order_fields as $key => $value) : ?>
							'<td class="product-<?php esc_html_e( $value['woo_ids'] ); ?>"></td>' +
							<?php endforeach; ?>
							'<td class="product-quantity"></td></tr>');
					jQuery(document).on('click', 'a.remove-row', function(e){
						jQuery(this).closest('tr').remove();
					});
					initSearch();
				}); 

				jQuery(document).on('click', '.wc-order-remove-item', function (event) {
					event.preventDefault();
					if( jQuery(this).closest('tr').css('opacity') == 0.5 ){
						return;
					}
					jQuery(this).closest('tr').css('opacity', '0.5' );


					jQuery.ajax({
						url: wc_enhanced_select_params.ajax_url,
						type: 'POST',
						data: {
							action: 'wc_quick_order_remove_item',
							form_key: jQuery(this).data('cart_item_key'),
							form_id: <?php echo esc_attr($quick_order_id); ?>,
							nonce: wc_enhanced_select_params.search_products_nonce
						},
						success: function (response) {

							if( response['form_empty'] ){
								location.reload();
							}
							jQuery('table.wc-quick-order__contents').replaceWith( response['form-table'] );
							initSearch();
							jQuery('body').animate({
								scrollTop: jQuery('div.woocommerce-notices-wrapper').offset().top,
							}, 500
							);
						}
					});
				});
				jQuery(document).on('click', 'a.wc_quick_order_add_to_cart', function () {

					var redirect_url = jQuery(this).attr('data-url');
					var current_button = jQuery(this);
					if ( current_button.hasClass('loading') ) {
						return;
					}
					current_button.addClass('loading');
					jQuery.ajax({
						url: wc_enhanced_select_params.ajax_url,
						type: 'POST',
						data: {
							action: 'wc_quick_order_add_to_cart',
							form_id: <?php echo esc_attr($quick_order_id); ?>,
							nonce: wc_enhanced_select_params.search_products_nonce
						},
						success: function (response) {

							if ( 'success' == jQuery.trim(response) ) {

								window.location.href = redirect_url;

							} else if( 'failed' == jQuery.trim(response) ){

								location.reload();
								
							} else {

								current_button.removeClass('loading');

							}	
						}
					});

					return false;
				});

				jQuery(document).on('input', '.wc-quick-order__contents tbody tr .quantity .qty', function () {
					if( jQuery('a.wc_quick_order_add_to_cart').hasClass('loading') ){
						return;
					}
					jQuery('a.wc_quick_order_add_to_cart').addClass('loading');
					var form_key = jQuery(this).attr('name');
					var quantity = jQuery(this).val();
					form_key = form_key.replace('order_qty[', '').replace(']','');
					jQuery.ajax({
						url: wc_enhanced_select_params.ajax_url,
						type: 'POST',
						dataType: 'JSON',
						delay: 250,
						data: {
							action: 'wc_quick_order_update_items',
							form_id: <?php echo esc_attr($quick_order_id); ?>,
							form_key: form_key,
							quantity: quantity,
							nonce: wc_enhanced_select_params.search_products_nonce
						},
						success: function (response) {
							if( response['form_empty'] ){
								location.reload();
							}
							jQuery('a.wc_quick_order_add_to_cart').removeClass('loading');
						}
					});
				});

			});

		</script>
		<?php
		if ( isset( WC()->session ) && ! empty( WC()->session->get( 'wc_quick_order_' . $quick_order_id ) ) ) :
			if ( file_exists( get_stylesheet_directory() . '/woocommerce/bulkorder/templates/quick-order-table.php' ) ) {

				include get_stylesheet_directory() . '/woocommerce/bulkorder/templates/quick-order-table.php';

			} else {

				include WCPT_PLUGIN_FILE . '/templates/quick-order-table.php';
			}
			?>
		<?php else : ?>
			<table class="wc-quick-order__contents" cellspacing="0">
				<thead>
					<tr>
						<th class="product-remove"></th>
						<th class="product-name"><?php esc_html_e( 'Product', 'woo-product-table' ); ?></th>
						<?php foreach ($quick_order_fields as $key => $value) : ?>
							<th class="product-<?php esc_html_e( $value['woo_ids'] ); ?>"><?php esc_html_e( $value['woo_label'] ); ?></th>
						<?php endforeach; ?>
						<th class="product-quantity"><?php esc_html_e( 'Quantity', 'woo-product-table' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<tr class="woocommerce-cart-form__order-item">
						<td class="product-remove"></td>
						<td class="product-name" data-title="<?php esc_attr_e( 'Product', 'woo-product-table' ); ?>">
							<select style="width:100%" class="wc-product-search" data-placeholder="<?php esc_attr_e( 'Search for a product&hellip;', 'woocommerce' ); ?>" data-action="woocommerce_json_search_products_and_variations" data-include="[<?php echo esc_attr( $product_ids ); ?>]" data-exclude_type="variable"></select>
						</td>
						<?php foreach ($quick_order_fields as $key => $value) : ?>
							<td class="product-<?php esc_html_e( $value['woo_ids'] ); ?>"></td>
						<?php endforeach; ?>
						<td class="product-quantity"></td>
					</tr>
				</tbody>
			</table>		
		<?php endif; ?>

		<div class="order-collapse">
			<div id="order_actions" class="action-btn">

				<?php 
				/**
				 * Action before quick order actions
				 * 
				 * @since 1.1.6
				**/
				do_action( 'quick_order_before_actions' ); 
				?>
				<div class="wc-proceed-to-checkout form_row">

					<a href="javascript:void(0)" class="button alt wc_quick_order_add_row"><?php echo esc_attr( 'Add Another Row' ); ?></a>

					<a href="javascript:void(0)" class="button alt wc_quick_order_add_to_cart wc-forward" data-url="<?php echo esc_url( wc_get_cart_url() ); ?>"><?php echo esc_attr( 'Add To Cart' ); ?></a>
				</div>
			</div>
		</div>

		<?php 
		/**
		 * Action after quick order actions
		 * 
		 * @since 1.1.6
		**/
		do_action( 'quick_order_after_actions' ); 
		?>

	</form>
</div>

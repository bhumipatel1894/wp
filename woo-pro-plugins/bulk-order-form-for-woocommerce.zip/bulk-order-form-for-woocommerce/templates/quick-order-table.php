<?php
/**
 * Order Details table for request a order page.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/wcorder/front/order-table.php.
 *
 */

defined( 'ABSPATH' ) || exit;

if ( ! isset( $wc_quick_order ) ) {
	$wc_quick_order = new WC_Quick_Order_Process(array(), $quick_order_id);
}

$colspan          = 4;
/**
 * Action before quick order table
 * 
 * @since 1.1.6
 **/
do_action( 'quick_order_before_table' ); ?>

<table class="wc-quick-order__contents" cellspacing="0">
	<thead>
		<tr>
			<th class="product-remove"></th>
			<th class="product-name"><?php esc_html_e( 'Product', 'woo-product-table' ); ?></th>
			<?php foreach ($quick_order_fields as $key => $value) : ?>
				<th class="product-<?php esc_html_e( $value['woo_ids'] ); ?>"><?php esc_html_e( $value['woo_label'] ); ?></th>
			<?php endforeach; ?>
			<th class="product-qty"><?php esc_html_e( 'Quantity', 'woo-product-table' ); ?></th>
		</tr>
	</thead>
	<tbody>
		<?php 
		/**
		 * Action before quick order table content
		 * 
		 * @since 1.1.6
		**/
		do_action( 'wc_quick_order_before_content' ); 
		?>

		<?php
		foreach ( WC()->session->get( 'wc_quick_order_' . $quick_order_id ) as $form_item_key => $form_item ) {

			if (  !isset( $form_item['data'] ) || !is_object( $form_item['data'] ) ) {
				continue;
			}
			/**
			 * Filter quick order product object
			 * 
			 * @since 1.1.6
			**/
			$_product = apply_filters( 'wc_quick_order_item_product', $form_item['data'], $form_item, $form_item_key );
			/**
			 * Filter quick order product id
			 * 
			 * @since 1.1.6
			**/
			$product_id = apply_filters( 'wc_quick_order_item_product_id', $form_item['product_id'], $form_item, $form_item_key );

			/**
			 * Filter quick order product visibility
			 * 
			 * @since 1.1.6
			**/
			if ( $_product && $_product->exists() && $form_item['quantity'] > 0 && apply_filters( 'quick_order_item_visible', true, $form_item, $form_item_key ) ) {
				/**
				 * Filter quick order product permalink
				 * 
				 * @since 1.1.6
				**/
				$product_permalink = apply_filters( 'quick_order_item_permalink', $_product->is_visible() ? $_product->get_permalink( $form_item ) : '', $form_item, $form_item_key );
				?>
				<tr class="woocommerce-cart-form__order-item 
				<?php 
				/**
				 * Filter quick order product class
				 * 
				 * @since 1.1.6
				**/
				esc_attr_e( apply_filters( 'quick_order_item_class', 'cart_item', $form_item, $form_item_key ) ); 
				?>
			">

			<td class="product-remove">
				<?php
					/**
					 * Filter quick order product remove link
					 * 
					 * @since 1.1.6
					**/
					echo wp_kses_post( apply_filters( 
						'quick_order_item_remove_link',
						sprintf(
							'<a href="%s" class="remove remove-cart-item wc-order-remove-item" aria-label="%s" data-cart_item_key="%s" data-product_id="%s" data-product_sku="%s">&times;</a>',
							esc_attr( $form_item_key ),
							esc_html__( 'Remove this item', 'woo-product-table' ),
							esc_attr( $form_item_key ),
							esc_attr( $product_id ),
							esc_attr( $_product->get_sku() )
						),
						$form_item_key
					) );
				?>
				</td>
				<td class="product-name" data-title="<?php esc_attr_e( 'Product', 'woo-product-table' ); ?>">
					<select style="width:100%" class="wc-product-search" data-placeholder="<?php esc_attr_e( 'Search for a product&hellip;', 'woocommerce' ); ?>" data-action="woocommerce_json_search_products_and_variations" data-include="[<?php esc_attr_e( $product_ids ); ?>]" data-exclude="<?php esc_attr_e( $product_id ); ?>" data-update="true" data-exclude_type="variable" data-cart_item_key="<?php esc_attr_e($form_item_key); ?>"><option value="<?php esc_attr_e( $product_id ); ?>" selected><?php esc_attr_e( $_product->get_name() ); ?></option></select>
					<?php 
					/**
					 * Action after quick order item name
					 * 
					 * @since 1.1.6
					**/
					do_action( 'quick_order_after_item_name', $form_item, $form_item_key ); 
					?>
				</td>
				<?php 
				foreach ( $quick_order_fields as $quick_order_field ) {
					switch ( $quick_order_field['woo_ids'] ) { 
						case 'sku':
							?>
						<td class="product-sku">
							<?php esc_attr_e( $_product->get_sku() ); ?>
						</td>
							<?php
							break;
						case 'short_desc':
							?>
						<td class="product-short_desc">
							<?php esc_attr_e( $_product->get_short_description() ); ?>
						</td>
							<?php
							break;
						case 'cat':
							?>
						<td class="product-cat">
							<?php echo wp_kses_post( wc_get_product_category_list($product_id) ) ; ?>
						</td>
							<?php
							break;
						case 'featured_img':
							?>
						<td class="product-featured_img">
							<?php
								/**
								 * Filter quick order product thumbnail
								 * 
								 * @since 1.1.6
								**/
								$thumbnail = apply_filters( 'quick_order_item_thumbnail', $_product->get_image(), $form_item, $form_item_key );

							if ( ! $product_permalink ) {
								echo wp_kses_post( $thumbnail ); // phpcs:ignore WordPress.Security.EscapeOutput
							} else {
								printf( '<a href="%s">%s</a>', esc_url( $product_permalink ), wp_kses_post( $thumbnail ) ); 
							}
							?>
							</td>
							<?php
							break;
						case 'stock':
							?>
							<td class="product-stock">
							<?php 
							if ( empty( $_product->get_stock_quantity() ) ) :
								if ( ! $_product->is_in_stock() ) {
									$class = 'out-of-stock';
								} elseif ( ( $_product->managing_stock() && $_product->is_on_backorder( 1 ) ) || ( ! $_product->managing_stock() && $_product->is_on_backorder( 1 ) ) ) {
									$class = 'available-on-backorder';
								} else {
									$class = 'in-stock';
								}
								?>
									<span class="stock_<?php esc_attr_e( $_product->get_id() ); ?>" data-stock='<span class="stock <?php esc_attr_e( $class ); ?>">
									<?php esc_html_e( $_product->get_stock_status() ); ?>
									</span>'>
									<span class="stock <?php esc_attr_e( $class ); ?>">
									<?php esc_html_e( $_product->get_stock_status() ); ?>
									</span>
								</span>
								<?php 
							else :
								esc_attr_e($_product->get_stock_quantity());
							endif;
							?>
						</td>
							<?php
							break;
						case 'weight':
							?>
						<td class="product-weight">
							<?php esc_attr_e( $_product->get_weight() ) ; ?>
						</td>
							<?php
							break;
						case 'dimensions':
							?>
						<td class="product-dimensions">
							<?php esc_html_e( wc_format_dimensions( $_product->get_dimensions( false ) ) ); ?>
						</td>
							<?php
							break;
						case 'price':
							?>
						<td class="product-price" data-title="<?php esc_attr_e( 'Price', 'woo-product-table' ); ?>">
							<?php echo wp_kses_post($_product->get_price_html()); ?>		
						</td>
							<?php
							break;
					}
				}
				?>

			<td class="product-quantity" data-title="<?php esc_attr_e( 'Quantity', 'woo-product-table' ); ?>">
				<?php
				if ( $_product->is_sold_individually() ) {
					$product_quantity = sprintf( '<input type="hidden" name="order_qty[%s]" value="1" data-cart_item_key="%s"/>', $form_item_key, $form_item_key );
				} else {
					if ( class_exists( 'Wwp_Wholesale_Pricing' ) ) {
						add_filter( 'woocommerce_quantity_input_args', function( $wp_parse_args ) use ( $form_item ) {
							$wp_parse_args['input_value'] = $form_item['quantity'];
							return $wp_parse_args;
						} );
					}
					woocommerce_quantity_input(
						array(
							'input_id'	   => 'quantity_' . $form_item_key,
							'input_name'   => "order_qty[{$form_item_key}]",
							'input_value' => $form_item['quantity'], // WPCS: CSRF ok, input var ok.
							'min_value'   => apply_filters( 'woocommerce_quantity_input_min', $_product->get_min_purchase_quantity(), $_product ),
							'max_value'   => apply_filters( 'woocommerce_quantity_input_max', $_product->get_max_purchase_quantity(), $_product ),
							'product_name' => $_product->get_name(),
						),
						$_product,
						true
					);
				}
				?>
			</td>

		</tr>
				<?php
			}
		}
		?>
<?php 
/**
 * Action quick order contents
 * 
 * @since 1.1.6
**/
do_action( 'quick_order_contents' ); 
?>
</tbody>
</table>
<?php 
/**
 * Action after quick order contents
 * 
 * @since 1.1.6
**/
do_action( 'quick_order_after_contents' );

/**
 * Action after quick order table
 * 
 * @since 1.1.6
**/
do_action( 'quick_order_after_table' ); 
?>

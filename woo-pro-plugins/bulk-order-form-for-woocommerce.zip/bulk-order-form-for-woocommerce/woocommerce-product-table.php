<?php
/**
 * Plugin Name:	Bulk Order Form For WooCommerce
 * Description:	Display your WooCommerce shop products with desired fields in a table layout easily. 
 * Version: 1.1.6
 * Tested up to: 6.1.1
 * Author: WPExperts
 * Author URI: https://wpexperts.io/
 * Developer: WPExperts
 * Developer URI: https://wpexperts.io/
 * Text Domain: woo-product-table
 *
 * Woo: 5706596:4122eb01d12e27aeb1880d4cc0506b7d
 * WC requires at least: 3.0
 * WC tested up to: 7.1.1
 *
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @package WooCommerce Product Table
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


if ( ! defined( 'WCPT_PLUGIN_FILE' ) ) {
	define( 'WCPT_PLUGIN_FILE', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'WCPT_PLUGIN_URL' ) ) {
	define( 'WCPT_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

if ( ! defined( 'WCPT_PLUGIN_VERSION' ) ) {
	define( 'WCPT_PLUGIN_VERSION', '1.1.6' );
}

/**
 * Adds notice in case of WooCommerce being inactive
 */
function wcpt_woocommerce_inactive_notice() {
	$class    = 'notice notice-error';
	$headline = __( 'WooCommerce Product Table requires WooCommerce to be active.', 'woo-product-table' );
	$message  = __( 'Go to the plugins page to activate WooCommerce', 'woo-product-table' );
	printf( '<div class="%1$s"><h2>%2$s</h2><p>%3$s</p></div>', esc_attr( $class ), esc_html( $headline ), esc_html( $message ) );
}

/**
 * Check for plugin dependencies
 */
if ( ! class_exists( 'WCPT_Dependencies' ) ) {
	require_once WCPT_PLUGIN_FILE . 'includes/class-wcpt-dependencies.php';
}

if ( WCPT_Dependencies::woocommerce_active_check() ) {
	require_once WCPT_PLUGIN_FILE . 'includes/class-wc-product-table.php';

	/**
	 * Create instance of WooCommerce Product Table.
	 */
	function wc_product_table() {
		return WC_Product_Table::instance();
	}

	// Global for backwards compatibility.
	$GLOBALS['wc_product_table'] = wc_product_table();
} else {
	add_action( 'admin_notices', 'wcpt_woocommerce_inactive_notice' );
}
add_action( 'plugins_loaded', 'wpml_active_check' );

/**
 * Make WCPT translated by default
 */
function wpml_active_check() {
	$is_lang_configured_for_first_time = get_option( 'wcpt_wpml_lang', false );
	if ( function_exists( 'icl_object_id' ) && ! $is_lang_configured_for_first_time ) {
		/**
		 * WCPT Action for translation
		 *
		 * @since 1.0.0
		 */
		do_action( 'wpml_set_translation_mode_for_post_type', 'wcpt', 'translate' );
		update_option( 'wcpt_wpml_lang', true );
	}
}

add_action( 'wp_loaded', 'init_wholesale_pricing' );
/** Initialize wholesale ajax pricing */ 
function init_wholesale_pricing() { 
	if ( class_exists( 'Wwp_Wholesale_Pricing' ) ) {
		include_once WWP_PLUGIN_PATH . 'inc/class-wwp-wholesale-frontend.php';
		$main_class = new Wwp_Wholesale_Pricing();
		$main_class->include_wholesale_functionality();
	}
}

=== WooCommerce All Products For Subscriptions ===

Contributors: SomewhereWarm, Prospress
Tags: woocommerce, subscriptions, subscribe, order, cart, product, convert, product type, bundle, composite, extension, plan
Requires at least: 4.4
Tested up to: 6.0
Stable tag: 4.0.4
WC requires at least: 3.9
WC tested up to: 6.9
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Make existing products available on subscription, offer subscription options in the cart, and give customers the freedom to add products to their existing subscriptions.

== Description ==

WooCommerce Subscriptions add-on formerly known as Subscribe All The Things.

Make existing products available on subscription, and let customers add products to their subscriptions.

Use it to attach subscriptions to Simple & Variable products, [Product Bundles](http://woocommerce.com/products/product-bundles/) and [Composite Products](http://woocommerce.com/products/composite-products/).

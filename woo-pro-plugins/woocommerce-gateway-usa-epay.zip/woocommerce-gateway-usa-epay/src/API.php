<?php
/**
 * WooCommerce USA ePay Gateway
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to woosupport@atreus.io so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce USA ePay Gateway to newer
 * versions in the future. If you wish to customize WooCommerce USA ePay Gateway for your
 * needs please refer to http://docs.woocommerce.com/document/usa-epay/
 *
 * @author    Atreus
 * @copyright Copyright (c) 2014-2022, Atreus (woosupport@atreus.io)
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

namespace Atreus\WooCommerce\USAePay;

use SkyVerge\WooCommerce\PluginFramework\v5_10_12 as Framework;

defined( 'ABSPATH' ) or exit;

/**
 * The base USA ePay API class.
 *
 * @since 2.0.0
 */
class API extends Framework\SV_WC_API_Base implements Framework\SV_WC_Payment_Gateway_API {


	/** the default production domain */
	const PRODUCTION_DOMAIN = 'usaepay.com';

	/** the test endpoint domain */
	const TEST_DOMAIN = 'sandbox.usaepay.com';

	/** @var string gateway ID */
	protected $gateway_id;

	/** @var string API key */
	protected $api_key;

	/** @var string pin */
	protected $pin;

	/** @var \WC_Order WooCommerce order object */
	protected $order;


	/**
	 * Constructs the class.
	 *
	 * @since 2.0.0
	 *
	 * @param string $api_key API key
	 * @param string $pin API pin
	 * @param string $environment current API environment, either `production` or `test`
	 */
	public function __construct( string $api_key, string $pin, string $environment, string $gateway_id ) {

		$this->api_key     = $api_key;
		$this->pin         = $pin;
		$this->request_uri = $this->get_api_request_uri( $environment );
		$this->gateway_id  = $gateway_id;

		$this->set_request_content_type_header( 'application/json' );
		$this->set_request_accept_header( 'application/json' );
	}


	/**
	 * Return the complete API request URI.
	 *
	 * @since 3.0.0
	 *
	 * @param string $environment
	 *
	 * @return string
	 */
	protected function get_api_request_uri( string $environment ) : string {

		if ( 'production' === $environment ) {

			/**
			 * Filters the API domain to allow for alternate high-availability domains.
			 *
			 * Normally, this should not be overridden since USA ePay automatically load-balances
			 * their primary domain, but there may be some instances in which a merchant needs to
			 * run all their transactions through a specific server, which can be done with this filter.
			 *
			 * @see https://help.usaepay.info/developer/reference/highavailability/
			 *
			 * @since 2.0.0
			 *
			 * @param string $domain the API domain
			 */
			$domain = apply_filters( 'wc_usa_epay_api_production_domain', self::PRODUCTION_DOMAIN );

			/**
			 * Filters the endpoint key of the API URL.
			 *
			 * The default `v2` endpoint key will work for everyone, but is throttled.
			 * High-volume merchants will want to create a new endpoint key and filter it here.
			 *
			 * @see https://help.usaepay.info/developer/rest-api/#api-rate-limits
			 *
			 * @since 2.0.0
			 *
			 * @param string $endpoint_key the API endpoint key
			 * @param string $environment the current API environment, either `production` or `test`
			 */
			$endpoint = apply_filters( 'wc_usa_epay_api_endpoint', 'v2', $environment );


		} else {

			// sandbox
			$domain   = self::TEST_DOMAIN;
			$endpoint = 'v2';
		}

		/**
		 * Filters the entire API request URL.
		 *
		 * @since 3.0.0
		 *
		 * @param string $request_uri current request URI, e.g. https://sandbox.usaepay.com/api/v2/
		 * @param string $environment current environment, e.g. test
		 * @param API $this instance
		 */
		return apply_filters( 'wc_usa_epay_api_request_uri', "https://{$domain}/api/{$endpoint}/", $environment, $this );
	}

	/**
	 * Override this method to filter the API key and PIN immediately before a request is made, but late enough such
	 * that the $order is available, in case actors want to change the credentials on a per-order basis (e.g. multicurrency)
	 *
	 * @since 2.0.0
	 */
	protected function reset_response() {

		/**
		 * Filters the USA ePay API Key.
		 *
		 * @since 2.0.0
		 *
		 * @param string $api_key API key
		 * @param \WC_Order|null $order order object
		 */
		$this->api_key = apply_filters( 'wc_usa_epay_api_request_api_key', $this->api_key, $this->get_order(), $this );

		/**
		 * Filters the USA ePay API Pin.
		 *
		 * @since 2.0.0
		 *
		 * @param string $pin API pin
		 * @param \WC_Order|null $order order object
		 */
		$this->pin = apply_filters( 'wc_usa_epay_api_request_pin', $this->pin, $this->get_order(), $this );

		$this->set_request_header( 'Authorization', 'Basic ' . $this->api_auth_key() );

		parent::reset_response();
	}


	/**
	 * Performs a credit card charge.
	 *
	 * @param \WC_Order $order WooCommerce order object
	 *
	 * @return API\Response\Response|object|Framework\SV_WC_API_Request|Framework\SV_WC_API_Response
	 * @throws Framework\SV_WC_API_Exception
	 * @since 2.0.0
	 *
	 */
	public function credit_card_charge( \WC_Order $order ) {

		$this->order = $order;

		$request = $this->get_new_request( 'charge' );

		$request->set_charge_data( $order );

		return $this->perform_request( $request );
	}


	/**
	 * Performs a credit card authorization.
	 *
	 * @param \WC_Order $order WooCommerce order object
	 *
	 * @return API\Response\Response|object|Framework\SV_WC_API_Request|Framework\SV_WC_API_Response
	 * @throws Framework\SV_WC_API_Exception
	 * @since 2.0.0
	 *
	 */
	public function credit_card_authorization( \WC_Order $order ) {

		$this->order = $order;

		$request = $this->get_new_request( 'charge' );

		$request->set_authorization_data( $order );

		return $this->perform_request( $request );
	}


	/**
	 * Captures an authorized credit card payment.
	 *
	 * @param \WC_Order $order order object
	 *
	 * @return API\Response\Response|object|Framework\SV_WC_API_Request|Framework\SV_WC_API_Response
	 * @throws Framework\SV_WC_API_Exception
	 * @since 2.0.0
	 *
	 */
	public function credit_card_capture( \WC_Order $order ) {

		$this->order = $order;

		$request = $this->get_new_request( 'capture' );

		$request->set_capture_data( $order );

		return $this->perform_request( $request );
	}


	/**
	 * Refunds a transaction.
	 *
	 * @param \WC_Order $order order object
	 *
	 * @return API\Response\Response|object|Framework\SV_WC_API_Request|Framework\SV_WC_API_Response
	 * @throws Framework\SV_WC_API_Exception
	 * @since 2.0.0
	 *
	 */
	public function refund( \WC_Order $order ) {

		$this->order = $order;

		$request = $this->get_new_request( 'refund' );

		$request->set_refund_data( $order );

		return $this->perform_request( $request );
	}


	/**
	 * Voids a transaction.
	 *
	 * @param \WC_Order $order order object
	 *
	 * @return API\Response\Response|object|Framework\SV_WC_API_Request|Framework\SV_WC_API_Response
	 * @throws Framework\SV_WC_API_Exception
	 * @since 2.0.0
	 */
	public function void( \WC_Order $order ) {

		$this->order = $order;

		$request = $this->get_new_request( 'void' );

		$request->set_void_data( $order );

		return $this->perform_request( $request );
	}


	/**
	 * Tokenize the credit card.
	 *
	 * @param \WC_Order $order order object
	 *
	 * @return API\Response\Response|object|Framework\SV_WC_API_Request|Framework\SV_WC_API_Response
	 * @throws Framework\SV_WC_API_Exception
	 * @since 3.0.0
	 */
	public function tokenize_payment_method( \WC_Order $order ) {

		$this->order = $order;

		$request = $this->get_new_request( 'tokenize' );

		$request->set_tokenize_data( $order );

		return $this->perform_request( $request );
	}


	/** Validation methods ****************************************************/


	/**
	 * Validates the response for errors after parsing the data.
	 *
	 * @see Framework\SV_WC_API_Base::do_post_parse_response_validation()
	 *
	 * @since 2.0.0
	 *
	 * @return true
	 * @throws Framework\SV_WC_API_Exception
	 */
	protected function do_post_parse_response_validation() : bool {

		$response_code = (int) $this->get_response_code();

		// if response code is not 200 or there is an error code
		if ( 300 <= $response_code || 0 < (int) $this->get_response()->get_error_code() ) {
			throw new Framework\SV_WC_API_Exception( $this->get_response()->get_status_message() );
		}

		return true;
	}


	/** Helper methods ********************************************************/


	/**
	 * Generates and returns an API auth key used in the authentication header.
	 *
	 * @since 2.0.0
	 *
	 * @return string API hash
	 */
	private function api_auth_key() : string {

		$seed     = bin2hex( openssl_random_pseudo_bytes( 8 ) );
		$prehash  = $this->api_key . $seed . $this->pin;
		$api_hash = 's2/' . $seed . '/' . hash( 'sha256', $prehash );

		return base64_encode( $this->api_key . ':' . $api_hash );
	}


	/**
	 * Builds and returns a new API request object.
	 *
	 * @param string $type request type to get
	 *
	 * @return API\Request\Request
	 * @throws Framework\SV_WC_API_Exception
	 * @since 2.0.0
	 */
	protected function get_new_request( $type = '' ) {

		switch ( $type ) {

			case 'charge':
				$request_handler  = '\\Atreus\\WooCommerce\\USAePay\\API\\Request\\Charge';
			break;

			case 'capture':
				$request_handler = '\\Atreus\\WooCommerce\USAePay\\API\Request\Capture';
			break;

			case 'refund':
				$request_handler = '\\Atreus\\WooCommerce\USAePay\\API\Request\Refund';
			break;

			case 'void':
				$request_handler = '\\Atreus\\WooCommerce\USAePay\\API\Request\AuthVoid';
			break;

			case 'tokenize':
				$request_handler = '\\Atreus\\WooCommerce\USAePay\\API\Request\Tokenize';
			break;


			default:
				throw new Framework\SV_WC_API_Exception( 'Invalid request type' );
		}

		$this->set_response_handler( '\\Atreus\\WooCommerce\\USAePay\\API\\Response\\Transaction' );

		return new $request_handler;
	}


	/**
	 * Return the parsed response object for the request
	 *
	 * Overridden because the order object is needed to parse the response
	 *
	 * @since 3.0.0
	 * @param string $raw_response_body
	 * @return API\Response\Response class instance which implements SV_WC_API_Request
	 */
	protected function get_parsed_response( $raw_response_body ) {

		$handler_class = $this->get_response_handler();

		return new $handler_class( $raw_response_body, $this->get_order() );
	}


	/**
	 * Gets the order associated with the request.
	 *
	 * @since 2.0.0
	 *
	 * @return \WC_Order|null
	 */
	public function get_order() : \WC_Order {

		return $this->order;
	}


	/**
	 * Return the API ID, mainly used for namespacing actions
	 *
	 * @since 2.0.0
	 * @return string
	 */
	protected function get_api_id() : string {
		return $this->gateway_id;
	}


	/**
	 * Gets the main plugin instance.
	 *
	 * @see Framework\SV_WC_API_Base::get_plugin()
	 *
	 * @since 2.0.0
	 *
	 * @return Plugin
	 */
	protected function get_plugin() {

		return Plugin::instance();
	}


	/* No-op methods **********************************************************/


	/**
	 * No-op: we do not currently support echeck transactions.
	 *
	 * @since 2.0.0
	 *
	 * @param \WC_Order $order order object
	 */
	public function check_debit( \WC_Order $order ) { }


	/**
	 * No-op: USA ePay doesn't support updating previously tokenized payment methods.
	 *
	 * @since 2.0.2
	 *
	 * @param \WC_Order $order order object
	 */
	public function update_tokenized_payment_method( \WC_Order $order ) { }


	/**
	 * No-op: USA ePay doesn't support removing previously tokenized payment methods.
	 *
	 * @since 2.0.0
	 *
	 * @param string $token payment method token
	 * @param string $customer_id unique customer ID
	 */
	public function remove_tokenized_payment_method( $token, $customer_id ) { }


	/**
	 * No-op: USA ePay doesn't support getting previously tokenized payment methods.
	 *
	 * @since 2.0.0
	 *
	 * @param string $customer_id unique customer ID
	 */
	public function get_tokenized_payment_methods( $customer_id ) { }


	/**
	 * USA ePay doesn't support getting previously tokenized payment methods.
	 *
	 * @see Framework\SV_WC_Payment_Gateway_API::supports_get_tokenized_payment_methods()
	 *
	 * @since 2.0.0
	 *
	 * @return false
	 */
	public function supports_get_tokenized_payment_methods() : bool {

		return false;
	}


	/**
	 * USA ePay doesn't support updating previously tokenized payment methods.
	 *
	 * @see Framework\SV_WC_Payment_Gateway_API::supports_update_tokenized_payment_method()
	 *
	 * @since 2.0.2
	 *
	 * @return false
	 */
	public function supports_update_tokenized_payment_method() : bool {

		return false;
	}


	/**
	 * USA ePay doesn't support removing previously tokenized payment methods.
	 *
	 * @see Framework\SV_WC_Payment_Gateway_API::supports_remove_tokenized_payment_method()
	 *
	 * @since 2.0.0
	 *
	 * @return false
	 */
	public function supports_remove_tokenized_payment_method() : bool {

		return false;
	}


}

<?php
/**
 * WooCommerce USA ePay Gateway
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to woosupport@atreus.io so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce USA ePay Gateway to newer
 * versions in the future. If you wish to customize WooCommerce USA ePay Gateway for your
 * needs please refer to http://docs.woocommerce.com/document/usa-epay/
 *
 * @author    Atreus
 * @copyright Copyright (c) 2014-2022, Atreus (woosupport@atreus.io)
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

namespace Atreus\WooCommerce\USAePay\API\Request;

defined( 'ABSPATH' ) or exit;

/**
 * The Refund request class.
 *
 * @since 2.0.0
 */
class Refund extends Request {


	/**
	 * Sets the refund transaction data.
	 *
	 * @since 2.0.0
	 *
	 * @param \WC_Order $order order object
	 */
	public function set_refund_data( \WC_Order $order ) {

		$this->order = $order;

		$data = [
			'command' => 'cc:refund',
			'amount'  => $order->refund->amount,
		];

		// TODO: remove refnum in ~March 2023 {MR 2022-08-12}
		if ( ! empty( $order->refund->refnum ) ) {
			$data['refnum'] = $order->refund->refnum;
		} else {
			$data['trankey'] = $order->refund->trans_id;
		}

		$this->set_data( $data );
	}


}

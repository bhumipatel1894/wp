<?php
/**
 * WooCommerce USA ePay Gateway
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to woosupport@atreus.io so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce USA ePay Gateway to newer
 * versions in the future. If you wish to customize WooCommerce USA ePay Gateway for your
 * needs please refer to http://docs.woocommerce.com/document/usa-epay/
 *
 * @author    Atreus
 * @copyright Copyright (c) 2014-2022, Atreus (woosupport@atreus.io)
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

namespace Atreus\WooCommerce\USAePay\API\Response;

use SkyVerge\WooCommerce\PluginFramework\v5_10_12 as Framework;

defined( 'ABSPATH' ) or exit;

/**
 * The USA ePay API base response class.
 *
 * @since 2.0.0
 */
class Response extends Framework\SV_WC_API_JSON_Response implements Framework\SV_WC_Payment_Gateway_API_Response {


	/**
	 * Construct the response.
	 *
	 * @since 3.0.0
	 * @param string $raw_response_json
	 * @param \WC_Order $order
	 */
	public function __construct( string $raw_response_json, \WC_Order $order ) {

		$this->order = $order;

		parent::__construct( $raw_response_json );
	}


	/**
	 * Gets the transaction ID.
	 *
	 * @since 2.0.0
	 *
	 * @return string|null
	 */
	public function get_transaction_id() {

		return $this->key;
	}


	/**
	 * Gets the reference number, a legacy identifier for the transaction.
	 *
	 * @since 3.0.0
	 *
	 * @return string|null
	 */
	public function get_reference_number() {

		return $this->refnum;
	}


	/**
	 * Determines if the transaction was approved.
	 *
	 * @since 2.0.0
	 *
	 * @return bool
	 */
	public function transaction_approved() : bool {

		return 'A' === $this->result_code;
	}


	/**
	 * Determines if the transaction was held.
	 *
	 * @since 2.0.0
	 *
	 * @return bool
	 */
	public function transaction_held() : bool {

		// USA ePay doesn't have this concept
		return false;
	}


	/**
	 * Gets the transaction status code.
	 *
	 * @since 2.0.0
	 *
	 * @return string|null
	 */
	public function get_status_code() {

		if ( null !== $this->get_error_code() ) {

			return $this->get_error_code();
		}

		return $this->result_code;
	}


	/**
	 * Gets the error code returned.
	 *
	 * @since 2.0.0
	 *
	 * @return string|null
	 */
	public function get_error_code() {

		return $this->error_code;
	}


	/**
	 * Gets the transaction status message.
	 *
	 * @since 2.0.0
	 *
	 * @return string|null
	 */
	public function get_status_message() {

		if ( null !== $this->error ) {

			return $this->error;
		}

		return $this->result;
	}

	/**
	 * Gets the payment type.
	 *
	 * @since 2.0.0
	 *
	 * @return string
	 */
	public function get_payment_type() : string {

		return Framework\SV_WC_Payment_Gateway::PAYMENT_TYPE_CREDIT_CARD;
	}


	/**
	 * Gets a customer-friendly error message if available.
	 *
	 * @since 2.0.0
	 *
	 * @return string
	 */
	public function get_user_message() : string {

		$message = '';

		if ( isset( $this->error_code ) ) {

			$helper  = new \Atreus\WooCommerce\USAePay\API\Message_Helper();
			$message = $helper->get_message( $this->get_error_code() );
		}

		return $message;
	}


}

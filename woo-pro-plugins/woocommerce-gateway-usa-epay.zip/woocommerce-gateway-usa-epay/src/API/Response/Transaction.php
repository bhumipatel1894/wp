<?php
/**
 * WooCommerce USA ePay Gateway
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to woosupport@atreus.io so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce USA ePay Gateway to newer
 * versions in the future. If you wish to customize WooCommerce USA ePay Gateway for your
 * needs please refer to http://docs.woocommerce.com/document/usa-epay/
 *
 * @author    Atreus
 * @copyright Copyright (c) 2014-2022, Atreus (woosupport@atreus.io)
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

namespace Atreus\WooCommerce\USAePay\API\Response;

use SkyVerge\WooCommerce\PluginFramework\v5_10_12 as Framework;

defined( 'ABSPATH' ) or exit;

/**
 * The USA ePay Sale response class.
 *
 * @since 2.0.0
 */
class Transaction extends Response implements Framework\SV_WC_Payment_Gateway_API_Authorization_Response, Framework\SV_WC_Payment_Gateway_API_Create_Payment_Token_Response {


	/**
	 * Gets the transaction authorization code.
	 *
	 * @since 2.0.0
	 *
	 * @return string|null
	 */
	public function get_authorization_code() : string {

		return $this->authcode;
	}


	/**
	 * Determines if the AVS was a match.
	 *
	 * @since 2.0.0
	 *
	 * @return bool
	 */
	public function avs_match() : bool {

		$matching_codes = array(
			'YYY', // address: match & 5 digit zip: match
			'Y',   // `YYY` alternate
			'YYA', // `YYY` alternate
			'YYD', // `YYY` alternate
			'YYX', // address: match & 9 digit zip: match
			'X',   // `YYX` alternate
			'GGG', // international address: match & zip: match
			'D',   // `GGG` alternate
		);

		return isset( $this->avs->result_code ) && in_array( $this->avs->result_code, $matching_codes, true );
	}


	/**
	 * Determines if AVS was processed.
	 *
	 * @since 2.0.0
	 *
	 * @return bool
	 */
	public function avs_processed() : bool {

		return isset( $this->avs );
	}


	/**
	 * Gets the transaction AVS result code.
	 *
	 * @since 2.0.0
	 *
	 * @return string
	 */
	public function get_avs_result() : string {

		return $this->avs->result_code ?? '';
	}


	/**
	 * Gets the transaction CSC validation result.
	 *
	 * @since 2.0.0
	 *
	 * @return string|null
	 */
	public function get_csc_result() : string {

		return $this->cvc->result_code ?? '';
	}


	/**
	 * Determines if the CSC was a match.
	 *
	 * @since 2.0.0
	 *
	 * @return bool
	 */
	public function csc_match() : bool {

		return isset( $this->cvc->result_code ) && 'M' === $this->cvc->result_code;
	}


	/**
	 * Return the payment token for a tokenization transaction.
	 *
	 * @since 3.0.0
	 *
	 * @return Framework\SV_WC_Payment_Gateway_Payment_Token
	 */
	public function get_payment_token() : Framework\SV_WC_Payment_Gateway_Payment_Token {

		$data = [
			'default'   => true,
			'type'      => 'credit_card',
			'card_type' => $this->order->payment->card_type,
			'last_four' => substr( $this->order->payment->account_number, -4 ),
			'exp_month' => $this->order->payment->exp_month,
			'exp_year'  => $this->order->payment->exp_year,
		];

		return new Framework\SV_WC_Payment_Gateway_Payment_Token( $this->savedcard->key, $data );
	}


}

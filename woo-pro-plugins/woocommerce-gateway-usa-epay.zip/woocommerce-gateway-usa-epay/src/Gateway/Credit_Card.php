<?php
/**
 * WooCommerce USA ePay Gateway
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to woosupport@atreus.io so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce USA ePay Gateway to newer
 * versions in the future. If you wish to customize WooCommerce USA ePay Gateway for your
 * needs please refer to http://docs.woocommerce.com/document/usa-epay/
 *
 * @author    Atreus
 * @copyright Copyright (c) 2014-2022, Atreus (woosupport@atreus.io)
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

namespace Atreus\WooCommerce\USAePay\Gateway;

use SkyVerge\WooCommerce\PluginFramework\v5_10_12 as Framework;
use Atreus\WooCommerce\USAePay\Plugin;
use Atreus\WooCommerce\USAePay\API;

defined( 'ABSPATH' ) or exit;

/**
 * WooCommerce USA ePay Gateway main plugin class.
 *
 * @since 2.0.0
 */
class Credit_Card extends Framework\SV_WC_Payment_Gateway_Direct {


	/** @var string API Key */
	protected $api_key;

	/** @var string test API Key */
	protected $test_api_key;

	/** @var string Pin */
	protected $pin;

	/** @var string test Pin */
	protected $test_pin;

	/** @var string whether a receipt email should be sent or not */
	protected $receipt_email;

	/** @var API API handler instance */
	protected $api;


	/**
	 * Constructs the gateway.
	 *
	 * @since 2.0.0
	 */
	public function __construct() {

		parent::__construct(
			Plugin::CREDIT_CARD_GATEWAY_ID,
			Plugin::instance(),
			[
				'method_title'       => __( 'USA ePay', 'woocommerce-gateway-usa-epay' ),
				'method_description' => __( 'USA ePay allows customers to checkout using a credit card', 'woocommerce-gateway-usa-epay' ),
				'supports'           => [
					self::FEATURE_PRODUCTS,
					self::FEATURE_CARD_TYPES,
					self::FEATURE_PAYMENT_FORM,
					self::FEATURE_CREDIT_CARD_CHARGE,
					self::FEATURE_CREDIT_CARD_CHARGE_VIRTUAL,
					self::FEATURE_CREDIT_CARD_AUTHORIZATION,
					self::FEATURE_CREDIT_CARD_CAPTURE,
					self::FEATURE_TOKENIZATION,
					self::FEATURE_ADD_PAYMENT_METHOD,
					self::FEATURE_TOKEN_EDITOR,
					self::FEATURE_DETAILED_CUSTOMER_DECLINE_MESSAGES,
					self::FEATURE_REFUNDS,
					self::FEATURE_VOIDS,
				],
				'environments' => [
					self::ENVIRONMENT_PRODUCTION => esc_html_x( 'Production', 'software environment', 'woocommerce-gateway-usa-epay' ),
					self::ENVIRONMENT_TEST       => esc_html_x( 'Sandbox', 'software environment', 'woocommerce-gateway-usa-epay' ),
				],
				'payment_type' => self::PAYMENT_TYPE_CREDIT_CARD,
			]
		);
	}


	/**
	 * Gets the gateway form fields.
	 *
	 * @see Framework\SV_WC_Payment_Gateway::get_method_form_fields()
	 *
	 * @since 2.0.0
	 *
	 * @return array
	 */
	protected function get_method_form_fields() : array {

		return array(
			'api_key' => array(
				'title'       => __( 'API Key', 'woocommerce-gateway-usa-epay' ),
				'description' => __( 'Your API Key, generated in the Merchant Console.', 'woocommerce-gateway-usa-epay' ),
				'type'        => 'text',
				'class'       => 'environment-field production-field',
			),
			'test_api_key' => array(
				'title'       => __( 'API Key', 'woocommerce-gateway-usa-epay' ),
				'description' => __( 'Your API Key, generated in the Merchant Console.', 'woocommerce-gateway-usa-epay' ),
				'type'        => 'text',
				'class'       => 'environment-field test-field',
			),
			'pin' => array(
				'title'       => __( 'PIN', 'woocommerce-gateway-usa-epay' ),
				'description' => __( 'This is the private PIN you set in your merchant console for the above API key.', 'woocommerce-gateway-usa-epay' ),
				'type'        => 'text',
				'class'       => 'environment-field production-field',
			),
			'test_pin' => array(
				'title'       => __( 'PIN', 'woocommerce-gateway-usa-epay' ),
				'description' => __( 'This is the private PIN you set in your merchant console for the above API key.', 'woocommerce-gateway-usa-epay' ),
				'type'        => 'text',
				'class'       => 'environment-field test-field',
			),
			'receipt_email' => array(
				'title'       => __( 'Receipt Email', 'woocommerce-gateway-usa-epay' ),
				'type'        => 'checkbox',
				'label'       => __( 'Send Receipt Email', 'woocommerce-gateway-usa-epay' ),
				'description' => __( 'If checked USA ePay will send a receipt email to the customer in addition to the WooCommerce order email.' ),
				'default'     => 'no',
			)
		);
	}


	/**
	 * Gets the payment form field defaults for the test environment.
	 *
	 * @see Framework\SV_WC_Payment_Gateway::get_payment_method_defaults()
	 *
	 * @since 2.0.0
	 *
	 * @return array payment method defaults
	 */
	public function get_payment_method_defaults() : array {

		$defaults = parent::get_payment_method_defaults();

		if ( $this->is_test_environment() ) {
			$defaults['account-number'] = '4000100011112224';
			$defaults['expiry']         = '09/' . ( date( 'y' ) + 1 );
		}

		return $defaults;
	}


	/**
	 * Gets the API handler.
	 *
	 * @since 2.0.0
	 *
	 * @return API
	 */
	public function get_api() : API {

		if ( null === $this->api ) {
			$this->api = new API( $this->get_api_key(), $this->get_pin(), $this->get_environment(), $this->get_id() );
		}

		return $this->api;
	}


	/**
	 * Determines if the gateway is properly configured to perform transactions.
	 *
	 * @since 2.0.0
	 *
	 * @return bool
	 */
	public function is_configured() : bool {

		return ( $this->get_api_key() && $this->get_pin() );
	}


	/**
	 * Gets the API Key.
	 *
	 * @since 2.0.0
	 *
	 * @param string|null $environment_id gateway environment ID
	 * @return string
	 */
	public function get_api_key( $environment_id = null ) : string {

		if ( null === $environment_id ) {
			$environment_id = $this->get_environment();
		}

		return self::ENVIRONMENT_PRODUCTION === $environment_id ? $this->api_key : $this->test_api_key;
	}


	/**
	 * Gets the pin.
	 *
	 * @since 2.0.0
	 *
	 * @param string|null $environment_id gateway environment ID
	 * @return string
	 */
	public function get_pin( $environment_id = null ) : string {

		if ( null === $environment_id ) {
			$environment_id = $this->get_environment();
		}

		return self::ENVIRONMENT_PRODUCTION === $environment_id ? $this->pin : $this->test_pin;
	}


	/**
	 * Get the order for transaction, overridden to add the receipt email option.
	 *
	 * @since 3.0.0
	 *
	 * @param $order_id
	 * @return \WC_Order
	 */
	public function get_order( $order_id ) : \WC_Order {

		$order = parent::get_order( $order_id );

		$order->payment->should_send_receipt = $this->should_send_receipt();

		$order->payment->should_tokenize = $this->get_payment_tokens_handler()->should_tokenize();

		return $order;
	}


	/**
	 * Tokenization should happen concurrently with the transaction charge.
	 *
	 * @since 3.0.0
	 *
	 * @return bool
	 */
	public function tokenize_with_sale() : bool {

		return true;
	}


	/**
	 * Returns true if the receipt email should be sent via USA ePay for transactions.
	 *
	 * @since 3.0.0
	 *
	 * @return bool
	 */
	public function should_send_receipt() : bool {

		return 'yes' === $this->receipt_email;
	}


	/** TODO: temporary methods to support change from refnum to trankey as the primary transaction identifier
	 * in ~March 2023, this can be simplified to just use trankey. refnum is a legacy identifier
	 * which was replaced by transaction key in 3.0.0, but is handled to account for orders placed before the plugin
	 * was upgraded to 3.0.0, and thus missing transaction key but refnum is present. {MR 2022-08-12}
	 */


	/**
	 * Maybe add refnum to the order for capture
	 *
	 * @since 3.0.0
	 * @param \WC_Order $order
	 * @param string $amount
	 *
	 * @return \WC_Order
	 */
	public function get_order_for_capture( $order, $amount = null ) {
		$order = parent::get_order_for_capture( $order, $amount );

		if ( is_numeric( $order->capture->trans_id ) ) {
			$order->capture->refnum = $order->capture->trans_id;
		}

		return $order;
	}


	/**
	 * Maybe add refnum to the order for refund/void
	 *
	 * @since 3.0.0
	 * @param \WC_Order $order
	 * @param string $amount
	 * @param string $reason
	 *
	 * @return \WC_Order|\WP_Error
	 */
	public function get_order_for_refund( $order, $amount, $reason ) {
		$order = parent::get_order_for_refund( $order, $amount, $reason );

		if ( is_numeric( $order->refund->trans_id ) ) {
			$order->refund->refnum = $order->refund->trans_id;
		}

		return $order;
	}


}

<?php
/**
 * WooCommerce USA ePay Gateway
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to woosupport@atreus.io so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce USA ePay Gateway to newer
 * versions in the future. If you wish to customize WooCommerce USA ePay Gateway for your
 * needs please refer to http://docs.woocommerce.com/document/usa-epay/
 *
 * @author    Atreus
 * @copyright Copyright (c) 2014-2022, Atreus (woosupport@atreus.io)
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

namespace Atreus\WooCommerce\USAePay;

use SkyVerge\WooCommerce\PluginFramework\v5_10_12 as Framework;

defined( 'ABSPATH' ) or exit;

/**
 * WooCommerce USA ePay Gateway main plugin class.
 *
 * @since 2.0.0
 */
class Plugin extends Framework\SV_WC_Payment_Gateway_Plugin {


	/** @var Plugin single instance of this plugin */
	protected static $instance;

	/** string version number */
	const VERSION = '3.0.0';

	/** string the plugin ID */
	const PLUGIN_ID = 'usa_epay';

	/** string credit card gateway class name */
	const CREDIT_CARD_GATEWAY_CLASS_NAME = '\\Atreus\\WooCommerce\\USAePay\\Gateway\\Credit_Card';

	/** string credit card gateway id */
	const CREDIT_CARD_GATEWAY_ID = 'usa_epay_credit_card';


	/**
	 * Constructs the class.
	 *
	 * @since 2.0.0
	 */
	public function __construct() {

		parent::__construct(
			self::PLUGIN_ID,
			self::VERSION,
			[
				'text_domain'        => 'woocommerce-gateway-usa-epay',
				'gateways'           => [
					self::CREDIT_CARD_GATEWAY_ID => self::CREDIT_CARD_GATEWAY_CLASS_NAME
				],
				'dependencies'       => [
					'php_extensions' =>
						[ 'json', 'openssl' ]
				],
				'supports'           => [
					self::FEATURE_CAPTURE_CHARGE,
					self::FEATURE_MY_PAYMENT_METHODS,
				],
				'require_ssl'        => true,
				'display_php_notice' => true,
			]
		);
	}


	/**
	 * Loads and initializes the plugin lifecycle handler.
	 *
	 * @since 2.0.0
	 */
	protected function init_lifecycle_handler() {

		$this->lifecycle_handler = new Lifecycle( $this );
	}


	/**
	 * Signals that TLS is required by this gateway plugin.
	 *
	 * @since 2.2.0
	 *
	 * @return true
	 */
	public function require_tls_1_2() : bool {

		return true;
	}


	/** Helper methods ******************************************************/


	/**
	 * Gets the main USA ePay instance.
	 *
	 * Ensures only one instance is/can be loaded.
	 *
	 * @since 2.0.0
	 *
	 * @return Plugin
	 */
	public static function instance() : Plugin {

		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}


	/**
	 * Gets the plugin name.
	 *
	 * @see SV_WC_Payment_Gateway::get_plugin_name()
	 *
	 * @since 2.0.0
	 *
	 * @return string
	 */
	public function get_plugin_name() : string {

		return __( 'WooCommerce USA ePay Gateway', 'woocommerce-gateway-usa-epay' );
	}


	/**
	 * Gets the plugin documentation URL.
	 *
	 * @see Framework\SV_WC_Plugin::get_documentation_url()
	 *
	 * @since 2.0.0
	 *
	 * @return string
	 */
	public function get_documentation_url() : string {

		return 'https://docs.woocommerce.com/document/usa-epay/';
	}


	/**
	 * Gets the plugin support URL.
	 *
	 * @see Framework\SV_WC_Plugin::get_support_url()
	 *
	 * @since 2.0.0
	 *
	 * @return string
	 */
	public function get_support_url() : string {

		return 'https://woocommerce.com/my-account/marketplace-ticket-form/';
	}


	/**
	 * Gets the plugin sales page URL.
	 *
	 * @since 2.0.0
	 *
	 * @return string
	 */
	public function get_sales_page_url() : string {

		return 'https://woocommerce.com/products/usa-epay/';
	}


	/**
	 * Returns __DIR__
	 *
	 * @since 2.0.0
	 *
	 * @return string
	 */
	protected function get_file() : string {

		return __FILE__;
	}


	/**
	 * Returns the plugin file, overridden because the plugin class is located within the src directory and the framework
	 * method assumes the plugin class is always in the same directory as the loader class
	 *
	 * @since 3.0.0
	 * @return string /dir/to/plugins/woocommerce-gateway-usa-epay/woocommerce-gateway-usa-epay.php
	 */
	public function get_plugin_file() : string {

		return trailingslashit( dirname( $this->get_file(), 2 ) ) . 'woocommerce-gateway-usa-epay.php';
	}


}

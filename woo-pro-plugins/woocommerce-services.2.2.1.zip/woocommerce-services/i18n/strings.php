<?php
/* THIS IS A GENERATED FILE. DO NOT EDIT DIRECTLY. */
$i18nStrings = array(
__( "Dismiss", "woocommerce-services" ), // dist/chunks/3fb65e7047473c3c974a.min.js:1
__( "Saving\\u2026", "woocommerce-services" ), // dist/chunks/3fb65e7047473c3c974a.min.js:1
__( "Save Settings", "woocommerce-services" ), // dist/chunks/3fb65e7047473c3c974a.min.js:1
__( "Required", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Optional", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Dismiss", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Debug", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Debug", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Display troubleshooting information on the Cart and Checkout pages.", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Enabled", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Disabled", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Logging", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Write diagnostic messages to log files. Helpful when contacting support.", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Enabled", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Disabled", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Shipping Log", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Taxes Log", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Other Log", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Tax Rates", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Download Backed-up Tax Rates", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Click a file below to download it, then import it into the {{taxRatesA}}tax rates table{{/taxRatesA}}.", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Support", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Need help?", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Our team is here for you. View our {{docsA}}support docs{{/docsA}} or {{ticketA}}open a support ticket{{/ticketA}}.", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
_x( "Health", "This section displays the overall health of WooCommerce Shipping & Tax and the things it depends on", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "WooCommerce", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Jetpack", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Automated Taxes", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Go to the Tax settings", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Go to General settings", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Automated taxes documentation", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Service data was found, but is more than three days old", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Service data was found, but is more than one day old", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Service data is up-to-date", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Service data found, but may be out of date", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "No service data available", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "WooCommerce Shipping & Tax Data", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Last updated %s.", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Refresh", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Log tail copied to clipboard", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
_n( "Last %s entry. {{a}}Show full log{{/a}}", "Last %s entries. {{a}}Show full log{{/a}}", 1, "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Copy for support", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Request was made %s - check logs below or {{a}}edit service settings{{/a}}", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Edit service settings", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "Services", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "No services configured. {{a}}Add a shipping service{{/a}}", "woocommerce-services" ), // dist/chunks/4327f6a24bddfa4f7372.min.js:1
__( "No activity yet", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Labels older than 30 days cannot be refunded.", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "USPS labels without tracking are not eligible for refund.", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Request refund", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Request refund", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Label images older than 180 days are deleted by our technology partners for general security and data privacy concerns.", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Reprint", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Reprint shipping label", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "View details", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Schedule a pickup", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Print customs form", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "%(service)s label (#%(labelIndex)d)", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Tracking #: {{trackingLink/}}", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Internal note", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Note sent to customer", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "%(service)s label (#%(labelNum)d) refund requested (%(amount)s)", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "%(service)s label (#%(labelNum)d) refunded (%(amount)s)", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "%(service)s label (#%(labelNum)d) refund rejected", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Refund", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Refunded %(amount)s", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Note", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Toggle menu", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Cancel", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Refund label (-%(amount)s)", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Request a refund", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "You can request a refund for a shipping label that has not been used to ship a package. It will take at least %(days)s days to process.", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Purchase date", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Amount eligible for refund", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Cancel", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Print", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Reprint shipping label", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "If there was a printing error when you purchased the label, you can print it again.", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "NOTE: If you already used the label in a package, printing and using it again is a violation of our terms of service and may result in criminal charges.", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Paper size", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Close", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Label #%(labelIndex)s details", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Receipt", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Service", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Package", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Items", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "N/A", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "%(service)s label (#%(labelIndex)d)", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Purchasing\\u2026", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
_n( "%(count)s event", "%(count)s events", 1, "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Show notes from %(date)s", "woocommerce-services" ), // dist/chunks/7ecc01dc97271b63f096.min.js:1
__( "Required", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Optional", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Dismiss", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Saving\\u2026", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Save Settings", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "More", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Untitled", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "You have unsaved changes.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "You have unsaved changes. Are you sure you want to leave this page?", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Your shipping packages have been saved.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Unable to save your shipping packages. Please try again.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
_n( "Add package", "Add packages", 1, "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Done", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Cancel", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "{{icon/}} Delete this package", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Invalid value.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "This field is required.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Type of package", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Box", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Envelope", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Package name", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Unique package name", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "This field must be unique", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Dimensions (L x W x H)", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Weight of empty package", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "0.0", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
/* translators: Length placeholder for dimensions input */
__( "L", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
/* translators: Width placeholder for dimensions input */
__( "W", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
/* translators: Height placeholder for dimensions input */
__( "H", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "All packages selected", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
_n( "%(selectedCount)d package selected", "%(selectedCount)d packages selected", 1, "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Expand Services", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Return to Order #%(orderId)s", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Your shipping settings have been saved.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Unable to save your shipping settings. Please try again.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Save changes", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Unable to get your settings. Please refresh the page to try again.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Shipping Labels", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Print shipping labels yourself and save a trip to the post office", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Only the site owner can manage shipping label payment methods. Please contact %(ownerName)s (%(ownerLogin)s) to manage payment methods.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Retry", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Only the site owner can change these settings. Please contact %(ownerName)s (%(ownerLogin)s) to change the shipping label settings.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Credit cards are retrieved from the following WordPress.com account: %(wpcomLogin)s <%(wpcomEmail)s>", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "We'll charge the credit card on your account (%(card)s) to pay for the labels you print", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "To purchase shipping labels, add a credit card.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Choose a different card", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "To purchase shipping labels, choose a credit card you have on file or add a new card.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Add another credit card", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "To purchase shipping labels, add a credit card.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Add a credit card", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Email Receipts", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Email the label purchase receipts to %(ownerName)s (%(ownerLogin)s) at %(ownerEmail)s", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Service Selection", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Save the service selection from previous transaction.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Package Selection", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Save the package selection from previous transaction.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Paper size", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Payment", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "American Express", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Discover", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "MasterCard", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "VISA", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "PayPal", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "%(card)s ****%(digits)s", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
_x( "Expires %(date)s", "date is of the form MM/YY", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
/* translators: Name for WeChat Pay - https://pay.weixin.qq.com/ */
__( "WeChat Pay", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Name", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Dimensions", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Edit", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Remove", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Packaging", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Add boxes, envelopes, and other packages you use most frequently", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Add package", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Carrier account", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Set up your own carrier account by adding your credentials here", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Name", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Credentials", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Your carrier account was disconnected succesfully.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "There was an error trying to disconnect your carrier account", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Cancel", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Disconnect", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Disconnect", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Connect", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Disconnect your %(carrier_name)s account", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "This will remove the connection with %(carrier_name)s. All of your %(carrier_name)s account information will be deleted and you won\\u2019t see %(carrier_name)s rates.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Live rates at checkout", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Show live rates directly on your store - never under or overcharge for shipping again", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Add to shipping zones", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "To be displayed at checkout, this carrier must be added as a shipping method to selected shipping zones", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Discounted %(carrierName)s shipping labels", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "USPS", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Ship with the largest delivery network in the United States", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "USPS", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Live rates for %(carrierName)s at checkout", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "USPS", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "DHL Express", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Express delivery from the experts in international shipping", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "DHL Express", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Live rates for %(carrierName)s at checkout", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "DHL Express", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Carrier", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Features", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Shipping method", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "View and manage your subscription usage", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Name", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Usage", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Your store is over the limit for rate calls this month and your account will be charged for overages. To prevent future overage charges you can upgrade your plan.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Manage", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Your subscription was succesfully activated.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "There was an error trying to activate your subscription.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Activate", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "This field is required", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "The UPS account number needs to be 6 letters and digits in length", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "The phone number needs to be 10 digits in length", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "The ZIP/Postal code needs to be 5 digits in length", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "The email format is not valid", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "The company website format is not valid", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "The invoice number needs to be 9 or 13 letters and digits in length", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "The date must be a valid date in the format YYYY-MM-DD", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Cancel", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Ok", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Cancel connection", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "This action will delete any information entered on the form.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Select one\\u2026", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "State", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "State", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Your carrier account was connected successfully.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "There was an error connecting to your %(carrierName)s account. Please check that all of the information entered matches your %(carrierName)s account and try to connect again.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Connect your UPS account", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Set up your own UPS carrier account to compare rates and print labels from multiple carriers in WooCommerce Shipping. Learn more about adding {{a}}carrier accounts{{/a}}.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "If you need a UPS account number, go to {{a}}UPS.com{{/a}} to create a new account.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "General information", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "This is the account number and address from your UPS profile", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Account number", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Name", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Address", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Address 2 (optional)", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "City", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Country", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "ZIP/Postal code", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Phone", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Email", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Company information", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "This is the company info you used to create your UPS account", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Company name", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Job title", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Company website", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "UPS account information", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "I have been issued an invoice from UPS within the past 90 days", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "UPS invoice number", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "UPS invoice date", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "UPS invoice amount", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "UPS invoice currency", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "UPS invoice control id", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Connect", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Cancel", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Loading", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "%(carrierName)s not supported.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Your carrier account was connected successfully.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "There was an error connecting to your %(carrierName)s account. Please check that all of the information entered matches your %(carrierName)s account and try to connect again.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Connect your %(carrierName)s account", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Set up your own carrier account to compare rates and print labels from multiple carriers in WooCommerce Shipping. Learn more about adding {{a}}carrier accounts{{/a}}.", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "General Information", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Connect", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Cancel", "woocommerce-services" ), // dist/chunks/a93e468c4be157e9fc2d.min.js:1
__( "Create shipping label", "woocommerce-services" ), // dist/chunks/b42dc9c183dab13ebdbc.min.js:1
_n( "Track Package", "Track Packages", 1, "woocommerce-services" ), // dist/chunks/b42dc9c183dab13ebdbc.min.js:1
__( "Create new label", "woocommerce-services" ), // dist/chunks/b42dc9c183dab13ebdbc.min.js:1
_n( "Track Package", "Track Packages", 1, "woocommerce-services" ), // dist/chunks/b42dc9c183dab13ebdbc.min.js:1
__( "Create shipping label", "woocommerce-services" ), // dist/chunks/b42dc9c183dab13ebdbc.min.js:1
__( "Connection error: unable to create label at this time", "woocommerce-services" ), // dist/chunks/b42dc9c183dab13ebdbc.min.js:1
_n( "%(itemCount)d item was fulfilled on {{span}}%(createdDate)s{{/span}}", "%(itemCount)d items were fulfilled on {{span}}%(createdDate)s{{/span}}", 1, "woocommerce-services" ), // dist/chunks/b42dc9c183dab13ebdbc.min.js:1
_n( "%(itemCount)d item is ready to be fulfilled", "%(itemCount)d items are ready to be fulfilled", 1, "woocommerce-services" ), // dist/chunks/b42dc9c183dab13ebdbc.min.js:1
__( "We were unable to automatically verify the address \\u2014 %(error)s.", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "We were unable to automatically verify the address.", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Address entered", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Automatic verification failed for this address. It may still be a valid address \\u2014 use the tools below to manually verify.", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Verify with USPS", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "View on Google Maps", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Edit address", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Use address as entered", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Packaging", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "No packages selected", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "1 item in 1 package: %(weight)s %(unit)s total", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "%(itemsCount)d items in 1 package: %(weight)s %(unit)s total", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "%(itemsCount)d items in %(packageCount)d packages: %(weight)s %(unit)s total", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Use these packages", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Packages to be Shipped", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Add items", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Items to fulfill", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Weight", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "QTY", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "There are no items in this package.", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Total Weight (with package)", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "0", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Move", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Individually Shipped Item", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Item Dimensions", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Package details", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Add package", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Select a package type", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Please select a package", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "{{itemLink/}} is currently saved for a later shipment.", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "{{itemLink/}} is currently shipped in its original packaging.", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "{{itemLink/}} is currently in {{pckg/}}.", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Cancel", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Submit", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Move item", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Where would you like to move it?", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Add to a New Package", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Ship in original packaging", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "%(item)s from {{pckg/}}", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Close", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Add", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Add item", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Which items would you like to add to {{pckg/}}?", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Customs information incomplete", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Customs information valid", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Customs", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Save customs form", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Return to sender if package is unable to be delivered", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Contents type", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Merchandise", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Documents", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Gift", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Sample", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Other\\u2026", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Details", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Restriction type", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "None", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Quarantine", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Sanitary / Phytosanitary inspection", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Other\\u2026", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Details", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "ITN", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "more info", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Description", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Optional", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Weight (per unit)", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Value (per unit)", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Unsaved changes made to packages", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "No rates found", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "%(serviceName)s: %(rate)s", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Total rate: %(total)s", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Customer paid a {{shippingMethod/}} of {{shippingCost/}} for shipping", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Your customer selected {{shippingMethod/}}", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Shipping rates", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "The service and rate chosen by the customer at checkout is not available. Please choose another.", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Choose rate: %(pckg)s", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Signature required", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Adult signature required", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Shipping summary", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Shipping summary", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Paper size", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Notify the customer with shipment details", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Mark this order as complete and notify the customer", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "WooCommerce Shipping gives you access to USPS Commercial Pricing, which is discounted over Retail rates.", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "You save %s with WooCommerce Shipping", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Package %(index)s \\u2013 %(title)s", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Your UPS account will be charged", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Total", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Shipping from", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Edit", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
_n( "shipping label ready", "shipping labels ready", 1, "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Choose credit card", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "To print this shipping label, {{a}}choose a credit card to add to your account{{/a}}.", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Add credit card", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "To print this shipping label, {{a}}add a credit card to your account{{/a}}.", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Print", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Purchasing\\u2026", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
_n( "Buy shipping label", "Buy shipping labels", 1, "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Required", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Optional", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Dismiss", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Saving\\u2026", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Save Settings", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Untitled", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Expand", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Your shipping packages have been saved.", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Unable to save your shipping packages. Please try again.", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
_n( "Add package", "Add packages", 1, "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Done", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Cancel", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "{{icon/}} Delete this package", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Invalid value.", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "This field is required.", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Type of package", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Box", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Envelope", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Package name", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Unique package name", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "This field must be unique", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Dimensions (L x W x H)", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Weight of empty package", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "0.0", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
/* translators: Length placeholder for dimensions input */
__( "L", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
/* translators: Width placeholder for dimensions input */
__( "W", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
/* translators: Height placeholder for dimensions input */
__( "H", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "All packages selected", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
_n( "%(selectedCount)d package selected", "%(selectedCount)d packages selected", 1, "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Expand Services", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "HS Tariff number", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "more info", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Origin country", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Country where the product was manufactured or assembled", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Description", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Weight (%s per unit)", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Value ($ per unit)", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
_n( "Create shipping label", "Create shipping labels", 1, "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Origin address", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Destination address", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Validating address\\u2026", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Invalid address", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "You've edited the address, please revalidate it for accurate rates", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "One of the address data has non-roman character(s) that might not be printed properly!", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Name", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Company", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Phone", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "%(message)s. Please modify the address and try again.", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Address", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "City", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "State", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Select one\\u2026", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "State", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "ZIP/Postal code", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Country", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Verify address", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Use address as entered", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "We have slightly modified the address entered. If correct, please use the suggested address to ensure accurate delivery.", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Address entered", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Suggested address", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Use selected address", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "Edit address", "woocommerce-services" ), // dist/chunks/bd7242945b25544c602a.min.js:1
__( "More", "woocommerce-services" ), // dist/chunks/cd87f3f33bf21b75b06d.min.js:1
__( "Which package would you like to track?", "woocommerce-services" ), // dist/chunks/d98fdeff61280fb4c67c.min.js:1
__( "Dismiss", "woocommerce-services" ), // dist/chunks/e60170d2f95aee89a0ed.min.js:1
__( "No tracking information available at this time", "woocommerce-services" ), // dist/chunks/e60170d2f95aee89a0ed.min.js:1
__( "Required", "woocommerce-services" ), // dist/chunks/e9577575f6d86f17b50c.min.js:1
__( "Optional", "woocommerce-services" ), // dist/chunks/e9577575f6d86f17b50c.min.js:1
__( "Dismiss", "woocommerce-services" ), // dist/chunks/e9577575f6d86f17b50c.min.js:1
__( "More", "woocommerce-services" ), // dist/chunks/e9577575f6d86f17b50c.min.js:1
__( "You have unsaved changes.", "woocommerce-services" ), // dist/chunks/e9577575f6d86f17b50c.min.js:1
__( "You have unsaved changes. Are you sure you want to leave this page?", "woocommerce-services" ), // dist/chunks/e9577575f6d86f17b50c.min.js:1
__( "Your changes have been saved.", "woocommerce-services" ), // dist/chunks/e9577575f6d86f17b50c.min.js:1
__( "There was a problem with one or more entries. Please fix the errors below and try saving again.", "woocommerce-services" ), // dist/chunks/e9577575f6d86f17b50c.min.js:1
__( "Save changes", "woocommerce-services" ), // dist/chunks/e9577575f6d86f17b50c.min.js:1
__( "Saved Packages", "woocommerce-services" ), // dist/chunks/e9577575f6d86f17b50c.min.js:1
__( "Add and edit saved packages using the {{a}}Packaging Manager{{/a}}.", "woocommerce-services" ), // dist/chunks/e9577575f6d86f17b50c.min.js:1
__( "All services selected", "woocommerce-services" ), // dist/chunks/e9577575f6d86f17b50c.min.js:1
_n( "%(numSelected)d service selected", "%(numSelected)d services selected", 1, "woocommerce-services" ), // dist/chunks/e9577575f6d86f17b50c.min.js:1
__( "Expand Services", "woocommerce-services" ), // dist/chunks/e9577575f6d86f17b50c.min.js:1
__( "Service", "woocommerce-services" ), // dist/chunks/e9577575f6d86f17b50c.min.js:1
__( "Price adjustment", "woocommerce-services" ), // dist/chunks/e9577575f6d86f17b50c.min.js:1
__( "Increase the rates calculated by the carrier to account for packaging and handling costs. You can also add a negative amount to save your customers money.", "woocommerce-services" ), // dist/chunks/e9577575f6d86f17b50c.min.js:1
);
/* THIS IS THE END OF THE GENERATED FILE */
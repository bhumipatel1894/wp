﻿=== WooCommerce Wholesale Pricing ===
Contributors: wpexpertsio
Tags: WooCommerce, Pricing, Promotions
Requires at least: 4.9
Tested up to: 6.1.1
Requires PHP: 5.6
Stable tag: 2.1.1
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==
A WooCommerce extention that gives an ability to your store to better success with wholesale pricing. You can easily manage your existing store with wholesale pricing. Just you need to add a wholesaler customer by selecting their role “Wholesaler”, wholesale prices only visible for Wholesaler Customers not for public customers.

== Installation ==
1- Download WooCommerce Wholesale Pricing from WooCommerce.com
2- Go to: WordPress Admin > Plugins > Add New and Upload Plugin with the file you downloaded with Choose File.
3- Install Now and Activate the extension.